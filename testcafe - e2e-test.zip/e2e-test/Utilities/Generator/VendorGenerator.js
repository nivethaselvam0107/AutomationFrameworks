global.localStorage = require('localStorage');
global.fetch = require('node-fetch');
import { JsonRPCService } from '../../../common/modules/gw-portals-transport-js';
const btoa = require('btoa');
const data = require('../../producer-engage/Data/PE_Data.json')
const config = require('../../package.json');
var username = data.login.apiUser;
var password = data.login.password;
const authString = `${username}:${password}`;

const backendHost = process.env.BACKEND_HOST;

export default class VendorGenerator {
    async generateVendorWithBodyService() {
        await this.generateVendorWithServices(["body"]);
    }
    async  generateVendorWithServices(serviceList) {
        const endpoint = `${backendHost}:8280/ab/service/edge/vendorgen/vendorgen`;
        const dataObj = { serviceTypes: serviceList };
        return JsonRPCService.send(endpoint, 'generateVendor', [dataObj], { Authorization: 'Basic' + btoa(authString) });
    }
}
