global.localStorage = require('localStorage');
global.fetch = require('node-fetch');
import PolicyGenerator from './PolicyGenerator';
import { JsonRPCService } from '../../../common/modules/gw-portals-transport-js';
const btoa = require('btoa');
const config = require('../../package.json');
const data = require('../../producer-engage/Data/PE_Data.json')
var username = data.login.apiUser;
var password = data.login.password;
const authString = `${username}:${password}`;
const policyGen = new PolicyGenerator();

const backendHost = process.env.BACKEND_HOST;

export default class RenewalGenerator {
    async createBasicDraftPARenewal() {
        var policyData = await policyGen.createBasicBoundPAPolicy();
        var status = await this.createRenewal(policyData.policyNum,'Draft');
        console.log(status);

        return policyData;
    }
    async createRenewal(policyNumber,renewalStatus) {
        const endpoint = `${backendHost}:8180/pc/service/edge/test-policy/datacreation`;
        const dataObj = [policyNumber,renewalStatus];
        return JsonRPCService.send(endpoint, 'createRenewal', dataObj, { Authorization: 'Basic' + btoa(authString) });
    }
}
