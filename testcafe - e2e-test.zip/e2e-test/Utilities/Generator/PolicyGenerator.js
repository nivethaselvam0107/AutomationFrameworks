import { JsonRPCService } from '../../../common/modules/gw-portals-transport-js';
const fromEntries = require('fromentries')
const btoa = require('btoa');
const data = require('../../producer-engage/Data/PE_Data.json');
global.localStorage = require('localStorage');
global.fetch = require('node-fetch');
const environment = process.env.TEST_ENV_URL;
var username = data.login.apiUser;
var password = data.login.password;
const authString = `${username}:${password}`;

const backendHost = process.env.BACKEND_HOST;

export default class PolicyGenerator {
    async createBasicBoundPAPolicy() {
        var policyNum = await this.createBasicPolicy('Bound', 'PersonalAutoLine');
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }

    async createBasicBoundHOPolicy() {
        var policyNum;
        if (environment.includes('granite')) {
            policyNum = await this.createBasicPolicy('Bound', 'HOPLine');
        } else {
            policyNum = await this.createBasicPolicy('Bound', 'HomeownersLine_HOE');
        }
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }
    async createBasicBoundBOPolicy() {
        const policyNum = await this.createBasicPolicy('Bound', 'BusinessOwnersLine');
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }

    async createBasicBoundCPPolicy() {
        const policyNum = await this.createBasicPolicy('Bound', 'CommercialPropertyLine');
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }
    async createBasicCPolicy() {
        const policyNum = await this.createCPPolicy('Bound', 'CommercialPropertyLine', 1, 1);
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }
    async createBasicBoundWCPolicy() {
        const policyNum = await this.createBasicPolicy('Bound', 'WorkersCompLine');
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }
    async createBasicBoundIMPolicy() {
        const policyNum = await this.createBasicPolicy('Bound', 'InlandMarineLine');
        var policyData = await this.getAgentPolicyData(policyNum);
        return policyData;
    }
    async createBasicQuotedPAPolicy() {
        const policynumber = await this.createBasicPolicy('Quoted', 'PersonalAutoLine');
        var policyData = await this.getAgentPolicyData(policynumber);
        return policyData ;
    }
    async createBasicPolicy(policyStatus, policyLine) {
        const endpoint = `${backendHost}:8180/pc/service/edge/policygen/policygen`;
        const dataObj = {
            policyStatus: policyStatus,
            policyLine: policyLine
        };
        return JsonRPCService.send(endpoint, 'generateBasicPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString)});
    }
    async getAgentPolicyData(policyNum) {
        let map = new Map();
        const endpoint = `${backendHost}:8180/pc/service/edge/gateway/policy`;
        const dataObj = policyNum;
        var policyData = await JsonRPCService.send(endpoint, 'getPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString)});
        map.set('accountName', policyData.account.policySummaries[0].accountHolderName); 
        map.set('accountNumber',  policyData.account.accountNumber);
        map.set('accountFirstName', policyData.account.accountHolder.firstName);
        map.set('accountLastName', policyData.account.accountHolder.lastName);
        map.set('policyNum', policyData.policyNumber);
        map.set('policyEffectiveDate', policyData.account.policySummaries[0].effective);
        map.set('policyExpirationDate', policyData.account.policySummaries[0].expiration);
        map.set('policyTotalAmount', policyData.latestPeriod.totalCost.amount);
        map.set('zipCode', policyData.account.accountHolder.primaryAddress.postalCode);
        map.set('producerOrg', policyData.latestPeriod.producerCodeOfServiceOrg);
        map.set('producerCode', policyData.latestPeriod.producerCodeOfService);
        map.set('productCode', policyData.product.productCode);
        map.set('policyStatus', policyData.periods[0].status);
        map.set('AddressLine1', policyData.account.accountHolder.primaryAddress.addressLine1);
        map.set('AddressLine2', policyData.account.accountHolder.primaryAddress.addressLine2);
        map.set('AddressLine3', policyData.account.accountHolder.primaryAddress.addressLine3);
        map.set('city', policyData.account.accountHolder.primaryAddress.city);
        map.set('state', policyData.account.accountHolder.primaryAddress.state);
        map.set('coverables',policyData.coverables);
        let obj = fromEntries(map);
        return obj;
    }
    async getAgentPolicy(policyNum) {
        let map = new Map();
        const endpoint = `${backendHost}:8180/pc/service/edge/gateway/policy`;
        const dataObj = policyNum;
        var policyData = await JsonRPCService.send(endpoint, 'getPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString)});
    return policyData;
    }

    async getAgentPolicyDocument(policyNum) {
        let map = new Map();
        const endpoint = `${backendHost}:8180/pc/service/edge/gateway/policy`;
        const dataObj = policyNum;
        var policyDoc = await JsonRPCService.send(endpoint, 'getDocumentsForPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString) });
        map.set('author',policyDoc[0].author);
        map.set('mimeType',policyDoc[0].mimeType);
        map.set('securityType',policyDoc[0].securityType);
        map.set('name',policyDoc[0].name);
        map.set('canDelete',policyDoc[0].canDelete);
        map.set('status',policyDoc[0].status);
        map.set('documentType',policyDoc[0].documentType);
        let obj = fromEntries(map);
        return obj;
    }
    async getQuoteData(quoteNum, zipCode) {
        let map = new Map();
        const endpoint = `${backendHost}:8180/pc/service/edge/test-quote/quote`;
        const dataObj = {
            quoteID: quoteNum,
            postalCode: zipCode
        };
        var policyData = await JsonRPCService.send(endpoint, 'retrieve', [dataObj], { Authorization: 'Basic' + btoa(authString) });
        map.set('accountNumber',policyData.bindData.accountNumber);
        map.set('policyNum',policyData.bindData.policyNumber);
        map.set('policyEffectiveDay',policyData.baseData.periodStartDate.day);
        map.set('policyEffectiveMonth',policyData.baseData.periodStartDate.month);
        map.set('policyEffectiveYear',policyData.baseData.periodStartDate.year);
        map.set('policyExpirationDay',policyData.baseData.periodEndDate.day);
        map.set('policyExpirationMonth',policyData.baseData.periodEndDate.month);
        map.set('policyExpirationYear',policyData.baseData.periodEndDate.year);
        map.set('policyTotalAmount',policyData.bindData.paymentPlans[0].total.amount);
        map.set('paymentPlanName',policyData.bindData.paymentPlans[0].name);
        map.set('policyCurrentPayment',policyData.bindData.paymentPlans[0].downPayment.amount);
        let obj = fromEntries(map);
        return obj;

    }

    async getQuote(quoteNum, zipCode) {
        const endpoint = `${backendHost}:8180/pc/service/edge/test-quote/quote`;
        const dataObj = {
            quoteID: quoteNum,
            postalCode: zipCode
        };
        var policyData = await JsonRPCService.send(endpoint, 'retrieve', [dataObj], { Authorization: 'Basic' + btoa(authString) });
        return policyData;
    }
    async getAgentPolicy(policyNum) {
        const endpoint = `${backendHost}:8180/pc/service/edge/gateway/policy`;
        const dataObj = policyNum;
        var policyData = await JsonRPCService.send(endpoint, 'getPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString)});
        return policyData;
    }


    async createCPPolicy(policyStatus, policyLine, locations, buildings) {
        const endpoint = `${backendHost}:8180/pc/service/edge/policygen/policygen`;
        const dataObj = {
            policyStatus: policyStatus,
            policyLine: policyLine,
            numOfLocations: locations,
            numOfBuildingsPerLocation: buildings
        };
        return JsonRPCService.send(endpoint, 'generateBasicPolicy', [dataObj], { Authorization: 'Basic' + btoa(authString) });

    }
}
