import { Selector, t } from 'testcafe';
import Helper from '../Helper';
import Assertion from '../Assertions';

const helper = new Helper();
const assert = new Assertion();

export default class Modal {
    constructor() {
        this.confirmButton = Selector("[class*='Modal-module__modalInner'] [class*='Modal-module__modalFooter'] [class*='Button-module__primary']");
    }
    async confirm() {
        await helper.click(this.confirmButton);
    }
}