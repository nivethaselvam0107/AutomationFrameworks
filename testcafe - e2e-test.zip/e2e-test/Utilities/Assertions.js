import {Selector,t} from 'testcafe';
import fs from 'fs';

export default class Assertion {

    async assertEqual(actual, expected, message) {
        await t.expect(actual).eql(expected, message);
    }
    async assertNotEqual(actual, unexpected, message){
        await t.expect(actual).notEql(unexpected, message);
    }
    async isElementClickable(locator, attributeName, message) {
        await t.expect(locator.hasAttribute(attributeName)).notOk(message);
    }
    async hasText(value1, text, message) {
        await t.expect(value1).contains(text, message);
    }
    async hasHref(locator, text) {
        await t.expect(locator.getAttribute('href')).contains(text);
    }
    async elementPresent(locator, message) {
        await t.expect(locator.exists).ok(message);
    }
    async elementChecked(locator,message){
        await t.expect(locator.checked).ok(message);
    }
    async hasClass(locator, text) {
        await t.expect(locator.getAttribute('class')).contains(text);
    }
    async attributeNotPresent(locator,attributeName, attributeValue,text ){
        await t.expect(locator.getAttribute(attributeName)).notEql(attributeValue,text);
    }
    async attributePresent(locator,attributeName, attributeValue,text ){
        await t.expect(locator.getAttribute(attributeName)).eql(attributeValue,text);
    }
    async elementNotPresent(locator, message) {
        await t.expect(locator.exists).notOk(message);
    }
    async verifyDownload(path, message) {
        await t.expect(fs.existsSync(path)).ok(message);
    }
    async textContains(actual, expected, message) {
        await t.expect(actual).contains(expected, message);
    }
    async textNotContains(actual, expected, message) {
        await t.expect(actual).notContains(expected, message);
    }  
    async isElementNotClickable(locator, attributeName, message) {
        await t.expect(locator.hasAttribute(attributeName)).ok(message);
        }
    async getAttributeValue(locator, attributeName, attributeValue) {
        await t.expect(locator.getAttribute(attributeName)).eql(attributeValue);
    }
    async assertAttributeValue(element, attribute, expected, message) {
        const attributeValue = await Selector(element).getAttribute(attribute);
        await this.assertEqual(attributeValue, expected, message);
    }
}
