const _ = require('lodash');

module.exports = (testName, fixtureName, fixturePath, testMeta, fixtureMeta, metaFilter) => {
    if (_.isEmpty(metaFilter)) {
        return true;
    }

    const metaFilterAsArray = metaFilter.split(',');

    let shouldRunTest = false;
    _.forEach(metaFilterAsArray, (filterToTest) => {
        // Splitting Type e.g Platform and Value e.g Granite
        const [filteredType, filteredValue] = metaFilter.split('=');
        // Case where we say what test/fixture to run
        const testMetaValueFromTest = _.get(testMeta, filteredType);
        const fixtureMetaValueFromTest = _.get(fixtureMeta, filterToTest);
        // Handle case where fixtureMeta is {foo: true}, and testMeta is {foo: false}
        if (fixtureMetaValueFromTest && testMetaValueFromTest === undefined) {
            shouldRunTest = true;
        } else if (testMetaValueFromTest === filteredValue) {
            shouldRunTest = true;
        }
    });
    return shouldRunTest;
};
