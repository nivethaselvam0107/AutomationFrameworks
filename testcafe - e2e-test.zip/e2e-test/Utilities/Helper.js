import { ClientFunction, t } from 'testcafe';
export default class Helper {

    // Type Text
    async typeText(locator, textValue) {
        await t.typeText(locator, textValue, {
            replace: true
        });
    }   
    async click(locator) {
        await t.click(locator);
    }
    async selectDropdown(locatorSelect, locatoroption, option) {
        await t.click(locatorSelect);
        await t.click(locatoroption.withExactText(option));
    }
    async selectDropdownWithText(locatorSelect, locatoroption, option) {
        await t.click(locatorSelect);
        await t.click(locatoroption.withText(option));
    }

    //To Remove text from Input Box
    async removeText(locator) {
        await t.click(locator);
        await t.pressKey('ctrl+a delete');
    }
    async pressEnter() {
        await t.pressKey('enter');
    }
    async pressTab() {
        await t.pressKey('tab');
    }
    async pressEsc() {
        await t.pressKey('esc');
    }
    async pageDown()
    {
        await t.pressKey('pagedown');
    }
    async hover(locator) {
        await t.hover(locator);
    }

    //Get Text
    async getTextAtLocator(locator) {
        return await locator.innerText;
    }
    //Get Value from the locator
    async getValueAttributeFromLocator(locator) {
        return await locator.value;
    }
    //To upload file
    async uploadFile(uploadDocInput, filepath) {
        await t.setFilesToUpload(uploadDocInput, filepath);
    }
    async getAttribute(locator, attributeName) {
        await locator.getAttribute(attributeName);
    }
    async removeRequiredTextAndValidate(elementLoc,errorLocfield) {
        await this.removeText(elementLoc);
        await this.pressTab();
        await this.pressEsc();
        await 
        await t.expect(
            await this.getTextAtLocator(errorLocfield)
        ).eql('This is a required field', `Incorrect alert message displayed for required field`);
    }

    //dateformat
    async formatDate(date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2)
            month = '0' + month;
        if (day.length < 2)
            day = '0' + day;
        var dformat = [year, month, day].join('-');

        return dformat;
    }
    async futureDate(){
        var d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + (d.getDate()+7),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    var dformat = [year, month, day].join('-');

    return dformat; 
    }
    async futureDatePolicy(date){
        var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + (d.getDate()+7),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    var dformat = [year, month, day].join('-');

    return dformat; 

    }
    async pastDate(){
        var d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + (d.getDate()-7),
        year = d.getFullYear();

    if (month.length < 2)
        month = '0' + month;
    if (day.length < 2)
        day = '0' + day;
    var dformat = [year, month, day].join('-');

    return dformat; 
    }



}



