import { Selector, t } from 'testcafe';
import Helper from '../Utilities/Helper';
import Assertion from '../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertion();

export default class CommonLocators {
    constructor() {
       
        this.nextButton=Selector("[id='gw-wizard-Next']");
        this.cancelButton = Selector("[id='gw-wizard-cancel']");
        this.confirmCancelButton = Selector("[role='document'] [class*='primary']");
        this.previousButton=Selector("[id='gw-wizard-previous']");
        this.doneBtn=Selector("[id='doneButton']")
        this.scheduledItemsAddBtn_Disabled=Selector("[id*='scheduleItem'] [class*='Button-module__disabled']");
        this.scheduledItemsAddBtn=Selector("[id*='scheduleItem'] [class*='Button-module__primary']");
    }
     
    async confirmCancel() {
        await helper.click(this.confirmCancelButton);
    }
    async validateNextButtonIsDisabled() {
        await assert.isElementNotClickable(this.nextButton,'disabled','Button is enabled');
    }
    async validateScheduledAddButtonIsDisabled(){
        await assert.isElementNotClickable(this.scheduledItemsAddBtn_Disabled,'disabled','Button is enabled');
    }
    async validateScheduledAddButtonIsEnabled(){
        await assert.isElementClickable(this.scheduledItemsAddBtn,'enabled', 'Button is Disabled');
    }
    async validateNextButtonIsEnabled(){
        await assert.isElementClickable(this.nextButton,'enabled', 'Button is Disabled');
    }
    async pressCancel() {
        await helper.click(this.cancelButton); 
    }
    async goPrev(){
        await helper.click(this.previousButton);
    }
    async goNext() { 
        await helper.click(this.nextButton);
        await t.wait(1000);
    }
    async doneButton(){
        await helper.click(this.doneBtn);
    }
    async verifyCancel(){ //Verfiy Cancel button in any page
        await assert.elementPresent(this.cancelButton, 'Cancel button is not displayed');
    }
    async verifyPrevious(){ //Verify Previous button in any page
        await assert.elementPresent(this.previousButton, 'Previous button is not displayed');
    }
    async verifyTitle(title){ //Verify title of any page
        await assert.assertEqual(this.title.innerText, title, title+' page is not displayed')
    }
       
    async isNextBtnDisabled(value) {
        await assert.isElementClickable(this.nextButton, value, "Next Button is not disabled");
    }
}