require('json5/lib/register');
const fs = require('fs');
const createTestCafe = require('testcafe');
const metaFilterHelper = require('../e2e-test/Utilities/MetaFilterHelper');
const glob = require('fast-glob');
global.fetch = require('node-fetch');
global.localStorage = require('localStorage');

module.exports = (runArgs) => {
    console.log('Configuring testCafe...');

    const {
        browser,
        concurrency,
        reportsFolder,
        testFolder,
        selectorTimeout,
        portalToTest,
        backendHost,
        app,
        quarantineMode,
        metaFilter
    } = runArgs;

    const reportNameML = `report-${app}.xml`;
    const reportNameHTML = `report-${app}.html`;
    localStorage.setItem('selectedLanguage', 'en-US');
    process.env.TEST_ENV_URL = portalToTest;
    process.env.BACKEND_HOST = backendHost;
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = 0;

    console.log(`Tests are going to be run in this URL ${process.env.TEST_ENV_URL} and this browser ${browser} against this backend ${process.env.BACKEND_HOST}`);

    if (!fs.existsSync(reportsFolder)) {
        fs.mkdirSync(reportsFolder);
    }
    const filter = (testName, fixtureName, fixturePath, testMeta, fixtureMeta) => {
        return metaFilterHelper(
            testName,
            fixtureName,
            fixturePath,
            testMeta,
            fixtureMeta,
            metaFilter
        );
    };

    const xmlstream = fs.createWriteStream(`${reportsFolder}/${reportNameML}`);
    const htmlstream = fs.createWriteStream(`${reportsFolder}/${reportNameHTML}`);
    const testFiles = glob.sync(`${testFolder}${app}/Fixtures/**`);

    let testcafe = null;
    createTestCafe('localhost', 1236, 1237)
        .then((tc) => {
            testcafe = tc;
            console.log('All set, running testcafe ...');
            return (
                testcafe.createRunner()
                // list multiple test files

                    .src([testFiles])
                    .browsers(browser)
                    .concurrency(concurrency)
                    .reporter([{
                        name: 'xunit',
                        output: xmlstream
                    }, {
                        name: 'html',
                        output: htmlstream
                    }])
                    .screenshots(
                        `${reportsFolder}`,
                        true,
                        //eslint-disable-next-line no-template-curly-in-string
                        '${DATE}_${TIME}/${FIXTURE}/${TEST}/test-${TEST_INDEX}.png'
                    )
                    .filter(filter)
                    .run({
                        skipJsErrors: true,
                        skipUncaughtErrors: true,
                        selectorTimeout,
                        quarantineMode
                    })
            );
        })
        .then((failedCount) => {
             xmlstream.end();
             htmlstream.end();
            testcafe.close();
            if (failedCount > 0) {
                console.log('##### ERROR ####');
                throw new Error(`Tests failed: ${failedCount}`);
            }
        });
};
