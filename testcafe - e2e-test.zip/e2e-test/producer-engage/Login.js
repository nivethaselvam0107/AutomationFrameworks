import { Selector, Role, t } from 'testcafe';
import Helper from '../Utilities/Helper';
const data = require('../producer-engage/Data/PE_Data.json');
const policy = require('../Utilities/Generator/PolicyGenerator');
const helper = new Helper();
const username = Selector("input[id='username']");
const password = Selector("input[id='password']");
const signin = Selector("button[id='signIn']");
const url = process.env.TEST_ENV_URL;
var uname;

const login = Role(url, async t => {
    await t.maximizeWindow();
    await helper.typeText(username, data.login.username);
    await helper.typeText(password, data.login.password)
    await helper.click(signin);
}, { preserveUrl: true });

const loginasDiffUser = Role(url, async t => {
    await t.maximizeWindow();
    await helper.typeText(username, uname);
    await helper.typeText(password, data.login.password)
    await helper.click(signin);
}, { preserveUrl: true });

export default class Login {
    async loginasDiffUser(producerCode) {
        uname = await this.setUserForGPA(producerCode);
        await t.useRole(loginasDiffUser);
    }
    async login() {
        await t.useRole(login);
    }
    async setUserForGPA(producerCode) {
        if (producerCode == '100-002541') {
            if (url.includes('service-rep-engage')) {
                uname = 'bbaker';
            }
            uname = 'aarmstrong';
        }
        else if ((producerCode == '301-008578') || (producerCode == '201-343434')) {
            if (url.includes('service-rep-engage')) {
                uname = 'bbaker';
            }
            else {
                uname = 'carkle';
            }
        }
        return await uname;
    }
}
