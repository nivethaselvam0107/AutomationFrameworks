import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import NavBar from '../Pages/NavBar';
import AgentDashboard from '../Pages/AgentDashboard';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import AccountSummary from '../Pages/AccountSummary';
import Tiles from '../Pages/Tiles';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import ActivitiesScheduleComponent from '../Pages/ActivitiesScheduleComponent';
import AddNoteComponent from '../Pages/AddNoteComponent';
import AlertHandler from '../Pages/AlertHandler';
import PE_PageQuoteFactory from '../Pages/PE_PageQuoteFactory';
import CommonLocators from '../../Utilities/CommonLocators';
import Assertion from '../../Utilities/Assertions';
import AccountSearch from '../Pages/AccountSearch';
import QuoteStart from '../Pages/QuoteStart';
import QuoteSummary from '../Pages/QuoteSummary';


const login = new Login();
const policyGen = new PolicyGenerator();
const dataPE = require('../Data/PE_Data.json');
const qnbData = require('../Data/QnB_PA_Data.json');
const agentDashboard = new AgentDashboard();
const accountSearch = new AccountSearch();
const navBar = new NavBar();
const activitiesLanding = new ActivitiesLanding();
const accountSummary = new AccountSummary();
const addNoteComponent = new AddNoteComponent();
const tiles = new Tiles();
const jsonDataResult = require('../../Utilities/Generator/PolicyGenerator');
const activityPageFactory = new ActivityPageFactory();
const activitiesScheduleComponent = new ActivitiesScheduleComponent();
const alert = new AlertHandler();
const quotePageFactory = new PE_PageQuoteFactory();
const common = new CommonLocators();
const assert = new Assertion();
const quoteStart = new QuoteStart();
const quoteSummary = new QuoteSummary();

fixture`Activities Test`
//Selector changed
test.skip('TC3497: ViewActivityDetailsOnAccountDetails', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activityPageFactory.clickOnFirstActivity();
    await activitiesScheduleComponent.canViewActivitySummary();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3498: AddActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activityPageFactory.clickOnFirstActivity();
    await activityPageFactory.validatedActivityRowUIComponent();
    await activitiesLanding.validatedActivityUIComponant();
    await activityPageFactory.isAddedActivityComponentVisible(dataPE.activityDefault.subject);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3499: CancelAddActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    var activitiesNumber = await tiles.getCountOnActiveTile();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.withActivityTypeByText('Cancel a split policy');
    await activityPageFactory.clickCancelButton();
    await activityPageFactory.isAddedActivityComponentNotVisible();
    var activitesAfterCancel = await tiles.getCountOnActiveTile();
    await assert.assertEqual(activitiesNumber,activitesAfterCancel,'Activity was still created');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3500: MissingTypeWhileAddingActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.submit();
    await activityPageFactory.isChooseActivityTypeErrorModalShown(dataPE.modalErrorMsg);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

//Selector changed
test.skip('TC3501: AddNoteToOpenActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activityPageFactory.clickOnFirstActivity();
    await addNoteComponent.clickAddNoteButton();
    await activitiesLanding.addNoteToNonCompleteActivity();
    await addNoteComponent.validatedAddedNoteUIComponant();
    await addNoteComponent.isNoteAddedToActivity(dataPE.activityFuture.subject, policyData.accountNumber);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3502: MissingMandatoryValuesWhileAddingNoteToActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await addNoteComponent.validateAddbuttonIsDisabled();
    await addNoteComponent.withTopic('General');
    await addNoteComponent.withSubject('NoteSubject');
    await addNoteComponent.withNoteText('NoteText');
    await addNoteComponent.validateMandatoryErrorMessage();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3504: ReassignActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.openReassignActivityDropdown(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.setAssigneeByName(dataPE.activityAssignee, policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickConfirmButton(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.isNotAssignedToCurrentUser(policyData.accountFirstName+" "+policyData.accountLastName);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3505: CancelReassignActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.openReassignActivityDropdown(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.setAssigneeByName(dataPE.activityAssignee,policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickCancelButton(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.isAssignedToCurrentUser(policyData.accountFirstName+" "+policyData.accountLastName); 

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3506: CompleteActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activitiesScheduleComponent.setActivityFilter('Open, Assigned to me');
    await activityPageFactory.clickOnFirstActivity();
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.setActivityFilter('All Completed');
    await activitiesScheduleComponent.doesActivityStatusShowCompleted(policyData.accountFirstName+" "+policyData.accountLastName,'COMPLETED');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC5700: CompleteActivityOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.doesActivityStatusShowCompleted(policyData.accountFirstName+" "+policyData.accountLastName,'COMPLETED');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC5939: AddNoteToCompletedActivityOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist('open');
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist('completed');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3507: AddNoteToCompletedActivityOnAccountDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist('open');
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist('completed');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC5699: ViewActivityDetailsOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.canViewActivitySummary();
    await activitiesLanding.validatedActivityUIComponant();
    await activityPageFactory.isAddedActivityComponentVisible(dataPE.activityDefault.subject);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3501: AddNoteToOpenActivityOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await activitiesLanding.addNoteToNonCompleteActivity();
    await addNoteComponent.validatedAddedNoteUIComponant();
    await addNoteComponent.isNoteAddedToActivity(dataPE.activityFuture.subject);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3307: MissingMandatoryValuesWhileAddingNoteToActivity', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
     await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await addNoteComponent.validateAddbuttonIsDisabled();
    await addNoteComponent.withTopic('General');
    await addNoteComponent.withSubject('NoteSubject');
    await addNoteComponent.withNoteText('NoteText');
    await addNoteComponent.validateMandatoryErrorMessage();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3311 : AccountLinkOnActivitiesOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
     await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesLanding.openAccountUsingAccountNumber(policyData.accountNumber);
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector chnaged
test.skip('TC3310: ReassignActivityOnDashboard', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
     await agentDashboard.goToAccountFromAccountSearch(); //Chnaged 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.openReassignActivityDropdown(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.setAssigneeByName(dataPE.activityAssignee, policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickConfirmButton(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.isNotAssignedToCurrentUser(policyData.accountFirstName+" "+policyData.accountLastName);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3313 : CancelReassignActivityOnDashboard', async t=>{
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToDashboard();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.openReassignActivityDropdown(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.setAssigneeByName(dataPE.activityAssignee,policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickCancelButton(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.isAssignedToCurrentUser(policyData.accountFirstName+" "+policyData.accountLastName); 
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC4063: AddActivityOnPolicyDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToFirstPolicyInList();
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.withActivityTypeByText(dataPE.activityDefault.type);
    await activityPageFactory.withSubject(dataPE.activityDefault.subject);
    await activityPageFactory.submit();
    await activityPageFactory.wasActivityCreatedModalDisplayed(dataPE.activityCreatedMsg);
    await alert.closeAlert();
    await activityPageFactory.isAddedActivityComponentVisible(dataPE.activityDefault.subject);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC5816: MissingTypeWhileAddingActivityOnQuoteDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await navBar.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed
    await quoteStart.selectState('California');
    await quoteStart.selectProducerCode(policyData.producerCode);
    await t.wait(2000);
    await quoteStart.selectProductCode('Personal Auto');
    await quoteStart.clickSubmit();
    await quotePageFactory.createDraftQuote(qnbData);
    await common.pressCancel();
    await common.confirmCancel();
    await navBar.goToDashboard();
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToOpenQuotes();
    await accountSummary.goToFirstQuoteInList();
    await quoteSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.submit();
    await activityPageFactory.isChooseActivityTypeErrorModalShown(dataPE.modalErrorMsg);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3480: CancelAddActivityOnQuoteDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await navBar.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed
    await quoteStart.selectState('California');
    await quoteStart.selectProducerCode(policyData.producerCode);
    await t.wait(2000);
    await quoteStart.selectProductCode('Personal Auto');
    await quoteStart.clickSubmit();
    await quotePageFactory.createDraftQuote(qnbData);
    await common.pressCancel();
    await common.confirmCancel();
    await navBar.goToDashboard();
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToOpenQuotes();
    await accountSummary.goToFirstQuoteInList();
    await quoteSummary.goToOpenActivities();
    var activitiesNumber = await tiles.getCountOnActiveTile();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.withActivityTypeByText('Meet with Insured')
    await activityPageFactory.clickCancelButton();
    await activityPageFactory.isAddedActivityComponentNotVisible();
    var activitesAfterCancel = await tiles.getCountOnActiveTile();
    await assert.assertEqual(activitiesNumber,activitesAfterCancel,'Activity was still created');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC4064 : CancelAddActivityOnPolicyDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToFirstPolicyInList();
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.clickCancelButton();
    await activityPageFactory.isAddedActivityComponentNotVisible();

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC4065 :MissingTypeWhileAddingActivityOnPolicyDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToFirstPolicyInList();
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.submit();
    await activityPageFactory.isChooseActivityTypeErrorModalShown(dataPE.modalErrorMsg);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC5829: AddActivityOnQuoteDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await navBar.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed
    await quoteStart.selectState('California');
    await quoteStart.selectProducerCode(policyData.producerCode);
    await t.wait(1000);
    await quoteStart.selectProductCode('Personal Auto');
    await quoteStart.clickSubmit();
    await quotePageFactory.createDraftQuote(qnbData);
    await common.pressCancel();
    await common.confirmCancel();
    await navBar.goToDashboard();
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
     await agentDashboard.goToAccountFromAccountSearch(); //Changed 
    await accountSummary.goToOpenQuotes();
    await accountSummary.goToFirstQuoteInList();
    await quoteSummary.goToOpenActivities();
    var activitiesNumber = await tiles.getCountOnActiveTile();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activityPageFactory.validatedActivityRowUIComponent();
    var activitesAfterAdding = await tiles.getCountOnActiveTile();
    await assert.assertNotEqual(activitiesNumber,activitesAfterAdding,'Activity number was not correctly increased');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
