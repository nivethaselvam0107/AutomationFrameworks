import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import AgentDashboard from '../Pages/AgentDashboard';
import NavBar from '../Pages/NavBar';
import PolicySummary from '../Pages/PolicySummary';
import Assertion from '../../Utilities/Assertions';

const login = new Login();
const policyGen = new PolicyGenerator();
const agentDashboard = new AgentDashboard();
const navBar = new NavBar();
const policySummary = new PolicySummary();
const assert = new Assertion();

fixture`Policy Summary Test`

test('TC4057: DetailsAndTilesOnPolicyDetailsSummaryPage', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.policyNum);
    await navBar.navigateToPolicy();
    await policySummary.validatePolicySummaryPageLoaded(policyData.policyNum);
    await policySummary.verifyDetailsOnPolicySummaryPage(policyData.policyNum);
    var backEndData = await policySummary.getPolicySummaryDataFromBackEnd(policyData.policyNum);
    var uiData = await policySummary.getPolicySummaryDataFromUI();
    var result = await policySummary.verifyDetailsOnPolicySummaryPage(uiData,backEndData);
    await assert.assertEqual(result,true,'Policy details on summary page did not match');
    await policySummary.verifyTilesOnPolicyPage();   
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});



