import Login from "../Login";
import NavBar from "../Pages/NavBar";
import AccountCreate from "../Pages/AccountCreate";
import QuoteStart from "../Pages/QuoteStart";
import PolicyInfoPage from "../Pages/PolicyInfoPage";
import CommonLocators from "../../Utilities/CommonLocators";
import Modal from "../../Utilities/WidgetComponents/Modal";
import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import PaymentDetailsPage from "../Pages/PaymentDetailsPage";
import LeftNavigationMenuHandlerPage from "../Pages/LeftNavigationMenuHandlerPage";
import HOPaymentDetailsPage from "../Pages/HOPaymentDetailsPage";
import AccountSearch from "../Pages/AccountSearch";
import AccountsLanding from "../Pages/AccountsLanding";
import AccountSummary from "../Pages/AccountSummary";
import PolicyConfirmationPage from "../Pages/PolicyConfirmationPage";
import CPPolicyDetailsPage from "../Pages/CPPolicyDetailsPage";
import CPBuildingsAndLocations from "../Pages/CPBuildingsAndLocations";
import CPPolicyInfoPage from "../Pages/CPPolicyInfoPage";
import CPPageFactory from "../Pages/CPPageFactory";
import CPQuotePage from "../Pages/CPQuotePage";
const dataCP = require("../Data/PE_CP_Data.json");
const dataQnBCP = require("../Data/QnB_CP_Data.json");
const dataQnB = require("../Data/QnB_PA_Data.json");
const dataQnBHO = require("../Data/QnB_HO_Data.json");
import AlertHandler from "../Pages/AlertHandler";
import Helper from "../../Utilities/Helper";
import QuoteSummary from "../Pages/QuoteSummary";

const alert = new AlertHandler();
const login = new Login();
const helper = new Helper();
const policyInfo = new PolicyInfoPage();
const paymentDetails = new PaymentDetailsPage();
const quoteSummary = new QuoteSummary();
const leftNavigationMenu = new LeftNavigationMenuHandlerPage();
const nav = new NavBar();
const quoteStart = new QuoteStart();
const accountSearch = new AccountSearch();
const accountLanding = new AccountsLanding();
const accountSummary = new AccountSummary();
const policyGen = new PolicyGenerator();
const accountCreate = new AccountCreate();
const cpBOPPolicyInfo = new CPPolicyInfoPage();
const common = new CommonLocators();
const cpPolicy = new CPPolicyDetailsPage();
const cpBuildingsAndLocations = new CPBuildingsAndLocations();
const cpPageFactory = new CPPageFactory();
const hoPayment = new HOPaymentDetailsPage();
const modal = new Modal();
const policyConfirmationPA = new PolicyConfirmationPage();
const cpQuote = new CPQuotePage();

fixture`Policy Creation For Commercial Property`;
//Dropdown Selector has to change
test.skip("TC5767: CommercialPropertyPolicyDetailsPageValidation", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataCP.policyInfoValidation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataCP.policyInfoValidation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataCP.policyInfoValidation);
  await accountCreate.clickSubmit();
  await common.validateNextButtonIsDisabled();
  await cpPolicy.mandatoryErrorValidationInPolicyDetailsPage();
  await cpPolicy.setOrgType(dataQnBCP.policyDetails.OrgType);//change
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3586:CommercialPropertyBuildings&LocationsPageValidation-NoBuildingAdded", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await common.validateNextButtonIsDisabled();
  await cpBuildingsAndLocations.validateTooltipDisplayedForNoBuildings('Next');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3596:CommercialPropertyAddBuildingFromEmptyStateView", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await cpBuildingsAndLocations.validateBuildingWithoutChangesSavedMessage("Building saved.");
  await common.doneButton();
  await cpBuildingsAndLocations.validateNewBadgeOnBuilding();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3587:CommercialPropertyBuildings&LocationsPageValidation-MandatoryFieldsAddBuilding", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.clickOnAddBuilding();
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await cpBuildingsAndLocations.setPropClassCode(dataQnBCP.BuildingData.PropertyClassCode);
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC4429 : CommercialPropertyRemoveLastBuildingFromListing, TC4455 : CommercialPropertyRemoveLastBuildingFromListing", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.removeBuildingFromListing();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3594 : CommercialPropertyRemoveLastBuildingFromViewMode", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.removeBuildingFromViewMode();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3597:CommercialPropertyAddLocation, TC4453:CommercialPropertyAddLocation", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3588:CommercialPropertyBuildings&LocationsPageValidation-MandatoryFieldsAddLocation", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.clickOnAddBuilding();
  await cpBuildingsAndLocations.selectNewLocation();
  await common.validateNextButtonIsDisabled();
  await cpBuildingsAndLocations.setAddressLine1(dataQnBCP.Location.AddressLine1);
  await cpBuildingsAndLocations.setCity(dataQnBCP.Location.City);
  await cpBuildingsAndLocations.setZIPCode(dataQnBCP.Location.Zip);
  await cpBuildingsAndLocations.setState(dataQnBCP.Location.State);
  await cpBuildingsAndLocations.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3584:CommercialPropertyPolicyInfoPageValidation-MandatoryFields", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataCP.policyInfoValidation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataCP.policyInfoValidation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataCP.policyInfoValidation);
  await accountCreate.clickSubmit();
  await cpPolicy.setCPBOPPolicyDetailPage(dataQnBCP.policyDetails.OrgType);
  await common.goNext();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.goNext();
  await t.wait(5000);
  await common.goNext();
  await t.wait(2000);
  await cpPageFactory.mandatoryValidationOnPolicyInfoPage(dataQnBCP.PolicyInformation);
  await cpBuildingsAndLocations.validateNextButtonIsDisabled();
  await cpPageFactory.setEmailField(dataQnBCP.PolicyInformation.Email);
  await cpPageFactory.setPhoneField(dataQnBCP.PolicyInformation.Phone);
  await cpBuildingsAndLocations.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3590 : CommercialPropertyPaymentDetailsPageValidation-BankAccountMandatoryFields", async t => {

  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.goNext();
  await t.wait(3000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await cpBuildingsAndLocations.validateNextButtonIsDisabled();
  await hoPayment.setAccountNumber(dataQnBCP.PaymentDetails.AccountNumber);
  await hoPayment.setABARoutingNumber(dataQnBCP.PaymentDetails.ABANumber);
  await hoPayment.setBankName(dataQnBCP.PaymentDetails.Bank);
  await cpBuildingsAndLocations.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3591 : CommercialPropertyPaymentDetailsPageValidation-CreditCardMandatoryFields", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.goNext();
  await t.wait(3000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await paymentDetails.setPaymentMethod(dataQnB.paymentDetails.PaymentMethod);
  await cpBuildingsAndLocations.validateNextButtonIsDisabled();
  await paymentDetails.setCreditCardNumber();
  await paymentDetails.setExpirationDate();
  await cpBuildingsAndLocations.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3592:CommercialPropertyPaymentDetails-CreditCardNumberCheck", async t => {

  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.goNext();
  await t.wait(3000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await paymentDetails.setPaymentMethod(dataQnB.paymentDetails.PaymentMethod);
  await paymentDetails.setCardNumber(dataQnBCP.PaymentDetailsTC3592.CreditCardNumber);
  await paymentDetails.setExpirationDate();
  await paymentDetails.isCreditCardNumberMarkedWithInvalidError("Incomplete input");

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3593:CommercialPropertyPaymentDetails-CreditCardExpirationDateCheck", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await t.wait(2000);
  await common.goNext();
  await t.wait(4000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await paymentDetails.setPaymentMethod(dataQnB.paymentDetails.PaymentMethod);
  await paymentDetails.setCreditCardNumber();
  await paymentDetails.setExpirationDateCP(dataQnBCP.TC3593);
  await cpBuildingsAndLocations.validateNextButtonIsDisabled();
  await paymentDetails.setExpirationDate();
  await cpBuildingsAndLocations.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC35 : CommercialPropertyConfirmationPage-AccountDetailPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await t.wait(2000);
  await common.goNext();
  await t.wait(2000);
  await common.doneButton();
  await t.wait(2000);
  await common.goNext();
  await t.wait(2000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnBCP.PaymentDetailsPage);
  await hoPayment.purchasePolicy();
  var policyNumber = await policyConfirmationPA.getCPPolicyNumber();
  await policyConfirmationPA.goToCPAccountDetailPage();
  await policyConfirmationPA.isAccountDetailPageDisplayed(policyData.accountNumber);
  await accountSummary.isPolicyDisplayedOnAccountPage(policyNumber);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown Selector has to change
test.skip("TC3581 : CommercialPropertyConfirmationPage-PolicyDetailPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await t.wait(3000);
  await common.goNext();
  await t.wait(3000);
  await common.goNext();
  await t.wait(3000);
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await cpPageFactory.setDataTillCPPaymentAndGoNext(dataQnBCP.PaymentDetailsPage);
  await policyConfirmationPA.getCPPolicyNumber();
  await policyConfirmationPA.goToCPPolicyDetailPage();
  await t.wait(5000);
  await policyConfirmationPA.isPolicyDetailPageDisplayed(policyData.policyNum);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC3600:CommercialProperty-PastDateUnavailableForEffectiveDate", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await common.goPrev();
  await cpPolicy.setCoverageDate(dataQnBCP.TC3600.CoverageDate);
  await cpPolicy.setCPBOPPolicyDetailPage(dataQnBCP.policyDetails.OrgType);
  await cpBuildingsAndLocations.validateNextButtonIsDisabled();
  await cpPolicy.isCoverageStartFieldMarkedWithInvalidError("Incorrect input");
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC3604:CommercialProperty-ContinueQuoteAfterpressCancellingOnPolicyDetails", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await common.goPrev();
  await cpPolicy.setCoverageDate(dataQnBCP.policyDetails.CoverageDate);
  await cpPolicy.setCPBOPPolicyDetailPage(dataQnBCP.policyDetails.OrgType);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.clickContinueQuote();
  await common.goPrev();
  await cpPolicy.arePolicyDetailsSaved(dataQnBCP.policyDetails);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC3606:CommercialProperty-ContinueQuoteAfterCancellingOnLocations&Buildings", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.clickContinueQuote();
  await t.wait(2000);
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC3607:CommercialProperty-ContinueQuoteAfterCancellingOnQuote", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await common.goNext();
  await t.wait(3000);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.clickContinueQuote();
  await cpQuote.isCPQuotePageLoaded();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC3608:CommercialProperty-ContinueQuoteAfterCancellingOnPolicyInfo", async t => {

  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await t.wait(2000);
  await common.goNext();
  await t.wait(4000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.clickContinueQuote();
  await common.goNext();
  await cpBOPPolicyInfo.isPolicyInfoPageSaved(dataQnBCP.PolicyInformation);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC3609 : CommercialProperty-ContinueQuoteAfterCancellingOnPaymentDetails", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await t.wait(2000);
  await common.goNext();
  await t.wait(4000);
  await common.goNext();
  await cpPageFactory.setDataTillCPPolicyInfoAndGoNext(dataQnBCP.PolicyInformation);
  await common.goNext();
  await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
    dataQnBHO.HOPaymentDetailsPage
  );
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.clickContinueQuote();
  await common.goNext();
  await common.goNext();
  await hoPayment.arePaymentFieldsInInitialState(dataQnBHO.HOPaymentDetailsPage);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4370:CommercialPropertyCancelAddingBuilding-LocationsPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.pressCancel();
  await modal.confirm();
  await t.wait(5000);
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
  await t.wait(1000);
  await cpBuildingsAndLocations.clickOnAddBuilding();
  await t.wait(4000);
  await cpBuildingsAndLocations.isLocationAvailableInExistingLocations(policyData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4371:CommercialPropertyCancelAddingBuilding-BuildingsPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.pressCancel();
  await modal.confirm();
  await t.wait(4000);
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await t.wait(4000);
  await cpBuildingsAndLocations.isLocationAvailableInExistingLocations(policyData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4372:CommercialPropertyCancelAddingBuilding-CoveragesPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await t.wait(3000);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await common.pressCancel();
  await modal.confirm();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await t.wait(4000);
  await cpBuildingsAndLocations.isLocationAvailableInExistingLocations(policyData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4373:CommercialPropertyAddBuilding-LocationSummaryOnBuildingDetails", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4374:CommercialPropertyAddBuilding-LocationSummaryOnCoveragesForm", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4375:CommercialPropertyAddBuilding-BuildingSummaryOnCoveragesForm", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4434:CommercialPropertyViewBuildingFromLocationViewMode", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.openFirstBuildingFromLocationView();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4435:CommercialPropertyAddBuildingFromLocationViewMode", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.addBuildingForExistingLocation();
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await common.goNext();
  await cpBuildingsAndLocations.validateBuildingonLocationSavedMessage(dataQnBCP.BuildingData.BuildingSavedAlert);
  await common.doneButton();
  await cpBuildingsAndLocations.isBuildingAvailableOnLocation(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4436:CommercialPropertyAddAnotherBuilding", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.setPersonalPropertyLimit(dataQnBCP.BuildingData.PersonalLimit);
  await common.goNext();
  await cpBuildingsAndLocations.clickAddAnotherBuilding();
  await cpBuildingsAndLocations.isLocationPageDisplayedOnAddBuilding();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC7554,TC7604:CommercialPropertyCoverageDependency-BusinessPersonalProperty-CauseOfLoss-Special", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.setPersonalPropertyLimit(dataQnBCP.BuildingData.PersonalLimit);
  await common.goNext();
  await common.doneButton();
  await t.wait(4000);
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.clickBackOnViewModes();
  await cpBuildingsAndLocations.isBuildingListingPageDisplayed();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4438:CommercialPropertyBackButtonOnLocationViewMode", async t => {

  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidation);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.setPersonalPropertyLimit(dataQnBCP.BuildingData.PersonalLimit);
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.clickBackOnViewModes();
  await cpBuildingsAndLocations.isBuildingListingPageDisplayed();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4378:CommercialPropertyAddBuilding-EditLocationFromBuildingDetails", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4379:CommercialPropertyAddBuilding-EditLocationFromCoverages", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await common.goNext();
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4389:CommercialPropertyEditBuildingDetailsFromListingsPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.setPersonalPropertyLimit(dataQnBCP.BuildingData.PersonalLimit);
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.clickEditOnBuildingSummary();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await cpBuildingsAndLocations.saveAddedBuilding();
  await cpBuildingsAndLocations.validateEditBuildingSavedMessage(dataQnBCP.BuildingData.BuildingChangesSavedMessage);
  await cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4439:CommercialPropertyBackButtonOnBuildingViewMode", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.clickBackOnViewModes();
  await cpBuildingsAndLocations.isBuildingListingPageDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4380:CommercialPropertyAddBuilding-EditBuildingFromCoverages", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidation
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnBuildingSummary();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4383:CommercialPropertyEditLocation-1Building", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidation
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.saveAddedLocation();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(
    dataQnBCP.Location
  );
  await cpBuildingsAndLocations.openFirstBuildingFromLocationView();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(
    dataQnBCP.Location
  );
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;
test.skip("TC4384:CommercialPropertyEditLocation-2Buildings,TC4454:CommercialPropertyEditLocation-2Buildings", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.addBuildingOnExistingLocation(dataQnBCP.TC4384);
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.saveAddedLocation();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(
    dataQnBCP.Location
  );
  await cpBuildingsAndLocations.clickBackOnViewModes();
  await cpBuildingsAndLocations.validateLocationsOnListing(dataQnBCP.Location);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;
test.skip("TC4387:CommercialPropertyEditLocation-ViewBuildingsLink", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.addBuildingOnExistingLocation(dataQnBCP.TC4384);
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4388:CommercialPropertyEditBuildingDetailsFromConfirmationPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.clickEditOnBuildingSummary();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await cpBuildingsAndLocations.saveAddedBuilding();
  await cpBuildingsAndLocations.validateEditBuildingSavedMessage(dataQnBCP.BuildingData.BuildingChangesSavedMessage);
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4430:CommercialPropertyEditLocationFromConfirmationPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change

  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidation
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.saveAddedLocation();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(
    dataQnBCP.Location
  );
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;
test.skip("TC4432:CommercialPropertyEditBuildingCoveragesFromConfirmationPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnCoveragesSummary();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.saveCoveragesOnBuilding();
  await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCoverageChange();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;
test.skip("TC4433:CommercialPropertyEditBuildingCoveragesFromListingsPage,TC4457:CommercialPropertyEditBuildingCoveragesFromListingsPage", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow_ExcludesFirefox();
  await cpBuildingsAndLocations.clickEditOnCoveragesSummary();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.saveCoveragesOnBuilding();
  await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCoverageChange();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4431:CommercialPropertyEditLocationFromBuildingViewMode", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidation
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await cpBuildingsAndLocations.setPersonalPropertyLimit(
    dataQnBCP.BuildingData.PersonalLimit
  );
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.saveAddedLocation();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(
    dataQnBCP.Location
  );
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4467:CommercialPropertyNavigatingToPolicyDetails-BuildingsPageOnAddBuilding", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidation);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await leftNavigationMenu.policyPageDetailsLink();
  await common.goNext();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4466:CommercialPropertyEditLocation-DefaultToNew", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditLocation();
  await cpBuildingsAndLocations.editLocationDetails(dataCP.TC4466);
  await common.goNext();
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataCP.TC4466);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4450:CommercialPropertySwitchEditModes-CoverageToLocation-DoNotSaveChanges", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.clickEditCoverages();
  await cpBuildingsAndLocations.setBuildingLimit(dataCP.TC4466.Limit);
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditLocation();
  await alert.clickNo();
  await cpBuildingsAndLocations.editLocationDetails(dataCP.TC4466);
  await cpBuildingsAndLocations.cancel_Button();
  await common.confirmCancel();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.validateCoverageChange();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4449:CommercialPropertySwitchEditModes-BuildingToCoverage-DoNotSaveChanges", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.clickEditCoverages();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4448:CommercialPropertySwitchEditModes-CoverageToLocation-SaveChanges", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.clickEditCoverages();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await alert.clickNo();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.cancel_Button();
  await common.confirmCancel();
  await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCoverageChange();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC4447:CommercialPropertySwitchEditModes-BuildingToCoverage-SaveChanges, TC4458:CommercialPropertySwitchEditModes-BuildingToCoverage-SaveChanges", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.clickEditCoverages();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4446:CommercialPropertyAddBuildingToThisLocation", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingToDefaultLocation(dataQnBCP.BuildingData);
  await common.doneButton();
  await cpBuildingsAndLocations.addBuildingForExistingLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.setPersonalPropertyLimit(dataQnBCP.BuildingData.PropertyClassCode);
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.clickOnAddBuildingToThisLocation();
  await cpBuildingsAndLocations.validateSelectedLocation(dataQnBCP.TC4446);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4442:CommercialPropertyCancelEditBuildingCoverages", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await common.doneButton();

  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.clickEditCoverages();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await cpBuildingsAndLocations.cancel_Button();
  await common.confirmCancel();
  await cpBuildingsAndLocations.expandCoveragesSummary();
  await cpBuildingsAndLocations.validateCoverageChange();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4441:CommercialPropertyCancelEditBuildingDetails", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openFirstBuildingFromListing();
  await cpBuildingsAndLocations.expandBuildingSummary();
  await cpBuildingsAndLocations.clickEditOnBuildingSummary();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await cpBuildingsAndLocations.cancel_Button();
  await common.confirmCancel();
  await cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow();
  await cpBuildingsAndLocations.validateCPBuildingData(dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4440:CommercialPropertyCancelEditLocation", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(
    dataQnBCP.BuildingData.BuildingLimit
  );
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.openLocationOfFirstBuilding();
  await cpBuildingsAndLocations.clickEditOnLocationSummary();
  await cpBuildingsAndLocations.setLocationData(dataQnBCP.Location);
  await cpBuildingsAndLocations.cancel_Button();
  await common.confirmCancel();
  await cpBuildingsAndLocations.validateLocationDetailsInViewMode(dataQnBCP.Location);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4437:CommercialPropertyRemovingLastBuildingRemovesItsLocation", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await t.wait(6000);
  await cpBuildingsAndLocations.getExistingLocation();
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.addBuildingForExistingLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await common.goNext();
  await common.doneButton();
  await cpBuildingsAndLocations.removeBuildingForLocation();
  await common.goNext();
  await common.goPrev();
  await cpBuildingsAndLocations.addBuildingForExistingLocation();
  await cpBuildingsAndLocations.verifyExistingLocationIsAvailable(dataCP.policyInfoValidationCP);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC7555,TC7606:CommercialPropertyCoverageDependency-BusinessPersonalProperty-CauseOfLoss-Broad", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.setCauseOfLossOnNewBuilding(
    dataCP.TC7554.cause1,
    dataCP.TC7554.cvgTerm
  );
  await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;
test.skip("TC7552,TC7603:CommercialPropertyCoverageDependency-CauseOfLoss-Special", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.setCauseOfLossOnNewBuilding(
    dataCP.TC7554.cause,
    dataCP.TC7554.cvgTerm1
  );
  await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change;

test.skip("TC7553,TC7602:CommercialPropertyCoverageDependency-BusinessPersonalPropertyCoverage-CauseOfLoss-Basic", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.setCauseOfLossOnNewBuilding(
    dataCP.TC7554.cause2,
    dataCP.TC7554.cvgTerm
  );
  await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC7543,TC7605:CommercialPropertyCoverageDependency-CauseOfLoss-Broad", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.setCauseOfLossOnNewBuilding(
    dataCP.TC7554.cause1,
    dataCP.TC7554.cvgTerm1
  );
  await cpBuildingsAndLocations.isCoverageTermExcludeTheftNotAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change
test.skip("TC7542,TC7601:CommercialPropertyCoverageDependency-CauseOfLoss-Basic", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.setCauseOfLossOnNewBuilding(dataCP.TC7554.cause2, dataCP.TC7554.cvgTerm1);
  await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4469:CommercialPropertyNavigatingToPolicyDetails-LocationPageOnAddBuilding", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(
    dataCP.policyInfoValidation
  );
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await leftNavigationMenu.policyPageDetailsLink();
  await common.goNext();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Dropdown selector has to change

test.skip("TC4468:CommercialPropertyNavigatingToPolicyDetails-CoveragesPageOnAddBuilding", async t => {
  let policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//change
  await accountSearch.clickStartNewQuote();//change
  await quoteStart.fillQuoteForPAExistingAccount(dataCP.policyInfoValidationCP);
  await quoteStart.clickSubmit();
  await cpBuildingsAndLocations.addBuildingOnNewLocation();
  await cpBuildingsAndLocations.addNewLocationDetails(dataCP.policyInfoValidationCP);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingData(dataQnBCP.BuildingData);
  await common.goNext();
  await cpBuildingsAndLocations.setBuildingLimit(dataQnBCP.BuildingData.BuildingLimit);
  await leftNavigationMenu.policyPageDetailsLink();
  await common.goNext();
  await cpBuildingsAndLocations.isEmptyStateViewDisplayed();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });



