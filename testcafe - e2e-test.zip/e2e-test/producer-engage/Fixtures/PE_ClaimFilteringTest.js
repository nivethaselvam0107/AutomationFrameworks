import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import Login from "../Login";
import NavBar from "../Pages/NavBar";
import PolicySummary from "../Pages/PolicySummary";
import AccountsSummary from "../Pages/AccountSummary";
import ClaimsTileView from "../Pages/ClaimsTileView";
import ClaimsPageFactory from "../Pages/ClaimsPageFactory";
import NewClaimConfirmationPage from "../Pages/NewClaimConfirmationPage";
import ClaimListPage from "../Pages/ClaimListPage";
import TypeOfIncidentPage from "../Pages/NewClaimTypeOfIncidentPage";
import AgentDashboard from "../Pages/AgentDashboard";
const dataClaim= require('../Data/PE_Claim.json');
const policyGen = new PolicyGenerator();
const login = new Login();
const nav = new NavBar();
const policySummary = new PolicySummary();
const accountSummary = new AccountsSummary();
const claimtile = new ClaimsTileView();
const claim = new ClaimsPageFactory();
const confirm = new NewClaimConfirmationPage();
const claimList = new ClaimListPage();
const type = new TypeOfIncidentPage();
const agent = new AgentDashboard();
fixture` PE Claim Filtering Test`
test.skip('Test Filtering General Claims Associated With Policy', async t => {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimtile.clickfileAClaimAccount();
    await claim.createGeneralClaim(dataClaim.TC001,policyData.AddressLine1);
    var claimNumber =await confirm.getClaimNumber();
    await confirm.goToDashboard();
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimList.isClaimListPageLoadedOnPoliciesClaim();
    await claimList.filterClaimByTextSearch(claimNumber);
    await claimList.validateContainsClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test.skip('Test Filtering WC Claims Associated With Policy', async t => {
    let policyData = await policyGen.createBasicBoundWCPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimtile.clickfileAClaimAccount();
    await claim.createWCClaim(dataClaim.TC002,policyData.AddressLine1);
    var claimNumber =await confirm.getClaimNumber();
    await confirm.goToDashboard();
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimList.isClaimListPageLoadedOnPoliciesClaim();
    await claimList.filterClaimByTextSearch(claimNumber);
    await claimList.validateContainsClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});
