import Login from '../Login';
import FaqPage from "../Pages/FaqPage";
const login = new Login();
const faq = new FaqPage();
const url = process.env.TEST_ENV_URL;
var FAQURL = '/faq/';

fixture`FaqTest`
test("Verify if Faq Page Loaded By Clicking Link", async () => {
    await faq.getFaqPage();
    await faq.isFaqPageOpened();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("Verify is Faq Page Loaded By Typing Url", async t => {
    await login.login();
    await t.navigateTo(url + FAQURL);
    await faq.isFaqPageOpened();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
//Selector changed
test.skip("Verify if the Faq Selected Section Visible On Screen", async t => {
    await faq.getFaqPageByUrl();
    await faq.selectLastSection();
    await faq.isSelectedElementVisible();//Change
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("Test search Topic Question", async t => {
    await faq.getFaqPage();
    await faq.checkSearchResultsForTopicQuestionWord();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("Test search Special Chars Text", async t => {
    await faq.getFaqPage();
    await faq.searchSpecialCharsText();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("checkNoResultsMessage", async t => {
    await faq.getFaqPageByUrl();
    await faq.checkSearchContainsNoResultsMessage('some fake text here to have no results for sure');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

