import NavBar from '../Pages/NavBar';
import AccountSearch from '../Pages/AccountSearch';
import AccountCreate from '../Pages/AccountCreate';
import Helper from '../../Utilities/Helper';
import Login from '../Login';
import QuoteStart from '../Pages/QuoteStart';
import CommonLocators from '../../Utilities/CommonLocators';
import BOPPolicyDetailsPage from '../Pages/BOPPolicyDetailsPage';
import BOPQualification from '../Pages/BOPQualification';
import BOPGeneralCoverages from '../Pages/BOPGeneralCoverages';
import BOPLocationsAndBuildings from '../Pages/BOPLocationsAndBuildings';
import BOPAdditionalInfo from '../Pages/BOPAdditionalInfo';
import BOPPolicyInfo from '../Pages/BOPPolicyInfo';
import BOPPaymentDetails from '../Pages/BOPPaymentDetails';
import BOPPaymentSuccessful from '../Pages/BOPPaymentSuccessful';
import BOPQuote from '../Pages/BOPQuote';
import BOPAdditionalCoverages from '../Pages/BOPAdditionalCoverages';
import Modal from '../../Utilities/WidgetComponents/Modal';
import QuoteSummary from '../Pages/QuoteSummary';
import LeftNavigationMenuHandlerPage from '../Pages/LeftNavigationMenuHandlerPage';

const data = require('../Data/PE_BOP_Data.json');
const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const accountCreate = new AccountCreate();
const qualification = new BOPQualification();
const generalCoverages = new BOPGeneralCoverages();
const additionalCoverages = new BOPAdditionalCoverages();
const locationsAndBuildings = new BOPLocationsAndBuildings();
const quote = new BOPQuote();
const additionalInfo = new BOPAdditionalInfo();
const policyInfo = new BOPPolicyInfo();
const paymentDetails = new BOPPaymentDetails();
const paymentSuccessful = new BOPPaymentSuccessful();
const helper = new Helper();
const quoteStart = new QuoteStart();
const common = new CommonLocators();
const policyDetails = new BOPPolicyDetailsPage();
const quoteSummary = new QuoteSummary();
const modal = new Modal();
const wizard = new LeftNavigationMenuHandlerPage();

fixture`BOP line test`
//All Dropdown Values have to change
//Dropdown Selector chnaged
test.skip('TC3640 : Verify mandatory fields on Policy Details', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await common.validateNextButtonIsDisabled();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3647: Verify that a building can be added on Building & Locations page', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.verifyAddedBuilding();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3645: Verify that a building can be removed on Building & Locations page while creating a quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.verifyAddedBuilding();
    await locationsAndBuildings.deleteAddedBuilding();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3646: Verify that a location can be removed on Building & Locations page while creating a quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addLocationDetails(data.BOP);
    await locationsAndBuildings.clickAddLocationButton();
    await locationsAndBuildings.verifyAddedLocation();
    await locationsAndBuildings.deleteAddedLocation();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3648: Verify that a location can be added on Building & Locations page while creating a quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addLocationDetails(data.BOP);
    await locationsAndBuildings.clickAddLocationButton();
    await locationsAndBuildings.verifyAddedLocation();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3651: Verify Policy Info page for mandatory fields', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await common.validateNextButtonIsEnabled();
    await policyInfo.removeEmailAndPhone();
    await common.validateNextButtonIsDisabled();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3650: Verify that the policy detail page can be opened from Policy confirmation page', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await policyInfo.clickNext();
    await paymentDetails.setpaymentDetailsBank(data.BOP);
    await paymentDetails.clickNext();
    await paymentSuccessful.validatePolicySummaryPage();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3654: Verify changes on Policy Details page are saved when user cancels on this page and the user is taken to next page on continuing quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await wizard.goToBOPPolicyDetailsPage();
    await policyDetails.arePolicyDetailsSaved(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3655: Test BOP Cancel On Qualification Page', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await wizard.goToBOPQualificationPage();
    await qualification.isPolicyDeclinedQuesMarkedYes();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3656:Test Businessowners-Continue Quote After Cancelling On General Coverages', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setLimitsOccurenceCoverage(data.BOP);
    await generalCoverages.clickNext();
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await wizard.goToBOPGeneralCoveragePage();
    await generalCoverages.isLimitsOccurenceCoverageSaved(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3657:Test Businessowners - Continue Quote After Cancelling On Additional Coverages', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.setContractorsCoverage();
    await additionalCoverages.clickNext();
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await wizard.goToBOPAdditionalCoveragePage();
    await additionalCoverages.isAdditionalCoveragesSaved();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3659:Test Businessowners -Continue Quote After Cancelling On Locations And Buildings', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await wizard.goToBOPLocAndBuildingsPage();
    await locationsAndBuildings.verifyAddedBuilding();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3660: Test Business owners-Continue Quote After Cancelling On Quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await quote.isBOPQuotePageLoaded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3661: Test Businessowners - Continue Quote After Cancelling On PolicyInfo', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.removeEmailAndPhone();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.isPolicyInfoPageSaved(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3662: Test Business owners- Continue Quote After Cancelling On Payment Details', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.removeEmailAndPhone();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await policyInfo.clickNext();
    await paymentDetails.setpaymentDetailsBank(data.BOP);
    await common.pressCancel();
    await modal.confirm();
    await quoteSummary.clickContinueQuote();
    await quote.clickNext();
    await policyInfo.clickNext();
    await common.goNext();
    await paymentDetails.isPaymentInformationPageSaved(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3667: Verify that a building can be edited and changes are saved', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.editAddedBuilding(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.verifyEditedBuilding(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3668: Verify changes to building are discarded when user clicks on Back and confirms', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.editAddedBuilding(data.BOP);
    await locationsAndBuildings.clickCancelButton();
    await locationsAndBuildings.verifyBuildingDetailsValues(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3664: Verify Business owners Building Details View', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.isBOPBuildingSaved(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3666: Verify Business owners Building Additional Coverages View', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickEarthQuakeSprinklerLeakage();
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.isBOPBuildingSaved(data.BOP);
    await locationsAndBuildings.isEarthquakeSprinklerLeakageAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3665: Verify Business owners Building Coverages View', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.isBOPBuildingSaved(data.BOP);
    await locationsAndBuildings.verifyBuildingCoverageValues(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3663: Verify Business owners Coverages Display On New Building Form', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickAddBuildingIcon();
    await locationsAndBuildings.isAddBuildingDetailsMessageDisplayed();
    await locationsAndBuildings.enterPropertyClassCode(data.BOP.PropClassCode);
    await locationsAndBuildings.enterPremiumBasisAmount(data.BOP.PremiumBasisAmount);
    await locationsAndBuildings.enterBuildingDesc(data.BOP.BuildingDesc);
    await locationsAndBuildings.enterYearBuilt(data.BOP.YearBuilt);
    await locationsAndBuildings.isAddBuildingDetailsMessageNotDisplayed();
    await locationsAndBuildings.removePropClassCode();
    await locationsAndBuildings.isAddBuildingDetailsMessageDisplayed();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3669 : Verify that user can cancel adding a building on Building & Locations page while creating a quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickCancelButton();
    await locationsAndBuildings.verifyBuildingNotAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3670 :Verify that user can cancel adding a location on Building & Locations page while creating a quote', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addLocationDetails(data.BOP);
    await locationsAndBuildings.clickLocationBack();
    await locationsAndBuildings.verifyLocationNotAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3671: Verify Business owners Add Contractor Tools', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.selectOrgType(data.BOP.organizationType);//changed
    await policyDetails.selectsmallBusinessType(data.BOP.contractorBusinessType);
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await qualification.clickNext();
    await generalCoverages.clickOnAddContractorTools();
    await generalCoverages.setDataOnContractorTools(data.BOP);
    await generalCoverages.clickOnAdd();
    await generalCoverages.isContractorToolAdded(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3672: Verify Business owners Cancel Add Contractor Tools', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.selectOrgType(data.BOP.organizationType);//changed
    await policyDetails.selectsmallBusinessType(data.BOP.contractorBusinessType);
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await qualification.clickNext();
    await generalCoverages.clickOnAddContractorTools();
    await generalCoverages.setDataOnContractorTools(data.BOP);
    await generalCoverages.clickOnCancelForSI();
    await generalCoverages.isContractorToolNotAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3673 : Verify Business owners Edit Contractor Tools', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.selectOrgType(data.BOP.organizationType);//changed
    await policyDetails.selectsmallBusinessType(data.BOP.contractorBusinessType);
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await qualification.clickNext();
    await generalCoverages.clickOnAddContractorTools();
    await generalCoverages.setDataOnContractorTools(data.BOP);
    await generalCoverages.clickOnAdd();
    await generalCoverages.isContractorToolAdded(data.BOP);
    await generalCoverages.clickOnEdit();
    await generalCoverages.setNewDataOnContractorTools(data.BOP);
    await generalCoverages.clickOnAdd();
    await generalCoverages.isContractorToolEdited(data.BOP);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3674: Verify Business owners Remove Contractor Tools', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.selectOrgType(data.BOP.organizationType);//changed
    await policyDetails.selectsmallBusinessType(data.BOP.contractorBusinessType);
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await qualification.clickNext();
    await generalCoverages.clickOnAddContractorTools();
    await generalCoverages.setDataOnContractorTools(data.BOP);
    await generalCoverages.clickOnAdd();
    await generalCoverages.isContractorToolAdded(data.BOP);
    await generalCoverages.removeContractorTools();
    await generalCoverages.isContractorToolNotAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown locator changed
test.skip('TC3649: Verify user can edit coverages from Quote page', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP); //changed
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickEditCoverages();
    await generalCoverages.isGeneralCoveragesPageLoaded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

