import Login from '../Login';
import navbar from '../Pages/NavBar';
import AccountsLanding from '../Pages/AccountsLanding';
import PolicyLanding from '../Pages/PolicyLanding';
import ClaimsLanding from '../Pages/ClaimsLanding';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import AgentDashboard from '../Pages/AgentDashboard';
import AnalyticsLanding from '../Pages/AnalyticsLanding';

const login = new Login();
const nav = new navbar();
const accountsLanding = new AccountsLanding();
const policiesLanding = new PolicyLanding();
const claimsLanding = new ClaimsLanding();
const activitiesLanding = new ActivitiesLanding();
const dashboard = new AgentDashboard();
const analyticsLanding = new AnalyticsLanding();


fixture`Landing Page`
test('TC3296: Verify Account landing page in gateway ', async t => {
    await login.login();
    await nav.goToAccountsLanding();
    await accountsLanding.checkTitle();
    await accountsLanding.checkDefaultTile();
});
test('TC3297: Verify Policy landing page in gateway', async t => {
    await login.login();
    await nav.goToPoliciesLanding();
    await policiesLanding.checkTitle();
    await policiesLanding.checkDefaultTile();
});
test('TC3298: Verify Claims landing page in gateway', async t => {
    await login.login();
    await nav.goToClaimsLanding();
    await claimsLanding.checkTitle();
    await claimsLanding.checkDefaultTile();
});
test('TC3299: Verify Activities landing page in gateway', async t => {
    await login.login();
    await nav.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await activitiesLanding.checkDefaultTile();
});
test('TC3300: AnalyticsLanding', async t => {
    await login.login();
    await nav.goToAnalyticsLanding();
    await analyticsLanding.checkTitle();
    await analyticsLanding.checkDefaultTile();
    await analyticsLanding.checkTile();
});
test('TC3306 : Verify user can view activities under Activites list on Dashboard', async t => {
    await login.login();
    await dashboard.verifyActivitiesForNext7daySections();
});

test('TC3302 : Verify user can view all open policy renewals from dashboard', async t => {
    await login.login();
    await dashboard.clickOpenRenewalsTile();
    await dashboard.verifyOpenRenewalLoaded();
});

test('TC3303 : Verify user can view all open quotes from dashboard', async t => {
    await login.login();
    await dashboard.clickOpenQuotesTile();
    await dashboard.verifyOpenQuotesLoaded();
});

test('TC3304 : Verify user can view all open policy changes from dashboard', async t => {
    await login.login();
    await dashboard.clickOpenPolicyChangesTile();
    await dashboard.verifyOpenPolicyChangesLoaded();
});

test('TC3305 : Verify user can view all open policy cancellation from dashboard', async t => {
    await login.login();
    await dashboard.clickOpenCancellationsTile();
    await dashboard.verifyOpenCancellationLoaded();
});

