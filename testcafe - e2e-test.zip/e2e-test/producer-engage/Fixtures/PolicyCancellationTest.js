import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator.js'
import PolicyCancellation from '../Pages/PolicyCancellation';
import PolicySummary from '../Pages/PolicySummary';
import Assertion from '../../Utilities/Assertions';
import ActivityPageFactory from '../Pages/ActivityPageFactory.js';
import Tiles from '../Pages/Tiles';
import AddNoteComponent from '../Pages/AddNoteComponent';
import NavBar from '../Pages/NavBar';
import DocumentsTab from '../Pages/DocumentsTab';
import PolicyLanding from '../Pages/PolicyLanding';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import AccountsLanding from '../Pages/AccountsLanding';
import AgentDashboard from '../Pages/AgentDashboard';
const data = require('../Data/PE_PA_Data.json');
const assert = new Assertion();
const nav = new NavBar();
const tiles = new Tiles();
const login = new Login();
const policyGen = new PolicyGenerator();
const policyCancel = new PolicyCancellation();
const policySummaryPage = new PolicySummary();
const activityPageFactory = new ActivityPageFactory();
const addNoteComponent = new AddNoteComponent();
const documentTab = new DocumentsTab();
const policyLanding = new PolicyLanding();
const agentDashboard = new AgentDashboard()
fixture`Policy Cancellation`
test('TC3954, TC4077: BindCancellationOnPolicy', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var type = await policyCancel.cancellationStatus();
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var status = policy.policyStatus;
   await assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled')
   await assert.assertEqual(status, 'Bound', 'policy is not bounded')
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4078: QuotedCancelPolicy', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var type = await policyCancel.cancellationStatus()
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var status = policy.policyStatus;
   await assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled');
   await t.wait(2000)
   await assert.assertEqual(status, 'Quoted', 'policy is not quoted')

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

 test('TC4079, TC3955: WithdrawPolicy', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.withdrawCancellation();
   await policyCancel.confirmWithdrawcancellation();
   var type = await policyCancel.cancellationStatus();
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var status = policy.policyStatus;
   await assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled')
   await t.wait(2000)
   await assert.assertEqual(status, 'Withdrawn', 'policy is not withdrawn')
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4080 : Verify  "Renew Policy" button is not displayed if policy is already cancelled', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var type = await policyCancel.cancellationStatus();
   var policy = await policyGen.getAgentPolicyData(policy.policyNum);
   var status = policy.policyStatus;
   assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled')
   assert.assertEqual(status, 'Bound', 'policy is not bounded');
   await policyCancel.clickPolicyLink();
   await policySummaryPage.validateCanceledPolicyStatus();
   await policySummaryPage.validateRenewPolicyButtonNotPresent();
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4082: Verify for validation message is displayed when user provides effective date not within the policy period for Cancel action', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateNotWithinPolicyPeriod(policyData);
   await policyCancel.validateEffectiveDateErrorMessage();
   await policyCancel.startCancelButtonDisabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4083: Verify for validation message is displayed when user does not provide mandatory fields for Cancel action', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.startCancelButtonDisabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4084: Test Verify Cancellation Details Page Quoted Cancellation', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policySummaryPage.goToPolicySummaryPage(policyData.policyNum);
   await policySummaryPage.goCancellationSummaryPage(jobNum);
   await policyCancel.validateQuotedCancellationPageComponents(jobNum, data.PolicyCancellation);

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4085: Test Verify Cancellation Details Page Bound Cancellation', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policySummaryPage.goToPolicySummaryPage(policyData.policyNum);
   await policySummaryPage.goCancellationSummaryPage(jobNum);
   await policyCancel.validateBoundCancellationPageComponents(jobNum, data.PolicyCancellation);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4086: Verify user can add an activity on Cancellation details page', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickOpenActivitiesTile(jobNum);
   await activityPageFactory.clickOnAddActivity();
   await activityPageFactory.addDefaultActivity();
   await policySummaryPage.isAddedActivityAvailable(jobNum);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4087: Verify user can cancel the add an activity action on Cancellation details page', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickOpenActivitiesTile(jobNum);
   await activityPageFactory.clickOnAddActivity();
   await activityPageFactory.addActivityThanCancelSubmition(data.PolicyCancellation.ActivityType, data.PolicyCancellation.ActivitySubject);
   await policySummaryPage.isAddedActivityNotAvailable(policyData.policyNum);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4088: Verify user can add a note on Cancellation details page', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickNotesTile(jobNum);
   await addNoteComponent.addGeneralNote(data.TC3996.NoteSubject);
   await addNoteComponent.isNoteListed(data.TC3996.NoteSubject);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4089: Verify user can cancel the add a note action on Cancellation details page', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickNotesTile(jobNum);
   await addNoteComponent.cancelAddingNote(data.TC3997.NoteSubject)
   await addNoteComponent.isNoteNotAdded();
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4090: Verify user can upload document on Cancellation details page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickDocumentsTile(jobNum);
   await documentTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await documentTab.isDocAdded(data.UploadDocOnPolicyDetails.fileName);

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('Test Case GPA--371: Verify user can delete uploaded document on Cancellation details page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.bindConfirmCancellation();
   var jobNum = await policyCancel.getJobNumber();
   await policyCancel.clickDocumentsTile(jobNum);
   await documentTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await documentTab.deleteDoc();
   await documentTab.ValidateDocDeleted()
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4094: WithdrawCancelPolicy', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.withdrawCancellation();
   await policyCancel.doNotWithdrawnCancellation();
   await t.wait(5000);
   var type = await policyCancel.cancellationStatus();
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var status = policy.policyStatus;
   await assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled');
   await assert.assertEqual(status, 'Quoted', 'policy is not quoted');

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4095: DoNotBindCancellationOnPolicy', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await policyCancel.bindCancellation();
   await policyCancel.doNotBindCancellationOnPolicy();
   await t.wait(5000);
   var type = await policyCancel.cancellationStatus();
   var policy = await policyGen.getAgentPolicyData(policyData.policyNum);
   var status = policy.policyStatus;
   await assert.assertEqual(type, 'Cancellation', 'policy not is not cancelled')
   await t.wait(2000);
   await assert.assertEqual(status, 'Quoted', 'policy is not quoted')

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4096: Verify user can view policy Cancellation details page from policies landing', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var jobNumber = await policyCancel.getJobNumber();
   await nav.goToPoliciesLanding();
   await policyLanding.showOpenCancellations();
   await policyLanding.openJob(jobNumber);
   await policySummaryPage.isCancellationPagePresented(jobNumber);

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4097: Verify user can view Change Policy details page from Dashboard', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var jobNumber = await policyCancel.getJobNumber();
   await nav.goToDashboard();
   await agentDashboard.clickOpenCancellationsTile();
   await policySummaryPage.goCancellationSummaryPage(jobNumber);
   await policySummaryPage.isCancellationPagePresented(jobNumber);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test('TC4098: Verify user can view Cancellation Policy details page from Activites details section on Dashboard', async t => {
   var policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agentDashboard.searchUsingSearchBox(policyData.policyNum);
   await agentDashboard.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var jobNumber = await policyCancel.getJobNumber();
   await policyCancel.clickOpenActivitiesTile(jobNumber);
   await activityPageFactory.clickOnAddActivity();
   await activityPageFactory.addDefaultActivity();
   await nav.goToDashboard();
   await agentDashboard.clickOpenCancellationsTile();
   await policySummaryPage.goCancellationSummaryPage(jobNumber);
   await policySummaryPage.isCancellationPagePresented(jobNumber);
}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });
