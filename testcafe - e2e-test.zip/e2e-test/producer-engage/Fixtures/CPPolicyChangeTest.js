
import CommonLocators from "../../Utilities/CommonLocators";
import CPPolicyDetailsPage from "../Pages/CPPolicyDetailsPage";
import CPBuildingsAndLocations from "../Pages/CPBuildingsAndLocations";
import CPQuotePage from "../Pages/CPQuotePage";
import PolicyChangeSummaryPage from "../Pages/PolicyChangeSummaryPage";
const dataCP = require("../Data/PE_CP_Data.json");
const dataQnBCP = require("../Data/QnB_CP_Data.json");
const polichangeCp = require("../Data/PE_PolicyChange_Data.json")
import PolicyChange from "../Pages/PolicyChange";
const common = new CommonLocators();
const cpPolicy = new CPPolicyDetailsPage();
const cpBuildingsAndLocations = new CPBuildingsAndLocations();
const cpQuote = new CPQuotePage();
const policyChange = new PolicyChange();
const sum = new PolicyChangeSummaryPage();

fixture`CP PolicyChange`;

test("TC7025:CPPolicyChangeWithinGP", async t => {
    var policy = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await cpPolicy.validatePresenceOfAllFields(polichangeCp.CPDetails.PolicyType);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7034:CancelPolicyChangeonPolicyDetailsScreen", async t => {
    var policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await cpPolicy.orgType_Select(polichangeCp.CPDetails.NewOrganizationType);
    await common.pressCancel();
    await common.confirmCancel();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, polichangeCp.CPDetails.status);
    await sum.continuePolicyChange();
    await common.goPrev();
    await cpPolicy.validatePolicyDetailsWithBackend(policyData.policyNum, polichangeCp.CPDetails.OrganizationType);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7026:AddBuildingManuallyChangeOnCP", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.addBuildingOnExistingLocationCPChange(dataQnBCP.BuildingData);
    await common.doneButton();
    await common.goNext();
    await t.wait(2000);
    await common.goNext();
    await cpPolicy.clickSpreadPayments();
    await cpPolicy.clickViewPolicyChangeBtn();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, polichangeCp.CPDetails.TC7026);
    await sum.clickPolicyLink();
    await cpPolicy.validateBuildingLimitOnCPPolicyChange(policyData.policyNum,dataQnBCP.BuildingData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test("TC7028:DeleteBuildingManuallyChangeOnCP", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.removeBuildingFromListing();
    await common.goNext();
    await cpPolicy.validateTransactionQuotePageForDecrease(policyData.policyNum);
    await common.goNext();
    await cpPolicy.clickViewPolicyChangeBtn();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, polichangeCp.CPDetails.TC7026);
    await sum.clickPolicyLink();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7027:EditBuildingDetailsManuallyChangeOnCP", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.openFirstBuildingFromListing();
    await cpBuildingsAndLocations.expandBuildingSummary();
    await cpBuildingsAndLocations.clickEditOnBuildingSummary();
    await cpBuildingsAndLocations.setBuildingDesc(polichangeCp.CPDetails.Buildingdesc);
    await cpBuildingsAndLocations.saveAddedBuilding();
    await cpBuildingsAndLocations.clickBackOnViewModes();
    await common.goNext();
    await t.wait(2000);
    await cpPolicy.validateTransactionQuotePageForNoChange();
    await common.goNext();
    await cpPolicy.clickViewPolicyChangeBtn();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, polichangeCp.CPDetails.TC7026);
    await sum.clickPolicyLink();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test("TC7035:CancelPolicyChangeonBuildingsAndLocationScreen", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.openFirstBuildingFromListing();
    await cpBuildingsAndLocations.clickEditOnCoveragesSummary();
    await cpBuildingsAndLocations.setPersonalPropertyLimit(polichangeCp.CPDetails.PersonalPropertyLimit);
    await cpBuildingsAndLocations.setBuildingLimit(polichangeCp.CPDetails.BuildingLimit);
    await cpBuildingsAndLocations.saveCoveragesOnBuilding();
    await cpBuildingsAndLocations.clickBackOnViewModes();
    await common.pressCancel();
    await common.confirmCancel();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, 'Draft');
    await sum.continuePolicyChange();
    await cpBuildingsAndLocations.openFirstBuildingFromListing();
    await cpBuildingsAndLocations.expandCoveragesSummaryInAddBuildingFlow();
    await cpBuildingsAndLocations.validateCoverageChange(polichangeCp.CPDetails.BuildingLimit);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7036:CancelPolicyChangeOnQuoteScreen", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.openFirstBuildingFromListing();
    await cpBuildingsAndLocations.clickEditOnCoveragesSummary();
    await cpBuildingsAndLocations.setPersonalPropertyLimit(polichangeCp.CPDetails.PersonalPropertyLimit);
    await cpBuildingsAndLocations.saveCoveragesOnBuilding();
    await cpBuildingsAndLocations.clickBackOnViewModes();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, 'Quoted');
    await sum.continuePolicyChange();
    await cpPolicy.isCPQuotePageLoaded();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7037:CancelPolicyChangeOnPaymentScreen", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.addBuildingOnExistingLocationCPChange(dataQnBCP.BuildingData);
    await common.doneButton();
    await common.goNext();
    await common.goNext();
    await common.goNext();
    await cpPolicy.clickPay();
    await cpPolicy.setABARoutingNumber(polichangeCp.CPDetails.RoutingNumber);
    await cpPolicy.setAccountNumber(polichangeCp.CPDetails.AccountNumber);
    await cpPolicy.setBankName(polichangeCp.CPDetails.BankName);
    await cpPolicy.cancelPayment();
    await common.pressCancel();
    await common.confirmCancel();
    await cpPolicy.validatePolicyChangeJobStatus(policyData.policyNum, 'Quoted');
    await sum.continuePolicyChange();
    await cpPolicy.isCPQuotePageLoaded();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7038:ViewCPPolicyDetailsFromConfirmationPage", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.addBuildingOnExistingLocationCPChange(dataQnBCP.BuildingData);
    await common.doneButton();
    await common.goNext();
    await cpPolicy.validateTransactionQuotePageForIncrease(policyData.policyNum);
    await common.goNext();
    await cpPolicy.clickSpreadPayments();
    await cpPolicy.clickViewPolicyBtn();
    await cpPolicy.validateTileOpened();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7607:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Basic", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Basic', 'Building');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7623:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Broad", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Broad', 'Building');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7609:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Special", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Special', 'Building');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test("TC7620:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalPropertyCoverage-CauseOfLoss-Basic", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Basic', 'Business Personal Property');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test("TC7612:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalProperty-CauseOfLoss-Broad", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Broad', 'Business Personal Property');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test("TC7612:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalProperty-CauseOfLoss-Broad", async t => {
    let policyData = await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Broad', 'Business Personal Property');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test("TC7622:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalProperty-CauseOfLoss-Special", async t => {
    await policyChange.goToPolicyChangePage(polichangeCp.CPDetails.PolicyType);
    await common.goNext();
    await cpBuildingsAndLocations.setCauseOfLossOnNewBuildingCPPolicyChange('Special', 'Business Personal Property');
    await cpBuildingsAndLocations.isCoverageTermExcludeTheftAvailable();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });



