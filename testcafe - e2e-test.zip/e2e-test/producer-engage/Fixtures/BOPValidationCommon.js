import NavBar from '../Pages/NavBar';
import AccountSearch from '../Pages/AccountSearch';
import AccountCreate from '../Pages/AccountCreate';
import Login from '../Login';
import QuoteStart from '../Pages/QuoteStart';
import CommonLocators from '../../Utilities/CommonLocators';
import BOPPolicyDetailsPage from '../Pages/BOPPolicyDetailsPage';
import BOPQualification from '../Pages/BOPQualification';
import BOPGeneralCoverages from '../Pages/BOPGeneralCoverages';
import BOPLocationsAndBuildings from '../Pages/BOPLocationsAndBuildings';
import BOPAdditionalInfo from '../Pages/BOPAdditionalInfo';
import BOPPolicyInfo from '../Pages/BOPPolicyInfo';
import BOPPaymentDetails from '../Pages/BOPPaymentDetails';
import BOPQuote from '../Pages/BOPQuote';
import BOPAdditionalCoverages from '../Pages/BOPAdditionalCoverages';

const data = require('../Data/PE_BOP_Data.json');
const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const accountCreate = new AccountCreate();
const qualification = new BOPQualification();
const generalCoverages = new BOPGeneralCoverages();
const additionalCoverages = new BOPAdditionalCoverages();
const locationsAndBuildings = new BOPLocationsAndBuildings();
const quote = new BOPQuote();
const additionalInfo = new BOPAdditionalInfo();
const policyInfo = new BOPPolicyInfo();
const paymentDetails = new BOPPaymentDetails();
const quoteStart = new QuoteStart();
const common = new CommonLocators();
const policyDetails = new BOPPolicyDetailsPage();

fixture`BOPValidationCommon`
//Dropdown Selector has to change
test.skip('TC3319: BOP Locations & Buildings Page Validation - Mandatory Fields Add Building ', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickAddBuildingIcon();
    await locationsAndBuildings.verifyAddBuildingButtonDisabled();
    await locationsAndBuildings.enterPropertyClassCode(data.BOP.PropClassCode);
    await locationsAndBuildings.enterPremiumBasisAmount(data.BOP.PremiumBasisAmount);
    await locationsAndBuildings.enterBuildingDesc(data.BOP.BuildingDesc);
    await locationsAndBuildings.enterYearBuilt(data.BOP.YearBuilt);
    await locationsAndBuildings.enterBusinessPersonalPropLimit(data.BOP.BusinessPersonalPropLimit);
    await locationsAndBuildings.enterBuildingLimit(data.BOP.BuildingLimit);
    await locationsAndBuildings.verifyAddBuildingButtonEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC3320: BOP Locations & Buildings-Mandatory Fields Add Location', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickAddLocationIcon();
    await locationsAndBuildings.verifyAddLocationButtonDisabled();
    await locationsAndBuildings.enterAddressLine1(data.BOP.AddressLine1);
    await locationsAndBuildings.enterCity(data.BOP.City);
    await locationsAndBuildings.enterZIPCode(data.BOP.Zip);
    await locationsAndBuildings.selectState(data.BOP.State);
    await locationsAndBuildings.verifyAddLocationButtonEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC3321: BOP Payment Details - Bank Account Mandatory Fields', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.removeEmailAndPhone();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await policyInfo.clickNext();
    await common.validateNextButtonIsDisabled();
    await paymentDetails.setpaymentDetailsBank(data.BOP);
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC3322: BOP Payment Details-Credit Card Mandatory Fields', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await locationsAndBuildings.navigateToQuotePage();
    await quote.clickNext();
    await additionalInfo.clickNext();
    await policyInfo.removeEmailAndPhone();
    await policyInfo.setPolicyInfoPage(data.BOP);
    await policyInfo.clickNext();
    await common.validateNextButtonIsDisabled();
    await paymentDetails.setpaymentDetailsCredit(data.BOP);
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC4229: BOP Remove Primary Location', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await locationsAndBuildings.isRemoveIconAvailableForPrimaryLocation();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC2848: Locations and Buildings - No buildings Mandatory Validation', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.setPolicyDetails(data.BOP);//change
    await policyDetails.clickNext();
    await qualification.clickNext();
    await generalCoverages.setgeneralCoverages(data.BOP);
    await generalCoverages.clickNext();
    await additionalCoverages.clickNext();
    await common.validateNextButtonIsDisabled();
    await locationsAndBuildings.addBuildingDetails(data.BOP);
    await locationsAndBuildings.clickAddBuildingButton();
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector has to change
test.skip('TC4232: BOP Add Contractor Tools Mandatory Fields', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.BOP);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.BOP);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.BOP);
    await accountCreate.clickSubmit();
    await policyDetails.selectOrgType(data.BOP.organizationType);//change
    await policyDetails.selectsmallBusinessType(data.BOP.contractorBusinessType);
    await policyDetails.clickNext();
    await qualification.setPolicyDeclinedQuestion(data.BOP);
    await qualification.clickNext();
    await generalCoverages.clickOnAddContractorTools();
    await generalCoverages.validateContractorToolsAddButtonIsDisabled();
    await generalCoverages.setDataOnContractorTools(data.BOP);
    await generalCoverages.validateContractorToolsAddButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});


