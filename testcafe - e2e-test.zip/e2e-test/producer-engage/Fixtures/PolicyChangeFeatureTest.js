import { Selector , ClientFunction} from 'testcafe'
import PolicyChange from '../Pages/PolicyChange';
import PolicyChangeSummaryPage from '../Pages/PolicyChangeSummaryPage';
import EndorsementTypeBoxPage from '../Pages/EndorsementTypeBoxPage';
import EndorsementDriversPage from '../Pages/EndorsementDriversPage';
import CommonLocators from '../../Utilities/CommonLocators';
import EndorsementMortgageePage from '../Pages/EndorsementMortgageePage';
import EndorsementPaymentPage from '../Pages/EndorsementPaymentPage';
import PolicySummary from '../Pages/PolicySummary';
import EndorsementValuablesPage from '../Pages/EndorsementValuablesPage';
import EndorsementCoverages_HO from '../Pages/EndorsementCoverages_HO';
import Assertion from '../../Utilities/Assertions';
import EndorsementVehiclePage from '../Pages/EndorsementVehiclePage';
import EndorsementAddressPage from '../Pages/EndorsementAddressPage';
import EndorsementCoverages_PA from '../Pages/EndorsementCoverages_PA';
import DocumentsTab from '../Pages/DocumentsTab';
import claimSummaryDocumentsTab from '../Pages/ClaimSummaryDocumentsTab';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import NavBar from '../Pages/NavBar';
import AgentDashboard from '../Pages/AgentDashboard';
import EndorsementQuotePage from '../Pages/EndorsementQuotePage';
import Helper from '../../Utilities/Helper';
import PolicyLanding from '../Pages/PolicyLanding';

const policyChange = new PolicyChange();
const polChangeSummary = new PolicyChangeSummaryPage();
const typeBox = new EndorsementTypeBoxPage();
const drivers = new EndorsementDriversPage();
const vehicles = new EndorsementVehiclePage();
const address = new EndorsementAddressPage();
const common = new CommonLocators();
const mortgagee = new EndorsementMortgageePage();
const data = require('../../producer-engage/Data/PE_PolicyChange_Data.json');
const payment = new EndorsementPaymentPage();
const policySummary = new PolicySummary();
const valuable = new EndorsementValuablesPage();
const coverages = new EndorsementCoverages_HO();
const coveragesPA = new EndorsementCoverages_PA();
const assert = new Assertion();
const docTab = new DocumentsTab();
const quote = new EndorsementQuotePage();
const docs = new claimSummaryDocumentsTab();
const pageFactory = new ActivityPageFactory();
const navBar = new NavBar();
const agentDashboard = new AgentDashboard();
const policyLanding = new PolicyLanding();
fixture`Policy Change Feature Test`

test('TC3983: testAddDriverEndorsement', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.addNewDriver();
     await drivers.setDriverPage(data.DriversData);
     await common.goNext();
     await coveragesPA.verifyPageTitle();
     await common.goNext();
     await quote.verifyNoChangesNotification();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await drivers.isDriverAvailableInPolicyFromBackEnd(data.DriversData,policyData.policyNum);
     await assert.assertEqual(value,true,'Added Driver details are not applied to the policy');
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3980: Verify Change Policy functionality for PA policy- edit a vehicle', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveVehicle();
     await common.goNext();
     await vehicles.editFirstVehicleDetails(data.VehiclesEditData);
     var dataUI = await vehicles.getEditVehicleUIdetails();
     await common.goNext();
     await coveragesPA.verifyPageTitle();
     await common.goNext();
     //await quote.verifyIncreaseNotification();
     await t.wait(2000);
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await vehicles.isEditedVehicleAvailableInPolicyFromBackEnd(dataUI,data.VehiclesEditData,policyData.policyNum);
     await assert.assertEqual(value,true,'Edited vehicle details are not applied to policy');
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3979: Verify Change Policy functionality for PA policy- add a vehicle - change address', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddressChange();
     await typeBox.selectAddEditRemoveVehicle();
     await common.goNext();
     await address.setCity(data.VehiclesData.NewCity);
     await common.goNext();
     await vehicles.addVehicle();
     await vehicles.setVehiclesPage(data.VehiclesData);
     await common.goNext();
     await common.goNext();
     //await quote.verifyIncreaseNotification();
     await t.wait(2000);
     await common.goNext();
     await payment.buyAndRedistributeCoverageChanges();
     var value = await vehicles.isAddedVehicleAvailableInPolicyFromBackEnd(data.VehiclesData,policyData.policyNum);
     await assert.assertEqual(value,true,'Added Vehicle details are not applied to the policy');
     await address.validateAddressChangedInPolicyFromBackEnd(data.VehiclesData,policyData.policyNum);
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3984: Verify Change Policy functionality for PA policy- edit a driver', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.editFirstDriverDetails(data.DriversEditData);
     var dataUI = await drivers.getEditDriverUIdetails();
     await common.goNext();
     await coveragesPA.verifyPageTitle();
     await common.goNext();
     await quote.verifyNoChangesNotification();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await drivers.isEditedDriverAvailableInPolicyFromBackEnd(dataUI,data.DriversEditData,policyData.policyNum);
     await assert.assertEqual(value,true,'Edited Driver details are not applied to policy');
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3977: Verify Change Policy functionality for PA policy- coverage change only- Pay in Full', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.setMedicalLimit(data.PA_CoveragesData.CovValue);
     await common.goNext();
     await quote.verifyPolicyDetailsTitle();
     //await quote.verifyIncreaseNotification();
     await t.wait(2000);
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await coveragesPA.validateMedicalLimitValue(data.PA_CoveragesData,policyData.policyNum);
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3978: Verify Change Policy functionality for PA policy- coverage change only- Confirm',async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     var unchechedCoverage = await coveragesPA.uncheckCheckedCoverage();
     await common.goNext();
     await quote.verifyPolicyDetailsTitle();
     await t.wait(2000);
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await coveragesPA.isLineCoverageSelected(unchechedCoverage,policyData.policyNum);
     await assert.assertEqual(value,false,'Coverage is selected while shouldnot');
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3989: Verify user can withdraw quoted policy change for PA policy', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.setMedicalLimit(data.PA_CoveragesData.CovValue);
     await common.goNext();
     await quote.verifyPolicyDetailsTitle();
     //await quote.verifyIncreaseNotification();
     await t.wait(2000);
     await common.pressCancel();
     await common.confirmCancel();
     await polChangeSummary.withdrawPolicyChange();
     await polChangeSummary.validatePolicyChangeStatus('Withdrawn');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4001: Verify user can continue quoted policy change for PA policy', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.setMedicalLimit(data.PA_CoveragesData.CovValue);
     await common.goNext();
     await quote.verifyPolicyDetailsTitle();
     //await quote.verifyIncreaseNotification();
     await t.wait(1000);
     await common.pressCancel();
     await common.confirmCancel();
     await polChangeSummary.continuePolicyChange();
     await typeBox.isEndorsementWizardDisplayed();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3976: Verify Change Policy functionality for PA policy- coverage change only- Redistribute', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.setMedicalLimit(data.PA_CoveragesData.CovValue);
     await common.goNext();
     await quote.verifyPolicyDetailsTitle();
     //await quote.verifyIncreaseNotification();
     await t.wait(2000);
     await common.goNext();
     await payment.buyAndRedistributeCoverageChanges();
     await coveragesPA.validateMedicalLimitValue(data.PA_CoveragesData,policyData.policyNum);
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4007: Verify user can view Change Policy details page from Activites details section on Dashboard', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.uncheckCheckedCoverage();
     await common.goNext();
     await common.pressCancel();
     await common.confirmCancel();
     var jobNum = await polChangeSummary.getPolicyChangeJobNumber();
     await polChangeSummary.goToOpenActivitiesTile();
     await polChangeSummary.clickAddActivityBtn();
     await pageFactory.addDefaultActivity();
     await navBar.goToDashboard();
     await agentDashboard.clickOpenPolicyChangesTile();
     await t.wait(9000);
     await policyLanding.openJob(jobNum);
     await polChangeSummary.validatePolicyChangePageWasLoaded(jobNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3982: Verify Change Policy functionality for PA policy- remove a vehicle', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveVehicle();
     await common.goNext();
     await vehicles.addVehicle();
     await vehicles.setVehiclesPage(data.VehiclesData);
     await common.goNext();
     await t.wait(2000);
     await common.goNext();
     await t.wait(2000);
     await common.goNext();
     await payment.buyAndRedistributeCoverageChanges();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.selectAddEditRemoveVehicle();
     await common.goNext();
     await vehicles.clickRemoveVehicle();
     await common.goNext();
     await t.wait(2000);
     await common.goNext();
     await t.wait(2000);
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await vehicles.isAddedVehicleAvailableInPolicyFromBackEnd(data.VehiclesData,policyData.policyNum);
     await assert.assertEqual(value,false,'Vehicle is was not deleted from policy');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3986: Verify Change Policy functionality for PA policy- remove a driver', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.addNewDriver();
     await drivers.setDriverPage(data.DriversData);
     await common.goNext();
     await coveragesPA.verifyPageTitle();
     await common.goNext();
     await quote.verifyNoChangesNotification();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.clickRemoveDriver();
     await common.goNext();
     await t.wait(2000);
     await common.goNext();
     await quote.verifyNoChangesNotification();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await drivers.isDriverAvailableInPolicyFromBackEnd(data.DriversData,policyData.policyNum);
     await assert.assertEqual(value,false,'Driver is still avaliable in the policy while it shouldnot');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4021: Verify Change Policy functionality for PA policy- add a driver under 25 age', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.addNewDriver();
     await drivers.setDriverPage(data.DriversData_25Age);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     await policySummary.clickChangePolicyButton();
     await typeBox.selectAddEditRemoveDriver();
     await common.goNext();
     await drivers.clickRemoveDriver(data.DriversData_25Age.FirstName+" "+data.DriversData_25Age.LastName);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await drivers.isDriverAvailableInPolicyFromBackEnd(data.DriversData_25Age,policyData.policyNum);
     await assert.assertEqual(value,true,'Added Driver is applied to the policy');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3993: Verify Policy Change details page', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectCoverages();
     await common.goNext();
     await coveragesPA.setMedicalLimit(data.PA_CoveragesData.CovValue);
     await common.goNext();
     await common.pressCancel();
     await common.confirmCancel();
     await polChangeSummary.validateWithdrawPolicyChangeButton();
     await polChangeSummary.validateContinuePolicyChangeButton();
     await polChangeSummary.validateTilesOnPolicyChangeSummaryPage();
     await polChangeSummary.validatePolicyChangeSummaryPageComponents();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4010: Verify change policy functionality for HO policy - Navgation to Endorsement Wizard.', async t=>{
     await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.isEndorsementWizardDisplayed();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4011: Verify user can perform change to HO policy by adding Mortgagee', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.addNewMortgagee();
     await mortgagee.fillMortageeFormData(data.MortgageeData);
     await common.goPrev();
     await mortgagee.isAddedMortgageePresent(data.MortgageeData.MortGagee_Name);
     await common.goNext();
     await coverages.verifyPageTitle();
     await common.goNext();
     await quote.verifyNoChangesNotification();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     var value = await mortgagee.isMortgageeAvailableInPolicyFromBackEnd(data.MortgageeData,policyData.policyNum);
     await assert.assertEqual(value,true,'Mortgagee is not applied to policy')
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4012: Verify user can perform change to HO policy by adding Valuables', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.addValuable();
     await valuable.fillValuableFormData(data.ValuablesData);
     await valuable.isAddedPropertyValuablePresent(data.ValuablesData);
     await common.goNext();
     await common.goNext();
     //await quote.verifyIncreaseNotificationHO();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     var value = await valuable.isValuablesAvailableInPolicyFromBackEnd(policyData.policyNum,data.ValuablesData);
     assert.assertEqual(value,true,'Valuable is not applied to the policy');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4013: Verify user can perform change to coverages for a HO policy', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectCoveragesHO();
     await common.goNext();
     await coverages.setLimitPercentOfDwel(data.HO_CoveragesData);
     await common.goNext();
     await t.wait(2000);
     //await quote.verifyIncreaseNotificationHO();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     await coverages.isHOBaseCoverageLimitChangesAvailableInPolicy(policyData.policyNum,data.HO_CoveragesData);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4014: Verify validation messages when no mandatory fields are provided while adding Mortgagee', async t=>{
     await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.addNewMortgagee();
     await common.validateNextButtonIsDisabled();
     await common.pressCancel();
     await common.confirmCancel();
     await polChangeSummary.withdrawPolicyChange();
     await polChangeSummary.validatePolicyChangeStatus('Withdrawn');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4015: Verify validation messages when no mandatory fields are provided while adding Valuables', async t=>{
     await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.addValuable();
     await common.goNext();
     await common.isNextBtnDisabled('disabled');
     await common.pressCancel();
     await common.confirmCancel();
     await polChangeSummary.withdrawPolicyChange();
     await polChangeSummary.validatePolicyChangeStatus('Withdrawn');

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4016: Verify user can perform change to HO policy by editing existing Mortgagee', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.addNewMortgagee();
     await mortgagee.fillMortageeFormData(data.MortgageeData);
     await common.goPrev();
     await mortgagee.isAddedMortgageePresent(data.MortgageeData.MortGagee_Name);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.setEffectiveDateHO();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.clickEditMortgagee();
     await mortgagee.fillMortageeFormData(data.MortgageeEditData);
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     var value = await mortgagee.isMortgageeAvailableInPolicyFromBackEnd(data.MortgageeEditData,policyData.policyNum);
     await assert.assertEqual(value,true,'Mortgagee is not applied to policy')

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4017: Verify user can perform change to HO policy by editing Valuables', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.addValuable();
     await valuable.fillValuableFormData(data.ValuablesData);
     await valuable.isAddedPropertyValuablePresent(data.ValuablesData);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.clickEditValuable();
     await valuable.fillValuableFormData(data.ValuablesEditData);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
     var value = await valuable.isValuablesAvailableInPolicyFromBackEnd(policyData.policyNum,data.ValuablesEditData);
     await assert.assertEqual(value,true,'Valuable is not applied to the policy');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4019: Verify user can perform change to HO policy by removing existing Mortgagee', async t=>{
     var policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.addNewMortgagee();
     await mortgagee.fillMortageeFormData(data.MortgageeData);
     await common.goPrev();
     await mortgagee.isAddedMortgageePresent(data.MortgageeData.MortGagee_Name);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.selectMortgagee();
     await common.goNext();
     await mortgagee.clickRemoveMortgagee();
     await mortgagee.isMortgageeRemoved(data.MortgageeData.MortGagee_Name);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await mortgagee.isMortgageeAvailableInPolicyFromBackEnd(data.MortgageeData,policyData.policyNum);
     await assert.assertEqual(value,false,'Mortgagee is not deleted and still applied to policy')
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4020: Verify user can perform change to HO policy by removing valuables', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('HomeOwners');
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.addValuable();
     await valuable.fillValuableFormData(data.ValuablesData);
     await valuable.isAddedPropertyValuablePresent(data.ValuablesData);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     await payment.clickBackToPolicy();
     await policySummary.clickChangePolicyButton();
     await typeBox.setEffectiveDateHO();
     await typeBox.selectValuables();
     await common.goNext();
     await valuable.clickRemoveValuable();
     await valuable.isValuableRemoved(data.ValuablesData);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.confirmOrPayInFullWithCheckingBank();
     var value = await valuable.isValuablesAvailableInPolicyFromBackEnd(policyData.policyNum,data.ValuablesData);
     await assert.assertEqual(value,false,'Valuable is not removed and still applied to the policy');

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4024: Verify Policy Change details page with UW issue', async t=>{
     let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
     await typeBox.setEffectiveDate();
     await typeBox.selectAddEditRemoveVehicle();
     await common.goNext();
     await vehicles.addVehicle();
     await vehicles.setVehiclesPage(data.VehiclesData_HighCost);
     await common.goNext();
     await common.goNext();
     await common.goNext();
     await payment.buyAndRedistributeCoverageChanges();
     await payment.validateUnderwriterIssueMessage();
     await payment.clickBackToPolicy();
     await policySummary.openPolicySummaryOfChangedPolicy();
     await polChangeSummary.validateHighValueVehicleUnderwritingIssue(data.VehiclesData_HighCost);
     await polChangeSummary.validateTilesOnPolicyChangeSummaryPage();
     await polChangeSummary.validatePolicyChangeSummaryPageComponents();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
