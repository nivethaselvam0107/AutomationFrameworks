import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import VendorGenerator from '../../Utilities/Generator/VendorGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ConfirmationPage from '../Pages/NewClaimConfirmationPage';
import NavBar from '../Pages/NavBar';
import PolicySummary from '../Pages/PolicySummary';
import ClaimsTileView from '../Pages/ClaimsTileView';
import ClaimListPage from '../Pages/ClaimListPage';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import Assertion from '../../Utilities/Assertions';
import NewClaimContactDetails from '../Pages/NewClaimContactDetailsPage';
import NewClaimConfirmationPage from '../Pages/NewClaimConfirmationPage';
import NewClaimClaimSummary from '../Pages/NewClaimSummaryPage';
import AccountSummary from '../Pages/AccountSummary';
import SelectPolicy from '../Pages/SelectPolicy';
import NewClaimTypeOfIncidentPage from '../Pages/NewClaimTypeOfIncidentPage';
import NewClaimDetailsPage from '../Pages/NewClaimDetailsPage';
import NewClaimVehiclePage from '../Pages/NewClaimVehiclePage';
import NewClaimRepairPage from '../Pages/NewClaimRepairPage';
import NewClaimsDocumentPage from '../Pages/NewClaimsDocumentPage';
import ContactUs from '../Pages/ContactUsPage';
import ClaimSummaryDocumentsTab from '../Pages/ClaimSummaryDocumentsTab';
import AlertHandler from '../Pages/AlertHandler';
import ClaimWizardPage from '../Pages/ClaimWizardPage';
import ClaimSummaryNotesTab from '../Pages/ClaimSummaryNotesTab';
import AgentDashboard from '../Pages/AgentDashboard';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
const vendorGen = new VendorGenerator();
const assert = new Assertion();
const alert = new AlertHandler();
const vehicle = new NewClaimVehiclePage();
const login = new Login();
const policyGen = new PolicyGenerator();
const claim = new ClaimsPageFactory();
const nav = new NavBar();
const policySummary = new PolicySummary();
const accountSummary = new AccountSummary();
const claimTile = new ClaimsTileView();
const claimList = new ClaimListPage();
const dataClaim = require('../Data/PE_Claim.json');
const confirm = new NewClaimConfirmationPage();
const claimSummary = new ClaimSummaryPage();
const contact = new NewClaimContactDetails();
const summary = new NewClaimClaimSummary();
const selectPolicy = new SelectPolicy();
const type = new NewClaimTypeOfIncidentPage();
const detail = new NewClaimDetailsPage();
const repair = new NewClaimRepairPage();
const document = new NewClaimsDocumentPage();
const contactUs = new ContactUs();
const claimSummaryDocument = new ClaimSummaryDocumentsTab();
const claimSummaryNote = new ClaimSummaryNotesTab();
const wizard = new ClaimWizardPage();
const modal = new Modal();
const agent = new AgentDashboard();
const common = new CommonLocators();
fixture`Personal Auto File A Claim Test`

test.skip('TC3777,TC3781: Collision PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createCollisionClaimFromAccount(dataClaim.TC3777, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3841: Missing Loss Date While Filing A Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await selectPolicy.selectPolicy();
    await selectPolicy.removeClaimDateOfLoss();
    await common.validateNextButtonIsDisabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3778: Missing Values On Where Did It Happen Page While Filing A Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await selectPolicy.selectPolicy();
    await common.goNext();
    await common.goNext();
    await detail.verifyNextButtonDisabledForRequiredFields('Foster City', 'California');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3779: Missing Values On What About Vehicle Page While Filing A Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await selectPolicy.selectPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3779.ClaimSubType);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3779.LossLocationInput, dataClaim.Address);
    await detail.typeDescribeWhatHappened(dataClaim.TC3779.LossCause);
    await common.goNext();
    await vehicle.verifyNextButtonDisabledForRequiredFields();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3783: Theft PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createTheftClaim(dataClaim.TC3783, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });


test('TC3784: Theft Audio Only PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createTheftClaimForVendorChoice(dataClaim.TC3784, dataClaim.Address);
    await repair.selectNoFacility();
    await common.goNext();
    await common.goNext();
    await common.goNext();
    await summary.clickSubmitClaim();
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3785:Glass PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createGlassClaim(dataClaim.TC3785, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber());
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3786: Other PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    var accountNumber = await accountSummary.getAccountHolderName();
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createOtherClaim(dataClaim.TC3786);
    await contactUs.isContactUsPageLoaded();
    await contactUs.backToClaims();
    await accountSummary.titleContains(accountNumber);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3787,TC3792: Collision With Pedestrain PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3787, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3788: Collision While Turning Left PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3788, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3789: Malicious Mischief And Vandalism PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3789, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3842: Check if User Cannot Claim Without Policy Selection', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await common.validateNextButtonIsDisabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC378691: Check the Existing Contact in Claim summary page ', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    var accountNumber = (await accountSummary.getAccountHolderName()).split('(')[0];
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createCollisionClaimTillAddInfoPage(dataClaim.TC378691, dataClaim.Address);
    await contact.withContactCellNum(dataClaim.TC378691.CellPhone);
    await common.goNext();
    var contactValue = (await summary.getContactValue()).split(",")[0];
    await assert.assertEqual(contactValue, accountNumber, 'Summary page has incorrect contact details');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC37861: Check the newly added contact Value in summary page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createCollisionClaimTillAddInfoPage(dataClaim.TC378691, dataClaim.Address);
    await contact.selectContactPerson(dataClaim.TC37861.FirstNameNewPerson, dataClaim.TC37861.LastNameNewPerson);
    await contact.setContactPersonDetails(dataClaim.TC37861.CityNewPerson, dataClaim.TC37861.StateNewPerson);
    await contact.withContactCellNum(dataClaim.TC37861.CellPhone);
    await common.goNext();
    var contactValue = await summary.getContactValue();
    await assert.hasText(contactValue, dataClaim.TC37861.FirstNameNewPerson, 'Summary page has incorrect first name in contact person details');
    await assert.hasText(contactValue, dataClaim.TC37861.LastNameNewPerson, 'Summary page has incorrect Last name in contact person details');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3843:Invalid Email Id While Filing Claim On Contact Information page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createCollisionClaimTillAddInfoPage(dataClaim.TC378691, dataClaim.Address);
    await contact.selectContactPerson(dataClaim.TC3843.FirstNameNewPerson, dataClaim.TC3843.LastNameNewPerson);
    await contact.setContactPersonDetails(dataClaim.TC3843.CityNewPerson, dataClaim.TC3843.StateNewPerson);
    await contact.withContactCellNum(dataClaim.TC3843.CellPhone);
    await contact.validateEmailFieldOnSummaryPage();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3790: Missing New Person Detail On Supporting Information', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await selectPolicy.selectPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3790.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3790.ClaimTypeCollision);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3790.LossLocationInput, dataClaim.Address);
    await detail.typeDescribeWhatHappened(dataClaim.TC3790.LossCause);
    await detail.withPropDamageDetails(dataClaim.TC3790.WithPropDamage);
    await common.goNext();
    await vehicle.selectFirstAvailableDriver();
    await vehicle.selectFirstAvailableVehicle();
    await vehicle.setVehicleSafetyToDrive(dataClaim.TC3790.SafetyToDrive);
    await vehicle.setAirBagDeployStatus(dataClaim.TC3790.AirBagDeploy);
    await vehicle.setEquiFailureStatus(dataClaim.TC3790.EquipmentFailure);
    await vehicle.setVehicleTowStatus(dataClaim.TC3790.VehicleTowed);
    await vehicle.setVehicleRentalStatus(dataClaim.TC3790.RentalStatus);
    await vehicle.setVehicleCollisionPoint(dataClaim.TC3790.CollisionPoint);
    await vehicle.addNewPassenger();
    await common.validateNextButtonIsDisabled();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3852, TC5843: Upload JPEG Document To Claim in Claim summary', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3852, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3852.FileName1);
    await claimSummaryDocument.isDocAdded(dataClaim.TC3852.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('Upload GIF Document To Claim in Claim summary', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.upload_GIF, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.upload_GIF.FileName1);
    await t.wait(3000);
    await claimSummaryDocument.isDocAdded(dataClaim.upload_GIF.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3854: Upload Word doc Document To Claim in Claim summary', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3854, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3854.FileName1);
    await claimSummaryDocument.isDocAdded(dataClaim.TC3854.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3855: Upload Word Docx Document To Claim in Claim summary', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3855, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3855.FileName1);
    await claimSummaryDocument.isDocAdded(dataClaim.TC3855.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3853: Verify user can upload a .pdf document to a personal auto claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3853, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3853.FileName1);
    await claimSummaryDocument.isDocAdded(dataClaim.TC3853.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3851: Verify user can upload a .txt document to a personal auto claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3851, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3851.FileName1);
    await claimSummaryDocument.isDocAdded(dataClaim.TC3851.FileName1);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('Verify user cannot upload a .html document to a personal auto claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.upload_html, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.upload_html.FileName1);
    await alert.isFailedToUploadPopUpDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('Verify user cannot upload a .js file to a personal auto claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.upload_js, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.upload_js.FileName1);
    await alert.isFailedToUploadPopUpDisplayed();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3856: Verify user cannot upload 2 documents with same name to a personal auto claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3856, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimTile.uploadDocument(claimNumber, dataClaim.TC3856.FileName);
    await claimTile.isDocUploaded();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3800: test Cancel Claim On Date Of Loss Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await selectPolicy.selectPolicy();
    await wizard.cancelWizardPopup();
    await claimList.isDraftClaimNotLoadedOnClaimsList();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3801: test Cancel Claim On What Happened Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3801.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3801.ClaimTypeCollision);
    await wizard.cancelWizardPopup();//selector needs to be changed
    await policySummary.goToclaimsTile();
    await claimList.isDraftClaimNotLoadedOnClaimsList();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test.skip('TC3802: test Cancel Claim On Details Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await t.wait(3000);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3802.LossLocationInput, dataClaim.Address);
    await detail.typeDescribeWhatHappened(dataClaim.TC3802.LossCause);
    await detail.withPropDamageDetails(dataClaim.TC3802.WithPropDamage);
    var draftNum = await detail.getDraftClaimNumber();
    await wizard.cancelWizardPopup();//selector need to be changed
    await policySummary.goToclaimsTile();
    await claimList.openClaimDetailsPage(draftNum);
    await detail.areClaimLocationDetailsAreSaved(dataClaim.TC3802);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3804: test Cancel Claim On Supporting Information Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3804.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3804.ClaimTypeCollision);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3804.LossLocationInput, dataClaim.Address);
    await common.goNext();
    await vehicle.selectFirstAvailableDriver();
    await vehicle.selectFirstAvailableVehicle();
    await vehicle.setVehicleSafetyToDrive(dataClaim.TC3804.SafetyToDrive);
    await vehicle.setAirBagDeployStatus(dataClaim.TC3804.AirBagDeploy);
    await vehicle.setEquiFailureStatus(dataClaim.TC3804.EquipmentFailure);
    await vehicle.setVehicleTowStatus(dataClaim.TC3804.VehicleTowed);
    await vehicle.setVehicleRentalStatus(dataClaim.TC3804.RentalStatus);
    await vehicle.setVehicleCollisionPoint(dataClaim.TC3804.CollisionPoint);
    await common.goNext();
    await repair.selectNoFacility();
    await common.goNext();
    await document.withNewContactPerson(dataClaim.TC3804.FirstNameNewPerson, dataClaim.TC3804.LastNameNewPerson, dataClaim.TC3804.NewPersonHomePhone);
    await document.uploadDocFromFNOL(dataClaim.TC3804.FileName);
    var draftNum = await detail.getDraftClaimNumber();
    await wizard.cancelWizardPopup();
    await policySummary.goToclaimsTile();
    await claimList.openClaimDetailsPage(draftNum);
    await t.wait(2000);
    await document.isDocumentUploaded();
    await document.areNewPersonDetailsAreSaved();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3805: test Cancel Claim On Contact Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaimTillAdditionalInformation(dataClaim.TC3805, dataClaim.Address);
    await contact.withNewContactPerson(dataClaim.TC3805);
    await contact.withContactCellNum(dataClaim.TC3805.CellPhoneNewContact);
    await contact.withContactHomeNum(dataClaim.TC3805);
    await contact.withContactWorkNum(dataClaim.TC3805.WorkNewContact);
    var draftNum = await detail.getDraftClaimNumber();
    await wizard.cancelWizardPopup();
    await policySummary.goToclaimsTile();
    await claimList.openClaimDetailsPage(draftNum);
    await claimList.clickAdditionalInformationWizard();
    await document.isDocumentUploaded();
    await common.goNext();
    await contact.areContactPersonDetailsAreSaved(dataClaim.TC3805);

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3806: test Cancel Claim On Summary Page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaimTillAdditionalInformation(dataClaim.TC3806, dataClaim.Address);
   await contact.goToSummary();
    var summaryData = await summary.getBasicClaimSummaryDetails();
    var draftNum = await summary.getDraftClaimNumber();
    await wizard.cancelWizardPopup();
    await policySummary.goToclaimsTile();
    await claimList.openClaimDetailsPage(draftNum);
    await claimList.clickAdditionalInformationWizard();
    await document.isDocumentUploaded();
    await common.goNext();
    await contact.goToSummary();
    await summary.validateClaimSummaryPageData(summaryData);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3799: test Mandatory Fields For New Vehicle', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3799.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3799.ClaimTypeCollision);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3799.LossLocationInput, dataClaim.Address);
    await detail.typeDescribeWhatHappened(dataClaim.TC3799.LossCause);
    await detail.withPropDamageDetails(dataClaim.TC3799.WithPropDamage);
    await common.goNext();
    await vehicle.selectOtherVehicle();
    await common.validateNextButtonIsDisabled();
    await vehicle.enterNewVehicle(dataClaim.TC3809);
    await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3797: test Mandatory Fields For Additional New Vehicle', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3797.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3797.ClaimTypeCollision);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3797.LossLocationInput, dataClaim.Address);
    await common.goNext();
    await vehicle.selectFirstAvailableDriver();
    await vehicle.selectFirstAvailableVehicle();
    await vehicle.addAdditionalVehicle();
    await vehicle.selectVehicleOnAdditionalVehiclePage();
    await common.validateNextButtonIsDisabled();

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3808: test Mandatory Fields For New Driver', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3808.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3808.ClaimTypeCollision);
    await common.goNext();
    await detail.withLossLocation(dataClaim.TC3808.LossLocationInput, dataClaim.Address);
    await common.goNext();
    await vehicle.selectDriver('Other Driver');
    await common.validateNextButtonIsDisabled();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3796: test Add Note To PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3796, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.openNoteTab();
    await claimSummaryNote.addNote();
    await claimSummaryNote.addNoteDetails(dataClaim.TC3796);
    await claimSummary.openNoteTab();
    await claimSummaryNote.searchNote(dataClaim.TC3796.NoteSubject);
    await claimSummaryNote.isNotesAdded(dataClaim.TC3796);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3798: test Missing Mandatory Values For Add Note To PA Claim', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaim(dataClaim.TC3798, dataClaim.Address);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.openNoteTab();
    await claimSummaryNote.addNote();
    await claimSummaryNote.saveNotes();
    await claimSummaryNote.validateMandatoryFieldsErrorOnNotePage();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3809: test PA Claim With New Vehicle', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3809.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3809.ClaimTypeCollision);
    await common.goNext();
    await detail.withExactAccidentAddress(dataClaim.Address);
    await common.goNext();
    await vehicle.withNewVehicle(dataClaim.TC3809);
    await vehicle.selectFirstAvailableDriver();
    await common.goNext();
    await repair.selectNoFacility();
    await common.goNext();
    await contact.goToSummary();
    await common.goNext();
    await summary.clickSubmitClaim();
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC3810: test PA Claim With New Driver', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC3810.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC3810.ClaimTypeCollision);
    await common.goNext();
    await detail.withExactAccidentAddress(dataClaim.Address);
    await common.goNext();
    await vehicle.selectFirstAvailableVehicle();
    await vehicle.withNewDriver(dataClaim.TC3810);
    await common.goNext();
    await repair.selectNoFacility();
    await common.goNext();
    await contact.goToSummary();
    await common.goNext();
    await summary.clickSubmitClaim();
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('TC4474: test PA Claim With No Repair', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await common.goNext();
    await type.selectPAClaimType(dataClaim.TC4474.ClaimSubType);
    await type.selectCollisionClaimType(dataClaim.TC4474.ClaimTypeCollision);
    await common.goNext();
    await detail.withExactAccidentAddress(dataClaim.Address);
    await common.goNext();
    await vehicle.selectFirstAvailableVehicle();
    await vehicle.selectFirstAvailableDriver();
    await common.goNext();
    await repair.selectNoFacility();
    await common.goNext();
    await common.goNext();
    await contact.goToSummary();
    await summary.clickSubmitClaim();
    var claimNumber = await confirm.getClaimNumber();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
    await assert.textNotContains(await claimSummary.getPartiesInvolvedDataFromUI(), 'VendorName', 'Vendor is available on UI');
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('test PA Collision Claim For Vendor Choice', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createCollisionClaimForVendorChoice(dataClaim.vendorChoice, dataClaim.Address);
    await repair.selectRecommendedFacility();
    await repair.selectVendor();
    await common.goNext();
    await common.goNext();
    await contact.goToSummary();
    await summary.clickSubmitClaim();
    var claimNumber = await confirm.getClaimNumber();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });

test('test PA Glass Claim For Vendor Choice', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await vendorGen.generateVendorWithBodyService();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createGlassClaimForVendorChoice(dataClaim.GlassVendorChoice, dataClaim.Address);
    await repair.selectRecommendedFacility();
    await repair.selectFirstAvailableVendor();
    await common.goNext();
    await common.goNext();
    await contact.goToSummary();
    await summary.clickSubmitClaim();
    var claimNumber = await confirm.getClaimNumber();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isPAPageDisplayedCorrectly();
    var uiValue = await claimSummary.getClaimSummaryDataFromUI('PersonalAuto');
    var backEndValue = await claimSummary.getClaimSummaryAgentDataFromBackEnd(claimNumber);
    await claimSummary.isClaimSummaryDataForAgentMatchingWithBackEnd(uiValue, backEndValue);
}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
