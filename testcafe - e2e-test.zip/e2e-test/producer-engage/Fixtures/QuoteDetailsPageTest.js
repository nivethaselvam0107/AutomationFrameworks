import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator.js'
import AddNoteComponent from '../Pages/AddNoteComponent';
import NavBar from '../Pages/NavBar';
import PE_PageQuoteFactory from '../Pages/PE_PageQuoteFactory';
import AccountsLanding from '../Pages/AccountsLanding';
import AlertHandler from '../Pages/AlertHandler';
import AccountSummary from '../Pages/AccountSummary';
import QuoteSummary from '../Pages/QuoteSummary';
import AccountSearch from '../Pages/AccountSearch';
import QuoteStart from '../Pages/QuoteStart';

const data = require('../Data/PE_PA_Data.json');
const dataQnB = require('../Data/QnB_PA_Data.json');
const accountSearch = new AccountSearch();
const quoteStart = new QuoteStart();
const nav = new NavBar();
const policyGen = new PolicyGenerator();
const login = new Login();
const pageQuote = new PE_PageQuoteFactory();
const accountLanding = new AccountsLanding();
const addNote = new AddNoteComponent();
const accountSummary = new AccountSummary();
const quoteSummary = new QuoteSummary();
const alert = new AlertHandler();
const accSum = new AccountSummary();

fixture`QuoteDetails`
test('TC5805: Verify validation message is displayed for missing values while add a note to quote', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createDraftQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.goToQuoteSummaryPage(quoteNum);
   await quoteSummary.validatestatusOfQuote('Draft');
   await quoteSummary.goToNotesTile();
   await addNote.clickAddNote();
   await addNote.validateAddbuttonIsDisabled();
   await addNote.withTopic('General');
   await addNote.withSubject(data.TC5805.Note);
   await addNote.withNoteText(data.TC5805.Note);
   await addNote.validateAddbuttonIsEnabled();
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC5807: Verify Quote Details page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createDraftQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.goToQuoteSummaryPage(quoteNum);
   await quoteSummary.validatestatusOfQuote('Draft');
   await quoteSummary.validateQuotePageComponents();
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC5810: Verify user can withdraw quote if the quote status is draft ', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createDraftQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.goToQuoteSummaryPage(quoteNum);
   await quoteSummary.validatestatusOfQuote('Draft');
   await quoteSummary.clickWithdrawQuote();
   await quoteSummary.validateQuoteWithdrawn();
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC5813:Verify user can withdraw quote if the quote status is quoted ', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createQuotedQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.goToQuoteSummaryPage(quoteNum);
   await quoteSummary.validatestatusOfQuote('Quoted');
   await quoteSummary.clickWithdrawQuote();
   await quoteSummary.validateQuoteWithdrawn();
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC5819:Verify user can add a note on quote details page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createQuotedQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.goToQuoteSummaryPage(quoteNum);
   await quoteSummary.goToNotesTile();
   await addNote.addGeneralNote(data.TC5819.NoteSubject);
   await addNote.isNoteListed(data.TC5819.NoteSubject);
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC3512: SearchQuoteByProvidingPartialQuoteNumber Verify user can search for quote by providing partial quote number', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createQuotedQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.searchQuoteByPartialNumber(quoteNum);
   await accSum.isquotepresented(quoteNum);
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});

test('TC3509: Verify user can search for quote by providing full quote number.', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountSearch.clickPersonal();
   await accountSearch.typeFirstName(policyData.accountFirstName);
   await accountSearch.typeLastName(policyData.accountLastName);
   await accountSearch.clickSearchButton();
   await accountSearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
   await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
   await quoteStart.clickSubmit();
   const quoteNum = await pageQuote.createQuotedQuote(dataQnB);
   await nav.goToAccountsLanding();
   await alert.clickYes();
   await accountLanding.showRecentlyCreated();
   await accountLanding.clickAccountNameLink(policyData.accountNumber)
   await accountSummary.goToOpenQuotes();
   await pageQuote.searchQuoteByQuoteNumber(quoteNum);
   await accSum.isquotepresented(quoteNum);
}).meta({Emerald:"true",Granite:"true",Ferrite:"true"});



