import Login from "../Login";
import QualificationPage from "../Pages/QualificationPage";
import CommonLocators from "../../Utilities/CommonLocators";
import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import YourHomePage from "../Pages/YourHomePage";
import ConstructionPage from "../Pages/ConstructionPage";
import DiscountPage from "../Pages/DiscountPage";
import HOQuotePage from "../Pages/HOQuotePage";
import HOPolicyInfoPage from "../Pages/HOPolicyInfoPage";
import HOPaymentDetailsPage from "../Pages/HOPaymentDetailsPage";
import HOPolicyConfirmationPage from "../Pages/HOPolicyConfirmationPage";
import GPA_QuotePageFactory from "../Pages/GPA_QuotePageFactory";
import PropertyLocationModel from "../Pages/PropertyLocationModel"
import QuoteStart from '../Pages/QuoteStart';
import AdditionalInformationPage from "../Pages/AdditionalInformationPage"

import NavBar from "../Pages/NavBar";
const nav = new NavBar();
import AccountSearch from "../Pages/AccountSearch";
const accountSearch = new AccountSearch();
import AccountCreate from "../Pages/AccountCreate";

const accountCreate = new AccountCreate();
const data = require("../Data/PE_HO_Data.json");
const dataQnB = require("../Data/QnB_HO_Data.json");
const login = new Login();
const policyGen = new PolicyGenerator();
const qualiPage = new QualificationPage();
const construction = new ConstructionPage();
const common = new CommonLocators();
const discount = new DiscountPage();
const yourHome = new YourHomePage();
const hoQuote = new HOQuotePage();
const hoPolicyInfo = new HOPolicyInfoPage();
const hoPayment = new HOPaymentDetailsPage();
const policyConfirmation = new HOPolicyConfirmationPage();
const quotePageFactory = new GPA_QuotePageFactory();
const propertyLocation = new PropertyLocationModel();
const quoteStart = new QuoteStart();
const addInfo=new AdditionalInformationPage();

fixture`HO Scheduled Items Test`;
//Selector has to change
test.skip("TC4138 : Add Scheduled Personal Property Item For HO: Verify user can add Scheduled Personal Property Item for HO", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4138);
    await hoQuote.clickRecalculate();
    await t.wait(3000);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validatePersonalProperty(data.TC4138);
}).meta({Ferrite:"true"});
//Selector has to change
test.skip("TC4139: Missing Mandatory Values While Adding Scheduled Personal Property : Verify validation message is displayed when user tries to add a scheduled personal property item.", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    await hoQuote.clickAddScheduledPersonalProperty(data.TC4139);
    await common.validateScheduledAddButtonIsDisabled();
    await hoQuote.addHOScheduledPersonalPropertyDescription(data.TC4146.ScheduledDescription);
    await hoQuote.addScheduledPersonalPropertyType(data.TC4146.ScheduledType);
    await hoQuote.addHOScheduledPropertyValue(data.TC4146.ScheduledValue);
    await common.validateScheduledAddButtonIsEnabled();
}).meta({Ferrite:"true"});
//Selector has to change
test.skip("TC4146 : Add Special Limits Personal Property:  Verify user can add Special Limits Personal Property Item for HO", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4146);
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validatePersonalProperty(data.TC4146);
}).meta({Ferrite:"true"});
//Selector has to change
test.skip("TC4143 Missing Mandatory Values While Adding Special Limits Personal Property: Verify validation message is displayed when user tries to add a special limits personal property item.", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    await hoQuote.clickAddScheduledPersonalProperty(data.TC4143);
    await common.validateScheduledAddButtonIsDisabled();
    await hoQuote.addHOScheduledPersonalPropertyDescription(data.TC4146.ScheduledDescription);
    await hoQuote.addScheduledPersonalPropertyType(data.TC4146.ScheduledType);
    await hoQuote.addHOScheduledPropertyValue(data.TC4146.ScheduledValue);
    await common.validateScheduledAddButtonIsEnabled();
}).meta({Ferrite:"true"});
//Selector has to change
test.skip("TC4142: Add Other Structures On The Residence Premises: Verify user can add Other Structures on the Residence Premises for HO", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    await hoQuote.addOtherStructures(data.TC4142);
    await hoQuote.clickRecalculate();
    await t.wait(3000);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validateOtherPersonalProperty(data.TC4142);
}).meta({Ferrite:"true"});
//Selector has to change
test.skip("TC4147 Missing Mandatory Values While Adding Other Structures On The Residence Premises: Verify validation message is displayed when user tries to add Other Structures On The Residence Premises", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    await hoQuote.clickAddScheduledPersonalProperty(data.TC4147);
    await common.validateScheduledAddButtonIsDisabled();
    await hoQuote.addHOScheduledPersonalPropertyDescription(data.TC4147.ScheduledDescription);
    await propertyLocation.setIncreasedLimit(data.TC4147);
    await common.validateScheduledAddButtonIsEnabled();
}).meta({Ferrite:"true"});

test("TC4148 : Edit Special Limits Personal Property", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4148);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4148);
    await accountCreate.fillEmailAddress(data.TC4148);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4148);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite(dataQnB.qualificationPage);
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4148);
    await hoQuote.clickRecalculate();
    await t.wait(3000);
    await hoQuote.editFirstHOScheduledPersonalProperty(dataQnB.QuotePage);
    await t.wait(3000);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validatePersonalProperty(dataQnB.QuotePage);
    const fetchData = await policyGen.getQuote(quoteID, data.TC4148.Zip);
    await policyConfirmation.validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4149 : Remove Special Limits Personal Property", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4149);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4149);
    await accountCreate.fillEmailAddress(data.TC4149);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4149);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite(dataQnB.qualificationPage);
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4149);
    await hoQuote.clickRecalculate();
    await t.wait(1000);
    await hoQuote.deleteFirstProperty();
    await hoQuote.clickRecalculate();
    await t.wait(1000);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4149.Zip);
    await policyConfirmation.checkSpecialScheduledPropertyIsEmpty(fetchData);
}).meta({Ferrite:"true"});

test("TC4144 : Edit Other Structures On The Residence Premises", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4144);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4144);
    await accountCreate.fillEmailAddress(data.TC4144);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4144);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite(dataQnB.qualificationPage);
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addOtherStructures(data.TC4144);
    await hoQuote.clickRecalculate();
    await hoQuote.editFirstOtherStructureOnPremisesProperty(dataQnB.QuotePage);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validateOtherPersonalProperty(dataQnB.QuotePage);
    var fetchData = await policyGen.getQuote(quoteID, data.TC4144.Zip);
    await policyConfirmation.validateHOOtherScheduledPersonalPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4145 : Remove Other Structures On The Residence Premises", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4145);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4145);
    await accountCreate.fillEmailAddress(data.TC4145);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4145);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite(dataQnB.qualificationPage);
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addOtherStructures(data.TC4145);
    await hoQuote.clickRecalculate();
    await hoQuote.deleteFirstProperty();
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4145.Zip);
    await policyConfirmation.checkOtherScheduledPropertyIsEmpty(fetchData);
}).meta({Ferrite:"true"});

test("TC4158 : Verify Scheduled Items In PC", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4158);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4158);
    await accountCreate.fillEmailAddress(data.TC4158);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4158);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite(dataQnB.qualificationPage);
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4158.scheduledPersonalProperty);
    await hoQuote.addHOScheduledPersonalProperty(data.TC4158.specialLimitsPersonalProperty);
    await hoQuote.addOtherStructures(data.TC4158.otherStructures);
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4158.Zip);
    await policyConfirmation.validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(fetchData);
    await policyConfirmation.validateHOOtherScheduledPersonalPropertyDataWithBackEnd(fetchData);
    await policyConfirmation.validateHOScheduledPersonalPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4140 : Edit Scheduled Personal Property Item For HO", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4140);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4140);
    await accountCreate.fillEmailAddress(data.TC4140);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4140);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4140);
    await hoQuote.clickRecalculate();
    await hoQuote.editFirstHOScheduledPersonalProperty(dataQnB.QuotePage);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.validatePersonalProperty(dataQnB.QuotePage);
    var fetchData = await policyGen.getQuote(quoteID, data.TC4140.Zip);
    await policyConfirmation.validateHOScheduledPersonalPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4141 : Remove Scheduled Personal Property Item For HO", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4141);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4141);
    await accountCreate.fillEmailAddress(data.TC4141);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4141);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addHOScheduledPersonalProperty(data.TC4141);
    await hoQuote.clickRecalculate();
    await hoQuote.deleteFirstProperty();
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4141.Zip);
    await policyConfirmation.checkScheduledPersonalPropertyIsEmpty(fetchData);
}).meta({Ferrite:"true"});

test("TC4150 : Add Personal Property At Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4150);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4150);
    await accountCreate.fillEmailAddress(data.TC4150);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4150);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addPersonalPropertyAtOtherResidence(data.TC4150);
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4150.Zip);
    await policyConfirmation.validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4152 : Edit Personal Property At Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4152);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4152);
    await accountCreate.fillEmailAddress(data.TC4152);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4152);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addPersonalPropertyAtOtherResidence(data.TC4152);
    await hoQuote.clickRecalculate();
    await hoQuote.editFirstPersonalPropertyOnOtherPremises(data.TC4152.EditData);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4152.Zip);
    await policyConfirmation.validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4153 : Remove Personal Property At Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4141);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4141);
    await accountCreate.fillEmailAddress(data.TC4141);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4141);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addPersonalPropertyAtOtherResidence(data.TC4153);
    await hoQuote.clickRecalculate();
    await hoQuote.deleteFirstProperty();
    await t.wait(1000);
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID, data.TC4152.Zip);
    await policyConfirmation.checkPersonalPropertyAtOtherResidencesIsEmpty(fetchData);
}).meta({Ferrite:"true"});

test("TC4151 : Mandatory Fields Personal Property At Other Residences", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    await hoQuote.clickAddScheduledPersonalProperty(data.TC4151);
    await propertyLocation.addNewLocation();
    await propertyLocation.validateMandatoryFieldsOfPersonalPropertyAtOtherResidence(data.TC4151);
}).meta({Ferrite:"true"});

test("TC4154 : Add Specific Structures Away From The Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4141);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4141);
    await accountCreate.fillEmailAddress(data.TC4141);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4141);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data.TC4154);
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await addInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID,'94404');
    await policyConfirmation.validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(fetchData)
}).meta({Ferrite:"true"});

test("TC4156 : Edit Specific Structures Away From The Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4141);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4141);
    await accountCreate.fillEmailAddress(data.TC4141);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4141);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data.TC4156);
    await hoQuote.clickRecalculate();
    await hoQuote.editFirstSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data.TC4156.EditedData);
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID,'94404');
    await policyConfirmation.validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(fetchData);
}).meta({Ferrite:"true"});

test("TC4157 : Remove Specific Structures Away From The Other Residences", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC4141);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC4141);
    await accountCreate.fillEmailAddress(data.TC4141);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC4141);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await common.goNext();
    var quoteID = await hoQuote.getSubmissionNumber();
    await hoQuote.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data.TC4157);
    await hoQuote.clickRecalculate();
    await hoQuote.deleteFirstProperty();
    await hoQuote.clickRecalculate();
    await hoQuote.buyBasePolicyWithMonthlyPremium();
    await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
    await common.goNext();
    await hoPolicyInfo.setPolicyInfoPageDetails(dataQnB.HOPolicyInfoPage);
    await common.goNext();
    await hoPayment.payMonthlyPremiumWithSavingsBankAccount(
        dataQnB.HOPaymentDetailsPage
    );
    await hoPayment.purchasePolicy();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    var fetchData = await policyGen.getQuote(quoteID,'94404');
    await policyConfirmation.checkSpecificStructuresAtOtherResidencesIsEmpty(fetchData);
}).meta({Ferrite:"true"});

test("TC4155 : Mandatory Fields Specific Structures Away From The Other Residences", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();//change
    await quoteStart.fillQuoteForHOExistingAccount(data.policyInfoValidationHO);
    await quoteStart.clickSubmit();
    await qualiPage.setQualificationPageDetailsHOFerrite();
    await common.goNext();
    await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
    await common.goNext();
    await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
    await common.goNext();
    await discount.setDiscountPageDetails(dataQnB.DiscountPage);
    await t.wait(3000);
    await common.goNext();
    await hoQuote.clickAddScheduledPersonalProperty(data.TC4155);
    await common.validateScheduledAddButtonIsDisabled();
    await propertyLocation.validateMandatoryFieldsOfSpecificStrAtOtherResidence(data.TC4156);
    await common.validateScheduledAddButtonIsEnabled();
}).meta({Ferrite:"true"});