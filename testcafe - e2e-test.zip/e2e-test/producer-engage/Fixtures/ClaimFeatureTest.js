import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ClaimsTileView from '../Pages/ClaimsTileView';
import NewClaimConfirmationPage from '../Pages/NewClaimConfirmationPage';
import NewClaimContactDetailsPage from '../Pages/NewClaimContactDetailsPage';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import Tiles from '../Pages/Tiles';
import PolicySummary from '../Pages/PolicySummary';
import PE_PageQuoteFactory from '../Pages/PE_PageQuoteFactory';
import PAQuotePage from '../Pages/PAQuotePage';
import PolicyConfirmationPage from '../Pages/PolicyConfirmationPage';
import AccountSummary from '../Pages/AccountSummary';
import NewClaimClaimSummary from '../Pages/NewClaimSummaryPage';
import ClaimSummaryDocumentsTab from '../Pages/ClaimSummaryDocumentsTab';
import ClaimSummaryNotesTab from '../Pages/ClaimSummaryNotesTab';
import SelectPolicy from '../Pages/SelectPolicy';
import NavBar from '../Pages/NavBar';
import ClaimsLanding from '../Pages/ClaimsLanding';
import Login from '../Login';
import Assertion from '../../Utilities/Assertions';
import AccountSearch from '../Pages/AccountSearch';
import QuoteStart from '../Pages/QuoteStart';
import Helper from '../../Utilities/Helper';

const assert = new Assertion();
const helper = new Helper();
const quotePageFactory = new PE_PageQuoteFactory();
const policyGen = new PolicyGenerator();
const claimsTileView = new ClaimsTileView();
const claimsPage = new ClaimsPageFactory();
const claimConfirmation = new NewClaimConfirmationPage();
const documentsTab = new ClaimSummaryDocumentsTab();
const claimSummary = new ClaimSummaryPage();
const dataClaim = require('../Data/PE_Claim.json');
const dataQnB = require('../Data/QnB_PA_Data.json');
const policySummary = new PolicySummary();
const quotePagePA = new PAQuotePage();
const policyConfirm = new PolicyConfirmationPage();
const accountSummary = new AccountSummary();
const notesTab = new ClaimSummaryNotesTab();
const selPolicy = new SelectPolicy();
const navBar = new NavBar();
const claimsLanding = new ClaimsLanding();
const login = new Login();
const accountSearch = new AccountSearch();
const quoteStart = new QuoteStart();

fixture`Claim Features`
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3830: AddDocToClaim', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimsTileView.uploadDocument(claimNumber,dataClaim.PAcollision.FileName1);
    await documentsTab.isDocAdded(dataClaim.PAcollision.FileName1);
    var uiValue = await documentsTab.getClaimDocumentNamesFromUI();
    var backEndValue = [];
    backEndValue = await documentsTab.getClaimDocumentDataFromBackEnd(claimNumber);
    await assert.assertEqual(uiValue.length,backEndValue.length,'Claim Document Data is not matched with Back End');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3831:ClaimsDetailsPage', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    await claimSummary.openNoteTab();
    await notesTab.addANewNote(dataClaim.TC3831);
    await notesTab.validateNotePageElements(dataClaim.TC3831);
    await claimSummary.openDocTab();
    await documentsTab.uploadFile('../../Utilities/FileTypes/JPGFile.jpg');
    await documentsTab.validateDocPageElementsOnClaimSummary();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3832: ViewPolicyFromClaimsPage', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    await claimConfirmation.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await policySummary.goToPolicySummaryPage(policyData.policyNum);
    await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3833: ClaimFilterOnAccDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
     await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await assert.assertEqual(await claimsTileView.validateLOBDropDown(),true,'LOB options are not listed correctly');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3834: ViewPolicyFromClaimsDetailsPage', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    await claimSummary.clickPolicyNumber();
    await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);
 }).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
 test.skip('TC3835:ViewAccountFromClaimsDetailsPage', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    await claimSummary.clickAccountNumber();
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3837: LossDateInFutureWhileFilingAClaim',async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await selPolicy.withClaimDateOfLossInFuture();
    await selPolicy.selectPolicy();
    await selPolicy.validateNextButtonIsDisabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3840: ClaimAndPolicyDetailsinClaimCenter', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    var uiData = await claimSummary.getClaimSummaryDataFromUI('PersonalAuto');
    console.log(uiData)
    var backEndData = await claimSummary.getClaimSummaryDataFromBackEnd(claimNumber,'PersonalAuto');
    console.log(backEndData);
    await assert.assertEqual(await claimSummary.isClaimSummaryDataMatchingWithBackEnd(uiData,backEndData),true,'Claim Summary Data is not matched with Back End');

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3846: DeleteClaimDocument', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    await claimSummary.openDocTab();
    await documentsTab.deleteDoc();
    await documentsTab.isDocTableEmpty();
    var uiValue = await documentsTab.getClaimDocumentNamesFromUI();
    var backEndValue = await documentsTab.getClaimDocumentDataFromBackEnd(claimNumber);
    console.log(await documentsTab.validateClaimDocumentDataWithBackEnd(uiValue,backEndValue));
    await assert.assertEqual(await documentsTab.validateClaimDocumentDataWithBackEnd(uiValue,backEndValue),true,'Claim Document Data is not matched with Back End');

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3847: ReferenceNumberFormat',async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    await assert.assertEqual(await claimConfirmation.validateReferenceNumberFormat(),true,'Reference number doesnot match format');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3848: PAClaimOnPolicyDetailPage',async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPageTroughPolicies(policyData);
    await claimsTileView.goToMakeAClaim();
    await claimsPage.createCollisionClaim(dataClaim.TC3831, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToPolicySummaryPage();
    await  policySummary.goToclaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    var uiData = await claimSummary.getClaimSummaryDataFromUI('PersonalAuto');
    var backEndData = await claimSummary.getClaimSummaryDataFromBackEnd(claimNumber,'PersonalAuto');
    await assert.assertEqual(await claimSummary.isClaimSummaryDataMatchingWithBackEnd(uiData,backEndData),true,'Claim Summary Data is not matched with Back End');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3849: AddNoteToAdjusterOnClaimsDetails', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsTileView.selectClaim(claimNumber);
    await notesTab.addNoteInSummary();
    await notesTab.addNoteDetails(dataClaim.PAcollision);
    await documentsTab.openNoteTab();
    await notesTab.isNotesAdded(dataClaim.PAcollision);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3857: ViewAccountDetailsFromLandingClaims', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await navBar.goToClaimsLanding();
    await accountSummary.clickRecentlyCreatedTile();
    await claimsLanding.clickAccountName(policyData.accountNumber);
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3858: ViewPolicyDetailsFromLandingClaims', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address); var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await navBar.goToClaimsLanding();
    await accountSummary.clickRecentlyCreatedTile();
    await claimsLanding.clickPolicyNumber(policyData.policyNum);
    await policySummary.isPolicyDetailsPageLoaded(policyData.policyNum);

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3859: ViewClaimDetailsFromLandingClaims', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await navBar.goToClaimsLanding();
    await accountSummary.clickRecentlyCreatedTile();
    await claimsLanding.clickClaimNumber(claimNumber);
    await claimSummary.isClaimSummaryPageLoaded();

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3860: RecentlyViewedTileOnClaimsLanding', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await navBar.goToClaimsLanding();
    await claimsLanding.validateClaimIsNotPresent(claimNumber);
    await accountSummary.clickRecentlyCreatedTile();
    await claimsLanding.clickClaimNumber(claimNumber);
    await claimSummary.isClaimSummaryPageLoaded();
    await navBar.goToClaimsLanding();
    await claimsLanding.validateClaimIsPresent(claimNumber);

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3861: RecentlyCreatedTileOnClaimsLanding', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    var claimNumber = await claimConfirmation.getClaimNumber();
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await navBar.goToClaimsLanding();
    await accountSummary.clickRecentlyCreatedTile();
    await claimsLanding.validateClaimIsPresent(claimNumber);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Defect-https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3862: OpenClaimsTileOnClaimsLanding', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await claimsPage.goToAccountsClaimsPage(policyData);
    await claimsTileView.clickfileAClaimAccount();
    await claimsPage.createCollisionClaimFromAccount(dataClaim.PAcollision, dataClaim.Address);
    await claimConfirmation.goToAccountSummaryPage();
    await  accountSummary.goToAccountsClaimsTile();
    await claimsPage.createPACollisionDraftClaim( dataClaim.Address);
    await navBar.goToClaimsLanding();
    await accountSummary.clickRecentlyCreatedTile();
    await assert.assertEqual(await claimsLanding.validateOpenClaims(),true,'Not only Draft and Open claims are shown.');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

