import Login from '../Login';
import PolicyLanding from '../Pages/PolicyLanding';
import AccountSearch from "../Pages/AccountSearch";
import PolicySummary from '../Pages/PolicySummary';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import RenewalGenerator from '../../Utilities/Generator/RenewalGenerator';
import DocumentsTab from '../Pages/DocumentsTab';
import AlertHandler from '../Pages/AlertHandler';
import Modal from '../../Utilities/WidgetComponents/Modal';
import Assertion from '../../Utilities/Assertions';
import PAQuotePage from '../Pages/PAQuotePage';
import QuoteSummary from '../Pages/QuoteSummaryPage';
import QuoteStart from '../Pages/QuoteStart';
import QualificationPage from '../Pages/QualificationPage';
import DriversPage from '../Pages/DriversPage';
import CommonLocators from "../../Utilities/CommonLocators";
import VehiclesPage from '../Pages/VehiclesPage';
import PolicyCancellationPage from '../Pages/PolicyCancellation';
import AccountsSummary from '../Pages/AccountSummary';
import NavBar from '../Pages/NavBar';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import AddNoteComponent from '../Pages/AddNoteComponent';
import ClaimsTileView from '../Pages/ClaimsTileView';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import NewClaimConfirmationPage from '../Pages/NewClaimConfirmationPage';
import AgentDashboard from '../Pages/AgentDashboard';
import Tiles from '../Pages/Tiles';
const data = require('../Data/PE_PA_Data.json');
const dataQnB = require('../Data/QnB_PA_Data.json');
const dataClaim= require('../Data/PE_Claim.json');
const agent = new AgentDashboard();
const login = new Login();
const quoteStart = new QuoteStart();
const qualipage = new QualificationPage();
const accountsearch = new AccountSearch();
const policySummary = new PolicySummary();
const quoteSummary = new QuoteSummary();
const policyCancel = new PolicyCancellationPage();
const policyGen = new PolicyGenerator();
const renewalGen = new RenewalGenerator();
const nav = new NavBar();
const modal = new Modal();
const alert = new AlertHandler();
const docTab = new DocumentsTab();
const quote = new PAQuotePage();
const policyLanding = new PolicyLanding();
const assert = new Assertion();
const driversPage = new DriversPage();
const vehicles = new VehiclesPage
const common = new CommonLocators();
const accsum = new AccountsSummary();
const activity= new ActivityPageFactory();
const note =new AddNoteComponent();
const claimTile = new ClaimsTileView();
const homedir = require('os').homedir();
const claim = new ClaimsPageFactory();
const confirm = new NewClaimConfirmationPage();
const addNote = new AddNoteComponent();
const tiles=new Tiles();
fixture`Policy Details Page`

test('TC4067: Verify for validation message is displayed when user does not provide mandatory fields which adding note', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToNotesTile();
   await addNote.clickAddNote();
   await addNote.validateAddbuttonIsDisabled();
   await addNote.withTopic('General');
   await addNote.withSubject(data.TC4067.NoteSubject);
   await addNote.withNoteText(data.TC4067.NoteText);
   await addNote.validateAddbuttonIsEnabled();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4066: Verify user can add notes on policy details page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToNotesTile();
   await addNote.addGeneralNote(data.TC4066.NoteSubject);
   await addNote.isNoteListed(data.TC4066.NoteSubject);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4068: Verify user can add documents on policy details page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToDocumentsTile();
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await docTab.isDocAdded(data.UploadDocOnPolicyDetails.fileName);
   await t.wait(3000);
   let policy = await policyGen.getAgentPolicyDocument(policyData.policyNum);
   await docTab.validatePolicyDocumentDataWithBackEnd(policy.name, data.UploadDocOnPolicyDetails.fileName);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4060: Verify Documents On Policy Details Page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToDocumentsTile();
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await docTab.isDocAdded(data.UploadDocOnPolicyDetails.fileName);
   await docTab.validateDocTileElements();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4069: Verify for validation message is displayed when user tries to upload a documents with same name', async t => {
   var filepath = '../../Utilities/FileTypes/';
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToDocumentsTile();
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await alert.isFailedToUploadPopUpDisplayed();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test.skip('TC4070: Verify user can delete uploaded documents on policy details page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToDocumentsTile();
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await docTab.isDocAdded(data.UploadDocOnPolicyDetails.fileName);
   await docTab.deleteDoc();// modal pop up should be changed
   await docTab.ValidateDocDeleted();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4071: Verify user can view uploaded documents on policy details page', async t => {
   var filepath = '../../Utilities/FileTypes/';
   var downloadedPath = homedir + "/Downloads/" + data.UploadDocOnPolicyDetails.fileName;
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToDocumentsTile();
   await docTab.uploadFile(filepath + data.UploadDocOnPolicyDetails.fileName);
   await docTab.isDocAdded(data.UploadDocOnPolicyDetails.fileName);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4047: Verify user can view policy details page from Policies landing, recently viewed page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.goToPoliciesLanding();
   await policyLanding.showRecentlyIssued();
   await t.wait(2000);
   await policySummary.goToPolicySummaryPage(policyData.policyNum);
   await nav.goToPoliciesLanding();
   await policySummary.goToPolicySummaryPage(policyData.policyNum);
   await policySummary.validatePolicySummaryPageLoaded(policyData.policyNum);

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4048: Verify user can view policy details page from Policies landing, recently created page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.goToPoliciesLanding();
   await policyLanding.showRecentlyIssued();
   await policySummary.goToPolicySummaryPage(policyData.policyNum);
   await policySummary.validatePolicySummaryPageLoaded(policyData.policyNum);

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4049: Verify user can view policy details page from Policies landing, delinquent page', async t => {
   await login.login();
   await nav.goToPoliciesLanding();
   await policyLanding.showDelinquent();
   await policyLanding.openFirstPolicy();
   await tiles.validateTileOpened('SUMMARY');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4050: Verify user can view policy details page from Policies landing, open renewals page', async t => {
   var policyData = await renewalGen.createBasicDraftPARenewal();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.goToPoliciesLanding();
   await policyLanding.showOpenRenewals();
   await policySummary.goToPolicySummaryPage(policyData.policyNum);
   await policySummary.validatePolicySummaryPageLoaded(policyData.policyNum);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4052: Verify user can view policy details page from Policies landing, open cancellations page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   await nav.goToPoliciesLanding();
   await policyLanding.showOpenCancellations();
   await policySummary.goToPolicySummaryPage(policyData.policyNum);
   await policySummary.validatePolicySummaryPageLoaded(policyData.policyNum);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4053: View Quote From Policy Landing Open Quotes', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await nav.clickStartNewQuote();
   await accountsearch.clickPersonal();
   await accountsearch.typeFirstName(policyData.accountFirstName);
   await accountsearch.typeLastName(policyData.accountLastName);
   await accountsearch.clickSearchButton();
   await accountsearch.isAccountExists();
   await accountsearch.clickStartNewQuote();
   await quoteStart.selectProducerCode(data.TC4053.ProducerCode);
   await quoteStart.selectProductCode(data.TC4053.ProductCode);
   await quoteStart.clickSubmit();
   await qualipage.setPAQualificationPageDetails(dataQnB.qualificationPage);
   await common.goNext();
   await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
   await common.goNext();
   await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
   await common.goNext();
   var submissionNumber = await quote.getSubmissionNumber();
   await nav.goToPoliciesLanding();
   await modal.confirm();
   await policyLanding.showOpenQuotes();
   await policyLanding.openFirstJob();
   var quoteNumber = await quoteSummary.getQuoteNumber();
   await assert.assertEqual(quoteNumber, submissionNumber, 'Quote Page is not opened');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4056: Verify user can view the job, related to policy cancellation from policy landing page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policyCancel.clickCancelPolicy();
   await policyCancel.selectReasonForCancellation(data.PolicyCancellation.Reason3);
   await policyCancel.selectRefundMethod(data.PolicyCancellation.RefundMethod);
   await policyCancel.setDateWithinPolicyPeriod(policyData.policyNum);
   await policyCancel.startCancellation();
   var jobNumber = await policyCancel.getJobNumber();
   await nav.goToPoliciesLanding();
   await policyLanding.showOpenCancellations();
   await policyLanding.openJob(jobNumber);
   await policySummary.isCancellationPagePresented(jobNumber);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4058: Verify Open Activities on Policy details page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToOpenActivitiesTile();
   await activity.clickOnAddActivity();
   await activity.addDefaultActivity();
   await activity.validateActivityScheduleUIComponent();
   await activity.clickOnFirstActivity();
   await activity.validatedActivityRowUIComponent();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4059: Notes On Policy Details Page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToNotesTile();
   await note.addGeneralNote('Adding Notes On Policy Details Page');
   await note.isNoteListed('Adding Notes On Policy Details Page');
   await note.validateNoteUIComponent();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4061: Active Claims On Policy Details Page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.goToclaimsTile();
   await claimTile.fileAClaimPolicy();
   await claim.createTheftClaim(dataClaim.TC4061,dataClaim.Address);
   await confirm.goToPolicySummaryPage();
   await policySummary.goToclaimsTile();
   await claimTile.validateClaimTileViewUIInPolicy();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC4073: Verify Vehicle, Driver, Policy Transactions section on PA policy details page', async t => {
   let policyData = await policyGen.createBasicBoundPAPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.verifyVehiclesSection();
   await policySummary.verifyCoveredDriversSections();
   await policySummary.verifyPolicyTransactionsSections();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test("TC4074: Verify Home, Construction, Protection, Coverages and Policy transaction sections for HO policy",async t =>{
   let policyData = await policyGen.createBasicBoundHOPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.verifyHomeDetailsSections();
   await policySummary.verifyConstructionDetailsSections();
   await policySummary.verifyProtectionDetailsSections();
   await policySummary.verifyCoveragesDetailsSections();
   await policySummary.verifyPolicyTransactionsSections();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test("TC4075: Verify user can view Coverages and Policy Transactions for BOP",async t =>{
   let policyData = await policyGen.createBasicBoundBOPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.verifyCoveragesSectionsBO();
   await policySummary.verifyPolicyTransactionsSections();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test("TC4076: Verify user can view Coverages and Policy Transactions for CP",async t =>{
   let policyData = await policyGen.createBasicBoundCPPolicy();
   await login.loginasDiffUser(policyData.producerCode);
   await agent.searchUsingSearchBox(policyData.policyNum);
   await agent.goToPolicyFromPolicySearch();
   await policySummary.verifyCoveragesSectionsCP();
   await policySummary.verifyPolicyTransactionsSections();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
