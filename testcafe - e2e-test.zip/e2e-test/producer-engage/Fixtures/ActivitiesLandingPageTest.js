import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import NavBar from '../Pages/NavBar';
import AgentDashboard from '../Pages/AgentDashboard';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import AccountSummary from '../Pages/AccountSummary';
import Tiles from '../Pages/Tiles';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import ActivitiesScheduleComponent from '../Pages/ActivitiesScheduleComponent';
import AddNoteComponent from '../Pages/AddNoteComponent';


const login = new Login();
const policyGen = new PolicyGenerator();
const dataPE = require('../Data/PE_Data.json');
const agentDashboard = new AgentDashboard();
const navBar = new NavBar();
const activitiesLanding = new ActivitiesLanding();
const accountSummary = new AccountSummary();
const addNoteComponent = new AddNoteComponent();
const tiles = new Tiles();
const jsonDataResult = require('../../Utilities/Generator/PolicyGenerator');
const activityPageFactory = new ActivityPageFactory();
const activitiesScheduleComponent = new ActivitiesScheduleComponent();

fixture`Activities Landing Page`
//selector changed
test.skip('TC4127: ViewAccountFromActivities', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//Account number changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await navBar.isActivitiesLandingSelected();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesLanding.openAccountUsingAccountNumber(policyData.accountNumber);
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC4121: ViewOpenActivitiesOwnedByUser', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//account number selector changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await navBar.isActivitiesLandingSelected();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesLanding.validateMyOpenActivitiesData();
    await activitiesLanding.validateActivitiesCount();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC4122:ViewCompletedActivitiesAssignedToUser', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await navBar.isActivitiesLandingSelected();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesLanding.validateMyCompletedActivitiesData();
    await activitiesLanding.validateActivitiesCount();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC4124:ViewAllOpenActivities', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await navBar.isActivitiesLandingSelected();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesLanding.validateAllOpenActivitiesData();
    await activitiesLanding.validateActivitiesCount();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC4125:ViewAllCompletedActivities', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesScheduleComponent.isActivityScheduleComponentPresent();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesLanding.validateAllCompletedActivitiesData();
    await activitiesLanding.validateActivitiesCount();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC4126:Verify the Advanced Filter link Functionality on activities landing page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.clickAdvancedFiltersLink();
    await activitiesLanding.validateAllAdvancedFiltersPresent();
    await activitiesLanding.isActivityPresentOnAdvancedFiltersPage(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesLanding.clickUrgentFilter();
    await activitiesLanding.isActivityNotPresentOnAdvancedFiltersPage(policyData.accountFirstName+" "+policyData.accountLastName);

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector chnaged
test.skip('TC4130: NoteAdditionToCompletedActivity', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist(policyData.accountNumber, 'open');
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.doesAddNoteButtonExist(policyData.accountNumber, 'completed');

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector chnaged
test.skip('TC4129: CompleteAnActivity', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToActivitiesLanding();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.completeActivity(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesScheduleComponent.doesActivityStatusShowCompleted(policyData.accountFirstName+" "+policyData.accountLastName, 'COMPLETED');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC4133: AddNoteToTheActivity', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToActivitiesLanding();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await activitiesLanding.addNoteToNonCompleteActivity();
    await addNoteComponent.isNoteAddedToActivity(dataPE.activityFuture.subject, policyData.accountNumber);
    await addNoteComponent.validatedAddedNoteUIComponant();

}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector chnaged
test.skip('TC4134: MandatoryFieldCheckForAddingANote', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await navBar.goToActivitiesLanding();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await addNoteComponent.validateAddbuttonIsDisabled();
    await addNoteComponent.withTopic('General');
    await addNoteComponent.withSubject('NoteSubject');
    await addNoteComponent.withNoteText('NoteText');
    await addNoteComponent.validateMandatoryErrorMessage();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC4128: ViewActivityDetails', async t =>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.addFutureActivityFromActivityTile(dataPE.activityFuture);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.isActivitiesLandingPageOpened();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await addNoteComponent.clickAddNoteButton();
    await activitiesLanding.addNoteToNonCompleteActivity();
    await addNoteComponent.isNoteAddedToActivity(dataPE.activityFuture.subject);
    await activitiesLanding.validatedActivityUIComponant();
    await addNoteComponent.validatedAddedNoteUIComponant();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector chnaged
test.skip('TC4120: ActivityLandingPageVerification', async t =>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDueTomorrowActivityFromActivityTile(dataPE.activityTmrw);
    await navBar.goToActivitiesLanding();
    await activitiesLanding.areActivitiesLandingPageTilesDisplayed();
    await activitiesScheduleComponent.clickOnCorrespondingActivityUserOwns(policyData.accountFirstName+" "+policyData.accountLastName);
    await activitiesLanding.validatedDueDayActivityRowUIComponant(policyData.accountFirstName+" "+policyData.accountLastName,'Tomorrow');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});






