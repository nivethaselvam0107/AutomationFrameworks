import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import GPA_QuotePageFactory from '../Pages/GPA_QuotePageFactory';
import PE_PageQuoteFactory from '../Pages/PE_PageQuoteFactory';
import QuoteStart from '../Pages/QuoteStart';
import PAQuotePage from '../Pages/PAQuotePage';
import NavBar from '../Pages/NavBar';
import AccountSearch from "../../producer-engage/Pages/AccountSearch";
import Assertion from '../../Utilities/Assertions';

const login = new Login();
const policyGen = new PolicyGenerator();
const quotePage = new GPA_QuotePageFactory();
const quotePagePE = new PE_PageQuoteFactory();
const quoteStart = new QuoteStart();
const data = require('../Data/PE_PA_Data.json');
const quotepagePA = new PAQuotePage();
const dataQnB = require("../Data/QnB_PA_Data.json");
const navBar = new NavBar();
const accountSearch = new AccountSearch();
const assert = new Assertion();


fixture`Risk Reserved Test`

test('TC4162 @ Verify risk reserved functionality when policies are bound', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await navBar.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.useExistingAccountWithAccountNumber(policyData.accountNumber);
    await quoteStart.selectState(data.RiskReserve.State);
    await quoteStart.selectProducerCode(data.RiskReserve.ProducerCode_1);
    var PcodeDisabled = await quoteStart.isProductCodeNotAvailableWithRiskReservedTag(data.RiskReserve.ProductCode);
    await assert.assertEqual(PcodeDisabled,true,'product code is not risk reserved');
}).meta({Ferrite:"true",Granite:"true"});

test.skip('TC4160 @ Verify risk reserved functionality when policies are quoted', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await quotePage.startQuoteWithExistingAcount(policyData);
    await quoteStart.selectState(data.RiskReserve.State);
    await quoteStart.selectProducerCode(data.RiskReserve.ProducerCode_1);
    await quoteStart.selectProductCode(data.RiskReserve.ProductCode);
    await quoteStart.clickSubmit();
    await quotePagePE.createQuotedQuote(dataQnB);
    await quotepagePA.goToAccountPage();
    await quotePage.clickQuoteBtnAndFindAccount(policyData);
    await quoteStart.selectState(data.RiskReserve.State);
    await quoteStart.selectProducerCode(data.RiskReserve.ProducerCode_2);
    var PcodeDisabled = await quoteStart.isProductCodeNotAvailableWithRiskReservedTag(data.RiskReserve.ProductCode);
    await assert.assertEqual(PcodeDisabled,true,'product code is not risk reserved');
}).meta({Ferrite:"true",Granite:"true"});

test.skip('TC4161 @ Verify risk reserved functionality when policies are issued', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await quotePage.startQuoteWithExistingAcount(policyData);
    await quoteStart.selectState(data.RiskReserve.State);
    await quoteStart.selectProducerCode(data.RiskReserve.ProducerCode_1);
    await quoteStart.selectProductCode(data.RiskReserve.ProductCode);
    await quoteStart.clickSubmit();
    await quotePage.createAndBuyPolicyPA(dataQnB);
    await quotePage.clickQuoteBtnAndFindAccount(policyData);
    await quoteStart.selectState(data.RiskReserve.State);
    await quoteStart.selectProducerCode(data.RiskReserve.ProducerCode_2);
    var PcodeDisabled = await quoteStart.isProductCodeNotAvailableWithRiskReservedTag(data.RiskReserve.ProductCode);
    await assert.assertEqual(PcodeDisabled,true,'product code is not risk reserved');
}).meta({Ferrite:"true",Granite:"true"});