import navbar from '../Pages/NavBar';
import AccountsLanding from '../Pages/AccountsLanding';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSummary from '../Pages/AccountSummary';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import Login from '../Login';
const login = new Login();
const agentDashboard = new AgentDashboard();
const policyGen = new PolicyGenerator();
const nav = new navbar();
const accountsLanding=new AccountsLanding();
const accountSummary = new AccountSummary();
fixture`Account Landing Page Test`

test('TC3531: Verify the policies count link on Account landing page', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.goToAccountsLanding();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickPolicyCountLink(policyData.accountNumber);
    await accountsLanding.isAccountSummaryPageLoaded(policyData.accountNumber);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Selector changed
test.skip('TC3525 : Verify user can view Account details page from account landing page', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.policyNum);
    await agentDashboard.goToAccountFromPolicySearch();//account link changed
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3527 : Verify the open activites count link on Account landing page', async t=>{
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.goToAccountsLanding();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickOpenActivitiesLink(policyData.accountNumber);
    await accountsLanding.isOpenActivitiesTileOpened();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
