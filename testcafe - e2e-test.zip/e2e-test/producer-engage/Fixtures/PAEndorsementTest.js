import NavBar from '../Pages/NavBar';
import PolicyLanding from '../Pages/PolicyLanding'
import EndorsementTypeBoxPage from '../Pages/EndorsementTypeBoxPage';
import EndorsementAddressPage from '../Pages/EndorsementAddressPage';
import EndorsementDriversPage from '../Pages/EndorsementDriversPage';
import EndorsementVehiclePage from '../Pages/EndorsementVehiclePage';
import PolicyChangeSummaryPage from '../Pages/PolicyChangeSummaryPage';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import ActivitiesScheduleComponent from '../Pages/ActivitiesScheduleComponent';
import AddNoteComponent from '../Pages/AddNoteComponent';
import PolicyChange from '../Pages/PolicyChange';
import DocumentsTab from '../Pages/DocumentsTab';
import CommonLocators from "../../Utilities/CommonLocators";
import AccountsLanding from '../Pages/AccountsLanding';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSummary from '../Pages/AccountSummary';
const data = require('../Data/PE_PolicyChange_Data.json');

const agent = new AgentDashboard();
const endorsementType = new EndorsementTypeBoxPage();
const endorseAddType = new EndorsementAddressPage();
const endorseDriverType = new EndorsementDriversPage();
const endorseVehicleType = new EndorsementVehiclePage();
const polChangeSmry = new PolicyChangeSummaryPage();
const actPagFac = new ActivityPageFactory();
const addNote = new AddNoteComponent();
const policyChange = new PolicyChange();
const common = new CommonLocators();
const document = new DocumentsTab();
const nav = new NavBar();
const policyLanding = new PolicyLanding();
const accLanding = new AccountsLanding();
const accSummary = new AccountSummary();
const activitiesSchedule = new ActivitiesScheduleComponent();

fixture`PA Endorsement Test`
test('TC3974: Policy Change - PAPolicy', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.isEndorsementWizardDisplayed();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3973: Missing Mandatory Values While Updating Address In Policy Change', async () => {
    var policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await endorseAddType.validateMandatoryErrorMessageInAddressPage();
    await common.validateNextButtonIsDisabled();
    await endorseAddType.setAddressLine1(data.TC3973.AddressLine1);
    await endorseAddType.setCity(data.TC3973.City);
    await endorseAddType.setZip(data.TC3973.Zip);
    await common.validateNextButtonIsEnabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3971 : Missing Mandatory Values While Adding New Driver In PolicyChange', async () => {
    var policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveDriver();
    await common.goNext();
    await endorseDriverType.addNewDriver();
    await common.validateNextButtonIsDisabled();
    await endorseDriverType.setDriverPage(data.DriversData);    
    await endorseDriverType.validateMandatoryErrorMessageInDriverPage();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3972 : Missing Mandatory Values While Adding New Vehicle In PolicyChange', async () => {
    var policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await endorseVehicleType.addVehicle();
    await common.validateNextButtonIsDisabled();
    await endorseVehicleType.setVehiclesPage(data.VehiclesData);
    await endorseVehicleType.validateMandatoryErrorMessageInVehiclePage();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3994: Add Activity On Policy Change Details', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToOpenActivitiesTile();
    await polChangeSmry.clickAddActivityBtn();
    await actPagFac.addDefaultActivity();
    await actPagFac.clickOnFirstActivity();
    await activitiesSchedule.canViewActivitySummary();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3995: Cancel Add Activity On Policy Change Details', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToOpenActivitiesTile();
    await polChangeSmry.clickAddActivityBtn();
    await actPagFac.withActivityTypeByText(data.TC3995.ActivityType);
    await actPagFac.withSubject(data.TC3995.ActivitySubject);
    await actPagFac.clickCancelButton();
    await actPagFac.isAddActivityComponentVisible();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3996: Add Note On Policy Change Details Page', async t => {
    var  policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToNotesTile();
    await addNote.addGeneralNote(data.TC3996.NoteSubject);
    await addNote.isNoteListed(data.TC3996.NoteSubject);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3997: Cancel Add Note On Policy Change Details Page', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToNotesTile();
    await addNote.cancelAddingNote(data.TC3997.NoteSubject);
    await addNote.isNoteNotAdded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3975: Unable To Select Date In Past Effective Date For Policy Change', async () => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setPastEffectiveDate();
    await endorsementType.dateError(policyData.policyEffectiveDate);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3998: Upload Doc On Policy Change Details Page', async t => {
    var filepath = '../../Utilities/FileTypes/';
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToDocumentsTile();
    await document.uploadFile(filepath+data.TC3998.FileName);
    await document.isDocAdded(data.TC3998.FileName);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4003: Delete Doc On Policy Change Details Page', async t => {
    var filepath = '../../Utilities/FileTypes/';
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddressChange();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.goToDocumentsTile();
    await document.uploadFile(filepath+data.TC4003.FileName);
    await document.isDocAdded(data.TC4003.FileName);
    await document.deleteDoc();
    await document.ValidateDocDeleted();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4000: Withdraw Draft Policy Change for PA', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.withdrawPolicyChange();
    await polChangeSmry.validatePolicyChangeStatus('Withdrawn');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4002: Continue Draft Policy Change for PA', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await polChangeSmry.continuePolicyChange();
    await endorsementType.isEndorsementWizardDisplayed();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4006: View Policy Change Detail Page From Dashboard', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    var jobNum = await polChangeSmry.getPolicyChangeJobNumber();
    await nav.goToDashboard();
    await agent.clickOpenPolicyChangesTile();
    await policyLanding.openJob(jobNum);
    await polChangeSmry.isEndorsementPageDisplayed(jobNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4008: View Policy Change Detail Page From Account Details', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveDriver();
    await common.goNext();
    await endorseDriverType.addNewDriver();
    await endorseDriverType.setDriverPage(data.DriversData); 
    await common.pressCancel();
    await common.confirmCancel();
    var jobNum = await polChangeSmry.getPolicyChangeJobNumber();
    await nav.goToDashboard();
    await nav.goToAccountsLanding();
    await accLanding.showRecentlyCreated();
    await accLanding.clickAccountNameLink(policyData.accountNumber);
    await accSummary.goToOpenTransactionsTile();
    await accLanding.openJob(jobNum);
    await polChangeSmry.isEndorsementPageDisplayed(jobNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4026: View Policy Change Detail Page From Policies Open Transactions', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    var jobNum = await polChangeSmry.getPolicyChangeJobNumber();
    await nav.goToDashboard();
    await nav.goToPoliciesLanding();
    await policyLanding.showOpenchanges();
    await policyLanding.openJob(jobNum);
    await polChangeSmry.isEndorsementPageDisplayed(jobNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4005: View Policy Change Detail Page From Policies Open Changes', async t => {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    var jobNum = await polChangeSmry.getPolicyChangeJobNumber();
    await polChangeSmry.clickPolicyLink();
    await policyLanding.openJob(jobNum);
    await polChangeSmry.isEndorsementPageDisplayed(jobNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4009: Remove Driver When Only One Driver Avaliable', async ()=> {
    let policyData = await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveDriver();
    await common.goNext();
    await endorseDriverType.isRemoveButtonDisabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC4025: Remove Vehicle When Only One Vehicle Avaliable', async () => {
    await policyChange.goToPolicyChangePage('PersonalAuto');
    await endorsementType.setEffectiveDate();
    await endorsementType.selectAddEditRemoveVehicle();
    await common.goNext();
    await endorseVehicleType.isRemoveButtonDisabled();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
