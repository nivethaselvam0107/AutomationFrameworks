import AccountSummary from '../Pages/AccountSummary';
const accountSummary = new AccountSummary();

fixture`Account Summary Test`

test('TC348: MissingMandatoryValuesWhileEditingContactInformation', async t=>{
   await accountSummary.verifyMissingMandatoryValuesWhileEditingContactInformation();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC388: InvalidZipCodeWhileEditingContactDetails', async t=>{
    await accountSummary.verifyInvalidZipCodeWhileEditingContactDetails();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC3489: InvalidPhoneNumberWhileEditingContactDetails', async t=>{
    await accountSummary.verifyInvalidPhoneNumberWhileEditingContactDetails();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC3490: InvalidEmailIdWhileEditingContactDetails', async t=>{
    await accountSummary.verifyInvalidEmailIdWhileEditingContactDetails();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC3492: MissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails', async t=>{
    await accountSummary.verifyMissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC3495: ViewPolicyFromAccountSummaryPage', async t=>{
    await accountSummary.verifyViewPolicyFromAccountSummaryPage();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

test('TC3496: ViewPolicyFromAccountDetailsBilling', async t=>{
    await accountSummary.verifyViewPolicyFromAccountDetailsBilling();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});


