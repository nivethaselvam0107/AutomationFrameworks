import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ConfirmationPage from '../Pages/NewClaimConfirmationPage';
import NavBar from '../Pages/NavBar';
import PolicySummary from '../Pages/PolicySummary';
import ClaimsTileView from '../Pages/ClaimsTileView';
import AccountsLanding from '../Pages/AccountsLanding';
import Tiles from '../Pages/Tiles';
import ClaimListPage from '../Pages/ClaimListPage';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSummary from '../Pages/AccountSummary';
const login = new Login();
const policyGen = new PolicyGenerator();
const claim = new ClaimsPageFactory();
const nav = new NavBar();
const policySummary = new PolicySummary();
const claimTile = new ClaimsTileView();
const claimList = new ClaimListPage();
const dataClaim = require('../Data/PE_Claim.json');
const confirm = new ConfirmationPage();
const accountsLanding = new AccountsLanding();
const tiles = new Tiles();
const agent = new AgentDashboard();
const accountSummary = new AccountSummary();

fixture`Claim List Page UI Validation Test`
test.skip('Test Claim List Page View From Account', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createTheftClaim(dataClaim.TC003,dataClaim.Address);
    await confirm.goToDashboard();
    await nav.goToAccountsLanding();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.goToAccountsClaimsTile();
    await claimList.isClaimListPageLoadedOnAccountClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});
test.skip('TC3848:Test Claim List Page View From Policy', async t => {
    let policyData = await policyGen.createBasicBoundIMPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createGeneralClaimForIM(dataClaim.TC3848,policyData.AddressLine1);
    await confirm.goToDashboard();
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimList.isClaimListPageLoadedOnPoliciesClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});
test('TC3859:  View Claim Details From Claims Landing', async t => {
    let policyData = await policyGen.createBasicBoundWCPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.goToClaimsLanding();
    await claimList.isClaimListPageLoadedOnClaims();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

