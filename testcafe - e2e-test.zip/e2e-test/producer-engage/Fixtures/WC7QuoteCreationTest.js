import Login from "../Login";
import NavBar from "../Pages/NavBar";
import QuoteStart from "../Pages/QuoteStart";
import CommonLocators from "../../Utilities/CommonLocators";
import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import PaymentDetailsPage from "../Pages/PaymentDetailsPage";
import AccountSearch from "../Pages/AccountSearch";
import QualificationPage from "../Pages/QualificationPage";
import WCEmployeeAndLocations from "../Pages/WCEmployeeAndLocations";
import WCExperienceModificationFactor from "../Pages/WCExperienceModificationFactor";
import WCCoveragesAndExclusions from "../Pages/WCcoveragesAndExclusions";
import WC7Quote from "../Pages/WC7Quote";
import WC7AdditionalInformation from "../Pages/WC7AdditionalInformation";
import WC7FinalQuote from "../Pages/WC7FinalQuote";
import WCPaymentSuccessful from "../Pages/WC7PaymentSuccessful";
import Assertion from "../../Utilities/Assertions";

const login = new Login();
const paymentDetails = new PaymentDetailsPage();
const assert = new Assertion();
const nav = new NavBar();
const quoteStart = new QuoteStart();
const accountSearch = new AccountSearch();
const policyGen = new PolicyGenerator();
const common = new CommonLocators();
const qualification = new QualificationPage();
const employeeAndLocation = new WCEmployeeAndLocations();
const emod = new WCExperienceModificationFactor();
const coverage = new WCCoveragesAndExclusions();
const quote = new WC7Quote();
const addInfo = new WC7AdditionalInformation();
const finalQuote = new WC7FinalQuote();
const confirmation = new WCPaymentSuccessful();
const data = require("../Data/PE_WC7_Data.json");

fixture`WC7 Policy Creation`;

test("Verify mandatory fields in Qualification page for Workers Compensation v7", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();  
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await qualification.clickAddNameInsured();
    await qualification.validateMandatoryFieldsInAddInsurer();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test("Verify mandatory fields in Employee and Location page - enter information manually for Workers Compensation v7", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote(); 
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.validateMandatoryFieldsInAddEmployeeClass(data.CreateQuote);
}).meta({Ferrite:"true",Granite:"true"});

test("Verify added information manually for Workers Compensation v7 in Employee and Location page", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote(); 
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
}).meta({Ferrite:"true",Granite:"true"});

test("Verify edit employee classes information manually for Workers Compensation v7 in Employee and Location page", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote(); 
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
    await employeeAndLocation.clickEmployeeClassEdit();
    await employeeAndLocation.editEmployeeClasses(data.CreateQuote);
    await employeeAndLocation.validateEditedEmployeeClasses(data.CreateQuote);
}).meta({Ferrite:"true",Granite:"true"});

test("Verify mandatory fields in Experience Modification Factor (EMOD) and State Coverages for Workers Compensation v7", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
    await common.goNext();
    await emod.validateMandatoryFieldExperienceModFactor();
}).meta({Ferrite:"true",Granite:"true"});

test("Verify two EMOD and State Coverages  are displayed in EMOD and State Coverages page when multiple employee classes added in employees and Location page ", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
    await employeeAndLocation.clickAddMore();
    await employeeAndLocation.selectState(data.MultipleEmployeeClasses.State);
    await employeeAndLocation.addEmployeeClassManually(data.MultipleEmployeeClasses);
    await common.goNext();
    await emod.validateMultipleEmodIsDisplayed(data.MultipleEmployeeClasses);
}).meta({Ferrite:"true",Granite:"true"});

test("Verify mandatory fields in Coverages and Exclusions for Workers Compensation v7", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
    await common.goNext();
    await emod.clickUpdate();
    await common.goNext();
    await coverage.validateMandatoryFieldInCoveragesAndExclusions();
}).meta({Ferrite:"true",Granite:"true"});

test("Verify Policy Creation  for Workers Compensation v7", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.searchExistingAccountForPersonal(policyData);
    await accountSearch.clickStartNewQuote();
    await quoteStart.fillQuoteForWC7ExistingAccount(data.StartQuote);
    await quoteStart.clickSubmit();
    await common.goNext();
    await common.validateNextButtonIsDisabled();
    await employeeAndLocation.clickAddEmployeeClasses();
    await employeeAndLocation.addEmployeeClassManually(data.CreateQuote);
    await employeeAndLocation.validateAddedEmployeeClasses(data.CreateQuote);
    await employeeAndLocation.clickAddMore();
    await employeeAndLocation.selectState(data.MultipleEmployeeClasses.State);
    await employeeAndLocation.addEmployeeClassManually(data.MultipleEmployeeClasses);
    await common.goNext();
    await emod.clickUpdate();
    await emod.clickUpdate();
    await common.goNext();
    await coverage.selectStopGap(data.CreateQuote.StopGap);
    await common.goNext();
    await common.goNext();
    await quote.validateSelectedStopGapValue(data.CreateQuote.StopGap);
    await common.goNext();
    await addInfo.setFinalQuote(data.CreateQuote);
    await addInfo.setNCCIIntrastateID(data.CreateQuote.NCCIIntrastateID);
    await t.wait(2000);
    await addInfo.clickFinalQuote();
    await t.wait(2000);
    var quoteValue = await finalQuote.getQuoteValue();
    await common.goNext();
    await paymentDetails.payMonthlyPremiumWithSavingsBankAccount();
    await common.goNext();
    var totalAmount = await confirmation.getPolicyTotalAmount();
    await assert.assertEqual(quoteValue,totalAmount,'Total Amount displayed in confirmation page is incorrect');
}).meta({Ferrite:"true",Granite:"true"});








