import Login from "../Login";
import NavBar from "../Pages/NavBar";
import AccountSearch from "../Pages/AccountSearch";
import AccountCreate from "../Pages/AccountCreate";
import QuoteStart from "../Pages/QuoteStart";
import QualificationPage from "../Pages/QualificationPage";
import PolicyInfoPage from "../Pages/PolicyInfoPage";
import DriversPage from "../Pages/DriversPage";
import VehiclesPage from "../Pages/VehiclesPage";
import CommonLocators from "../../Utilities/CommonLocators";
import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import PAQuotePage from "../Pages/PAQuotePage";
import PaymentDetailsPage from "../Pages/PaymentDetailsPage";
import PolicyConfirmationPage from "../Pages/PolicyConfirmationPage";
import QuoteSummaryPage from "../Pages/QuoteSummaryPage";
import ActivityPageFactory from "../Pages/ActivityPageFactory";
import ActivitiesScheduleComponent from "../Pages/ActivitiesScheduleComponent";
import LeftNavigationMenuHandlerPage from "../Pages/LeftNavigationMenuHandlerPage";
import GPA_QuotePageFactory from "../Pages/GPA_QuotePageFactory";
import QuoteSummary from "../Pages/QuoteSummary";
const data = require("../Data/PE_PA_Data.json");
const dataQnB = require("../Data/QnB_PA_Data.json");

const login = new Login();
const policyInfo = new PolicyInfoPage();
const paymentDetails = new PaymentDetailsPage();
const paQuote = new PAQuotePage();
const nav = new NavBar();
const quoteStart = new QuoteStart();
const accountSearch = new AccountSearch();
const policyGen = new PolicyGenerator();
const accountCreate = new AccountCreate();
const qualiPage = new QualificationPage();
const driversPage = new DriversPage();
const vehicles = new VehiclesPage();
const common = new CommonLocators();
const policyConfirmation = new PolicyConfirmationPage();
const quoteSummary = new QuoteSummaryPage();
const quote = new QuoteSummary();
const activity = new ActivityPageFactory();
const activitySchedule = new ActivitiesScheduleComponent();
const leftNavMenu = new LeftNavigationMenuHandlerPage();
const quotePageFactory = new GPA_QuotePageFactory();


fixture `PA Quote Creation Test`;
test.skip("TC3544 : Create PA Quote For New Personal Account", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3544);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3544);
    await accountCreate.fillEmailAddress(data.TC3544);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3544);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3544);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3544);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3544);
    await common.goNext();
    var quoteID = await paQuote.getSubmissionNumber();
    await paQuote.clickBuyNow();
    await t.wait(3000);
    await policyInfo.setPhoneNumber(data.TC3544.PhoneNumber);
    await common.goNext();
    await policyInfo.setPhoneNumber(data.TC3544.PhoneNumber);
    await common.goNext();
    await paymentDetails.setPaymentMethod(data.TC3544.PaymentMethod);
    await paymentDetails.setCreditCardNumber();
    await paymentDetails.setExpirationDate();
    await paymentDetails.goNext();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.arePolicyDetailsSectionsCollapsedByDefault();
    var fetchData = await policyGen.getQuoteData(quoteID, data.TC3544.Zip);
    await policyConfirmation.policySummaryConfirmation(fetchData);
    await policyConfirmation.getVehiclesTableData(data.TC3544);
    await policyConfirmation.getDriverTableData(data.TC3544);
})
test.skip("TC3545 : Verify user can start a quote of type Personal Auto for exisitng account", async t => {
    var policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.clickStartNewQuote();
    await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
    await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
    await common.goNext();
    var quoteID = await paQuote.getSubmissionNumber();
    await paQuote.clickBuyNow();
    await policyInfo.setPhoneNumber(data.TC3545.PhoneNumber);
    await common.goNext();
    await policyInfo.setPhoneNumber(data.TC3545.PhoneNumber);
    await common.goNext();
    await paymentDetails.setPaymentMethod(dataQnB.paymentDetails.PaymentMethod);
    await paymentDetails.setCreditCardNumber();
    await paymentDetails.setExpirationDate();
    await paymentDetails.goNext();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
    await policyConfirmation.arePolicyDetailsSectionsCollapsedByDefault();
    await policyConfirmation.getVehiclesTableData(dataQnB.vehiclesPage);
    await policyConfirmation.getDriverTableData(dataQnB.driversPage);
})
test("TC3546 : Verify for validation on Driver screen while creating personal auto quote", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.isAccountExists();
    await accountSearch.clickStartNewQuote();
    await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
    await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
    await common.goNext();
    await driversPage.typeDOB(data.TC3546.DriverDOB);
    await driversPage.typeLicenseNumber(data.TC3546.DriverLicenseNum);
    await common.validateNextButtonIsDisabled();
})
test.skip("TC3570 : Verify when the applicant has revoked/suspended license, quote is not generated", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.isAccountExists();//selector to be changed
    await accountSearch.clickStartNewQuote();
    await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
    await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
    await qualiPage.setCurrentLicenseStatusCanceled(data.TC3570.CurrentLicencseStatus);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
    await common.goNext();
    await paQuote.uwIssueValidation(data.TC3570.UWIssueHeader, data.TC3570.UWIssue);
})
test.skip("TC3571 : Verify when the person has been declined a policy or coverage, quote is not generated", async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.isAccountExists();//selector to be changed
    await accountSearch.clickStartNewQuote();
    await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
    await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
    await qualiPage.setPolicyDeclinedStatus(data.TC3571.PolicyDeclinedStatus);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
    await common.goNext();
    await paQuote.uwIssueValidationForPolicyDecline(data.TC3571.UWIssueHeader, data.TC3571.UWIssue);
})
test.skip("TC3556 : Verify when the drivers age is below 25 years, quote is not generated", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3556);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3556);
    await accountCreate.fillEmailAddress(data.TC3556);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3556);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3556);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3556);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3556);
    await common.goNext();
    await paQuote.validationUnderwritingMessage();
    await paQuote.clickReferToUnderwriterAndConfirm();
    await t.wait(4000);
    await quoteSummary.validationUnderwritingIssues(data.TC3556.ShortDescription,data.TC3556.ProgramStatus);
});
test.skip("TC3558 : Verify user can refer the underwriting issues to the underwriter", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3558);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3558);
    await accountCreate.fillEmailAddress(data.TC3558);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3558);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3558);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3558);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3558);
    await common.goNext();
    await paQuote.clickReferToUnderwriterAndConfirm();
    await quoteSummary.validationReferedToUnderwriteForReviewMessage();
});
test.skip("TC3559 : Verify the underwriting issue view on quote detail page.", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3559);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3559);
    await accountCreate.fillEmailAddress(data.TC3559);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3559);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3559);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3559);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3559);
    await common.goNext();
    await paQuote.validationUnderwritingMessage();
    await paQuote.clickReferToUnderwriterAndConfirm();
    await quoteSummary.validationUnderwritingIssuesColumns();
});
test.skip("TC3561 : Verify user can cancel refer to underwriter action.", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3561);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3561);
    await accountCreate.fillEmailAddress(data.TC3561);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3561);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3561);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3561);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3561);
    await common.goNext();
    await paQuote.clickReferToUnderwriterAndCancel();
    await paQuote.validationUnderwritingMessage();
});
test.skip("TC3560 : Verify the activity is created for underwriter when agent refer the UW issues to the underwriter", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3560);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3560);
    await accountCreate.fillEmailAddress(data.TC3560);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3560);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3560);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3560);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3560);
    await common.goNext();
    await paQuote.clickReferToUnderwriterAndConfirm();
    await quote.goToOpenActivities();
    await activity.clickOnAddActivity();
    await activity.addDefaultActivity();
    await activity.clickOnFirstActivity();
    await activitySchedule.canViewActivitySummary();
});
test.skip("TC3564 : Verify the activity is created for underwriter when agent refer the UW issues to the underwriter", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3564);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3564);
    await accountCreate.fillEmailAddress(data.TC3564);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3564);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3564);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3564);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3564);
    await common.goNext();
    await paQuote.clickWithdraw();
    await quoteSummary.validateQuoteWithdrawn();
});

test.skip("TC3576 : User should be able to resolve UW issues by editing quote", async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(data.TC3576);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(data.TC3576);
    await accountCreate.fillEmailAddress(data.TC3576);
    await accountCreate.clickNext();
    await quoteStart.fillQuoteDetails(data.TC3576);
    await quoteStart.clickSubmit();
    await qualiPage.setPAQualificationPageDetails(data.TC3576);
    await common.goNext();
    await driversPage.setPrimaryDriverDetails(data.TC3576);//selector to be changed
    await common.goNext();
    await vehicles.setVehicleDetails(data.TC3576);
    await common.goNext();
    await paQuote.validationUnderwritingMessage();
    await leftNavMenu.goToVehiclesPage();
    await vehicles.typeCost('9999');
    await common.goNext();
    await t.wait(2000);
    await paQuote.clickBuyNow();
    await common.goNext();
    await policyInfo.setPhoneNumber(data.TC3576.PhoneNumber);
    await common.goNext();
    await paymentDetails.setPaymentMethod(data.TC3576.PaymentMethod);
    await paymentDetails.setCreditCardNumber();
    await paymentDetails.setExpirationDate();
    await paymentDetails.goNext();
    await policyConfirmation.isPolicyConfirmationPageDisplayed();
});
