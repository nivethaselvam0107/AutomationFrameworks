import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ConfirmationPage from '../Pages/NewClaimConfirmationPage';
import ClaimsTileView from '../Pages/ClaimsTileView';
import ClaimListPage from '../Pages/ClaimListPage';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import Assertion from '../../Utilities/Assertions';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSummary from '../Pages/AccountSummary';

const assert =new Assertion();
const login = new Login();
const policyGen = new PolicyGenerator();
const claim = new ClaimsPageFactory();
const claimTile = new ClaimsTileView();
const claimList = new ClaimListPage();
const dataClaim = require('../Data/PE_Claim.json');
const confirm = new ConfirmationPage();
const claimSummary = new ClaimSummaryPage();
const agent = new AgentDashboard();
const accountSummary = new AccountSummary();
fixture`Workers Compensation File A Claim Test`

test.skip('TC4550:General Liability Claim Creation', async t => {
    let policyData = await policyGen.createBasicBoundWCPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
    await claim.createWCClaim(dataClaim.TC4550,dataClaim.Address);
    var claimNumber =(await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    var uiValue = await claimSummary.getClaimSummaryDataFromUI('WorkersComp');
    var backEndValue = await claimSummary.getClaimSummaryDataFromBackEnd(claimNumber,'WorkersComp');
    await assert.assertEqual(await claimSummary.isClaimSummaryDataMatchingWithBackEnd(uiValue,backEndValue),true,'Claim Summary Data for Workers Comp policy is not matched with Back End');

}).meta({ Emerald: "true", Ferrite: "true", Granite: "true" });
