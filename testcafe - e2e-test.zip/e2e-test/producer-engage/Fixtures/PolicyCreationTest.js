import Login from "../Login";
import NavBar from "../Pages/NavBar";
import AccountCreate from "../Pages/AccountCreate";
import QuoteStart from "../Pages/QuoteStart";
import QualificationPage from "../Pages/QualificationPage";
import PolicyInfoPage from "../Pages/PolicyInfoPage";
import DriversPage from "../Pages/DriversPage";
import VehiclesPage from "../Pages/VehiclesPage";
import CommonLocators from "../../Utilities/CommonLocators";
import Modal from "../../Utilities/WidgetComponents/Modal";
import PolicyGenerator from "../../Utilities/Generator/PolicyGenerator";
import PAQuotePage from "../Pages/PAQuotePage";
import PaymentDetailsPage from "../Pages/PaymentDetailsPage";
import QuoteSummaryPage from "../Pages/QuoteSummaryPage";
import LeftNavigationMenuHandlerPage from "../Pages/LeftNavigationMenuHandlerPage";
import YourHomePage from "../Pages/YourHomePage";
import ConstructionPage from "../Pages/ConstructionPage";
import DiscountPage from "../Pages/DiscountPage";
import HOQuotePage from "../Pages/HOQuotePage";
import HOPolicyInfoPage from "../Pages/HOPolicyInfoPage";
import HOPaymentDetailsPage from "../Pages/HOPaymentDetailsPage";
import HOPolicyConfirmationPage from "../Pages/HOPolicyConfirmationPage";
import GPA_QuotePageFactory from "../Pages/GPA_QuotePageFactory";
import AccountSearch from "../Pages/AccountSearch";
import AccountsLanding from "../Pages/AccountsLanding";
import AccountSummary from "../Pages/AccountSummary";
import PolicyConfirmationPage from "../Pages/PolicyConfirmationPage";
import AdditionalInformationPage from "../Pages/AdditionalInformationPage";
const data = require("../Data/PE_PA_Data.json");
const dataHO = require("../Data/PE_HO_Data.json");
const dataQnB = require("../Data/QnB_PA_Data.json");
const dataQnBHO = require("../Data/QnB_HO_Data.json");

const login = new Login();
const policyInfo = new PolicyInfoPage();
const paymentDetails = new PaymentDetailsPage();
const quoteSummary = new QuoteSummaryPage();
const leftNavigationMenu = new LeftNavigationMenuHandlerPage();
const paQuote = new PAQuotePage();
const nav = new NavBar();
const modal = new Modal();
const quoteStart = new QuoteStart();
const accountSearch = new AccountSearch();
const accountLanding = new AccountsLanding();
const accountSummary = new AccountSummary();
const policyGen = new PolicyGenerator();
const accountCreate = new AccountCreate();
const qualiPage = new QualificationPage();
const driversPage = new DriversPage();
const vehicles = new VehiclesPage();
const construction = new ConstructionPage();
const common = new CommonLocators();
const discount = new DiscountPage();
const yourHome = new YourHomePage();
const hoQuote = new HOQuotePage();
const hoPolicyInfo = new HOPolicyInfoPage();
const hoPayment = new HOPaymentDetailsPage();
const policyConfirmation = new HOPolicyConfirmationPage();
const addInfo = new AdditionalInformationPage();
const policyConfirmationPA = new PolicyConfirmationPage();
const quotePageFactory = new GPA_QuotePageFactory();
var firstName = data.vehicleValidation.FirstName.toUpperCase();
var lastName = data.vehicleValidation.LastName.toUpperCase();

fixture`Policy Creation`;
test("Mandatory Validation for Vehicles page on Personal Auto", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(data.vehicleValidation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(data.vehicleValidation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(data.vehicleValidation);
  await accountCreate.clickSubmit();
  await qualiPage.validateAccountName(`${firstName}` + " " + `${lastName}`);
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.validateNextButtonIsEnabled();

}).meta({ Emerald: "true", Ferrite: "true", Granite:"true" });

test.skip("Policy Info Validation On Personal Auto Quote On Existing Account", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.goNext();
  await paQuote.clickBuyNow();
  await common.goNext();
  await policyInfo.setPhoneNumberasEmpty();
  await policyInfo.setEmailasEmpty();
  await common.validateNextButtonIsDisabled();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await policyInfo.setEmailAddress(dataQnB.policyInformation.EmailAddress);
  await common.validateNextButtonIsEnabled();
}).meta({Ferrite: "true"});

test.skip("Payment Details Validation On Personal Auto Quote On Existing Account", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.goNext();
  await paQuote.clickBuyNow();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await common.goNext();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await paymentDetails.setAccountNumber(dataQnB.policyInformation.AccountNumber);
  await paymentDetails.setABARoutingNumber(dataQnB.policyInformation.RoutingNumber);
  await paymentDetails.setBankName(dataQnB.policyInformation.BankName);
  await common.validateNextButtonIsEnabled();
  await paymentDetails.setPaymentMethod(dataQnB.paymentDetails.PaymentMethod);
  await common.validateNextButtonIsDisabled();
  await paymentDetails.setCreditCardNumber();
  await paymentDetails.setExpirationDate();
  await common.validateNextButtonIsEnabled();
}).meta({Ferrite: "true"});

test.skip("TC3552: Cancel PA Quote On Drivers Screen", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.continueQuote();
  await leftNavigationMenu.gotoDriverPage();
  await modal.confirm();
  await driversPage.areDriverDetailsSaved(dataQnB.driversPage);
}).meta({Ferrite: "true"});

test.skip("TC3553: Cancel PA Quote On Vehicles Screen", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.continueQuote();
  await vehicles.areVehiclesDetailsSaved(dataQnB.vehiclesPage);
}).meta({Ferrite: "true"});

test.skip("TC3554: CancelPAQuoteOnPolicyInfoScreen", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.goNext();
  await paQuote.clickBuyNow();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await common.goNext();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await policyInfo.setEmailAddress(dataQnB.policyInformation.EmailAddress);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.continueQuote();
  await paQuote.clickBuyNow();
  await common.goNext();
  await policyInfo.isEmailEqualsTo(dataQnB.policyInformation);
}).meta({Ferrite: "true"});

test.skip("TC3555: CancelPAQuoteOnPaymentDetailsScreen", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillPolicyDetailsFormForExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.goNext();
  await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
  await common.goNext();
  await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
  await common.goNext();
  await paQuote.clickBuyNow();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await common.goNext();
  await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
  await policyInfo.setEmailAddress(dataQnB.policyInformation.EmailAddress);
  await common.goNext();
  await paymentDetails.setAccountNumber(
    dataQnB.policyInformation.AccountNumber
  );
  await paymentDetails.setABARoutingNumber(
    dataQnB.policyInformation.RoutingNumber
  );
  await paymentDetails.setBankName(dataQnB.policyInformation.BankName);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.continueQuote();
  await paQuote.clickBuyNow();
  await common.goNext();
  await policyInfo.isEmailEqualsTo(dataQnB.policyInformation);
}).meta({Ferrite: "true" });

test.skip("TC3551: CancelPAQuoteOnQualificationScreen", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForPAExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
  await common.pressCancel();
  await common.confirmCancel();
  await quoteSummary.continueQuote();
  await qualiPage.arePAQualificationAnswersSaved(dataQnB.qualificationPage);
}).meta({Ferrite: "true"});

test.skip("TC5815: Verify user can start a new quote on Account details page", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.goToAccountsLanding();
  await accountLanding.showRecentlyCreated();
  await accountLanding.openFirstAccount();
  await accountSummary.goToOpenQuotes();
  await accountSummary.clickAddQuoteButton();//selector to be changed
  await quoteStart.fillPolicyDetailsFormForExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await quotePageFactory.createAndBuyPolicyPA(dataQnB);
  var policyNumber = await policyConfirmationPA.savePolicyNumber();
  await policyConfirmationPA.goToAccountDetailPage();
  await accountSummary.isPolicyDisplayedOnAccountPage(policyNumber);
}).meta({Ferrite: "true"});

test("TC5818: Verify user can start a quote on Account details page for different existing account by using global New Quote button on nav bar", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.goToAccountsLanding();
  await accountLanding.showRecentlyCreated();
  await accountLanding.clickAccountNameLink(policyData.accountNumber);
  await accountSummary.goToOpenQuotes();
  await quotePageFactory.startQuoteForAnyAccount(policyData);
  await quoteStart.fillPolicyDetailsFormForExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit();
  await quotePageFactory.createAndBuyPolicyPA(dataQnB);
  await policyConfirmationPA.savePolicyNumber();
  await policyConfirmationPA.goToAccountDetailPage();
  await accountSummary.isPolicyDisplayedOnAccountPage(policyData.policyNum);
}).meta({Ferrite: "true"});

test.skip("Test Purchase Of Homeowners Insurance For Existing Account", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillQuoteForHOExistingAccount(dataHO.policyInfoValidationHO);
  await quoteStart.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.goNext();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await addInfo.setAddInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPolicyInfo.setPolicyInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnBHO.HOPaymentDetailsPage);
  await hoPayment.purchasePolicy();
  await policyConfirmation.isPolicyConfirmationPageDisplayed();
}).meta({Ferrite: "true" });

test.skip("TC5821: Verify user can start a new quote on Account details page using global New Quote button on nav bar", async t => {
  var policyData = await policyGen.createBasicBoundPAPolicy();
  await login.loginasDiffUser(policyData.producerCode);
  await nav.goToAccountsLanding();
  await accountLanding.showRecentlyCreated();
  await accountLanding.clickAccountNameLink(policyData.accountNumber);
  await accountSummary.goToOpenQuotes();
  await nav.clickStartNewQuote();
  await accountSearch.searchExistingAccountForPersonal(policyData);
  await accountSearch.isAccountExists();//selector to be changed
  await accountSearch.clickStartNewQuote();
  await quoteStart.fillPolicyDetailsFormForExistingAccount(data.QuoteStart);
  await quoteStart.clickSubmit(); 
  await quotePageFactory.createAndBuyPolicyPA(dataQnB);
  await policyConfirmationPA.savePolicyNumber();
  await policyConfirmationPA.goToAccountDetailPage();
  await accountSummary.isPolicyDisplayedOnAccountPage(policyData.policyNum);

}).meta({Ferrite: "true" });

test("Missing Fields On Qualification Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await common.validateNextButtonIsDisabled();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("Missing Mandatory Values On Your Home Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("Missing Fields On Construction Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("Missing Mandatory Values On Discount Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await common.validateNextButtonIsDisabled();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("Missing Mandatory Values On Policy Info Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.goNext();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await addInfo.setAddInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPolicyInfo.validateMandatoryErrorMsg();
  await common.validateNextButtonIsDisabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("Missing Mandatory Values On Payment Details Screen For HOE", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.goNext();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await addInfo.setAddInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPolicyInfo.setPolicyInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPayment.setPaymentPlan();
  await common.validateNextButtonIsDisabled();
  await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnBHO.HOPaymentDetailsPage);
  await common.validateNextButtonIsEnabled();
}).meta({ Emerald: "true", Ferrite: "true" });

test("TC3614: Validation for Estimated Value Of Home Greater Than 2000000000", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.withHomeEstimationValue(dataQnBHO.TC3614.HomeValue);
  await yourHome.isHomeEstimationFieldMarkedWithMAXValueError("Maximum value is 2000000000");
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3619: Test Cancel HO Quote On Qualification Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.pressCancel();
  await common.confirmCancel();//selector to be changed
  await quoteSummary.continueQuote();
  await leftNavigationMenu.gotoQualificationPage();
  await qualiPage.areHOQualificationAnswersSavedHO();
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3618: Test Cancel HO Quote On Your Home Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.pressCancel();
  await common.confirmCancel();//selector to be changed
  await quoteSummary.continueQuote();
  await leftNavigationMenu.gotoYourHomePage();
  await yourHome.areYourHomePageFieldsValuesAreSaved(dataQnBHO.HomePageHO);
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3620: Test Cancel HO Quote On Construction Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.pressCancel();
  await common.confirmCancel();//selector to be changed
  await quoteSummary.continueQuote();
  await leftNavigationMenu.gotoConstructionPage();
  await construction.areConstructionPageDetailsSavedHO(dataQnBHO.ConstructionPage);
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3621: Test Cancel HO Quote On Discount Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.pressCancel();
  await common.confirmCancel();//selector to be changed
  await quoteSummary.continueQuote();
  await discount.getDiscountPage();
  await discount.areDiscountPageValueSavedHO(dataQnBHO.DiscountPage);
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3622: Test Cancel HO On Policy Information Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.goNext();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await addInfo.setAddInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPolicyInfo.setPolicyInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.pressCancel();
  await common.confirmCancel();// selector to be changed
  await quoteSummary.continueQuote();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await common.goNext();
  await common.goNext();
  await hoPolicyInfo.isEmailSaved(dataQnBHO.HOPolicyInfoPage);
  await hoPolicyInfo.isPhoneSaved(dataQnBHO.HOPolicyInfoPage);
}).meta({ Emerald: "true", Ferrite: "true" });

test.skip("TC3623:Test Cancel HO Payment Details Screen", async t => {
  await login.login();
  await nav.clickStartNewQuote();
  await accountSearch.accountSearchForPersonal(dataHO.AccountCreation);
  await accountSearch.clickContinueAsNewcustomer();
  await accountCreate.fillAccountCreate(dataHO.AccountCreation);
  await accountCreate.clickNext();
  await quoteStart.fillQuoteDetails(dataHO.AccountCreation);
  await accountCreate.clickSubmit();
  await qualiPage.setQualificationPageDetailsHOFerrite();
  await common.goNext();
  await yourHome.setYourHomePageDetails(dataQnBHO.HomePageHO);
  await common.goNext();
  await construction.setConstructionPageDetails(dataQnBHO.ConstructionPage);
  await common.goNext();
  await discount.setDiscountPageDetails(dataQnBHO.DiscountPage);
  await common.goNext();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await addInfo.setAddInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPolicyInfo.setPolicyInfoPageDetails(dataQnBHO.HOPolicyInfoPage);
  await common.goNext();
  await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnBHO.HOPaymentDetailsPage);
  await common.pressCancel();
  await common.confirmCancel();//selector to be changed
  await quoteSummary.continueQuote();
  await hoQuote.buyBasePolicyWithMonthlyPremium();
  await common.goNext();
  await common.goNext();
  await hoPayment.arePaymentFieldsInInitialState(dataQnBHO.HOPaymentDetailsPage);
}).meta({ Emerald: "true", Ferrite: "true" });
