import PolicySummary from '../Pages/PolicySummary';
import BOPPolicyDetailsPage from '../Pages/BOPPolicyDetailsPage';
import PolicyChangeSummaryPage from '../Pages/PolicyChangeSummaryPage';
import BOPLocationsAndBuildings from '../Pages/BOPLocationsAndBuildings';
import BOPAdditionalCoverages from '../Pages/BOPAdditionalCoverages';
import BOPGeneralCoverages from '../Pages/BOPGeneralCoverages';
import PolicyChange from '../Pages/PolicyChange';
import BOPQuote from '../Pages/BOPQuote';
import BOPPaymentDetails from '../Pages/BOPPaymentDetails';
import AccountSummary from '../Pages/AccountSummary';
import BOPTransactionConfirmation from '../Pages/BOPTransactionConfirmationPage';
import Tiles from '../Pages/Tiles';
import CommonLocators from '../../Utilities/CommonLocators';
import LeftNavigationMenuHandlerPage from '../Pages/LeftNavigationMenuHandlerPage';
const data = require('../Data/PE_BOP_Data.json');
const policyChange = new PolicyChange();
const policyDetails = new BOPPolicyDetailsPage();
const policySummary = new PolicySummary();
const tiles = new Tiles();
const policyChangeSummary = new PolicyChangeSummaryPage();
const bopPolicyDetails = new BOPPolicyDetailsPage();
const locAndBuildings = new BOPLocationsAndBuildings();
const addCov = new BOPAdditionalCoverages();
const generalCov = new BOPGeneralCoverages();
const quote = new BOPQuote();
const common = new CommonLocators();
const payment = new BOPPaymentDetails();
const accountSummary = new AccountSummary();
const transConfirmation = new BOPTransactionConfirmation();
const wizard = new LeftNavigationMenuHandlerPage();

fixture`BOP Policy Change Test`
//Dropdown Selector hass to change
test.skip('TC6303,TC6615: Test BOP Policy Change Wizard Entry Policy Details', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await bopPolicyDetails.validatePresenceOfAllFields();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6394: Test BOP Policy Change Cancel On Policy Details Page', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await bopPolicyDetails.selectsmallBusinessType(data.TC6394.smallBusinessType);
    await bopPolicyDetails.selectOrgType(data.TC6394.organizationType);
    await common.goNext();
    await common.pressCancel();
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Draft',policyNum);
    await policyChangeSummary.continuePolicyChange();
    await wizard.goToBOPPolicyDetailsPage();
    await policyChangeSummary.validateBOPPolicyDetailsWithBackend(policyNum, data.TC6394.smallBusinessType, data.TC6394.organizationType);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6395: Test BOP Policy Change Cancel On General Coverages', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.setEmployeeDishonestyCoverageTerms(data.TC6395);
    await common.goNext();
    await common.pressCancel();
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Draft', policyNum);
    await policyChangeSummary.continuePolicyChange();
    await wizard.goToBOPGeneralCoveragePage();
    await generalCov.isEmployeeDishonestySelectedInBackend(policyNum);
    await generalCov.validateEmployeeDishonestyTermsInBackend(policyNum, data.TC6395);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6400: Test BOP Policy Change Cancel On Additional Coverages', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await t.wait(2000);
    await common.goNext();
    await addCov.setGuestPropertyInSafeDepositCoverage(data.TC6400.GuestPropSafeDepositLimit);
    await common.goNext();
    await common.pressCancel();
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Draft', policyNum);
    await policyChangeSummary.continuePolicyChange();
    await wizard.goToBOPAdditionalCoveragePage();
    await addCov.isGuestPropertySafeDepositSelected(policyNum);
    await addCov.validateGuestPropSafeDepositLimitInBackend(policyNum, data.TC6400);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

//Dropdown Selector hass to change
test.skip('TC6401: Test BOP Policy Change Cancel On Buildings And Locations', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await common.goNext();
    await common.goNext();
    await locAndBuildings.clickOnEditBldng();
    await locAndBuildings.enterBuildingDesc(data.TC6401.NewBuildingDescription);
    await locAndBuildings.enterPremiumBasisAmount(data.TC6401.NewBasisAmount);
    await locAndBuildings.enterBuildingLimit(data.TC6401.NewBuildingLimit);
    await locAndBuildings.saveBOPBuilding();
    await common.pressCancel();
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Draft',policyNum);
    await policyChangeSummary.continuePolicyChange();
    await locAndBuildings.isBasisAmountCorrectOnDetails(data.TC6401.NewBasisAmount);
    await locAndBuildings.validateBOPBuildingDetailsInBackend(policyNum, data.TC6401);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6402: Test BOP Policy Change Cancel On BOP Quote Screen', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await common.goNext();
    await addCov.setGuestPropertyInSafeDepositCoverage(data.TC6402.GuestPropSafeDepositLimit);
    await common.goNext();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Quoted', policyNum);
    await policyChangeSummary.continuePolicyChange();
    await quote.isBOPQuotePageLoaded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6404: Test BOP Policy Change Cancel On BOP Payment Screen', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.setEmployeeDishonestyCoverageTerms(data.TC6404);
    await common.goNext();
    await common.goNext();
    await common.goNext();
    await common.goNext();
    await t.wait(2000);
    await common.pressCancel()
    await common.confirmCancel();
    await policyChangeSummary.validatePolicyChangeJobStatus('Quoted',policyNum);
    await policyChangeSummary.continuePolicyChange();
    await quote.isBOPQuotePageLoaded();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

//Dropdown Selector hass to change
test.skip('TC6677: Test BOP Policy Change Click Account On Invalid General Coverages', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.clickOnAccountLinkFromWizard();
    await accountSummary.goToOpenTransactionsTile();
    var jobNumber = await accountSummary.openFirstChangeJob();
    await policyChangeSummary.continuePolicyChange();
    await generalCov.validateEmployeeDishonestyFieldsAreEmpty();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6678: Test BOP Policy Change Click Account On Invalid Addtional Coverages', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext();
    await common.goNext();
    await addCov.clickTerrorCap();
    await addCov.clickOnAccountLinkFromWizard();
    await accountSummary.goToOpenTransactionsTile();
    var jobNumber = await accountSummary.openFirstChangeJob();
    await policyChangeSummary.continuePolicyChange();
    await addCov.validateTerrorSelectedAndEmpty();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6411: Test BOP Policy Change View Policy From Confirmation', async t => {
    var jobNumber = await policyChange.makeBOPChangesAndConfirm(data.TC6411);
    await transConfirmation.clickViewPolicyBtn();
    await tiles.validateTileOpened('SUMMARY');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6947: Test BOP Policy Change View Policy Change Page From Confirmation', async t => {
    var jobNumber = await policyChange.makeBOPChangesAndConfirm(data.TC6947);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangePageWasLoaded(jobNumber);

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6410: Test BOP Policy Change View Policy Billing From Confirmation', async t => {
    var jobNumber = await policyChange.makeBOPChangesAndConfirm(data.TC6410);
    await transConfirmation.clickPolicyBillingPageLink();
    await tiles.validateTileOpened('SUMMARY');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6305,TC6616: Test BOP Policy Change General Coverage Change', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyChange.makeBOPPolicychange(policyNum,data.TC6305);
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound', policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.validateGeneralCoverageChangesOnBOPolicy(policyNum, data.TC6305);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6306,TC6617: Test BOP Policy Change Additional Coverage Change', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyChange.makeBOPPolicychange(policyNum,data.TC6306);
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.validateAddtnlCoverageChangesOnBOPolicy(policyNum, data.TC6306);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

//Dropdown Selector hass to change
test.skip('TC6381,TC6618: Test BOP Policy Change Add Building', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyChange.makeBOPPolicychange(policyNum,data.TC6381);
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.validateBuildingOnPolicy(policyNum, data.TC6381);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6382,TC6620: Test BOP Policy Change Edit Building', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickNext();
    await addCov.clickNext();
    await locAndBuildings.clickOnEditBldng();
    await locAndBuildings.enterBuildingDesc(data.TC6382.NewBuildingDescription);
    await locAndBuildings.saveBOPBuilding();
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForNoChange();
    await quote.clickNext();
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policySummary.isBuildingPresentOnPolicyOnBackend(policyNum, data.TC6382.NewBuildingDescription);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6390: Test BOP Policy Change Spread Payments', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.setEmployeeDishonestyCoverageTerms(data.TC6390);
    await generalCov.clickNext();
    await addCov.setGuestPropertyInSafeDepositCoverage(data.TC6390.GuestPropSafeDepositLimit);
    await addCov.setContractorsCoverage();
    await addCov.clickNext();
    await locAndBuildings.clickAddBuildingIcon();
    await locAndBuildings.setBuildingData(data.TC6390.BOPPropertyClassCode,data.TC6390.BasisAmount);
    await locAndBuildings.enterBuildingDesc(data.TC6390.NewBuildingDescription);
    await locAndBuildings.enterBusinessPersonalPropLimit(data.TC6390.PersonalPropertyLimit);
    await locAndBuildings.enterBuildingLimit(data.TC6390.BuildingLimit);
    await locAndBuildings.clickAddBuildingButton();
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForIncrease(policyNum);
    await quote.clickNext();
    await payment.clickSpreadPayments();
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.validateGeneralCoverageChangesOnBOPolicy(policyNum, data.TC6390);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6388: Test BOP Policy Change Remove General Coverage', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyChange.makeBOPPolicychange(policyNum,data.TC6388);
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policySummary.clickChangePolicyButton();
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.clickNext();
    await addCov.clickNext();
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForDecrease(policyNum);
    await quote.clickNext();
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.isEmployeeDishonestySelectedInBackend(policyNum, false, 'Employee Dishonesty  general coverage is selected');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6389: Test BOP Policy Change Remove Additional Coverage', async t => {
    var policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyChange.makeBOPPolicychange(policyNum,data.TC6389);
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policySummary.clickChangePolicyButton();
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickNext();
    await addCov.clickGuestPropertyInSafeDepositCoverage();
    await addCov.clickNext();
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForNoChange();
    await quote.clickNext();
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.isGuestPropSafeDepositSelectedInBackend(policyNum, false, 'Employee Dishonesty  general coverage is selected');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6383: Test BOP Policy Change Remove Building', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.setEmployeeDishonestyCoverageTerms(data.TC6383);
    await generalCov.clickNext();
    await addCov.setGuestPropertyInSafeDepositCoverage(data.TC6383.GuestPropSafeDepositLimit);
    await addCov.setContractorsCoverage();
    await addCov.clickNext();
    await locAndBuildings.clickAddBuildingIcon();
    await locAndBuildings.setBuildingData(data.TC6383.BOPPropertyClassCode,data.TC6383.BasisAmount);
    await locAndBuildings.enterBuildingDesc(data.TC6383.NewBuildingDescription);
    await locAndBuildings.enterBusinessPersonalPropLimit(data.TC6383.PersonalPropertyLimit);
    await locAndBuildings.enterBuildingLimit(data.TC6383.BuildingLimit);
    await locAndBuildings.clickAddBuildingButton();
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForIncrease(policyNum);
    await quote.clickNext();
    await payment.clickPay();
    await payment.enterAccountNumber(data.TC6383.AccountNumber);
    await payment.enterRoutingNumber(data.TC6383.RoutingNumber);
    await payment.enterBankName(data.TC6383.BankName);
    await payment.clickPayAndFinish();
    await transConfirmation.validateTransactionConfirmationPage(jobNumber,policyNum);
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policySummary.clickChangePolicyButton();
    var jobNumber = await policyDetails.getJobNumber();
    await policyDetails.clickNext();
    await generalCov.clickNext();
    await addCov.clickNext();
    await locAndBuildings.removeBuilding(data.TC6383.NewBuildingDescription);
    await locAndBuildings.clickNext();
    await quote.validateTransactionQuotePageForDecrease(policyNum);
    await quote.clickNext();
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound',policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.isBuildingPresentOnPolicyOnBackend(policyNum,data.TC6383.NewBuildingDescription, false, 'Building Description is present in backend');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//Dropdown Selector hass to change
test.skip('TC6392: Test BOP Policy Change Add Building On New Location', async t => {
    let policyNum = await policyChange.goToBOPPolicyChangePage();//changed
    await common.goNext()
    await generalCov.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCov.setEmployeeDishonestyCoverageTerms(data.TC6392);
    await common.goNext();
    await addCov.setGuestPropertyInSafeDepositCoverage(data.TC6392.GuestPropSafeDepositLimit);
    await addCov.setContractorsCoverage();
    await common.goNext();
    await t.wait(2000);
    await locAndBuildings.addLocationDetails(data.TC6392);
    await locAndBuildings.clickAddLocationButton();
    await t.wait(2000);
    await locAndBuildings.getNewBuildingForm(data.TC6392.AddressLine1+', '+ data.TC6392.City);
    await locAndBuildings.setBuildingData(data.TC6392.BOPPropertyClassCode,data.TC6392.BasisAmount);
    await locAndBuildings.enterBuildingDesc(data.TC6392.NewBuildingDescription);
    await locAndBuildings.enterBusinessPersonalPropLimit(data.TC6392.PersonalPropertyLimit);
    await locAndBuildings.enterBuildingLimit(data.TC6392.BuildingLimit);
    await locAndBuildings.clickAddBuildingButton();
    await locAndBuildings.clickNext();
    await t.wait(3000);
    await quote.clickNext();
    await payment.clickSpreadPayments();
    await transConfirmation.clickViewPolicyChangeBtn();
    await policyChangeSummary.validatePolicyChangeJobStatus('Bound', policyNum);
    await policyChangeSummary.clickPolicyLink();
    await policyChangeSummary.validateNewLocationOnBOPolicy(policyNum,data.TC6392.AddressLine1+', '+ data.TC6392.City,'New Location not present on policy');

}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});



























