import Login from '../Login';
import NavBar from '../Pages/NavBar';
import AccountSearch from '../Pages/AccountSearch';
import AccountCreate from '../Pages/AccountCreate';
import AccountSummary from '../Pages/AccountSummary';
import AlertHandler from '../Pages/AlertHandler';
import QuoteStart from '../Pages/QuoteStart';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
const PAdata = require('../Data/PE_PA_Data.json');
const CAdata = require('../Data/PE_CA_Data.json');

const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const accountCreate = new AccountCreate();
const accountSummary = new AccountSummary();
const quote = new QuoteStart();
const alert = new AlertHandler();
const policyGen = new PolicyGenerator();

fixture`Account Creation Test`
//selector changed
test.skip('TC3515: Test User Can Add Personal Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(PAdata.TC3515);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(PAdata.TC3515);
    await accountCreate.clickNext();
    await quote.isEnteredAddressPresent(PAdata.TC3515);
    await quote.cancel();
    await alert.clickYes();//selector changed for popup
    await accountSummary.titleContains(`${PAdata.TC3515.FirstName}` + " " + `${PAdata.TC3515.LastName}`);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//selector changed
test.skip('TC3516:Test User Can Add Commercial Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForCommercial(CAdata.TC3516);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(CAdata.TC3516);
    await accountCreate.clickNext();
    await quote.isEnteredAddressPresent(CAdata.TC3516);
    await quote.cancel();
    await alert.clickYes();//selector changed for popup
    await accountSummary.titleContains(`${CAdata.TC3516.Company}`);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//selector changed
test.skip('TC3517: Test Validation Messages While Creating Personal Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(PAdata.TC3517);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.clickNext();
    await accountCreate.accountCreationMandatoryErrorPresent();// Validation error message for state and producer code
    await accountCreate.accountCreationMandatoryErrorTextMessage(PAdata.TC3517.ErrorMessage);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//selector changed
test.skip('TC3518: Test Validation Messages While Creating Commercial Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForCommercial(CAdata.TC3518);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.clickNext();
    await accountCreate.accountCreationMandatoryErrorPresent();// Validation error message for state and producer code
    await accountCreate.accountCreationMandatoryErrorTextMessage(CAdata.TC3518.ErrorMessage);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3519 : Test Invalid Zip code Validation Messages While Creating Personal Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(PAdata.TC3519);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(PAdata.TC3519);
    await accountCreate.clickNext();
    await accountCreate.isZipCodeErrorDisplayed(PAdata.TC3519);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3520: Test Invalid Zip code Validation Messages While Creating Commercial Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForCommercial(CAdata.TC3520);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(CAdata.TC3520);
    await accountCreate.clickNext();
    await accountCreate.isZipCodeErrorDisplayed(CAdata.TC3520);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3521 : Test Invalid Email Validation Messages While Creating Personal Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(PAdata.EmailError);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(PAdata.EmailError);
    await accountCreate.typeEmailAddress(PAdata.EmailError);
    await accountCreate.clickNext();
    await accountCreate.isEmailAddressFieldMarkedWithError(PAdata.EmailError);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC3523: Test Invalid Email Validation Messages While Creating Commercial Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForCommercial(CAdata.EmailError);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(CAdata.EmailError);
    await accountCreate.typeEmailAddress(CAdata.EmailError);
    await accountCreate.clickNext();
    await accountCreate.isEmailAddressFieldMarkedWithError(CAdata.EmailError);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});
//selector change
test.skip('TC3522: Test Cancel Creating Personal Account', async t => {
    await login.login();
    await nav.clickStartNewQuote();
    await accountSearch.accountSearchForPersonal(PAdata.TC3522);
    await accountSearch.clickContinueAsNewcustomer();
    await accountCreate.fillAccountCreate(PAdata.TC3522);
    await accountCreate.clickCancel();
    await alert.clickYes();// yes popup
    await nav.isAccountsLandingSelected();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});