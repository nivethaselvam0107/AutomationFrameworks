import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ConfirmationPage from '../Pages/NewClaimConfirmationPage';
import PolicySummary from '../Pages/PolicySummary';
import ClaimsTileView from '../Pages/ClaimsTileView';
import ClaimListPage from '../Pages/ClaimListPage';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSummary from '../Pages/AccountSummary';

const login = new Login();
const policyGen = new PolicyGenerator();
const claim = new ClaimsPageFactory();
const policySummary = new PolicySummary();
const claimTile = new ClaimsTileView();
const claimList = new ClaimListPage();
const data = require('../Data/PE_HO_Data.json');
const confirm = new ConfirmationPage();
const claimSummary = new ClaimSummaryPage();
const agent = new AgentDashboard();
const accountSummary = new AccountSummary();
fixture`Home Owners File A Claim Test`

test('Test Start Claim From Policy', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test.skip('Test Start Claim From Account', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claimTile.clickfileAClaimAccount();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test('TC3771 :Test File Claim For HO Policy From Policy Detail Page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claim.createHOFireClaimFromPolicy(data.TC3771);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isHOPageDisplayedCorrectly();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});


test('TC3772 :Test HO Claim Of Type Burglary from Policy Detail Page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claim.createHOCrimeClaimFromPolicy(data.TC3772);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isHOPageDisplayedCorrectly();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test.skip('TC3773 :Test HO Claim Of Type Water from Account details page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claim.createHOWaterClaimFromAccount(data.TC3773);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimList.filterClaimByTextSearch(claimNumber);
    await claimList.validateContainsClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test.skip('TC3774 :Test HO Claim Of Type Fire from Account Detail Page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claim.createHOFireClaimFromAccount(data.TC3774);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimList.filterClaimByTextSearch(claimNumber);
    await claimList.validateContainsClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test('TC3775 :Test HO Claim Of Type Riot Or Civil Commotion Crime from Policy Details Page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.goToclaimsTile();
    await claim.createHOCrimeClaimFromPolicy(data.TC3775);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isHOPageDisplayedCorrectly();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

test.skip('TC3776 :Test HO Claim Of Type Riot Or Civil Commotion Crime from Account Details Page', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToAccountsClaimsTile();
    await claim.createHOCrimeClaimFromAccount(data.TC3776);
    var claimNumber = (await confirm.getClaimNumber()).trim();
    await confirm.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimList.filterClaimByTextSearch(claimNumber);
    await claimList.validateContainsClaim();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});

