import Login from '../Login';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import ConfirmationPage from '../Pages/NewClaimConfirmationPage';
import NavBar from '../Pages/NavBar';
import PolicySummary from '../Pages/PolicySummary';
import ClaimsTileView from '../Pages/ClaimsTileView';
import AccountsLanding from '../Pages/AccountsLanding';
import Tiles from '../Pages/Tiles';
import ClaimListPage from '../Pages/ClaimListPage';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import AgentDashboard from '../Pages/AgentDashboard';
const login = new Login();
const policyGen = new PolicyGenerator();
const claim = new ClaimsPageFactory();
const policySummary = new PolicySummary();
const claimTile = new ClaimsTileView();
const claimList = new ClaimListPage();
const agent = new AgentDashboard();
const dataClaim = require('../Data/PE_Claim.json');
const confirm = new ConfirmationPage();
const claimSummary = new ClaimSummaryPage();

fixture`General File A Claim Test`

test('Test General BO Claim Creation', async t => {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await policySummary.searchBOPolicyNumber();
    await policySummary.goToclaimsTile();
    await claimTile.fileAClaimPolicy();
    await claim.createGeneralClaimFromPolicy(dataClaim.TC004,policyData.AddressLine1);
    var claimNumber =(await confirm.getClaimNumber()).trim();
    await confirm.goToPolicySummaryPage();
    await policySummary.goToclaimsTile();
    await claimTile.validateClaimListed(claimNumber);
    await claimList.openClaimSummary(claimNumber);
    await claimSummary.isBOPageDisplayedCorrectly();
}).meta({Emerald :"true",Ferrite:"true",Granite:"true"});
