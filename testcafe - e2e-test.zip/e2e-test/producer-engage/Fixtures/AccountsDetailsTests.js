import navbar from '../Pages/NavBar';
import PolicyLanding from '../Pages/PolicyLanding';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import AgentDashboard from '../Pages/AgentDashboard';
import PolicySummary from '../Pages/PolicySummary';
import AccountSummary from '../Pages/AccountSummary';
import BillingTileview from '../Pages/BillingTileView';
import ActivityPageFactory from '../Pages/ActivityPageFactory';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import Login from '../Login';
import Tiles from '../Pages/Tiles';
import ClaimsTileView from '../Pages/ClaimsTileView';
import PAQuotePage from '../Pages/PAQuotePage';
import QuoteSummary from '../Pages/QuoteSummary';
import ClaimsPageFactory from '../Pages/ClaimsPageFactory';
import SelectPolicy from '../Pages/SelectPolicy';
import PaymentDetailsPage from '../Pages/PaymentDetailsPage';
import PolicyConfirmationPage from '../Pages/PolicyConfirmationPage';
import CommonLocators from '../../Utilities/CommonLocators';
import NewClaimConfirmationPage from '../Pages/NewClaimConfirmationPage';
import PolicyCancellation from '../Pages/PolicyCancellation';
import OpentransactionTileView from '../Pages/OpentransactionTileView';
import Assertion from '../../Utilities/Assertions';
import AccountSearch from '../Pages/AccountSearch';
import PE_PageQuoteFactory from '../Pages/PE_PageQuoteFactory';
import LeftNavigationMenuHandlerPage from '../Pages/LeftNavigationMenuHandlerPage';
import AccountsLanding from '../Pages/AccountsLanding';
const QnbData = require('../Data/QnB_PA_Data.json');
const policyconf = new PolicyConfirmationPage();
const login = new Login();
const agentDashboard = new AgentDashboard();
const policyGen = new PolicyGenerator();
const nav = new navbar();
const tiles = new Tiles();
const accountsLanding = new AccountsLanding();
const accountSummary = new AccountSummary();
const activityPageFactory = new ActivityPageFactory();
const billingtile = new BillingTileview();
const claimtileview = new ClaimsTileView();
const quotesummary = new QuoteSummary();
const claimpagefactory = new ClaimsPageFactory();
const selectPolicy = new SelectPolicy();
const paquotepage = new PAQuotePage();
const paymentdetails = new PaymentDetailsPage();
const activitiesLanding = new ActivitiesLanding();
const policysummary = new PolicySummary();
const accountSearch = new AccountSearch();
const common = new CommonLocators();
const claimConfirmation = new NewClaimConfirmationPage();
const policyCancel = new PolicyCancellation();
const quotepagefactory = new PE_PageQuoteFactory();
const wizard = new LeftNavigationMenuHandlerPage();
const data = require("../Data/PE_PA_Data.json");
const dataHO = require("../Data/PE_HO_Data.json");
const dataCP = require("../Data/PE_CP_Data.json");
const dataClaim = require('../Data/PE_Claim.json');
const openTransaction = new OpentransactionTileView();
const assert = new Assertion();


fixture`Accounts Details Test`
//selector changed
test.skip('TC3481 : Verify Open Activities on Account details page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//Account number selector changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await activityPageFactory.validateActivityScheduleUIComponent();
    await nav.goToAccountsLanding();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.goToOpenActivities();
    await tiles.validateTileOpened('OPEN ACTIVITIES');
    var filterValue = await activityPageFactory.validateActivityFilterValues();
    await assert.assertEqual(filterValue, true, 'Filter options are not listed correctly');
    await activityPageFactory.validateActivityScheduleUIComponent();
    await activityPageFactory.validatedActivityRowUIComponent();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

//selector changed
test.skip('TC3482 : Verify Open Quotes on Account details page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//start new quote selector changed
    await quotepagefactory.fillPolicyDetailsFormForExistingAccount(policyData);
    var quoteNum = await quotepagefactory.getToVehicleDetailsPageAndSetData(QnbData);
    await common.goNext();
    await wizard.goToVehiclesPage();
    await nav.goToAccountsLanding();
    await common.confirmCancel();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.goToOpenQuotes();
    await accountSummary.isquotepresented(quoteNum);
    await accountSummary.validateQuoteTileComponents(dataCP.TC3482);
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3486 : Verify Billing information on Account details page.', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.goToAccountsLanding();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.clickBillingAndPaymentTile();
    await billingtile.validateBillingTileUIComponentsGPA(policyData.accountNumber);// all locators changed in the tabel
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC3503: Verify user can view account information from activities', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agentDashboard.searchUsingSearchBox(policyData.accountNumber);
    await accountSummary.isSearchResultsPresent();
    await agentDashboard.goToAccountFromAccountSearch();//account number changed
    await accountSummary.goToOpenActivities();
    await activityPageFactory.clickOnAddActivity();
    await activityPageFactory.addDefaultActivity();
    await nav.goToDashboard();
    await agentDashboard.searchUsingSearchBox(policyData.policyNum);
    await agentDashboard.goToAccountFromPolicySearch();//selector to be changed
    await accountSummary.goToOpenActivities();
    await activitiesLanding.openAccountUsingAccountNumber(policyData.accountNumber);
    await accountSummary.isAccountSummaryPageLoaded(policyData.accountNumber);
    await tiles.validateTileOpened('SUMMARY');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//https://guidewirejira.atlassian.net/browse/DA-6620
test.skip('TC3485 : Verify Claims on Account details page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.goToAccountsLanding();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.fileAClaimPolicy();
    await selectPolicy.selectPolicy();
    await claimpagefactory.createCollisionClaim(dataClaim.TC3831, dataClaim.Address);
    await claimConfirmation.goToAccountSummaryPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.validateClaimTileViewUIElements();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test('TC3483: Verify only personal auto claims can be displayed on Claims page by selecting the right filter', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed 
    await quotepagefactory.fillPolicyDetailsFormForExistingAccount(policyData);
    await quotepagefactory.getToVehicleDetailsPageAndSetData(QnbData);
    await common.goNext();
    await paquotepage.buyQuotedPolicy();
    await policyconf.isPolicyConfirmationPageDisplayed();
    await policyconf.goToAccountDetailPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.clickfileAClaimAccount();
    await claimpagefactory.createCollisionClaimFromAccount(dataClaim.TC3831, dataClaim.Address);
    await claimtileview.Backtoclaims();
    await accountSummary.goToSummaryTile();
    await accountSummary.clickPolicyNumber(policyData.policyNum);
    await policysummary.goToclaimsTile();
    await claimpagefactory.createHOFireClaimFromPolicy(dataHO.TC3774);
    await claimtileview.Backtoclaims();
    await policysummary.clickAccountNumber();
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.filterClaimsByLOB('Personal Auto');
    await claimtileview.validateFilteredLOBClimes('Personal Auto');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//selector changed
test.skip('TC3508: Verify user can view Quote details from Account details page', async t => {
    let policyData = await policyGen.createBasicBoundPAPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed
    await quotepagefactory.fillPolicyDetailsFormForExistingAccount(policyData);
    var quoteNum = await quotepagefactory.createDraftQuote(QnbData);
    await nav.goToAccountsLanding();
    await common.confirmCancel();
    await accountsLanding.showRecentlyCreated();
    await accountsLanding.clickAccountNameLink(policyData.accountNumber);
    await accountSummary.goToOpenQuotes();
    await accountSummary.openQuoteByLink(quoteNum);
    await quotesummary.validateQuotePageComponents();
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});
//Selector changed
test.skip('TC3494: Verify only homeowner claims can be displayed on Claims page by selecting the right filter', async t => {
    let policyData = await policyGen.createBasicBoundHOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await nav.clickStartNewQuote();
    await accountSearch.clickPersonal();
    await accountSearch.typeFirstName(policyData.accountFirstName);
    await accountSearch.typeLastName(policyData.accountLastName);
    await accountSearch.clickSearchButton();
    await accountSearch.useExistingAccountWithAccountNumber();//changed
    await quotepagefactory.fillPolicyDetailsFormForExistingAccount(policyData);
    await quotepagefactory.getToVehicleDetailsPageAndSetData(QnbData);
    await common.goNext();
    await paquotepage.buyQuotedPolicy();
    await policyconf.isPolicyConfirmationPageDisplayed();
    await policyconf.goToAccountDetailPage();
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.clickfileAClaimAccount();
    await claimpagefactory.createCollisionClaimFromAccount(dataClaim.TC3831, dataClaim.Address);
    await claimtileview.Backtoclaims();
    await accountSummary.goToSummaryTile();
    await accountSummary.clickPolicyNumber(policyData.policyNum);
    await policysummary.goToclaimsTile();
    await claimpagefactory.createHOFireClaimFromPolicy(dataHO.TC3774);
    await claimtileview.Backtoclaims();
    await policysummary.clickAccountNumber();
    await accountSummary.goToAccountsClaimsTile();
    await claimtileview.filterClaimsByLOB('Homeowners');
    await claimtileview.validateFilteredLOBClimes('Homeowners');
}).meta({Ferrite:"true",Granite:"true",Emerald:"true"});

