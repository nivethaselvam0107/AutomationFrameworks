import Login from '../Login.js';
import PolicySummary from '../Pages/PolicySummary';
import CommonLocators from '../../Utilities/CommonLocators';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import BOPPolicyDetailsPage from '../Pages/BOPPolicyDetailsPage';
import BOPGeneralCoverages from '../Pages/BOPGeneralCoverages';
import BOPAdditionalCoverages from '../Pages/BOPAdditionalCoverages';
import BOPLocationsAndBuildings from '../Pages/BOPLocationsAndBuildings';
import BOPQuote from '../Pages/BOPQuote';
import BOPPaymentDetails from '../Pages/BOPPaymentDetails';
import AccountSummary from '../Pages/AccountSummary';
import BOPPolicyRenewalSummaryPage from '../Pages/BOPPolicyRenewalSummaryPage';
import AgentDashboard from '../Pages/AgentDashboard.js';
const data = require('../Data/PE_BOP_Data.json');

const login = new Login();
const accountSummary = new AccountSummary();
const policyDetails = new BOPPolicyDetailsPage();
const generalCoverages = new BOPGeneralCoverages();
const additionalCoverages = new BOPAdditionalCoverages();
const locationsAndBuildings = new BOPLocationsAndBuildings();
const quote = new BOPQuote();
const paymentDetails = new BOPPaymentDetails();
const policySummary = new PolicySummary();
const policyGen = new PolicyGenerator();
const renewalPolicySum = new BOPPolicyRenewalSummaryPage();
const agent = new AgentDashboard();
const common = new CommonLocators();

fixture`BOPRenewalTest`
test('TC6700 Test BOP Policy Renewal Details Page When Quoted', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.setGuestPropertyInSafeDepositCoverage(data.TC6402.GuestPropSafeDepositLimit);
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickNext();
    await common.pressCancel();
    await common.confirmCancel();
    await renewalPolicySum.validateMessageOnRenewalDetailPage(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC6700 :Test BOP Policy Renewal Wizard Entry Policy Details', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.validatePresenceOfAllFieldsRenewal();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC7277 :Test BOP Renewal Message On Payment Screen', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.setGuestPropertyInSafeDepositCoverage(data.TC6402.GuestPropSafeDepositLimit);
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickNext();
    await quote.clickNext();
    await paymentDetails.validateMessageOnRenewalPaymentForAgent();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});


test('TC6672 :Test BOP Renewal Go To Account From General Coverages', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await generalCoverages.clickOnCoverageCheckbox('Employee Dishonesty');
    await generalCoverages.clickOnAccountLinkFromWizard();
    await accountSummary.goToOpenTransactionsTile();
    var jobNumber = await accountSummary.openFirstJob();
    await renewalPolicySum.editPolicyRenewal();
    await generalCoverages.validateEmployeeDishonestyFieldsAreEmpty();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC6673 :Test BOP Renewal Go To Account From Additional Coverages', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.clickTerrorCap();
    await additionalCoverages.clickOnAccountLinkFromWizard();
    await accountSummary.goToOpenTransactionsTile();
    var jobNumber = await accountSummary.openFirstJob();
    await renewalPolicySum.editPolicyRenewal();
    await additionalCoverages.validateTerrorSelectedAndEmpty();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC6695 :Test BOP Policy Renewal Details Page When In Draft', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await common.pressCancel();
    await common.confirmCancel();
    await renewalPolicySum.validateMessageOnDraftRenewalDetailPage(policyData.policyNum);
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC6681 :Test BOP Policy Renewal Page Details And Tiles', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await t.wait(2000);
    await common.pressCancel();
    await common.confirmCancel();
    await renewalPolicySum.validateTilesAndHeaderOnPolicyRenewalSummaryPage();
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC7351 :Test BOP Renewal Cancel On Customer Request', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await common.pressCancel();
    await common.confirmCancel();
    await renewalPolicySum.clickWithdrawRenewal();
    await renewalPolicySum.validateMessageOnWithdrawalRenewalDetailPage();
    await renewalPolicySum.validatePolicyRenewalJobStatus('withdrawn');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});

test('TC6694 :Test BOP Renewal Modify Add Coverages', async t=> {
    let policyData = await policyGen.createBasicBoundBOPolicy();
    await login.loginasDiffUser(policyData.producerCode);
    await agent.searchUsingSearchBox(policyData.policyNum);
    await agent.goToPolicyFromPolicySearch();
    await policySummary.clickRenewPolicyButton();
    await policyDetails.clickNext();
    await generalCoverages.clickNext();
    await additionalCoverages.setGuestPropertyInSafeDepositCoverage(data.TC6694.GuestPropSafeDepositLimit);
    await additionalCoverages.clickNext();
    await locationsAndBuildings.clickNext();
    await quote.clickNext();
    await paymentDetails.payAnnualPremiumWithSavingsBankAccount(data.TC6694);
    await paymentDetails.clickReferRenewalToUW();
    await paymentDetails.confirmReferRenewalToUW(data.TC6694.NotesToUW);
    await renewalPolicySum.validatePolicyRenewalJobStatus('Quoted');
}).meta({Emerald:"true",Ferrite:"true",Granite:"true"});


