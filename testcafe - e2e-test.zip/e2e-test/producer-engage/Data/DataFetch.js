global.localStorage = require('localStorage');
global.fetch = require('node-fetch');
import { JsonRPCService } from '../../../common/modules/gw-portals-transport-js';
const btoa = require('btoa');
const data = require('../Data/PE_Data.json');
var username = data.login.apiUser;
var password = data.login.password;
export var content;
export var accountData;
const backendHost = process.env.BACKEND_HOST;

export default class DataFetch {
    async getAgentClaimData(claimNum) {
        const authString = `${username}:${password}`;
        const endpoint = `${backendHost}:8080/cc/service/edge/gatewayclaim/claim`;
        const dataObj = claimNum;
        return JsonRPCService.send(endpoint, 'getClaimDetail', [dataObj], { Authorization: 'Basic' + btoa(authString) });
    }
    async getClaimData(claimNum) {
        const authString = `${username}:${password}`;
        const endpoint = `${backendHost}:8080/cc/service/edge/test-claim/claim`;
        const dataObj = claimNum;
        return JsonRPCService.send(endpoint, 'getClaimDetail', [dataObj], { Authorization: 'Basic' + btoa(authString) });
    }
    async getClaimDetailsDataFromBackEnd(claimNum) {
        var data = await this.getAgentClaimData(claimNum);
        var claimData = [];
        var temp = {};
        temp.vehicle = data.lobs.personalAuto.vehicles[0].make + " " + data.lobs.personalAuto.vehicles[0].model + " " + data.lobs.personalAuto.vehicles[0].year;
        temp.safeToDrive = data.lobs.personalAuto.vehicleIncidents[0].safeToDrive;
        temp.airbagsDeployed = data.lobs.personalAuto.vehicleIncidents[0].airbagsDeployed;
        temp.equipmentFailure = data.lobs.personalAuto.vehicleIncidents[0].equipmentFailure;
        temp.vehicleTowed = data.lobs.personalAuto.vehicleIncidents[0].vehicleTowed;
        temp.rentalRequired = data.lobs.personalAuto.vehicleIncidents[0].rentalRequired;
        temp.collisionPoint = data.lobs.personalAuto.vehicleIncidents[0].collisionPoint;
        return claimData.push(temp);

    }
    async getPolicyChangeData(policyNum) {
        const authString = `${username}:${password}`;
        const endpoint = `${backendHost}:8180/pc/service/edge/test-policychange/policychange`;
        const dataObj = policyNum;
        return JsonRPCService.send(endpoint, 'load', [dataObj], { Authorization: 'Basic' + btoa(authString) });

    }
}
