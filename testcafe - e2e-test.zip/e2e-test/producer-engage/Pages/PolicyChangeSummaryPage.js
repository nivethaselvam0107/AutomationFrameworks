import { Selector ,t,ClientFunction} from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal'
import DataFetch from '../Data/DataFetch';
import Tiles from './Tiles';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
const poligen = new PolicyGenerator();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
const dataFetch = new DataFetch();
const tiles = new Tiles();

export default class PolicyChangeSummaryPage {
    constructor() {
        this.addActivityBtn = Selector("#addActivityButton");
        this.continueChangeBtn = Selector("#continueQuote");
        this.withdrawQuoteBtn = Selector("button[id='withdrawQuote']");
        this.policyChangeHeader = Selector("[class*='FormattedHeaderComponent_gwPageTitle']");
        this.policyLink = Selector("[class*='FormattedHeaderComponent_gwSidePageAssociated']").nth(1);
        this.underWritingMessageTitle = Selector("[class*='UnderwritingComponent_gwWarningContentHeading']");
        this.underWritingMessageLine1 = Selector("[class*='UnderwritingComponent_gwWarningContentInfo']");
        this.underWritingMessageLine2 = Selector("#editJobForAccept");
        this.underWritingMessageLine3 = Selector("#reviewForUnderWritter");
        this.underWritingMessageLine4 = Selector("#wishToContinue");
        this.editPolicyChangeButton = Selector("#raisedEditJob");
        this.referToUnderWriterButton = Selector("#referToUnderwriterButton");
        this.underWritingIssueShortDescription = Selector("[class*='digitalTable Table-module'] tbody td").nth(0);
        this.underWritingIssueLongDescription = Selector("[class*='digitalTable Table-module'] tbody td").nth(1);
        this.openActivitiesTile = Selector("div[class*='TileComponent_gwTileTitle']").nth(1);
        this.notesTile = Selector("div[class*='TileComponent_gwTileTitle']").nth(2);
        this.documentsTile = Selector("div[class*='TileComponent_gwTileTitle']").nth(3);
        this.summaryTile = Selector("div[class*='TileComponent_gwTileTitle']").nth(0);
        this.changeStatus = Selector("[id='summaryStatusdDataId']");
        this.createdDate = Selector("#summaryCreatedDataId");
        this.policyInception = Selector("#summaryPolicyInceptionId");
        this.policyNumber = Selector("#policyInfoLink");
        this.producerOfRecord = Selector("#producerCodeOfRecordOrgId");
        this.producerOfService = Selector("#producerOfServiceId");

    }
    async clickAddActivityBtn() {
        await helper.click(this.addActivityBtn);
    }
    async continuePolicyChange() {
        await helper.click(this.continueChangeBtn);
    }
    async withdrawPolicyChange() {
        await helper.click(this.withdrawQuoteBtn);
        await modal.confirm();
    }

    async isEndorsementPageDisplayed(jobnumber) {
        await assert.textContains(await helper.getTextAtLocator(this.policyChangeHeader), jobnumber, 'Job number does not match');
    }
    async clickPolicyLink() {
        await helper.click(this.policyLink);
    }
    async validatePolicyChangeStatus(expectedStatus) {
        await assert.elementPresent(this.changeStatus,'Change status is not displayed');
        await t.wait(2000);
        await assert.assertEqual(await helper.getTextAtLocator(this.changeStatus), expectedStatus, 'policy Change status is not displayed as expected');
    }
    async validateBOPPolicyDetailsWithBackend(policyNum, businessType, orgType) {
        var changeData = await dataFetch.getPolicyChangeData(policyNum);
        await assert.assertEqual(businessType.toLowerCase(), (changeData.lobData.businessOwners.smallBusinessType).toLowerCase(), 'Small Business Type does not match');
        await assert.assertEqual(orgType.toLowerCase(), (changeData.lobData.businessOwners.accountOrgType).toLowerCase(), 'Organization Type does not  match');
    }
    async validatePolicyChangeJobStatus(status, policyNum) {
        var changeData = await dataFetch.getPolicyChangeData(policyNum);
        await assert.assertEqual(status, changeData.status, 'The status didnot match backend');
    }
    async goToDocumentsTile() {
        await helper.click(this.documentsTile);
    }
    async goToOpenActivitiesTile() {
        await helper.click(this.openActivitiesTile);
    }
    async goToNotesTile(){
        await helper.click(this.notesTile);
    }
    async getPolicyChangeJobNumber() {
        var polChnHeader = await helper.getTextAtLocator(this.policyChangeHeader);
        var jobNumber = polChnHeader.replace(/\D/g, '').trim();
        return jobNumber;
    }
    async validatePolicyChangePageWasLoaded(jobNum) {
        var expected = 'PolicyChange (' + jobNum + ')';
        await assert.textContains(await helper.getTextAtLocator(this.policyChangeHeader), expected, 'Policy Change page was not loaded');
    }
    async validateAddtnlCoverageChangesOnBOPolicy(policyNum, coverageData) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var guestPropSafedepositLimit;
        var lineGenCoveIteration = policyData.coverables;
        var CovCount = lineGenCoveIteration.length;
        for (let i = 0; i < CovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name === 'Businessowners Line') {
                var bopCovCount = element.coverages.length;
                for (let j = 0; j < bopCovCount; j++) {
                    const lineCov = element.coverages[j];
                    if (lineCov.name === 'Guests Property In Safe Deposit') {
                        guestPropSafedepositLimit = lineCov.terms[0].amount;
                    }
                }
            }
            await assert.assertEqual(guestPropSafedepositLimit, coverageData.GuestPropSafeDepositLimit, 'Guest Property Safe Deposit Limit does not match');
        }
    }
    async validateNewLocationOnBOPolicy(policyNum,NewAddressHeader,message){
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var newLocation;
        var newLocationPresent;
        var lineGenCoveIteration = policyData.coverables;
        var locCount = lineGenCoveIteration.length;
        for (let i = 0; i < locCount; i++) {
            const element = lineGenCoveIteration[i];
            if ((element.name).includes(NewAddressHeader)) {
                newLocation = element.name;
            }
            else {
                newLocationPresent = false;
            }
        }
            await assert.textContains(newLocation, NewAddressHeader, message);
    }
    async validateBuildingOnPolicy(policyNum, coverageData) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var businessPersonalPropertyLimit;
        var buildingLimit;
        var lineGenCoveIteration = policyData.coverables;
        var CovCount = lineGenCoveIteration.length;
        for (let i = 0; i < CovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name.split(': ')[1] === 'Building # 2') {
                var bopCovCount = element.coverages.length;
                for (let j = 0; j < bopCovCount; j++) {
                    const lineCov = element.coverages[j];
                    if (lineCov.name === 'Business Personal Property') {
                        businessPersonalPropertyLimit = lineCov.terms[0].amount;
                        await assert.assertEqual(businessPersonalPropertyLimit, coverageData.PersonalPropertyLimit, 'Building Personal Property Limit does not match');
                    }
                    if (lineCov.name === 'Building') {
                        buildingLimit = lineCov.terms[1].amount;
                        await assert.assertEqual(buildingLimit, coverageData.BuildingLimit, 'Building Limit does not match');
                    }
                }
            }
        }
    }
    async validateGeneralCoverageChangesOnBOPolicy(policyNum, coverageData) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var employeeDishonestyLimit;
        var noCoveredEmployees;
        var noCoveredLocations;
        var lineGenCoveIteration = policyData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name === 'Businessowners Line') {
                var bopCovCount = element.coverages.length;
                for (let j = 0; j < bopCovCount; j++) {
                    const lineCov = element.coverages[j];
                    if (lineCov.name === 'Employee Dishonesty') {
                        employeeDishonestyLimit = lineCov.terms[0].amount;
                        noCoveredEmployees = lineCov.terms[1].amount;
                        noCoveredLocations = lineCov.terms[2].amount;
                    }
                }
            }
            await assert.assertEqual(employeeDishonestyLimit, coverageData.EmployeeDishonestyLimit, 'Employee Dishonesty Limit does not match');
            await assert.assertEqual(noCoveredEmployees, coverageData.NumberOfCoveredEmployees, 'Number of covered employees does not match');
            await assert.assertEqual(noCoveredLocations, coverageData.NumberOfCoveredLocations, 'Number of covered locations does not match');
        }
    }
    async isEmployeeDishonestySelectedInBackend(policyNum, selected, message) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var employeeDishonestySelected;
        var lineGenCoveIteration = policyData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name == 'Businessowners Line') {
                var bopCovCount = element.coverages.length;
                for (let j = 0; j < bopCovCount; j++) {
                    const lineCov = element.coverages[j];
                    if (lineCov.name == 'Employee Dishonesty') {
                        employeeDishonestySelected = true;
                    }
                    else {
                        employeeDishonestySelected = false;
                    }
                }
            }
            await assert.assertEqual(employeeDishonestySelected, selected, message);
        }
    }
    async isGuestPropSafeDepositSelectedInBackend(policyNum, selected, message) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var guestPropSafedepositSelected;
        var lineGenCoveIteration = policyData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name == 'Businessowners Line') {
                var bopCovCount = element.coverages.length;
                for (let j = 0; j < bopCovCount; j++) {
                    const lineCov = element.coverages[j];
                    if (lineCov.name == 'Guests Property In Safe Deposit') {
                        guestPropSafedepositSelected = true;
                    }
                    else {
                        guestPropSafedepositSelected = false;
                    }
                }
            }
            await assert.assertEqual(guestPropSafedepositSelected, selected, message);
        }
    }
    async isBuildingPresentOnPolicyOnBackend(policyNum, description, present, message) {
        var policyData = await poligen.getAgentPolicyData(policyNum);
        var buildingDescriptionPresent;
        var lineGenCoveIteration = policyData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if ((element.name).split(": ")[1] == description) {
                buildingDescriptionPresent = true;
            }
            else {
                buildingDescriptionPresent = false;
            }
        }
            await assert.assertEqual(buildingDescriptionPresent, present, message);
       }


async validateHighValueVehicleUnderwritingIssue(dataUW) {
    await assert.assertEqual(await helper.getTextAtLocator(this.underWritingMessageTitle), dataUW.Underwriting_Message_Change_Title, 'Underwriting issue header is incorrect or missing');
    await assert.assertEqual(await helper.getTextAtLocator(this.underWritingMessageLine1), dataUW.Underwriting_Message_Change_Line1, 'Underwriting issue line 1 is incorrect or missing');
    await assert.assertEqual(await helper.getTextAtLocator(this.underWritingMessageLine2), dataUW.Underwriting_Message_Change_Line2, 'Underwriting issue line 2 is incorrect or missing');
    await assert.assertEqual(await helper.getTextAtLocator(this.underWritingMessageLine3), dataUW.Underwriting_Message_Change_Line3, 'Underwriting issue line 3 is incorrect or missing');
    await assert.assertEqual(await helper.getTextAtLocator(this.underWritingMessageLine4), dataUW.Underwriting_Message_Change_Line4, 'Underwriting issue line 4 is incorrect or missing');
    await assert.elementPresent(this.editPolicyChangeButton, 'Edit policy button is missing');
    await assert.elementPresent(this.referToUnderWriterButton, 'Refer to underwriter button is missing');

    var longDescription = 'Vehicle ' + dataUW.VehicleYear + ' ' + dataUW.Make + ' ' + dataUW.Model + ' in ' + dataUW.VehicleState + ' (12345/CA) has a stated value of ' + dataUW.Cost_desc;
    var uwIssues = ClientFunction(() => {
        var items = document.querySelectorAll(this.underWritingIssueShortDescription);
        for (var item of items) {
            assert.textContains(item.textContent, data.SD_HighValueVehicle, 'UW issue is Missing');
        }
    });
    var uwDesc = ClientFunction(() => {
        var items = document.querySelectorAll(this.underWritingIssueLongDescription);
        for (var item of items) {
            assert.textContains(item.textContent, longDescription, 'UW Description  is Missing');
        }
    });


}

async validateTilesOnPolicyChangeSummaryPage() {
    await assert.elementPresent(this.openActivitiesTile, 'No Open Activities tile was found');
    await assert.elementPresent(this.notesTile, 'No Notes tile was found');
    await assert.elementPresent(this.documentsTile, 'No Documents tile was found');
    await assert.elementPresent(this.summaryTile, 'No Summary tile was found');
}

async validatePolicyChangeSummaryPageComponents() {
    await assert.elementPresent(this.createdDate, 'No created date was found');
    await assert.elementPresent(this.changeStatus,'Status was not found');
    await assert.elementPresent(this.policyInception, 'No policy Inception was found');
    await assert.elementPresent(this.policyNumber, 'No Policy number was found');
    await assert.elementPresent(this.producerOfRecord, 'No Producer of record was found');
    await assert.elementPresent(this.producerOfService, 'No producer of service was found');
}

async validateWithdrawPolicyChangeButton() {
    await assert.elementPresent(this.withdrawQuoteBtn, 'Withdraw change button is missing');
}
async validateContinuePolicyChangeButton() {
    await assert.elementPresent(this.continueChangeBtn, 'Continue Policy Change Button is missing');
}

}
