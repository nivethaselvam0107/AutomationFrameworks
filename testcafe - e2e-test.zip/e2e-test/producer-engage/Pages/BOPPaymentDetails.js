import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const modal = new Modal();
const renewalPaymentAgentMsgLine1 = "You do not have permission to issue this renewal"; 
const renewalPaymentAgentMsgLine2 = "If you would like this renewal to be issued, please refer it to an underwriter for their consideration.";

export default class BOPPaymentDetails {
    constructor() {

        this.spreadPaymentsButton= Selector("#existingPlanButton");
        this.paymentMethod = Selector("#paymentOptions");
        this.paymentMethodOption = Selector("[id='paymentOptions']").find("div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.SavingsAccountType = Selector("[data-value='savings']");
        this.accountNumber = Selector("input[id='accountNumber']");
        this.routingNumber = Selector("input[id='abaNumber']");
        this.bankName = Selector("input[id='bankName']");
        this.cardIsser = Selector("#creditCardIssuer");
        this.cardIssuerOption = Selector("[id='creditCardIssuer']").find("div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.cardNumber = Selector("#creditCardNumber");
        this.expMonth = Selector("#expirationMonth");
        this.expMonthOption = Selector("[id='expirationMonth']").find("div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.expYear = Selector("#expirationYear");
        this.expYearOption = Selector("[id='expirationYear']").find("div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.cancelButton = Selector("#cancel");
        this.payInFullButton = Selector("#payButton");
        this.payAndFinishButton = Selector("#payNow");

        this.accNumErrMsg = Selector("[id*='accountNumber'][role='alert']");
        this.routingNumErrMsg = Selector("[id*='abaNumber'][role='alert']");
        this.bankNameErrMsg = Selector("[id*='bankName'][role='alert']");
        this.cardNumErrMsg = Selector("[id*='creditCardNumber'][role='alert']");

        this.renewalReferToUW = Selector("#rejectReferToUnderwriterButton");
        this.renewalPaymentAgentMsgLine1 = Selector("h3[id='proceedOffering']");
        this.renewalPaymentAgentMsgLine2 = Selector("p[id='proceedOffering']");
        this.uwNotesTextArea = Selector("#uwNoteForUnderwriter");
        this.confirmReferToUWButton = Selector("#uwReferUnderwriterButtonsConfirm");
    }
 
    async selectPaymentMethod(option){
        await helper.selectDropdown(this.paymentMethod,this.paymentMethodOption, option);
    }
    async clickPay(){
        await helper.click(this.payInFullButton);
    }
    async enterAccountNumber(data){
        await helper.typeText(this.accountNumber, data);
    }
    async enterRoutingNumber(data){
        await helper.typeText(this.routingNumber, data);
    }
    async enterBankName(data){
        await helper.typeText(this.bankName, data);
    }
    async selectCardIssuer(option){
        await helper.selectDropdown(this.cardIsser,this.cardIssuerOption,option);
    }
    async enterCardNumber(data){
        await helper.typeText(this.cardNumber, data);
    }
    async selectExpMonth(option){
        await helper.selectDropdown(this.expMonth,this.expMonthOption, option);
    }
    async selectExpYear(option){
        await helper.selectDropdown(this.expYear,this.expYearOption, option);
    }
    async clickSpreadPayments(){
        await helper.click(this.spreadPaymentsButton);
    }
    async verifyCancelPrevious() {
        await commonLocators.verifyCancel();
        await commonLocators.verifyPrevious();
    }
    async pressCancelAndConfirm() {
        await helper.click(this.cancelButton);
        await modal.confirm();
    }
    async clickPayAndFinish(){
        await helper.click(this.payAndFinishButton);
    }
    async clickNext() {
        await commonLocators.goNext();
    }
    async clickReferRenewalToUW(){
        await helper.click(this.renewalReferToUW);
    }
    async confirmReferRenewalToUW(notes){
        await helper.typeText(this.uwNotesTextArea,notes);
        await helper.click(this.confirmReferToUWButton);
    }
    async setpaymentDetailsBank(data){
        await this.enterAccountNumber(data.AccountNumber);
        await this.enterRoutingNumber(data.ABANumber);
        await this.enterBankName(data.BankName);
    }
    async isPaymentInformationPageSaved(data){
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.accountNumber),'','Account Number is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.routingNumber),'','Routing Number is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.bankName),'','Bank Name is not saved');
    
    }
    async setpaymentDetailsCredit(data){
        await this.selectPaymentMethod(data.CardPayment);
        await this.selectCardIssuer(data.CardIssuer);
        await this.enterCardNumber(data.CardNumber);
        await this.selectExpMonth(data.ExpMonth);
        await this.selectExpYear(data.ExpYear);
    }
    async payAnnualPremiumWithSavingsBankAccount(data){
        await helper.click(this.SavingsAccountType);
        await this.enterAccountNumber(data.AccountNumber);
        await this.enterRoutingNumber(data.ABANumber);
        await this.enterBankName(data.BankName);
    }
    async validatePaymentBankMandatoryFields(){
        await this.clickNext();
        await assert.elementPresent(this.accNumErrMsg, "Error message is not displayed for Account Number field");
        await assert.elementPresent(this.routingNumErrMsg, "Error message is not displayed for ABA Number field");
        await assert.elementPresent(this.bankNameErrMsg, "Error message is not displayed for Bank Name field");
    }  
    async validatePaymentCardMandatoryFields(){
        await this.selectPaymentMethod(data.CardPayment);
        await this.clickNext();
        await assert.elementPresent(this.cardNumErrMsg, "Error message is not displayed for Card Number field");
    } 
    async validateMessageOnRenewalPaymentForAgent(){
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalPaymentAgentMsgLine1),renewalPaymentAgentMsgLine1,'The first line of the renewal payment agent message does not  match');
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalPaymentAgentMsgLine2),renewalPaymentAgentMsgLine2,'The Second line of the renewal payment agent message does not  match');

    } 
}