import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";
import CommonLocators from "../../Utilities/CommonLocators";

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
export default class NewClaimContactDetails {
    constructor() {
        this.contactPerson = Selector("div[id='fnolContactField']");
        this.contactPersonOption = Selector("div[id='fnolContactField'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.firstName = Selector("input[id='firstNameField']");
        this.lastName = Selector("input[id='lastNameField']");
        this.addressLine1 = Selector("input[id='addressLine1Field']");
        this.addressLine2 = Selector("input[id='addressLine2Field']");
        this.addressLine3 = Selector("input[id='addressLine3Field']");
        this.city = Selector("input[id='newContactCityField']");
        this.zipCode = Selector("input[id='newContactZipCodeField']");
        this.primaryPhoneSelect = Selector("#primaryPhoneField");
        this.primaryPhoneOption = Selector("[id='primaryPhoneField'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.state = Selector("div[id='newContactStateField']");
        this.stateOption = Selector("div[id='newContactStateField'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.homeNumber = Selector("input[id='homeNumberField']");
        this.emailId = Selector("input[id='emailField']");
        this.workNumber = Selector("input[id='workNumberField']");
        this.cellPhone = Selector("input[id='mobileNumberField']");
        this.emailIdReqErr = Selector("div[id*='emailField'][class*='error']");
    }
    async addNewContact() {
        await helper.selectDropdown(this.contactPerson,this.contactPersonOption, 'Other Person');
    }
    async setNewContactPersonDetails(contactDetails) {
        await helper.typeText(this.firstName, contactDetails.FirstNameNewContact);
        await helper.typeText(this.lastName, contactDetails.LastNameNewContact);
        await helper.typeText(this.addressLine1, contactDetails.AddLine1NewContact);
        await helper.typeText(this.addressLine2, contactDetails.AddLine2NewContact);
        await helper.typeText(this.addressLine3, contactDetails.AddLine3NewContact);
        await helper.typeText(this.city, contactDetails.CityNewContact);
        await helper.typeText(this.zipCode, contactDetails.ZipNewContact)
        await helper.selectDropdown(this.state,this.stateOption, contactDetails.StateNewContact);
    }
    async withNewContactPerson(contactDetails) {
        await this.addNewContact();
        await this.setNewContactPersonDetails(contactDetails);
    }
    async selectContactPerson(firstName, lastName) {
        var contactPersonValue = firstName+' '+lastName;
        await helper.selectDropdown(this.contactPerson,this.contactPersonOption, contactPersonValue);
    }
    async setContactPersonDetails(city, state) {
        await helper.typeText(this.city, city);
        await helper.selectDropdown(this.state,this.stateOption, state);
    }
    async withContactCellNum(phoneNum) {
        await helper.selectDropdown(this.primaryPhoneSelect,this.primaryPhoneOption,'Mobile');
        await helper.removeText(this.cellPhone);
        await helper.typeText(this.cellPhone, phoneNum);
    }
    async withContactWorkNum(workNum) {
        await helper.typeText(this.workNumber, workNum);
    }
    async withContactEmail(emailId) {
        await helper.typeText(this.emailId, emailId);
    }
      async withContactHomeNum(contactDetails) {
        await helper.typeText(this.homeNumber, contactDetails.HomePhoneNewContact);
        await helper.typeText(this. emailId, contactDetails.EmailNewContact);
    }
    async validateEmailFieldOnSummaryPage() {
        await this.withContactEmail('test');
        await common.goNext();
        await this.validateEmailFieldErrorMessage();
    }

    async areContactPersonDetailsAreSaved(contactDetails) {
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.contactPerson), contactDetails.FirstNameNewContact + " " + contactDetails.LastNameNewContact, 'New contact person is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.firstName),contactDetails.FirstNameNewContact,'New contact first name is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.lastName), contactDetails.LastNameNewContact, 'New Contact Last Name is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine1),contactDetails.AddLine1NewContact, 'New Contact Address line 1 is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine2),contactDetails.AddLine2NewContact, 'New Contact Address line 2 is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine3),contactDetails.AddLine3NewContact, 'New Contact Address line 3 is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.city),contactDetails.CityNewContact,'New Contact City is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.state),contactDetails.StateNewContact,'New Contact State is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.zipCode),contactDetails.ZipNewContact,'New Contact Postal Code is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.workNumber),contactDetails.WorkNewContact,'New Contact work number is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.cellPhone),contactDetails.CellPhoneNewContact,'New contact Cell phone number is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.homeNumber),contactDetails.HomePhoneNewContact,'New Contact Home number is not saved');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this. emailId),contactDetails.EmailNewContact,'New contact  emailId ID is not saved');
    }
    async validateEmailFieldErrorMessage() {
        await assert.assertEqual(await helper.getTextAtLocator(this.emailIdReqErr), 'Value must be a valid email address', 'Invalid error message for  emailId ID is incorrect');
    }
    async goToSummary(){
        await common.goNext();
    }

}
