import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();

export default class BOPPolicyInfo {
    constructor() {
        this.email = Selector("input[id='email']");
        this.phone = Selector("input[id='phone']");
    
    }
    async clickNext() {
        await commonLocators.goNext();
    }
    async setPolicyInfoPage(data){
        await helper.typeText(this.email,data.Email);
        await helper.typeText(this.phone,data.Phone);
    } 
    async removeEmailAndPhone(){
        await helper.removeText(this.email);
        await helper.removeText(this.phone);
    }  
    async isPolicyInfoPageSaved(data){
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.email),data.Email,'Email is not saved');
        await assert.assertEqual((await helper.getValueAttributeFromLocator(this.phone)).replace(/-/g, ''),data.Phone,'Phone Number is not saved');

    } 
}