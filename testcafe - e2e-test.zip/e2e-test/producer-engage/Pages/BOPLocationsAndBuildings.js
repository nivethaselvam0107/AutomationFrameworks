import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
import DataFetch from '../Data/DataFetch';

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
const modal = new Modal();
const dataFetch = new DataFetch();

export default class BOPLocationsAndBuildings {
    constructor() {
        this.addLocationIcon = Selector("button[id='addLocation']");
        this.addLocation = Selector("button[id='locationAddButton']");
        this.locationBackButton = Selector("button[id='locationBackButton']");
        this.addBuildingIcon = Selector("button[id*='addBuildingButton']");
        this.addBuilding = Selector("button[id='addBuilding']");
        this.backButton = Selector("button[id='back']");
        this.editAddedBuildingIcon = Selector("button[id*='editBuilding']");

        this.cancelButton = Selector("[id='gw-wizard-cancel']");
        this.addressDisplay = Selector("[class*='address-display']");
        this.buildingCount = Selector("[class*='building-count']");
        this.propertyClassCode = Selector("[id='propertyClassCode']");
        this.clearPropClassCode = Selector("[id='propertyClassCode'] svg");
        this.premiumBasisAmount = Selector("input[id='premiumBasicAmount']");
        this.buildingDesc = Selector("input[id='buildingDescription']");
        this.yearBuilt = Selector("input[id='yearBuilt']");
        this.constructionType = Selector("div[id='constructionType']");
        this.constructionTypeOption = Selector("div[id='constructionType'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.numberOfStories = Selector("input[id='numberOfStories']");
        this.totalArea = Selector("input[id='totalAreaExcludingBasement']");
        this.percentSprinklered = Selector("div[id='percentageSprinklered']");
        this.percentSprinkleredOption =Selector("div[id='percentageSprinklered'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.exposure = Selector("input[id='exposure']");
   
        this.buildingHeaderDesc = Selector("[class*='BuildingHeaderComponent_buildingDetails']");
        this.locationHeader = Selector("[class*='LocationHeaderComponent_locationNameContainer']");
        this.businessPersonalPropLimit = Selector("input[id='ClauseTerm_[BOPPersonalPropCov]_[0]']");
        this.buildingLimit = Selector("input[id='ClauseTerm_[BOPBuildingCov]_[1]']");
        this.addressLine1 = Selector("input[id='addressLine1']");
        this.addressLine2 = Selector("input[id='addressLine2']");
        this.addressLine3 = Selector("input[id='addressLine3']");
        this.city = Selector("input[id='city']");
        this.zipCode = Selector("input[id='zipCode']");
        this.state = Selector("div[id='state']");
        this.stateOption = Selector("div[id='state'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.locationCode = Selector("input[id='locationCode']");
        this.phoneNumber = Selector("input[id='phoneNumber']");
        this.fireProtection = Selector("div[id='fireProtection']");
        this.fireProtectionOption = Selector("div[id='fireProtection'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        
        this.verifyBuildingAdded = Selector("[class*='BuildingHeaderComponent_buildingDetails'] [class*='fa fa-building']");
        this.verifyLocationAdded = Selector("[class*='LocationHeaderComponent_locationNameContainer'] [class*='fa fa-map-marker']").nth(1);
        
        this.deleteAddedBuildingIcon = Selector("button[id*='removeBuilding']");
        this.deleteAddedLocationIcon = Selector("[id*='locationAccordionCard'] [class*='fa-trash']");
        this.deleteButton = Selector("[class*='modalFooter'] button").nth(1);

        this.addBuildingMessage = Selector("[id='infoBoxText']");
        this.buildingCoveragesTab = Selector("button[id*='coveragesTab']");
        this.buildingAddCoveragesTab = Selector("button[id*='additionCoveragesTab']");
        this.busPersonalPropLimitValue = Selector("[id='ClauseTerm_[BOPPersonalPropCov]_[0]']");
        this.buildLimitValue = Selector("[id='ClauseTerm_[BOPBuildingCov]_[1]']");
        this.additionalCovSection = Selector("[id*='buildingAccordionCard'] [class*='AccordionToggle']");
        this.earthquakeSprinklerLeakage = Selector("input[id*='BOPEqSpBldgCov']").parent(0).find('span');
        this.addCovTenantsLiability = Selector("#BOPTenantsLiabilityCov");
        this.addCovTenantsLiabLimit = Selector("#BOPTenantsLiabLim");
        this.addCovSecTenLiabLimVal = Selector("[coverages*='additionalCoverages'] [class*='termAmount']");
        this.buildDetailsPropClassCode = Selector("div[id*='propertyClassCode']").nth(0);
        this.buildDetailsPremBasisAmt = Selector("div[id*='premiumBasisAmount']").nth(0);
        this.buildDetailsYearBuild = Selector("div[id*='yearBuilt']").nth(0);
        this.buildDetailsNumberOfStories = Selector("div[id*='numberOfStories']").nth(0);
        this.buildDetailsExposure = Selector("div[id*='exposure']").nth(0);
        this.buildDetailsConstructionType = Selector("div[id*='constructionType']").nth(0);
        this.buildDetailstotalArea = Selector("div[id*='totalArea']").nth(0);
        this.buildDetailsPercentageSprinkled = Selector("div[id*='percentageSprinklered']").nth(0);
        this.buildDetailsAddCoverageValue = Selector("div[id*='additionCoveragesTab'] span");
        this.buildDetailsAddCoverageNoValue = Selector("div[id*='additionCoveragesTab'] h4");
        this.buildingTabSelect = Selector("[class*='digitalAccordionToggle']");
    }
    async verifyLocationsAndBuildingsPage() {
        await assert.elementPresent(this.addressDisplay, "Locations and Buildings page is not displayed");
    }
    async clickAddBuildingIcon() {
        await helper.click(this.addBuildingIcon);
    }
    async setBuildingData(classCode, basisAmount) {
        await this.enterPropertyClassCode(classCode);
        await helper.pressTab();
        await this.enterPremiumBasisAmount(basisAmount);
        await helper.pressTab();
    }
    async enterPropertyClassCode(option) {
        await helper.typeText(this.propertyClassCode, option);
        await helper.pressTab();
    }
    async verifyInvalidPropClassCodeDropDownOption() {
        await assert.elementNotPresent(this.propClassCodeOption, 'Results are displayed for the entered Invalid Prop Class Code');
    }
    async verifyPropClassCodeTenDropDownOptions() {
        await assert.elementNotPresent(this.propClassCodeTenResults, 'Results are displayed for the entered Invalid Prop Class Code');
    }
    async removePropClassCode() {
        await helper.click(this.clearPropClassCode);
    }
    async enterPremiumBasisAmount(option) {
        await helper.typeText(this.premiumBasisAmount, option);
    }
    async enterBuildingDesc(option) {
        await helper.typeText(this.buildingDesc, option);
    }
    async enterYearBuilt(option) {
        await helper.typeText(this.yearBuilt, option);
    }
    async selectConstructionType(option) {
        await helper.selectDropdown(this.constructionType,this.constructionTypeOption, option);
    }
    async enterNoOfStories(option) {
        await helper.typeText(this.numberOfStories, option);
    }
    async enterTotalArea(option) {
        await helper.typeText(this.totalArea, option);
    }
    async selectPercentSprinklered(option) {
        await helper.selectDropdown(this.percentSprinklered,this.percentSprinkleredOption,option);
    }
    async enterExposure(option) {
        await helper.typeText(this.exposure, option)
    }
    async enterBusinessPersonalPropLimit(option) {
        await helper.typeText(this.businessPersonalPropLimit, option)
    }
    async enterBuildingLimit(option) {
        await helper.typeText(this.buildingLimit, option);
        await helper.pressTab();
        await t.wait(2000);
    }
    async removeBuilding(buildingDescription){
        var buildingHeaderCount = await this.buildingHeaderDesc.count;
        for (let i = 0; i < buildingHeaderCount; i++) {
            var element = this.buildingHeaderDesc.nth(i);
            if(await helper.getTextAtLocator(element)===buildingDescription){
                    await helper.click(element);
                    await helper.click(element.parent(0).find("[id*='removeBuilding']"));
                    await modal.confirm();
            }    
        }
    }
    async enterAdditionalCoverages(data) {
        await helper.click(this.additionalCovSection);
        await helper.click(this.addCovTenantsLiability);
        await helper.typeText(this.addCovTenantsLiabLimit, data.TenantsLiabilityLimit);
    }
    async clickOnEditBldng() {
        await helper.click(this.editAddedBuildingIcon);
    }
    async clickCancelButton() {
        await helper.click(this.backButton);
    }
    async clickAddBuildingButton() {
        await helper.click(this.addBuilding);
    }
    async clickAddLocationIcon() {
        await helper.click(this.addLocationIcon);
    }
    async clickLocationBack(){
        await helper.click(this.locationBackButton);
    }
    async enterAddressLine1(option) {
        await helper.typeText(this.addressLine1, option);
    }
    async enterCity(option) {
        await helper.typeText(this.city, option);
    }
    async enterZIPCode(option) {
        await helper.typeText(this.zipCode, option);
    }
    async selectState(option) {
        await helper.selectDropdown(this.state,this.stateOption, option);
    }
    async clickAddLocationButton() {
        await helper.click(this.addLocation);
    }
    async clickBuildingCoveragesTab() {
        await helper.click(this.buildingCoveragesTab);
    }
    async clickBuildingAddCovTab() {
        await helper.click(this.buildingAddCoveragesTab);
    }
    async saveBOPBuilding() {
        await helper.click(this.addBuilding);
    }
    async clickNext() {
        await common.goNext();
    }
    async addBuildingDetails(data) {
        await this.clickAddBuildingIcon();
        await this.enterPropertyClassCode(data.PropClassCode);
        await this.enterPremiumBasisAmount(data.PremiumBasisAmount);
        await this.enterBuildingDesc(data.BuildingDesc);
        await this.enterYearBuilt(data.YearBuilt);
        await this.selectConstructionType(data.ConstructionType);
        await this.enterNoOfStories(data.NoOfStories);
        await this.enterTotalArea(data.TotalArea);
        await this.selectPercentSprinklered(data.PercentSprinklered);
        await this.enterExposure(data.Exposure);
        await this.enterBusinessPersonalPropLimit(data.BusinessPersonalPropLimit);
        await this.enterBuildingLimit(data.BuildingLimit);
    }
    async verifyAddBuildingButtonDisabled(){
        await assert.isElementNotClickable(this.addBuilding,'disabled','Add Building button is enabled');
    }
    async verifyAddBuildingButtonEnabled(){
        await assert.isElementClickable(this.addBuilding,'disabled','Add Building button is enabled');
    }
    async verifyAddLocationButtonDisabled(){
        await assert.isElementNotClickable(this.addLocation,'disabled','Add Location button is enabled');
    }
    async verifyAddLocationButtonEnabled(){
        await assert.isElementClickable(this.addLocation,'disabled','Add Location button is enabled');
    }
    async verifyAddedBuilding() {
        await assert.elementPresent(this.verifyBuildingAdded, "Added Building is not displayed");
    }
    async verifyBuildingNotAdded() {
        await assert.elementNotPresent(this.verifyBuildingAdded, "Building is displayed");
    }
    async deleteAddedBuilding() {
        await helper.click(this.deleteAddedBuildingIcon);
        await helper.click(this.deleteButton);
        await assert.elementNotPresent(this.verifyBuildingAdded, "Added Building is not deleted");
    }
    async editAddedBuilding(data) {
        await helper.click(this.editAddedBuildingIcon);
        await this.enterPremiumBasisAmount(data.PremimumBasisAmountEdited);
        await this.enterBuildingLimit(data.BuildingLimitEdit);
        await helper.pressTab();
        await t.wait(2000);
        await helper.click(this.additionalCovSection);
        await helper.click(this.earthquakeSprinklerLeakage);
    }
    async clickEarthQuakeSprinklerLeakage(){
        await t.wait(1000);
        await helper.click(this.additionalCovSection);
        await helper.click(this.earthquakeSprinklerLeakage);
    }
    async verifyEditedBuilding(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsPremBasisAmt), data.PremimumBasisAmountEdited, "Edited premimum amount value mismatch");
        await helper.click(this.buildingCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildLimitValue), data.BuildingLimitEdit, "Edited Building limit value mismatch");
        await helper.click(this.buildingAddCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsAddCoverageValue),'Earthquake - Sprinkler Leakage','Edited Additional coverage value is not displayed');

    }
    async isEarthquakeSprinklerLeakageAdded(){
        await helper.click(this.buildingAddCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsAddCoverageValue),'Earthquake - Sprinkler Leakage','Edited Additional coverage value is not displayed');
    }
    async addLocationDetails(data) {
        await this.clickAddLocationIcon();
        await this.enterAddressLine1(data.AddressLine1);
        await this.enterCity(data.City);
        await this.enterZIPCode(data.Zip);
        await this.selectState(data.State);
    }
    async getNewBuildingForm(locHeader){
        var locationHeaderCount = await this.locationHeader.count;
        for (let i = 0; i < locationHeaderCount; i++) {
            var element = this.locationHeader.nth(i);
            if((await helper.getTextAtLocator(element)).includes(locHeader)){
                    await helper.click(element.parent(4).find("button[id*='addBuilding']"));
            }    
        }

    }
    async verifyAddedLocation() {
        await assert.elementPresent(this.verifyLocationAdded, "Added Location is not displayed");
    }
    async verifyLocationNotAdded() {
        await assert.elementNotPresent(this.verifyLocationAdded, "Location is displayed");
    }
    async deleteAddedLocation() {
        await helper.click(this.deleteAddedLocationIcon);
        await helper.click(this.deleteButton);
        await assert.elementNotPresent(this.verifyLocationAdded, "Added Location is not deleted");
    }
    async selectBuildingTab(tab) {
        await helper.click(this.buildingTabSelect.nth(tab));
    }
    async isAddBuildingDetailsMessageDisplayed() {
        await assert.assertEqual(await helper.getTextAtLocator(this.addBuildingMessage),'Please provide building details to see the coverages.','General Coverage display message is not displayed');
    }
    async isAddBuildingDetailsMessageNotDisplayed() {
        await assert.elementNotPresent(this.addBuildingMessage,'General Coverage display message is displayed');
    }
    async verifyBuildingDetailsValues(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsPremBasisAmt), data.PremiumBasisAmount, "Premium Basis Amount mismatch");
        await helper.click(this.buildingCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildLimitValue), data.BuildingLimit, " Building limit value mismatch");
        await helper.click(this.buildingAddCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsAddCoverageNoValue),'No Coverages','Additional coverage value mismatch');

    }
    async isBOPBuildingSaved(data){
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsYearBuild), data.YearBuilt, "Year built is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsNumberOfStories), data.NoOfStories, "No. of Stories is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailstotalArea), data.TotalArea, "Total area is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsConstructionType), data.ConstructionType, "Construction Type is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsExposure), data.Exposure, "Exposure is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsPercentageSprinkled), data.PercentSprinklered, "Percent Sprinkled is incorrect");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsPremBasisAmt), data.PremiumBasisAmount, "Premium Basic amount is incorrect");

    }
    async verifyBuildingCoverageValues(data) {
        await helper.click(this.buildingCoveragesTab);
        await assert.assertEqual(await helper.getTextAtLocator(this.busPersonalPropLimitValue), data.BusinessPersonalPropLimit, " Business Personal Property  Limit value mismatch");
        await assert.assertEqual(await helper.getTextAtLocator(this.buildLimitValue), data.BuildingLimit, " Building limit value mismatch");
    }
    async isBasisAmountCorrectOnDetails(basisAmount) {
        await this.selectBuildingTab(1);
        await assert.assertEqual(await helper.getTextAtLocator(this.buildDetailsPremBasisAmt), basisAmount, 'Basis Amount does not match');
    }

    async isBuildingLimitDataCorrectOnCoverages(coverageName, buildingLimit) {
        var buildingLimit = await this.getBuildingLimit(coverageName);
        await assert.assertEqual(await helper.getTextAtLocator(Selector(buildingLimit).parent(0).find("div[class*='termAmount']")), buildingLimit, 'Building limit did not save on Coverages');

    }
    async getBuildingLimit(cvgName) {
        for (let i = 0; i < await coverageTerm.count; i++) {
            var coverage = coverageTerm.nth(i);
            if (await helper.getTextAtLocator(coverage) == cvgName) {
                return coverage;
            }
        }
    }
    async validateBOPBuildingDetailsInBackend(policyNum, buildingDetails) {
        var policyChange = await dataFetch.getPolicyChangeData(policyNum);
        var buildingLimit;
        var buildingDetailsFirstBldng = policyChange.lobData.businessOwners.coverables.locations[0].buildings[0].baseCoverages;
        var baseCovCount = buildingDetailsFirstBldng.length;
        var buildingDesc = policyChange.lobData.businessOwners.coverables.locations[0].buildings[0].name;
        var basisAmount = policyChange.lobData.businessOwners.coverables.locations[0].buildings[0].basisAmount;
        for (let i = 0; i < baseCovCount; i++) {
            const element = buildingDetailsFirstBldng[i];
            if (element.name === 'Building') {
                buildingLimit = element.terms[1].chosenTermValue;
            }
        }
        await assert.assertEqual(buildingDesc.trim(),(buildingDetails.NewBuildingDescription).trim(), 'Building Description does not match with backend');
        await assert.assertEqual(basisAmount.toString(),buildingDetails.NewBasisAmount.toString(), 'Basis Amount does not match with backend');
        await assert.assertEqual(buildingLimit.replace(',',''),buildingDetails.NewBuildingLimit, 'Building Limit does not match with backend');

    }
    async isBuildingLimitDataCorrectOnCoverages() {
        await this.selectBuildingTab(2);
    }
    async pressCancelAndConfirm() {
        await helper.click(this.cancelButton);
        await modal.confirm();
    }
    async navigateToQuotePage() {
        await common.goNext();
    }
    async goPrevious() {
        await common.goPrev();
    }
    async isRemoveIconAvailableForPrimaryLocation() {
        await assert.elementNotPresent(this.deleteAddedLocationIcon, "Remove location option is displayed for primary Location");
    }

}