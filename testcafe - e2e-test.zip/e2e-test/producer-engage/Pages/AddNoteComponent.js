import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import AlertHandler from '../Pages/AlertHandler';

const helper = new Helper();
const assert = new Assertion();
const alert = new AlertHandler();
const dataPE = require('../Data/PE_Data.json');
var accountName;
var accountNameLink = "[title='"+accountName+"']";



export default class AddNoteComponent {
    constructor() {
        this.addNoteBtn = Selector("button[id='notesAddButtonId']"); 
        this.addNoteButtonInActivity = Selector("#notesAddButtonIdinShowHide")
        this.searchNotes= Selector("#searchFilter");
        this.addNoteTopic = Selector("div[id='notesTopic']"); 
        this.addNoteTopicOption = Selector("div[id='notesTopic'] div[class*='TypeaheadMultiSelectField__menu'] div"); 
        this.addNoteTopicErrMsg = Selector("div[id*='notesTopic'][role='alert']"); 
        this.addNoteSubject = Selector("input[id='notesInput']"); 
        this.addNoteSubjectErrMsg = Selector("div[id*='notesInput'][role='alert']"); 
        this.noteBody = Selector("[id='notesTextarea']"); 
        this.noteBodyErrMsg = Selector("div[id*='notesTextarea'][role='alert']"); 
        this.submitBtn = Selector("button[id='notesAddDataid']"); 
        this.submitNoteBtn = Selector("[id='notesAddDataid']"); 
        this.noteSubject = Selector("[class*='NotesComponent_noteSubject']"); 
        this.cancelBtn = Selector("#notesCancelid");
        this.addedNoteSection = Selector("[class='gw-note-view-list-wrapper']");
        this.noteCreatedText = Selector("[class*='Modal-module__modalTitle']");
        this.noteAuthor = Selector("div[class*='NotesComponent_noteTopic']"); 
        this.noteCreationDate = Selector("div[class*='NotesComponent_noteDate']").nth(0); 
        this.noteCreationTime =Selector("div[class*='NotesComponent_noteDate']").nth(1); 
        this.noteDescription = Selector("[class*='NotesComponent_noteBody']"); 
        
    }
    async clickAddNote() {
        await helper.click(this.addNoteBtn);
    }
    async withTopic(text) {
        await helper.selectDropdown(this.addNoteTopic,this.addNoteTopicOption,text);
    }
    async withSubject(text) {
        await helper.typeText(this.addNoteSubject, text)
    }
    async withNoteText(text) {
        await helper.typeText(this.noteBody, text)
    }
    async submitNote() {
        await helper.click(this.submitNoteBtn);
    }

    async cancel() {
        await helper.click(this.cancelBtn);
    }
    async addGeneralNote(text) {
        await this.clickAddNote();
        await this.withTopic('General');
        await this.withSubject(text);
        await this.withNoteText(text);
        await this.submitNote();
    }
    async cancelAddingNote(text) {
        await this.clickAddNote();
        await this.withTopic('General');
        await this.withSubject(text);
        await this.withNoteText(text);
        await this.cancel();
    }
    async validateAddbuttonIsDisabled(){
        await assert.isElementNotClickable(this.submitBtn,'disabled','Button is enabled');
    }
    async validateAddbuttonIsEnabled(){
        await assert.isElementClickable(this.submitBtn,'enabled', 'Button is Disabled');
    }
    async isNoteListed(text) {
        await assert.assertEqual(await helper.getTextAtLocator(this.noteSubject), text, 'Note Subject does not match');
    }
    async isNoteNotAdded() {
        await assert.elementNotPresent(this.addedNoteSection, 'Note is not created');
    }

    

    async doesAddNoteButtonExist(status) {
        if (status == "open") {
            await assert.elementPresent(this.addNoteButtonInActivity, 'Add note button was not visible for the open activity');
        } else if (status == "completed") {
            await assert.elementNotPresent(this.addNoteButtonInActivity, "Add note button was visible for the completed activity");

        }

    }

    async clickAddNoteButton() {
        await helper.click(this.addNoteButtonInActivity);
    }

    async isNodeAddedModalDisplayed(noteCreatedMessage) {
        await assert.assertEqual(await helper.getTextAtLocator(this.noteCreatedText), noteCreatedMessage, 'Note added model pop up is not displayed');
    }

    async isNoteAddedToActivity(noteSubject) {
        await assert.assertEqual(await helper.getTextAtLocator(this.noteSubject), noteSubject, 'Note is not added to activity');
        await assert.assertEqual(await helper.getTextAtLocator(this.noteDescription), noteSubject, 'Note is not added to activity');
    }

    async areRequiredFieldsMarked() {
        await assert.assertEqual(await helper.getTextAtLocator(this.addNoteTopicErrMsg),dataPE.addNoteMandatoryErrMsg,'Mandatory Error message is not displayed for Note Topic');
        await assert.assertEqual(await helper.getTextAtLocator(this.addNoteSubjectErrMsg),dataPE.addNoteMandatoryErrMsg,'Mandatory Error message is not displayed for Note Subject');
        await assert.assertEqual(await helper.getTextAtLocator(this.noteBodyErrMsg),dataPE.addNoteMandatoryErrMsg,'Mandatory Error message is not displayed for Note Body');

    }
    async validateMandatoryErrorMessage(){
        await helper.removeRequiredTextAndValidate(this.addNoteSubject,this.addNoteSubjectErrMsg);
        await helper.removeRequiredTextAndValidate(this.noteBody,this.noteBodyErrMsg);
    }
    async validateNoteUIComponent(){
        await assert.elementPresent(this.addNoteBtn,'Add note button is not displayed');
        await assert.elementPresent(this.searchNotes,'Note search textbox is not displayed');
    }

    async validatedAddedNoteUIComponant(){
        await assert.elementPresent(this.noteAuthor,'Note author is not present');
        await assert.elementPresent(this.noteCreationDate,'Note creation date is not present');
        await assert.elementPresent(this.noteSubject,'Note subject is not present');
        await assert.elementPresent(this.noteDescription,'Note description is not present');
    }

}
