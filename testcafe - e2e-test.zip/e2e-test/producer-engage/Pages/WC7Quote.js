import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WC7Quote{
    constructor() {
        this.employeesCodeAccordion = Selector("[id='gridaccordion']");
        this.employeesCodeAnnualWagesValue = Selector("[id*='employeeAddressSection']").sibling("[class*='RatesAndCostsComponent_tableStyle']").find('td').nth(2);
        this.employeesCodeValue = Selector("[id*='employeeAddressSection']").sibling("[class*='RatesAndCostsComponent_tableStyle']").find('td').nth(1);
        this.stopGapValue = Selector("[id*='coverageTableContainer'] tbody [class*='digitalRow Table-module__row']").nth(2).child(1);
    }
    async clickNext() {
        await helper.click(this.nextButton);
    }

    async validateSelectedStopGapValue(stopGapValue){
        await assert.assertEqual(await helper.getTextAtLocator(this.stopGapValue),stopGapValue,'Stop Gap value is incorrect');
    }
}