import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import moment from 'moment';
const helper = new Helper();
const assert = new Assertion();

export default class EndorsementTypeBoxPage {
    constructor() {
        this.address = Selector("[aria-label*='Address Change']");
        this.vehicle = Selector("[aria-label*='Add, Edit or remove Vehicle']");
        this.driver = Selector("[aria-label*='Add, Edit or remove Driver']");
        this.coverage = Selector("[for='c_coverages']");
        this.setDateField = Selector("input[id='paPolicyChangeEffectiveDate']");
        this.setDateFieldHO =Selector("#hoPolicyChangeEfectiveDateId");
        this.dateErrorMsg = Selector("[id*='paPolicyChangeEffectiveDate'][class*='error']");
        this.endorsementWizardAutoTile = Selector("[class*='Template_wizardContent']");
        this.endorsementWizardTitle = Selector("[id='paPolicyChangeId']");
        this.mortgagee = Selector("[aria-label='Mortgagee']");
        this.jobNum = Selector("[class*='WizardPageHeader_gwWizardPageTitle'] div").nth(1);
        this.valuables = Selector("[aria-label='Valuables']");
        this.coverages = Selector("[aria-label='Coverage change']");
        this.coverageHO = Selector("[aria-label='Coverages']");
    }
    async selectAddressChange() {
        await helper.click(this.address);
        await t.wait(1000);
    }
    
    async selectAddEditRemoveDriver() {
        await helper.click(this.driver);
        await t.wait(1000);
    }
    async selectAddEditRemoveVehicle(){
        await helper.click(this.vehicle);
        await t.wait(1000);
    }

    async setEffectiveDate(){
        var date = moment().add(1,'day');
        var futureDate = date.format('ll');
        await helper.typeText(this.setDateField,futureDate);
    }

    async setEffectiveDateHO(){
        var date = moment().add(1,'day');
        var futureDate = date.format('ll');
        await helper.typeText(this.setDateFieldHO,futureDate);
    }
    async getDate(){
        var date = await helper.getValueAttributeFromLocator(this.setDateField);
        return date;
    }

    async isEndorsementWizardDisplayed() {
        await assert.elementPresent(this.endorsementWizardAutoTile, 'Endorsement Wizard is not displayed');
        await assert.textContains(await helper.getTextAtLocator(this.endorsementWizardAutoTile),'Policy Changes','Policy Changes page title is incorrect or not presented.')
    }
    async selectMortgagee(){
        await helper.click(this.mortgagee);
        await t.wait(2000);
    }

    async selectValuables(){
        await helper.click(this.valuables);
        await t.wait(2000);
    }
    async selectCoverages(){
        await helper.click(this.coverages);
        await t.wait(2000);
    }
    async selectCoveragesHO(){
        await helper.click(this.coverageHO);
        await t.wait(2000);
    }
    async setPastEffectiveDate(){
        var date = moment().subtract(1,'day');
        var pastDate = date.format('L');
        await helper.typeText(this.setDateField,pastDate);
        await helper.pressTab();
    }
    async setBlankEffectiveDate(){
        var date = ' ';
        await helper.typeText(this.setDateField,date);
    }
    
    async dateError(currentdate){
        var date = moment(currentdate).format("ddd MMM DD YYYY");
        await assert.textContains(this.dateErrorMsg.innerText,'Minimum date is '+date,'Past date can be entered');
    }
    async getPolicyChangeJobNumber(){
        var num = await this.jobNum.innerText;
        var polChangeNum = num.replace(/\D+/g, "");;
        return polChangeNum;
    }
}