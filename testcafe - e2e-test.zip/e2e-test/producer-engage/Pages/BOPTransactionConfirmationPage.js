import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const modal = new Modal();
const TRANSACTION_CONFIRMATION_HEADING='Your changes have been confirmed.' ;
var jobNumber;
const REFERENCE_NUMBER = 'Reference Number: '+jobNumber;
var policyNumber ;
const POLICYNUMBER = 'Businessowners policy: '+policyNumber;
const BILLING_SECTION = 'You can check the payment schedule and invoices here: Policy Billing Page';

export default class BOPTransactionConfirmation {
    constructor() {
        this.viewPolicyButton = Selector("#viewPolicyButton");
        this.viewPolicyChangeButton = Selector("#transactionButton");
        this.policybillingLink = Selector("[id='paymentScheduleAndInvoices']").find('a');
        this.confirmationHeading = Selector("#changesConfirmed");
        this.referenceNumberSection = Selector("#referenceNumber");
        this.policyNumberSection = Selector("#lobDetails");
        this.policyBillingSection = Selector("#paymentScheduleAndInvoices");
        this.transactionDoneIcon = Selector("#phoneIcon");
    }
    async clickViewPolicyBtn(){
        await helper.click(this.viewPolicyButton);
    }
    async clickViewPolicyChangeBtn(){
        await helper.click(this.viewPolicyChangeButton);
    }
    async clickPolicyBillingPageLink(){
        await helper.click(this.policybillingLink);
    }
    async validateTransactionConfirmationPage(jobNum,policyNum){
        await assert.assertEqual(await helper.getTextAtLocator(this.confirmationHeading),TRANSACTION_CONFIRMATION_HEADING,'The Transaction confirmation Heading is correct');
        await assert.assertEqual(await helper.getTextAtLocator(this.referenceNumberSection),REFERENCE_NUMBER.replace(jobNumber,jobNum),'Reference Number is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyNumberSection),POLICYNUMBER.replace(policyNumber,policyNum),'The Policy Number section is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyBillingSection),BILLING_SECTION,'Contents in the Billing Section is incorrect');
        await assert.elementPresent(this.viewPolicyChangeButton,'View Change Policy Button is not available');
        await assert.elementPresent(this.viewPolicyButton,'View Policy Button is not available');
        await assert.elementPresent(this.transactionDoneIcon,'Transaction Done Icon is not displayed');
    }
}