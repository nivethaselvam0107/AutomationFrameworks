import { Selector ,ClientFunction} from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const data = require('../Data/PE_Data.json');
const helper = new Helper();
const assert = new Assertion();
var accnum;
var accountName = "a[href*='/accounts/"+accnum+"']";
var policynum;
var policyNumber = "a[href*='/policies/"+policynum+"']";
var claimnum;
var claimNumber ="a[href*='/claims/"+claimnum+"']";



export default class ClaimsLanding {
    constructor() {
        this.title = Selector("[id='pageTitlelayout']");
        this.defaultTitle = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.paginatedTable = Selector("[class*='Table-module__tableElement']");
        this.recentlyCreated = Selector("[class*='TileComponent_gwTileTitle']").nth(1);
        this.recentlyViewed = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.openClaims = Selector("[class*='TileComponent_gwTileTitle']").nth(2);
        this.closedClaims = Selector("[class*='TileComponent_gwTileTitle']").nth(3);
        this.recentlyViewedTable = Selector("[class*='Table-module__tableElement']");
        this.claimStatus =Selector("[class*='digitalRow Table-module__row__'] td:nth-child(4)");
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.claimsTitle, 'Claims landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, data.defaultTitle, 'Recently Viewed was not default tile');
    }
    async clickAccountName(accountNum){
        var accountNameLink = accountName.replace(accnum,accountNum);
        await helper.click(Selector(accountNameLink));
    }

    async clickPolicyNumber(policyNum){
        var policyNumberLink = policyNumber.replace(policynum,policyNum);
        await helper.click(Selector(policyNumberLink));
    
    }
    async clickClaimNumber(claimNum){
        var claimNumberLink = claimNumber.replace(claimnum,claimNum);
        await helper.click(Selector(claimNumberLink));
    
    }

    async validateClaimIsPresent(claimNum){
        var claimNumberLink = claimNumber.replace(claimnum,claimNum);
        await assert.elementPresent(Selector(claimNumberLink),'Claim is not present in page while it should');
    }
    async validateClaimIsNotPresent(claimNum){
        var claimNumberLink = claimNumber.replace(claimnum,claimNum);
        await assert.elementNotPresent(Selector(claimNumberLink),'Claim is present in page while it should not');
    }

    async validateOpenClaims(){

        var claimStatus = ClientFunction(() => {
            var statuses = document.querySelectorAll("[class*='rt-tr DataTable-module__tableRow'] div:nth-child(5)");
            for (var status of statuses)
            {
            if(status.textContent == 'Draft' || status.textContent == 'Open'){
               return true;
            }else{
               return false;
            }
        }
        });
        var status = await claimStatus();
        console.log(status);
        return status;
    }
    async validateCloseClaims(){
        var claimStatus = ClientFunction(() => {
            var statuses = document.querySelectorAll(this.claimStatus);
            
            for (var status of statuses)
            if(status.textContent == 'Closed'){
                return true;
            }else{
                return false;
            }
        });
        var status = claimStatus();
        return status;
    }



    
}