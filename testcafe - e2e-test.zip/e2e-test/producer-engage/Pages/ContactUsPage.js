import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const helper = new Helper();
const assert = new Assertion();
export default class ContactUs {
    constructor() {
        this.backToClaimButton = Selector("#linkDiv");
        this.errorMessage1 = Selector("#informationBased");
        this.errorMessage2 = Selector("#callOurAgent");

    }

    async isContactUsPageLoaded(){
        await assert.elementPresent(this.backToClaimButton,'Back to Claim button not visible');
        await assert.assertEqual(await helper.getTextAtLocator(this.errorMessage1),'Based on the information you have provided, we are unable to process this claim online.','Can Not proceed error message is not correct');
        await assert.assertEqual((await helper.getTextAtLocator(this.errorMessage2)).replace(/[\r\n]+/gm, " "),'Please call one of our agents at 1-866-555-0124 for assistance with submitting your claim.','Call agent error message is not correct');
    }
    async backToClaims(){
        await helper.click(this.backToClaimButton);
    }
}