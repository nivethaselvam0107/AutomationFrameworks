import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from './Tiles';
import PolicyCancellation from './PolicyCancellation';
import Modal from '../../Utilities/WidgetComponents/Modal';
const policydata = require('../../Utilities/Generator/PolicyGenerator');
const data = require('../Data/PE_PA_Data.json');
const helper = new Helper();
const assert = new Assertion();
const tiles = new Tiles();
const policyCancel = new PolicyCancellation();
const modal = new Modal();

export default class QuoteSummary {
    constructor() {
        this.withdrawbutton = Selector("#withdrawQuote");
        this.continuequotebutton = Selector("#continueQuote");
        this.tableheader = Selector("#uwIssuesTitle");
        this.shortdes = Selector("th:nth-child(1)");
        this.longdes = Selector("th:nth-child(2)");
        this.status = Selector("th:nth-child(3)");
        this.summaryTile = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.openActivitiesTile = Selector("[class*='TileComponent_gwTileTitle']").nth(1);
        this.notesTile = Selector("[class*='TileComponent_gwTileTitle']").nth(2);
        this.documentsTile = Selector("[class*='TileComponent_gwTileTitle']").nth(3);
        this.createdDate = Selector('#summaryCreatedDataId');
        this.inceptionDate = Selector("#summaryPolicyInceptionId");
        this.producerCodeOfRecord = Selector("#producerCodeOfRecordOrgId");
        this.quoteStatus = Selector('#summaryStatusdDataId');
        this.producerCodeOfService = Selector('#producerOfServiceId');
        this.quote_Withdraw_Message_Title = Selector('#alertContentInfo');
        this.quoteWithdrawStatus = Selector("#infoStatus");

    }
    async validateQuotePageComponents() {
        await assert.elementPresent(this.summaryTile, 'Summary tile not present');
        await assert.elementPresent(this.openActivitiesTile, 'Open Activities tile not present');
        await assert.elementPresent(this.notesTile, 'Notes tile not present');
        await assert.elementPresent(this.documentsTile, 'Documents tile not present');
        await assert.elementPresent(this.withdrawbutton, "Withdraw button is not present");
        await assert.elementPresent(this.continuequotebutton, "Continue Quote Button is not present");
        await this.validateQuoteDataExistance();
    }
    async validateQuoteDataExistance() {
        await assert.elementPresent(this.createdDate, 'Created Date is not present');
        await assert.elementPresent(this.inceptionDate, 'Policy Inception Date is not present');
        await assert.elementPresent(this.quoteStatus, 'Status is not present');
        await assert.elementPresent(this.producerCodeOfRecord, 'Producer Of Record is not present');
        await assert.elementPresent(this.producerCodeOfService, 'Producer Of Service is not present');
        await assert.assertEqual(await helper.getTextAtLocator(this.tableheader),'Underwriting Issues',"Underwriting Issues Header is not present.");
    }

    async clickContinueQuote() {
        await helper.click(this.continuequotebutton);
    }
    async goToNotesTile() {
        await helper.click(this.notesTile);
    }
    async validatestatusOfQuote(status){
        await assert.assertEqual(await helper.getTextAtLocator(this.quoteStatus),status,'Status is incorrect');
    }
    async clickWithdrawQuote() {
        await helper.click(this.withdrawbutton);
        await modal.confirm();
        await t.wait(2000);
    }
    async validateQuoteWithdrawn() {
        let withdrawMessage = await helper.getTextAtLocator(this.quote_Withdraw_Message_Title);
        let status = await helper.getTextAtLocator(this.quoteWithdrawStatus);
        await assert.assertEqual(withdrawMessage, 'This quote has been withdrawn.', 'quote not withdrawn');
        await assert.assertEqual(status, 'Withdrawn', 'status is not withdrawn');
    }
    async goToOpenActivities(){
        await helper.click(this.openActivitiesTile);
    }

}