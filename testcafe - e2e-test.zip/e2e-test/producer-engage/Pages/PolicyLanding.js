import { Selector ,t} from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';

const data = require('../Data/PE_Data.json');
const helper = new Helper();
const assert = new Assertion();
var number;
var jobNumberLink = "a[href*='"+number+"']";

export default class PolicyLanding {
    constructor() {
        this.title = Selector("[id='pageTitle']");  
        this.defaultTitle = Selector("[class*='TileComponent_gwTileTitle']").nth(0);  
        this.recentlyIssued= Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(1);
        this.recentlyViewed = Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(0);
        this.openChanges = Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(5);
        this.openCancellations = Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(6);
        this.renewalChanges = Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(4);
        this.delinquent=Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(2);
        this.openQuotes= Selector("div[id='policyPageTileContainer'] [class*='TileComponent_gwTileTitle']").nth(3);
        this.firstPolicyNum=Selector("[title='Policy Number']").nth(0);
        this.firstJobNum= Selector("[title='Job Number']").nth(0);
    }
    async openFirstPolicy(){
        await helper.click(this.firstPolicyNum);      
    }

    async openFirstJob(){
        await helper.click(this.firstJobNum);

    }
    async showDelinquent(){
        await helper.click(this.delinquent);
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.policyTitle,'Policies landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText,data.defaultTitle,'Recently Viewed was not default tile');
    }

    async showRecentlyIssued(){
        await helper.click(this.recentlyIssued);
        await t.wait(2000);
    }
    async showRecentlyViewed(){
        await helper.click(this.recentlyViewed);
        await t.wait(2000);
    }
    async showOpenRenewals(){
        await  helper.click(this.renewalChanges);
        await t.wait(2000);
    }
    async showOpenQuotes(){
        await helper.click(this.openQuotes);
        await t.wait(2000);
    }
    async showOpenCancellations(){
        await helper.click(this.openCancellations);
        await t.wait(2000);
    }
    async showOpenchanges(){
        await helper.click(this.openChanges);
        await t.wait(2000);
    }
    async openJob(jobNumber){ 
        var jobLink = jobNumberLink.replace(number, jobNumber)
        await helper.click(Selector(jobLink));
    }
}