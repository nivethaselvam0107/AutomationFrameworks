import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';
const data = require('../Data/PE_PA_Data.json');
const dataCP =require('../Data/PE_CP_Data.json');

const helper = new Helper();
const assert = new Assertion();


export default class CPBOPPolicyInfoPage {


    constructor() {
        this.email=Selector("[id='email'][class*='InputField-module__input']");
        this.phoneNum=Selector("[id='phone'][class*='InputField-module__input']");
    }

    async isEmailFieldMarkedWithError(errormsg){
        await assert.assertEqual(await helper.getTextAtLocator(this.email_val_Error),errormsg,"Email not marked with error properly");
    }
    async isPhoneFieldMarkedWithError(errormsg){
        await assert.assertEqual(await helper.getTextAtLocator(this.phone_Val_Error),errormsg,"Phone not marked with error properly");
    }
    async isPolicyInfoPageSaved(data){
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.email),data.Email,"Email didn't save");
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.phoneNum), data.Phone,"Phone didn't save");

    }







}
