import { Selector, t, ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Login from '../Login';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const url = process.env.TEST_ENV_URL;
var FAQURL = '/faq/';
var FAQ_NO_RESULTS_TEXT = "No matching results found";


const login = new Login();


export default class FaqPage {
    constructor() {
        this.userName = Selector("[id='gwAuthStatus'] button");
        this.faq_Menu_Link = Selector("a[id='faq']");
        this.faq_Container = Selector("[class*='FaqPage_pageContainer']");
        this.navBar_Hamburger = Selector("div[class*='gw-hamburger']");
        this.faq_Hamburger_Menu_Link = Selector("li[gw-faq-link] a");
        this.faq_Link_Name = Selector("faq/");
        this.faq_Section_Menu = Selector("[class*='FaqPage_wizardLi']");
        this.faq_Search_Box = Selector("#searchTopicField");
        this.home_Btn = Selector("//div[@class='gw-header']//a[@href='#/home' or @href='#/']");
        this.faq_NoResults_Area = Selector("gw-faq div[class*='FaqDirective'] div[class*='FaqEmptyInfo']");
        this.faq_Customize = Selector("[class*='digitalContentContainer FieldComponent-module']").nth(4);
        this.FAQ_HIGHLIGHTED = Selector("[class*='FaqItemComponent_gwHighlightedText']");
        this.Faq_menu_link_parent_css = Selector("[gw-faq-link]:not(li) span[category='faq']");
        this.FAQ_NO_RESULTS_AREA_CSS = Selector("#error");
        this.FAQ_SECTIONS_MENU_CSS = Selector("ul.gw-steps a");
    }

    async getFaqPage() {
        await login.login();
        await this.openFaqPageByClickingLink();
    }
    async openFaqPageByClickingLink() {
        await helper.click(this.userName);
        await helper.click(this.faq_Menu_Link);
    }

    async isFaqPageOpened() {

        await assert.elementPresent(this.faq_Container, "FAQ page is NOT loaded after clicking menu link.");
    }
    async getFaqPageOnResizedWindow() {
        await login.login();
        await t.resizeWindow(600, 730);
        await helper.click(this.navBar_Hamburger);
        await this.openFaqPageByClickingLinkOnHamburgerMenu();
    }
    async openFaqPageByClickingLinkOnHamburgerMenu() {
        await helper.click(this.faq_Hamburger_Menu_Link);
    }
    async getFaqPageByUrl() {
        await login.login();
        await this.openFaqPageByClickingLink();
    }

    async checkAllSearchResultsForTopicQuestionWord() {

        var actualStatusList = []
        actualStatusList = await this.getTopicQuestions();
        for (var i = 0; i < actualStatusList.length; i++) {
            var text = actualStatusList[i];
            await this.search(text);
            var actual = await this.listContains();
        }


    }
    async  checkSearchResultsForTopicQuestionWord() {
        var actualStatusList = [];
        actualStatusList = await this.getTopicQuestions();
        var searchedText = await this.getSingleWord(actualStatusList);
        await this.search(searchedText);

    }

    async search(data) {
        await helper.typeText(this.faq_Search_Box, data);
        await this.verifyHighlightedElements();
    }
    async verifyHighlightedElements(){
        await assert.elementPresent(this.FAQ_HIGHLIGHTED,'Search results are not highlighted');
    }

    async getHighlightedElements() {
        var results = ClientFunction(() => {
            var items = document.querySelectorAll("[class*='FaqItemComponent_gwHighlightedText']");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        })
        var highlights = await results();
        return highlights;
    }

    async listContains(list, expected) {
            if (list.includes(expected))
            return true;
        else
            return false;
    }

    async getTopicQuestions() {
        var questions = ClientFunction(() => {
            var items = document.querySelectorAll("[class*='FaqItemComponent_gwQuestionTitle'] h2");
            var itemsValues = [];

            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;

        })
        var listOfQuestions = await questions();
        return listOfQuestions;
    }


    async getSingleWord(arrayList) {
        var str = await this.getRandomList(arrayList);
        var strList = [];
        strList = await str.split(" ");
        var word = await this.getRandomList(strList);
        console.log(word);
        return word;
    }


    async selectLastSection() {
        var index = await this.faq_Section_Menu.count;
        await helper.click(this.faq_Section_Menu.nth(index - 1));
    }
    async isSelectedElementVisible() {
        await assert.elementPresent(this.faq_Customize, "FAQ selected section is NOT visible on screen.");
        var print = await helper.getTextAtLocator(this.faq_Customize);
        await assert.assertEqual(print, 'How to customize the FAQ content', 'FAQ selected section is NOT visible on screen.');

    }

    async checkIfDeepLinkInURLForSectionDisplayed() {
        await this.goToLandingPage()
    }
    async checkIfDeepLinkForTopicDisplayed() {
        await this.setDeepLinkInLandingPageScope();
        await this.goToLandingPage();
        await this.openFaqPageByClickingLink();
    }
    async getRandomList(list) {
        var randomNum = list[Math.floor(Math.random()*list.length)];
        return randomNum;
    }
    async search(text) {
        await helper.typeText(this.faq_Search_Box, text);
    }
    get getTopicLinkNames() {
        var questions = ClientFunction(() => {
            var items = document.querySelectorAll("[class*='FaqItemComponent_gwFaqItemLink__']");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.innerText);
            return itemsValues;

        })
        var listOfQuestions = []
        return listOfQuestions;

    }

    async  searchSpecialCharsText() {

        var searchedText = [":", "?", ">", "/", "\\", "%", "#", "@", "!", ",", "!=", "=", "+", "\\d", "\\w", "^", '$'];
        for (var item of searchedText) {
           await this.search(item);
        }
    }
    async checkSearchContainsNoResultsMessage(str) {
        await this.search(str);
        await assert.assertEqual(await helper.getTextAtLocator(this.FAQ_NO_RESULTS_AREA_CSS), FAQ_NO_RESULTS_TEXT);


    }

}
