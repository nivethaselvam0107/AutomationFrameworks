import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
import DataFetch from '../Data/DataFetch';
const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const modal = new Modal();
const dataFetch = new DataFetch();

export default class BOPAdditionalCoverages {
    constructor() {
        this.cancelButton = Selector("#gw-wizard-cancel");
        this.guestsPropertyInSafeDeposit = Selector("[id='_BOPGuestSafeDepCov']").sibling('span');
        this.selectGuestsPropSafeDeposit = Selector("div[id*='ClauseTerm_[BOPGuestSafeDepCov]'][class*='typeaheadMultiSelect']");
        this.selectGuestsPropSafeDepositOption =Selector("div[id*='ClauseTerm_[BOPGuestSafeDepCov]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.contractorsDesignPremises = Selector("input[id*='BOPDesigPremProj']").parent(0).find('span');
        this.contractorsAggregateLimits = Selector("input[id*='BOPAggLimitProjCov']").parent(0).find('span');
        this.contractorsPesticideAppCoverage = Selector("input[id*='BOPPesticideApplicatorCov']").parent(0).find('span');
        this.liabilityComputerLimitedCov = Selector("input[id*='BOPY2KLimitedCov']").parent(0).child(1);
        this.liabilityEmpBenefits = Selector("input[id*='BOPEmpBenefits']").parent(0).child(1);
        this.textEmpBenEachEmpLim = Selector("input[id*='[BOPEmpBenefits]']").nth(0);
        this.textEmpBenAggLim = Selector("input[id*='[BOPEmpBenefits]']").nth(1);
        this.empBenEachEmpDedSelect = Selector("div[id='ClauseTerm_[BOPEmpBenefits]_[2]']");
        this.empBenEachEmpDedOption = Selector("div[id='ClauseTerm_[BOPEmpBenefits]_[2]'] div[class*='TypeaheadMultiSelectField__menu'] div"); 
        this.dateTime = Selector("input[id*='[BOPEmpBenefits]']").nth(2);
        this.liabilityComputerPremises = Selector("input[id*='BOPY2KPremOnlyCov']").parent(0).child(1);
        this.crimeComputerFundsTfrFraud = Selector("input[id*='BOPComputerFraudCov']").parent(0).child(1);
        this.crimeComputerFraudLimitSelect = Selector("div[id*='ClauseTerm_[BOPComputerFraudCov]_[0]'][class*='typeaheadMultiSelect']");
        this.crimeComputerFraudLimitOption = Selector("div[id*='ClauseTerm_[BOPComputerFraudCov]_[0]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.liquorLiabilityEventOnly = Selector("input[id*='BOPLiquorEvents']").parent(0).child(1);
        this.liquorLiabilityEventDate = Selector("input[id='ClauseTerm_[BOPLiquorEvents]_[0]']");
        this.liquorLiabilityEventDescription = Selector("textarea[id='ClauseTerm_[BOPLiquorEvents]_[1]']");
        this.liquorLiabilityCoverage = Selector("input[id*='BOPLiquorCov']").parent(0).child(1);
        this.liquorLiabilityCoverageAggLimit = Selector("input[id='ClauseTerm_[BOPLiquorCov]_[0]']");
        this.policywideFDService = Selector("input[id*='BOPFDService']").parent(0).child(1);
        this.policywideBusInc = Selector("input[id*='BusIncChangeCov']").parent(0).child(1);
        this.professionsBarber = Selector("input[id*='BOPBarberCov']").parent(0).child(1);
        this.profBarberBeautCount = Selector("input[id='ClauseTerm_[BOPBarberCov]_[0]']");
        this.professionsFuneral = Selector("input[id*='BOPFuneralDirCov']").parent(0).child(1);
        this.profFuneralDirCount = Selector("#input[id='ClauseTerm_[BOPFuneralDirCov]_[0]']");
        this.terrorTerrorCap = Selector("input[id*='BOPCertTerrorCap']").parent(0).child(1);
        this.terrorTerrorCapLimit = Selector("input[id='ClauseTerm_[BOPCertTerrorCap]_[0]']");
        this.accountLink = Selector("[class*='WizardPageHeader_gwWizardPageAssociated']");
    }
    async verifyTitle(text) {
        await commonLocators.verifyTitle(text);
    }
    async validateTerrorSelectedAndEmpty(){
        await assert.elementPresent(this.terrorTerrorCapLimit,'Terror - Cap on Cert. Acts is not  selected');
        await assert.assertEqual(await helper.getTextAtLocator(this.terrorTerrorCapLimit),'','Aggregate Limit is not  empty for Terrorism');
    }
    async setContractorsCoverage(){
        await this.selectContractorsPesticideApplicant();
        await this.selectContractorsDesignPremises();
        await this.selectContractorsAggregateLimits();
    }

    async selectContractorsPesticideApplicant(){
        await helper.click(this.contractorsPesticideAppCoverage);
    }
    async selectContractorsDesignPremises(){
        await helper.click(this.contractorsDesignPremises);
    }
    async selectContractorsAggregateLimits(){
        await helper.click(this.contractorsAggregateLimits);
    }
    async selectLiabilityComputerLimitedCov(){
        await helper.click(this.liabilityComputerLimitedCov);
    }
    async selectLiabilityEmpBenefits(data){
        await helper.click(this.liabilityEmpBenefits);
        await helper.typeText(this.textEmpBenEachEmpLim, data.EmpBenEachEmpLim);
        await helper.typeText(this.textEmpBenAggLim, data.EmpBenAggLim);
        await helper.selectDropdown(this.empBenEachEmpDedSelect,this.empBenEachEmpDedOption,data.EmpBenEachEmpDed);
        await helper.typeText(this.dateTime,(today.getMonth()+'/'+today.getDate()+'/'+today.getFullYear()+' '+today.getHours()+':00 AM'));
    }
    async selectLiabilityComputerPremisesOnly(){
        await helper.click(this.liabilityComputerPremises);
    }
    async selectCrimeComputerFundsTfrFraud(option){
        await helper.click(this.crimeComputerFundsTfrFraud);
        await helper.selectDropdown(this.crimeComputerFraudLimitSelect,this.crimeComputerFraudLimitOption,option);
    }
    async selectLiquorLiabilityEventOnly(data){
        await helper.click(this.liquorLiabilityEventOnly);
        await helper.typeText(this.liquorLiabilityEventDate,(today.getMonth()+'/'+today.getDate()+'/'+today.getFullYear()+' '+today.getHours()+':00 AM'));
        await helper.typeText(this.liquorLiabilityEventDescription,data);
    }
    async selectLiquorLiabilityCoverage(data){
        await helper.click(this.liquorLiabilityCoverage);
        await helper.typeText(this.liquorLiabilityCoverageAggLimit,data);
    }
    async selectPolicywideFDService(){
        await helper.click(this.policywideFDService);
    }
    async selectPolicywideBusInc(){
        await helper.click(this.policywideBusInc);
    }
    async selectProfBarberBeautyLiability(data){
        await helper.click(this.professionsBarber);
        await helper.typeText(this.profBarberBeautCount,data);
    }
    async selectProfFuneralDirLiability(data){
        await helper.click(this.professionsFuneral);
        await helper.typeText(this.profFuneralDirCount,data)
    }
    async selectTerrorCap(data){
        await helper.click(this.terrorTerrorCap);
        await helper.typeText(this.terrorTerrorCapLimit,data);
    }
    async clickTerrorCap(){
        await helper.click(this.terrorTerrorCap);
    }
    async verifyCancelPrevious() {
        await commonLocators.verifyCancel();
        await commonLocators.verifyPrevious();
    }
    async clickOnCoverageCheckbox(coverageName) {
        var coverage = await this.getCoverageEntry(coverageName);
        await helper.click(Selector(coverage).parent(1).find('[role="checkbox"]'));

    }
    async getCoverageEntry(cvgName) {
        var cvg = Selector("[class*='digitalFieldLabel FieldLabel-module__fieldLabel']");
        for (let i = 0; i < await cvg.count; i++) {
            var coverage = Selector("[class*='digitalFieldLabel FieldLabel-module__fieldLabel']").nth(i);
            if (await helper.getTextAtLocator(coverage) == cvgName) {
                return coverage;
            }
        }
    }

    async clickOnAccountLinkFromWizard(){
        await helper.click(this.accountLink);
        await modal.confirm();
    }
    async clickGuestPropertyInSafeDepositCoverage(){
        await helper.click(this.guestsPropertyInSafeDeposit);
    }

    async setGuestPropertyInSafeDepositCoverage(GuestPropSafeDepositLimit){
        await helper.click(this.guestsPropertyInSafeDeposit);
        await helper.selectDropdown(this.selectGuestsPropSafeDeposit,this.selectGuestsPropSafeDepositOption,GuestPropSafeDepositLimit);   
     }
     async isAdditionalCoveragesSaved(){
            await assert.attributePresent(this.contractorsPesticideAppCoverage,'aria-checked','true','Pesticide Applicant Coverage not saved');
            await assert.attributePresent(this.contractorsDesignPremises,'aria-checked','true','Design Premesis not saved');
            await assert.attributePresent(this.contractorsAggregateLimits,'aria-checked','true','Aggregate Limits not saved');
     } 
    async isGuestPropertySafeDepositSelected(policyNum) {
        var policyChange = await dataFetch.getPolicyChangeData(policyNum);
        var Guest_Prop_Safe_deposit_Selected;
        var lineAddCoveIteration = policyChange.lobData.businessOwners.coverages.additionalCoverages;
        var baseCovCount = lineAddCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineAddCoveIteration[i];
            if (element.name === 'Guests Property In Safe Deposit') {
                Guest_Prop_Safe_deposit_Selected = element.selected;
            }
        }
        await assert.assertEqual(Guest_Prop_Safe_deposit_Selected, true, 'Guest Property In Safe Deposit is not  selected in backend');
    }
    async validateGuestPropSafeDepositLimitInBackend(policyNum, coverageData) {
        var policyChange = await dataFetch.getPolicyChangeData(policyNum);
        var Guest_Prop_Safe_deposit_Limit;
        var lineAddCoveIteration = policyChange.lobData.businessOwners.coverages.additionalCoverages;
        var baseCovCount = lineAddCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineAddCoveIteration[i];
            if (element.name == 'Guests Property In Safe Deposit') {
                Guest_Prop_Safe_deposit_Limit = element.terms[0].chosenTermValue;
                console.log(Guest_Prop_Safe_deposit_Limit);
            }
        }
        await assert.assertEqual(Guest_Prop_Safe_deposit_Limit, coverageData.GuestPropSafeDepositLimit, 'Guests Property In Safe Deposit Limit does not match');
    }
   
    async clickNext() {
        await commonLocators.goNext();
    }
    async setadditionalCoverages(data) {
        await this.setGuestPropertyInSafeDepositCoverage(data.GuestPropSafeDepositLimit);
        await this.selectContractorsDesignPremises();
        await this.selectLiabilityComputerLimitedCov();
        await this.selectLiabilityEmpBenefits(data);
        await this.selectLiabilityComputerPremisesOnly();
        await this.selectCrimeComputerFundsTfrFraud(data.ComputerFraudLimit);
        await this.selectLiquorLiabilityEventOnly(data.LiquorLiabilityEventDesc);
        await this.selectLiquorLiabilityCoverage(data.LiquorLiabilityCovAggLimit);
        await this.selectPolicywideFDService();
        await this.selectPolicywideBusInc();
        await this.selectProfBarberBeautyLiability(data.ProfBarberBeautCount);
        await this.selectProfFuneralDirLiability(data.ProfFuneralDirCount);
        await this.selectTerrorCap(data.TerrorCapLimit);
    }
    async pressCancelAndConfirm(){
        await helper.click(this.cancelButton);
        await modal.confirm();
    }
    async goPrevious(){
        await commonLocators.goPrev();
    }
}