import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();

export default class AdditionalInformationPage {
    constructor() {
        this.email_Address=Selector("#contactEmail");
        this.phone_Number=Selector("#phoneNumber");
     
    }
    async setEmailAddress(email){
        await helper.removeText(this.email_Address);
        await helper.typeText(this.email_Address,email);
    }
    async setPhoneNumber(phonenumber){
        await helper.removeText(this.phone_Number);
        await helper.typeText(this.phone_Number,phonenumber);
    }
    async setAddInfoPageDetails(dataHO){
        await this.setEmailAddress(dataHO.EmailAddress);
        await this.setPhoneNumber(dataHO.PhoneNumber);
    }
    
}