import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';
import CommonLocators from '../../Utilities/CommonLocators';
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
const common = new CommonLocators();
export default class BOPPolicyDetailsPage {
    constructor() {
        this.pageTitle = Selector("[class*='WizardPageHeader_gwWizardPageCategory']");
        this.pageTitleAccountLink = Selector("a[class*='gwWizardPageAssociated']");
        this.effectiveDate = Selector("[id='policyChangeEffectiveDate']");
        this.orgType = Selector("[id='organizationType']");
        this.orgOption = Selector("[id='organizationType'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.smallBusType = Selector("[id='smallBusinessType']");
        this.smallBusTypeOption = Selector("[id='smallBusinessType'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.jobNumber = Selector("[class*='WizardPageHeader_gwWizardPageTitle'] div").nth(1);
        this.description = Selector("#policyChangeDescription");
        this.policyRenewalDescription = Selector('#policyRenewalDescription');
        this.policyRenewalEffectiveDate = Selector('#policyRenewalEffectiveDate');

       
    }
    async selectOrgType(organizationType) {
        await helper.selectDropdown(this.orgType,this.orgOption,organizationType);
    }
    async selectsmallBusinessType(businessType) {
        await helper.selectDropdown(this.smallBusType,this.smallBusTypeOption,businessType);
    }
    async setCoverageDate(date){
        await helper.typeText(this.effectiveDate,date);
    }
    async setPolicyDetails(data){
        await this.selectOrgType(data.organizationType);
        await this.selectsmallBusinessType(data.smallBusinessType);
    }
    async clickNext() {
        await common.goNext();
    }
    async clickCancel(){
        await common.pressCancel();
    }
    async getJobNumber(){
        var job = await helper.getTextAtLocator(this.jobNumber);
        var jobNum = (job.split('-')[1]).replace(/[^0-9]+/g,'');
        return jobNum;
    }
    async arePolicyDetailsSaved(data){
        await assert.assertEqual(await helper.getTextAtLocator(this.smallBusType),data.smallBusinessType,'Business Type is not saved');
        await assert.assertEqual(await helper.getTextAtLocator(this.orgType),data.organizationType,'Organization Type is not saved');
    }
    async validatePageHeaderForPolicyChange(){
        await assert.textContains((await helper.getTextAtLocator(this.pageTitle)).split('-'[1]),'Policy Change ','Job name is missing in the header');
        await assert.elementPresent(this.pageTitleAccountLink,'Account link  is not present');
    }
    async validatePresenceOfAllFields(){
        await assert.elementPresent(this.orgType,'Organization Type field is missing');
        await assert.elementPresent(this.description,'Description is field missing');
        await assert.elementPresent(this.effectiveDate,'Effective Date field is missing');
        await assert.elementPresent(this.smallBusType,'Small Business type field is missing');
    }
    async validatePresenceOfAllFieldsRenewal(){
        await assert.elementPresent(this.orgType,'Organization Type field is missing');
        await assert.elementPresent(this.policyRenewalDescription,'Description is field missing');
        await assert.elementPresent(this.policyRenewalEffectiveDate,'Effective Date field is missing');
        await assert.elementPresent(this.smallBusType,'Small Business type field is missing');
    }
    async validatePageHeaderForPolicyRenewal(policyNum){
        await assert.hasText(helper.getTextAtLocator(this.pageTitle),"Businessowners"+policyNum+" - Renewal ", "LOB and job name header missing");
        await assert.elementPresent(this.pageTitleAccountLink,'Account link not present');
    }
    
}