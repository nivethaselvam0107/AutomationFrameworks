import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();

export default class HOPaymentDetailsPage {
    constructor() {
        this.payment_Plan_Option=Selector("[for='plan_pctest:2']");
        this.account_Number=Selector("[id='accountNumber']");
        this.routing_Number=Selector("[id='abaNumber']"); 
        this.bank_Name=Selector("[id='bankName']"); 
        this.buy_Now=Selector("[id='gw-wizard-Next']"); 
        
    }
    async setPaymentPlan(){
        await  helper.click(this.payment_Plan_Option);
    }
async setAccountNumber(accnumber){
    await helper.typeText(this.account_Number,accnumber);
}
async setABARoutingNumber(abanum){
    await helper.typeText(this.routing_Number,abanum);
}
async setBankName(bankname){
    await helper.typeText(this.bank_Name,bankname);
}
async payMonthlyPremiumWithSavingsBankAccount(data){
    await this.setAccountNumber(data.AccountNumber);
    await this.setABARoutingNumber(data.RoutingNumber);
    await t.wait(2000);
    await this.setBankName(data.BankName);

}
async purchasePolicy(){
    await helper.click(this.buy_Now);

}

async getAccountNumber(data){
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.account_Number), data.AccountNum,'Account number is not empty');
}
async getRoutingNumber(data){
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.routing_Number), data.RoutingNum,'Routing number is not empty');
}
async getBankName(data){
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.bank_Name),data.Bank,'Bank name is not empty');
}
async arePaymentFieldsInInitialState(data){
    await this.getAccountNumber(data);
    await this.getRoutingNumber(data);
    await this.getBankName(data);


}
}