import { Selector, t,ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const helper = new Helper();
const assert = new Assertion();
export default class NewClaimWhere {
    constructor() {
        this.predefinedAddressOption = Selector("[for='whereDidHappenRadioButton_predefinedAddress']");
        this.selectAddressDropdown = Selector("[id='selectAddress']");
        this.selectAddressOption = Selector("[id='selectAddress'] div[class*='TypeaheadMultiSelectField__menu'] div");

    }
    async selectPredefinedAddress(){
        await helper.click(this.predefinedAddressOption);
    }
    async selectAddress(address){
        await helper.selectDropdownWithText(this.selectAddressDropdown,this.selectAddressOption,address)
    }
    async selectFirstAvailableAddress() {
        var optionToBeSelected=[];
        await helper.click(this.selectAddressDropdown);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("[id='selectAddress'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var dropDownoptions = await dropDownValues();
        for (var option of dropDownoptions)
            if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
                optionToBeSelected.push(option);    
            }
            await helper.click(this.selectAddressOption.withExactText(optionToBeSelected[0]));
    }

}
