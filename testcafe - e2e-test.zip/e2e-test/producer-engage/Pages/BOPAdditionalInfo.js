import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();

export default class BOPAdditionalInfo {
    async verifyTitle(text) {
        await common.verifyTitle(text);
    }
    async verifyCancelPrevious() {
        await common.verifyCancel();
        await common.verifyPrevious();
    }
    async clickNext() {
        await common.goNext();
    }    
}