import { Selector,ClientFunction,t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import AlertHandler from '../Pages/AlertHandler';
import moment from 'moment';

const helper = new Helper();
const assert = new Assertion();
const alert = new AlertHandler();

export default class ActivityPageFactory {
    constructor() {
        this.activityType = Selector("div[id='type']");    
        this.activityTypeOption = Selector("div[id='type'] div[class*='TypeaheadMultiSelectField__menu'] div")    
        this.activitySubject = Selector("input[id='subject']");    
        this.addBtn = Selector("button[id='addNewActivityButton']");    
        this.firstActivityInSchedule = Selector("[class*='rt-tr-group DataTable'] [class*='rt-td DataTable-module__tableCell']").nth(1);    
        this.addActivityDueDateInput = Selector("input[id='dueDate']");    
        this.addActivityDescInput = Selector("input[id='description']");    
        this.cancelBtn = Selector("[id='cancelNewActivityButton']");    
        this.addActivitySelector = Selector("div[id='addNewActivityContainer']");    
        this.addActivity = Selector("button[id='addActivityButton']");    
        this.addActivityDetails = Selector("[id='addNewActivityContainer']");    
        this.goToActivitiesTile = Selector("div[ui-sref='accounts.detail.contacts']");
        this.activityFilter = Selector("div[id='LOBFilter']");    
        this.activitySearch = Selector("input[id='searchFilter']");    
        this.priority = Selector("[class*='rt-td DataTable-module'] [class*='InfoLabel-module'] span");    
        this.dueDate = Selector("div[class*='rt-td DataTable-module']:nth-child(1)").sibling('div');    
        this.subject = Selector("div[class*='rt-td DataTable-module']:nth-child(4)");    
        this.assignee=Selector("#assignedName");    
        this.notes =Selector("div[class*='rt-td DataTable-module']:nth-child(6) div");    
        this.statusButton= Selector("div[class*='rt-td DataTable-module']:nth-child(7) span");   
        this.modalHeader = Selector("[class*='Modal-module__modalTitle']");
        

    }
    async clickOnAddActivity() {
        await helper.click(this.addActivity);
    }

    async withActivityTypeByText(type) {
        await helper.selectDropdown(this.activityType,this.activityTypeOption,type);
    }
    async withDueTomorrowDate(){
        var date = moment().add(1,'day');
        var futureDate = date.format('ll');
        await helper.typeText(this.addActivityDueDateInput,futureDate);

    }
    async withDescription(){
        await helper.typeText(this.addActivityDescInput,'Meet with Insured')
    }
    async withSubject(subject) {
        await helper.typeText(this.activitySubject, subject);
    }
    async submit() {
        await helper.click(this.addBtn);
    }

    async addFutureActivityFromActivityTile(activityFuture) {
        await this.clickOnAddActivity();
        await assert.elementPresent(this.addActivityDetails, 'Add Activity details are not displayed');
        await this.withActivityTypeByText(activityFuture.type);
        await this.withSubject(activityFuture.subject);
        await this.submit();
       await alert.closeAlert();

    }

    async addDueTomorrowActivityFromActivityTile(activityDue){
        await this.withActivityTypeByText(activityDue.type);
        await this.withDueTomorrowDate();
        await this.withSubject(activityDue.subject);
        await this.submit();
        await alert.closeAlert();
    }
    async addActivityFromActivityTile(type,subject) {
        await this.withActivityTypeByText(type);
        await this.withSubject(subject);
        await this.submit();
    }
    async addDefaultActivity() {
        await this.addActivityFromActivityTile('Meet with Insured','Producer meets with Insured');
        await alert.closeAlert();
    
    }
    async clickOnFirstActivity() {
        await helper.click(this.firstActivityInSchedule);
    }
    async clickCancelButton() {

        await helper.click(this.cancelBtn);
    }
    async isAddActivityComponentVisible() {
        await assert.elementNotPresent(this.addActivitySelector, 'Activity is still displayed');
    }
    async isAddedActivityComponentVisible(subject){
        await assert.elementPresent(this.subject,'Activity is not listed')
    }
    async isAddedActivityComponentNotVisible(){
        await assert.elementNotPresent(this.subject,'Activity is listed');
    }
    async addActivityThanCancelSubmition(type, subject) {
        await this.withActivityTypeByText(type);
        await this.withSubject(subject);
        await this.clickCancelButton();
    }
    async validateActivityScheduleUIComponent() {
        await assert.elementPresent(this.activityFilter, 'Activity filter is not present on UI');
        await assert.elementPresent(this.activitySearch, 'Activity search is not present on UI');
        await assert.elementPresent(this.addActivity, 'Add Activity button is not present on UI');
    }
    async validateActivityFilterValues() {
        var expectedStatusList = ["All Open", "All Completed","Overdue Only", "Open, Assigned to me"];
        await helper.click(this.activityFilter);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("div[id='LOBFilter'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var actualStatusList =await dropDownValues();
        actualStatusList.splice(0,1);
        console.log(actualStatusList);
        if (JSON.stringify(expectedStatusList) == JSON.stringify(actualStatusList))
            return true;
        else
            return false;

    }
async validatedActivityRowUIComponent(){
    await assert.elementPresent(this.priority,'Priority element is not present');
    await assert.elementPresent(this.dueDate,'Due date element is not present ');
    await assert.elementPresent(this.subject,'Subject element is not present');
    await assert.elementPresent(this.assignee,'Assignee element is not present');
    await assert.elementPresent(this.notes,'Notes element is not present');
   
}
async isChooseActivityTypeErrorModalShown(modalErrorMsg){
    await assert.assertEqual(await helper.getTextAtLocator(this.modalHeader),modalErrorMsg,'Error Modal for an Activity is not displayed');
}

async wasActivityCreatedModalDisplayed(CreatedMsg){
    await assert.assertEqual(await helper.getTextAtLocator(this.modalHeader),CreatedMsg,'Alert message incorrect or missing')
}

}
