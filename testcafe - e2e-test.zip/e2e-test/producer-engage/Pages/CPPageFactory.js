import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';
import CommonLocators from "../../Utilities/CommonLocators";
import HOPaymentDetailsPage from "../Pages/HOPaymentDetailsPage";

const data = require('../Data/PE_PA_Data.json');
const dataCP = require('../Data/PE_CP_Data.json');


const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
const common = new CommonLocators();
const hoPayment = new HOPaymentDetailsPage();

export default class CPPageFactory {


    constructor() {
        this.email = Selector("[id='email']");
        this.emailError = Selector("[id*='email'][role='alert']");
        this.phoneNum = Selector("[id='phone']");
        this.phoneNumError = Selector("[id*='phone'][role='alert']");
    }

    async setEmailField(input) {
        await helper.typeText(this.email,input);
    }
    async setPhoneField(phone) {
        await helper.typeText(this.phoneNum,phone);
    }
    async setDataTillCPPolicyInfoAndGoNext(data) {
        await this.setEmailField(data.Email);
        await this.setPhoneField(data.Phone);
    }
    async setDataTillCPPaymentAndGoNext(data) {
        await hoPayment.setAccountNumber(data.AccountNumber);
        await hoPayment.setABARoutingNumber(data.RoutingNumber);
        await hoPayment.setBankName(data.BankName);
        await common.goNext();
    }
    async mandatoryValidationOnPolicyInfoPage(data){
        await this.setEmailField(data.Email);
        await helper.removeText(this.email);
        await helper.pressTab();
        await assert.assertEqual(await helper.getTextAtLocator(this.emailError),'This is a required field', "This is not a required field");
       await this.setPhoneField(data.Phone);
        await helper.removeText(this.phoneNum);
        await helper.pressTab();
        await assert.assertEqual(await helper.getTextAtLocator(this.phoneNumError), 'This is a required field', "This is not a required field");
    }
  






}
