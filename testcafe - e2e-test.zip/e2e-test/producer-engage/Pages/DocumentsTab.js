import { Selector,ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';

const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
var document;
const DOC_NAME_HEADER = 'Name';
const DOC_UPLOADED_HEADER = 'Date Uploaded';
const DOC_REMOVE_HEADER = 'Remove';
var docName = "a[href*="+document+"]";
export default class DocumentsTab {
    constructor() {
        this.uploadButton =Selector("h2[id='documentsTitleId'] [type='button']");
        this.uploadDocInput = Selector(" input[id='uploadDocumentsId']");
        this.firstDocName = Selector("[class='rt-table'] [class*='tableCell'] a").nth(0);
        this.doclink= Selector("[class='rt-table'] [class*='tableCell'] a").nth(0);
        this.searchField = Selector("#search");
        this.docHeader = Selector("[title='Name']");
        this.dataUploadedHeader = Selector("[title='Date Uploaded']");
        this.removeHeader = Selector("[title='Remove']");
        this.deleteDocButton =Selector("i[class='fas fa-trash']");
        this.docTable = Selector("[class*='module__tableRowGroup']");
        this.clickYes=Selector("[class*='modalFooter'] [class*='Button-module__primary']");
    }
    async clickUploadButton(){
        await helper.click(this.uploadButton);
    }
    async uploadFile(filepath){
        await helper.uploadFile(this.uploadDocInput,filepath);
    }
    async isDocAdded(fileName){
        var docName =  await this.firstDocName.innerText;
        await assert.assertEqual(docName,fileName,'Document is not attached')
    }
    async validateDocTileElements(){
        await assert.elementPresent(this.uploadButton,'Upload button is not present');
        await assert.elementPresent(this.searchField,'Search Field is not present');
        await assert.assertEqual(this.docHeader.innerText,DOC_NAME_HEADER,'Document Header is incorrect');
        await assert.assertEqual(this.dataUploadedHeader.innerText,DOC_UPLOADED_HEADER,'Data uploaded field header is incorrect');
        await assert.assertEqual(this.removeHeader.innerText,DOC_REMOVE_HEADER,'Remove header is incorrect');
   }

    async validatePolicyDocumentDataWithBackEnd(docNameFromBackend,filename){
        await assert.assertEqual(docNameFromBackend,filename,'File name does not match');
    }
    async deleteDoc(){
        await helper.click(this.deleteDocButton);
        await modal.confirm(); //selector to be changed
    }
    async ValidateDocDeleted(){
        await assert.elementNotPresent(this.docTable,'Document table is present');
        await assert.elementNotPresent(this.searchField,'Search Field is present');
    }
    async downloadDoc(){
        await helper.click(this.doclink);
    }
}