import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const data = require('../Data/PE_Data.json');

const helper = new Helper();
const assert = new Assertion();
export default class AnalyticsLanding {
    constructor() {
        this.title = Selector("h2[id='analyticsPageTitle']");
        this.defaultTitle = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.LossTile = Selector("[class*='TileComponent_gwTileTitle']").nth(1);
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.analyticsTitle, 'Analytics landing page title mismatch');
    }
    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, data.analyticsDefaultTitle, 'Growth was not default tile');
    }
    async checkTile() {
        await assert.assertEqual(this.LossTile.innerText, data.analyticsTile, 'Loss Ratios tile is not displayed on Analytics page');
    }
}