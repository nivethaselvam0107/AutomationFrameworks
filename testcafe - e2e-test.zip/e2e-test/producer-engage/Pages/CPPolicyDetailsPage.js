import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from '../Data/DataFetch';
const fromEntries = require('fromentries')
const data = require('../Data/PE_PA_Data.json');
const dataCP = require('../../producer-engage/Data/PE_CP_Data.json');
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import Tiles from './Tiles';
const polichangeCp = require("../Data/PE_PolicyChange_Data.json")


const dataFetch = new DataFetch();
const helper = new Helper();
const assert = new Assertion();
const DOC_NAME_HEADER = 'NAME';
const DOC_UPLOADED_HEADER = 'DATE UPLOADED';
const DOC_REMOVE_HEADER = 'REMOVE';
const policyGen = new PolicyGenerator();
const tiles = new Tiles()
var QUOTE_ALERT_INCREASE_MSG = "There is an increase in the premium\n" +
    "The new premium is now $newPremium.00. This is an increase of $changePremium.00 on the current premium and will be reflected in upcoming invoices.";
var QUOTE_ALERT_DECREASE_MSG = "There is a decrease in the premium\n" +
    "The new premium is now $newPremium.00. That is $changePremium.00 less than the current premium and will be reflected in upcoming invoices.";
var QUOTE_ALERT_NO_CHANGE_MSG = "There are no changes to the premium.\n" +
    "The changes you've made to the policy don't affect the premium.";

export default class CPPolicyDetailsPage {
    constructor() {
        this.coverage_Start_Date = Selector("[id='coverageStartDate']");
        this.coverage_Start_Date_Val_Error = Selector("div[id*='coverageStartDate'][role='alert']");
        this.orgType_Select = Selector("[id='cpOrganizationType']");
        this.orgType_Option = Selector("[id='cpOrganizationType'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.pageTitle = Selector("[class*='WizardPageHeader_gwWizardPageTitle']");
        this.accNumLink = Selector("[class*='WizardPageHeader_gwWizardPageAssociated']");
        this.policyChangeEffDate = Selector("#cpEffectiveDate");
        this.policyChangeDescription = Selector("#cpPolicyChangeDescription");
        this.newPremium = Selector("[class*='gw-alert'] strong:nth-of-type(1)");
        this.alertContent = Selector("#detailMessageContainer");
        this.changeInPremium = Selector("[class*='gw-alert'] strong:nth-of-type(2)");
        this.changeButton = Selector("#transactionButton");
        this.spreadPayment = Selector("#existingPlanBoxContent");
        this.printQuoteBtn = Selector("#quoteDetails");
        this.ABARoutingNumber = Selector("#abaNumber");
        this.AccountNumber = Selector("#accountNumber");
        this.BankName = Selector("#bankName");
        this.viewPolicyBtn = Selector("#viewPolicyButton");
        this.payInFullBtnCss = Selector("#payButton");
        this.nextButton = Selector("button[id='gw-wizard-Next']");
        this.nextBtn_Disabled = Selector("[class*='Button-module__disabled']");
        this.summaryTile = Selector("[class*='TileComponent_gwTileTitle__']").nth(0);
        this.cancelPay = Selector("#cancel");

    }
    async mandatoryErrorValidationInPolicyDetailsPage() {
        await helper.removeRequiredTextAndValidate(this.coverage_Start_Date, this.coverage_Start_Date_Val_Error);

    } async validateNextButtonIsDisabled() {
        await assert.isElementNotClickable(this.nextBtn_Disabled, 'disabled', 'Button is enabled');
    }
    async validateNextButtonIsEnabled() {
        await assert.isElementClickable(this.nextButton, 'enabled', 'Button is Disabled');
    }
    async setCPBOPPolicyDetailPage(orgtype) {
        await helper.selectDropdown(this.orgType_Select, this.orgType_Option, orgtype);
    }
    async setCoverageDate(date) {

        await helper.typeText(this.coverage_Start_Date, date);

    }
    async isCoverageStartFieldMarkedWithInvalidError(error) {
        await assert.assertEqual(await helper.getTextAtLocator(this.coverage_Start_Date_Val_Error), error, "Coverage Start date not marked with error properly");
    }

    async arePolicyDetailsSaved(data) {
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.coverage_Start_Date), data.CoverageDate, "Coverage Date didn't save");
        await assert.assertEqual(await helper.getTextAtLocator(this.orgType_Select), data.OrgType, "Organization type didn't save");

    }
    async validatePageHeaderForPolicyChange(policyType, policyNumber) {
        await assert.hasText(await this.pageTitle.innerText, "Commercial Property " + policyNumber, 'lob is missing');
        await assert.hasText(policyType, 'Policy Change ', 'jobname missing');
        await assert.elementPresent(this.accNumLink, 'account link not present');
    }
    async validatePresenceOfAllFields(policyType) {
        await assert.elementPresent(this.orgType_Select, 'Organisation type field is missing');
        await assert.elementPresent(this.policyChangeDescription, 'Description field is missing');
        await assert.elementPresent(this.policyChangeEffDate, 'Effective date field is missing');
    }
    async validatePolicyChangeJobStatus(policyNum, Status) {
        var data = await dataFetch.getPolicyChangeData(policyNum);
        var status = data.status
        await assert.assertEqual(status, Status, 'The status didnt match backend');
    }
    async setOrgType(value) {
        await helper.selectDropdown(this.orgType_Select, this.orgType_Option, value);
    }
    async validatePolicyDetailsWithBackend(policyNum, orgType) {
        var data = await dataFetch.getPolicyChangeData(policyNum);
        var orgTyp = data.lobData.commercialProperty.accountOrgType;

        await assert.assertEqual(orgTyp, orgType, 'organisationtype are not equal');
    }

    async  validateTransactionQuotePageForIncrease(policyNum) {
        var data = await dataFetch.getPolicyChangeData(policyNum);
        var totalPremium = data.totalCost.amount;
        var premiumChange = data.transactionCost.amount + 0;
        var alertText = await helper.getTextAtLocator(this.alertContent);
        var expectAlert = QUOTE_ALERT_INCREASE_MSG.replace('newPremium', totalPremium).replace('changePremium', premiumChange);
        await assert.assertEqual(alertText.replace(",", ""), expectAlert, 'The message for increase in premium is not correct');

    }
    async validateTransactionQuotePageForDecrease(policyNum) {
        var data = await dataFetch.getPolicyChangeData(policyNum);
        var totalPremium = data.totalCost.amount;
        var total = await totalPremium;
        var premiumChange = data.transactionCost.amount + 0;
        var premium = await premiumChange.toLocaleString().replace(/-/g, "");
        var alertText = await this.alertContent.innerText;
        var expectAlert = QUOTE_ALERT_DECREASE_MSG.replace('newPremium', total).replace('changePremium', premium);
        await assert.assertEqual(alertText.replace(",", ""), expectAlert, 'The message for decrease in premium is not correct');

    }

    async clickViewPolicyChangeBtn() {
        await helper.click(this.changeButton);

    }

    async validateBuildingOnPolicy(policyNum, data) {
        var agentData = await policyGen.getAgentPolicy(policyNum);
        var lineGenCoveIteration = agentData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        let lineCoverage = new Map();
        for (var i = 0; i < baseCovCount; i++) {
            var covItr = lineGenCoveIteration[i];
            if ((covItr.name).split(": ")[1] == data.BuildingDescription) {
                lineCoverage.set('buildingDescriptionPresent', 'true');
                var buildingCovCount = covItr.coverages.length;
                for (var j = 0; j < buildingCovCount; j++) {
                    var newCovItr = covItr.coverages[j];
                    var name = newCovItr.name;
                    if (name == "Business Personal Property Coverage") {
                        lineCoverage.set('Business_Personal_Property_Limit', newCovItr.terms[0].amount);
                    }
                    if (name == "Building Coverage") {
                        lineCoverage.set('Building_Limit', newCovItr.terms[2].amount);
                    }
                }
            }
            if (covItr.name.includes('Location')) {
                lineCoverage.set('New_Location', (covItr.name).split(": ")[1]);
            }
            else {
                lineCoverage.set('buildingDescriptionPresent', 'false');
            }
        }
        let obj = fromEntries(lineCoverage);
        await assert.assertEqual(obj.Business_Personal_Property_Limit, data.PersonalLimit, 'Business Personal Property limit is incorrect');
        await assert.assertEqual(obj.Building_Limit, data.BuildingLimit, 'Building Limit is incorrect')
    }
    async validateBuildingLimitOnCPPolicyChange(policyNum, data) {
        var agentData = await policyGen.getAgentPolicy(policyNum);
        var lineGenCoveIteration = agentData.coverables;
        var baseCovCount = lineGenCoveIteration.length;
        let lineCoverage = new Map();
        for (var i = 0; i < baseCovCount; i++) {
            var covItr = lineGenCoveIteration[i];
            if ((covItr.name).split(": ")[1] == data.BuildingDescription) {
                lineCoverage.set('buildingDescriptionPresent', 'true');
                var buildingCovCount = covItr.coverages.length;
                for (var j = 0; j < buildingCovCount; j++) {
                    var newCovItr = covItr.coverages[j];
                    var name = newCovItr.name;
                    if (name == "Business Personal Property Coverage") {
                        lineCoverage.set('Business_Personal_Property_Limit', newCovItr.terms[0].amount);
                    }
                    if (name == "Building Coverage") {
                        lineCoverage.set('Building_Limit', newCovItr.terms[2].amount);
                    }
                }
            }
            if (covItr.name.includes('Location')) {
                lineCoverage.set('New_Location', (covItr.name).split(": ")[1]);
            }
            else {
                lineCoverage.set('buildingDescriptionPresent', 'false');
            }
        }
        let obj = fromEntries(lineCoverage);
        await assert.assertEqual(obj.Building_Limit, data.BuildingLimit, 'Building Limit is incorrect')
    }


    async isBuildingPresentOnPolicyOnBackend(policyNum, data, buildingdesc) {
        await this.validateBuildingOnPolicy(policyNum, data);
        await assert.assertNotEqual(buildingdesc, buildings.Building_Description, 'desc should not be equal ');
    }
    async validateTransactionQuotePageForNoChange() {
        var alertText = await this.alertContent.innerText;
        await assert.assertEqual(alertText, QUOTE_ALERT_NO_CHANGE_MSG, 'The message is not correct');


    }
    async BuildingPresentOnPolicyOnBackend(policyNum, data, buildingdesc) {
        await this.validateBuildingOnPolicy(policyNum, data, buildingdesc);
        await assert.assertEqual(buildingdesc, buildings.Building_Description, 'desc should not be equal ')
    }
    async validateNewLocationOnCPBOPolicy(policyNum, data, buildingdesc, Location) {
        await this.validateBuildingOnPolicy(policyNum, data, buildingdesc, Location);
        await assert.assertEqual(Location, buildings.Location, 'desc should not be equal ')

    }
    async clickSpreadPayments() {
        await helper.click(this.spreadPayment);
    }
    async isCPQuotePageLoaded() {
        await assert.elementPresent(this.printQuoteBtn, 'quote page  not opened');
    }
    async clickPay() {
        await helper.click(this.payInFullBtnCss);
    }
    async setABARoutingNumber(data) {
        await helper.typeText(this.ABARoutingNumber, data)

    }
    async setAccountNumber(data) {
        await helper.typeText(this.AccountNumber, data);
    }
    async setBankName(data) {
        await helper.typeText(this.BankName, data);

    }
    async clickViewPolicyBtn() {
        await helper.click(this.viewPolicyBtn);
    }
    async validateTileOpened() {
        await assert.elementPresent(this.summaryTile, 'tile doesnt exist');
    }
    async cancelPayment() {
        await helper.click(this.cancelPay);
    }
}
