import { Selector,ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from "../Data/DataFetch";
import Modal from '../../Utilities/WidgetComponents/Modal';
const data = require('../Data/PE_PA_Data.json');
const dataFetch = new DataFetch();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
const DOC_NAME_HEADER = 'NAME';
const DOC_UPLOADED_HEADER = 'DATE UPLOADED';
const DOC_REMOVE_HEADER = 'REMOVE';
export default class ClaimSummaryDocumentsTab {
    constructor() {
        this.uploadButton = Selector("div[id='uploadDocumentsDiv'] button");
        this.uploadDocInput = Selector("input[id='uploadDocumentsId']");
        this.secondDocName = Selector("[class='rt-table'] [class*='tableCell'] span").nth(2);
        this.doclink= Selector("[list='filteredDocuments'] [title='Name'] a");
        this.searchField = Selector("#search");
        this.docHeader = Selector("[title='Name']");
        this.docName = Selector("[class*='rt-td DataTable-module__tableCell']");
        this.dataUploadedHeader = Selector("[title='Date Modified']");
        this.removeHeader = Selector("[title='Remove']");
        this.deleteDocButton = Selector("i[class*='fas fa-trash ClaimDetails_document_icon_']");
        this.docTable = Selector("[class='rt-tr-group DataTable-module__tableRowGroup__HT_AP']");
        this.docdateModifiedHeader = Selector("[class*='rt-td DataTable-module__tableCell__']").nth(1);
        this.docViewIcon = Selector("i[class='fas fa-file']");
        this.docRemoveIcon = Selector("i[class*='fas fa-trash ClaimDetails_document_icon_']");
        this.notesTab = Selector("[id*='notesTab_']");

     }
    async clickUploadButton(){
        await helper.click(this.uploadButton);
    }
    async uploadFile(filepath){
        await helper.uploadFile(this.uploadDocInput,filepath);
    }
    async isDocAdded(fileName){
        var docName =  await this.secondDocName.innerText;
        await assert.assertEqual(docName,fileName,'Document is not attached')
    }
    async openNoteTab(){
        await helper.click(this.notesTab)
    }

    async validatePolicyDocumentDataWithBackEnd(docNameFromBackend,filename){
        await assert.assertEqual(docNameFromBackend,filename,'File name does not match');
    }
    async validateDocPageElementsOnClaimSummary(){
        await assert.elementPresent(this.uploadButton,'Upload Document button is not present');
        await assert.elementPresent(this.searchField,'Search Document field is not present');
        await assert.elementPresent(this.docHeader,'Document name header is not presented');
        await assert.elementPresent(this.docdateModifiedHeader,'Document data modified header is not present');
        await assert.elementPresent(this.docViewIcon,'Document view icon is not presented');
        await assert.elementPresent(this.docRemoveIcon,'Document remove icon is not present');

    }
    async validateDocTileElements(){
        await assert.elementPresent(this.uploadButton,'Upload button is not present');
        await assert.elementPresent(this.searchField,'Search Field is not present');
        await assert.assertEqual(this.docHeader.innerText,DOC_NAME_HEADER,'Document Header is incorrect');
        await assert.assertEqual(this.dataUploadedHeader.innerText,DOC_UPLOADED_HEADER,'Data uploaded field header is incorrect');
        await assert.assertEqual(this.removeHeader.innerText,DOC_REMOVE_HEADER,'Remove header is incorrect');
    }
    async deleteDoc(){
        await helper.click(this.deleteDocButton);
        await modal.confirm();
    }
    async isDocTableEmpty(){
        await assert.elementNotPresent(this.docTable,'Document table is present');
        await assert.elementNotPresent(this.searchField,'Search Field is present');
    }
    async downloadDoc(){
        await helper.click(this.doclink);
    }
    async getClaimDocumentDataFromBackEnd(claimNumber){
        var data = await dataFetch.getAgentClaimData(claimNumber);
        var count = data.documents.length;
        var documentData= [];
        for(var i=0;i<count;i++){
            documentData.push((data.documents[i].name).split('.')[0]);
        }
        return documentData;
    }

    async getClaimDocumentNamesFromUI(){
            var docNames = ClientFunction(() => {
            var documents = document.querySelectorAll("[class='rt-tr-group DataTable-module__tableRowGroup__HT_AP']");
            var docName = [];
            for (var doc of documents)
              docName.push((doc.textContent).split('.')[0]);
            return docName;
        });
        var docs = []
        docs = await docNames();
        return docs;

       var uiValue=[]
       var data=  await helper.getTextAtLocator(this.firstDocName);
       uiValue.push(data);
       return uiValue
    }

    async validateClaimDocumentDataWithBackEnd(uiValue,backendValue){
        if(JSON.stringify(uiValue)==JSON.stringify(backendValue))
            return true;
        else
            return false;
    }


}
