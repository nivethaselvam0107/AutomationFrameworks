import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Modal from "../../Utilities/WidgetComponents/Modal";
import Assertion from "../../Utilities/Assertions";
import PropertyLocationModel from "../Pages/PropertyLocationModel"
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();
const propertyLocation = new PropertyLocationModel();
const addPersonalProperty = "[id='scheduleItemContainer'] button";

export default class HOQuotePage {
    constructor() {

        this.buy_Policy_Btn = Selector("[id*='buyNowButton']");
        this.submissionNumber = Selector("div[class*='WizardPageHeader_gwWizardPageTitle'] div").nth(1);
        this.scheduledPropertySelect = Selector("[id='ArticleType']");
        this.scheduledPropertyOption = Selector("[id='ArticleType'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.addPersonalPropertyValue = Selector("[id='ArticleLimit']");
        this.scheduledPropertyDescription = Selector("[id='SchedItemDescriptionId']");
        this.scheduledPropertyDeductibleSelect = Selector("[id='ArticleDeductible']");
        this.scheduledPropertyDeductibleOption =  Selector("[id='ArticleDeductible'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.scheduledPropertyValuationMethod = Selector("[id='ArticleValuationMethod']");
        this.scheduledPropertyValuationMethodOption = Selector("[id='ArticleValuationMethod'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.recalculate_Btn = Selector("[id*='recalculateButton']");
        this.addScheduledProperty = Selector("button[class*='Table-hashed__gwTableButtonSize'][on-click*='add']");
        this.editScheduledProperty = Selector("[id='scheduleItemContainer']").find("[class*='fas fa-pen']");
        this.deleteScheduledProperty = Selector("[id='scheduleItemContainer']").find("[class*='fas fa-trash']");
        this.saveScheduledProperty = Selector("tr[class*='scope'] button[on-click='doneEditing(scheduledItem)']");
        this.scheduledProperty_AddButton = Selector("[class*='ScheduleItemModalPopover_buttonContainer'] button").nth(1);
        this.personalPropertyType = Selector("[id='LimitId']");
        this.personalPropertyType_Option=Selector("[id='LimitId'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.hoScheduledPropertyValue = Selector("[id='SchedItemValueId']");
        
    }
    

    async buyBasePolicyWithMonthlyPremium() {
        await helper.click(this.buy_Policy_Btn);
    }
    async getSubmissionNumber() {
        var submission = await helper.getTextAtLocator(this.submissionNumber);
        var quoteNumber = submission.replace(/\D+/g, "");
        return quoteNumber;

    }
    async addScheduledPersonalProperty(data) {
        await helper.click(Selector(addPersonalProperty));
        await this.addScheduledPersonalPropertyType(data.ScheduledType);
        await this.addScheduledPersonalPropertyValue(data.ScheduledValue);
        await this.addScheduledPersonalPropertyDeductible(data.ScheduledDeductible);
        await this.addScheduledPersonalPropertyValuation(data.ScheduledValuation);
        await this.submitScheduledPersonalProperty();
    }

    async editScheduledPersonalProperty(data) {
        await helper.click(this.editScheduledProperty);
        await this.addScheduledPersonalPropertyType(data.ScheduledType);
        await this.submitScheduledPersonalProperty();
        await this.clickRecalculate();
    }
    async clickAddScheduledPersonalProperty(data) {
        await helper.click(Selector(addPersonalProperty).nth(data.Value));
    }
    async addScheduledPersonalPropertyType(type) {
        await helper.selectDropdown(this.scheduledPropertySelect,this.scheduledPropertyOption,type);
    }
    async addScheduledPersonalPropertyValue(amt) {
        await helper.typeText(this.addPersonalPropertyValue, amt)
    }
    async addScheduledPersonalPropertyDeductible(deduct) {
        await helper.selectDropdown(this.scheduledPropertyDeductibleSelect,this.scheduledPropertyDeductibleOption,deduct);
    }
    async addScheduledPersonalPropertyValuation(value) {
        await helper.selectDropdown(this.scheduledPropertyValuationMethod,this.scheduledPropertyValuationMethodOption,value);
    }
    async clickRecalculate() {
        await helper.click(this.recalculate_Btn);
        await t.wait(3000);
    }
 
    async submitScheduledPersonalProperty() {
        await helper.click(this.scheduledProperty_AddButton);
    }
    async editFirstHOScheduledPersonalProperty(data) {
        await helper.click(this.editScheduledProperty);
        await this.addScheduledPersonalPropertyType(data.ScheduledType);
        await this.addHOScheduledPersonalPropertyDescription(data.ScheduledDescription);
        await this.submitScheduledPersonalProperty();
        await this.clickRecalculate();
    }
    async deleteFirstProperty() {
        await helper.click(this.deleteScheduledProperty);
        await modal.confirm();
    }
    async addOtherStructures(data) {
        await helper.click(Selector(addPersonalProperty).nth(data.Value));
        await helper.typeText(this.scheduledPropertyDescription,data.ScheduledDescription)
        await helper.selectDropdown(this.personalPropertyType, this.personalPropertyType_Option,  data.Limit);
        await this.submitScheduledPersonalProperty();
    }
    async addHOScheduledPersonalProperty(data) {
        await helper.click(Selector(addPersonalProperty).nth(data.Value));
        await this.addScheduledPersonalPropertyType(data.ScheduledType);
        await this.addHOScheduledPersonalPropertyDescription(data.ScheduledDescription);
        await this.addHOScheduledPropertyValue(data.ScheduledValue);
        await helper.click(this.scheduledProperty_AddButton);
    }
    async addHOScheduledPersonalPropertyDescription(desc) {
        await helper.typeText(this.scheduledPropertyDescription, desc)
    }
    async addHOScheduledPropertyValue(amt) {
        await helper.typeText(this.hoScheduledPropertyValue, amt)
    }
    async editFirstOtherStructureOnPremisesProperty(data){
        await helper.click(this.editScheduledProperty);
        await helper.typeText(this.scheduledPropertyDescription,data.ScheduledDescription)
        await helper.selectDropdown(this.personalPropertyType,this.personalPropertyType_Option, data.Limit);
        await this.submitScheduledPersonalProperty();
        await this.clickRecalculate();
    }
    async addPersonalPropertyAtOtherResidence(data){
        await this.clickAddScheduledPersonalProperty(data);
        await propertyLocation.validateNewLocationPopUp(data);
        await propertyLocation.setIncreasedLimit(data);
        await propertyLocation.fillNewLocationFrom(data);
    }
    async editFirstPersonalPropertyOnOtherPremises(data){
        await helper.click(this.editScheduledProperty);
        await propertyLocation.setIncreasedLimit(data);
        await propertyLocation.addLocation();
        await this.clickRecalculate();
    }
    async addSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data){
        await this.clickAddScheduledPersonalProperty(data);
        await propertyLocation.validateNewLocationPopUp(data);
        await propertyLocation.setIncreasedLimit(data);
        await propertyLocation.setDescription(data);
        await propertyLocation.fillNewLocationFrom(data);
    }
    async editFirstSpecificStructuresAwayFromTheOtherResidencePremisesProperty(data){
        await helper.click(this.editScheduledProperty);
        await propertyLocation.setDescription(data);
        await propertyLocation.setIncreasedLimit(data);
        await propertyLocation.addLocation();
        await this.clickRecalculate();
    }

}