import { Selector } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from "./Tiles";
import PAQuotePage from "./PAQuotePage";
import { verify } from 'crypto';
import Modal from '../../Utilities/WidgetComponents/Modal';

const data = require("../../producer-engage/Data/PE_PA_Data.json")
const helper = new Helper();
const tiles = new Tiles();
const paQuote = new PAQuotePage();
const assert = new Assertion();
const modal = new Modal();
const referedToUWForReviewText = "This quote has been referred to an underwriter for review.";

export default class QuoteSummaryPage {


    constructor() {
        this.continueButton = Selector("[id='continueQuote']");
        this.quoteNumber = Selector("[class*='FormattedHeaderComponent_gwPageTitle']");
        this.quote_Withdraw_Message_Title = Selector("[class*='Modal-module__modalTitle']");
        this.quoteWithdrawStatus = Selector("#infoStatus");
        this.uwMsgTitle = Selector("[class*='UnderwritingComponent_gwWarningContentHeading']");
        this.withdrawQuoteBtn = Selector("#referReviewWithDrawJob");
        this.uwIssueTableHeader1 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(1)");
        this.uwIssueTableHeader2 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(2)");
        this.uwIssueTableHeader3 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(3)");
        this.uwIssueTableHeader4 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(4)");
        this.uwIssueTableHeader5 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(5)");
        this.uwIssueTableHeader6 = Selector("thead tr[class*='digitalRow Table-module__row'] th:nth-child(6)");
    }

    async continueQuote() {
        await helper.click(this.continueButton);
    }
    async getQuoteNumber() {
        var quote = await helper.getTextAtLocator(this.quoteNumber);
        var quoteNumber = quote.replace(/\D+/g, "");
        return quoteNumber;

    }
    async validateQuotePageComponents() {
        await tiles.isTilePresent('Open Activities', 'Open Activities button is not presented');
        await tiles.isTilePresent('Notes', 'Notes button is not presented');
        await tiles.isTilePresent('Summary', 'Summary is not presented');
        await tiles.isTilePresent('Documents', 'Documents is not presented');
        await paQuote.uwIssueValidation(data.TC3571.UWIssueHeader, data.TC3571.UWIssue);



    }

    async withDrawQuote() {
        await helper.click(this.withdrawQuoteBtn);
        await modal.confirm();
    }
    async validateQuoteWithdrawn() {
        const status = await helper.getTextAtLocator(this.quoteWithdrawStatus);
        await assert.assertEqual(status, 'Withdrawn', 'status is not withdrawn');

    }
    async validationReferedToUnderwriteForReviewMessage() {
        await assert.assertEqual(this.uwMsgTitle.innerText, referedToUWForReviewText, 'Refered to Underwriter for review message is incorrect');
        await assert.elementPresent(this.withdrawQuoteBtn, 'Withdrawn button is not present');
    }
    async validationUnderwritingIssuesColumns() {
        await assert.elementPresent(this.uwIssueTableHeader1);
        await assert.elementPresent(this.uwIssueTableHeader2);
        await assert.elementPresent(this.uwIssueTableHeader3);
        await assert.elementPresent(this.uwIssueTableHeader4);
        await assert.elementPresent(this.uwIssueTableHeader5);
        await assert.elementPresent(this.uwIssueTableHeader6);
    }
    async validationUnderwritingIssues(uwIssue,blockStatus){
        var table = Selector("tbody tr[class*='digitalRow Table-module__row']");
        var table_size=await table.count;
        for(var i=1;i<=table_size;i++){
            var final_xpath_short_description = Selector("tbody tr[class*='digitalRow Table-module__row']:nth-child("+i+") td:nth-child(1)");
            var bindBlocked = Selector("tbody tr[class*='digitalRow Table-module__row']:nth-child("+i+") td:nth-child(3)");
            var shortDescription = await final_xpath_short_description.innerText;
            if(shortDescription==uwIssue)
            {
                await assert.assertEqual(await bindBlocked.innerText,blockStatus,'Driver under 25 short decription or program are incorrect.')
            }
        }
    }
}


