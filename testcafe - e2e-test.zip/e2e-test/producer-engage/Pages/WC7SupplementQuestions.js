import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WC7SupplementQuestions{
    constructor() {
        this.nextButton = Selector("[id='gw-wizard-Next']");
    }
    async clickNext() {
        await helper.click(this.nextButton);
    }
}