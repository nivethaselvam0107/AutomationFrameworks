import { Selector, ClientFunction } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import ClaimSummaryPage from './ClaimSummaryPage';
import Login from '../Login';
import moment from 'moment';

const helper = new Helper();
const assert = new Assertion();
const claimSummary = new ClaimSummaryPage();
const login = new Login();



export default class ClaimSummaryNotesTab {
     constructor(){
        this.addNoteButton = Selector("button[id='addNoteButtonId']");
        this.noteSubject = Selector("input[id='subjectField']");
        this.noteBody = Selector("textarea[id='noteField']");
        this.noteSubjectErr = Selector("div[id*='subjectField']");
        this.noteBodyErr = Selector("div[id*='noteField']");
        this.saveNoteButton = Selector("button[id='saveBtnId']");
        this.user = Selector("div[class='rt-table'] [class*='rt-tbody'] span").nth(0);
        this.DateTime = Selector("div[class='rt-table'] [class*='rt-tbody'] span").nth(1);
        this.subject = Selector("div[class='rt-table'] [class*='rt-tbody'] span").nth(2);
        this.note = Selector("div[class='rt-table'] [class*='rt-tbody'] span").nth(3);
        this.noteSearch = Selector("#search");
        this.addNoteSummary=Selector("#addNoteButton")
        
     }
     
     async addNote(){
         await helper.click(this.addNoteButton);
     }

     async addNoteInSummary(){
         await helper.click(this.addNoteSummary);
     }

     async addNoteDetails(details){
         await helper.typeText(this.noteSubject,details.NoteSubject);
         await helper.typeText(this.noteBody,details.NoteBody);
         await this.saveNotes();
     }

     async saveNotes(){
         await helper.click(this.saveNoteButton);
     }
     async searchNote(subject){
         await helper.typeText(this.noteSearch,subject);

     }

     async addANewNote(details){
         await this.addNote();
         await this.addNoteDetails(details);
         await claimSummary.openNoteTab();
     }
     async validateMandatoryFieldsErrorOnNotePage(){
        await assert.elementPresent(this.noteSubjectErr,"Mandatory error message for note subject is not present");
        await assert.elementPresent(this.noteBodyErr,'Mandatory error message for note Body is not present');
        await assert.assertEqual(await helper.getTextAtLocator(this.noteSubjectErr),'This is a required field','Mandatory error message for note subject is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.noteBodyErr),'This is a required field','Mandatory error message for note Body is incorrect');
        
     }

     async validateNotePageElements(details){
         const user = await login.setUserForGPA();
         var date = (moment()).format('MM/DD/YY');
         await assert.elementPresent(this.addNoteButton,"Add Note button is not present");
         await assert.elementPresent(this.noteSearch,'Search Note field is not present');
         await assert.assertEqual(await helper.getTextAtLocator(this.user),user,'Notes author is not correct');
         await assert.assertEqual(await helper.getTextAtLocator(this.subject),details.NoteSubject,'Notes Subject is not correct');
         await assert.assertEqual(await helper.getTextAtLocator(this.note),details.NoteBody,'Notes Body is not correct');
         await assert.hasText(await helper.getTextAtLocator(this.DateTime),date,'Date created is not present');

     }

     async isNotesAdded(details){
         await this.searchNote(details.NoteSubject);
         var user = await login.setUserForGPA();
         console.log(user);
         await assert.assertEqual(await helper.getTextAtLocator(this.user),user,'Notes author is not correct');
         await assert.assertEqual(await helper.getTextAtLocator(this.subject),details.NoteSubject,'Notes Subject is not correct');
         await assert.assertEqual(await helper.getTextAtLocator(this.note),details.NoteBody,'Notes Body is not correct');
    }

    

     

}
