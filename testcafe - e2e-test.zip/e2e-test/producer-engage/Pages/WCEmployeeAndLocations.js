import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WCEmployeeAndLocations {
  constructor() {
    this.addManuallyButton = Selector("#addEmployees");
    this.state = Selector("#stateSearch");
    this.stateOption = Selector("[id='stateSearch'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.employeeClassesValue = Selector("[id='form']").find('td').nth(1);
    this.annualWagesValue = Selector("[id='form']").find('td').nth(2);
    this.addButton = Selector("[id='form'] button").withExactText('Add');
    this.employeeclassesSearch = Selector("#employeeClassSearch");
    this.employeeclassesSearchOption = Selector("div[id='employeeClassSearch'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.annualWagesInput = Selector("#annualWagesField");
    this.addMoreButton = Selector("#wc7AddMoreButton");
    this.editIcon = Selector("[id='form'] i[class*='pen']");
  }
  async clickAddEmployeeClasses() {
    await helper.click(this.addManuallyButton);
  }
  async validateNextButtonDisabled() {
    await assert.isElementNotClickable(this.nextButton, 'disabled', 'Next Button is enabled');
  }
  async validateMandatoryFieldsInAddEmployeeClass(data) {
    await assert.isElementNotClickable(this.addButton, 'disabled', 'Add button is enabled');
    await common.validateNextButtonIsDisabled();
    await this.selectEmployeeClassesSearch(data.EmployeeClass);
    await this.typeAnnualWages(data.AnnualWages);
    await assert.isElementClickable(this.addButton, 'disabled', 'AddButton is disabled');
    await common.validateNextButtonIsEnabled();
  }
  async selectEmployeeClassesSearch(data) {
    await helper.selectDropdown(this.employeeclassesSearch, this.employeeclassesSearchOption, data);
  }
  async selectState(state){
    await helper.selectDropdown(this.state,this.stateOption,state)
  }
  async typeAnnualWages(annualWages) {
    await helper.typeText(this.annualWagesInput, annualWages);
  }
  async clickAdd() {
    await helper.click(this.addButton);
  }
  async clickEmployeeClassEdit(){
    await helper.click(this.editIcon);
  }
  async clickAddMore(){
    await helper.click(this.addMoreButton);
  }

  async editEmployeeClasses(data){
    await this.selectEmployeeClassesSearch(data.EmployeeClassEdited);
    await this.typeAnnualWages(data.AnnualWagesEdited);
    await this.clickAdd();
  }

  async addEmployeeClassManually(data) {
    await this.selectEmployeeClassesSearch(data.EmployeeClass);
    await this.typeAnnualWages(data.AnnualWages);
    await assert.isElementClickable(this.addButton, 'disabled', 'AddButton is disabled');
    await this.clickAdd();
  }
  async validateAddedEmployeeClasses(data){
    await assert.textContains((await helper.getTextAtLocator(this.employeeClassesValue)).replace(/[\n\r\t]/g,'').replace(' - ',": "),(data.EmployeeClass),'Added Employee Class is incorrect');
    await assert.assertEqual((await helper.getTextAtLocator(this.annualWagesValue)).replace(/[\n\r\t]/g,''),data.AnnualWages,'Added Annual Wages is incorrect');
    await assert.elementPresent(this.editIcon,'Edit Icon is not displayed');
    await assert.elementPresent(this.addMoreButton,'Add More button is not displayed');
  }
  async validateEditedEmployeeClasses(data){
    await assert.textContains((await helper.getTextAtLocator(this.employeeClassesValue)).replace(/[\n\r\t]/g,'').replace(' - ',": "),(data.EmployeeClassEdited).slice(6),'Added Employee Class is incorrect');
    await assert.assertEqual((await helper.getTextAtLocator(this.annualWagesValue)).replace(/[\n\r\t]/g,''),data.AnnualWagesEdited,'Added Annual Wages is incorrect');
    await assert.elementPresent(this.editIcon,'Edit Icon is not displayed');
    await assert.elementPresent(this.addMoreButton,'Add More button is not displayed');
  }


}
