import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import moment from 'moment';

const helper = new Helper();
const assert = new Assertion();

export default class PolicyConfirmationPage {
    constructor() {
        this.accountNumber = Selector("[id='accountNumberLink']");
        this.policyNumber = Selector("[id='policyNumberLink']");
        this.cpAccountNumber = Selector("[id='accountNumber'] a");
        this.cpPolicyNumber = Selector("[id='policyNumber'] a");
        this.policyStartDate = Selector("#effectiveDate");
        this.policyPeriod = Selector("#policyPeriod");
        this.policyTotalAmt = Selector("[class*='CurrencyField']").nth(0);
        this.policyPlanName = Selector("[id='paymentPlanName']");
        this.policyCurrentPayment = Selector("[class*='CurrencyField']").nth(1);
        this.vehicleSectionAccordion = Selector("#vehicleAccordion");
        this.driverSectionAccordion = Selector("#driverAccordion");
        this.vehicleSection = Selector("[id='vehicleAccordion'] [role='region']");
        this.driverSection = Selector("[id='driverAccordion'] [role='region']");
        this.contactDetailsSection = Selector("[id='contactAccordion'] [role='region']");
        this.coverageSectionAccordion = Selector("#coverageAccordion");
        this.coverageSection = Selector("[id='coverageAccordion'] [role='region']");
        this.vehicleMake = Selector("[id*='vehicleAccordion']").find('td').nth(0);
        this.vehilceModel = Selector("[id*='vehicleAccordion']").find('td').nth(1);
        this.vehiclePlate = Selector("[id*='vehicleAccordion']").find('td').nth(2);
        this.driverLicenseNumber = Selector("[id*='driverLicenseNumber'][data-read-only='true']");
        this.driverLicenseState = Selector("[id*='driverLicenseState'][data-read-only='true']");
        this.driverLicenseYear = Selector("[id*='yearFirstLicensed'][data-read-only='true']");
        this.account_Num_Details_Page = Selector("[id='accountTilesTitle']");
        this.policy_Num_Details_page = Selector("#policyProductItem");

    }
    async isPolicyConfirmationPageDisplayed() {
        await assert.elementPresent(this.accountNumber, 'Policy confirmation Page is displayed');
    }
    async savePolicyNumber() {
        var POLICY_NUM = await helper.getTextAtLocator(this.policyNumber);
        return POLICY_NUM;
    }
    async goToAccountDetailPage() {

        await helper.click(this.accountNumber);
    }
    async goToCPAccountDetailPage() {
        await helper.click(this.cpAccountNumber);
    }
    async policySummaryConfirmation(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.accountNumber), data.accountNumber, 'Account Number does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyNumber), data.policyNum, 'Policy Number does not match');
        var effMonth = data.policyEffectiveMonth + 1;
        var startDate = effMonth + '/' + data.policyEffectiveDay + '/' + data.policyEffectiveYear;
        var effDate = moment(startDate).format('ll');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyStartDate), effDate, 'Policy effective date does not match');
        var expMonth = data.policyExpirationMonth + 1;
        var endDate = expMonth + '/' + data.policyExpirationDay + '/' + data.policyExpirationYear;
        var expDate = moment(endDate).format('ll');
        const period = effDate + ' - ' + expDate;
        await assert.assertEqual((await helper.getTextAtLocator(this.policyPeriod)).replace(/[\r\n]+/gm, " "), period.replace(/[\r\n]+/gm, " "), 'Policy period does not match');
    }
    async getPolicyNumber() {
        var policyNum = await helper.getTextAtLocator(this.policyNumber);
        return policyNum;
    }
    async getCPPolicyNumber() {
        var policyNum = await helper.getTextAtLocator(this.cpPolicyNumber);
        return policyNum;
    }
    async isAccountDetailPageDisplayed(accountNumber) {

        await assert.textContains(await helper.getTextAtLocator(this.account_Num_Details_Page), accountNumber, "Correct account detail page not displayed")
    }

    async goToPolicyDetailPage() {

        await helper.click(this.policyNumber);
    }
    async goToCPPolicyDetailPage() {

        await helper.click(this.cpPolicyNumber);
    }
    async isPolicyDetailPageDisplayed(policyNumber) {

        await assert.textContains((await helper.getTextAtLocator(this.policy_Num_Details_page)).replace(/[^0-9]+/g,''),policyNumber, "Correct policy detail page not displayed");
    }
    async arePolicyDetailsSectionsCollapsedByDefault() {
        await assert.getAttributeValue(this.vehicleSection, 'aria-expanded', 'false');
        await assert.getAttributeValue(this.driverSection, 'aria-expanded', 'false');
        await assert.getAttributeValue(this.contactDetailsSection, 'aria-expanded', 'false');
        await assert.getAttributeValue(this.coverageSection, 'aria-expanded', 'false');
    }
    async getVehiclesTableData(data) {
        await helper.click(this.vehicleSectionAccordion);
        await assert.assertEqual((await helper.getTextAtLocator(this.vehicleMake)).replace(/[\n\r\t]/g,''), data.Make, 'Vehicle make does not match');
        await assert.assertEqual((await helper.getTextAtLocator(this.vehilceModel)).replace(/[\n\r\t]/g,''), data.Model, 'Vehicle model does not match');
        await assert.assertEqual((await helper.getTextAtLocator(this.vehiclePlate)).replace(/[\n\r\t]/g,''), data.LicensePlate, 'Vehicle license plate does not match');
    }
    async getDriverTableData(data) {
        await helper.click(this.driverSectionAccordion);
        await assert.assertEqual((await helper.getTextAtLocator(this.driverLicenseNumber)).replace(/[\n\r\t]/g,''), data.DriverLicenseNum, 'Driver license number does not match');
        await assert.assertEqual((await helper.getTextAtLocator(this.driverLicenseYear)).replace(/[\n\r\t]/g,''), data.FirstYearLicensed, 'Driver first licensed year does not match');
    }
    async getCoverageData() {
        await helper.click(this.coverageSectionAccordion);
        var elements = Selector("[id='coverageAccordion'] table[class*='Table-module'] tbody tr");
        var rows = await elements.count;
        let coverageTest = new Map();
        for (var i = 1; i <= rows; i++) {
            var covName = "[id='coverageAccordion'] tbody tr[class*='digitalRow Table-module__row']:nth-child(" + i + ") td:nth-child(1)";
            var amt = await helper.getTextAtLocator(Selector("[id='coverageAccordion'] tbody tr[class*='digitalRow Table-module__row']:nth-child(" + i + ") td:nth-child(2)"));
            var limit = amt.replace('$', '');
            coverageTest.set(await helper.getTextAtLocator(Selector(covName)), limit);
        }
        return coverageTest;
    }
    async compareCoverageData(data) {
        const response = await this.getCoverageData();
        await assert.assertEqual(response.get('Uninsured Motorist - Bodily Injury'), parseFloat(data.lobData.personalAuto.offerings[0].coverages.lineCoverages[0].amount.amount).toFixed(2), 'Uninsured motorist bodily injury coverage does not match');
        await assert.assertEqual(response.get('Uninsured Motorist - Property Damage'), parseFloat(data.lobData.personalAuto.offerings[0].coverages.lineCoverages[1].amount.amount).toFixed(2), 'Uninsured motorist property damage coverage does not match');
        await assert.assertEqual(response.get('Mexico Coverage - Limited'), parseFloat(data.lobData.personalAuto.offerings[0].coverages.lineCoverages[2].amount.amount).toFixed(2), 'Mexico coverage limited coverage does not match');
        await assert.assertEqual(response.get('Medical Payments'), parseFloat(data.lobData.personalAuto.offerings[0].coverages.lineCoverages[3].amount.amount).toFixed(2), 'Medical Payments coverage does not match');
        await assert.assertEqual(response.get('Liability - Bodily Injury and Property Damage'), parseFloat(data.lobData.personalAuto.offerings[0].coverages.lineCoverages[5].amount.amount).toFixed(2), 'Liability - Bodily Injury and Property Damage coverage does not match');
    }
}

