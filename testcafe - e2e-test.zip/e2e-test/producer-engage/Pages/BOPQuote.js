import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
import DataFetch from '../Data/DataFetch';
const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const modal = new Modal();
const dataFetch = new DataFetch();
var newPremium;
var changePremium;
const alertDecreaseHeader = 'There is a decrease in the premium';
const alertContentDecreaseMsg = 'The new premium is now $'+newPremium+'. That is $'+changePremium+' less than the current premium and will be reflected in upcoming invoices.';
const alertIncreaseHeader = 'There is an increase in the premium';
const alertContentIncreaseMsg = 'The new premium is now $'+newPremium+'. This is an increase of $'+changePremium+' on the current premium and will be reflected in upcoming invoices.'
const alertNoIncreaseHeader = 'There are no changes to the premium.';
const alertContentNoIncreaseMsg = "The changes you've made to the policy don't affect the premium.";

export default class BOPQuote {
    constructor() {
        this.title = Selector("#bopQuotePage");
        this.editCoverages = Selector("a[id='editCoveragesLink']");
        this.cancelButton = Selector("#gw-wizard-cancel");
        this.decreasePremiumHeader = Selector('#messagePremiumDecrease');
        this.decreasePremiumContent = Selector("#messagePremiumNewDecrease");
        this.increasePremiumHeader = Selector('#messagePremiumIncrease');
        this.increasePremiumContent = Selector("#messagePremiumNewIncrease");
        this.noChangesPremiumHeader = Selector('#messagePremiumNoChange');
        this.noChangesPremiumContent = Selector("#messagePremiumNotAffected");
    }
    async clickEditCoverages(){
        await helper.click(this.editCoverages);
    }
    async verifyCancelPrevious() {
        await commonLocators.verifyCancel();
        await commonLocators.verifyPrevious();
    }
    async pressCancelAndConfirm(){
        await helper.click(this.cancelButton);
        await modal.confirm();
    }
    async clickNext() {
        await commonLocators.goNext();
    }
    async validateTransactionQuotePageForIncrease(policyNum){
        var changeData = await dataFetch.getPolicyChangeData(policyNum);
        var totalPremium = changeData.totalCost.amount;
        var previousTotal = changeData.previousTotalCost.amount;
        var taxes = changeData.taxes.amount;
        var premiumIncrease;
        var premiumChange;
        var changeInPremium = changeData.transactionCost.amount;
        if(changeInPremium.toString().includes('-')){
            premiumIncrease = false;
            premiumChange= changeInPremium.replace('-',''); 
        }
        else{
            premiumIncrease= true;
            premiumChange=changeInPremium;
        }
        //await assert.assertEqual(await helper.getTextAtLocator(this.increasePremiumHeader),alertIncreaseHeader,'The Header for increase in premium is not correct')
        //await assert.assertEqual((await helper.getTextAtLocator(this.increasePremiumContent)).replace(',',''),alertContentIncreaseMsg.replace(newPremium,totalPremium.toFixed(2)).replace(changePremium,premiumChange.toFixed(2)),'The message for increase in premium is not correct');
    }
    async validateTransactionQuotePageForDecrease(policyNum){
        var changeData = await dataFetch.getPolicyChangeData(policyNum);
        var totalPremium = changeData.totalCost.amount;
        var previousTotal = changeData.previousTotalCost.amount;
        var taxes = changeData.taxes.amount;
        var premiumDecrease;
        var premiumChange;
        var changeInPremium = changeData.transactionCost.amount;
        if(changeInPremium.toString().includes('-')){
            premiumDecrease = true;
            premiumChange= changeInPremium.toString().replace('-',''); 
        }
        else{
            premiumDecrease= false;
            premiumChange=changeInPremium;
        }
        await assert.assertEqual(await helper.getTextAtLocator(this.decreasePremiumHeader),alertDecreaseHeader,'The Header for increase in premium is not correct')
        await assert.assertEqual((await helper.getTextAtLocator(this.decreasePremiumContent)).replace(',',''),alertContentDecreaseMsg.replace(newPremium,totalPremium.toFixed(2)).replace(changePremium,(parseInt(premiumChange)).toFixed(2)),'The message for increase in premium is not correct');
    }
    async validateTransactionQuotePageForNoChange(){
        await assert.assertEqual(await helper.getTextAtLocator(this.noChangesPremiumHeader),alertNoIncreaseHeader,"The Header for no change isn't correct");
    }
    async isBOPQuotePageLoaded(){
        await assert.elementPresent(this.title,'Quote page does not  load');
    }
  
}