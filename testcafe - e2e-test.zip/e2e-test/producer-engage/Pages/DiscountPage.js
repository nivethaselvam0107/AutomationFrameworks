import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();

export default class DiscountPage {
    constructor() {
        this.fire_Extinguisher=Selector("[id='fireExtinguishers']");
        this.fire_Extinguisher_Yes=Selector("[id='fireExtinguishers'] [data-value='true']");
        this.fire_Extinguisher_No=Selector("[id='fireExtinguishers'] [data-value='false']");
        this.burg_Alarm_Yes=Selector("[id='burglarAlarm'] [data-value='true']");
        this.burg_Alarm_No=Selector("[id='burglarAlarm'] [data-value='false']");
        this.local_Type=Selector("[for='burglarAlarmType_local']");
        this.fire_Alarm_Rep_No=Selector("[id='fireAlarmReportingToMonitoringCenter'] [data-value='false']");
        this.fire_Alarm_Yes=Selector("[id='fireAlarmReportingToMonitoringCenter'] [data-value='true']");
        this.fire_Alarm_No=Selector("[id='fireAlarmReportingToMonitoringCenter'] [data-value='false']");
        this.smokeAlarm_yes=Selector("[id='smokeAlarm'] [data-value='true']");
        this.smokeAlarm_No=Selector("[id='smokeAlarm'] [data-value='false']");
        this.dead_Yes=Selector("[id='deadbolts'] [data-value='true']");
        this.dead_No=Selector("[id='deadbolts'] [data-value='true']");
        this.smoke_Alarm_Yes=Selector("[id='smokeAlarm'] [data-value='true']");
        this.smoke_Alarm_AllFloors=Selector("[id='smokeAlarmOnAllFloors'] [data-value='true']");
        this.deadBolds_yes=Selector("[id='deadbolts'] [data-value='true']");
        this.deadBolds_Count=Selector("[id='numberOfDeadbolts']");
        this.residence_Neighbour_Yes=Selector("[id='residenceVisibleToNeighbors'] [data-value='true']");
        this.sprinkler_System_Select=Selector("[id='sprinklerSystemType'] ");
        this.sprinkler_System_Option=Selector("[id='sprinklerSystemType'] div[class*='TypeaheadMultiSelectField__menu'] div ");
        this.neighbours_Yes=Selector("[id='residenceVisibleToNeighbors'] button[data-value='true']");
        this.neighbours_No=Selector("[id='residenceVisibleToNeighbors'] button[data-value='false']");
        this.mandatory_Field_Discount=Selector("[id='hoDiscountPage']");
    }

    async setFireExtinguishersDetails(fireextinguisher){
        await helper.typeText(this.fire_Extinguisher,fireextinguisher);
    }
    async setHOFireExtinguishersDetails(){
        await helper.click(this.fire_Extinguisher_Yes);
    }
    async setBurgularAlarmAvailability(){
        await helper.click(this.burg_Alarm_Yes);
    }
    async setBurgularAlarmType(){
        await helper.click(this.local_Type);
    }
    async setFireAlarmReportingAvailability(){
        await helper.click(this.fire_Alarm_Yes);

    }
    async setSmokeAlarmAvailability(){
        await helper.click(this.smoke_Alarm_Yes);
    }
    async setSmokeAlarmAllFloor(){
        await helper.click(this.smoke_Alarm_AllFloors);
    }
    async setDeadBoltsAvailability(){
        await helper.click(this.deadBolds_yes);
    }
    async setDeadBoltsCount(count){
        await helper.typeText(this.deadBolds_Count,count);
    }
    async setVisibilityToNeighbours(){
        await helper.click(this.residence_Neighbour_Yes);
    }
    async setSprinklerType(sprinkler){
        await helper.selectDropdown(this.sprinkler_System_Select,this.sprinkler_System_Option, sprinkler);
    }
    async setDiscountPageDetails(dataHO){
        await this.setHOFireExtinguishersDetails();
        await this.setBurgularAlarmAvailability();
        await this.setBurgularAlarmType();
        await this.setFireAlarmReportingAvailability();
        await this.setSmokeAlarmAvailability();
        await this.setSmokeAlarmAllFloor();
        await this.setDeadBoltsAvailability();
        await this.setDeadBoltsCount(dataHO.DeadBoltsCount);
        await this.setVisibilityToNeighbours();
        await this.setSprinklerType(dataHO.SprinklerType);
    }
    async setHOPDiscountPageDetails(dataHO){
        await this.setFireExtinguishersDetails(dataHO.FireExtinguishers);
        await this.setBurgularAlarmAvailability();
        await this.setBurgularAlarmType();
        await this.setFireAlarmReportingAvailability();
        await this.setSmokeAlarmAvailability();
        await this.setSmokeAlarmAllFloor();
        await this.setDeadBoltsAvailability();
        await this.setVisibilityToNeighbours();
        await this.setSprinklerType(dataHO.SprinklerType);

    }
    async isFireAlarmReportingAvailable(data){
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.fire_Extinguisher), data.FireExtinguishers,'Fire Alarm reporting value is not matched');
    }
    
    async isSprinklerTypeEqualsTo(data){
        await assert.assertEqual(await helper.getTextAtLocator(this.sprinkler_System_Select),data.SprinklerType,'Sprinkler type value is not matched');
    }
    async getDiscountPage(){
        await assert.elementPresent(this.mandatory_Field_Discount,'Discount page is not dispalyed');
    }
    async areDiscountPageValueSaved(data){
        await this.isFireAlarmReportingAvailable(data);
        await assert.assertAttributeValue(
            '#burglarAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            data.BurgAlarm,
            'Incorrect value selected for Burglar Alarm'
        );
        await assert.assertAttributeValue(
            '#fireAlarmReportingToMonitoringCenter > [class*="ToggleField-module__active"]',
            'data-value',
            data.MonitoringAlarm,
            'Incorrect value selected for Fire Alarm Reporting To Monitoring Center'
        );
        await assert.assertAttributeValue(
            '#smokeAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            data.SmokeAlarm,
            'Incorrect value selected for Smoke Alarms'
        );
        await assert.assertAttributeValue(
            '#deadbolts > [class*="ToggleField-module__active"]',
            'data-value',
            data.DeadBolts,
            'Incorrect value selected for Deadbolts'
        );
        await assert.assertAttributeValue(
            '#residenceVisibleToNeighbors > [class*="ToggleField-module__active"]',
            'data-value',
            data.Residence,
            'Incorrect value selected for Residence Visible to Neighbours'
        );
        await this.isSprinklerTypeEqualsTo(data);
    }
    async areDiscountPageValueSavedHO(data){
        await assert.assertAttributeValue(
            '#fireExtinguishers > [class*="ToggleField-module__active"]',
            'data-value',
            data.FireExtinguishersValue,
            'Incorrect value selected for Fire Alarm'
        );
        await assert.assertAttributeValue(
            '#burglarAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            data.BurgAlarm,
            'Incorrect value selected for Burglar Alarm'
        );
        await assert.assertAttributeValue(
            '#fireAlarmReportingToMonitoringCenter > [class*="ToggleField-module__active"]',
            'data-value',
            data.MonitoringAlarm,
            'Incorrect value selected for Fire Alarm Reporting To Monitoring Center'
        );
        await assert.assertAttributeValue(
            '#smokeAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            data.SmokeAlarm,
            'Incorrect value selected for Smoke Alarms'
        );
        await assert.assertAttributeValue(
            '#deadbolts > [class*="ToggleField-module__active"]',
            'data-value',
            data.DeadBolts,
            'Incorrect value selected for Deadbolts'
        );
        await assert.assertAttributeValue(
            '#residenceVisibleToNeighbors > [class*="ToggleField-module__active"]',
            'data-value',
            data.Residence,
            'Incorrect value selected for Residence Visible to Neighbours'
        );
        await this.isSprinklerTypeEqualsTo(data);
    }

    async isSmokeAlarmAvailable(){
        if(await this.smokeAlarm_yes.checked){
            var value ='true';
            return value;
           }
           else if(await this.smokeAlarm_No.checked){
               var value = 'false';
               return value;
           }
        }
    async isDeadBoltAvailable(){

        if(await this.dead_Yes.checked){
            var value ='true';
            return value;
           }
           else if(await this.dead_No.checked){
               var value = 'false';
               return value;
           }
        }
    async isResidenceVisibileToNeighbour(){

        if(await this.neighbours_Yes.checked){
            var value ='true';
            return value;
           }
           else if(await this.neighbours_Yes.checked){
               var value = 'false';
               return value;
           }
        }
        async setHODiscountPageDetails(dataHO){
            await this.setHOFireExtinguishersDetails('2');
            await this.setBurgularAlarmAvailability();
            await this.setBurgularAlarmType();
            await this.setFireAlarmReportingAvailability();
            await this.setSmokeAlarmAvailability();
            await this.setSmokeAlarmAllFloor();
            await this.setDeadBoltsAvailability();
            await this.setDeadBoltsCount(dataHO.DeadBoltsCount);
            await this.setVisibilityToNeighbours();
            await this.setSprinklerType(dataHO.SprinklerType);
    
        }


}