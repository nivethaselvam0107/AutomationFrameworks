import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import AlertHandler from './AlertHandler';
import AddNoteComponent from './AddNoteComponent';
import Tiles from './Tiles';
import Login from '../Login';
const helper = new Helper();
const assert = new Assertion();
const tiles = new Tiles();
const login = new Login();
const dataPE = require('../Data/PE_Data.json');
var accountNumber;
var accountNumberLink = "[href*='/accounts/"+accountNumber+"/summary']";
var accountName;
var accountNameLink = "[title='"+accountName+"']";
const addNoteComponent = new AddNoteComponent();
const alert = new AlertHandler();
const activities = "[class='gw-completed']";
const selectAll = "[id*='selectAll']";
const clearAll = "[id*='clearAll']";

export default class ActivitiesLanding {
    constructor() {
        this.activiitysummary = Selector("[class='gw-activity-summary']");
        this.title = Selector("[id='pageTitle']");
        this.defaultTitle = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.yourCompletedTile = Selector("[class*='TileComponent_gwTileTitle']").nth(1);
        this.createdByYouTile = Selector("[class*='TileComponent_gwTileTitle']").nth(2);
        this.allOpenTile = Selector("[class*='TileComponent_gwTileTitle']").nth(3);
        this.allCompletedTile = Selector("[class*='TileComponent_gwTileTitle']").nth(4);
        this.subject = Selector("[class*='subject']  [gw-displaykey-format-replaces='action']");
        this.assignee = Selector("[class*='assignee']");
        this.status = Selector("[class*='completed'] [class*='status'][aria-hidden='false']");
        this.accountName = Selector("[class*='subject']  [ui-sref*='accounts']");
        this.advancedFilterLink = Selector("a[id='advanceFilterLink']");
        this.statusOpenFilter = Selector("span[aria-label='Open']");
        this.statusFilterSectionTitle = Selector("div[class*='ActivityAdvancedFilter_gwFilterSectionTitle']").nth(0);
        this.statusCompleteFilter = Selector("span[aria-label='Complete']");
        this.statusCanceledFilter = Selector("span[aria-label='Canceled']");
        this.statusSkippedFilter = Selector("span[aria-label='Skipped']");
        this.assignmentFilterSectionTitle = Selector("div[class*='ActivityAdvancedFilter_gwFilterSectionTitle']").nth(1);
        this.assignmentToMeFilter = Selector("span[aria-label='To Me']");
        this.assignmentToOthersFilter = Selector("span[aria-label='To Others']");
        this.priorityFilterSectionTitle = Selector("div[class*='ActivityAdvancedFilter_gwFilterSectionTitle']").nth(2);
        this.priorityUrgentFilter = Selector("span[aria-label='Urgent']");
        this.priorityHighFilter = Selector("span[aria-label='High']");
        this.priorityNormalFilter = Selector("span[aria-label='Normal']")
        this.priorityLowFilter = Selector("span[aria-label='Low']");
        this.createdByFilterSectionTitle = Selector("div[class*='ActivityAdvancedFilter_gwFilterSectionTitle']").nth(3);
        this.createdByMeFilter = Selector("span[aria-label='Me']");
        this.createdByOthersFilter = Selector("span[aria-label='Others']");
        this.typeFilterSection = Selector("[advanced-filter='activityTypeFilter']");
        this.typeFilterSectionTitle = Selector("div[class*='ActivityAdvancedFilter_gwFilterSectionTitle']").nth(4);
        this.typeReminderFilter = Selector("label[id*='Reminder']");
        this.typeInterviewFilter = Selector("label[id*='Interview']");
        this.escalationDateLabel = Selector("div[class*='expandableRowWrapper'] [class*='Grid-module'] div").nth(0);
        this.createdByLabel = Selector("div[class*='expandableRowWrapper'] [class*='Grid-module'] div").nth(2);
        this.descriptionLabel = Selector("div[class*='expandableRowWrapper'] [class*='Grid-module'] div").nth(8);
        this.createdDateLabel = Selector("div[class*='expandableRowWrapper'] [class*='Grid-module'] div").nth(6);
        this.typeLabel = Selector("div[class*='expandableRowWrapper'] [class*='Grid-module'] div").nth(4);
        this.completeActivityButton = Selector("div[class*='rt-td DataTable-module']:nth-child(7)").find("button");
        this.addNoteButton = Selector("[id='notesAddButtonIdinShowHide']");
        this.activityRowComponents = Selector("div[class*='rt-td DataTable-module__tableCell']"); 
        

    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, dataPE.activitiesTitle, 'Activities landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, dataPE.activitiesDefaultTitle, 'Your Open is not default tile');
    }

    async isActivitiesLandingPageOpened() {
        await assert.elementPresent(this.defaultTitle,'Activities page is not opened')
    }


    async areActivitiesLandingPageTilesDisplayed() {
        await assert.elementPresent(this.defaultTitle,'My Open tile is not present');
        await assert.elementPresent(this.yourCompletedTile,'Completed By Me tile is not present');
        await assert.elementPresent(this.createdByYouTile,'Created By Me tile is not present');
        await assert.elementPresent(this.allCompletedTile,'All Completed tile is not present');
        await assert.elementPresent(this.allOpenTile,'All Open tile is not present');
    }

    async openAccountUsingAccountNumber(number) {
        var account = accountNumberLink.replace(accountNumber, number);
        await helper.click(Selector(account));
    }

    async goToYourOpenActivities(){
        await helper.click(this.defaultTitle);
    }
    async goToYourCompletedActivities(){
        await helper.click(this.yourCompletedTile);
    }
    async goToCreatedByYouActivities(){
        await helper.click(this.createdByYouTile);
    }
    async goToAllOpenActivities(){
        await helper.click(this.allOpenTile);
    }
    async goToAllCompletedActivities(){
        await helper.click(this.allCompletedTile);
    }

    async validateMyOpenActivitiesData() {
        await this.goToYourOpenActivities();
        await this.compareActivityStatusData('open');
        const assignee = await login.setUserForGPA();
        await this.compareActivityAssigneeData(assignee);
    }
    async validateActivitiesCount(){
        var activityUIData = await this.getActivitiesDataFromUI();
        var activityCountOnTile = await tiles.getCountOnActiveTile();
        await assert.assertEqual((activityUIData.length).toString(),activityCountOnTile, "Count on the tile mismatches with the number of activites");
    }

    async validateMyCompletedActivitiesData() {
        await this.goToYourCompletedActivities();
        await this.compareActivityStatusData('completed');
        const assignee = await login.setUserForGPA();
        await this.compareActivityAssigneeData(assignee);
    }

    async validateCreatedByMeActivitiesData() {
        await this.goToCreatedByYouActivities();
        const creator = await login.setUserForGPA();
        await this.compareActivityCreatedByData(creator);
    }

    async validateAllOpenActivitiesData() {
        await this.goToAllOpenActivities();
        await this.compareActivityStatusData('open');
    }

    async validateAllCompletedActivitiesData() {
        await this.goToAllCompletedActivities();
        await this.compareActivityStatusData('completed');
    }

    async getActivitiesDataFromUI() {
        var elements = Selector("[class*='rt-tr DataTable-module']");
        var count = await elements.count;
        let activityData = [];
        for (var i = 0; i < count; i++) {
            var temp = {};
            var expandActivity = "[class*='fas fa-chevron-right']";
            var assignee = "[class*='rt-tr DataTable-module'] :nth-child(5)";
            temp.assignee = await helper.getTextAtLocator(Selector(assignee).nth(i));
            var accountName = "[class*='rt-tr DataTable-module'] :nth-child(4) a"
            temp.accountName = await helper.getTextAtLocator(Selector(accountName).nth(i));
            var subDetail = "[class*='rt-tr DataTable-module'] :nth-child(4) div";
            var subject = await helper.getTextAtLocator(Selector(subDetail).nth(i));
            temp.subject = await (subject.replace('for '+accountName,"")).replace(/\s\s*$/, '');
            var statusDetail = "[class*='rt-tr DataTable-module'] :nth-child(7)";
            var status = await helper.getTextAtLocator(Selector(statusDetail).nth(i));
            temp.status =  status === "" ? 'open' : 'completed';
            activityData.push(temp);
        }
        return activityData;
    }

    async getCompletedActivitiesDataFromUI() {
        var elements = Selector("[class*='rt-tr DataTable-module']");
        var count = await elements.count;
        let activityData = [];
        for (var i = 0; i < count; i++) {
            var temp = {};
            var expandActivity = "[class*='fas fa-chevron-right']";
            await helper.click(Selector(expandActivity).nth(i));
            var assignee = "[class*='rt-tr DataTable-module'] :nth-child(5)";
            temp.assignee = await helper.getTextAtLocator(Selector(assignee).nth(i));
            var accountName = "[class*='rt-tr DataTable-module'] :nth-child(4) a"
            temp.accountName = await helper.getTextAtLocator(Selector(accountName).nth(i));
            var subDetail = "[class*='rt-tr DataTable-module'] :nth-child(4) div";
            var subject = await helper.getTextAtLocator(Selector(subDetail).nth(i));
            temp.subject = await (subject.replace('for '+accountName,"")).replace(/\s\s*$/, '');
            var statusDetail = "[class*='rt-tr DataTable-module'] :nth-child(7)";
            var status = await helper.getTextAtLocator(Selector(status).nth(i));
            temp.status =  status === "" ? 'open' : 'completed';
            var createdBy = "[class*='DataTable-module__expandableRow'] [class*='Grid-module'] div";
            temp.createdBy = await helper.getTextAtLocator(Selector(createdBy).nth(3));
            await helper.click(Selector(expandActivity).nth(i));
            activityData.push(temp);
        }

        return activityData;
    }


    async compareActivityStatusData(status) {
        let activityUIData = [];
        activityUIData = await this.getActivitiesDataFromUI();
        var numberOfActivities = activityUIData.length;
        var Status = activityUIData.filter(activityUIData => activityUIData.status == status);
        var countOfStatus = Status.length;
        await assert.assertEqual(countOfStatus, numberOfActivities, "All activities are not in" + status + " status");
        return numberOfActivities;
    }

    async compareActivityAssigneeData(uname) {
        let assignee;
        if (uname == 'carkle') {
            assignee = 'Charles Arkle';
        } else if (uname == 'aarmstrong') {
            assignee = 'aarmstrong';
        }
        let activityUIData = [];
        activityUIData = await this.getActivitiesDataFromUI();
        var numberOfActivities = activityUIData.length;
        var assigneeName = activityUIData.filter(activityUIData => activityUIData.assignee == assignee);
        var countOfAssigneeList = assigneeName.length;
        await assert.assertEqual(countOfAssigneeList, numberOfActivities, "Activites does not have correct asignee");
    }

    async compareActivityCreatedByData(uname) {
        let createdBy;
        if (uname == 'carkle') {
            createdBy = 'Charles Arkle';
        } else if (uname == 'aarmstrong') {
            createdBy = 'aarmstrong';
        }
        let activityFutureUIData = [];
        activityFutureUIData = await this.getActivitiesDataFromUI();
        var numberOfOpenActivities = activityFutureUIData.length;
        var createdByName_Open = activityFutureUIData.filter(activityFutureUIData => activityFutureUIData.createdBy == createdBy);
        var countOfcreatedByList_Open = createdByName_Open.length;
        await assert.assertEqual(countOfcreatedByList_Open, numberOfOpenActivities, "Activites does not have correct creator");
        }

    async clickAdvancedFiltersLink() {
        await helper.click(this.advancedFilterLink);
    }

    async validateAllAdvancedFiltersPresent() {
        //validation of status filter section
        await assert.assertEqual(await helper.getTextAtLocator(this.statusFilterSectionTitle),'STATUS','Status Filter section is not displayed');
        await assert.elementPresent(this.statusOpenFilter, 'Open filter is not present under Status section');
        await assert.elementPresent(this.statusCanceledFilter, 'Canceled filter is not present under Status section');
        await assert.elementPresent(this.statusCompleteFilter, 'Complete filter is not present under Status section');
        await assert.elementPresent(this.statusSkippedFilter, 'Skipped filter is not present under Status section');

        //validaton of assignment filter section
        await assert.assertEqual(await helper.getTextAtLocator(this.assignmentFilterSectionTitle),'ASSIGNMENT','Assignment Filter section is not displayed');
        await assert.elementPresent(this.assignmentToMeFilter, 'Assignment to me filter is not present under Assignment section');
        await assert.elementPresent(this.assignmentToOthersFilter, 'Assignment to others filter is not present under Assignment section');

        //validation of Priority Filter Section
        await assert.assertEqual(await helper.getTextAtLocator(this.priorityFilterSectionTitle),'PRIORITY','Assignment Filter section is not displayed');
        await assert.elementPresent(this.priorityUrgentFilter, 'Urgent filter is not present under Priority section');
        await assert.elementPresent(this.priorityHighFilter, 'High filter is not present under Priority section');
        await assert.elementPresent(this.priorityNormalFilter, 'Normal filter is not present under Priority section');
        await assert.elementPresent(this.priorityLowFilter, 'Low filter is not present under Priority section');

        //validation of createdBy filter section
        await assert.assertEqual(await helper.getTextAtLocator(this.createdByFilterSectionTitle),'CREATED BY','Created By Filter section is not displayed');
        await assert.elementPresent(this.createdByMeFilter, 'Created by me filter is not present under Created by section');
        await assert.elementPresent(this.createdByOthersFilter, 'Created by others filter is not present under Created by section');

        //validation of Type Filter Section
        await assert.assertEqual(await helper.getTextAtLocator(this.typeFilterSectionTitle),'TYPE','Type Filter section is not displayed');
        await assert.elementPresent(this.typeReminderFilter, 'Reminder filter is not present under Type section');
        await assert.elementPresent(this.typeInterviewFilter, 'Interview filter is not present under Type section')
        for(var i=0; i<4; i++){
            await assert.elementPresent(Selector(selectAll).nth(i),'Select All link is not present under filter');
        }
        for(var i=0; i<5; i++){
            await assert.elementPresent(Selector(clearAll).nth(i),'Clear All link is not present under filter');
        }


    }

    async isActivityPresentOnAdvancedFiltersPage(Name) {
        var account = accountNameLink.replace(accountName,Name);
        console.log(account);
        await assert.elementPresent(Selector(account),'Activity is not present while it should');
    }

    async clickUrgentFilter() {
        await helper.click(this.priorityUrgentFilter);
    }

    async isActivityNotPresentOnAdvancedFiltersPage(Name) {
        var account = accountNameLink.replace(accountName,Name);
        console.log(account);
        await assert.elementNotPresent(Selector(account),'Activity is present while it should not');
   }



    async addNoteToNonCompleteActivity() {
        await addNoteComponent.withTopic(dataPE.addNoteTopic);
        await addNoteComponent.withSubject(dataPE.activityFuture.subject);
        await addNoteComponent.withNoteText(dataPE.activityFuture.subject);
        await addNoteComponent.submitNote();
        await addNoteComponent.isNodeAddedModalDisplayed(dataPE.activityNoteCreatedMessage);
        await alert.closeAlert();
    }

    async areActivityNoteFieldsAreMarkedWithMandatoryErrors() {
        await addNoteComponent.submitNote();
        await addNoteComponent.areRequiredFieldsMarked();

    }

    async validatedActivityUIComponant() {
        await assert.assertEqual((await helper.getTextAtLocator(this.escalationDateLabel)).trim(), dataPE.ESCALATION_DATE_LABEL, 'Escalation date label is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.createdByLabel)).trim(), dataPE.CREATED_BY_LABEL, 'Created By label is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.descriptionLabel)).trim(), dataPE.DESCRIPTION_LABEL, 'Description label is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.createdDateLabel)).trim(), dataPE.CREATED_LABEL, 'Creation date label is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.typeLabel)).trim(), dataPE.TYPE_LABEL, 'Type label is not matched');
        await assert.elementPresent(this.completeActivityButton, 'Complete activity button is not present');
        await assert.elementPresent(this.addNoteButton, 'Add note button is not present');
    }


    async validatedDueDayActivityRowUIComponant(Name,Day) {
        var account = accountNameLink.replace(accountName,Name);
        await helper.getTextAtLocator(Selector(account).parent(2));
        await assert.elementPresent(Selector(account).parent(2),'Row components: Due day, priority, subject, assignee are not present');
        await assert.elementPresent(Selector(account).parent(2).child('div').withText(Day),'Due date is not present as expected');
        await assert.elementPresent(this.completeActivityButton, 'Complete activity button is not present');
        await assert.elementPresent(this.addNoteButton, 'Add note button is not present');

    }


}

