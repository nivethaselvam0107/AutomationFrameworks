import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';

const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class LeftNavigationMenuHandlerPage {
    constructor() {

        this.driver_Wizard_Link = Selector("[class*='WizardSidebar_navigationButton']").nth(2);
        this.qualification_Wizard_Link = Selector("[class*='WizardSidebar_navigationButton']").nth(1);
        this.Vehicles_Wizard_Link = Selector("[class*='WizardSidebar_navigationButton']").nth(3);
        this.policyDetails = Selector("[class*='WizardSidebar_na']").nth(0);
        this.home_Wizard_Link = Selector("li[class*='WizardSidebar_step']").nth(2);
        this.construction_Wizard_Link = Selector("li[class*='WizardSidebar_step']").nth(3);
        this.bopPolicyDetailsLink = Selector("[class*='WizardSidebar_navigationButton']").nth(0);
        this.bopQualificationLink = Selector("[class*='WizardSidebar_navigationButton']").nth(1);
        this.bopGeneralCoverageLink = Selector("[class*='WizardSidebar_navigationButton']").nth(2);
        this.bopAdditionalCoverageLink = Selector("[class*='WizardSidebar_navigationButton']").nth(3);
        this.bopLocAndBuildLink = Selector("[class*='WizardSidebar_navigationButton']").nth(4);
        this.bopQuoteLink = Selector("[class*='WizardSidebar_navigationButton']").nth(5);
        this.bopAddInfoLink = Selector("[class*='WizardSidebar_navigationButton']").nth(6);
        this.bopPolicyInfoLink = Selector("[class*='WizardSidebar_navigationButton']").nth(7);
        this.bopPaymentDetailsLink = Selector("[class*='WizardSidebar_navigationButton']").nth(8);
    }

    async gotoDriverPage() {
        await helper.click(this.driver_Wizard_Link);
    }
    async gotoQualificationPage() {
        await helper.click(this.qualification_Wizard_Link);
        await modal.confirm();
    }
    async goToVehiclesPage() {
        await helper.click(this.Vehicles_Wizard_Link);
    }
    async gotoYourHomePage() {
        await helper.click(this.home_Wizard_Link);
        await modal.confirm();
    }
    async gotoConstructionPage() {
        await helper.click(this.construction_Wizard_Link);
        await modal.confirm();
    }
    async policyPageDetailsLink() {
        await helper.click(this.policyDetails);
    }
    async goToBOPPolicyDetailsPage(){
        await helper.click(this.bopPolicyDetailsLink);

    }
    async goToBOPQualificationPage(){
        await helper.click(this.bopQualificationLink);

    }
    async goToBOPGeneralCoveragePage(){
        await helper.click(this.bopGeneralCoverageLink);
    }
    async goToBOPAdditionalCoveragePage(){
        await helper.click(this.bopAdditionalCoverageLink);
    }
    async goToBOPLocAndBuildingsPage(){
        await helper.click(this.bopLocAndBuildLink);

    }
}