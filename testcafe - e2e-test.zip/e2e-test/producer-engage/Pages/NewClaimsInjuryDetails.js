import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
const helper = new Helper();
var reportValue;
var lossTimeValue;
var treatment;
var deathReport = "[id='wcInjuryResultInDeath'] [data-value="+reportValue+"]";
var lossTime = "[id='wcInjuryWorkTimeLost'] [data-value="+reportValue+"]";
var medicalTreatment = "[id='wcInjuryOccurredInCourseOfEmployment'] [data-value="+reportValue+"]";
export default class NewClaimInjuryDetails {
    constructor() {
        this.injuryTypeSelect = Selector("[id='wcInjuryType']");
        this.injuryTypeOption = Selector("[id='wcInjuryType'] div[class*='TypeaheadMultiSelectField__menu'] div");

    }
    async selectInjuryType(injuryType){
        await helper.selectDropdown(this.injuryTypeSelect,this.injuryTypeOption,injuryType);
    }
    async setDeathReport(value){
        var deathReportButton = deathReport.replace(reportValue, value);
        await helper.click(Selector(deathReportButton));
    }
    async setLostTimeFromWork(value){
        var lossTimeButton = lossTime.replace(lossTimeValue,value);
        await helper.click(Selector(lossTimeButton));
    }
    async setMedicalTreatment(value){
        var medicalTreatmentButton = medicalTreatment.replace(treatment,value);
        await helper.click(Selector(medicalTreatmentButton));
    }
}
