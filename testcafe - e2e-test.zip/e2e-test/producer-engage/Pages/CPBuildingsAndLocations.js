import { Selector, t,ClientFunction } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const data = require("../Data/PE_PA_Data.json");
const dataCP = require("../Data/PE_CP_Data.json");
const dataQnB = require("../Data/QnB_CP_Data.json");
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class CPBuildingsAndLocations {
  constructor() {
    this.nextButton = Selector("button[id='gw-wizard-Next']");
    this.next_Empty_State_TOOL_TIP_Css = Selector("[class*='nextbutton']");
    this.addBuilding_Btn = Selector("[id='addBuilding']");
    this.building = Selector("[id='addBuildingButton']");
    this.newLocation = Selector("[data-value='newLocation']");
    this.Add_Address_Linel = Selector("input[id='addressLine1']");
    this.addAddressLine1Error = Selector("[id*='addressLine1'][role='alert']");
    this.Add_Address_Line2 = Selector("input[id='addressLine2']");
    this.Add_Address_Line3 = Selector("input[id='addressLine3']");
    this.add_State_Select = Selector("[id='state']");
    this.add_State_Option = Selector(
      "[id='state'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.add_ZipCode = Selector("input[id='zipCode']");
    this.addZipCodeError = Selector("[id*='zipCode'][role='alert']");
    this.add_City = Selector("[id='city']");
    this.addCityError = Selector("[id*='city'][role='alert']");
    this.location_Code = Selector("input[id='locationCode']");
    this.phoneNumber = Selector("input[id='phoneNumber']");
    this.fireProtection_Select = Selector("[id='fireProtection']");
    this.fireProtection_Option = Selector(
      "[id='fireProtection'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.propClass_Code_Select = Selector("[id='propertyClassCode']");
    this.propClass_Code_Select_Option = Selector(
      "[id='propertyClassCode'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.propClass_Error = Selector(
      "div[id*='propertyClassCode'][role='alert']"
    );
    this.building_Description = Selector("[id='buildingDescription']");
    this.build_Year = Selector("[id='yearBuilt']");
    this.construction_Type_Select = Selector("[id='constructionType']");
    this.construction_Type_Option = Selector(
      "[id='constructionType'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.noOfStories = Selector("[id='numberOfStories']");
    this.totalArea = Selector("[id='totalAreaExcludingBasement']");
    this.sprinklered_Select = Selector("[id='percentageSprinklered']");
    this.sprinklered_Option = Selector(
      "[id='percentageSprinklered'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.add_Exposure = Selector("[id='exposure']");
    this.alarm_Type_Select = Selector("[id='alarmType']");
    this.alarm_Type_Option = Selector(
      "[id='alarmType'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.building_Limit = Selector(" input[id*='ClauseTerm_[CPBldgCov]']");
    this.new_Badge = Selector("[class*='InfoLabel-module__infoLabel']");
    this.first_Building_Ellipsis_Icon = Selector("[id='builidngsListAction']");
    this.ellipsis_Delete_Building = Selector("[id='deleteBuilding']");
    this.delete_Building = Selector(
      "[id='actionContainer'] [class*='trash Button-module']"
    );
    this.next_Empty_State_Btn = Selector("[id*='Next'][class*='disabled']");
    this.building_Desc_Link_On_Listing = Selector(
      "[class*='BuildingsListPage_gwBuildingAndLocationNameLink']"
    ).nth(0);
    this.location_First_Building_Link = Selector(
      "[class*='BuildingsListPage_gwBuildingAndLocationNameLink']"
    ).nth(1);
    this.location_Address1 = Selector(
      "[id='locationFullAddress'] div:nth-child(1)"
    );
    this.location_Address2 = Selector(
      "[id='locationFullAddress'] div:nth-child(2)"
    );
    this.location_Address3 = Selector(
      "[id='locationFullAddress'] div:nth-child(3)"
    );
    this.loc_Location_Code = Selector("[id='locationCode']");
    this.loc_Phone_Num = Selector("[id='locationPhone']");
    this.loc_Fire_Protection = Selector("[id='locationFireProtection']");

    this.building_Details_View_Mode = Selector(
      "[class*='SummaryHeader_summaryInfoHeading']"
    ).nth(3);
    this.building_Details_Year_Build = Selector("[id='yearBuilt']");
    this.building_Details_No_Stories = Selector("[id='noOfStories']");
    this.building_Details_Exposure = Selector("[id='exposure']");
    this.building_Details_Construction_Type = Selector(
      "[id='constructionType']"
    );
    this.building_Details_Total_Area = Selector("[id='totalArea']");
    this.building_Details_Alarm_Type = Selector("[id='alarmType']");
    this.building_Details_Sprinklered = Selector(
      "[id='percentageSprinklered']"
    );
    this.building_Details_Class_Code = Selector("[id='propertyClassCode']");
    this.existingLocation_Dropdown = Selector("[id='exisitingLocation']");
    this.existingLocation_Dropdown_Select = Selector(
      "[id='exisitingLocation'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.location_Expand_Btn = Selector(
      "[id='locationSummaryContainer'] [class*='fa-default Chevron-module']"
    );
    this.building_Expand_Btn = Selector(
      "[id='buildingSummaryCard'] [class*='fa-default Chevron-module']"
    );
    this.coverages_Expand_Btn = Selector(
      "[id='coverageSummaryCard'] [class*='fa-default Chevron-module']"
    );
    this.building_Link_Loc = Selector(
      "[class*='gwBuildingAndLocationNameLink']"
    );
    this.building_Changes_Save_Alert_Msg = Selector(
      "[class*='InlineNotification-module__messageDefault']"
    );
    this.building_Save_Alert_Msg = Selector("[id='buildingSavedNotification']");
    this.building_Listing_Table = Selector(
      "button[title='Building Description']"
    );
    this.personal_Property_Limit = Selector(
      "[id='ClauseElementContainer_[CPBPPCov]'] [id='ClauseTerm_[CPBPPCov]_[0]']"
    );
    this.add_Another_Building = Selector("[id='addAnotherBuildingButton']");
    this.location_Form_Building = Selector("[id='locationToggleContainer']");
    this.back_View_Btn = Selector("[id='backToListContainer']");
    this.edit_Location_Link = Selector(" [id='editLocation']");
    this.edit_Building_Link = Selector("[id='editBuilding']");
    this.location_Add_Save_Btn = Selector("[id='saveButton']");
    this.building_Add_Save_Btn = Selector("[id='saveButton']");
    this.businessPropCoverLossSelect = Selector(
      "[id='ClauseTerm_[CPBPPCov]_[1]'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.businessProCoverLoss = Selector("[id='ClauseTerm_[CPBPPCov]_[1]']");
    this.causeOfLossOption = Selector(
      "[id='ClauseTerm_[CPBldgCov]_[3]'] div[class*='TypeaheadMultiSelectField__menu'] div"
    );
    this.causeOfLossSelect = Selector("[id='ClauseTerm_[CPBldgCov]_[3]']");
    this.excludeTheftCvg = Selector("label[id*='ClauseTerm_[CPBldgCov]_[1]']");
    this.location_Link_List = Selector("button[title='Location']");
    this.cgv_Add_Summary_Add_Building_Flow = Selector(
      "[id='coverageSummaryCard'] [class*='SummaryHeader_sumaryAccordionHeaderContent']"
    );
    this.edit_Coverage_Link = Selector("[id='editCoveragesButton']");
    this.save_Coverage_Btn = Selector("[id='saveButton']");
    this.hover_Building = Selector(
      "[class*='rt-tr DataTable-module__tableRow']"
    );
    this.addBuildingToThisLocation = Selector("[id='addBuilding'] i");
    this.searchBuildingLocationCss = Selector("#search");
    this.edit_Coverages_Link = Selector("#editCoveragesButton");
    this.firstClassCode = Selector(
      "[class*='rt-td DataTable-module__tableCell']"
    ).nth(2);
    this.locationLinkListingCss = Selector(
      "[class*='rt-td DataTable-module__tableCell']"
    ).nth(3);
    this.buildingDescLink = Selector(
      "[class*='rt-td DataTable-module__tableCell']"
    )
      .find("span")
      .nth(3);
    this.cancel = Selector("[id='cancelButton']");
    this.base_CVGS_View = Selector(
      "[id='coverageSummaryCard'] [class*='ClauseComponent_readOnlyGrid']"
    );
  }

  async cancel_Button() {
    await helper.click(this.cancel);
  }
  async saveCoveragesOnBuilding() {
    await helper.click(this.save_Coverage_Btn);
  }
  async clickEditOnCoveragesSummary() {
    await helper.click(this.edit_Coverage_Link);
  }
  async validateCoverageChange() {
    await this.getCoverageEntryOnBuildingCoveragesView();
  }
  async getCoverageEntryOnBuildingCoveragesView() {
    await assert.elementPresent(
      this.base_CVGS_View,
      "Building Limit didn't match"
    );
  }
  async expandCoveragesSummaryInAddBuildingFlow_ExcludesFirefox() {
    await helper.click(this.cgv_Add_Summary_Add_Building_Flow);
  }
  async expandCoveragesSummaryInAddBuildingFlow() {
    await helper.click(this.cgv_Add_Summary_Add_Building_Flow);
  }
  async getAllLocationsFromListing(list) {
    await helper.getTextAtLocator(
      this.location_Link_List,
      list.Location,
      "Location Header didn't match on Listing page"
    );
  }
  async validateLocationsOnListing(dataCP) {
    await this.getAllLocationsFromListing(dataCP);
  }

  async clickEditOnLocationSummary() {
    await helper.click(this.edit_Location_Link);
  }
  async selectFromExistingLocations(location) {
    await helper.selectDropdownWithText(
      this.existingLocation_Dropdown,
      this.existingLocation_Dropdown_Select,
      location
    );
  }
  async addBuildingOnExistingLocation(dataCP) {
    await this.addBuildingForExistingLocation();
    await this.selectFromExistingLocations(dataCP.ExistingData);
    await common.goNext();
    await this.setBuildingData(dataCP);
    await common.goNext();
    await this.setBuildingLimit(dataCP.BuildingLimit);
    await common.goNext();
  }
  async addBuildingOnExistingLocationCPChange(dataCP) {
    await this.addBuildingForExistingLocation();
    await common.goNext();
    await this.setBuildingData(dataCP);
    await common.goNext();
    await this.setPersonalPropertyLimit(dataCP.PersonalLimit);
    await this.setBuildingLimit(dataCP.BuildingLimit);
    await common.goNext();
  }

  async addBuildingManually(dataCP){
      await this.addBuildingForExistingLocation();
      await this.addNewLocationDetails(dataCP);
      await common.goNext();
      await this.setBuildingData(dataCP);
      await common.goNext();
      await this.setPersonalPropertyLimit(dataCP.PersonalLimit);
      await this.setBuildingLimit(dataCP.BuildingLimit);
      await common.goNext();
    }
  
  async selectExistingLocation() {
    var optionToBeSelected=[];
    await helper.click(this.existingLocation_Dropdown);
    var dropDownValues = ClientFunction(() => {
        var items = document.querySelectorAll("[id='exisitingLocation'] div[class*='TypeaheadMultiSelectField__menu'] div");
        var itemsValues = [];
        for (var item of items)
            itemsValues.push(item.textContent);
        return itemsValues;
    });
    var dropDownoptions = await dropDownValues();
    for (var option of dropDownoptions)
        if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
            optionToBeSelected.push(option);    
        }
        await helper.click(this.existingLocation_Dropdown_Select.withExactText(optionToBeSelected[1]));
}
  async addBuildingToDefaultLocation(dataCP) {
    await t.wait(2000);
    await this.clickOnAddBuilding();
    await common.goNext();
    await this.setBuildingData(dataCP);
    await common.goNext();
    await this.setBuildingLimit(dataCP.BuildingLimit);
    await this.setPersonalPropertyLimit(dataCP.PersonalLimit);
    await common.goNext();
  }

  async isNextButtonDisabled() {
    await assert.elementPresent(
      this.next_Empty_State_Btn,
      "Next button enabled with no buildings"
    );
  }
  async isLocationPageDisplayedOnAddBuilding() {
    await assert.elementPresent(
      this.location_Form_Building,
      "Add Building wizard didn't open"
    );
  }
  async validateTooltipDisplayedForNoBuildings(text) {
    await assert.elementPresent(
      this.next_Empty_State_TOOL_TIP_Css,
      "Tooltip for no buildings not visible"
    );
    await assert.assertEqual(
      this.next_Empty_State_TOOL_TIP_Css.innerText,
      text,
      "Tooltip text for no buildings does not match"
    );
  }
  
  async isLocationAvailableInExistingLocations(data) {
    var address = await this.getExistingLocations();
    var addressUI =
      data.AddressLine1 +
      ", " +
      data.AddressLine2 +
      ", " +
      data.AddressLine3 +
      ", " +
      data.city +
      ", " +
      data.state +
      ", " +
      data.zipCode;
    await assert.assertEqual(
      address,
      addressUI,
      "Location still available in existing locations"
    );
  }
  async verifyExistingLocationIsAvailable(data) {
    var address = await this.getExistingLocations();
    var addressUI =
      data.AddressLine1 +
      ", " +
      data.AddressLine2 +
      ", " +
      data.AddressLine3 +
      ", " +
      data.City ;
    await assert.hasText(
      address,
      addressUI,
      "Location still available in existing locations"
    );
  }
  async getExistingLocations() {
    var existingLoc = await helper.getTextAtLocator(
      this.existingLocation_Dropdown
    );
    return existingLoc;
  }
  async setBuildingLimit(limit) {
    await helper.typeText(this.building_Limit, limit);
  }
  async addBuildingOnNewLocation() {
    this.clickOnAddBuilding();
  }
  async clickAddAnotherBuilding() {
    await helper.click(this.add_Another_Building);
  }
  async validateBuildingonLocationSavedMessage(data) {
    await assert.assertEqual(
      await helper.getValueAttributeFromLocator(this.building_Save_Alert_Msg),
      data.BuildingSavedAlert,
      "Building saved message not displayed"
    );
  }
  async setPersonalPropertyLimit(personal) {
    await helper.typeText(this.personal_Property_Limit, personal);
  }
  async validateNextButtonIsDisabled() {
    await assert.isElementNotClickable(
      this.nextButton,
      "disabled",
      "Button is enabled"
    );
  }
  async clickOnAddBuilding() {
    await helper.click(this.addBuilding_Btn);
  }
  async addBuildingForExistingLocation() {
    await helper.click(this.building);
  }
  async addNewLocationDetails(dataCP) {
    await this.selectNewLocation();
    await this.setLocationData(dataCP);
  }
  async expandLocationSummaryInAddBuildingFlow() {
    await helper.click(this.location_Expand_Btn);
  }

  async selectNewLocation() {
    await helper.click(this.newLocation);
  }
  async isEmptyStateViewDisplayed() {
    await assert.isElementNotClickable(this.next_Empty_State_Btn, "disabled");
  }
  async expandBuildingSummaryInAddBuildingFlow() {
    await helper.click(this.building_Expand_Btn);
  }
  async clickEditOnBuildingSummary() {
    await helper.click(this.edit_Building_Link);
  }
  async setLocationData(dataCP) {
    await this.setAddressLine1(dataCP.AddressLine1);
    await this.setAddressLine2(dataCP.AddressLine2);
    await this.setAddressLine3(dataCP.AddressLine3);
    await this.setCity(dataCP.City);
    await this.setZIPCode(dataCP.Zip);
    await this.setState(dataCP.State);
    await this.setLocationCode(dataCP.LocationCode);
    await this.setPhone(dataCP.PhoneNumber);
    await this.setFireProtection(dataCP.FireProtection);
  }
  async editLocationDetails(dataCP) {
    await this.setAddressLine1(dataCP.AddressLine1);
    await this.setLocationCode(dataCP.LocationCode);
    await this.setPhone(dataCP.PhoneNumber);
    await this.setFireProtection(dataCP.FireProtection);
  }
  async isBuildingAvailableOnLocation(data) {
    await assert.assertEqual(
      await helper.getValueAttributeFromLocator(this.building_Listing_Table),
      data.Building2,
      "Building wasn't added"
    );
  }

  async validateEditBuildingSavedMessage(data) {
    await assert.assertEqual(
      await helper.getAttribute(this.building_Changes_Save_Alert_Msg),
      data.BuildingChangesSavedMessage,
      "Building saved message not displayed"
    );
  }
  async getBuildingsDescriptionOnLocation() {
    var result = await this.building_Listing_Table.innerText;
    return result;
  }
  async setAddressLine1(address1) {
    await helper.typeText(this.Add_Address_Linel, address1);
  }
  async setAddressLine2(address2) {
    await helper.typeText(this.Add_Address_Line2, address2);
  }
  async setAddressLine3(address3) {
    await helper.typeText(this.Add_Address_Line3, address3);
  }

  async isBuildingAvailableOnLocation(data) {
    await this.getBuildingsDescriptionOnLocation();
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Listing_Table),
      data.Building2,
      "Building wasn't added"
    );
  }
  async validateBuildingSavedMessage(text) {
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Save_Alert_Msg),
      text,
      "Building saved message not displayed"
    );
  }
  async getBuildingsDescriptionOnLocation() {
    var table = await helper.getTextAtLocator(this.building_Listing_Table);
    return table;
  }
  async setAddressLine1(address1) {
    await helper.typeText(this.Add_Address_Linel, address1);
  }
  async setCity(city) {
    await helper.typeText(this.add_City, city);
  }
  async setZIPCode(zip) {
    await helper.typeText(this.add_ZipCode, zip);
  }
  async setState(state) {
    await helper.selectDropdown(
      this.add_State_Select,
      this.add_State_Option,
      state
    );
  }
  async setLocationCode(location) {
    await helper.typeText(this.location_Code, location);
  }
  async setPhone(phonenum) {
    await helper.typeText(this.phoneNumber, phonenum);
  }
  async setFireProtection(option) {
    await helper.selectDropdown(
      this.fireProtection_Select,
      this.fireProtection_Option,
      option
    );
  }
  async saveAddedLocation() {
    await helper.click(this.location_Add_Save_Btn);
  }
  async saveAddedBuilding() {
    await helper.click(this.building_Add_Save_Btn);
  }
  async setBuildingData(dataCP) {
    await this.setPropClassCode(dataCP.PropertyClassCode);
    await this.setBuildingDesc(dataCP.BuildingDescription);
    await this.setYearBuilt(dataCP.YearBuilt);
    await this.setConstructionType(dataCP.ConstructionType);
    await this.setNoOfStories(dataCP.NoofStories);
    await this.setTotalArea(dataCP.TotalArea);
    await this.setSprinklered(dataCP.Sprinklered);
    await this.setExposure(dataCP.Exposure);
    await this.setHasAlarm(dataCP.AlarmType);
  }
  async validateNextButtonIsEnabled() {
    await assert.isElementClickable(
      this.nextButton,
      "enabled",
      "Button is Disabled"
    );
  }
  async setPropClassCode(propcode) {
    await helper.typeText(this.propClass_Code_Select, propcode);
    await helper.pressTab();
  }
 
  async setBuildingDesc(descption) {
    await helper.typeText(this.building_Description, descption);
  }
  async setYearBuilt(yearBuilt) {
    await helper.typeText(this.build_Year, yearBuilt);
  }
  async setConstructionType(option) {
    await helper.selectDropdown(
      this.construction_Type_Select,
      this.construction_Type_Option,
      option
    );
  }
  async setNoOfStories(stories) {
    await helper.typeText(this.noOfStories, stories);
  }
  async setTotalArea(area) {
    await helper.typeText(this.totalArea, area);
  }
  async setSprinklered(option) {
    await helper.selectDropdown(
      this.sprinklered_Select,
      this.sprinklered_Option,
      option
    );
  }
  async setExposure(exposure) {
    await helper.typeText(this.add_Exposure, exposure);
  }
  async setHasAlarm(option) {
    await helper.selectDropdown(
      this.alarm_Type_Select,
      this.alarm_Type_Option,
      option
    );
  }
  async validateBuildingWithoutChangesSavedMessage(text) {
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Save_Alert_Msg),
      text,
      "Building saved message not displayed"
    );
  }
  async validateNewBadgeOnBuilding() {
    await assert.elementPresent(
      this.new_Badge,
      "New Badge not displayed for added building"
    );
  }

  async clickOnEllipsisIcon() {
    await helper.hover(this.hover_Building);
    await helper.click(this.first_Building_Ellipsis_Icon);
  }

  async clickDeleteAndConfirm() {
    await helper.click(this.delete_Building);
    await modal.confirm();
  }
  async clickDeleteAndConfirmButton() {
    await helper.click(this.ellipsis_Delete_Building);
    await modal.confirm();
  }
  async removeBuildingFromListing() {
    await this.clickOnEllipsisIcon();
    await this.clickDeleteAndConfirmButton();
  }
  async clickOnAddBuildingToThisLocation() {
    await this.clickOnEllipsisIcon();
    await helper.click(this.addBuildingToThisLocation);
  }
  async openFirstBuildingFromLocationView() {
    await helper.click(this.building_Link_Loc);
  }
  async isBuildingListingPageDisplayed() {
    await assert.elementPresent(
      this.building_Listing_Table,
      "User not taken back to Building Listing page"
    );
  }
  async isEmptyStateViewDisplayed() {
    await assert.elementPresent(
      this.next_Empty_State_Btn,
      "Building is present"
    );
  }
  async clickBackOnViewModes() {
    await helper.click(this.back_View_Btn);
  }
  async openFirstBuildingFromListing() {
    await helper.click(this.building_Desc_Link_On_Listing);
  }
  async expandBuildingSummary() {
    await helper.click(this.building_Details_View_Mode);
  }
  async validateCPBuildingData(data) {
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Year_Build),
      data.YearBuilt,
      "Year Built didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_No_Stories),
      data.NoofStories,
      "No. of stories didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Exposure),
      data.Exposure,
      "Exposure didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Construction_Type),
      data.ConstructionValue,
      "Construction didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Total_Area),
      data.TotalArea,
      "Total Area didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Alarm_Type),
      data.AlarmValue,
      "Alarm Type didn't save"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.building_Details_Class_Code),
      data.PropertyClassCode,
      "Property Class Code didn't save"
    );
  }
  async removeBuildingFromViewMode() {
    await this.clickDeleteAndConfirm();
  }
  async openLocationOfFirstBuilding() {
    await helper.click(this.location_First_Building_Link);
  }
  async validateLocationDetailsInViewMode(location) {
    await assert.assertEqual(
      (await helper.getTextAtLocator(this.location_Address1)).trim(),
      location.AddressLine1,
      "Address Line 1 did not matched"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.loc_Location_Code),
      location.LocationCode,
      "Location Code did not matched"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.loc_Phone_Num),
      location.PhoneNumber,
      "Phone Number did not matched"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.loc_Fire_Protection),
      location.FireProtection,
      "Fire Protection did not matched"
    );
  }
  async validateFirstBuilding(description) {
    await t.wait(2000);
    console.log(await this.buildingDescLink.innerText);
    await assert.assertEqual(
      await this.buildingDescLink.innerText,
      description.BuildingDescription,
      "Building Description did not matched"
    );
    console.log("Innertext of building link is working");
  }

  async setCauseOfLossOnNewBuilding(cause, cvgTerm) {
    await this.addBuildingOnNewLocation();
    await this.addNewLocationDetails(dataCP.policyInfoValidationCP);
    await common.goNext();
    await this.setBuildingData(dataCP.BuildingData);
    await common.goNext();
    if (cvgTerm == "Business Personal Property")
      await helper.selectDropdown(
        this.businessProCoverLoss,
        this.businessPropCoverLossSelect,
        cause
      );
    else
      await helper.selectDropdown(
        this.causeOfLossSelect,
        this.causeOfLossOption,
        cause
      );
  }
  async setCauseOfLossOnNewBuildingCPPolicyChange(cause, cvgTerm) {
    await this.addBuildingForExistingLocation();
    await this.addNewLocationDetails(dataCP.policyInfoValidationCP);
    await common.goNext();
    await this.setBuildingData(dataCP.BuildingData);
    await common.goNext();
    if (cvgTerm == "Business Personal Property")
      await helper.selectDropdown(
        this.businessProCoverLoss,
        this.businessPropCoverLossSelect,
        cause
      );
    else
      await helper.selectDropdown(
        this.causeOfLossSelect,
        this.causeOfLossOption,
        cause
      );
  }

  async isCoverageTermExcludeTheftNotAvailable() {
    await assert.assertNotEqual(
      this.excludeTheftCvg.innerText,
      "Exclude Theft",
      "Exclude Theft coverage term available for Building Coverage"
    );
  }

  async isCoverageTermExcludeTheftAvailable() {
    await assert.elementPresent(
      this.excludeTheftCvg,
      "Exclude Theft coverage term unavailable for Building Coverage"
    );
  }

  async clickEditLocation() {
    await helper.click(this.edit_Location_Link);
  }
  async expandCoveragesSummary() {
    await helper.click(this.coverages_Expand_Btn);
  }
  async clickEditCoverages() {
    await helper.click(this.edit_Coverages_Link);
  }
  async searchForString(data) {
    await helper.typeText(this.searchBuildingLocationCss, data);
  }
  async validateIfTextHighlighted(data) {
    await assert.elementPresent(
      this.textHighlighter,
      "No search result highlighted in black"
    );
    await assert.assertEqual(
      await helper.getTextAtLocator(this.textHighlighter),
      data,
      'Highlighted string and query didn"t match'
    );
  }
  async validateLocationOnFirstBuilding(data) {
    await assert.assertEqual(
      await helper.getTextAtLocator(this.locationLinkListingCss),
      data,
      "location header didnt match"
    );
  }
  async validateClassCodeOnFirstBuilding(data) {
    await assert.assertEqual(
      await helper.getTextAtLocator(this.firstClassCode),
      data,
      "Property Class Code didnt match"
    );
  }
  async validateFirstBuilding(data) {
    await assert.assertEqual(
      await helper.getTextAtLocator(
        this.bulidingdescrLink,
        data,
        "Building description dint match"
      )
    );
  }

  async validateSelectedLocation(data) {
    await helper.getTextAtLocator(
      this.existingLocation_Dropdown,
      data.ExistingLocation,
      "Selected location didn't match"
    );
  }

  async getExistingLocation() {
    var location = await helper.getTextAtLocator(
      this.existingLocation_Dropdown
    );
    return location;
  }
  async removeBuildingForLocation() {
    await this.removeBuildingFromListing();
  }
}
