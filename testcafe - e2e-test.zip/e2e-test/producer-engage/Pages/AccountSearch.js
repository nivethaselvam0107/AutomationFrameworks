import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper'
import Assertions from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertions();
export default class AccountSearch {
    constructor() {
        this.title = Selector("div[id='newQuoteHeader']");
        this.commercial = Selector("[id='accountType'] [data-value='company']");
        this.personal = Selector("[id*='accountType'] [data-value='person']");
        this.firstName = Selector("input[id='firstName']");
        this.lastName = Selector("input[id='lastName']");
        this.searchButton = Selector("button[id='search']");
        this.createNewAccount = Selector("[id='newCustomerBtn']");
        this.companyName = Selector("input[id='company']");
        this.accountSearchResult = Selector("[class*='digitalTable Table-module'] tr").nth(1);
        this.startNewQuote = Selector("[class*='digitalRow'] a[href*='new-quote']").nth(0);
        this.cancel = Selector("[id='possibleCancel']");
        this.searchAgain = Selector("[id='possibleSearchAgain']");
    }
    async clickCommercial() {
        await helper.click(this.commercial);
    }
    async clickPersonal() {
        await helper.click(this.personal);
    }
    async typeFirstName(firstname) {
        await helper.typeText(this.firstName, firstname);
    }
    async typeLastName(lastname) {
        await helper.typeText(this.lastName, lastname);
    }
    async clickSearchButton() {
        await helper.click(this.searchButton);
    }
    async clickContinueAsNewcustomer() {
        await helper.click(this.createNewAccount);
    }
    async enterCompanyName(company) {
        await helper.typeText(this.companyName, company);
    }
    async isAccountExists() {
        await assert.elementPresent(this.accountSearchResult, "No Search Results");
    }
    async clickStartNewQuote() {
        await helper.click(this.startNewQuote);
    }
    async checkCancelButton() {
        await assert.elementPresent(this.cancel, 'Cancel option is not present');
    }
    async checkSearchAgainButton() {
        await assert.elementPresent(this.searchAgain, 'Search Again option is not present');
    }
    async accountSearchForPersonal(data) {
        await this.clickPersonal();
        await this.typeFirstName(data.FirstName);
        await this.typeLastName(data.LastName);
        await this.clickSearchButton();
        await t.wait(2000);
    }
    async searchExistingAccountForPersonal(data) {
        await this.clickPersonal();
        await this.typeFirstName(data.accountFirstName);
        await this.typeLastName(data.accountLastName);
        await this.clickSearchButton();
        await t.wait(3000);
    }
    async accountSearchForCommercial(data) {
        await this.enterCompanyName(data.Company);
        await this.clickSearchButton();
        await t.wait(2000);
    }
    async useExistingAccountWithAccountNumber() {
        await helper.click(this.startNewQuote);
    }

}