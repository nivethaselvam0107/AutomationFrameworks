import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';
import CommonLocators from '../../Utilities/CommonLocators';

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
const modal = new Modal();

export default class BOPQualification {
    constructor() {
        this.policyRejectedYes = Selector("[id='PolicyRejected'] button").nth(0);
        this.policyRejectedNo = Selector("[id='PolicyRejected'] button").nth(1);
    }
    async clickNext() {
        await common.goNext();
    }
    async clickCancel() {
        await common.pressCancel();
    }
    async clickPrevious() {
        await common.goPrev();
    }
    async setPolicyDeclinedQuestion(data) {
        if (data.PolicyDeclineStatus == 'Yes') {
            await helper.click(this.policyRejectedYes);
        }
        else {
            await helper.click(this.policyRejectedNo);
        }
    }
    async isPolicyDeclinedQuesMarkedYes() {
        await this.policyRejectedYes.hasAttribute('active');
    }
    async pressCancelAndConfirm() {
        await this.clickCancel();
        await modal.confirm();
    }
}