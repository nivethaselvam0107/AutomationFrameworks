import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import AccountSearch from '../Pages/AccountSearch';
import Login from '../Login';
import NavBar from '../Pages/NavBar';
import QuoteStart from './QuoteStart';
import PolicyCancellation from './PolicyCancellation';
import LeftNavigationMenuHandlerPage from "../Pages/LeftNavigationMenuHandlerPage";
import QualificationPage from '../Pages/QualificationPage';
import DriversPage from '../Pages/DriversPage';
import VehiclesPage from '../Pages/VehiclesPage';
import CommonLocators from '../../Utilities/CommonLocators';
import PAQuotePage from '../Pages/PAQuotePage';
const data = require("../Data/PE_PA_Data.json");
var quoteNumber;
var quoteNumberLink = "[href*='/quotes/"+quoteNumber+"/summary']";
const paQuote = new PAQuotePage();
const common = new CommonLocators();
const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const quoteStart = new QuoteStart();
const policyCancel = new PolicyCancellation();
const qualification = new QualificationPage();
const drivers = new DriversPage();
const vehicles = new VehiclesPage();
const leftNavi = new LeftNavigationMenuHandlerPage();
const helper = new Helper();
export default class PE_PageQuoteFactory {
    constructor() {
        this.searchField = Selector("#searchFilter");
    }
    async createDraftQuote(data) {
        const quoteNum = await this.getToVehicleDetailsPageAndSetData(data);
        return quoteNum;
    }

    async startQuoteWithExistingAcount(policy) {
        await nav.clickStartNewQuote();
        await accountSearch.clickPersonal();
        await accountSearch.typeFirstName(policy.accountFirstName);
        await accountSearch.typeLastName(policy.accountLastName);
        await accountSearch.clickSearchButton();
        await accountSearch.useExistingAccountWithAccountNumber();
        await this.fillPolicyDetailsFormForExistingAccount(policy);
    }

    async fillPolicyDetailsFormForExistingAccount(policy) {
        await quoteStart.selectState(data.QuoteStart.State);
        await quoteStart.setDate(policy);
        await t.wait(2000);
        await quoteStart.selectProducerCode(data.QuoteStart.ProducerCode);
        await t.wait(2000);
        await quoteStart.selectProductCode(data.QuoteStart.ProductCode);
        await quoteStart.clickSubmit();

    }
    async getToVehicleDetailsPageAndSetData(data) {
        await qualification.setPAQualificationPageDetails(data.qualificationPage);
        await common.goNext();
        await drivers.setPrimaryDriverDetails(data.driversPage)
        await common.goNext();
        await vehicles.setVehicleDetails(data.vehiclesPage);
        const quoteNumber = await paQuote.getSubmissionNumber();
        return quoteNumber;
    }
    async goToQuoteSummaryPage(quoteNum) {
        let quote = quoteNumberLink.replace(quoteNumber,quoteNum);
        await helper.click(Selector(quote));
    }
    async createQuotedQuote(data) {
        const quoteNum = await this.getToVehicleDetailsPageAndSetData(data);
        await common.goNext();
        return quoteNum;

    }
    async searchQuoteByPartialNumber(quoteNum) {
        let quoteNumber = quoteNum.substr(0, 6);
        await helper.typeText(this.searchField, quoteNumber);
    }

    async searchQuoteByQuoteNumber(quoteNum) {
        await helper.typeText(this.searchField, quoteNum);
    }
}
