import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import moment from 'moment';
const helper = new Helper();
const assert = new Assertion();
let newPremium;
let effectiveDate;
const notificationIncrease = `Warning:Your Premium Will Increase by ${newPremium}.This change will be reflected in the upcoming invoices. The policy change effective date is ${effectiveDate}`;
const notificationDecrease = `Warning:Your Premium Will Decrease by ${newPremium}.This change will be reflected in the upcoming invoices. The policy change effective date is ${effectiveDate}.`;
const notificationNoChanges = `Warning:There are no changes to the premium.`;

export default class EndorsementQuotePage {
    constructor() {
        this.policyDetailsTitle = Selector("#paPolicyDetails");
        this.paymentNotification = Selector("#warningPaymentNotification");
        this.policyChangeEffectiveDate = Selector("#dateId");
        this.policyChangeEffectiveDateHO = Selector("#hoPolicyPeriod");
        this.paymentDifference = Selector("[id*='PACostAndPremiumPremiumDifference']").sibling('div').find("span[class*='digitalCurrency CurrencyField-module']");
        this.paymentDifferenceHO = Selector("[id*='hoCostAndPremiumPremiumDifference']").sibling('div').find("span[class*='digitalCurrency CurrencyField-module']");
    }

    async verifyNoChangesNotification() {
        await assert.elementPresent(this.paymentNotification, 'Warning Notification for No payment is not displayed');
        await assert.assertEqual(await helper.getTextAtLocator(this.paymentNotification),
            notificationNoChanges,'No payment message is incorrect');
    }

    async verifyIncreaseNotification() {
        await assert.elementPresent(this.paymentNotification, 'Warning Notification for  Increase payment is not displayed');
        await assert.assertEqual(await helper.getTextAtLocator(this.paymentNotification),
            notificationIncrease.replace(newPremium, await this.getPaymentDifference()).replace(effectiveDate,moment(await this.getEffectiveDate()).format("MMMM")),
            'Increase in policy premium message is incorrect');
    }

    async verifyIncreaseNotificationHO() {
        await assert.elementPresent(this.paymentNotification, 'Warning Notification for increase payment is not displayed');
        await assert.assertEqual(await helper.getTextAtLocator(this.paymentNotification),
            notificationIncrease.replace(newPremium, await this.getPaymentDifferenceHO()).replace(effectiveDate,moment(await this.getEffectiveDateHO()).format('MMMM')),
            'Increase in policy premium message is incorrect');
    }

    async   verifyDecreaseNotification() {
        await assert.elementPresent(this.paymentNotification, 'Warning Notification for decrease payment is not displayed');
        await assert.assertEqual(await helper.getTextAtLocator(this.paymentNotification),
            notificationDecrease.replace(newPremium, await this.getPaymentDifference()).replace(effectiveDate,moment(await this.getEffectiveDate()).format('MMMM')),
            'Decrease in policy premium is incorrect');
    }

    async verifyDecreaseNotificationHO() {
        await assert.elementPresent(this.paymentNotification, 'Warning Notification for decrease payment is not displayed');
        await assert.assertEqual(await helper.getTextAtLocator(this.paymentNotification),
            notificationDecrease.replace(newPremium, await this.getPaymentDifference()).replace(effectiveDate,moment(await this.getEffectiveDateHO()).format('MMMM')),
            'Decrease in policy premium is incorrect');
    }
    async getPaymentDifference() {
        return await helper.getTextAtLocator(this.paymentDifference);
    }
    async getPaymentDifferenceHO() {
        return (await helper.getTextAtLocator(this.paymentDifferenceHO)).replace('USD ','$');
    }
    async getEffectiveDate() {
        return await helper.getTextAtLocator(this.policyChangeEffectiveDate);
    }
    async getEffectiveDateHO() {
        return await helper.getTextAtLocator(this.policyChangeEffectiveDateHO);
    }
    async verifyPolicyDetailsTitle(){
        await assert.elementPresent(this.policyDetailsTitle,'Policy Details Title is not displayed');
    }
}
