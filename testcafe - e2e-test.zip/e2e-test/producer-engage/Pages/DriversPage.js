import { Selector } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions"
;

const helper = new Helper();
const assert = new Assertion();
const data = require('../Data/QnB_PA_Data.json');

export default class DriversPage {
  constructor() {
    this.DOB = Selector("[id='driverDateOfBirth']");    
    this.numOfAccidents=Selector("[id='driverNumberOfAccidents']");    
    this.numOfViolations=Selector("[id='driverNumberOfViolations']");    
    this.gender_select = Selector("[id='driverGender']");    
    this.gender_option = Selector("[id='driverGender'] div[class*='TypeaheadMultiSelectField__menu'] div");    
    this.licensenumber = Selector("[id='driverLicenseNumber']");    
    this.licenseState_select = Selector("[id='driverLicenceState']");    
    this.licenseState_option = Selector("[id='driverLicenceState'] div[class*='TypeaheadMultiSelectField__menu'] div");    
    this.licensedYear_select = Selector("[id='driverYearFirstLicenced']");    
    this.licensedYear_option = Selector("[id='driverYearFirstLicenced'] div[class*='TypeaheadMultiSelectField__menu'] div");    
  }
  async typeDOB(DOB) {
    await helper.typeText(this.DOB, DOB);
  }

  async selectLicenseState(option) {
    await helper.selectDropdown(this.licenseState_select,this.licenseState_option, option);
  }

  async selectLicenseYear(option) {
    await helper.selectDropdown(this.licensedYear_select,this.licensedYear_option, option);
  }
  async typeLicenseNumber(licenseNumber) {
    await helper.typeText(this.licensenumber, licenseNumber);
  }
  async setGender(option) {
    await helper.selectDropdown(this.gender_select,this.gender_option, option);
  }
  async setPrimaryDriverDetails(data) {
    
    await this.typeDOB(data.DriverDOB);
    await this.setGender(data.DriverGendor);
    await this.typeLicenseNumber(data.DriverLicenseNum);
    await this.selectLicenseYear(data.FirstYearLicensed);
    await this.selectLicenseState(data.DriverLicenseState);
  }
  async areDriverDetailsSaved(data) {
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.gender_select),data.DriverGendorValue,"Gender is not correct");
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.licensenumber),data.DriverLicenseNum,"License Number is not correct" );
    await assert.assertEqual(await helper.getValueAttributeFromLocator(this.licenseState_select),data.DriverLicenseStateValue, "License state is not correct");
    await assert.assertEqual(this.numOfAccidents.innerText,data.AccidentNum,'No of Accident is not correct');
    await assert.assertEqual(this.numOfViolations.innerText,data.ViolationNum,'No of Violatinos is not correct');
  }
}
