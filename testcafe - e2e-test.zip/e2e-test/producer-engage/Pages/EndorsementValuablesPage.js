import { Selector } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from '../Data/DataFetch';
import Modal from '../../Utilities/WidgetComponents/Modal';

const environment = process.env.TEST_ENV_URL;
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();
const modal = new Modal();

export default class EndorsementValuablesPage {
    constructor() {
        this.newValuableButton = Selector("button[class*='digitalSecondary']").nth(0);
        this.type = Selector("div[id='ArticleType']");
        this.typeValue = Selector("div[id='ArticleType'] div[class*='TypeaheadMultiSelectField__menu'] div")
        this.description = Selector("input[id='SchedItemDescriptionId']");
        this.value = Selector("input[id='SchedItemValueId']");
        this.addButton = Selector("[class*='ScheduleItemModalPopover'] button:nth-child(2)");
        this.addedType = Selector("[class*='digitalRow Table-module'] td:nth-child(1)");
        this.addedDesc = Selector("[class*='digitalRow Table-module'] td:nth-child(2)");
        this.addedvalue = Selector("[class*='digitalRow Table-module'] td:nth-child(3)");
        this.addedDeductible = Selector(" ");
        this.addedValuation = Selector(" ");
        this.editValuableButton = Selector("[class*='fas fa-pen Button-module']");
        this.removeValuableButton = Selector("[class*='fas fa-trash Button-module']");
    }

    async addValuable(){
        await helper.click(this.newValuableButton);
    }
    async setValuableDesc(description){
        await helper.typeText(this.description,description);
    }
    async selectValuableType(type){
        await helper.selectDropdown(this.type,this.typeValue,type);
    }
    async isAddedPropertyValuablePresent(data){
        await assert.assertEqual((await helper.getTextAtLocator(this.addedType)).replace(/\t/g, ''),data.Valuable_Type,'Added Valuable type is not present');
        await assert.assertEqual((await helper.getTextAtLocator(this.addedDesc)).replace(/\t/g, ''),data.Valuable_Desc,'Added Valuable description is not present');
        await assert.assertEqual(((await helper.getTextAtLocator(this.addedvalue)).replace(',','')).replace(/\t/g, ''),"$"+parseFloat(data.Valuable_Cost).toFixed(2),'Added valuable value is not present');
        if(environment.includes('granite')){
        await assert.assertEqual(await helper.getTextAtLocator(this.addedDeductible),data.Valuable_Deductible, 'Added deductible valuable is not present');
        await assert.assertEqual(await helper.getTextAtLocator(this.addedValuation),data.Valuable_Validation_method,'Added valuable valuation is not present');        }
    }



    async fillValuableFormData(data){
        if(environment.includes('granite')){
            await helper.selectDropdown((this.type).nth(0),data.Valuable_Type);
            await helper.selectDropdown((this.type).nth(1),data.Valuable_Deductible);
            await helper.selectDropdown((this.type).nth(1),data.Valuable_Validation_method);
            await helper.typeText(this.value,data.Valuable_Cost);
            await helper.click(this.addButton);
        }else{
            await this.selectValuableType(data.Valuable_Type);
            await this.setValuableDesc(data.Valuable_Desc);
            await helper.typeText(this.value,data.Valuable_Cost);
            await helper.click(this.addButton);
        }


    }

    async isValuablesAvailableInPolicyFromBackEnd(policy,data){
        var content = await dataFetch.getPolicyChangeData(policy);
        var count = content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems.length;
        var covFlag = false;
        for (var i=0; i<count; i++){    
            if(environment.includes('granite')){
                if(content.lobData.homeowners.offerings[0].coverages.schedules[0].displayName == data.ValuableItem_granite){
                    assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[i].itemData.ArticleType.typeCodeValue,data.Valuable_Type,'Valuables is not added to policy');
                    assert.assertEqual((content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[i].itemData.ArticleLimit.integerValue).toString(),(data.Valuable_Cost).toString(),'Valuables is not added to policy');
                    covFlag = true;
                }
            }else{
                if(content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[i].itemData.SchedItemDescriptionId.stringValue == data.Valuable_Desc){
                    assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[i].itemData.ArticleType.typeCodeValue,data.Valuable_Type,'Valuables is not added to policy');
                    assert.assertEqual((content.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[i].itemData.SchedItemValueId.integerValue).toString(),(data.Valuable_Cost).toString(),'Valuables is not added to policy');
                    covFlag = true;
                }

            }
        }
        return covFlag;
    }

    async clickEditValuable(){
        await helper.click(this.editValuableButton);
    }
    async isValuableRemoved(data){
        await assert.elementNotPresent((this.addedDesc).withText(data.Valuable_Desc),'Valuable is still present in the page');
    }
    async clickRemoveValuable(){
        await helper.click(this.removeValuableButton);
        await modal.confirm();
    }









}
