import { Selector, ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
import DataFetch from '../Data/DataFetch';

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
const modal = new Modal();
const dataFetch = new DataFetch();

export default class BOPGeneralCoverages {
    constructor() {
        this.generalCoverageHeader = Selector("[id='generalCoveragesPage']");
        this.accountLink = Selector("a[class*='gwWizardPageAssociated']");
        this.employeeDishonestyLimit = Selector("div[id*='ClauseTerm_[BOPEmpDisCov]'][class*='typeaheadMultiSelect']");
        this.employeeDishonestyLimitOption = Selector("div[id*='ClauseTerm_[BOPEmpDisCov]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.noOfCoveredEmployee = Selector("input[id*='ClauseTerm_[BOPEmpDisCov]']").nth(0);
        this.noOfCoveredLocations = Selector("input[id*='ClauseTerm_[BOPEmpDisCov]']").nth(1);
        this.limitOccurenceSelect = Selector("[id='ClauseTerm_[BOPLiabilityCov]_[0]']");
        this.limitOccurenceOption = Selector("[id='ClauseTerm_[BOPLiabilityCov]_[0]'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.pdDeductible = Selector("div[id*='ClauseTerm_[BOPLiabilityCov]_[1]'][class*='typeaheadMultiSelect']");
        this.pdDeductibleOption = Selector("div[id*='ClauseTerm_[BOPLiabilityCov]_[1]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.pdDeductibleType = Selector("div[id*='ClauseTerm_[BOPLiabilityCov]_[2]'][class*='typeaheadMultiSelect']");
        this.pdDeductibleTypeOption = Selector("div[id*='ClauseTerm_[BOPLiabilityCov]_[2]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.splCoveragesPackages = Selector("div[id*='ClauseTerm_[BOPAdditionalCov]'][class*='typeaheadMultiSelect']");
        this.splCoveragesPackagesOption = Selector("div[id*='ClauseTerm_[BOPAdditionalCov]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.otherNonOwnedAutoLiability = Selector("input[id='_BOPNonOwnedAutoCov']").sibling('span');
        this.otherHiredAuto = Selector("input[id='_BOPHiredAuto']").sibling('span');
        this.propOptionalCoveragesDeductible = Selector("[id='ClauseTerm_[BOPPropertyCov]_[1]']");
        this.propOptionalCoveragesDeductibleOption = Selector("[id='ClauseTerm_[BOPPropertyCov]_[1]'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.propCauseOfLoss = Selector("div[id*='ClauseTerm_[BOPPropertyCov]_[4]'][class*='typeaheadMultiSelect']");
        this.propCauseOfLossOption = Selector("div[id*='ClauseTerm_[BOPPropertyCov]_[4]'][class*='typeaheadMultiSelect'] div[class*='TypeaheadMultiSelectField-module__menu'] div");
        this.contToolsAddButton= Selector("[id='scheduleItemContainer'] button");
        this.contToolsSchDesc = Selector("input[id='Description']");
        this.contToolsSchCurr = Selector("input[id='EquipmentValue']");
        this.contToolsSchInsuredVal = Selector("[id='scheduleItemContainer'] td").nth(3);
        this.contToolsSchDescView = Selector("[id='scheduleItemContainer'] td").nth(2);
        this.contToolsSchCancelButton = Selector("[id='scheduleItem_[0]'] button").nth(0);
        this.contToolsSchTable = Selector("[id='scheduleItemContainer'] table");
        this.contToolsSchAddButton = Selector("[id='scheduleItem_[0]'] button").nth(1);
        this.contToolsSchDeleteIcon = Selector("[id='scheduleItemContainer'] table button").nth(0);
        this.contToolsSchEditIcon = Selector("[id='scheduleItemContainer'] table button").nth(1);
        this.contToolsSchDeleteCancel = Selector("[id='modalProvider'] button").nth(1);
        this.contToolsSchDeleteYes = Selector("[id='modalProvider'] button").nth(2);
    }
    async clickOnAccountLinkFromWizard() {
        await helper.click(this.accountLink);
        await modal.confirm();
    }
    async setLimitsOccurenceCoverage(data){
        await helper.selectDropdown(this.limitOccurenceSelect,this.limitOccurenceOption,data.LimitsOccurence);
    }
    async isLimitsOccurenceCoverageSaved(data){
        await assert.assertEqual(await helper.getTextAtLocator(this.limitOccurenceSelect),data.LimitsOccurence,'Limit Occurence not saved');
    }
    async selectPDDeductible(option) {
        await helper.selectDropdown(this.pdDeductible,this.pdDeductibleOption, option);
    }
    async selectPDDeductibleType(option) {
        await helper.selectDropdown(this.pdDeductibleType,this.pdDeductibleTypeOption,option);
    }
    async selectSplCoveragePackages(option) {
        await helper.selectDropdown(this.splCoveragesPackages,this.splCoveragesPackagesOption,option);
    }
    async selectOtherIncludedCoverages() {
        await helper.click(this.otherNonOwnedAutoLiability);
        await helper.click(this.otherHiredAuto);
    }
    async selectPropOptionalCoveragesDeductible(option) {
        await helper.selectDropdown(this.propOptionalCoveragesDeductible,this.propOptionalCoveragesDeductibleOption,option)
    }
    async selectPropCauseOfLoss(option) {
        await helper.selectDropdown(this.propCauseOfLoss,this.propCauseOfLossOption,option);
    }
    async clickOnAddContractorTools() {
        await helper.click(this.contToolsAddButton);
    }
    async setDataOnContractorTools(data){
        await this.enterContToolsScheduledDesc(data.ContToolsScheduledDesc);
        await this.enterContToolsScheduledCurrency(data.ContToolsScheduledCurrency);
    }
    async setNewDataOnContractorTools(data){
        await this.enterContToolsScheduledDesc(data.ContractorToolsDescNew);
        await this.enterContToolsScheduledCurrency(data.InsuredValueNew); 
    }
    async enterContToolsScheduledDesc(option) {
        await helper.typeText(this.contToolsSchDesc, option);
    }
    async enterContToolsScheduledCurrency(option) {
        await helper.typeText(this.contToolsSchCurr, option);
    }
    async clickOnCancelForSI() {
        await helper.click(this.contToolsSchCancelButton);
    }
    async clickOnAdd() {
        await helper.click(this.contToolsSchAddButton);
    }
    async isContractorToolAdded(data) {
        await assert.assertEqual((await helper.getTextAtLocator(this.contToolsSchDescView)).replace(/\t/g, ''),data.ContToolsScheduledDesc,'Description is incorrect');
        await assert.assertEqual((await helper.getTextAtLocator(this.contToolsSchInsuredVal)).replace(/\t/g, ''),'$'+data.ContToolsScheduledCurrency,'Insured Value is incorrect');    
    }
    async isContractorToolNotAdded() {
        await assert.elementNotPresent(this.contToolsSchTable,'Contractor Tools details added');
    }
    async isContractorToolEdited(data){
        await assert.assertEqual((await helper.getTextAtLocator(this.contToolsSchDescView)).replace(/\t/g, ''),data.ContractorToolsDescNew,'Edited Description is not saved');
        await assert.assertEqual((await helper.getTextAtLocator(this.contToolsSchInsuredVal)).replace(/\t/g, ''),'$'+data.InsuredValueNew,'Edited Insured Value is not saved');    
    }
    async removeContractorTools() {
        await helper.click(this.contToolsSchDeleteIcon);
        await helper.click(this.contToolsSchDeleteYes);
    }
    async clickOnEdit() {
        await helper.click(this.contToolsSchEditIcon);
    }
    async clickOnCoverageCheckbox(coverageName) {
        var coverage = await this.getCoverageEntry(coverageName);
        await helper.click(Selector(coverage).parent(1).find('[role="checkbox"]'));

    }
    async getCoverageEntry(cvgName) {
        var cvg = Selector("[class*='digitalFieldLabel FieldLabel-module__fieldLabel']");
        for (let i = 0; i < await cvg.count; i++) {
            var coverage = Selector("[class*='digitalFieldLabel FieldLabel-module__fieldLabel']").nth(i);
            if ((await helper.getTextAtLocator(coverage)).includes(cvgName) ) {
                return coverage;
            }
        }
    }

    async setEmployeeDishonestyCoverageTerms(coverageDetails) {
        await helper.selectDropdown(this.employeeDishonestyLimit,this.employeeDishonestyLimitOption,coverageDetails.EmployeeDishonestyLimit);
        await helper.typeText(this.noOfCoveredEmployee, coverageDetails.NumberOfCoveredEmployees);
        await helper.removeText(this.noOfCoveredLocations);
        await helper.typeText(this.noOfCoveredLocations, coverageDetails.NumberOfCoveredLocations);
    }
    
    async isGeneralCoveragesPageLoaded(){
        await assert.assertEqual(await helper.getTextAtLocator(this.generalCoverageHeader),'General Coverages','General Coverage page is not loaded');
    }
    async validateContractorToolsAddButtonIsDisabled(){
        await assert.isElementNotClickable(this.contToolsSchAddButton,'disabled','Add button in contractor tools is enabled');
    }
    async validateContractorToolsAddButtonIsEnabled(){
        await assert.isElementClickable(this.contToolsSchAddButton,'disabled','Add button in contractor tools is disabled');
    }
    async validateEmployeeDishonestyTermsInBackend(policyNum, coverageData) {
        var policyChange = await dataFetch.getPolicyChangeData(policyNum);
        var Employee_Dishonesty_Limit;
        var No_Covered_Employees;
        var No_Covered_Locations;
        var lineGenCoveIteration = policyChange.lobData.businessOwners.coverages.lobCoverages;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name === 'Employee Dishonesty') {
                Employee_Dishonesty_Limit = element.terms[0].chosenTermValue;
                No_Covered_Employees = element.terms[1].chosenTermValue;
                No_Covered_Locations = element.terms[2].chosenTermValue;
            }
        }
        await assert.assertEqual(Employee_Dishonesty_Limit, coverageData.EmployeeDishonestyLimit, 'Employee Dishonesty Limit does not match');
        await assert.assertEqual(No_Covered_Employees, coverageData.NumberOfCoveredEmployees, 'Number of covered employees does not match');
        await assert.assertEqual(No_Covered_Locations, coverageData.NumberOfCoveredLocations, 'Number of covered locations does not match');

    }
    async isEmployeeDishonestySelectedInBackend(policyNum) {
        var policyChange = await dataFetch.getPolicyChangeData(policyNum);
        var Employee_Dishonesty_Selected;
        var lineGenCoveIteration = policyChange.lobData.businessOwners.coverages.lobCoverages;
        var baseCovCount = lineGenCoveIteration.length;
        for (let i = 0; i < baseCovCount; i++) {
            const element = lineGenCoveIteration[i];
            if (element.name === 'Employee Dishonesty') {
                Employee_Dishonesty_Selected = element.selected;
            }
        }
        await assert.assertEqual(Employee_Dishonesty_Selected, true, 'Employee Dishonesty is not  selected in backend');
    }
    async validateEmployeeDishonestyFieldsAreEmpty() {
        await assert.elementPresent(this.noOfCoveredEmployee, 'Employee Dishonesty is not  selected');
        await assert.assertEqual(await helper.getTextAtLocator(this.noOfCoveredEmployee), '', 'Number of Covered Employees not empty');
    }
    async clickNext() {
        await common.goNext();
    }
    async pressCancelAndConfirm() {
        await common.pressCancel();
        await modal.confirm();
    }
    async goPrevious() {
        await common.goPrev();
    }
    async setgeneralCoverages(data) {
        await this.selectPDDeductible(data.PDDeductible);
        await this.selectPDDeductibleType(data.PDDeductibleType);
        await this.selectSplCoveragePackages(data.SplCoveragePackages)
        await this.selectOtherIncludedCoverages();
        await this.selectPropOptionalCoveragesDeductible(data.OptionalCoveragesDeductible);
        await this.selectPropCauseOfLoss(data.CauseOfLoss);
    }

}