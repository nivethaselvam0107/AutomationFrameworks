import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';

const data = require('../Data/PE_Data.json');
const helper = new Helper();
const assert = new Assertion();
var accnum;
var number;
var policyCount = "[title='Policies'][href*='/accounts/"+accnum+"/summary']";   
var openActivities = "[href*='/accounts/"+accnum+"/activities']"   
var jobNumberLink = "a[href*='"+number+"']";
var accountnamelink = "[title='Account'][href*='/accounts/"+accnum+"/summary']";
export default class AccountsLanding {
    constructor() {
       
        this.title = Selector("[id='pageTitle']");   
        this.defaultTitle = Selector("[class*='TileComponent_gwTileTitle']").nth(0);   
        this.recentlyCreated = Selector("[class*='TileComponent_gwTileTitle']").nth(1);   
        this.accountNumber = Selector("[id='pageTitle']");   
        this.accountSummaryTitle = Selector("[id='accountTilesTitleHeader']")   
        this.searchResult = Selector("accounts.detail.summary({accountNumber:policyInfo.accountNumber})");
        this.openAccountLink = Selector("a[href*='accounts/activities']");   
        this.activitiesComponent = Selector("[id='titleHeader'][class*='OpenActivities']");   
        this.firstAccLink = Selector("a[title='Account']").nth(0);

    }
    async goToAccountFromPolicySearch() {
        await helper.click(this.searchResult);
    }
    async isOpenActivitiesTileOpened() {
        await assert.elementPresent(this.activitiesComponent, 'Open Activities tile was not opened')
    }

    async showRecentlyCreated() {
        await helper.click(this.recentlyCreated);
        await t.wait(2000);
    }
    async isAccountSummaryPageLoaded(accountNumber) {
        await assert.textContains(await helper.getTextAtLocator(this.accountSummaryTitle),accountNumber, 'Account Page was not loaded correctly');
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.accountsTitle, 'Accounts landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, data.defaultTitle, 'Recently Viewed is not default tile');
    }
    async clickPolicyCountLink(accountNumber) {
        var policycountLink = policyCount.replace(accnum, accountNumber)
        await helper.click(Selector(policycountLink));
    }
    async clickOpenActivitiesLink(accountNumber) {
        var openactivitiesLink = openActivities.replace(accnum, accountNumber)
        await helper.click(Selector(openactivitiesLink));
    }

    async clickAccountNameLink(number) {
        var namelink = accountnamelink.replace(accnum, number)
        await t.wait(1000);
        await helper.click(Selector(namelink));
    }
    async openFirstAccount() {
        await helper.click(this.firstAccLink);
    }
    async openJob(jobNumber){ 
        var jobLink = jobNumberLink.replace(number, jobNumber)
        await helper.click(Selector(jobLink));
    }

}
