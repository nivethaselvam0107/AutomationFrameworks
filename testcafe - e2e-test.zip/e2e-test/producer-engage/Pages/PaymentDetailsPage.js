import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
const dataPE = require("../../producer-engage/Data/PE_PA_Data.json");
const dataQnB = require("../Data/QnB_PA_Data.json");


const helper = new Helper();
const assert = new Assertion();

export default class PaymentDetailsPage {
  constructor() {
    this.invalid_CC_Error = Selector("[id*='creditCardNumber'] div");  
    this.paymentMehodBank = Selector("[value='wire']");
    this.finishButton = Selector("[id='gw-wizard-Next']");  
    this.paymentMethod = Selector("[id='paymentOptions']");  
    this.paymentOption = Selector("[id='paymentOptions'] div[class*='TypeaheadMultiSelectField__menu'] div");  
    this.creditCardNumberTxt = Selector("[id='creditCardNumber']");  
    this.accountNumber = Selector("[id='accountNumber']");  
    this.routingNumber = Selector("[id='abaNumber']");  
    this.bankName = Selector("[id='bankName']");  
    this.creditCardMonthDropDown = Selector("[id='expirationMonth']");  
    this.creditCardMonthOption = Selector("[id='expirationMonth'] div[class*='TypeaheadMultiSelectField__menu'] div"); 
    this.creditcardYearDropDown = Selector("[id='expirationYear']");  
    this.creditcardYearOption = Selector("[id='expirationYear'] div[class*='TypeaheadMultiSelectField__menu'] div"); 
  }
                                                    
  async goNext() {
    await helper.click(this.finishButton);
  }
  async setAccountNumber(AccountNumber) {
    await helper.typeText(this.accountNumber, AccountNumber);
  }
  async setABARoutingNumber(RoutingNumber) {
    await helper.typeText(this.routingNumber, RoutingNumber);
  }
  async setBankName(BankName) {
    await helper.typeText(this.bankName, BankName);
  }
  async setPaymentPlan() {
    await helper.click(this.paymentMehodBank);
  }
  async setPaymentMethod(option) {
    await helper.selectDropdown(this.paymentMethod, this.paymentOption, option);
  }
  async setCreditCardNumber(){
       await helper.typeText(this.creditCardNumberTxt, dataQnB.paymentDetails.CreditCardNumber);
  }
  async setCardNumber(ccNumber) {

    await helper.typeText(this.creditCardNumberTxt, ccNumber);
  }
  async setExpirationDate()
  {
    await helper.selectDropdown(this.creditCardMonthDropDown,this.creditCardMonthOption ,dataQnB.paymentDetails.ExpiryMonth);
    await helper.selectDropdown(this.creditcardYearDropDown,this.creditcardYearOption,dataQnB.paymentDetails.ExpiryYear);
  }

  async areCreditCardPaymentFieldsMarkedWithMandatoryError(text) {
    await assert.assertEqual(
      this.creditCardFieldValidationError.innerText,
      text,
      "Credit Card Number is Not marked with Error"
    );
    await assert.assertEqual(
      this.expirationFieldValidationError.innerText,
      text,
      "Credit Card Expiration date is not marked with Error"
    );
    
  }
  async  setExpirationDateCP(option)
  {
    await helper.selectDropdown(this.creditCardMonthDropDown, this.creditCardMonthOption,option.ExpirationMonth);
    await helper.selectDropdown(this.creditcardYearDropDown,this.creditcardYearOption,option.ExpirationYear);
  }

  async isCreditCardNumberMarkedWithInvalidError(error) {

    await assert.assertEqual(await helper.getTextAtLocator(this.invalid_CC_Error), error, "Credit card number field not marked with error properly");
  }

  async payMonthlyPremiumWithSavingsBankAccount() {
    await this.setPaymentMethod('Bank Account');
    await this.setAccountNumber(dataPE.AccountNumber);
    await this.setABARoutingNumber(dataPE.RoutingNumber);
    await this.setBankName(dataPE.BankName);
  }

  async payMonthlyPremiumWithSavingsBankAccountWC7(accountNumber, routingNumber, bankName) {
    await this.setPaymentMethod('Bank Account');
    await this.setAccountNumber(accountNumber);
    await this.setABARoutingNumber(routingNumber);
    await this.setBankName(bankName);
  }
}
