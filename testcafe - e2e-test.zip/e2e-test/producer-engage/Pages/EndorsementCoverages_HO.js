import { Selector } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from '../../producer-engage/Data/DataFetch';
 
const environment = process.env.TEST_ENV_URL;
const dataFetch = new DataFetch();
 
const helper = new Helper();
const assert = new Assertion();

export default class EndorsementCoverages_HO {
    constructor() {
        this.HO_OtherLimitDwell = Selector("div[id*='Personal_Property_HOE]_[0]']:nth-child(1)");
        this.dwellOption = Selector("div[id*='Personal_Property_HOE]_[0]']:nth-child(1)").find("div[class*='TypeaheadMultiSelectField__menu'] div");
        this.title = Selector("#hoPolicyChangeCoveragePageTitle");
    }

    async setLimitPercentOfDwel(data){
        await helper.selectDropdown(this.HO_OtherLimitDwell,this.dwellOption,data.LimitCovValue);
    }
    async verifyPageTitle(){
        await assert.assertEqual(await helper.getTextAtLocator(this.title),'Coverages','Coverage title is incorrect');
    }
    
    async isHOBaseCoverageLimitChangesAvailableInPolicy(policy,data){
        var content = await dataFetch.getPolicyChangeData(policy);
        if(environment.includes('granite')){
            await assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.baseCoverages[0].terms[0].name,data.LimitCovName_granite,'Coverage is not added to the policy');
            await assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.baseCoverages[0].terms[0].chosenTermValue,data.LimitCovValue,'Coverage is not added to the policy');
        }else{
            await assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.baseCoverages[0].terms[0].name,data.LimitCovName,'Coverage is not added to the policy');
            await assert.assertEqual(content.lobData.homeowners.offerings[0].coverages.baseCoverages[0].terms[0].chosenTermValue,data.LimitCovValue,'Coverage is not added to the policy');
        }
    }


   
  





}