import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from './Tiles';
const helper = new Helper();
const assert = new Assertion();
var policyNumberValues = "[class*='digitalRow Table'] td:nth-child(3)";

export default class OpentransactionTileView {
    constructor() {
     this.searchfield = Selector("input[id='searchFilter']");
     this.filter = Selector("div[id='dropDownFilter']");
     this.jobnumber = Selector("[class*='digitalRow Table'] th:nth-child(1)");
     this.status = Selector("[class*='digitalRow Table'] th:nth-child(2)");
     this.policynumber = Selector("[class*='digitalRow Table'] th:nth-child(3)");
     this.type = Selector("[class*='digitalRow Table'] th:nth-child(4)");
     this.periodstatus = Selector("[class*='digitalRow Table'] th:nth-child(5)");
     this.effdate = Selector("[class*='digitalRow Table'] th:nth-child(6)");
    }
    async validateAllOpenTransactionTileComponents() {
        await assert.elementPresent(this.searchfield, 'Search field is not present on the page');
        await assert.elementPresent(this.filter, 'Filter field is not present on the page');
        var defaultFilterValue = await helper.getValueAttributeFromLocator(this.filter);
        await assert.assertEqual(defaultFilterValue,'All','Default value at filter dropdown list is incorrect');
        await this.validateTransactionTableColums();
        await this.validatePolicyNumbersForThreeTypesOfTransactions();
        
    }
    async validateTransactionTableColums() {
        await assert.elementPresent(this.jobnumber, 'Job number column is not present on the page');
        await assert.elementPresent(this.status, 'Transaction status column is not present on the page');
        await assert.elementPresent(this.policynumber, 'Policy number column is not present on the page');
        await assert.elementPresent( this.type, 'Type column is not present on the page');
        await assert.elementPresent( this.periodstatus, 'Period status column is not present on the page');
        await assert.elementPresent (this.effdate, 'Effective date column is not present on the page');
    }

    async validatePolicyNumbersForThreeTypesOfTransactions(){
        var policy = await helper.getTextAtLocator(Selector(policyNumberValues).nth(0));
        var policy1 = await helper.getTextAtLocator(Selector(policyNumberValues).nth(1));
        var policy2 = await helper.getTextAtLocator(Selector(policyNumberValues).nth(2));
        if(policy === '-' && policy1.matches('\\d*') && policy2.matches('\\d*')){
            return true;
        }else{
            return false;
        }


    }
}
