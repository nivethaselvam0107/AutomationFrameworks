import { Selector,t } from 'testcafe'
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import Login from '../Login';
import AgentDashboard from '../Pages/AgentDashboard';
import AccountSearch from '../Pages/AccountSearch';
import AccountCreate from '../Pages/AccountCreate'
import QuoteStart from '../Pages/QuoteStart'
import PolicySummary from '../Pages/PolicySummary';
import Helper from '../../Utilities/Helper';
import BOPPolicyDetailsPage from './BOPPolicyDetailsPage';
import BOPQualification from './BOPQualification';
import BOPGeneralCoverages from './BOPGeneralCoverages';
import BOPAdditionalCoverages from './BOPAdditionalCoverages';
import BOPLocationsAndBuildings from './BOPLocationsAndBuildings';
import BOPQuote from './BOPQuote';
import BOPAdditionalInfo from './BOPAdditionalInfo';
import BOPPolicyInfo from './BOPPolicyInfo';
import BOPPaymentDetails from './BOPPaymentDetails';
import BOPPaymentSuccessful from './BOPPaymentSuccessful';
import CommonLocators from '../../Utilities/CommonLocators';
import NavBar from './NavBar';
const data = require('../Data/PE_BOP_Data.json');

const common = new CommonLocators();
const policyGen = new PolicyGenerator();
const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const accountCreate = new AccountCreate();
const quoteStart = new QuoteStart();
const agentDashboard = new AgentDashboard();
const policySummary = new PolicySummary();
const policyDetails = new BOPPolicyDetailsPage();
const qualification = new BOPQualification();
const genCov = new BOPGeneralCoverages();
const addCov = new BOPAdditionalCoverages();
const locAndBuildings = new BOPLocationsAndBuildings();
const quote = new BOPQuote();
const additionalInfo = new BOPAdditionalInfo();
const policyInfo = new BOPPolicyInfo();
const payment = new BOPPaymentDetails();
const paymentSuccessful = new BOPPaymentSuccessful();


export default class PolicyChange {
    constructor() {

    }
    async goToPolicySummary(policyType) {
        if (policyType == "PersonalAuto") {
            var policyData = await policyGen.createBasicBoundPAPolicy();
        } else if (policyType == "HomeOwners") {
            var policyData = await policyGen.createBasicBoundHOPolicy();
        } else if (policyType == "BusinessOwners") {
            var policyData = await policyGen.createBasicBoundBOPolicy();
        } else if (policyType == 'CommercialProperty') {
            var policyData = await policyGen.createBasicBoundCPPolicy();
        }
        await login.loginasDiffUser(policyData.producerCode);
        await agentDashboard.searchUsingSearchBox(policyData.policyNum);
        await agentDashboard.goToPolicyFromPolicySearch();
        return policyData;
    }
    async goToPolicyChangePage(policyType){
        var policyData = await this.goToPolicySummary(policyType); 
        await policySummary.clickChangePolicyButton();
        return policyData;
    }
  
    async goToBOPPolicyChangePage() {
        await login.login();
        await nav.clickStartNewQuote();
        await accountSearch.accountSearchForPersonal(data.BOP);
        await accountSearch.clickContinueAsNewcustomer();
        await accountCreate.fillAccountCreate(data.BOP);
        await accountCreate.clickNext();
        await quoteStart.fillQuoteDetails(data.BOP);
        await accountCreate.clickSubmit();
        await policyDetails.setPolicyDetails(data.BOP);
        await policyDetails.clickNext();
        await qualification.clickNext();
        await genCov.setgeneralCoverages(data.BOP);
        await genCov.clickNext();
        await addCov.clickNext();
        await locAndBuildings.addBuildingDetails(data.BOP);
        await locAndBuildings.clickAddBuildingButton();
        await locAndBuildings.navigateToQuotePage();
        await quote.clickNext();
        await additionalInfo.clickNext();
        await policyInfo.removeEmailAndPhone();
        await policyInfo.setPolicyInfoPage(data.BOP);
        await policyInfo.clickNext();
        await payment.setpaymentDetailsBank(data.BOP);
        await payment.clickNext();
        var policyData = await paymentSuccessful.getPolicyNumber();
        await t.wait(2000);
        await paymentSuccessful.clickPolicyNumber();
        await policySummary.clickChangePolicyButton();
        return policyData;
    }
    async makeBOPChangesAndConfirm(data) {
        let policyNum = await this.goToBOPPolicyChangePage();
        var jobNumber = await policyDetails.getJobNumber();
        await policyDetails.clickNext();
        await genCov.clickOnCoverageCheckbox('Employee Dishonesty');
        await genCov.setEmployeeDishonestyCoverageTerms(data);
        await genCov.clickNext();
        await addCov.setGuestPropertyInSafeDepositCoverage(data.GuestPropSafeDepositLimit);
        await addCov.clickNext();
        await locAndBuildings.clickAddBuildingIcon();
        await locAndBuildings.setBuildingData(data.BOPPropertyClassCode, data.BasisAmount);
        await locAndBuildings.enterBusinessPersonalPropLimit(data.PersonalPropertyLimit);
        await locAndBuildings.enterBuildingLimit(data.BuildingLimit);
        await locAndBuildings.clickAddBuildingButton();
        await locAndBuildings.clickNext();
        await quote.validateTransactionQuotePageForIncrease(policyNum);
        await quote.clickNext();
        await payment.clickPay();
        await payment.enterAccountNumber(data.AccountNumber);
        await payment.enterRoutingNumber(data.RoutingNumber);
        await payment.enterBankName(data.BankName);
        await payment.clickPayAndFinish();
        return jobNumber;
    }
    async makeBOPPolicychange(policyNum,data){
        var jobNumber = await policyDetails.getJobNumber();
        await policyDetails.clickNext();
        await genCov.clickOnCoverageCheckbox('Employee Dishonesty');
        await genCov.setEmployeeDishonestyCoverageTerms(data);
        await genCov.clickNext();
        await addCov.setGuestPropertyInSafeDepositCoverage(data.GuestPropSafeDepositLimit);
        await addCov.setContractorsCoverage();
        await addCov.clickNext();
        await locAndBuildings.clickAddBuildingIcon();
        await locAndBuildings.setBuildingData(data.BOPPropertyClassCode, data.BasisAmount);
        await locAndBuildings.enterBusinessPersonalPropLimit(data.PersonalPropertyLimit);
        await locAndBuildings.enterBuildingLimit(data.BuildingLimit);
        await locAndBuildings.clickAddBuildingButton();
        await locAndBuildings.clickNext();
        await quote.validateTransactionQuotePageForIncrease(policyNum);
        await quote.clickNext();
        await payment.clickPay();
        await payment.enterAccountNumber(data.AccountNumber);
        await payment.enterRoutingNumber(data.RoutingNumber);
        await payment.enterBankName(data.BankName);
        await payment.clickPayAndFinish();
        return jobNumber;
    }


}