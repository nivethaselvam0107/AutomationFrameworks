import { Selector, ClientFunction ,t} from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import AccountCreate from '../Pages/AccountCreate';
import AccountsLanding from '../Pages/AccountsLanding';
import navbar from '../Pages/NavBar';
import PolicyGenerator from '../../Utilities/Generator/PolicyGenerator';
import Login from '../Login';
import DataFetch from '../Data/DataFetch';
const PAdata = require('../Data/PE_PA_Data.json');
const login = new Login();
const policyGen = new PolicyGenerator();
const nav = new navbar();
const helper = new Helper();
const assert = new Assertion();
const accCreate = new AccountCreate();
const accLanding = new AccountsLanding();
const dataFetch = new DataFetch();
var errorMsg = 'Value entered must be a valid phone number';
var qNumber;
var number;
var quoteNumberLink = "[href*='/quotes/"+qNumber+"/summary']";
var policyNumberLink = "[href*='/policies/"+number+"/summary']";

export default class AccountSummary {
    constructor() {
        this.accountName = Selector("h1[id='accountTilesTitle']");
        this.openActivitiesTile = Selector("div[class*='TileComponent_gwTileTitle']").nth(2);
        this.issuedPoliciesTitle = Selector("[id='issuedPolicyLabel']");
        this.policyPageTitle = Selector("[gw-visuallyhidden-unless='policy.product.productName'] h1");
        this.searchResults = Selector("[id='searchResults']");
        this.accountNumber = Selector("h1[id='accountTilesTitle']");
        this.accountClaimsTile = Selector("div[id='accountDetailsTilesContainer'] a[href*='claims']");
        this.policyNumberLink = Selector("a[href='#/policies/POLICY-NUM/summary']");
        this.policyPageTitle = Selector("[gw-visuallyhidden-unless='policy.product.productName'] h1");
        this.addQuoteButton = Selector("[id='titleHeader'] [class*='fas fa-plus Button']");//selector to be changed
        this.firstPolicy = Selector("[title='Policy Number']").nth(0);
        this.accountSummaryDetails = Selector("div[class*='gw-summary-container']")
        this.TileList = Selector(" [ui-sref-active='gw-active']");
        this.editPencilBtn = Selector("[class='fas fa-pen']");
        this.addressLine1 = Selector("#addressLine1");  
        this.addressLine1Error = Selector("[id*='addressLine1'] div");  
        this.city = Selector("input[id='city']");  
        this.cityError = Selector("[id*='city'] div");  
        this.zipCode = Selector("#zipCode");  
        this.zipCodeError = Selector("[id*='zipCode'] div");
        this.saveChanges = Selector("[id='save']");
        this.homePhone = Selector("#homePhone");
        this.workPhone = Selector("#workPhone");
        this.mobileNum = Selector("#mobilePhone");
        this.homePhoneErr = Selector("[id*='homePhone'][role='alert']");
        this.workPhoneErr = Selector("[id*='workPhone'][role='alert']");
        this.mobilePhErr = Selector("[id*='mobilePhone'][role='alert']");
        this.emailAddress = Selector("#email");
        this.emailAddressErr = Selector("[id*='email'][role='alert']");
        this.homePhoneCheckbox = Selector("[for='homeRadioButtonId_home']");
        this.cancelChanges = Selector("id='cancel']");
        this.changePolicy = Selector("[id='changePolicyButtonId']");
        this.renewPolicy = Selector("[id='renewPolicyButtonId']");
        this.cancelPolicy = Selector("[id='cancelPolicyButtonId']");
        this.firstQuote = Selector("td a[href*='/quotes']").nth(0);
        this.firstJob = Selector("td a[href*='/renewal']").nth(0);
        this.policyChangeFirstJob = Selector("td a[href*='/change']").nth(0);
        this.accountTitle = Selector("[id='accountTilesTitleHeader']");
        this.summaryTile = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.openQuotesTile = Selector("[class*='TileComponent_gwTileTitle']").nth(3);
        this.openTransactionTile = Selector("[class*='TileComponent_gwTileTitle']").nth(4);
        this.openClaimsTile = Selector("[class*='TileComponent_gwTileTitle']").nth(5)
        this.billingTile = Selector("[class*='TileComponent_gwTileTitle']").nth(6);
        this.numberOfOpenActivities = Selector("[class*='TileComponent_gwTileTitle']").nth(2);
        this.automaticpaymentTile = Selector(".gw-tile[tile-title='Automatic Payments']");
        this.searchfield = Selector("input[id='searchFilter']");
        this.dropdownbox = Selector("[id='filterDropDownLayout']");
        this.dropdownoption = Selector("[id='filterDropDownLayout'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.created = Selector("tr[class*='digitalRow'] th:nth-child(1)");
        this.product = Selector("tr[class*='digitalRow'] th:nth-child(2)");
        this.quote = Selector("tr[class*='digitalRow'] th:nth-child(3)");
        this.premium = Selector("tr[class*='digitalRow'] th:nth-child(4)");
        this.status = Selector("tr[class*='digitalRow'] th:nth-child(5)");
        this.accountlink = Selector("a[ui-sref='accounts.detail.summary({accountNumber: policy.account.accountNumber})']");
        this.getDefaultselected = Selector("[id='filterDropDownLayout'] [class*='singleValue']");
        this.firstPolicyLink = Selector("[title='Policy Number']");
        this.billingAndPaymentPolicyLink = Selector("a[class*='BillingAndPayment_link']");
        this.accName = Selector("a[class*='FormattedHeaderComponent_gwHeaderLink']");
        this.recentCreated=Selector("[class*='TileComponent_gwTileConten']").nth(1);
        this.accountNameValue = Selector("#name");
        this.addressLine1Value = Selector("#addressline1");
        this.cityValue = Selector("#city");

    }
    async clickRecentlyCreatedTile() {
        await helper.click(this.recentCreated);
    }
    async titleContains(text) {
        await assert.hasText(this.accountName.innerText, text, 'Account name mismatch');
    }
    async summaryPageConfirmation() {
        await assert.elementPresent(this.issuedPoliciesTitle, 'This is not summary page');
    }
    async isSearchResultsPresent() {
        await assert.elementPresent(this.searchResults, 'Search Results are not displayed');
    }
    async goToOpenActivities() {
        await helper.click(this.openActivitiesTile);
    }
    async isAccountSummaryPageLoaded(accountNum) {
        await assert.hasText(await helper.getTextAtLocator(this.accountNumber), accountNum, "AccountSummary Page is not loaded");
    }
    async goToOpenQuotes() {
        await helper.click(this.openQuotesTile);
    }
    async goToSummaryTile(){
        await helper.click(this.summaryTile);
    }
    async clickAddQuoteButton() {
        await helper.click(this.addQuoteButton);
    }
    async openFirstJob() {
        var jobNumber = await helper.getTextAtLocator(this.firstJob);
        await helper.click(this.firstJob);
        return jobNumber;
    }
    async openFirstChangeJob(){
        var jobNumber = await helper.getTextAtLocator(this.policyChangeFirstJob);
        await helper.click(this.policyChangeFirstJob);
        return jobNumber;
    }
    async goToAccountsClaimsTile() {
        await helper.click(this.accountClaimsTile);
    }
    async goToOpenTransactionsTile() {
        await helper.click(this.openTransactionTile);
        await t.wait(2000);
    }

    async goToFirstPolicyInList() {
        await helper.click(this.firstPolicy);
    }
    async getAccountHolderName() {
        var name = await helper.getTextAtLocator(this.accountName);
        return name;
        
    }
    async goToFirstQuoteInList() {
        await helper.click(this.firstQuote);
    }
    async verifyMissingMandatoryValuesWhileEditingContactInformation() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await t.wait(2000);
        await helper.click(this.editPencilBtn);
        await helper.removeRequiredTextAndValidate(this.addressLine1,this.addressLine1Error);
        await helper.removeRequiredTextAndValidate(this.city,this.cityError);
        await helper.removeRequiredTextAndValidate(this.zipCode,this.zipCodeError);
        await assert.isElementNotClickable(this.saveChanges,'disabled','Save changes button is enabled');
    }

    async verifyInvalidZipCodeWhileEditingContactDetails() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await t.wait(2000);
        await helper.click(this.editPencilBtn);
        await helper.removeText(this.zipCode);
        await helper.typeText(this.zipCode, 'ABCD');
        await helper.pressTab();
        await assert.assertEqual(await this.zipCodeError.innerText, 'Please enter a valid ZIP code.', 'Mandatory error message for zip code Does Not Match');
        await assert.isElementNotClickable(this.saveChanges,'disabled','Save changes button is enabled');
    }
    async verifyInvalidPhoneNumberWhileEditingContactDetails() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await t.wait(2000);
        await helper.click(this.editPencilBtn);
        await helper.removeText(this.homePhone);
        await helper.typeText(this.homePhone, '234');
        await helper.pressTab();
        await helper.removeText(this.workPhone);
        await helper.typeText(this.workPhone, '234');
        await helper.pressTab();
        await helper.removeText(this.mobileNum);
        await helper.typeText(this.mobileNum, '234');
        await helper.pressTab();
        await assert.assertEqual(await this.homePhoneErr.innerText, errorMsg, 'Mandatory error message for workphone Does Not Match');
        await assert.assertEqual(await this.workPhoneErr.innerText, 'Value entered must be a valid phone number', 'Mandatory error message for workphone Does Not Match');
        await assert.assertEqual(await this.mobilePhErr.innerText, 'Value entered must be a valid phone number', 'Mandatory error message for workphone Does Not Match');
        await assert.isElementNotClickable(this.saveChanges,'disabled','Save changes button is enabled');
    }
    async verifyInvalidEmailIdWhileEditingContactDetails() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await t.wait(2000);
        await helper.click(this.editPencilBtn);
        await helper.removeText(this.emailAddress);
        await helper.typeText(this.emailAddress, 'ABC');
        await helper.pressTab();
        await assert.assertEqual(await this.emailAddressErr.innerText, 'Value must be a valid email address', 'Mandatory error message for email Does Not Match');
        await assert.isElementNotClickable(this.saveChanges,'disabled','Save changes button is enabled'); 
    }
    async verifyMissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await t.wait(2000);
        await helper.click(this.editPencilBtn);
        await helper.click(this.homePhoneCheckbox);
        await helper.removeText(this.homePhone);
        await helper.pressTab();
        await assert.assertEqual(await this.homePhoneErr.innerText, 'This is a required field', 'Mandatory error message for homephone Does Not Match');
        await assert.isElementNotClickable(this.saveChanges,'disabled','Save changes button is enabled');
    }
    async verifyViewPolicyFromAccountSummaryPage() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await helper.click(this.firstPolicyLink);
        await assert.assertEqual(this.accName.innerText, policyData.accountName, 'account name not present');
        await assert.elementPresent(this.changePolicy, 'CHANGE POLICY button is missing, Policy page did not open');
        await assert.elementPresent(this.renewPolicy, 'Renew policy button is missing, Policy page did not open');
        await assert.elementPresent(this.cancelPolicy, 'CHANGE POLICY button is missing, Policy page did not open');
    }
    async clickBillingAndPaymentTile(){
        await helper.click(this.billingTile);
    }
    async verifyViewPolicyFromAccountDetailsBilling() {
        let policyData = await policyGen.createBasicBoundPAPolicy();
        await login.loginasDiffUser(policyData.producerCode);
        await nav.goToAccountsLanding();
        await this.clickRecentlyCreatedTile();
        await accLanding.clickAccountNameLink(policyData.accountNumber);
        await this.clickBillingAndPaymentTile();
        await helper.click(this.billingAndPaymentPolicyLink);
        await assert.assertEqual(await this.accName.innerText, policyData.accountName, 'account name not present');
        await assert.elementPresent(this.changePolicy, 'CHANGE POLICY button is missing, Policy page did not open');
        await assert.elementPresent(this.renewPolicy, 'Renew policy button is missing, Policy page did not open');
        await assert.elementPresent(this.cancelPolicy, 'CHANGE POLICY button is missing, Policy page did not open');
    }
    async isquotepresented(quoteNum) {
        var quoteNumber = quoteNumberLink.replace(qNumber, quoteNum);
        await assert.elementPresent(Selector(quoteNumber), 'Quote Number is not present')

    }
    async  validateSelectedDefaultValue(data) {
        await helper.getValueAttributeFromLocator(this.getDefaultselected, data.DefaultValue, "Job filter default value is incorrect.");
    }

    async validateQuoteTileComponents(data) {
        await assert.elementPresent(this.addQuoteButton, 'Add quote button is not presented');
        await assert.elementPresent(this.searchfield, 'Search field is not presented');
        await assert.elementPresent(this.dropdownbox, 'Job filter is not presented');
        await this.validatefiltervalue();
        await this.validateSelectedDefaultValue(data);
        await assert.elementPresent(this.created, 'Created column is missing');
        await assert.elementPresent(this.product, 'Product column is missing');
        await assert.elementPresent(this.quote, 'Quote column is missing');
        await assert.elementPresent(this.premium, 'Premium column is missing');
        await assert.elementPresent(this.status, 'Status column is missing');
    }
    async isPolicyDisplayedOnAccountPage(policyNum){
        var policylink = policyNumberLink.replace(number,policyNum);
        await assert.elementPresent(Selector(policylink),'Policy number is not available in Account Summary screen');
    }
    async clickaccountname() {
        await click(this.accountlink);
    }
    async openQuoteByLink(quoteNum) {
        var quotelink = quoteNumberLink.replace(qNumber, quoteNum);
        await helper.click(Selector(quotelink));
    }
    async validatefiltervalue() {
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("[id='filterDropDownLayout'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var actualStatusList = []
        actualStatusList = await dropDownValues();
        if (actualStatusList[1] == 'Open - Not Bound')
            return true;
        else
            return false;

    }
    async clickPolicyNumber(policyNum){
        var policyNumber = policyNumberLink.replace(number,policyNum);
        await helper.click(Selector(policyNumber));

    }
}
