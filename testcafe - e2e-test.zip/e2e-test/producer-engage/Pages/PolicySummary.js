import { Selector, t } from 'testcafe'
import moment from 'moment';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from '../Pages/Tiles';
import PolicyCancellation from '../Pages/PolicyCancellation';
import SelectPolicy from './SelectPolicy';
import DataFetch from '../Data/DataFetch';
import PolicyGenerator, { policyData } from '../../Utilities/Generator/PolicyGenerator';
const policyGen = new PolicyGenerator();
const data = require('../Data/PE_PA_Data.json');
const helper = new Helper();
const assert = new Assertion();
const tiles = new Tiles();
const policyCancel = new PolicyCancellation();
const dataFetch = new DataFetch();
var number;
var jobNumber;
var pnum;
const policyNumLink = "[href*='/policies/"+number+"/summary']";
const jobNumberLink = "[href*='/cancellation/"+jobNumber+"/summary']";
var titleTemplate = "Cancellation (" + jobNumber + ")";
var activityRow = "[class*='ActivityTableComponent'][href*='/cancellation/"+jobNumber +"/summary']";
var policyNumberlink = "div[class='gw-breadcrumbs__item'] a[href='#/policies/" + pnum + "/summary']";


export default class PolicySummary {
    constructor() {

        this.notesTile = Selector("div[id ='policiesTileContainer'] a[href*='notes']");
        this.note = Selector("[class='gw-btn-primary ng-binding ng-scope']");
        this.changePolicyButton = Selector("[id='changePolicyButtonId']");
        this.searchInputBox = Selector("#SearchParam");
        this.policyNumber = Selector("a[id*='policyNumber']");
        this.boPolicyNumber=Selector("[class*='SearchResults_policyNumber']");
        this.accountNumber = Selector("[class*='FormattedHeaderComponent_gwHeaderLink']");
        this.documentsTile = Selector("div[id ='policiesTileContainer'] a[href*='documents']");
        this.topicSelect = Selector("#Topic");
        this.topicOption = this.topicSelect.find('option');
        this.noteBody = Selector("#note-body");
        this.noteSubject = Selector("[class*='note'] [class*='subject']");
        this.policyPageTitle = Selector("[class*='Policies_gwTitle']");
        this.boundStatus = Selector("div[class='BadgeDirective-hashed__gwBa]dge__content__OpqdP']").find("transclude");
        this.cancellationDetails = Selector("div[class='gw-flex-wrapper']");
        this.activitySelector = Selector("div[class*='DataTable-module__tableRow']").nth(1);
        this.openActivitiesTile = Selector("[id='policiesTileContainer'] [href*='activities']");
        this.claimsTile = Selector("div[id ='policiesTileContainer'] a[href*='claims']");
        this.billingTile = Selector("div[id ='policiesTileContainer'] a[href*='billing']");
        this.makeSection = Selector("[id*='vehicleMake']").parent('div');
        this.modelSection = Selector("[id*='vehicleModel']").parent('div');
        this.yearSection = Selector("[id*='vehicleYear']").parent('div');
        this.licensePlateSection = Selector("[id*='vehicleLicence']").parent('div');
        this.showVehicleCoverageLink = Selector("[id*='showContentToggleLink']");
        this.coverageSection = Selector("[id='policyVehicleInfo']").find('th').nth(0);
        this.typeSection = Selector("[id='policyVehicleInfo']").find('th').nth(1);
        this.limitSection = Selector("[id='policyVehicleInfo']").find('th').nth(2);
        this.deductibleSection = Selector("[id='policyVehicleInfo']").find('th').nth(3);
        this.premimumBreakDownSection =Selector("[id='policyVehicleInfo']").find('th').nth(4);
        this.openCoveredDriversLink = Selector("[id='driverSection']").find("[class*='accordion']");
        this.openVehicleLink = Selector("[id='vehicleSection'] [class*='accordion']");
        this.nameSection = Selector("[id*='driverSection']").find('th').nth(0);
        this.licenceSection = Selector("[id*='driverSection']").find('th').nth(1);
        this.dobSection = Selector("[id*='driverSection']").find('th').nth(2);
        this.POLICY_TRANSACTIONS_JOB_NUMBER_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Job Number']");
        this.POLICY_TRANSACTIONS_TYPE_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Transaction Status']");
        this.POLICY_TRANSACTIONS_STATUS_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Type']");
        this.POLICY_TRANSACTIONS_PERIOD_STATUS_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Period Status");
        this.POLICY_TRANSACTIONS_PREMIUM_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Premium']");
        this.POLICY_TRANSACTIONS_EFFECTIVE_DATE_SECTION = Selector("[id='summaryPolicyTransactionsTableGrid']").find("[title='Effective Date']");

        this.EXPAND_HOME_DETAILS_LINK = Selector("[id='homeDetailsCard']").find("[class*='accordion']");
        this.ADDRESS_SECTION = Selector("[id*='homeDetailsCard'] h2").nth(1);
        this.DISTANCE_TO_FIRE_HYDRANT_SECTION = Selector("[for='distancetoFireHydrant']");
        this.DISTANCE_TO_FIRE_STATION_SECTION = Selector("[for='distanceToFireStation']");
        this.FLOODING_OR_FIRE_HAZARD_SECTION = Selector("[for='floodOrFireHazard']");
        this.WITHIN_300FT_OF_COMMERCIAL_PROPERTY_SECTION = Selector("[for='within300FtOfCommercialProp");
        this.LOCATION_TYPE_SECTION = Selector("[for='dwellingLocationType']");
        this.RESIDENCE_TYPE_SECTION = Selector("[for='residenceLocationType']");
        this.HOME_IS_USED_AS_SECTION = Selector("[for='dwellingUsage']");
        this.DWELLING_OCCUPIED_SECTION = Selector("[for='occupancy']");

        this.EXPAND_CONSTRUCTION_DETAILS_LINK = Selector("[id='constructionDetailsCard']").find("[class*='accordion']"); 
        this.YEAR_BUILD_SECTION = Selector("[for='yearBuild']");
        this.FOUNDATION_TYPE_SECTION = Selector("[for='foundationType']");
        this.PLUMBING_UPGRADED_SECTION = Selector("[for='plumbingUpgraded']");
        this.ELECTRICAL_SYSTEM_SECTION = Selector("[for='electricalSystem']");
        this.NUMBER_OF_STORIES_SECTION = Selector("[for='numberOfStories']");
        this.ROOF_TYPE_SECTION = Selector("[for='roofType']");
        this.PRIMARY_HEATING_TYPE_SECTION = Selector("[for='primaryHeatingType']");
        this.WIRING_UPGRADED_SECTION = Selector("[for='wiringUpgraded']");
        this.GARAGE_SECTION = Selector("[for='hasGarage']");
        this.ROOF_UPGRADED_SECTION = Selector("[for='roofUpgraded']");
        this.HEATING_UPGRADED_SECTION = Selector("[for='heatingUpgraded']");
        this.CONSTRUCTION_TYPE_SECTION = Selector("[for='constructionType']");
        this.PLUMBING_TYPE_SECTION = Selector("[for='plumbingType']");
        this.WIRING_TYPE_SECTION = Selector("[for='wiringType']");

        this.EXPAND_PROTECTION_DETAILS_LINK = Selector("[id='protectionDetailsCard']").find("[class*='accordion']");
        this.FIRE_EXTINGUISHER_SECTION = Selector("[for='fireExtinguisher']");
        this.DEAD_BOLTS_SECTION = Selector("[for='deadBolts']");
        this.NUMBER_OF_UNITS_SECTION = Selector("[for='noOfUnits']");
        this.FLOODING_OR_LEAK_WITHIN_5YEARS_SECTION = Selector("[for='floodingOrLeakWithin5Years']");
        this.BULGAR_ALARM_SECTION = Selector("[for='burglarAlarm']");
        this.RESIDENCE_VISIBLE_TO_NEIGHBOURS_SECTION = Selector("[for='residenceVisibleToNeighbours']");
        this.FIREPLACE_OR_WOODSTOVE_SECTION = Selector("[for='fireplaceOrWoodstove']");
        this.MONITORING_CENTER_FIRE_ALARM_SECTION = Selector("[for='monitoringCenterFireAlarm']");
        this.SPRINKLER_SYSTEM_TYPE_SECTION = Selector("[for='sprinklerSystemType']");
        this.SWIMMING_POOL_SECTION = Selector("[for='swimmingPool']");
        this.SMOKE_ALARMS_SECTION = Selector("[for='smokeAlarm']");
        this.ROOMERS_OR_BORDERS_SECTION = Selector("[for='roomersOrBorders']");
        this.TRAMPOLINA_SECTION = Selector("[for='trampoline']");
        this.boundStatus = Selector("div[class='BadgeDirective-hashed__gwBa]dge__content__OpqdP']").find("transclude");
        this.cancellationDetails = Selector("div[class='gw-flex-wrapper']");
        this.activitySelector = Selector("[class='gw-activity-summary']");
        this.cancellationTitle = Selector("#pageTitleContainer")

        this.effective_Date = Selector("[placeholder='MM/DD/YYYY']");
        this.EXPAND_COVERAGES_DETAILS_LINK = Selector("[id='coveragesDetailsCard'] [class*='accordion']");
        this.SECTION_I_SECTION = Selector("#sectionICoverables");
        this.SECTION_II_SECTION = Selector("#sectionIICoverables");
        this.ADITIONAL_PROPERTY_COVERAGES_SECTION = Selector("#additionalPropertyCoverables");

        this.EXPAND_COVERAGES_LINK = Selector("[id='coveragesSectionId'] [class*='accordion']");
        this.BUSINESSOWNERS_COVERAGES = Selector("[id*='title'][class*='controlReadOnly']");
        this.changeJobLink = Selector("a[href*='/change']");
        this.renewPolicyButton = Selector("#renewPolicyButtonId");
        this.policyStatusTitle = Selector("#policyStatus");
        this.checkaddress = Selector("label[for='c_address']");
        this.addressline2 = Selector("[model='address.addressLine2'] input");
        this.saveandexit = Selector("button[on-click='exitWizard()']");
        this.policyNum_Details = Selector("[class*='Policies_gwTitle']");
        this.policyInception = Selector("[id='policyInceptionValueId']");    
        this.policyExpiration = Selector("[id='policyExpirationValueId']");
        this.policyStatus = Selector("[id='policyStatusValueId']");
        this.producerOfRecord = Selector("[id='producerOfRecordValueId']");
        this.producerOfService = Selector("[id='producerOfServiceValueId']");
        this.totalPremium = Selector("[class*='digitalCurrency CurrencyField']").nth(0);
        this.taxesAndFees = Selector("[class*='digitalCurrency CurrencyField']").nth(1);
        this.totalCost = Selector("[class*='digitalCurrency CurrencyField']").nth(2);;
    
    }
    async goToDocumentsTile() {

        await helper.click(this.documentsTile);
    }
    async goToOpenActivitiesTile() {

        await helper.click(this.openActivitiesTile);
    }
    async clickChangePolicyButton() {
        await helper.click(this.changePolicyButton);
    }
    async goToclaimsTile() {
        await helper.click(this.claimsTile);
    }

    async clickAccountNumber(){
        await helper.click(this.accountNumber);
    }
    async typeNote(note) {
        await helper.typeText(this.noteBody, note);
    }
    async validationForNotePresent() {
        await assert.elementPresent(this.noteSubject, 'Note is not get added')
    }
    async selectTopic(option) {
        await helper.selectDropdown(this.topicSelect,this.topicOption, option);
    }
    async searchPolicyNumber() {
        await helper.click(this.policyNumber);
    }
    async searchBOPolicyNumber() {
        await helper.click(this.boPolicyNumber);
    }

    async goToPolicySummaryPage(policyNum) {
        var Link= "[href='/producer-engage-ferrite/policies/"+number+"/summary']";
        var policylink = Link.replace(number, policyNum)
        await helper.click(Selector(policylink));
    }
    async goToNotesTile() {
        await helper.click(this.notesTile);

    }
    async clickAddNote() {
        await helper.click(this.note);
    }

    async validateCanceledPolicyStatus() {
        assert.assertEqual(await this.policyStatusTitle.innerText, 'Canceled');
    }
    async isPolicyDetailsPageLoaded(policy) {
        await this.validatePolicySummaryPageLoaded(policy);
    }

    async openPolicySummaryOfChangedPolicy() {
        await helper.click(this.changeJobLink);
    }


    async validatePolicySummaryPageLoaded(policy) {
        var title = await helper.getTextAtLocator(this.policyPageTitle);
        await assert.assertEqual(title.replace(/\D+/g, ""), policy, 'Policy Number Does Not Match');
        await tiles.validateTileOpened('SUMMARY');
    }
    
    async goCancellationSummaryPage(jobNum) {
        var jobLink = jobNumberLink.replace(jobNumber, jobNum)
        await helper.click(Selector(jobLink));
    }
    async isCancellationPagePresented(jobNum) {
        await assert.hasText(await this.cancellationTitle.innerText, jobNum, 'Cancellation page opened incorrectly')
    }

    async isBuildingPresentOnPolicyOnBackend(policyNum, description) {
        var policyData = await policyGen.getAgentPolicyData(policyNum);
        var buildingDescriptionChanged;
        var lineGenCoveIteration = policyData.coverables;
        var CovCount = lineGenCoveIteration.length;
        for (let i = 0; i < CovCount; i++) {
            const element = lineGenCoveIteration[i];
            var buildingDescription = element.name.split(': ')[1];
            if (buildingDescription === description) {
                buildingDescriptionChanged = true;
            }
        }
        await assert.assertEqual(buildingDescriptionChanged, true, 'Building Description is not changed');
    }
    
    async isAddedActivityAvailable(jobNum) {
        await assert.elementPresent(Selector(activityRow.replace(jobNumber,jobNum)), 'Activity is not added');   
    }

    async isAddedActivityNotAvailable(jobNum) {
        await assert.elementNotPresent(Selector(activityRow.replace(jobNumber,jobNum)), 'Activity should not be available')
    }
    async validateRenewPolicyButtonNotPresent() {
       await  assert.elementNotPresent(this.renewPolicyButton, 'renew policy button available');
    }

    async verifyVehiclesSection() {
        await helper.click(this.openVehicleLink);
        await assert.elementPresent(this.makeSection, 'Make section is missing.');
        await assert.elementPresent(this.modelSection, 'Mpdel section is missing.');
        await assert.elementPresent(this.yearSection, 'Year section is missing.');
        await assert.elementPresent(this.licensePlateSection, 'License Plate section is missing.');
        await helper.click(this.showVehicleCoverageLink);
        await assert.elementPresent(this.coverageSection, 'Coverage section is missing');
        await assert.elementPresent(this.typeSection, 'Type section is missing');
        await assert.elementPresent(this.limitSection, 'Limit section is missing');
        await assert.elementPresent(this.deductibleSection, 'Deductible section is missing');
        await assert.elementPresent(this.premimumBreakDownSection, 'Premium Breakdown section is missing');
    }

    async verifyCoveredDriversSections() {
        await helper.click(this.openCoveredDriversLink);
        await assert.elementPresent(this.nameSection, 'Name section is missing');
        await assert.elementPresent(this.dobSection, 'DOB section is missing');
        await assert.elementPresent(this.licenceSection, 'License Section is missing');
    }
    async verifyPolicyTransactionsSections() {
        await assert.elementPresent(this.POLICY_TRANSACTIONS_JOB_NUMBER_SECTION, "Job number section is missing.");
        await assert.elementPresent(this.POLICY_TRANSACTIONS_STATUS_SECTION, "Status section is missing.");
        await assert.elementPresent(this.POLICY_TRANSACTIONS_TYPE_SECTION, "Type section is missing.");
        await assert.elementPresent(this.POLICY_TRANSACTIONS_PERIOD_STATUS_SECTION, "Period status section is missing.");
        await assert.elementPresent(this.POLICY_TRANSACTIONS_PREMIUM_SECTION, "premium section is missing.");
        await assert.elementPresent(this.POLICY_TRANSACTIONS_EFFECTIVE_DATE_SECTION, "Effective date section is missing.");

    }
    async verifyHomeDetailsSections() {
        await helper.click(this.EXPAND_HOME_DETAILS_LINK);
        await assert.elementPresent(this.ADDRESS_SECTION, "Address section is missing.");
        await assert.elementPresent(this.DISTANCE_TO_FIRE_HYDRANT_SECTION, "Distance to Fire Hydrant section is missing.");
        await assert.elementPresent(this.DISTANCE_TO_FIRE_STATION_SECTION, "Distance to Fire Station section is missing.");
        await assert.elementPresent(this.FLOODING_OR_FIRE_HAZARD_SECTION, "Flooding or Fire Hazard section is missing.");
        await assert.elementPresent(this.WITHIN_300FT_OF_COMMERCIAL_PROPERTY_SECTION, "Within 300ft of Commercial Property section is missing.");
        await assert.elementPresent(this.LOCATION_TYPE_SECTION, "Location Type section is missing.");
        await assert.elementPresent(this.RESIDENCE_TYPE_SECTION, "Residence Type section is missing.");
        await assert.elementPresent(this.HOME_IS_USED_AS_SECTION, "Home is used as section is missing.");
        await assert.elementPresent(this.DWELLING_OCCUPIED_SECTION, "Dwelling Occupied section is missing.");
    }

    async verifyConstructionDetailsSections() {
        await helper.click(this.EXPAND_CONSTRUCTION_DETAILS_LINK);
        await assert.elementPresent(this.YEAR_BUILD_SECTION, "Year Build section is missing.");
        await assert.elementPresent(this.FOUNDATION_TYPE_SECTION, "Foundation Type section is missing.");
        await assert.elementPresent(this.PLUMBING_UPGRADED_SECTION, "Plumbing Upgraded section is missing.");
        await assert.elementPresent(this.ELECTRICAL_SYSTEM_SECTION, "Electrical System section is missing.");
        await assert.elementPresent(this.NUMBER_OF_STORIES_SECTION, "No. of Stories section is missing.");
        await assert.elementPresent(this.ROOF_TYPE_SECTION, "Roof Type section is missing.");
        await assert.elementPresent(this.PRIMARY_HEATING_TYPE_SECTION, "Primary Heating Type section is missing.");
        await assert.elementPresent(this.WIRING_UPGRADED_SECTION, "Wiring Upgraded section is missing.");
        await assert.elementPresent(this.GARAGE_SECTION, "Garage section is missing.");
        await assert.elementPresent(this.ROOF_UPGRADED_SECTION, "Roof Upgraded section is missing.");
        await assert.elementPresent(this.HEATING_UPGRADED_SECTION, "Heating Upgraded section is missing.");
        await assert.elementPresent(this.CONSTRUCTION_TYPE_SECTION, "Construction type section is missing.");
        await assert.elementPresent(this.PLUMBING_TYPE_SECTION, "Plumbing type section is missing.");
        await assert.elementPresent(this.WIRING_TYPE_SECTION, "Wiring type section is missing.");

    }
    async verifyProtectionDetailsSections() {
        await helper.click(this.EXPAND_PROTECTION_DETAILS_LINK);
        await assert.elementPresent(this.FIRE_EXTINGUISHER_SECTION, "Fire extinguisher section is missing.");
        await assert.elementPresent(this.DEAD_BOLTS_SECTION, "Dead bolts section is missing.");
        await assert.elementPresent(this.NUMBER_OF_UNITS_SECTION, "Number of units section is missing.");
        await assert.elementPresent(this.FLOODING_OR_LEAK_WITHIN_5YEARS_SECTION, "Flooding or leak within 5years section is missing.");
        await assert.elementPresent(this.BULGAR_ALARM_SECTION, "Burglar alarm section is missing.");
        await assert.elementPresent(this.RESIDENCE_VISIBLE_TO_NEIGHBOURS_SECTION, "Residence visible to neighbours section is missing.");
        await assert.elementPresent(this.FIREPLACE_OR_WOODSTOVE_SECTION, "Fireplace or woodstove section is missing.");
        await assert.elementPresent(this.MONITORING_CENTER_FIRE_ALARM_SECTION, "Monitoring center fire alarm section is missing.");
        await assert.elementPresent(this.SPRINKLER_SYSTEM_TYPE_SECTION, "Sprinkler system type section is missing.");
        await assert.elementPresent(this.SWIMMING_POOL_SECTION, "Swimming pool section is missing.");
        await assert.elementPresent(this.SMOKE_ALARMS_SECTION, "Smoke alarm section is missing.");
        await assert.elementPresent(this.ROOMERS_OR_BORDERS_SECTION, "Roomers or borders section is missing.");
        await assert.elementPresent(this.TRAMPOLINA_SECTION, "Trampolina section is missing.");

    }
    async verifyCoveragesDetailsSections() {
        await helper.click(this.EXPAND_COVERAGES_DETAILS_LINK);
        await assert.elementPresent(this.SECTION_I_SECTION, "Section I is missing.");
        await assert.elementPresent(this.SECTION_II_SECTION, "Section II is missing.");
        await assert.elementPresent(this.ADITIONAL_PROPERTY_COVERAGES_SECTION, "Additional property coverages section is missing.");

    }
    async verifyCoveragesSectionsBO() {
        await helper.click(this.EXPAND_COVERAGES_LINK);
        var coverageBlocksNumber = 3;
        await assert.elementPresent(this.BUSINESSOWNERS_COVERAGES, 'coverage Blocks are missing');
        await assert.assertEqual(await this.BUSINESSOWNERS_COVERAGES.count, coverageBlocksNumber, 'Some of coverages blocks is missing.');
    }
    async verifyCoveragesSectionsCP() {
        await helper.click(this.EXPAND_COVERAGES_LINK);
        var coverageBlocksNumber = 7;
        await assert.elementPresent(this.BUSINESSOWNERS_COVERAGES, 'coverage Blocks are missing');
        await assert.assertEqual(await this.BUSINESSOWNERS_COVERAGES.count, coverageBlocksNumber, 'Some of coverages blocks is missing.');
    }

    
    async clickRenewPolicyButton() {
        await helper.click(this.renewPolicyButton);
    }

    async clickPolicyNumberLink(PolicyNum) {
        var namelink = policyNumberlink.replace(pnum, PolicyNum);
        await helper.click(Selector(namelink));
    }

    async verifyDetailsOnPolicySummaryPage(uiValue, backendValue){
        if (JSON.stringify(uiValue) == JSON.stringify(backendValue))
            return true;
        else
            return false;
    }

    async getPolicySummaryDataFromBackEnd(PolicyNum){
        const agentData = await policyGen.getAgentPolicy(PolicyNum);
        var policyDetails = [];
        var producerCodeOfSer = agentData.periods[0].producerCodeOfService;
        var producerCodeOfRec = agentData.periods[0].producerCodeOfRecord;
        var producerOfSerOrg = agentData.periods[0].producerCodeOfRecordOrg;
        var producerOfRecOrg = agentData.periods[0].producerCodeOfServiceOrg;
        var effDate = new Date(agentData.periods[0].effectiveDate);
        var polEffDate = await helper.formatDate(effDate);
        var expDate = new Date(agentData.periods[0].expirationDate);
        var polExpDate = await helper.formatDate(expDate);
        var producerOfService = producerOfSerOrg+"("+producerCodeOfSer+")";
        var producerOfRecord = producerOfRecOrg+"("+producerCodeOfRec+")";
        policyDetails.push(agentData.periods[0].policyNumber);
        policyDetails.push(moment(polEffDate).format('ll'));
        policyDetails.push(moment(polExpDate).format('ll'));
        policyDetails.push(agentData.periods[0].displayStatus);
        policyDetails.push(producerOfService);
        policyDetails.push(producerOfRecord);
        return policyDetails;

    }

    async getPolicySummaryDataFromUI(){
        var policyUIdata = [];
        var title = await helper.getTextAtLocator(this.policyNum_Details);
        var policyData = title.split(" ", 3);
        var policyNum = policyData[2].replace("(", " ").replace(")"," ").trim();
        policyUIdata.push(policyNum);
        policyUIdata.push(await helper.getTextAtLocator(this.policyInception));
        policyUIdata.push(await helper.getTextAtLocator(this.policyExpiration));
        policyUIdata.push(await helper.getTextAtLocator(this.policyStatus));
        policyUIdata.push(await helper.getTextAtLocator(this.producerOfService));
        policyUIdata.push(await helper.getTextAtLocator(this.producerOfRecord));
        return policyUIdata;
    }

    async verifyTilesOnPolicyPage(){
        await assert.elementPresent(this.openActivitiesTile,'Open Activities tile is not present');
        await assert.elementPresent(this.notesTile,'Notes tile is not present');
        await assert.elementPresent(this.documentsTile,'Document tile is not present');
        await assert.elementPresent(this.claimsTile,'Claims tile is not present');
        await assert.elementPresent(this.billingTile,'Billing tile is not present');
    }


    
}
