import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WC7PolicyDetails{
    constructor() {
        this.industrycode = Selector("#wc7IndustryCode");
        this.industrycodeOption = Selector("[id='wc7IndustryCode'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.organisationType = Selector("#wc7OrgType");
        this.organisationTypeOption = Selector("[id='wc7OrgType'] div[class*='TypeaheadMultiSelectField__menu'] div");
    }

    async selectIndustryCode(option){
        await helper.selectDropdown(this.industrycode,this.industrycodeOption,option);
    }
    async selectOrganisationType(option){
        await helper.selectDropdown(this.organisationType,this.organisationTypeOption,option);
    }

    async setWC7PolicyDetailsPage(data){
        await this.selectIndustryCode(data.IndustryCode);
        await this.selectOrganisationType(data.OrganisationType);
        await common.goNext();

    }

}
