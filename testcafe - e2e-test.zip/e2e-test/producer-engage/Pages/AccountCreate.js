import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper'
import Assertions from '../../Utilities/Assertions'

const helper = new Helper();
const assert = new Assertions();

export default class AccountCreate {
    constructor() {
        this.addressLine1 = Selector("#addressLine1");  
        this.addressLine1Error = Selector("[id*='addressLine1'] div");  
        this.city = Selector("input[id='city']");  
        this.cityError = Selector("[id*='city'] div");  
        this.zipCode = Selector("[id='postalCode']");  
        this.zipCodeError = Selector("[id*='postalCode'] div");  
        this.state_Select=Selector("[id='state']");  
        this.state_Option=Selector("[id='state'] div[class*='TypeaheadMultiSelectField__menu'] div")  
        this.stateError = Selector("[id='state']").nextSibling("div");  
        this.emailAddress = Selector("input[id='email']");  
        this.emailAddressError = Selector("[id*='email'] div");
        this.producerCode_Select=Selector("[id='producerCode']");  
        this.producerCode_Option=Selector("[id='producerCode'] div[class*='TypeaheadMultiSelectField__menu'] div")  
        this.producerCodeError = Selector("[id='producerCode']").nextSibling("div");  
        this.nextButton=Selector("button[id='next']").nth(0);  
        this.cancelButton = Selector("[id='cancel']").nth(0);  
        this.newSub_State_Select = Selector("select[gw-pl-select*='newSubmissionView.state.value']");
        this.newSub_ProducerCode_Select = Selector("select[id='ProducerCode']");
        this.productCode_select = Selector("select[id='ProductCode']");
        this.submitButton=Selector("[id='next']");
    }

    async typeAddressLine1(addressLine1) {
        await helper.typeText(this.addressLine1, addressLine1);
    }
    async typeCity(city) {
        await helper.typeText(this.city, city);
    }
    async typeZipCode(zipcode) {
        await helper.typeText(this.zipCode, zipcode);
    }
    async selectState(option) {
        await helper.selectDropdown(this.state_Select,this.state_Option, option);
    }
    async clickSubmit() {
        await helper.click(this.submitButton);
    }
    async typeEmailAddress(email) {
        await helper.typeText(this.emailAddress, email.Email);
    }
    async selectProducerCode(option) {
        await helper.selectDropdown(this.producerCode_Select, this.producerCode_Option, option);
    }
    async clickNext() {
        await helper.click(this.nextButton);
    }
    async clickCancel() {
        await helper.click(this.cancelButton);
    }
    async accountCreationMandatoryErrorTextMessage(text) {
        await assert.assertEqual(this.addressLine1Error.innerText, text, 'Mandatory error message for address Line1 Does Not Match');
        await assert.assertEqual(this.cityError.innerText, text, 'Mandatory error message for city Does Not Match');
        await assert.assertEqual(this.zipCodeError.innerText, text, 'Mandatory error message for zip code Does Not Match');
        await assert.assertEqual(this.stateError.innerText, text, 'Mandatory error message for state Does Not Match');
        await assert.assertEqual(this.producerCodeError.innerText, text, 'Mandatory error message for producer code Does Not Match');
    }
    async accountCreationMandatoryErrorPresent() {
        await assert.elementPresent(this.addressLine1Error, 'Mandatory error message for address Line1 is not Present');
        await assert.elementPresent(this.cityError, 'Mandatory error message for city is not Present');
        await assert.elementPresent(this.zipCodeError, 'Mandatory error message for zip code is not Present');
        await assert.elementPresent(this.stateError, 'Mandatory error message for state is not Present');
        await assert.elementPresent(this.producerCodeError, 'Mandatory error message for producer code is not Present');
    }
    async isZipCodeErrorDisplayed(text) {
        await assert.elementPresent(this.zipCodeError, 'Zip code error message Not Present');
        await assert.assertEqual(await helper.getTextAtLocator(this.zipCodeError), text.ErrorMessage, 'Zip Code Error Message Does Not Match');
    }
    async isEmailAddressFieldMarkedWithError(text) {
        await assert.elementPresent(this.emailAddressError, 'Email Address error message Not Present');
        await assert.assertEqual(await helper.getTextAtLocator(this.emailAddressError), text.ErrorMessage, 'Email Address Error Message Does Not Match');
    }
    async fillAccountCreate(data) {
        this.typeAddressLine1(data.AddressLine1);
        this.typeCity(data.City);
        this.typeZipCode(data.Zip);
        this.selectState(data.State);
        await t.wait(3000);
        this.selectProducerCode(data.ProducerCode);
        await t.wait(3000);
    }
    async fillEmailAddress(data) {
        await helper.typeText(this.emailAddress, data.Email);
    }
}