import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import PolicyInfoPage from './PolicyInfoPage';
import CommonLocators from '../../Utilities/CommonLocators';
import PaymentDetailsPage from './PaymentDetailsPage';
import AlertHandler from './AlertHandler';



const helper = new Helper();
const assert = new Assertion();
const alert = new AlertHandler();
const policyInfo = new PolicyInfoPage();
const PAdata = require('../../producer-engage/Data/PE_PA_Data.json');
const common = new CommonLocators();
const paymentDetails = new PaymentDetailsPage();
const uwMsgTitleText = "Underwriting issues have been raised for the following quotes:";
const uwMsgLine2Txt = "You can do the following:";
const uwMsgListLineText1 = "Edit the quote if the customer is willing to accept the change";
const uwMsgListLineText2 = "Approve the issue(s)";
const uwMsgListLineText3 = "Refer the quote to the underwriter";
const uwMsgListLineText4 = "Withdraw the quote";

export default class PAQuotePage {
    constructor() {
        this.buyBasicPolicy = Selector("[id='buyNowButton_[0]']");
        this.submissionNumber = Selector("[class*='WizardPageHeader_gwWizardPageTitle'] div").nth(1);
        this.uwIssueTitle = Selector("#gwAlertHeading");
        this.uwIssuePolicyDecline = Selector("td[class*='ProducerUnderwritingIssues']").nth(1);
        this.uwMsgText = Selector("#alertInfo");
        this.uwMsgListLine1 = Selector("#editText");
        this.uwMsgListLine2 = Selector("#approveText");
        this.uwMsgListLine3 = Selector("#referText");
        this.uwMsgListLine4 = Selector("#withdrawText");
        this.withdrawBtn = Selector("#withdrawButton");
        this.referUWBtn = Selector("#underwriterButton");
        this.referUWBtnConfirm = Selector("#referToUnderwriter");
        this.cancelReferUWBtn = Selector("#cancelButton");
        this.uwIssue = Selector("td[class*='ProducerUnderwritingIssues']");
        this.accountSummaryLink = Selector("a[href*='/accounts/']");
    }

    async clickBuyNow() {
        await helper.click(this.buyBasicPolicy);
    }
    async getSubmissionNumber() {
        var submission = await helper.getTextAtLocator(this.submissionNumber);
        var quoteNumber = submission.replace(/\D+/g, "");
        return quoteNumber;

    }

    async buyBasePolicyWithMonthlyPayment() {
        await helper.click(this.buyBasicPolicy);
    }
    async uwIssueValidation(value, value1) {
        await assert.assertEqual(await helper.getTextAtLocator(this.uwIssueTitle), value, "The Underwriting Issue does not exist");
        await assert.textContains(await helper.getTextAtLocator(this.uwIssue), value1, "The Underwriting Issue does not match");
        await assert.elementPresent(this.withdrawBtn, 'Withdraw Button does not exist');
        await assert.elementPresent(this.referUWBtn, "Refer to underwriter button does not exist");
    }
    async uwIssueValidationForPolicyDecline(value, value1) {
        await assert.assertEqual(await helper.getTextAtLocator(this.uwIssueTitle), value, "The Underwriting Issue does not exist");
        await assert.textContains(await helper.getTextAtLocator(this.uwIssuePolicyDecline), value1, "The Underwriting Issue does not match");
        await assert.elementPresent(this.withdrawBtn, 'Withdraw Button does not exist');
        await assert.elementPresent(this.referUWBtn, "Refer to underwriter button does not exist");
    }

    async buyQuotedPolicy() {
        await this.buyBasePolicyWithMonthlyPayment();
        await common.goNext();
        await policyInfo.setEmailAddress(PAdata.Email);
        await policyInfo.setPhoneNumber(PAdata.PhoneNumber);
        await common.goNext();
        await t.wait(2000);
        await common.goNext();
        await paymentDetails.payMonthlyPremiumWithSavingsBankAccount();
        await common.goNext();
    }
    async clickReferToUnderwriterAndConfirm() {
        await helper.click(this.referUWBtn);
        await helper.click(this.referUWBtnConfirm);
    }
    async validationUnderwritingMessage(){
        await assert.assertEqual(await helper.getTextAtLocator(this.uwIssueTitle),uwMsgTitleText,'Underwriting message is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.uwMsgText),uwMsgLine2Txt,'Underwriting message is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.uwMsgListLine1),uwMsgListLineText1,'Underwriting message line 1 is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.uwMsgListLine2),uwMsgListLineText2,'Underwriting message line 2 is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.uwMsgListLine3),uwMsgListLineText3,'Underwriting message line 3 is incorrect');
        await assert.assertEqual(await helper.getTextAtLocator(this.uwMsgListLine4),uwMsgListLineText4,'Underwriting message line 4 is incorrect');
        await assert.elementPresent(this.withdrawBtn,'Withdraw Button is not found');
        await assert.elementPresent(this.referUWBtn,'Refer to Underwriter button is not presented');
    }
    async clickReferToUnderwriterAndCancel() {
        await helper.click(this.referUWBtn);
        await helper.click(this.cancelReferUWBtn);
    }
    async clickWithdraw(){
        await helper.click(this.withdrawBtn);
    }

    async goToAccountPage(){
        await helper.click(this.accountSummaryLink);
    }
}
