import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";
import CommonLocators from "../../Utilities/CommonLocators";

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();

export default class NewClaimClaimSummary {
    constructor() {
        this.claimDraftNumber = Selector("[class*='gwClaimsWizardSpanNumber']");
        this.contactValue = Selector("div[id='fnolContactPerson']");
        this.policyNumberValue = Selector("div[id='fnolPolicyNumber']");
        this.whatHappenedValue = Selector("div[id='fnolTypeOfIncident']");
        this.whenValue = Selector("div[id='fnolWhen']");
        this.whereValue = Selector("div[id='fnolWhere']"); 
    }
    async getBasicClaimSummaryDetails() {
        var claimDetails = [];
        claimDetails.push(await helper.getTextAtLocator(this.policyNumberValue));
        claimDetails.push(await helper.getTextAtLocator(this.whatHappenedValue));
        claimDetails.push(await helper.getTextAtLocator(this.whenValue));
        claimDetails.push(await helper.getTextAtLocator(this.whereValue));
        claimDetails.push((await this.getContactValue()).split(",", 1));
        return claimDetails;
    }

    async getContactValue() {
        var contactValue = await helper.getTextAtLocator(this.contactValue);
        return contactValue;
    }
    async getDraftClaimNumber() {
        var draftNumber = await helper.getTextAtLocator(this.claimDraftNumber);
        return draftNumber;
    }
    async validateClaimSummaryPageData(summaryData) {
        if (JSON.stringify(summaryData) === JSON.stringify(await this.getBasicClaimSummaryDetails())) {
            return true;
        }
        else {
            return false;
        }

    }
    async clickSubmitClaim() {
       await common.goNext();
    }

}
