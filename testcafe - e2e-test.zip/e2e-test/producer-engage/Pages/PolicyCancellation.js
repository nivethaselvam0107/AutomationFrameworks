
import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import moment from 'moment';
const data = require('../Data/PE_PA_Data.json');
const helper = new Helper();
const assert = new Assertion();
var jobNumber;
var titleTemplate = "Cancellation (" + jobNumber + ")";
var openActivitiesTile = "a[href*='/cancellation/"+jobNumber+"/activities']";
var notesTile = "a[href*='/cancellation/"+jobNumber+"/notes']";
var documentsTile = "a[href*='/cancellation/"+jobNumber+"/documents']";
export default class PolicyCancellationPage {
    constructor() {
        this.cancelButton = Selector("[id='cancelPolicyButtonId']");
        this.reasonForCancel = Selector("[id='reasonId']");
        this.reasonForCancelOption = Selector("[id='reasonId'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.refundMethod = Selector("[id='refundMethodId']");
        this.refundMethodOption = Selector("[id='refundMethodId'] div[class*='TypeaheadMultiSelectField__menu'] div")
        this.selectDate = Selector("[id='effectiveDateId']");
        this.startCancel = Selector("[id='startCancel']");
        this.bindCancel = Selector("#continueQuote");
        this.confirmBind = Selector("[class*='modalFooter'] button[class*='primary']");
        this.donNotBind = Selector("button[class*='tertiary']")
        this.withdrawCancel = Selector("#withdrawQuote");
        this.confirmWithdrawCancel = Selector("[class*='modalFooter'] button[class*='primary']");
        this.doNotWithDraw = Selector("button[class*='tertiary']");
        this.cancelStatus = Selector("[id='pageTitleContainer'] [class*='gwPageTitle']");
        this.policyLink = Selector("[id='pageTitleContainer']").find("[href*='/policies']");
        this.policyStatusHeader = Selector("#infoStatus");
        this.renewPolicyButton = Selector("[on-click='createPolicyRenewalTransaction()']");
        this.effectiveDateErrorMessage = Selector('#errorMessageEffectiveDate');
        this.reasonValue = Selector('#reasonId');
        this.refundMethodValue = Selector('#refundMethodId');
        this.policyNumberLink = Selector("[ui-sref='policies.detail.summary({policyNumber: latestPeriod.policyNumber})']")
        this.cancellationMessageHeader = Selector("[class*='SuccessNotification_gwAlertContentHeading']");
        this.cancellationMessageBody = Selector("[class*='SuccessNotification_gwAlertContentSubHeading']");
    }
    async clickCancelPolicy() {
        await helper.click(this.cancelButton);
    }

    async selectReasonForCancellation(option) {
        await helper.selectDropdown(this.reasonForCancel,this.reasonForCancelOption, option)
    }
    async selectRefundMethod(option) {

        await helper.selectDropdown(this.refundMethod,this.refundMethodOption, option)
    }
    async selectEffectiveDate() {
        await helper.click(this.selectDate);
    }
    async setDateWithinPolicyPeriod(policy) {
        var policyeff = policy.policyEffectiveDate;
        var date = moment(policyeff).format('L');
        var effectiveDate = moment(date, 'mm/dd/yy').add(2, 'd').format('L');
        await helper.typeText(this.selectDate, effectiveDate);
    }

    async startCancellation() {
        await helper.click(this.startCancel)
    }
    async bindCancellation() {
        await helper.click(this.bindCancel)
    }
    async bindConfirmCancellation() {
        await helper.click(this.confirmBind)
    }
    async withdrawCancellation() {
        await helper.click(this.withdrawCancel);
    }
    async doNotWithdrawnCancellation() {
        await helper.click(this.doNotWithDraw);
    }
    async confirmWithdrawcancellation() {
        await helper.click(this.confirmWithdrawCancel);
    }

    async cancellationStatus() {
        var str = await this.cancelStatus.innerText;
        str =str.replace(/[^a-zA-Z ]/g, '').trim();
        return str;

    }
    async getJobNumber() {
        var number = await this.cancelStatus.innerText;
        number = number.replace(/\D/g, '').trim();
        return number;
    }
    async clickPolicyLink() {
        await helper.click(this.policyLink)
    }

    async validateCanceledPolicyStatus() {
        assert.assertEqual(this.policyStatusHeader.innerText, 'Canceled');
    }

    async renewPolicyButtonPresent() {
        assert.elementPresent(this.renewPolicyButton, 'renew policy button not available');
    }
    async startCancelButtonDisabled() {
        await assert.isElementNotClickable(this.startCancel, 'disabled', 'button not disabled');
    }
    async goToPolicySummaryPage() {
        await helper.click(this.policyNumberLink)
    }
    async setDateNotWithinPolicyPeriod(policy) {
        var effectiveDate = await helper.futureDatePolicy(policy.policyExpirationDate);
        await helper.typeText(this.selectDate, effectiveDate);
        await helper.pressTab();

    }
    async validateEffectiveDateErrorMessage(){
        await assert.assertEqual(await helper.getTextAtLocator(this.effectiveDateErrorMessage),'Please set a date that is before the expiry date of the policy','Effective Date error message is incorrect');
    }
    async doNotBindCancellationOnPolicy() {
        await helper.click(this.donNotBind);
    }
    async clickOpenActivitiesTile(jobNum){
        await helper.click(Selector(openActivitiesTile.replace(jobNumber,jobNum)));
    }
    async clickNotesTile(jobNum){
        await helper.click(Selector(notesTile.replace(jobNumber,jobNum)));
    }
    async clickDocumentsTile(jobNum){
        await helper.click(Selector(documentsTile.replace(jobNumber,jobNum)));
    }

    
    async validateQuotedCancellationPageComponents(jobNum,policydata) {
        await assert.assertEqual(this.cancelStatus.innerText, titleTemplate.replace(jobNumber, jobNum))
        await assert.assertEqual(this.policyStatusHeader.innerText, 'Quoted', 'status of cancellation is incorrect')
        await assert.assertEqual(this.cancellationMessageHeader.innerText, data.PolicyCancellation.QUOTED_CANCELLATION_MESSAGE_HEADER,'Quoted Cancellation Header is incorrect');
        await assert.assertEqual(this.cancellationMessageBody.innerText, data.PolicyCancellation.QUOTED_CANCELLATION_MESSAGE_BODY,'Quoted Cancellation Message is incorrect');
        await assert.isElementClickable(this.withdrawCancel, 'disabled', 'Withdraw cancellation button is missing');
        await assert.isElementClickable(this.bindCancel, 'disabled', 'Bind cancellation button is missing');
        await assert.assertEqual(this.reasonValue.innerText,policydata.Reason3,'Reason For Cancellation data is incorrect');
        await assert.assertEqual(this.refundMethodValue.innerText,policydata.RefundMethod,'Refund Method data is incorrect')
    }
    async validateBoundCancellationPageComponents(jobNum,policydata) {
        await assert.assertEqual(this.cancelStatus.innerText, titleTemplate.replace(jobNumber, jobNum))
        await assert.assertEqual(this.policyStatusHeader.innerText, 'Bound', 'status of cancellation is incorrect')
        await assert.assertEqual(this.cancellationMessageHeader.innerText,data.PolicyCancellation.BOUND_CANCELLATION_MESSAGE_HEADER,'Bound Cancellation Header is incorrect');
        await assert.assertEqual(this.cancellationMessageBody.innerText,data.PolicyCancellation.BOUND_CANCELLATION_MESSAGE_BODY,'Bound Cancellation Message is incorrect');
        await assert.elementNotPresent(this.withdrawCancel,'Withdraw button is displayed');
        await assert.elementNotPresent(this.bindCancel,'Withdraw button is displayed');
        await assert.assertEqual(this.reasonValue.innerText,policydata.Reason3,'Reason For Cancellation data is incorrect');
        await assert.assertEqual(this.refundMethodValue.innerText,policydata.RefundMethod,'Refund Method data is incorrect')
    }


}

