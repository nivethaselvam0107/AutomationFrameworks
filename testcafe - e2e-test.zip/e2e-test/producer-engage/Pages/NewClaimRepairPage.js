import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";
import CommonLocators from "../../Utilities/CommonLocators";

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
export default class NewClaimRepairPage {
    constructor() {
        this.repairRecommendedFacilityRadioButton= Selector("[data-value='PreferredVendor']");
        this.noRepairRadioButton = Selector("[data-value='NoRepair']");
        this.nextButton = Selector("button[id='gw-wizard-Next']");
        this.vendorNameFromList = Selector("li[role='presentation']");
        this.vendorAddressFromList = Selector("gw-fnol-pa-repair-facilities-list-item[model='item'] p");
        
    }
    async selectNoFacility(){
        await helper.click(this.noRepairRadioButton);
    }
    async selectRecommendedFacility(){
        await helper.click(this.repairRecommendedFacilityRadioButton);
        await common.goNext();
    }
    async selectVendor(){
        await this.selectFirstAvailableVendor();
    }
    async selectFirstAvailableVendor(){
        await helper.click(this.vendorNameFromList.nth(0));
    }
}