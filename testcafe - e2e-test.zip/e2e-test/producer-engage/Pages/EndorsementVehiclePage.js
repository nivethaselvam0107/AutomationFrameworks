import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import { throwStatement } from '@babel/types';
import DataFetch from '../Data/DataFetch';
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();

export default class EndorsementVehiclePage {
    constructor() {
        this.addVehicleAfterDetails = Selector("");
        this.removeVehicleButton = Selector("[id='paVehicleSectionTrashId_[1]']");
        this.addvehicleButton = Selector("button[id='addVehicle']");
        this.deleteBtn = Selector("[id*='paVehicleSectionTrash']");
        this.editBtn = Selector("[id*='paVehicleSectionEditId']");
        this.make = Selector("#vehicleMake");
        this.makeError = Selector("[id*='vehicleMake'][role='alert']");
        this.model = Selector("#vehicleModel");
        this.modelError = Selector("[id*='vehicleModel'][role='alert']");
        this.vin = Selector("#vehicleVin");
        this.year = Selector("#vehicleYear");
        this.licensePlate = Selector("#vehicleLicencePlate");
        this.yearOption = Selector("[id='vehicleYear'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.addCityInput = Selector(" ");
        this.state = Selector("#driverLicenceState");
        this.stateOption = Selector("[id='driverLicenceState'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.costNew = Selector("#vehicleCostNew");
        this.costNewError = Selector("[id*='vehicleCostNew'][role='alert']");
        this.assignedDriver = Selector("[id*='driverAssignment'] [class*='digitalCheckbox CheckboxField-module']")
    }
    async isAddNotEnabledForNewVehicle() {
        await assert.isElementClickable(this.addVehicleAfterDetails, "disabled", "The Button is enabled");
    }
    async addVehicle() {
        await helper.click(this.addvehicleButton);
    }
    async isRemoveButtonDisabled() {
        await assert.isElementNotClickable(this.deleteBtn,'disabled','Primary Vehicle can be removed');
    }
    async clickOnFirstEdit(){
        await helper.click(this.editBtn.nth(0));
    }
    async withLicensePlate(license){
        await helper.typeText(this.licensePlate,license);
    }
    async withCostNew(cost){
        await helper.typeText(this.costNew,cost);
    }
    async withVin(vin){
        await helper.typeText(this.vin,vin);
    }
    async withMake(make){
        await helper.typeText(this.make,make);
    }
    async withModel(model){
        await helper.typeText(this.model,model);
    }
    async withState(state){
        await helper.selectDropdown(this.state,this.stateOption,state);
    }
    async withYear(year){
        await helper.selectDropdown(this.year,this.yearOption,year);
    }
    async selectAssignedDriver(){
        await helper.click(this.assignedDriver);
    }
    async editVehicleData(data){
        await this.withLicensePlate(data.LicensePlate);
        await this.withCostNew(data.VehicleCost);

    }

    async editFirstVehicleDetails(data){
        await this.clickOnFirstEdit();
        await this.editVehicleData(data);
    }

    async getEditVehicleUIdetails(){
        let data = new Map();
        data.set("Make",await helper.getValueAttributeFromLocator(this.make));
        data.set("VIN", await helper.getValueAttributeFromLocator(this.vin));
        data.set("Model",await helper.getValueAttributeFromLocator(this.model));
        data.set("VehicleYear", await helper.getTextAtLocator(this.year));
        return data;

    }
    

    async isEditedVehicleAvailableInPolicyFromBackEnd(dataUI,data,policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        var count = content.lobData.personalAuto.coverables.vehicles.length;
        var covFlag = false;
        for (var i=0; i<count; i++){
            if((content.lobData.personalAuto.coverables.vehicles[i].vin == dataUI.get("VIN")) || (content.lobData.personalAuto.coverables.vehicles[i].fixedId == dataUI.get("VIN") )){
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].license,data.LicensePlate,'License no is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].licenseState,data.StateValue,'State license value is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.vehicles[i].year).toString(),(dataUI.get("VehicleYear")).toString(),'Vehicle year is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].model,dataUI.get("Model"),'Vehicle model is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].vin,dataUI.get("VIN"),'Vehicle vin is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].make,dataUI.get("Make"),'Vehicle make is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.vehicles[i].costNew.amount).toString(),(data.VehicleCost).toString(),'Vehicle cost is not matched');
                covFlag = true;

            }
        }
        return covFlag;
    }

    async setVehiclesPage(data){
        await this.withVin(data.VIN);
        await this.withLicensePlate(data.LicensePlate);
        await this.withMake(data.Make);
        await this.withModel(data.Model);
        await this.withCostNew(data.VehicleCost);
        await this.withState(data.VehicleState);
        await this.withYear(data.VehicleYear);
        await this.selectAssignedDriver();
    }
    async validateMandatoryErrorMessageInVehiclePage(){
        await helper.removeRequiredTextAndValidate(this.make,this.makeError);
        await helper.removeRequiredTextAndValidate(this.model,this.modelError);
        await helper.removeRequiredTextAndValidate(this.costNew,this.costNewError);
    }

    async isAddedVehiclePresent(title){
        await assert.assertEqual(await helper.getTextAtLocator(this.addedVehicleTitle),title,'Added Vehicle is not displayed');
    }
    async clickRemoveVehicle(){
        await helper.click(this.removeVehicleButton);
    }
    async isAddedVehicleAvailableInPolicyFromBackEnd(data,policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        var vehicle = content.lobData.personalAuto.coverables.vehicles;
        var count = content.lobData.personalAuto.coverables.vehicles.length;
        console.log(count);
        var covFlag = false;
        for (var i=0; i<count; i++){
            console.log(content.lobData.personalAuto.coverables.vehicles[i].vin);
            console.log(data.VIN);
            if((content.lobData.personalAuto.coverables.vehicles[i].vin == data.VIN || (content.lobData.personalAuto.coverables.vehicles[i].fixedId == data.VIN))){
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].license,data.LicensePlate,'License no is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.vehicles[i].year).toString(),(data.VehicleYear).toString(),'Vehicle year is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].model,data.Model,'Vehicle model is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].vin,data.VIN,'Vehicle vin is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.vehicles[i].make,data.Make,'Vehicle make is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.vehicles[i].costNew.amount).toString(),(data.VehicleCost).toString(),'Vehicle cost is not matched');
                covFlag = true;

            }
        }
        return covFlag;
    }

    

    
    





}