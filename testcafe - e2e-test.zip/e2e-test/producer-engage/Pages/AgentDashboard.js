import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper'
import Assertion from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertion();
var jobNumber;
var accNum;
const jobNumberLink = "a[href*='/endorsements/" + jobNumber + "/summary']";
const accountNumberLink = "a[href*='/accounts/" + accNum + "/summary']";

export default class AgentDashboard {
    constructor() {
        this.activity_note= Selector("div[class*='rt-tbody DataTable'] [class*='fas fa-sticky-note']");
        this.expand_activity_button = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-expand-activity]");
        this.activities_for_next_7_days = Selector("div[class*='rt-table'] [class*='tbody']").nth(0); 
        this.activity_priority = Selector("div[class*='rt-table'] [class*='InfoLabel-module']"); 
        this.activity_duedate = Selector("div[class*='rt-table'] [class*='tableCell'] div").nth(0); 
        this.activity_subject = Selector("div[class*='rt-table'] [class*='tableCell'] div").nth(1); 
        this.activity_assignedTo = Selector("div[class*='rt-table'] [class*='tableCell'] span[title]"); 
        this.activity_status = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-status]");
        this.activity_details = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-details]");
        this.openQuotestile = Selector("[id='landingPageTileContainer'] [class*='TilesLarge']").nth(0);
        this.openPolicyChangetile = Selector("[id='landingPageTileContainer'] [class*='TilesLarge']").nth(1);
        this.openCancelationtile = Selector("[id='landingPageTileContainer'] [class*='TilesLarge']").nth(2);
        this.openRenewalstile = Selector("[id='landingPageTileContainer'] [class*='TilesLarge']").nth(3);
        this.searchInputBox= Selector("input[id='headerSearchBox']"); 
        this.searchButton = Selector("i[class*='fa-search']"); 
        this.policyLink = Selector("[id*='policyNumber'][class*='SearchResults_policyNumber']");   
        this.accountNameLink = Selector("a[class*='policyAccountNameLink'] div");   
        this.accountNumber = Selector("[class*='gw-titles-title']");
        this.accountNumberLink = Selector("div[id*='accountNumber']");
        this.openRenewalTitle = Selector("[class='gwSubtitle']");
        this.openQuotesTitle = Selector("[class='gwSubtitle']");
        this.openPolicychangesTitle = Selector("[class='gwSubtitle']");
        this.openCancellationTitle = Selector("[class='gwSubtitle']");

    }
    

    async expandFirstActivity() {
        await helper.click(this.expand_activity_button.nth(1));
    }

    async verifyActivitiesForNext7daySections() {
        await t.wait(1000);
        await assert.elementPresent(this.activities_for_next_7_days, 'Activities for next 7 days are not Present');
        await assert.elementPresent(this.activity_priority, 'Priority is not Present');
        await assert.elementPresent(this.activity_duedate, 'Due Date is not Present');
        await assert.elementPresent(this.activity_note, 'Notes are not Present');
        await assert.elementPresent(this.activity_subject, 'Subject is not Present');

    }

    async clickOpenQuotesTile() {
        await helper.click(this.openQuotestile);
        await t.wait(3000);
    }
    async clickOpenPolicyChangesTile() {
        await helper.click(this.openPolicyChangetile);
        await t.wait(3000);
    }
    
    async clickOpenCancellationsTile() {
        await helper.click(this.openCancelationtile);
        await t.wait(3000);
    }
    async  clickOpenRenewalsTile() {
        await helper.click(this.openRenewalstile);
        await t.wait(3000);
    }

    async searchUsingSearchBox(accountOrPolicyNum){
        await helper.typeText(this.searchInputBox,accountOrPolicyNum);
        await helper.pressEnter();
        await t.wait(3000);
    }
    async goToAccountFromPolicySearch(){
        await helper.click(this.accountNameLink);//selector to be changed
        await t.wait(3000);
    }
    async goToAccountFromAccountSearch(){
        await helper.click(this.accountNumberLink);
        await t.wait(3000);
    }
    async goToPolicyFromPolicySearch(){
        await helper.click(this.policyLink);
        await t.wait(3000);
    }
    async clickJobLink(jobNum){
        var jobLink = jobNumberLink.replace(jobNumber, jobNum)
        await helper.click(Selector(jobLink));
    }
    async clickAccountLink(accNumber){
        var accLink = accountNumberLink.replace(accNum, accNumber)
        await helper.click(Selector(accLink));
    }
    async verifyOpenRenewalLoaded(){
        await assert.assertEqual(await helper.getTextAtLocator(this.openRenewalTitle),'Open Renewals for past 30 days','Open renewals Page is not loaded');
    }
    async verifyOpenQuotesLoaded(){
        await assert.assertEqual(await helper.getTextAtLocator(this.openQuotesTitle),'Open Quotes for past 30 days','Open quotes Page is not loaded');
    }
    async verifyOpenPolicyChangesLoaded(){
        await assert.assertEqual(await helper.getTextAtLocator(this.openPolicychangesTitle),'Open Changes for past 30 days','Open changes Page is not loaded');
    }

    async verifyOpenCancellationLoaded(){
        await assert.assertEqual(await helper.getTextAtLocator(this.openCancellationTitle),'Open Cancellations for past 30 days','Open cancellations Page is not loaded');
    }


}
