import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";
import CommonLocators from "../../Utilities/CommonLocators";

const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();

var driverOption = "div[id*='paVehiclesWhoDriving'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div"; 
var vehicleOption = "div[id*='paVehiclesWhichDamaged'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div"; 
export default class NewClaimVehiclePage {
    constructor() {
        this.addPassengerButton = Selector("[id*='paPassengersAddPassenger'] button");
        this.newPassengerOption = Selector("[id*='contactItemOtherPerson']");
        this.passengerFirstName = Selector("input[id*='firstName']");
        this.passengerLastName = Selector("input[id*='lastName']");
        this.roof = Selector("[id='roof']"); 
        this.frontBumper = Selector("[id='frontBumper']"); 
        this.rearBumper = Selector("[id='rearBumper']"); 
        this.rearLeftSide = Selector("[id='rearLeftSide']"); 
        this.rearRightSide = Selector("[id='rearRightSide']"); 
        this.frontLeftSide = Selector("[id='frontLeftSide']"); 
        this.frontRightSide = Selector("[id='frontRightSide']"); 
        this.frontLeftCorner = Selector("[id='frontLeftCorner']"); 
        this.frontRightCorner = Selector("[id='frontRightCorner']"); 
        this.frontLeftDoor = Selector("[id='frontLeftDoor']"); 
        this.frontRightDoor = Selector("[id='frontRightDoor']"); 
        this.rearLeftDoor = Selector("[id='rearLeftDoor']"); 
        this.rearRightDoor = Selector("[id='rearRightDoor']"); 
        this.hood = Selector("[id='hood']"); 
        this.driverSelect = Selector("[id*='paVehiclesWhoDriving'][class*='TypeaheadMultiSelectField']");
        this.select_Driver=Selector("[id*='paVehiclesWhoDriving'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div")
        this.vehicleSelect = Selector("div[id*='paVehiclesWhichDamaged'][class*='TypeaheadMultiSelectField']");
        this.select_Vehicle=Selector("div[id*='paVehiclesWhichDamaged'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div")
        this.nextButton = Selector("button[id='gw-wizard-Next']");
        this.vehicleSafeTodriveYes = Selector("[id*='paVehicleVehicleSafe'] button[data-value='true']"); 
        this.vehicleSafeTodriveNo = Selector("[id*='paVehicleVehicleSafe'] button[data-value='false']"); 
        this.airBagDeployedYes = Selector("[id*='paVehicleDidAirbagDeploy'] button[data-value='true']"); 
        this.airBagDeployedNo = Selector("[id*='paVehicleDidAirbagDeploy'] button[data-value='false']"); 
        this.equipmentFailureYes = Selector("[id*='paVehicleEquipmentFailure'] button[data-value='true']"); 
        this.equipmentFailureNo = Selector("[id*='paVehicleEquipmentFailure'] button[data-value='false']"); 
        this.vehicleTowedYes = Selector("[id*='paVehicleWasVehicleTowed'] button[data-value='true']"); 
        this.vehicleTowedNo = Selector("[id*='paVehicleWasVehicleTowed'] button[data-value='false']"); 
        this.rentalCarNeededYes = Selector("[id*='paVehicleWasRentalNeeded'] button[data-value='true']"); 
        this.rentalCarNeededNo = Selector("[id*='paVehicleWasRentalNeeded'] button[data-value='false']"); 
        this.newvehicleMake = Selector("input[id*='paVehicleOtherVehicleMake']");
        this.newvehicleModel = Selector("input[id*='paVehicleOtherVehicleModel']");
        this.newVehicleColor = Selector("input[id*='paVehicleOtherVehicleColor']");
        this.newVehicleLicense = Selector("input[id*='paVehicleOtherVehiclePlate']");
        this.newVehicleState = Selector("div[id*='paVehicleOtherVehicleState'][class*='TypeaheadMultiSelectField']");
        this.newVehicleStateOption=Selector("div[id*='paVehicleOtherVehicleState'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div ")
        this.newVehicleVIN = Selector("input[id*='paVehicleOtherVehicleVIN']");
        this.newVehicleYear = Selector("div[id*='paVehicleOtherVehicleYear'][class*='TypeaheadMultiSelectField']");
        this.newVehicleYearOption = Selector("div[id*='paVehicleOtherVehicleYear'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div ");
        this.newDriverFirstName = Selector("input[id*='paVehicleOtherDriverFirstName']");
        this.newDriverLastName = Selector("input[id*='paVehicleOtherDriverLastName']");
        this.newDriverContactNum = Selector("input[id*='paVehicleOtherDriverHomePhone']");
        this.newDriverCellNum = Selector("input[id*='paVehicleOtherDriverMobilePhone']");
        this.addAnotherVehicleButton = Selector("button[id='paAddVehicleButton']");
        this.anotherVehicleAccordion = Selector("div[id*='paVehicleAccordionDetails'][role='button']");
    }
    async isVehicleDriverPageLoaded(){
        await assert.elementPresent(this.vehicleSelect,'Vehicle driver page is not loaded');
    }
    async selectOtherVehicle(){
        await helper.selectDropdown(this.vehicleSelect,this.select_Vehicle,'Other Vehicle');
    }
    async selectOtherDriver(){
        await helper.selectDropdown(this.driverSelect,this.select_Driver,'Other Driver');
    }
    async addAdditionalVehicle(){
        await helper.click(this.addAnotherVehicleButton);
        await helper.click(this.anotherVehicleAccordion.nth(1));

    }
    async selectVehicleOnAdditionalVehiclePage(){
        await helper.selectDropdown(this.vehicleSelect.nth(1),this.select_Vehicle,'Other Vehicle');
    }
    async selectFirstAvailableDriver() {
        var optionToBeSelected=[];
        await helper.click(this.driverSelect);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("div[id*='paVehiclesWhoDriving'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var dropDownoptions = await dropDownValues();
        for (var option of dropDownoptions)
            if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
                optionToBeSelected.push(option);    
            }
            await helper.click(Selector(driverOption).withExactText(optionToBeSelected[0]));
    }

    async selectFirstAvailableVehicle() {
        var optionToBeSelected=[];
        await helper.click(this.vehicleSelect);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("div[id*='paVehiclesWhichDamaged'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];

            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var dropDownoptions = await dropDownValues();
        for (var option of dropDownoptions)
            if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
                optionToBeSelected.push(option);        
            }
            await helper.click(Selector(vehicleOption).withExactText(optionToBeSelected[0]));
         
    }

    async setVehicleSafetyToDrive(data) {
        if (data == 'Yes')
            await helper.click(this.vehicleSafeTodriveYes);
        else
            await helper.click(this.vehicleSafeTodriveNo);
    }
    async setAirBagDeployStatus(data) {
        if (data == 'Yes')
            await helper.click(this.airBagDeployedYes);
        else
            await helper.click(this.airBagDeployedNo);
    }
    async setEquiFailureStatus(data) {
        if (data == 'Yes')
            await helper.click(this.equipmentFailureYes);
        else
            await helper.click(this.equipmentFailureNo);
    }
    async setVehicleTowStatus(data) {
        if (data == 'Yes')
            await helper.click(this.vehicleTowedYes);
        else
            await helper.click(this.vehicleTowedNo);
    }
    async setVehicleRentalStatus(data) {
        if (data == 'Yes')
            await helper.click(this.rentalCarNeededYes);
        else
            await helper.click(this.rentalCarNeededNo);
    }
    async setVehicleCollisionPoint(part) {
               switch (part) {
            case 'roof':
                await helper.click(this.roof);
                break;
            case 'frontBumper':
                await helper.click(this.frontBumper);
                break;
            case 'rearBumper':
                await helper.click(this.rearBumper);
                break;
            case 'rearLeftSide':
                await helper.click(this.rearLeftSide);
                break;
            case 'rearRightSide':
                await helper.click(this.rearRightSide);
                break;
            case 'frontLeftSide':
                await helper.click(this.frontLeftSide);
                break;
            case 'frontRightSide':
                await helper.click(this.frontRightSide);
                break;
            case 'frontLeftCorner':
                await helper.click(this.frontLeftCorner);
                break;
            case 'frontLeftDoor':
                await helper.click(this.frontLeftDoor);
                break;
            case 'frontRightDoor':
                await helper.click(this.frontRightDoor);
                break;
            case 'rearLeftDoor':
                await helper.click(this.rearLeftDoor);
                break;
            case 'rearRightDoor':
                await helper.click(this.rearRightDoor);
                break;
            default:
                await helper.click(this.frontLeftDoor);
                break;

        }
    }
    async addNewPassenger() {
        await helper.click(this.addPassengerButton);
        await helper.click(this.newPassengerOption);
    }
    async verifyNextButtonDisabledForRequiredFields(){
        await common.validateNextButtonIsDisabled();
        await this.selectFirstAvailableDriver();
        await common.validateNextButtonIsDisabled();
        await this.selectFirstAvailableVehicle();
        await common.validateNextButtonIsEnabled();
    }
    async withNewVehicle(vehicleDetails){
        await this.selectOtherVehicle();
        await helper.typeText(this.newVehicleColor,vehicleDetails.NewVehColor);
        await helper.typeText(this.newVehicleLicense,vehicleDetails.NewVehLicense);
        await helper.typeText(this.newvehicleMake,vehicleDetails.NewVehMake);
        await helper.typeText(this.newvehicleModel,vehicleDetails.NewVehModel);
        await helper.selectDropdown(this.newVehicleState,this.newVehicleStateOption,vehicleDetails.NewVehState);
        await helper.typeText(this.newVehicleVIN,vehicleDetails.NewVehVIN);
        await helper.selectDropdown(this.newVehicleYear, this.newVehicleYearOption,vehicleDetails.NewVehYear);

    }
    async enterNewVehicle(vehicleDetails){
        await helper.typeText(this.newVehicleColor,vehicleDetails.NewVehColor);
        await helper.typeText(this.newVehicleLicense,vehicleDetails.NewVehLicense);
        await helper.typeText(this.newvehicleMake,vehicleDetails.NewVehMake);
        await helper.typeText(this.newvehicleModel,vehicleDetails.NewVehModel);
        await helper.selectDropdown(this.newVehicleState,this.newVehicleStateOption,vehicleDetails.NewVehState);
        await helper.typeText(this.newVehicleVIN,vehicleDetails.NewVehVIN);
        await helper.selectDropdown(this.newVehicleYear, this.newVehicleYearOption,vehicleDetails.NewVehYear);

    }

    async withNewDriver(driverDetails){
        await this.selectOtherDriver();
        await helper.typeText(this.newDriverFirstName,driverDetails.NewDriverFirstName);
        await helper.typeText(this.newDriverLastName,driverDetails.NewDriverLastName);
        await helper.typeText(this.newDriverContactNum,driverDetails.NewDriverContactNum);
        await helper.typeText(this.newDriverCellNum,driverDetails.NewDriverCellNum);
        }
     async selectVehicle(data){
        await helper.selectDropdown(this.vehicleSelect,this.select_Vehicle,data);
    }
    async selectDriver(data){
        await helper.selectDropdownWithText(this.driverSelect,this.select_Driver,data);
    }

}
