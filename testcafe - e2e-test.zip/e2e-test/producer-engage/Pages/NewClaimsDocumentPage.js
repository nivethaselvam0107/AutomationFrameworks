import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector,ClientFunction } from "testcafe";
const helper = new Helper();
const assert = new Assertion();
export default class NewClaimsDocumentPage {
    constructor() {
        this.uploadDocument = Selector("input[id='uploadDocument']")
        this.addPersonButton = Selector("[id='addPersonDropdown'] button");
        this.addNewPersonOption = Selector("a[id='anotherPersonLink']");
        this.newPersonFirstName = Selector("input[id*='firstName']");
        this.newPersonLastName = Selector("input[id*='lastName']"); 
        this.newPersonContactNumber = Selector("input[id*='homeNumber']");
        this.newPersonInjured = Selector("div[id*='injured']");
        this.uploadedDocumentList = Selector("div[id*='uploadDocumentItems']");

    }
    async uploadDocFromFNOL(fileName){
        var filePath = '../../Utilities/FileTypes/';
        await helper.uploadFile(this.uploadDocument,filePath + fileName);
    }

    async addNewContactPerson(){
        await helper.click(this.addPersonButton);
        await helper.click(this.addNewPersonOption);

    }
    async isDocumentUploaded(fileName){
        await assert.hasText(fileName,await helper.getTextAtLocator(this.uploadedDocumentList),'Document is not uploaded');
    }

    async areNewPersonDetailsAreSaved(firstName,lastName,contactNum){
       await assert.assertEqual(await helper.getValueAttributeFromLocator(this.newPersonFirstName),firstName,'New Person First Name is not saved');
       await assert.assertEqual(await helper.getValueAttributeFromLocator(this.newPersonLastName),lastName,'New Person Last Name is not saved');
       await assert.assertEqual(await helper.getValueAttributeFromLocator(this.newPersonContactNumber),contactNum,'New Person contact number is not saved');
    }
    async withNewContactPerson(firstName,lastName,contactNum){
        await this.addNewContactPerson();
        await helper.typeText(this.newPersonFirstName,firstName);
        await helper.typeText(this.newPersonLastName,lastName);
        await helper.typeText(this.newPersonContactNumber,contactNum);

    }
}
