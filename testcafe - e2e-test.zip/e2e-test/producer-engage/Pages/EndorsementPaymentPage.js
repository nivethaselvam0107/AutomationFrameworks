import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertions from '../../Utilities/Assertions';
import PaymentDetailsPage from '../Pages/PaymentDetailsPage';
import CommonLocators from '../../Utilities/CommonLocators';

const helper = new Helper();
const assert = new Assertions();
const data = require('../../producer-engage/Data/PE_PolicyChange_Data.json');
const dataPE = require("../../producer-engage/Data/PE_PA_Data.json");
const payment = new PaymentDetailsPage();
const common = new CommonLocators();
const underWriterHeader = 'Contact Underwriter';
const Underwriting_Message_Line1 = 'We are unable to process this policy change online.';
const Underwriting_Message_Line2 = 'Please call one of our underwriters for assistance in submitting your policy change.';


export default class EndorsementPaymentPage {
    constructor() {
        this.premiumDiff =  Selector("div[id*='hoCostAndPremiumPremiumDifference']").prevSibling();
        this.confirmButton = Selector(" ");
        this.changeBoundMsg = Selector("div[class*='InlineNotification-module']");
        this.noPaymentMsg = Selector("#policyChangePaymentsDecreaseInPremium");
        this.payInFullButton = Selector("[for='hoPaymentTypeRadioButton_payInfull']");
        this.purchaseButton = Selector(" ");
        this.checkingButton = Selector("button[data-value='checking']");
        this.savingButton = Selector(" ");
        this.purchaseButton = Selector(" ");
        this.backToPolicyButton = Selector("[id='backToPolicyButtonId']");
        this.redistributeButton = Selector("[for='hoPaymentTypeRadioButton_redistribute']");
        this.spreadPayment=Selector("[on-click*='redistribute()']");
        this.contactUnderWriterTitle = Selector("#contactUnderwriter");
        this.underwriterMsg1 = Selector("#changePolicy");
        this.underwriterMsg2 = Selector("#changePolicyContactUnderwriter");

    }
    async confirmOrPayInFullWithCheckingBank(){
        var difference = await helper.getTextAtLocator(this.premiumDiff);
       if(difference.includes("0.00") || difference.includes("-")){
            await common.goNext();
            await t.wait(3000);
            await assert.elementPresent(this.backToPolicyButton,'Back to policy button is not displayed in confirmation screen');
            await this.isChangeBound(data.ChangeBoundMsg);
        }else{
            await this.payInFull();
            await this.payWithCheckingBankAccount();
            await common.goNext();
            await t.wait(4000);
            await assert.elementPresent(this.backToPolicyButton,'Back to policy button is not displayed in confirmation screen');
            await this.isChangeBound(data.ChangeBoundMsg);

        }

    }


    async buyAndRedistributeCoverageChanges(){
        await helper.click(this.redistributeButton);
        await common.goNext();
    }
    async confirm(){
        await helper.click(this.confirmButton);
    }
    async isChangeBound(message){
        var actMessage = await helper.getTextAtLocator(this.changeBoundMsg);
        await assert.assertEqual(actMessage,message,'Change Bound message is not displayed');
    }
    async isNoPaymentNeedMsgPresent(message){
        await assert.elementPresent(this.noPaymentMsg,message, 'No Payment needed message is not displayed');
    }
    async payInFull(){
        await helper.click(this.payInFullButton);
    }
    async purchase(){
        await helper.click(this.purchaseButton);
    }
    async selectCheckingAccountType(){
        await helper.click(this.checkingButton);
    }
    async selectSavingAccountType(){
        await helper.click(this.savingButton);
    }
    async payWithCheckingBankAccount(){
        await payment.setPaymentMethod('Bank Account');
        await this.selectCheckingAccountType();
        await payment.setAccountNumber(dataPE.AccountNumber);
        await payment.setABARoutingNumber(dataPE.RoutingNumber);
        await payment.setBankName(dataPE.BankName);
    }
    async payWithSavingBankAccount(){
        await payment.setPaymentMethod('Bank Account');
        await this.selectSavingAccountType();
        await payment.setAccountNumber(dataPE.AccountNumber);
        await payment.setABARoutingNumber(dataPE.RoutingNumber);
        await payment.setBankName(dataPE.BankName);
    }

    async clickBackToPolicy(){
        await helper.click(this.backToPolicyButton);
    }
    async clickSpreadPayments(){
    await helper.click(this.spreadPayment);
    }
    async validateUnderwriterIssueMessage(){
        assert.assertEqual(await helper.getTextAtLocator(this.contactUnderWriterTitle),underWriterHeader,'Underwriter header is incorrect or missing');
        assert.assertEqual(await helper.getTextAtLocator(this.underwriterMsg1),Underwriting_Message_Line1,'Underwriter message line 1 is incorrect or missing');
        assert.assertEqual(await helper.getTextAtLocator(this.underwriterMsg2),Underwriting_Message_Line2,'Underwriter message line 2 is incorrect or missing');
    }




}
