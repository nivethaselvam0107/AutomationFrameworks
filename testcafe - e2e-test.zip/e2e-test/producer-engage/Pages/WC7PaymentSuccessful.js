import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common=new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WCPaymentSuccessful {
  constructor() {
      this.policyTotalAmountValue = Selector("[for='policyTotalAmount']").sibling('div');

  }
  async getPolicyTotalAmount(){
      var totalAmount = await helper.getTextAtLocator(this.policyTotalAmountValue);
      return totalAmount;
  }
  async validateTotalAmount(quoteValue,totalAmount){
      await assert.assertEqual(totalAmount,quoteValue,'Policy Total Amount displayed is incorrect');

  }
  async clickPolicyNumber(){
      await helper.click(this.policyNumberValue);
  }
}