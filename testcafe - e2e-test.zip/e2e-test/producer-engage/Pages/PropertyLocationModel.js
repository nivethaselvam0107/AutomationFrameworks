import { Selector, t ,ClientFunction} from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import CommonLocators from "../../Utilities/CommonLocators"

const helper = new Helper();
const common =new CommonLocators();
const assert = new Assertion();

export default class PropertyLocationModel {
    constructor() {
        this.existingLocDrop = Selector("[id='existingLocationSelect']");
        this.newLocRbtn = Selector("[id='existingLocationToggle'] [data-value='false']");
        this.limitDrop = Selector("[id='LimitId']");
        this.limitDrop_Option=Selector("[id='LimitId'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.propertyDescriptionTxt = Selector("[id='SchedItemDescriptionId']");
        this.addLocBtn = Selector("[class*='ScheduleItemModalPopover'] [class*='primary']");
        this.cancelAddLocBtn = Selector("[class*='ScheduleItemModalPopover'] [class*='secondary']");
        this.addLine1 = Selector("[id='addressLine1']");
        this.addressLine1 = Selector("[id='addressLine1']");
        this.addLine2 = Selector("[model='address.addressLine2'] input");
        this.addLine3 = Selector("[model='address.addressLine3'] input");
        this.city = Selector("[id='city']");
        this.zipCode = Selector("[id='zipCode']");
        this.state = Selector("[id='state']");
        this.state_Option=Selector("[id='state'] div[class*='TypeaheadMultiSelectField__menu'] div");
    }
    async validateNewLocationPopUp(data) {
        await assert.elementPresent(this.addressLine1, "Address Line1 Field not present");
        await assert.elementPresent(this.city, 'City Field not present');
        await assert.elementPresent(this.zipCode, 'Zip code field not present');
        await assert.elementPresent(this.state, 'State field not present');
        await assert.elementPresent(this.addLocBtn, 'Add button not present');
        await assert.elementPresent(this.cancelAddLocBtn, 'Cancel button not present');
        if (data.value == 4) {
            await assert.elementPresent(this.propertyDescriptionTxt, 'Property description not present');
        }
    }
    async setIncreasedLimit(data) {
        await helper.selectDropdown(this.limitDrop,this.limitDrop_Option, data.IncreasedLimit);
    }
    async fillNewLocationFrom(data){
        if(await this.existingLocDrop.exists)
        {
            await helper.click(this.newLocRbtn);
        }
        await helper.typeText(this.addLine1,data.AddressLine1);
        await helper.typeText(this.city,data.City);
        await helper.typeText(this.zipCode,data.Zip);
        await helper.click(this.state);
        await t.wait(1000);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("[id='state'] div[class*='TypeaheadMultiSelectField__menu'] div");
            for (var item of items)
                if(item.textContent=='California'){
                     item.scrollIntoView();
                }
        });
        await dropDownValues();
        await helper.click(this.state_Option.withExactText('California'));
        await this.addLocation();
    }
    async addLocation(){
        await helper.click(this.addLocBtn);
    }
    async validateMandatoryFieldsOfPersonalPropertyAtOtherResidence(data){
       await common.validateScheduledAddButtonIsDisabled();
       await this.setIncreasedLimit(data);
       await common.validateScheduledAddButtonIsEnabled();
    }
    async setDescription(data){
        await helper.typeText(this.propertyDescriptionTxt,data.Description);
    }
    async validateMandatoryFieldsOfSpecificStrAtOtherResidence(data){
        await this.setDescription(data); 
        await this.setIncreasedLimit(data);
    }
    async addNewLocation(){
        await helper.click(this.newLocRbtn);
    }
}