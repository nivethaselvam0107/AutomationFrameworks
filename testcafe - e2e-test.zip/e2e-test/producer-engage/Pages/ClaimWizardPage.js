import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector } from "testcafe";
import DataFetch from "../Data/DataFetch";
import AlertHandler from "./AlertHandler";
const helper = new Helper();
const alert = new AlertHandler();
const assert = new Assertion();
const dataFetch = new DataFetch();
export default class ClaimWizardPage {
    constructor() {
        this.cancelButton = Selector("button[id='gw-wizard-cancel']");
        this.previousButton = Selector("button[id='gw-wizard-previous']");
    }
    async cancelWizardPopup() {
        await this.clickCancel();
        await alert.closeAlert();
    }
    async clickCancel() {
        await helper.click(this.cancelButton);
    }
    async clickPrevious() {
        await helper.click(this.previousButton);
    }
}