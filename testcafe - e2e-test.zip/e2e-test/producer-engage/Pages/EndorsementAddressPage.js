import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from '../Data/DataFetch';
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();

export default class EndorsementAddressPage {
    constructor() {
        this.addressLine1Input = Selector("input[id='addressLine1']");
        this.addressLine1Error = Selector("[id*='addressLine1'][role='alert']");
        this.cityInput = Selector("input[id='city']");
        this.cityError = Selector("[id*='city'][role='alert']")
        this.nextAddressBtn = Selector("button[id='gw-wizard-Next']");
        this.zipCode = Selector("#postalCode");
        this.zipCodeError = Selector("[id*='postalCode'][role='alert']");
        this.state = Selector("#state");
    }
    async setAddressLine1(line1) {
        await helper.typeText(this.addressLine1Input, line1);
    }
    async validateMandatoryErrorMessageInAddressPage(){
        await helper.removeRequiredTextAndValidate(this.addressLine1Input,this.addressLine1Error);
        await helper.removeRequiredTextAndValidate(this.cityInput,this.cityError);
        await helper.removeRequiredTextAndValidate(this.zipCode,this.zipCodeError);
    }
    async setCity(city){
        await helper.typeText(this.cityInput, city);
    }
    async setZip(zip){
        await helper.typeText(this.zipCode,zip);
    }
    async setState(state){
        await helper.selectDropdown(this.state,state);
    }
    async validateAddressChangedInPolicyFromBackEnd(data,policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        await assert.assertEqual(data.NewCity,content.baseData.policyAddress.city,'City value is not matched');
    }
}