import { Selector,ClientFunction,t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertions from "../../Utilities/Assertions";
import moment from 'moment';
const helper = new Helper();
const assert = new Assertions();
var addressContainer = "div[id='addressDetails']"; 

export default class QuoteStart {
  constructor() {
    this.producerCode_Select=Selector("[id='submissionProducerCode']");
    this.producerCode_Option=Selector("[id='submissionProducerCode'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.productCode_Select=Selector("[id='submissionProductCode']");
    this.productCode_Option=Selector("[id='submissionProductCode'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.cancelButton = Selector("button[id='cancel']"); 
    this.nextButton=Selector("[id='next']"); 
    this.selectDate=Selector("[id='submissionDate']") 
    this.state_Select=Selector("[id='submissionState']"); 
    this.state_Option=Selector("[id='submissionState'] div[class*='TypeaheadMultiSelectField__menu'] div");
  
  }

  async selectProducerCode(option) {
    await helper.selectDropdown(this.producerCode_Select, this.producerCode_Option, option);
    await t.wait(2000);
  }
  async selectProductCode(option) {
    await helper.selectDropdown(this.productCode_Select, this.productCode_Option, option);
  }
  async clickSubmit() {
    await helper.click(this.nextButton);
  }
  async selectState(option) {
    await helper.selectDropdown(this.state_Select, this.state_Option, option);
  }
  async fillQuoteDetails(data) {
    await this.selectState(data.State);
    await this.selectProducerCode(data.ProducerCode);
    await t.wait(2000);
    await this.selectProductCode(data.ProductCode);
  }
  async fillQuoteForPAExistingAccount(data) {
    await this.selectProducerCode(data.ProducerCode);
    await t.wait(1000)
    await this.selectProductCode(data.ProductCode);
  }
  async fillQuoteForHOExistingAccount(dataHO) {
    await this.selectProducerCode(dataHO.ProducerCode);
    await this.selectProductCode(dataHO.ProductCode);
  }
  async fillQuoteForWC7ExistingAccount(data) {
    await this.selectProducerCode(data.ProducerCode);
    await this.selectProductCode(data.ProductCode);
  }
  async fillPolicyDetailsFormForExistingAccount(data){
    await this.selectProducerCode(data.ProducerCode);
    await this.selectProductCode(data.ProductCode);

  };

  async cancel() {
    await helper.click(this.cancelButton);
  }
  async isEnteredAddressPresent(data) {
    var enteredAddress;
    if(data.Type === 'Person'){
    enteredAddress = data.FirstName+" "+data.LastName+'\n'+data.AddressLine1 +'\n'+ data.City+'\n'+data.StateCode+" "+data.Zip;
    }else if(data.Type === 'Company'){
    enteredAddress = data.Company+'\n'+data.AddressLine1 +'\n'+ data.City+'\n'+data.StateCode+" "+data.Zip;
    }
    await assert.assertEqual(await helper.getTextAtLocator(Selector(addressContainer)),enteredAddress, 'Address details does not match');
  }


  async setDate(policy){
    var policyeff = policy.policyEffectiveDate;
        var date = moment(policyeff).format('L');
        var effectiveDate = moment(date, 'mm/dd/yy').format('ll');
        await helper.typeText(this.selectDate, effectiveDate);
  }
  async setFutureDate(date){
    var effectiveDate =moment(date,'mm/dd/yy').add(7,'d');
    await helper.typeText(this.selectDate,effectiveDate);
  }


  async isProductCodeNotAvailableWithRiskReservedTag(productCode){
    await helper.click(this.productCode_Select);
    var dropDownValueSelector = ClientFunction(() => {
      var items = document.querySelectorAll("[id='submissionProductCode'] div[class*='TypeaheadMultiSelectField__menu'] div");
      var itemsValues = [];
      for (var item of items)
          {
            itemsValues.push(item.textContent);
          }
      return itemsValues;
    });
    var personalAuto = await dropDownValueSelector();
    personalAuto.splice(0,2);
    for (var i=0; i<personalAuto.length; i++ ){
      if(personalAuto[i] === productCode){
        return false;
      }
    }
    return true;
  }

}
