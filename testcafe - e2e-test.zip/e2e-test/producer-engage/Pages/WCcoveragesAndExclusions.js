import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WCCoveragesAndExclusions {
    constructor() {
        this.nextButton = Selector("[id='gw-wizard-Next']");
        this.limitPerAccidentLabel = Selector("label[id*='ClauseTerm_[WC7WorkersCompEmpLiabInsurancePolicyACov]']").nth(0);
        this.policyLimitDiseaseLabel = Selector("label[id*='ClauseTerm_[WC7WorkersCompEmpLiabInsurancePolicyACov]']").nth(1);
        this.stopGapLabel = Selector("label[id*='ClauseTerm_[WC7WorkersCompEmpLiabInsurancePolicyACov]']").nth(2);
        this.stopGapSelect = Selector("div[id*='ClauseTerm_[WC7WorkersCompEmpLiabInsurancePolicyACov]'][class*='TypeaheadMultiSelectField']").nth(2);
        this.stopGapOption = Selector("div[id*='ClauseTerm_[WC7WorkersCompEmpLiabInsurancePolicyACov]'][class*='TypeaheadMultiSelectField']").nth(2).find("div[class*='TypeaheadMultiSelectField__menu'] div");
    }
    async validateMandatoryFieldInCoveragesAndExclusions(){ 
        await common.validateNextButtonIsDisabled();
        await assert.textNotContains(await helper.getTextAtLocator(this.limitPerAccidentLabel),'(optional)','Limit - per Accident / per Employee Disease should be mandatory field');
        await assert.textNotContains(await helper.getTextAtLocator(this.policyLimitDiseaseLabel),'(optional)','Policy Limit - Disease  should be mandatory field');
        await assert.textNotContains(await helper.getTextAtLocator(this.stopGapLabel),'(optional)','Stop Gap should be mandatory field');
        }
    

    async validateNextButtonDisabled() {
        await assert.isElementNotClickable(this.nextButton, 'disabled', 'Next Button is enabled');
    }
    async clickNext() {
        await helper.click(this.nextButton);
    }
    async selectStopGap(stopGap){
        await helper.selectDropdown(this.stopGapSelect,this.stopGapOption,stopGap);
    }
}