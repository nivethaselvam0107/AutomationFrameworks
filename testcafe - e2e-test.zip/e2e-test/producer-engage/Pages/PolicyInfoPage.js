import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertion();

export default class PolicyInfoPage {
    constructor() {
        this.phoneNumber = Selector("[id='phoneNumber']");
        this.email = Selector("[id='emailAddress']");
        this.emailAddress=Selector("[id='email']")
        this.phoneMandatoryError = Selector("[model*='contactPhone'] [gw-test-platform-widgets-basicinputs-ctrl-group-error-message]");
        this.emailMandatoryError = Selector("[model*='contactEmail']  span[class*='gw-error']");
    }
    async isEmailEqualsTo(data){
       
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.email),data.EmailAddress,'Email is not Correct');
    }

    async setPhoneNumberasEmpty() {
        await helper.removeText(this.phoneNumber);
    }
    async setPhoneNumber(phoneNumber){
        await helper.typeText(this.phoneNumber,phoneNumber);
    }

    async setEmailAddress(EmailAddress){
        await helper.removeText(this.email);
        await helper.typeText(this.email,EmailAddress);
    }

    async setEmailasEmpty() {
        await helper.removeText(this.email);
    }

    async phoneNumberMarkedWithMandatoryError() {
        await assert.elementPresent(this.phoneMandatoryError, "Mandatory error is not displayed for Phone Number");
        await assert.assertEqual(this.phoneMandatoryError.innerText, 'This is a required field', "Mandatory error message is incorrect")
    }

    async emailMarkedWithMandatoryError() {
        await assert.elementPresent(this.emailMandatoryError, "Mandatory error is not displayed for Phone Number");
        await assert.assertEqual(this.emailMandatoryError.innerText, 'This is a required field', "Mandatory error message is incorrect")
    }
    async arePolicyInfoPageFieldsMarkedWithMandatoryError() {
        await this.phoneNumberMarkedWithMandatoryError();
        await this.emailMarkedWithMandatoryError();
    }

}

