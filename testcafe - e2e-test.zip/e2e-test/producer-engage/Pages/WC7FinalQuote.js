import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WC7FinalQuote{
    constructor() {
        this.quoteValue = Selector("[id*='wc7CostAndPremiumTotalCost']").sibling('div');
    }
    async getQuoteValue(){
        var quoteValue = await helper.getTextAtLocator(this.quoteValue);
        return quoteValue;

    }
}