import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();
var value;
var roofType = "[src*='roof/" + value + "']";

export default class ConstructionPage {
    constructor() {

        this.build_Year = Selector("[id='yearBuilt']");
        this.no_Of_Stories = Selector("[id='numberOfStories']");
        this.no_Of_Stories_option = Selector("[id='numberOfStories'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.construction_Type_Select = Selector("[id='constructionType']");
        this.construction_Type_Option = Selector("[id='constructionType'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.foundation_Type_Select = Selector("[id='foundationType']");
        this.foundation_Type_Option = Selector("[id='foundationType'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.roof_Type=Selector("[src*='roof/wood.jpg']");
        this.plumbing_Type_Select = Selector("[id='plumbing']");
        this.plumbing_Type_Option = Selector("[id='plumbing'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.primary_Heating_Select = Selector("[id='primaryHeating']");
        this.primary_Heating_Option = Selector("[id='primaryHeating'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.electric_Wiring_Type_Select = Selector("[id='wiring']");
        this.electric_Wiring_Type_Option = Selector("[id='wiring'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.electrical_System_Select = Selector("[id='electricalSystem']");
        this.electrical_System_Option = Selector("[id='electricalSystem'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.roof_Upgrade_Check = Selector("[aria-label='Roofing Upgraded']");
        this.roof_Upgrade_Year = Selector("[id='roofUpgradeYear']");
        this.plumbing_Upgrade_Check = Selector("[aria-label='Plumbing Upgraded']");
        this.plumbing_Upgrade_Year = Selector("[id='plumbingUpgradeYear']");
        this.heating_Upgrade_Check = Selector("[aria-label='Heating Upgraded']");
        this.heating_Upgrade_Year = Selector("[id='heatingUpgradeYear']");
        this.electric_Wiring_Check = Selector("[aria-label='Wiring Upgraded']");
        this.electric_Wiring_Year = Selector("[id='electricalUpgradeYear']");
        this.selected_Roof_Type = Selector("input:checked + div").find('img');
        this.hoNoOfStories = Selector("[gw-viewmodel-ref*='storiesNumber'] [options*='availableValues']");
    }
    async withBuildYear(buildyear) {
        await helper.typeText(this.build_Year, buildyear);
    }
    async withHouseStories(stories) {
        await helper.selectDropdown(this.no_Of_Stories,this.no_Of_Stories_option,stories);
    }
    async withConstructionType(construction) {
        await helper.selectDropdown(this.construction_Type_Select,this.construction_Type_Option, construction);
    }
    async withFoundationType(foundation) {
        await helper.selectDropdown(this.foundation_Type_Select,this.foundation_Type_Option, foundation);
    }
    async withRoofType(roof) {
        const roof_Type  = roofType.replace(value,roof);
        await helper.click(Selector(roof_Type));
    }
    async withPlumbingType(plumbing) {
        await helper.selectDropdown(this.plumbing_Type_Select,this.plumbing_Type_Option, plumbing);
    }
    async withHeatingType(primaryheating) {
        await helper.selectDropdown(this.primary_Heating_Select,this.primary_Heating_Option, primaryheating);
    }
    async withElectricalWiringType(wiringtype) {
        await helper.selectDropdown(this.electric_Wiring_Type_Select,this.electric_Wiring_Type_Option, wiringtype)
    }
    async withElectricalSystemType(electrical) {
        await helper.selectDropdown(this.electrical_System_Select,this.electrical_System_Option, electrical)
    }

    async setConstructionPageDetails(dataHO) {
        await this.withBuildYear(dataHO.BuildYear);
        await this.withHouseStories(dataHO.NumberOfStories);
        await this.withConstructionType(dataHO.ConstructionType);
        await this.withFoundationType(dataHO.FoundationType);
        await this.withRoofType(dataHO.RoofType);
        await this.withPlumbingType(dataHO.PlumbingType);
        await this.withHeatingType(dataHO.PrimaryHeating);
        await this.withElectricalWiringType(dataHO.WiringType);
        await this.withElectricalSystemType(dataHO.ElectricalSystemType);
    }

    async areConstructionPageFieldsMakedWithMandatoryError(text) {
        await assert.assertEqual(this.build_Year_ValidationError.innerText, text, 'Build year Field is not marked with Error');
        await assert.assertEqual(this.no_Of_Stories_ValidationError.innerText, text, 'No of Stories Field is not marked with Error');
        await assert.assertEqual(this.construction_Type_ValidationError.innerText, text, 'Construction type Field is not marked with Error');
        await assert.assertEqual(this.foundation_Type_ValidationError.innerText, text, 'Foundation type Field is not marked with Error');
        await this.expandRoofSection();
        await assert.assertEqual(this.roof_Type_ValidationError.innerText, text, 'Roof Section Field is not marked with Error');
        await this.hideRoofSection();
        await this.expandPlumbingSection();
        await assert.assertEqual(this.plumbing_Type_ValidationError.innerText, text, 'Plumbing type Field is not marked with Error');
        await this.hidePlumbingSection();
        await this.expandHeatingSection();
        await assert.assertEqual(this.primary_Heating_ValidationError.innerText, text, 'Heating type Field is not marked with Error');
        await this.hideHeatingSection();
        await this.expandElectricSection();
        await assert.assertEqual(this.wiringtype_ValidationError.innerText, text, 'Wiring type Field is not marked with Error');
        await assert.assertEqual(this.electrical_System_ValidationError.innerText, text, 'Electrical system is not marked with Error');

    }
    async withRoofUpgraded() {
        await this.expandRoofSection();
        await helper.click(this.roof_Upgrade_Check);
    }

    async selectPlumbingUpgraded() {
        await this.expandPlumbingSection();
        await helper.click(this.plumbing_Upgrade_Check);
    }
    async selectHeatingUpgraded() {
        await this.expandHeatingSection();
        await helper.click(this.heating_Upgrade_Check);

    }
    async selectWiringUpgraded() {
        await this.expandElectricSection();
        await helper.click(this.electric_Wiring_Check);

    }
    async withRoofUpgradeYear(roof) {
        await this.withRoofUpgraded();
        await helper.typeText(this.roof_Upgrade_Year, roof);
    }
    async withPlumbingUpgradeYear(plumbing) {
        await this.selectPlumbingUpgraded();
        await helper.typeText(this.plumbing_Upgrade_Year, plumbing);
    }
    async withHeatingUpgradeYear(heating) {
        await this.selectHeatingUpgraded();
        await helper.typeText(this.heating_Upgrade_Year, heating);
    }
    async withWiringUpgradeYear(wiring) {
        await this.selectWiringUpgraded();
        await helper.typeText(this.electric_Wiring_Year, wiring);
    }
    async withConstructionUpgradeYear(dataHO) {
        await this.withRoofUpgradeYear(dataHO.RoofYear);
        await this.withPlumbingUpgradeYear(dataHO.PlumbingYear);
        await this.withHeatingUpgradeYear(dataHO.HeatingYear);
        await this.withWiringUpgradeYear(dataHO.WiringYear);
    }
    async isBuildYearEqualsTo(data) {
        await assert.assertEqual(
            await helper.getValueAttributeFromLocator(this.build_Year), data.BuildYear, "Build year value is not matched");
    }
    async areBuildlingStoriesEqualsTo(data) {
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.no_Of_Stories), data.NumberOfStories, 'No of buildings value is not matched');
    }
    async areBuildlingStoriesEqualsHO(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.no_Of_Stories), data.NumberOfStories, 'No of buildings value is not matched');
    }
    async isConstructionTypeEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.construction_Type_Select), data.ConstructionType, 'Construction value is not matched');
    }
    async isFoundationTypeEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.foundation_Type_Select), data.FoundationType, 'Foundation value is not matched');
    }
    async isRoofTypeEqualsTo(data) {
        var roofValue = await this.selected_Roof_Type.getAttribute('src');
        await assert.textContains(roofValue, data.RoofType, 'Roof type value is not matched');
    }
    async isPlumbingTypeEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.plumbing_Type_Select), data.PlumbingType, 'Plumbing value is not matched');
    }
    async isHeatingTypeEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.primary_Heating_Select), data.PrimaryHeating, 'Heating type value is not matched');
    }
    async isWiringTypeEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.electric_Wiring_Type_Select), data.WiringType, 'Wiring type value is not matched');
    }
    async isElectricalSystemEqualsTo(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.electrical_System_Select), data.ElectricalSystemType, 'Electrical system value is not matched');
    }
    async areConstructionPageDetailsSaved(data) {
        await this.isBuildYearEqualsTo(data);
        await this.areBuildlingStoriesEqualsTo(data);
        await this.isConstructionTypeEqualsTo(data);
        await this.isFoundationTypeEqualsTo(data);
        await this.isRoofTypeEqualsTo(data);
        await this.isPlumbingTypeEqualsTo(data);
        await this.isHeatingTypeEqualsTo(data);
        await this.isWiringTypeEqualsTo(data);
        await this.isElectricalSystemEqualsTo(data);
    }
    async areConstructionPageDetailsSavedHO(data) {
        await this.isBuildYearEqualsTo(data);
        await this.areBuildlingStoriesEqualsHO(data);
        await this.isConstructionTypeEqualsTo(data);
        await this.isFoundationTypeEqualsTo(data);
        await this.isRoofTypeEqualsTo(data);
        await this.isPlumbingTypeEqualsTo(data);
        await this.isHeatingTypeEqualsTo(data);
        await this.isWiringTypeEqualsTo(data);
        await this.isElectricalSystemEqualsTo(data);
    }
    async setHOPConstructionPageDetails(dataHO){
        await this.withBuildYear(dataHO.BuildYear);
        await this.withHOPHouseStories(dataHO.NumberOfStories);
        await this.withConstructionType(dataHO.ConstructionType);
        await this.withFoundationType(dataHO.FoundationType);
        await this.withRoofType(dataHO.RoofType);
        await this.withPlumbingType(dataHO.PlumbingType);
        await this.withHeatingType(dataHO.PrimaryHeating);
        await this.withElectricalWiringType(dataHO.WiringType);
        await this.withElectricalSystemType(dataHO.ElectricalSystemType);   
    }
    async withHOPHouseStories(stories) {
        await helper.typeText(this.no_Of_Stories, stories);
    }



}