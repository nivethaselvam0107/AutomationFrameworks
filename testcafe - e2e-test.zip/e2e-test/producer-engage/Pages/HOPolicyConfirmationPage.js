import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import moment from "moment";

const helper = new Helper();
const assert = new Assertion();
const scheduledProperty = "[class*='ScheduleItemsComponent_gwTableCell']";

export default class HOPolicyConfirmationPage {
    constructor() {
        this.account_Number = Selector("[id='accountNumberLink']");
        this.policyNumber = Selector("[id='policyNumberLink']");
        this.policyStartDate = Selector("[id='effectiveDate']");
        this.policyPeriod = Selector("#policyPeriod");
        this.policyTotalAmt = Selector("[class*='CurrencyField-module']").nth(0);
        this.policyPlanName = Selector("[id='paymentPlanName']");
        this.policyCurrentPayment = Selector("[class*='CurrencyField-module']").nth(1);
        this.infoSection =  Selector("[id='yourInfoAccordion']").find("[class*='accordion']");
        this.houseSection = Selector("[id='yourHouseAccordion']").find("[class*='accordion']");
        this.coverageSection = Selector("[id='yourCoveragesAccordion']").find("[class*='accordion']");
        this.scheduledTypeText = Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.scheduledTypeValue = Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.scheduledDeductible = Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(2);
        this.scheduledValuation = Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(3);
        this.specialSchPropertyType =  Selector("[class*='TableTitle']").withText('Special Limits Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.specialSchPropertyDesc =  Selector("[class*='TableTitle']").withText('Special Limits Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.specialSchPropertyValue =  Selector("[class*='TableTitle']").withText('Special Limits Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(2);
        this.schPropertyType =  Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.schPropertyDesc =  Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.schPropertyValue =  Selector("[class*='TableTitle']").withText('Scheduled Personal Property').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(2);
        this.othStrucOnResidencePremisePropertyDesc = Selector("[class*='TableTitle']").withText('Other Structures On The Residence Premises').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.othStrucOnResidencePremisePropertyLimit =  Selector("[class*='TableTitle']").withText('Other Structures On The Residence Premises').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.personalPropertyAtOtherResidenceLocation =  Selector("[class*='TableTitle']").withText('Personal Property At Other Residences').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.personalPropertyAtOtherResidenceLimit =  Selector("[class*='TableTitle']").withText('Personal Property At Other Residences').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.specificStructuresAtOtherResidenceLocation =  Selector("[class*='TableTitle']").withText('Specific Structures Away From The Residence Premises').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(2);
        this.specificStructuresAtOtherResidenceDesc =  Selector("[class*='TableTitle']").withText('Specific Structures Away From The Residence Premises').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(0);
        this.specificStructuresAtOtherResidenceLimit =  Selector("[class*='TableTitle']").withText('Specific Structures Away From The Residence Premises').parent(0).find("[class*='ScheduleItemsComponent_gwTableCell']").nth(1);
        this.accountFirstName = Selector("#firstName");
        this.accountLastName = Selector("#lastName");
        this.accountEmail = Selector("#emailAddress");
        this.accountAddressLine1 = Selector("#addressLine1");
        this.accountAddressLine2 = Selector("#addressLine2");
        this.accountAddressLine3 = Selector("#addressLine3");
        this.accountCity = Selector("#city");
        this.accountState = Selector("#state");
        this.accountZip = Selector("#postalCode");
    }

    async isPolicyConfirmationPageDisplayed() {
        await assert.elementPresent(this.account_Number, 'confirmation page is not opened');

    }
    async getScheduledPropertyDataFromBackEnd(data) {
        await helper.click(this.coverageSection);
        const type = await helper.getTextAtLocator(this.scheduledTypeText);
        const text = type.toLowerCase();
        const propType = (data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.ArticleType.typeCodeValue).replace('_',' ');
        await assert.assertEqual(text,propType, 'Scheduled Type does not match');
        const amt = (data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.ArticleLimit.integerValue).toFixed(2);
        const amount = '$' + amt;
        await assert.assertEqual(await helper.getTextAtLocator(this.scheduledTypeValue), amount, 'Scheduled Value does not match');
        const amount1 = await helper.getTextAtLocator(this.scheduledDeductible);
        const deduct = amount1.replace('$', '').replace(',', '');
        const deductvalue = (data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.ArticleDeductible.typeCodeValue).replace('HOPScheduledPersonalPropertyItemDeductible', '');
        await assert.assertEqual(deduct, deductvalue, 'Scheduled Deductible does not match');
        const scheduleValuation = await this.scheduledValuationConversion(data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.ArticleValuationMethod.typeCodeValue);
        await assert.assertEqual(await helper.getTextAtLocator(this.scheduledValuation), scheduleValuation, 'Scheduled Valuation does not match');
    }
    async scheduledValuationConversion(response) {
        if (response = 'ReplCost') {
            const cost1 = 'Replacement cost';
            return cost1
        } else {
            const cost2 = 'Actual cash value';
            return cost2;
        }
    }

    async getPolicyNumber(){
        return await helper.getTextAtLocator(this.policyNumber);
    }

    async validatePersonalProperty(data) {
        await assert.assertEqual((Selector(scheduledProperty).nth(0)).innerText, data.ScheduledType, "Scheduled Personal Property Type doesn't match one that was added");
        await assert.assertEqual((Selector(scheduledProperty).nth(1)).innerText, data.ScheduledDescription, "Scheduled Personal Property Description doesn't match one that was added");
        const scheduleValue = parseFloat(data.ScheduledValue).toFixed(2);
        const value = '$'+scheduleValue;
        await assert.assertEqual((Selector(scheduledProperty).nth(2)).innerText, value, "Scheduled Personal Property Value doesn't match one that was added");
    }
    async policySummaryConfirmation(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.account_Number), data.accountNumber, 'Account Number does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyNumber), data.policyNum, 'Policy Number does not match');
        var effMonth = data.policyEffectiveMonth + 1;
        var startDate = effMonth + '/' + data.policyEffectiveDay + '/' + data.policyEffectiveYear;
        var effDate = moment(startDate).format('ll');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyStartDate), effDate, 'Policy effective date does not match');
        var expMonth = data.policyExpirationMonth + 1;
        var endDate = expMonth + '/' + data.policyExpirationDay + '/' + data.policyExpirationYear;
        var expDate = moment(endDate).format('ll');
        const period = effDate + '-' + expDate;
        await assert.assertEqual((await helper.getTextAtLocator(this.policyPeriod)).replace(/\n/g, ""), period, 'Policy period does not match');
        var polTotalAmt = ((await helper.getTextAtLocator(this.policyTotalAmt)).replace(',', '').replace('USD', '')).trim();
        await assert.assertEqual(polTotalAmt,parseFloat(data.policyTotalAmount).toFixed(2), 'Policy total amount does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyPlanName), data.paymentPlanName, 'Policy payment plan does not match');
        var polCurrentAmt = ((await helper.getTextAtLocator(this.policyCurrentPayment)).replace(',', '').replace('USD', '')).trim();
        await assert.assertEqual(polCurrentAmt, parseFloat(data.policyCurrentPayment).toFixed(2), 'Policy current amount does not match');
    }

    async HOpolicySummaryConfirmation(data) {
        await assert.assertEqual(await helper.getTextAtLocator(this.account_Number), data.accountNumber, 'Account Number does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyNumber), data.policyNum, 'Policy Number does not match');
        var startDate = data.policyEffectiveDate;
        var effDate = moment(startDate).format('ll');
        await assert.assertEqual(await helper.getTextAtLocator(this.policyStartDate), effDate, 'Policy effective date does not match');
        var endDate = data.policyExpirationDate;
        var expDate = moment(endDate).format('ll');
        const period = effDate + '-' + expDate;
        await assert.assertEqual((await helper.getTextAtLocator(this.policyPeriod)).replace(/\n/g, ""), period, 'Policy period does not match');
        var polTotalAmt = ((await helper.getTextAtLocator(this.policyTotalAmt)).replace(',', '').replace('USD', '')).trim();
        await assert.assertEqual(polTotalAmt,parseFloat(data.policyTotalAmount).toFixed(2), 'Policy total amount does not match');
    }
    
    async checkScheduledPropertyIsEmpty(data) {
        console.log(data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems.length);
        await assert.assertEqual(data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems.length, 0, 'Scheduled property was added');
    }
    async validateOtherPersonalProperty(data){
        await assert.assertEqual((Selector(scheduledProperty).nth(0)).innerText, data.ScheduledDescription, "Scheduled Personal Property Description doesn't match one that was added");
        await assert.assertEqual((Selector(scheduledProperty).nth(1)).innerText, data.Limit, "Scheduled Personal Property Limit doesn't match one that was added");
    }
    async checkSpecialScheduledPropertyIsEmpty(data) {
        await assert.assertEqual(0, data.lobData.homeowners.offerings[0].coverages.schedules[1].scheduleItems.length, 'Special Scheduled property was added');
    }
    async validateHOOtherScheduledPersonalPropertyDataWithBackEnd(data){
        await assert.assertEqual(this.othStrucOnResidencePremisePropertyDesc.innerText,data.lobData.homeowners.offerings[0].coverages.schedules[2].scheduleItems[0].itemData.SchedItemDescriptionId.stringValue,'Other scheduled personal property description does not match');
        var limit = (data.lobData.homeowners.offerings[0].coverages.schedules[2].scheduleItems[0].itemData.LimitId.typeCodeValue)+'%';
        await assert.assertEqual(this.othStrucOnResidencePremisePropertyLimit.innerText,limit,'Other scheduled personal property limit does not match');
    }
    async checkOtherScheduledPropertyIsEmpty(data) {
        await assert.assertEqual(0, data.lobData.homeowners.offerings[0].coverages.schedules[2].scheduleItems.length, 'Other Scheduled property was added');
    }
    async validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(data){
        var type = data.lobData.homeowners.offerings[0].coverages.schedules[1].scheduleItems[0].itemData.ArticleType.typeCodeValue;
        var propertyType= await helper.getTextAtLocator(this.specialSchPropertyType);
        var uiType = propertyType.toString().replace(/\s/g,''); 
        await assert.assertEqual(uiType,type,'Special Scheduled property type does not match');
        await assert.assertEqual(await this.specialSchPropertyDesc.innerText,data.lobData.homeowners.offerings[0].coverages.schedules[1].scheduleItems[0].itemData.SchedItemDescriptionId.stringValue,'Special Scheduled property type does not match');
        var limit = parseFloat(data.lobData.homeowners.offerings[0].coverages.schedules[1].scheduleItems[0].itemData.SchedItemValueId.integerValue).toFixed(2);
        var value = '$'+limit;
        await assert.assertEqual(await this.specialSchPropertyValue.innerText,value,'Special Scheduled property type does not match');
    }
    async validateHOScheduledPersonalPropertyDataWithBackEnd(data){
        var a = await helper.getTextAtLocator(this.schPropertyType);
        var type = a.toString().replace(/\s/g,'');
        await assert.assertEqual(type, data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.ArticleType.typeCodeValue, "Scheduled Personal Property Type doesn't match one that was added");
        await assert.assertEqual(this.schPropertyDesc.innerText, data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.SchedItemDescriptionId.stringValue, "Scheduled Personal Property Description doesn't match one that was added");
        var y = parseFloat(data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems[0].itemData.SchedItemValueId.integerValue).toFixed(2);
        var value = '$'+y;
        await assert.assertEqual(this.schPropertyValue.innerText,value, "Scheduled Personal Property Value doesn't match one that was added");
    }
    async checkScheduledPersonalPropertyIsEmpty(data) {
        console.log(data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems.length);
        await assert.assertEqual(0, data.lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems.length, 'Scheduled Personal property was added');
    }
    async validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(data){
        var x = await helper.getTextAtLocator(this.personalPropertyAtOtherResidenceLocation);
        var uiLocation = x.toString().replace(/(\r\n|\n|\r)/gm, " ");
        var pcLocation =  data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems[0].location.address.addressLine1+", "+data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems[0].location.address.city+", "+data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems[0].location.address.postalCode+", "+data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems[0].location.address.state;
        await assert.assertEqual(uiLocation,pcLocation,'Address does not match');
        var limit = data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems[0].itemData.LimitId.typeCodeValue+'%';
        await assert.assertEqual(this.personalPropertyAtOtherResidenceLimit.innerText,limit,'Increased Limit Does not match');
    }
    async checkPersonalPropertyAtOtherResidencesIsEmpty(data){
        await assert.assertEqual(0,data.lobData.homeowners.offerings[0].coverages.schedules[3].scheduleItems.length , 'Personal property at other residences was added');
    }
    async validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(data){
        var location = await this.specificStructuresAtOtherResidenceLocation.innerText;
        var uiLocation = location.replace(/(\r\n|\n|\r)/gm, "");
        console.log(uiLocation);
        var pcLocation =  data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].location.address.addressLine1+", "+data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].location.address.city+", "+data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].location.address.postalCode+", "+data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].location.address.state;
        console.log(pcLocation);
        await assert.assertEqual(uiLocation,pcLocation,'Address does not match');
        await assert.assertEqual(await this.specificStructuresAtOtherResidenceDesc.innerText,data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].itemData.SchedItemDescriptionId.stringValue,'Description does not match');
        var limit = data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems[0].itemData.LimitId.typeCodeValue+'%';
        await assert.assertEqual(await this.specificStructuresAtOtherResidenceLimit.innerText,limit,'Increased Limit Does not match');
    }
    async checkSpecificStructuresAtOtherResidencesIsEmpty(data){
        await assert.assertEqual(0,data.lobData.homeowners.offerings[0].coverages.schedules[4].scheduleItems.length, 'Personal property at other residences was added');
    }
    async getBasicUICoverageData() {
    
            var coverageTest = ClientFunction(() => {
                var items = document.querySelectorAll("[id*='ClauseTerm'][data-read-only='true']");
                var itemsValues = [];
                for (var item of items)
                    itemsValues.push(item.textContent);
                return itemsValues;
            });
            return coverageTest;
    }
    async compareBasicInformation(data){
        await helper.click(this.infoSection);
        await assert.assertEqual(await helper.getTextAtLocator(this.accountFirstName),data.accountFirstName,'First name Does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.accountLastName),data.accountLastName,'Last name Does not match');
    }
    async compareAddress(data){
        await helper.click(this.houseSection);
        await assert.assertEqual(await helper.getTextAtLocator(this.accountAddressLine1),data.AddressLine1,'Address Line 1 does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.accountAddressLine2),data.AddressLine2,'Address Line 2 does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.accountAddressLine3),data.AddressLine3,'Address Line 3 does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.accountCity),data.city,'City does not match');
        await assert.assertEqual(await helper.getTextAtLocator(this.accountZip),data.zipCode,'Postal code does not match');
    }
}

        