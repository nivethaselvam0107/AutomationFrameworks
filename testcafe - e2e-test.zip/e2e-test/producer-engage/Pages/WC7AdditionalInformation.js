import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common = new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WC7AdditionalInformation{
    constructor() {
        this.phoneNumber = Selector("input[id='addressPhone']");
        this.email = Selector("input[id='addressEmail']");
        this.ncciIntrastateID1  = Selector("input[id*='stateID']").nth(0);
        this.stateTaxID = Selector("input[id*='stateID']").nth(1);
        this.bureauID  = Selector("input[id*='stateID']").nth(2);
        this.ncciIntrastateID2  = Selector("input[id*='stateID']").nth(3);
        this.additionalClassAccordion = Selector("[id*='additionalAccordionDetails'][class='additionalAccordionBody'] i");
        this.finalQuote = Selector("#gw-wizard-Next");
        this.employeeClass1 = Selector("tr[class*='Table-module']").nth(1).find('td').nth(1);
        this.annualWages1 = Selector("tr[class*='Table-module']").nth(1).find('td').nth(2);
        this.employeeClass2 = Selector("tr[class*='Table-module']").nth(2).find('td').nth(1);
        this.annualWages2 = Selector("tr[class*='Table-module']").nth(2).find('td').nth(2);
    }
    async typePhoneNumber(phoneNumber){
        await helper.removeText(this.phoneNumber)
        await helper.typeText(this.phoneNumber,phoneNumber);
    }
    async typeEmail(email){
        await helper.removeText(this.email);
        await helper.typeText(this.email,email);
    }
    async typeStateTaxID(taxID){
        await helper.typeText(this.stateTaxID,taxID);
    }
    async typeBureauID(bureauID){
        await helper.typeText(this.bureauID,bureauID);
    }
    async setFinalQuote(data){
        await this.typePhoneNumber(data.PhoneNumber);
        await this.typeEmail(data.Email);
        await this.typeStateTaxID(data.StateTaxID);
        await this.typeBureauID(data.BureauID);
    }
    async setNCCIIntrastateID(data){
        await helper.typeText(this.ncciIntrastateID1,data);
        await helper.typeText(this.ncciIntrastateID2,data);
    }
    async clickFinalQuote(){
        await helper.click(this.finalQuote);
    }
}