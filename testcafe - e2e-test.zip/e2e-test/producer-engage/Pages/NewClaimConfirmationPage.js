import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";

const helper = new Helper();
const assert = new Assertion();

export default class NewClaimConfirmationPage {
    constructor() {
        this.backToHomeButton = Selector("#callButtonID");
        this.claimNumber = Selector("#claimReferenceNumber");
        this.homeButton = Selector("i[class*='fa-home']");
    }

    async goToPolicySummaryPage() {
        await helper.click(this.backToHomeButton);
    }
    async goToDashboard() {
        await helper.click(this.homeButton);
    }
    async getClaimNumber() {
        var number = await helper.getTextAtLocator(this.claimNumber);
        var claimNumber = await number.replace('Claim reference number', '');
        return claimNumber.trim();
    }
    async goToAccountSummaryPage() {
        await helper.click(this.backToHomeButton);
   }

   async validateReferenceNumberFormat(){
       var referenceNumber = await this.getClaimNumber();
       if(referenceNumber.match("\\d{3}-\\d{2}-\\d{6}"))
       return true;
       else
       return false;
    }
}
