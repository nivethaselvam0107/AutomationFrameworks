import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertion();
var value1;
const currentlyLicensedStatus = "[id='CurrentSuspense'] button[data-value='" + value1 + "']";
const coverageDeclined = "[id='PriorDeclinedPolicy'] button[data-value='" + value1 + "']";

export default class QualificationPage {
    constructor() {

        
        this.currentSuspense_Yes = Selector("[id='CurrentSuspense'] [data-value='true']");
        this.currentSuspense_No = Selector("[id='CurrentSuspense'] [data-value='false']");
        this.isLicenseCancelledAnyTime_Yes = Selector("[id='Suspense'] [data-value='true']");
        this.isLicenseCancelledAnyTime_No = Selector("[id='Suspense'] [data-value='false']");
        this.traffic_Violations_Yes = Selector("[id='MovingViolations2'] [data-value='true']");
        this.traffic_Violations_No = Selector("[id='MovingViolations2'] [data-value='false']");
        this.isPolicyDeclinedHistory_Yes = Selector("[id='PriorDeclinedPolicy'] [data-value='true']");
        this.isPolicyDeclinedHistory_No = Selector("[id='PriorDeclinedPolicy'] [data-value='false']");
        this.personButton = Selector("button[data-value='Person']");
        this.nextButton = Selector("[id='gw-wizard-Next']");
        this.firstNameInsurerLabel = Selector("label[id*='wc7AdditionalInsuredPersonFirstName']");
        this.lastNameInsurerLabel = Selector("label[id*='wc7AdditionalInsuredPersonLastName']");
        this.countryInsurerLabel = Selector("label[id*='wc7AdditionalInsuredCountry']");
        this.addressInsurerLabel = Selector("label[id*='wc7AdditionalInsuredAddressLine1']");
        this.cityInsurerLabel = Selector("label[id*='wc7AdditionalInsuredCity']");
        this.stateInsurerLabel = Selector("label[id*='wc7AdditionalInsuredState']");
        this.zipCodeInsurerLabel = Selector("label[id*='wc7AdditionalInsuredZipCode']");
        this.addressTypeInsurerLabel = Selector("label[id*='wc7AdditionalInsuredAddressType']");
        this.addNameInsuredButton = Selector("#wc7AddNameInsured");
        this.haveADogNo = Selector("[id='HOPPreQualDog'] [data-value='false']");
        this.haveADogYes = Selector("[id='HOPPreQualDog'] [data-value='true']");
        this.vacant_No = Selector("[id='HOPPreQualPropVacant'] [data-value='false']]");
        this.vacant_Yes = Selector("[id='HOPPreQualPropVacant'] [data-value='true']");
        this.account = Selector("[class*='WizardPageHeader_gwWizardPageAssociated']");
        this.currently_insured_select = Selector("[id='PACurrentlyInsured']");
        this.currently_insured_option = Selector("[id='PACurrentlyInsured'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.occupies_Dwelling_Select = Selector("[id='HOPPreQualOccupant']");
        this.occupies_Dwelling_Option =Selector("[id='HOPPreQualOccupant'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.dwelling_Full_Time_No = Selector("[id='HOPPreQualOccupyFullTime'] [data-value='false']");
        this.dwelling_Full_Time_Yes = Selector("[id='HOPPreQualOccupyFullTime'] [data-value='true']");
        this.occupy_dwelling_Full_Time_Yes = Selector("[id='HOPPreQualOccupyFullTime'] [data-value='true']");
        this.has_Swimming_Pool_No = Selector("[id='HOPPreQualSwimmingPool'] [data-value='false']");
        this.has_Swimming_Pool_Yes = Selector("[id='HOPPreQualSwimmingPool'] [data-value='true']");
        this.any_Coverage_Declined_No = Selector("[id='HOCovDeclined_HOE'] [data-value='false']");
        this.any_Coverage_Declined_Yes = Selector("[id='HOCovDeclined_HOE'] [data-value='true']");
        this.any_Business_Conducted_No = Selector("[id='HOBusiness_HOE'] [data-value='false']");
        this.any_Business_Conducted_Yes= Selector("[id='HOBusiness_HOE'] [data-value='true']");


    }

    async selectCurrentlyInsured(option) {
        await helper.selectDropdown(this.currently_insured_select, this.currently_insured_option, option);
    }

    async validateAccountName(name) {
        await assert.assertEqual(this.account.innerText, name, 'Account name mismatch');

    }
    async setPAQualificationPageDetails(data) {
        await this.selectCurrentlyInsured(data.InsuranceStatus);
    }
    async arePAQualificationAnswersSaved(data) {
        console.log(await this.currently_insured_select.innerText);
        await assert.assertEqual(await this.currently_insured_select.innerText, data.InsuranceStatus, 'Current insurance status is not matched');
    }
    async isLicenseStatusCancelledSetAs() {

        if (await this.currentSuspense_Yes.checked) {
            var value = 'true';
            return value;
        }
        else if (await this.currentSuspense_No.checked) {
            var value = 'false';
            return value;
        }
    }
    async isLicenseCancelledAnyTimeSetAs() {
        if (await this.isLicenseCancelledAnyTime_Yes.checked) {
            var value = 'true';
            return value;
        }
        else if (await this.isLicenseCancelledAnyTime_No.checked) {
            var value = 'false';
            return value;
        }


    }
    async isTrafficeViolationHistorySetAs() {
        if (await this.traffic_Violations_Yes.checked) {
            var value = 'true';
            return value;
        }
        else if (await this.traffic_Violations_No.checked) {
            var value = 'false';
            return value;
        }


    }
    async isPolicyDeclinedHistorySetAs() {
        if (await this.isPolicyDeclinedHistory_Yes.checked) {
            var value = 'true';
            return value;
        }
        else if (await this.isPolicyDeclinedHistory_No.checked) {
            var value = 'false';
            return value;
        }

    }

    async propertyOccupiedFulltime() {
        await helper.click(this.occupy_dwelling_Full_Time_Yes);
    }
    async setQualificationPageDetails(option) {
        await helper.selectDropdown(this.occupies_Dwelling_Select, this.occupies_Dwelling_Option, option);
        await this.propertyOccupiedFulltime();
    }
    async setQualificationPageDetailsHOFerrite() {
        await helper.click(this.any_Coverage_Declined_No);
        await helper.click(this.any_Business_Conducted_No);
    }
    async setCurrentLicenseStatusCanceled(value) {
        var status = currentlyLicensedStatus.replace(value1, value);
        await helper.click(Selector(status));
    }
    async setPolicyDeclinedStatus(val) {
        var status1 = coverageDeclined.replace(value1, val);
        await helper.click(Selector(status1));
    }
    async areHOQualificationAnswersSaved(data) {
        await assert.assertAttributeValue('#HOPPreQualDog > [class*="ToggleField-module__active"]','data-value','false','Incorrect value selected for Do you have a dog');
        await assert.assertAttributeValue('#HOPPreQualPropVacant > [class*="ToggleField-module__active"]', 'data-value','false','Incorrect value selected for Is this property vacant');
        await assert.assertEqual(await helper.getTextAtLocator(this.occupies_Dwelling_Select), data.OccupiesDwelling, 'PropertyOccupier value is not matched');
        await assert.assertAttributeValue('#HOPPreQualOccupyFullTime > [class*="ToggleField-module__active"]','data-value', data.DwellingFullime,'Incorrect value selected for Do you occupy this dwelling full time');
        await assert.assertAttributeValue( '#HOPPreQualSwimmingPool > [class*="ToggleField-module__active"]','data-value','false','Incorrect value selected for Do you occupy this dwelling full time');
    }
    async areHOQualificationAnswersSavedHO() {
        await assert.assertAttributeValue('#HOCovDeclined_HOE > [class*="ToggleField-module__active"]','data-value','false','Incorrect value selected for Any coverage declined, cancelled or non-renewed in past 5 years');
        await assert.assertAttributeValue('#HOBusiness_HOE > [class*="ToggleField-module__active"]', 'data-value','false','Incorrect value selected for Any business conducted on the premises');
    }
    async clickAddNameInsured() {
        await helper.click(this.addNameInsuredButton);
    }
    async validateMandatoryFieldsInAddInsurer(){
        await assert.hasClass(this.personButton,'active');
        await assert.isElementNotClickable(this.nextButton,'disabled','Next Button is enabled');
        await assert.textNotContains(await helper.getTextAtLocator(this.firstNameInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.lastNameInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.countryInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.stateInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.addressInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.cityInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.zipCodeInsurerLabel),'(optional)','First Name should be a mandatory field ');
        await assert.textNotContains(await helper.getTextAtLocator(this.addressTypeInsurerLabel),'(optional)','First Name should be a mandatory field ');
    }
    async clickNext(){
        await helper.click(this.nextButton);
    }












}