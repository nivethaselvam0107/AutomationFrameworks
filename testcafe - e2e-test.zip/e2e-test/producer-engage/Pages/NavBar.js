import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertions from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertions();
export default class NavBar {
    constructor() { 
        this.startNewQuote = Selector("button[id='startNewQuoteBtn']");  
        this.accountTab = Selector("[class*='MenuBarComponent'] [href*='accounts']");  
        this.policiesTab = Selector("[class*='MenuBarComponent'] [href*='policies']");  
        this.claimTab = Selector("[class*='MenuBarComponent'] [href*='claims']");   
        this.analytics = Selector("[class*='MenuBarComponent'] [href*='analytics']");  
        this.quoteForAnyAccount = Selector("#startNewQuote");
        this.quoteForThisAccount = Selector("#startNewQuote");
        this.goDashboard = Selector("[class*='fas fa-home MenuBar']");
        this.activitiesTab = Selector("[class*='MenuBarComponent'] [href*='activities']");  
        this.searchInputBox = Selector("input[id='headerSearchBox']");  
        this.searchButton = Selector("i[class*='fa-search']");  
        this.clickAccount = Selector("[id*='accountNumberLink']");
        this.clickPolicy = Selector("[id*='policyNumberLink'] div");
        this.faq = Selector("a[id='faq']");
    }

    async navigateToPolicy() {
        await helper.click(this.clickPolicy);
    }
    async clickStartNewQuote() {
        await helper.click(this.startNewQuote);
    }
    async goToAccountsLanding() {
        await helper.click(this.accountTab);
    }
    async goToPoliciesLanding() {
        await helper.click(this.policiesTab);
        await t.wait(5000);
    }
    async goToClaimsLanding() {
        await helper.click(this.claimTab);
    }
    async goToActivitiesLanding() {
        await helper.click(this.activitiesTab);
    }
    async isAccountsLandingSelected() {
        await assert.hasClass(this.accountTab, 'active');
    }
    async goToAnalyticsLanding() {
        await helper.click(this.analytics);
    }
    async isActivitiesLandingSelected() {
        await assert.hasClass(this.activitiesTab, 'active')
    }
    async startQuoteForAnyAccount() {
        await helper.click(this.quoteForAnyAccount);
    }
    async startQuoteForThisAccount() {
        await helper.click(this.quoteForThisAccount);
    }
    async goToDashboard() {
        await helper.click(this.goDashboard);
        await t.wait(5000);
    }
    async clickFaq(){
        await helper.click(this.faq);
    }
}