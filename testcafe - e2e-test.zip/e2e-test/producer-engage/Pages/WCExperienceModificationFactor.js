import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import Modal from "../../Utilities/WidgetComponents/Modal";
import CommonLocators from "../../Utilities/CommonLocators";
const common=new CommonLocators();
const helper = new Helper();
const assert = new Assertion();
const modal = new Modal();

export default class WCExperienceModificationFactor {
  constructor() {
    this.updateButton = Selector("[id*='expModUpdate']");
    this.expModFactorInput = Selector("input[id*='expModFactor']");
    this.expModFactorLabel = Selector("label[id*='expModFactor']");
    this.emodTitle = Selector("[id*='wc7AdditionalInsuredTitleContainer']");

  }
  async validateMandatoryFieldExperienceModFactor(){ 
      await common.validateNextButtonIsDisabled();
      await this.clickUpdate();
      await common.validateNextButtonIsEnabled();
      await assert.textNotContains(await helper.getTextAtLocator(this.expModFactorLabel),'(optional)','State should be mandatory field');
      }
  async removeExperienceModificationFactor(){
      await helper.removeText(this.expModFactorInput);
  }
  async validateUpdateButtonDisabled(){
      await assert.isElementNotClickable(this.updateButton,'disabled','Update Button is enabled');
  }
  async validateMultipleEmodIsDisplayed(data){
    await assert.elementPresent(this.emodTitle.nth(1),'Experience Modification Factor (EMOD) and State Coverages of '+data.State+' is not dislayed');
    await assert.assertEqual(await helper.getTextAtLocator(this.emodTitle.nth(1)),'Experience Modification Factor (EMOD) and State Coverages: '+data.State,data.State+' Title is incorrect');
    await assert.assertEqual(await helper.getTextAtLocator(this.emodTitle.nth(0)),'Experience Modification Factor (EMOD) and State Coverages: California','California Title is incorrect');
  }
  async clickUpdate(){
      await helper.click(this.updateButton);
  }
  
}