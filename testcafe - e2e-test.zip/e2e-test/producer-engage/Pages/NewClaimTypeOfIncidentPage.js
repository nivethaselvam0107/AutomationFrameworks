import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
const helper = new Helper();
export default class NewClaimTypeOfIncidentPage {
    constructor() {
        this.glass = Selector("[for='incidentTypeRadioButton_glassbreakage']");   
        this.collision = Selector("[for='incidentTypeRadioButton_vehcollision']");   
        this.theft = Selector("[for='incidentTypeRadioButton_theftentire']");   
        this.fire = Selector("[for='lossCauseRadioButton_fire']");   
        this.water = Selector("[for='lossCauseRadioButton_waterdamage']");   
        this.crime = Selector("[for='lossCauseRadioButton_burglary']");   
        this.other = Selector("[for='lossCauseRadioButton_miscellaneous']");   
        this.PAother = Selector("[for='incidentTypeRadioButton_otherobjcoll']")   
        this.injuryCauseSelect = Selector("[id='whatInjuryCauseSource']");
        this.injuryCauseOption = Selector("[id='whatInjuryCauseSource'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.lossCauseSelect = Selector("[id='lossCause']");   
        this.lossCauseOption = Selector("[id='lossCause'] div[class*='TypeaheadMultiSelectField__menu'] div");   
        this.lossDescriptionTextArea = Selector("[id='indicateWho']");   
        this.causeOfIncidentTextArea = Selector("[id='whatDetailCauseOfIncident']");
        this.damageDescriptionTexrArea = Selector("[id='damageList']");   
        this.dateEmployerNoted = Selector("[id='dateEmployerNotified']");
        this.firstName = Selector("[id='whatFirstName']");
        this.lastName = Selector("[id='whatLastName']");
        this.dateOfBirth = Selector("[id='whatDOB']");
        this.city = Selector("[id='whatCity']");
        this.zipCode = Selector("[id='whatZipCode']");
        this.state = Selector("[id='whatState']");
        this.stateOption = Selector("[id='whatState'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.phoneNumber = Selector("[id='whatPhoneNumber']");
        this.collisionType = Selector("[id='typeOfCollisionOccur']");
        this.collisionTypeOption = Selector("[id='typeOfCollisionOccur'] div[class*='TypeaheadMultiSelectField__menu'] div");
    }
    async selectCollisionClaimType(collisionType){
        await helper.selectDropdown(this.collisionType,this.collisionTypeOption,collisionType);
    }
    async selectPAClaimType(claimSubType) {
        if (claimSubType == "Collision") {
            await helper.click(this.collision);
        } else if (claimSubType == "Theft") {
            await helper.click(this.theft);
        } else if (claimSubType == "Broken Glass") {
            await helper.click(this.glass);
        } else if (claimSubType == "Other") {
            await helper.click(this.PAother);
        }
    }
    async selectHOClaimType(claimSubType) {
        if (claimSubType == "Fire") {
            await helper.click(this.fire);
        } else if (claimSubType == "Water") {
            await helper.click(this.water);
        } else if (claimSubType == "Crime") {
            await helper.click(this.crime);
        } else if (claimSubType == "Other") {
            await helper.click(this.other);
        }
    }

    async selectLossCause(option) {
        await helper.selectDropdown(this.lossCauseSelect,this.lossCauseOption,option);
    }
    async selectInjuryCause(option) {
        await helper.selectDropdown(this.injuryCauseSelect,this.injuryCauseOption,option);
    }
    async selectGeneralClaimType(lossCause) {
        await this.selectLossCause(lossCause);

    }
    async selectWCClaimType(lossCause) {
        await this.selectInjuryCause(lossCause);
    }
    async setLossDesc(text) {
        await helper.typeText(this.lossDescriptionTextArea, text);
    }
    async setCauseOfIncident(text) {
        await helper.typeText(this.causeOfIncidentTextArea, text);
    }
    async setGeneralLossDesc(data) {
        await this.setLossDesc(data);
    }

    async setWCLossDesc(data) {
        await this.setCauseOfIncident(data);
    }
    async setNotificationDateInThePast() {
        Number.prototype.padLeft = function (base, chr) {
            var len = (String(base || 10).length - String(this).length) + 1;
            return len > 0 ? new Array(len).join(chr || '0') + this : this;
        }
        var date = new Date();
        var hours = date.getHours();
        var minutes = date.getMinutes();

        // Check whether AM or PM 
        var newformat = hours >= 12 ? 'PM' : 'AM';

        // Find current hour in AM-PM Format 
        hours = hours % 12;

        // To display "0" as "12" 
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        date.setDate(date.getDate() - 7);
        var dformat = [(date.getMonth() + 1).padLeft(), date.getDate().padLeft(), date.getFullYear()].join('/') + ' ' +
            [hours.padLeft(), minutes].join(':') + ' ' + newformat;
        await helper.typeText(this.dateEmployerNoted, dformat);

    }
    async setGeneralDamageDesc(text) {
        await helper.typeText(this.damageDescriptionTexrArea, text);
    }
    async setInjuredEmployeeName(firstName, lastName) {
        await helper.typeText(this.firstName, firstName);
        await helper.typeText(this.lastName, lastName);

    }
    async setInjuredEmployeeDateOfBirth() {
        var date = new Date();
        var hours = date.getHours();
        var minutes = date.getMinutes();

        // Check whether AM or PM 
        var newformat = hours >= 12 ? 'PM' : 'AM';

        // Find current hour in AM-PM Format 
        hours = hours % 12;

        // To display "0" as "12" 
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        date.setDate(date.getDate() - 7);
        var dformat = [(date.getMonth() + 1).padLeft(), date.getDate().padLeft(), date.getFullYear()].join('/') + ' ' +
            [hours.padLeft(), minutes].join(':') + ' ' + newformat;
        await helper.typeText(this.dateOfBirth,dformat);

    }
    async setInjuredEmployeeAddress(city,zip,state){
        await helper.typeText(this.city,city);
        await helper.typeText(this.zipCode,zip);
        await helper.selectDropdown(this.state,this.stateOption,state);

    }
    async setPhoneNumber(phoneNumber){
        await helper.typeText(this.phoneNumber,phoneNumber);
    }
}