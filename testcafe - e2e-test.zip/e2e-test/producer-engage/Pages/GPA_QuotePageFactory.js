import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Login from "../Login";
import AccountSearch from "./AccountSearch";
import NavBar from "./NavBar";
import CommonLocators from '../../Utilities/CommonLocators';
import QualificationPage from "./QualificationPage";
import PolicyInfoPage from "./PolicyInfoPage";
import DriversPage from "./DriversPage";
import VehiclesPage from "./VehiclesPage";
import PAQuotePage from "./PAQuotePage";
import PaymentDetailsPage from "./PaymentDetailsPage";
import YourHomePage from "./YourHomePage";
import ConstructionPage from "./ConstructionPage";
import DiscountPage from "./DiscountPage";
import HOQuotePage from "./HOQuotePage";
import HOPolicyInfoPage from "./HOPolicyInfoPage";
import HOPaymentDetailsPage from "./HOPaymentDetailsPage";
import AccountCreate from "./AccountCreate";
import QuoteStart from "./QuoteStart";


const helper = new Helper();
const assert = new Assertion();
const login = new Login();
const nav = new NavBar();
const accountSearch = new AccountSearch();
const policyInfo = new PolicyInfoPage();
const paQuote = new PAQuotePage();
const qualiPage = new QualificationPage();
const driversPage = new DriversPage();
const vehicles = new VehiclesPage();
const common = new CommonLocators();
const paymentDetails = new PaymentDetailsPage();
const construction = new ConstructionPage();
const discount = new DiscountPage();
const yourHome = new YourHomePage();
const hoQuote = new HOQuotePage();
const hoPolicyInfo = new HOPolicyInfoPage();
const hoPayment = new HOPaymentDetailsPage();
const data = require("../../producer-engage/Data/PE_PA_Data.json");
const accountCreate = new AccountCreate();
const quoteStart = new QuoteStart();

export default class GPA_QuotePageFactory {
    constructor() {

    }
    async createAndBuyPolicyPA(dataQnB) {
        await qualiPage.setPAQualificationPageDetails(dataQnB.qualificationPage);
        await common.goNext();
        await driversPage.setPrimaryDriverDetails(dataQnB.driversPage);
        await common.goNext();
        await vehicles.setVehicleDetails(dataQnB.vehiclesPage);
        await common.goNext();
        await paQuote.clickBuyNow();
        await common.goNext();
        await policyInfo.setPhoneNumber(dataQnB.policyInformation.PhoneNumber);
        await policyInfo.setEmailAddress(dataQnB.policyInformation.EmailAddress);
        await common.goNext();
        await paymentDetails.setAccountNumber(dataQnB.policyInformation.AccountNumber);
        await paymentDetails.setABARoutingNumber(dataQnB.policyInformation.RoutingNumber);
        await paymentDetails.setBankName(dataQnB.policyInformation.BankName);
        await paymentDetails.goNext();
    }
    async startQuoteForAnyAccount(data) {
        await nav.startQuoteForAnyAccount();
        await accountSearch.searchExistingAccountForPersonal(data);
        await accountSearch.useExistingAccountWithAccountNumber();
    }
    async startGlobalQuoteForExistingAccount() {
        await nav.startQuoteForThisAccount();
    }
    async loginAndStartQuote(data) {
        await login.loginasDiffUser(data.producerCode);
    }
    async clickQuoteBtnAndFindAccount(data) {
        await nav.startQuoteForAnyAccount();
        await accountSearch.searchExistingAccountForPersonal(data);
        await accountSearch.useExistingAccountWithAccountNumber();
    }
    async startQuoteWithExistingAcount(data) {
        await this.loginAndStartQuote(data);
        await this.clickQuoteBtnAndFindAccount(data)
    }
    async createAndBuyPolicyHO(dataQnB) {
        await qualiPage.setQualificationPageDetailsHOFerrite();
        await common.goNext();
        await yourHome.setYourHomePageDetails(dataQnB.HomePageHO);
        await common.goNext();
        await construction.setConstructionPageDetails(dataQnB.ConstructionPage);
        await common.goNext();
        await discount.setHODiscountPageDetails(dataQnB.DiscountPage);
        await common.goNext();
        var quoteID = await hoQuote.getSubmissionNumber();
        await hoQuote.clickBuyNow();
        await common.goNext();
        await hoPolicyInfo.setPhoneNumber(dataQnB.HOPolicyInfoPage.PhoneNumber);
        await hoPolicyInfo.setEmailAddress(dataQnB.HOPolicyInfoPage.EmailAddress);
        await common.goNext();
        await hoPayment.payMonthlyPremiumWithSavingsBankAccount(dataQnB.HOPaymentDetailsPage);
        await hoPayment.purchasePolicy();
    }
    async createAndBuyPAPolicy() {
        await login.login();
        await nav.clickStartNewQuote();
        await accountSearch.accountSearchForPersonal(data.TC3545);
        await accountSearch.clickContinueAsNewcustomer();
        await accountCreate.fillAccountCreate(data.TC3545);
        await accountCreate.fillEmailAddress(data.TC3545);
        await accountCreate.clickNext();
        await quoteStart.fillQuoteDetails(data.TC3545);
        await quoteStart.clickSubmit();
        await qualiPage.setPAQualificationPageDetails(data.TC3545);
        await common.goNext();
        await driversPage.setPrimaryDriverDetails(data.TC3545);
        await common.goNext();
        await vehicles.setVehicleDetails(data.TC3545);
        await common.goNext();
        await paQuote.clickBuyNow();
        await policyInfo.setPhoneNumber(data.TC3545.PhoneNumber);
        await common.goNext();
        await policyInfo.setPhoneNumber(data.TC3545.PhoneNumber);
        await common.goNext();
        await paymentDetails.setPaymentMethod(data.TC3545.PaymentMethod);
        await paymentDetails.setCreditCardNumber();
        await paymentDetails.setExpirationDate();
        await paymentDetails.goNext();
    }
}