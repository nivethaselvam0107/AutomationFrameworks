import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from '../Data/DataFetch';
const fromEntries = require('fromentries')
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();

export default class EndorsementDriversPage {
    constructor() {
        this.newDriverButton = Selector("#addDriver");
        this.removeDriverButton = Selector("[id='paDriverSectionTrashId']").nth(1);
        this.driverSection = Selector("[id*='titleContainer']");
        this.firstName = Selector("#driverFirstName");
        this.firstNameError = Selector("[id*='driverFirstName'][role='alert']");
        this.lastName = Selector("#driverLastName");
        this.lastNameError = Selector("[id*='driverLastName'][role='alert']");
        this.gender = Selector("#driverGender");
        this.genderOption = Selector("[id='driverGender'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.drivers = Selector("");
        this.licenseYear = Selector("#driverYearFirstLicenced");
        this.licenseYearOption = Selector("[id*='driverYearFirstLicenced'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.accidentIncrementButton = Selector("[id='driverNumberOfAccidents']").sibling('button');
        this.violationIncrementButton = Selector("[id='driverNumberOfViolations']").sibling('button');
        this.dateOfBirth = Selector("#driverDateOfBirth");
        this.DOBError = Selector("[id*='driverDateOfBirth'][role='alert']");
        this.licenseNumber = Selector("#driverLicenseNumber");
        this.licenseNumberError = Selector("[id*='driverLicenseNumber'][role='alert']");
        this.licenseState = Selector("#driverLicenceState");
        this.licenseStateOption = Selector("[id='driverLicenceState'] div[class*='TypeaheadMultiSelectField__menu'] div")
        this.deleteBtn = Selector("[id*='paDriverSectionTrashId']");
        this.editBtn = Selector("[id*='paDriverSectionEditId']");
        this.assignedVehicle = Selector("[id*='vehicleAssignment'] [class*='digitalCheckbox CheckboxField-module']");


    }
    async addNewDriver() {
        await helper.click(this.newDriverButton);
    }
    async isDriversPageLoaded() {
        await assert.elementPresent(this.drivers, 'Drivers page is not loaded')
    }
    async withFirstName(FirstName) {
        await helper.typeText(this.firstName, FirstName);
    }
    async withLastName(LastName) {
        await helper.typeText(this.lastName, LastName);
    }
    async withGender(gender) {
        await helper.selectDropdown(this.gender, this.genderOption, gender);
    }
    async withYearLicensed(licenseYear) {
        await helper.selectDropdown(this.licenseYear, this.licenseYearOption, licenseYear);
    }
    async selectVehicleCheckBox() {
        await helper.click(this.assignedVehicle);
    }

    async setNoOfAccidents(accidents) {
        var Num = accidents;
        for (var i = 0; i < Num; i++) {
            await helper.click(this.accidentIncrementButton);
        }
    }
    async setNoOfViolations(violations) {
        var Num = violations;
        for (var i = 0; i < Num; i++) {
            await helper.click(this.violationIncrementButton);
        }
    }
    async withDOB(dateOfBirth) {
        await helper.typeText(this.dateOfBirth, dateOfBirth);
        await helper.pressTab();
    }
    async withLicenseNumber(licenseNum) {
        await helper.typeText(this.licenseNumber, licenseNum);
    }
    async withLicenseState(licenseState) {
        await helper.selectDropdown(this.licenseState, this.licenseStateOption, licenseState);
    }
    async clickOnFirstEdit() {
        await helper.click(this.editBtn.nth(0));
    }
    async editDriversData(data) {
        await this.withLicenseNumber(data.LicenseNumber);
        await this.setNoOfAccidents(data.Accidents);
        await this.setNoOfViolations(data.Violations);
    }
    async getEditDriverUIdetails() {
        let data = new Map();
        data.set("FirstName", await helper.getValueAttributeFromLocator(this.firstName));
        data.set("LastName", await helper.getValueAttributeFromLocator(this.lastName));
        data.set("YearLicensed", await helper.getTextAtLocator(this.licenseYear));
        let obj = fromEntries(data);
        return obj;


    }

    async editFirstDriverDetails(data) {
        await this.clickOnFirstEdit();
        await this.editDriversData(data);
    }
    async validateMandatoryErrorMessageInDriverPage() {
        await helper.removeRequiredTextAndValidate(this.firstName, this.firstNameError);
        await helper.removeRequiredTextAndValidate(this.lastName, this.lastNameError);
        await helper.removeRequiredTextAndValidate(this.dateOfBirth, this.DOBError);
        await helper.removeRequiredTextAndValidate(this.licenseNumber, this.licenseNumberError);
    }

    async setDriverPage(formData) {
        await this.withFirstName(formData.FirstName);
        await this.withLastName(formData.LastName);
        await this.withGender(formData.Gender);
        await this.withYearLicensed(formData.YearLicensed);
        await this.withDOB(formData.DOB);
        await this.withLicenseNumber(formData.LicenseNumber);
        await this.withLicenseState(formData.LicenseState);
        await this.selectVehicleCheckBox();
    }
    async isRemoveButtonDisabled() {
        await assert.isElementNotClickable(this.deleteBtn, 'disabled', 'Delete button is enabled');
    }
    async clickRemoveDriver(name) {
        var count = await this.driverSection.count;
        for (let i = 0; i < count; i++) {
            if (await helper.getTextAtLocator(this.driverSection)!= name) {
                await helper.click(this.driverSection.find("button[id*='paDriverSectionTrashId']"));
            }
        }
    }
    async isAddedDriverPresent(title) {
        addedDriver = title.FirstName + " " + title.LastName;
        assert.assertEqual(await helper.getTextAtLocator(this.addedDriverTitle), addedDriver, 'Added Driver is not displayed');
    }

    async isDriverAvailableInPolicyFromBackEnd(data, policy) {
        var content = await dataFetch.getPolicyChangeData(policy);
        var drivers = 'lobData.personalAuto.coverables.drivers';
        var count = content.lobData.personalAuto.coverables.drivers.length;
        var covFlag = false;
        for (var i = 0; i < count; i++) {
            var driverNameFromUI = data.FirstName + " " + data.LastName;
            if (content.lobData.personalAuto.coverables.drivers[i].displayName == driverNameFromUI) {
                await assert.assertEqual(content.lobData.personalAuto.coverables.drivers[i].person.firstName, data.FirstName, 'First name is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.drivers[i].person.lastName, data.LastName, 'Last name is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.drivers[i].yearLicensed).toString(), (data.YearLicensed).toString(), 'License year is not matched');
                var month = content.lobData.personalAuto.coverables.drivers[i].dateOfBirth.month;
                var day = content.lobData.personalAuto.coverables.drivers[i].dateOfBirth.day;
                var year = content.lobData.personalAuto.coverables.drivers[i].dateOfBirth.year;
                var dob = (parseInt(month) + 1) + "/" + day + "/" + year;
                await assert.assertEqual(dob, data.DOB, 'Date of Birth is not matched');
                covFlag = true;

            }
        }
        return covFlag;
    }

    async isEditedDriverAvailableInPolicyFromBackEnd(dataUI, data, policy) {
        var content = await dataFetch.getPolicyChangeData(policy);
        var drivers = content.lobData.personalAuto.coverables.drivers;
        var count = content.lobData.personalAuto.coverables.drivers.length;
        var covFlag = false;
        for (var i = 0; i < count; i++) {
            var driver = content.lobData.personalAuto.coverables.drivers[i];
            var driverName = content.lobData.personalAuto.coverables.drivers[i].person;
            var driverNameFromUI = dataUI.FirstName + " " + dataUI.LastName;
            if (content.lobData.personalAuto.coverables.drivers[i].displayName == driverNameFromUI) {
                await assert.assertEqual(content.lobData.personalAuto.coverables.drivers[i].person.firstName, dataUI.FirstName, 'First name is not matched');
                await assert.assertEqual(content.lobData.personalAuto.coverables.drivers[i].person.lastName, dataUI.LastName, 'Last name is not matched');
                await assert.assertEqual((content.lobData.personalAuto.coverables.drivers[i].yearLicensed).toString(), (dataUI.YearLicensed).toString(), 'License year is not matched');
                covFlag = true;

            }
        }
        return covFlag;
    }

}