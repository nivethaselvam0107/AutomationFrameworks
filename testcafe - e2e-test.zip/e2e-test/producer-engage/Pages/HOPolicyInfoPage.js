import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();

export default class HOPolicyInfoPage {
    constructor() {
        this.email_Address=Selector("input[id='email']");
        this.phone_Number=Selector("input[id*='phone']");
        this.emailError =   Selector("div[id*='email'][role='alert']")
        this.phone_error =  Selector("div[id*='phone'][role='alert']")
     
    }
    async setEmailAddress(email){
        await helper.removeText(this.email_Address);
        await helper.typeText(this.email_Address,email);
    }
    async setPhoneNumber(phonenumber){
        await helper.removeText(this.phone_Number);
        await helper.typeText(this.phone_Number,phonenumber);
    }
    async setEmailasEmpty() {
        await helper.removeText(this.email_Address);
        await helper.pressTab();
    } 
    async setPhoneNumberasEmpty() {
        await helper.removeText(this.phone_Number);
        await helper.pressTab();
    }
    async validateMandatoryErrorMsg(){
        await helper.removeRequiredTextAndValidate(this.phone_Number,this.phone_error);
    }

async setPolicyInfoPageDetails(dataHO){
    await this.setEmailAddress(dataHO.EmailAddress);
    await this.setPhoneNumber(dataHO.PhoneNumber);
}

async isEmailSaved(data){
await assert.assertEqual(await helper.getValueAttributeFromLocator(this.email_Address),data.EmailAddress,'Email Address is not saved');

}
async isPhoneSaved(data){
await assert.assertEqual(await helper.getValueAttributeFromLocator(this.phone_Number), data.PhoneNumber,'Phone number is not saved');
}

}