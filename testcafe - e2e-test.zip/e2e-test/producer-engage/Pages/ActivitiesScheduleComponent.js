import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import ActivitiesLanding from '../Pages/ActivitiesLanding';
import Login from '../Login';


const helper = new Helper();
const assert = new Assertion();
const login = new Login();

var accountNumber;
var accountNumberLink = "[href*='/accounts/" + accountNumber + "/summary']";
var accountName;
var accountNameLink = "[title='"+accountName+"']";



export default class ActivitiesScheduleComponent {
    constructor() {
        this.activitiesScheduleComponent = Selector("[class*='Activities_gwRowLayout']");
        this.activitySummary = Selector("[class*='DataTable-module__expandableRowWrapper']");
        this.activityFilter = Selector("div[id='LOBFilter']");
        this.activityFilterOption = Selector("div[id='LOBFilter'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.activitysearch = Selector("input[id='searchFilter']");
        this.activitybutton = Selector("button[id='addActivityButton']");
    }

    async isActivityScheduleComponentPresent() {
        await assert.elementPresent(this.activitiesScheduleComponent, 'Activity schedule components are not dislayed');
    }

    async completeActivity(name) {
        var account = accountNameLink.replace(accountName, name);
        var completeButton = Selector(account).parent(2).find("div[class*='rt-td DataTable-module__tableCell").nth(6).find("button i[class*='fas fa-check']");
        await helper.click(completeButton);
    }

    async setActivityFilter(filterOption){
        await helper.selectDropdown(this.activityFilter,this.activityFilterOption,filterOption)

    }
    async doesActivityStatusShowCompleted(name, expectedStatus) {
        var account = accountNameLink.replace(accountName, name);
        var status = Selector(account).parent(2).find("i[class*='fas fa-check");
        var actualStatus = await helper.getTextAtLocator(status);
        await assert.assertEqual(actualStatus.trim(), expectedStatus, 'Activity status is not displayed as completed');
    }
    async clickOnCorrespondingActivityUserOwns(name) {
        var account = accountNameLink.replace(accountName, name);
        var activity = Selector(account).parent(2).find("div").nth(1);
        await helper.click(activity);
    }
    

    async  openReassignActivityDropdown(name) {
        var account = accountNameLink.replace(accountName, name);
        var hoverOnAssignedUser = Selector(account).parent(2).find("[id='activityReassignContainer']");
        await helper.hover(hoverOnAssignedUser);
        var reassignActivityButton = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='reassignActivityWrapper']").find("div[id='editAssignedName'] button i[class*='fas fa-pencil']");
        await helper.click(reassignActivityButton);
    }

    async setAssigneeByName(assigneeName, name) {
        var account =accountNameLink.replace(accountName, name);
        var activityAssigneeDropdown = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='selectUserContainer']").find("div[id='assignableUserList']");
        var activityAssigneeOption = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='selectUserContainer']").find("div[id='assignableUserList']").find("div[class*='TypeaheadMultiSelectField__menu'] div");
        await helper.selectDropdown(activityAssigneeDropdown,activityAssigneeOption,assigneeName);
    }

    async clickConfirmButton(name) { 
        var account =accountNameLink.replace(accountName, name);
        var reassignActivityConfirmButton = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='selectUserContainer']").find("[id='reassignConfirmationButtonClose']  button i[class*='fas fa-check']");
        await helper.click(reassignActivityConfirmButton);
    }

    async clickCancelButton(name){
        var account =accountNameLink.replace(accountName, name);
        var reassignActivityCancelButton =Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='selectUserContainer']").find("[id='reassignConfirmationButtonCheck']  button i[class*='fas fa-close']");
        await helper.click(reassignActivityCancelButton);
    }

    async isNotAssignedToCurrentUser(name){
        const uname = await login.setUserForGPA();
        var assignee;
        if (uname == 'carkle') {
            assignee = 'Charles Arkle';
        } else if (uname == 'aarmstrong') {
            assignee = 'aarmstrong';
        }
        var account = accountNameLink.replace(accountName, name);
        var reassignedTo = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='reassignActivityWrapper']").find("div[id='assignedName']");
        await assert.assertNotEqual(await helper.getTextAtLocator(reassignedTo),assignee,'Activity is still assigned to current user');
        
    }

    async  isAssignedToCurrentUser(name){
        const uname = await login.setUserForGPA();
        var assignee;
        if (uname == 'carkle') {
            assignee = 'Charles Arkle';
        } else if (uname == 'aarmstrong') {
            assignee = 'aarmstrong';
        }
        var account = accountNameLink.replace(accountName, name);
        var assignedTo = Selector(account).parent(2).find("[id='activityReassignContainer']").find("div[id='reassignActivityWrapper']").find("div[id='assignedName']");
        await assert.assertEqual(await helper.getTextAtLocator(assignedTo),assignee,'Activity is not assigned to current user');
     }
     async validateAllActivityScheduleUIComponents(){
        await this.validateActivityScheduleUIComponant();
        await this.validateActivityFilterValues();
    }
    async validateActivityScheduleUIComponant() {
    
        await assert.elementPresent(this.activityfilter, 'Activity filter is not present on UI');
        await assert.elementPresent(this.activitysearch, 'Activity search is not present on UI');
        await assert.elementPresent(this.activitybutton, 'Add Activity button is not present on UI');

    }


     async canViewActivitySummary(){
        await assert.elementPresent(this.activitySummary,'Activity Summary is not displayed');
     }

}