import { Selector, t, ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from '../Pages/Tiles';
import ClaimSummaryPage from '../Pages/ClaimSummaryPage';
import ClaimSummaryDocumentsTab from './ClaimSummaryDocumentsTab';
import NavBar from './NavBar';
const data = require('../Data/PE_PA_Data.json');
const helper = new Helper();
const assert = new Assertion();
const tiles = new Tiles();
const claimSummaryPage = new ClaimSummaryPage();
const documentTab = new ClaimSummaryDocumentsTab();
const navBar = new NavBar();
var cNum;
var claimNum = "a[href*='claims/" + cNum + "']";
export default class ClaimsTileView {
    constructor() {
        this.fileAClaimbutton = Selector("button[id='fileClaimButton']"); 
        this.fileAClaimAccount = Selector("button[id='fileClaimButton']");
        this.searchClaim = Selector("[id='searchFilter']");
        this.productFilter = Selector("[id='LOBFilter']");
        this.productFilterOption = Selector("[id='LOBFilter'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.productTypeHeader = Selector("[class*='digitalRow Table'] th:nth-child(1)");
        this.claimNumberHeader = Selector("[class*='digitalRow Table'] th:nth-child(2)");
        this.lossDateHeader = Selector("[class*='digitalRow Table'] th:nth-child(3)");
        this.claimStatusHeader = Selector("[class*='digitalRow Table'] th:nth-child(4)");
        this.claimPaidHeader = Selector("[class*='digitalRow Table'] th:nth-child(5)");
        this.claimNetIncurredHeader = Selector("[class*='digitalRow Table'] th:nth-child(6)");
        this.claimPolicyHeader = Selector("[class*='digitalRow Table'] th:nth-child(7)");
        this.policyClaimNumberHeader = Selector("[class*='digitalRow Table'] th:nth-child(1)");
        this.policyLossDateHeader = Selector("[class*='digitalRow Table'] th:nth-child(2)");
        this.policyClaimStatusHeader = Selector("[class*='digitalRow Table'] th:nth-child(3)");
        this.policyClaimPaidHeader = Selector("[class*='digitalRow Table'] th:nth-child(4)");
        this.policyClaimNetIncurredHeader = Selector("[class*='digitalRow Table'] th:nth-child(5)");
        this.uploadDoc = Selector("input[id='uploadDocumentsId']");
        this.claims = Selector("#callButtonID");
        this.fileUploaded=Selector("[class*='rt-td DataTable-module__tableCell']").nth(0);

    }
    async fileAClaimPolicy() {
        await helper.click(this.fileAClaimbutton);
    }
    async clickfileAClaimAccount() {
        await helper.click(this.fileAClaimAccount);
    }
    async validateClaimTileViewUIElements() {

        if (await navBar.isAccountsLandingSelected()) {
            await assert.elementPresent(this.productFilter, 'Product filter dropdown is not present');
            var defaultDropValue = await helper.getTextAtLocator(this.productFilter);
            await assert.assertEqual(await helper.getTextAtLocator(this.claimPolicyHeader), 'POLICY NUMBER', 'policy number header text is not matched');
            await assert.assertEqual(defaultDropValue, 'Filters', 'Default value at LOB dropdownlist is incorrect');
            await assert.assertEqual(await helper.getTextAtLocator(this.productTypeHeader), 'PRODUCT', 'product header text is not matched');
        }
        await assert.elementPresent(this.fileAClaimbutton, 'File a claim button is not present');
        await assert.elementPresent(this.searchClaim, 'Search claim textbox is not present');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimNumberHeader)).replace(/[\n\r\t]/g,''), 'CLAIM NUMBER', 'Claim number header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.lossDateHeader)).replace(/[\n\r\t]/g,''), 'DATE OF LOSS', 'Claim loss date header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimStatusHeader)).replace(/[\n\r\t]/g,''), 'STATUS', 'Claim status header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimPaidHeader)).replace(/[\n\r\t]/g,''), 'PAID', 'Claim paid header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimNetIncurredHeader)).replace(/[\n\r\t]/g,''), 'NET INCURRED', 'Claim net incurred header text is not matched');

    }
    async validateClaimTileViewUI() {
        await assert.elementPresent(this.fileAClaimbutton, 'File a claim button is not present');
        await assert.elementPresent(this.searchClaim, 'Search claim textbox is not present');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimNumberHeader)).replace(/[\n\r\t]/g,''), 'CLAIM NUMBER', 'Claim number header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.lossDateHeader)).replace(/[\n\r\t]/g,''), 'DATE OF LOSS', 'Claim loss date header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimStatusHeader)).replace(/[\n\r\t]/g,''), 'STATUS', 'Claim status header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimPaidHeader)).replace(/[\n\r\t]/g,''), 'PAID', 'Claim paid header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.claimNetIncurredHeader)).replace(/[\n\r\t]/g,''), 'NET INCURRED', 'Claim net incurred header text is not matched');
    }
    async validateClaimTileViewUIInPolicy() {
        await assert.elementPresent(this.fileAClaimbutton, 'File a claim button is not present');
        await assert.elementPresent(this.searchClaim, 'Search claim textbox is not present');
        await assert.assertEqual((await helper.getTextAtLocator(this.policyClaimNumberHeader)).replace(/[\n\r\t]/g,''), 'CLAIM NUMBER', 'Claim number header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.policyLossDateHeader)).replace(/[\n\r\t]/g,''), 'DATE OF LOSS', 'Claim loss date header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.policyClaimStatusHeader)).replace(/[\n\r\t]/g,''), 'STATUS', 'Claim status header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.policyClaimPaidHeader)).replace(/[\n\r\t]/g,''), 'PAID', 'Claim paid header text is not matched');
        await assert.assertEqual((await helper.getTextAtLocator(this.policyClaimNetIncurredHeader)).replace(/[\n\r\t]/g,''), 'NET INCURRED', 'Claim net incurred header text is not matched');
    }
    async isDocUploaded(){
        await assert.elementPresent(this.fileUploaded,'File not uploaded');
    }
    async goToMakeAClaim() {
        await assert.elementPresent(this.fileAClaimbutton, 'File a claim button is not present');
        await helper.click(this.fileAClaimbutton);
    }
    async validateClaimListed(claimNumber) {
        var claimNumberLink = claimNum.replace(cNum, claimNumber);
        await assert.elementPresent(Selector(claimNumberLink), 'Claim is not listed');
    }
    async isFileClaimButtonNotPresent() {
        await assert.elementNotPresent(this.fileAClaimbutton, 'File a claim button is present while it shouldnot');
    }
    async selectClaim(claimNumber) {
        var claimNumberLink = claimNum.replace(cNum, claimNumber);
        await helper.click(claimNumberLink);
    }

    async uploadDocument(claimNumber, fileName) {
        await this.selectClaim(claimNumber);
        await claimSummaryPage.openDocTab();
        var filePath = '../../Utilities/FileTypes/';
        await helper.uploadFile(this.uploadDoc, filePath + fileName);
    }

    async validateLOBDropDown() {
        await helper.click(this.productFilter);
        var dropDownlistProducts = ClientFunction(() => {
            var items = document.querySelectorAll("div[id='LOBFilter'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var actualProductList = ClientFunction(() => {
            var items = document.querySelectorAll("tr[class*='digitalRow Table-module'] td:nth-child(1)");
            var itemsValues = [];
            itemsValues.push('Filters');
            for (var item of items)
                itemsValues.push((item.textContent).trim());
            return itemsValues;

        });
        var actualProduct = await actualProductList();
        var dropdownProduct = await dropDownlistProducts();
        dropdownProduct.splice(0,1);
        let uniqueActualProduct = [...new Set(actualProduct)];
        console.log(uniqueActualProduct);
        console.log(dropdownProduct);
        if (JSON.stringify(dropdownProduct) == JSON.stringify(uniqueActualProduct))
            return true;
        else
            return false;
    }


    async Backtoclaims() {
        await helper.click(this.claims);
    }
    async filterClaimsByLOB(lob) {
        await helper.selectDropdown(this.productFilter, this.productFilterOption, lob);
    }
    async validateFilteredLOBClimes(lob) {
        var productElements = ClientFunction(() => {
            var items = document.querySelectorAll("span[title='Product']");
            var itemsValues = [];
            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var actualStatusList = await productElements();
        if (JSON.stringify(actualStatusList) === lob) {
            return true;
        } else {
            return false;
        }

    }
}
