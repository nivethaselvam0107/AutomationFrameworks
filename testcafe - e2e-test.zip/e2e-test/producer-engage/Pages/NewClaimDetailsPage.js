import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction, t } from "testcafe";
import CommonLocators from "../../Utilities/CommonLocators";


const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();

export default class NewClaimDetailsPage {
    constructor() {
        this.claimDraftNumber = Selector("[class*='gwClaimsWizardSpanNumber']");
        this.mapRadioButton = Selector("[for='whereDidHappenRadioButton_map']");
        this.state = Selector("div[id='exactState']");
        this.stateOption = Selector("div[id='exactState'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.addressLine1 = Selector("input[id='exactAddressLine1']");
        this.addressLine2 = Selector("input[id='exactAddressLine2']");
        this.addressLine3 = Selector("input[id='exactAddressLine3']");
        this.city = Selector("input[id='exactCity']");
        this.zipCode = Selector("input[id='exactZipCode']");
        this.claimDesc = Selector("textarea[id*='anyOther']");
        this.theftAdditionalInfo = Selector("textarea[id='theftAdditionalInfo']");
        this.describeWhatHappened = Selector("textarea[id='describeWhatHappened']");
        this.describeWhatHappenedGlass = Selector("textarea[id='glassDescribeWhatHappened']");
        this.propertyDamageYes = Selector("button[data-value='true']");
        this.propertyDamageDesc = Selector("textarea[id='describePropertyDamage']");
        this.cityMandatoryError = Selector("[model='address.city'] span[class*='gw-error-inline ']");
        this.stateMandatoryError = Selector("[model='address.state'] span[class*='gw-error-inline ']");
        this.cityOnly = Selector("[for='whereDidHappenRadioButton_cityOnly']");
        this.hidedFields = Selector("div[id='exactCityOnlyAddressContainer']");
        this.mapListSelector = Selector("div[class='gm-style'] div div").nth(1);
        this.causeoffire = Selector("textarea[id='fireCauseID']");
        this.firediscover = Selector("textarea[id='fireDiscoveredID']")
        this.burglaryRadio = Selector("[for='typeOfCrimeID_burglary']");
        this.vandalismRadio = Selector("[for='typeOfCrimeID_vandalism']");
        this.riotRadio = Selector("[for='typeOfCrimeID_riotandcivil']");
        this.waterDamageRadio = Selector("button[data-value='waterdamage']");
        this.moldDamageRadio = Selector("button[data-value='mold']");
        this.plumbWaterRadio = Selector("[for='sourceOfWaterID_plumbing_appliances']");
        this.roofLeakRadio = Selector("[for='sourceOfWaterID_roof']");
        this.otherRadio = Selector("[for='sourceOfWaterID_other']");
        this.waterTurnOffYesRadio = Selector("[for='hasWaterTurnedOffID_true']");
        this.waterTurnOffNoRadio = Selector("[for='hasWaterTurnedOffID_false']");
        this.waterTurnOffNotSureRadio = Selector("[for='hasWaterTurnedOffID_notSure']");
        this.vehicleDamaged = Selector("[id='vehicleDamaged']");
        this.vehicleDamagedOption = Selector("div[id='vehicleDamaged'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.vehicleInvolvedOption = "div[id*='vehicleInvolve'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div";
        this.vehicleInvolved = Selector("div[id*='vehicleInvolve'][class*='TypeaheadMultiSelectField']");
        this.vehicleTheftRadio = Selector("[for='whatStolen_theftentire']");
        this.vehiclePartTheftRadio = Selector("[for='whatStolen_theftparts']");

    }
    async areClaimLocationDetailsAreSaved(data) {
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine1), data.AddressLine1, 'Address line1 is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine2), data.AddressLine2, 'Address line2 is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.addressLine3), data.AddressLine3, 'Address line3 is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.city), data.City, 'City is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.zipCode), data.Zip, 'Postal Code is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.state), data.State, 'State is not correct');
    }
    async withLossLocation(lossLocationInput, address) {
        if (lossLocationInput == "Exact") {
            await this.withExactAccidentAddress(address);
        }
        else if (lossLocationInput == "CityOnly") {
            await this.withOnlyCity(address);
        }
        else if (lossLocationInput == "Map") {
            await this.withLocationOnMap();
        }
    }
    async withLocationOnMap() {
        await helper.click(this.mapRadioButton);
        await helper.click(this.mapListSelector);
    }
    async withExactAccidentAddress(data) {
        await helper.typeText(this.addressLine1, data.AddressLine1);
        await helper.typeText(this.addressLine2, data.AddressLine2);
        await helper.typeText(this.addressLine3, data.AddressLine3);
        await helper.typeText(this.city, data.City);
        await helper.typeText(this.zipCode, data.Zip);
        await helper.selectDropdown(this.state,this.stateOption, data.State);
    }
    async withClaimDescription(lossCause) {
        await helper.typeText(this.claimDesc, lossCause);
    }
    async typeTheftAdditionalInfo(lossCause) {
        await helper.typeText(this.theftAdditionalInfo, lossCause);
    }
    async typeDescribeWhatHappened(whatHappened) {
        await helper.typeText(this.describeWhatHappened, whatHappened);
    }
    async typeGlassDescribeWhatHappened(whatHappened) {
        await helper.typeText(this.describeWhatHappenedGlass, whatHappened);
    }
    async withPropDamageDetails(propertyDescription) {
        await helper.click(this.propertyDamageYes);
        await helper.typeText(this.propertyDamageDesc, propertyDescription);
    }
    async setFireDetails(fireDetails) {
        await this.firecause(fireDetails.FireCause);
        await this.firediscovered(fireDetails.FireDiscovery);
        await this.withClaimDescription(fireDetails.LossCause);
    }
    async withCrimeType(crimeDamageType) {
        if (crimeDamageType == "Burglary") {
            await helper.click(this.burglaryRadio);
        } else if (crimeDamageType == "Vandalism") {
            await helper.click(this.vandalismRadio);
        } else if (crimeDamageType == "Riot") {
            await helper.click(this.riotRadio);
        }
    }
    async withWaterDamageType(damageType) {
        if (damageType == "WaterDamage") {
            await helper.click(this.waterDamageRadio);
        } else if (damageType == "Mold") {
            await helper.click(this.moldDamageRadio);
        }
    }
    async withWaterDamageSource(damageSource) {
        if (damageSource == "Plumbing") {
            await helper.click(this.plumbWaterRadio);
        } else if (damageSource == "Roof") {
            await helper.click(this.roofLeakRadio);
        } else if (damageSource == "Other") {
            await helper.click(this.otherRadio);
        }
    }
    async withWaterTurnOffStatus(status) {
        if (status == "Yes") {
            await helper.click(this.waterTurnOffYesRadio);
        } else if (status == "No") {
            await helper.click(this.waterTurnOffNoRadio);
        } else if (status == "NotSure") {
            await helper.click(this.waterTurnOffNotSureRadio);
        }
    }
    async setWaterDamageDetails(waterDamageDetails) {
        await this.withWaterDamageType(waterDamageDetails.WaterDamageType);
        await this.withClaimDescription(waterDamageDetails.LossCause);
        await this.withWaterDamageSource(waterDamageDetails.WaterDamageSource);
        await this.withWaterTurnOffStatus(waterDamageDetails.WaterTurnOff);

    }
    async setCrimeDetails(crimeDetails) {
        await this.withCrimeType(crimeDetails.CrimeDamageType);
        await this.withClaimDescription(crimeDetails.LossCause);
    }
    async getDraftClaimNumber() {
        var draftNumber = await helper.getTextAtLocator(this.claimDraftNumber);
        return draftNumber;
    }
    async withVehicleInvolved(vehicleDamaged) {
        if (vehicleDamaged == null) {
            await this.selectFirstAvailableVehicle();
        }
    }
    async selectVehicleDamaged(vehicleDamaged) {
        if (vehicleDamaged == null) {
            await this.selectFirstAvailableVehicleDamaged();
        }
    }

    async verifyNextButtonDisabledForRequiredFields(city,state){
        await common.validateNextButtonIsDisabled();
        await helper.typeText(this.city,city);
        await common.validateNextButtonIsDisabled();
        await helper.selectDropdown(this.state,this.stateOption,state);
        await common.validateNextButtonIsEnabled();
    }
    async withTheftVehicleDamageDetails(theftType) {
        if (theftType == "VehicleStolen") {
            await helper.click(this.vehicleTheftRadio);
        }
        else if (theftType == "AudioStolen") {
            await helper.click(this.vehiclePartTheftRadio);
        }
    }
    async selectFirstAvailableVehicle() {
         var optionToBeSelected = [];
         await helper.click(this.vehicleInvolved);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("div[id*='vehicleInvolve'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];

            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var dropDownoptions = await dropDownValues();
        for (var option of dropDownoptions)
            if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
                optionToBeSelected.push(option);
            }
            await helper.click(Selector("div[id*='vehicleInvolve'][class*='TypeaheadMultiSelectField'] div[class*='TypeaheadMultiSelectField__menu'] div").withExactText(optionToBeSelected[0]));
    }
    async selectFirstAvailableVehicleDamaged() {
        var optionToBeSelected = [];
        await helper.click(this.vehicleDamaged);
        var dropDownValues = ClientFunction(() => {
            var items = document.querySelectorAll("div[id='vehicleDamaged'] div[class*='TypeaheadMultiSelectField__menu'] div");
            var itemsValues = [];

            for (var item of items)
                itemsValues.push(item.textContent);
            return itemsValues;
        });
        var dropDownoptions = await dropDownValues();
        for (var option of dropDownoptions)
            if (!(option.toLowerCase()).includes("choose") && !(option.toLowerCase()).includes("other")) {
                optionToBeSelected.push(option);
            }
            await helper.click((this.vehicleDamagedOption).withExactText(optionToBeSelected[0]));
    }
    async clickNext() {
        await helper.click(this.nextButton);
    }
    async openCityOnlyLocationSection() {
        await helper.click(this.cityOnly);
        await assert.elementPresent(this.hidedFields);
    }
    async withOnlyCity(data) {
        await this.openCityOnlyLocationSection();
        await helper.typeText(this.city, data.City);
        await helper.selectDropdown(this.state,this.stateOption, data.State);
    }
    async firecause(firecause) {
        await helper.typeText(this.causeoffire, firecause);
    }
    async firediscovered(firedis) {
        await helper.typeText(this.firediscover, firedis);
    }

}

