import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';

const helper = new Helper();
const assert = new Assertion();
export default class Tiles {
    constructor() {
        this.activeTile = Selector("[class*='TileComponent_gwActive'] div[class*='TileTitle']");    
        this.activeTileValue = Selector("[class*='TileComponent_gwActive'] div[class*='TileContent']");    
    }

    async validateTileOpened(tileName) {
        await assert.assertEqual(await helper.getTextAtLocator(this.activeTile), tileName, 'Tile name does not match')
    }
    async getCountOnActiveTile(){
        var tileValue = await helper.getTextAtLocator(this.activeTileValue);
        return tileValue;
    }



}
