import { Selector, t } from 'testcafe';
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const data = require('../Data/QnB_PA_Data.json');


const helper = new Helper();
const assert = new Assertion();

export default class VehiclesPage {
    constructor() {
        this.vin = Selector("[id='vehicleVin']");
        this.make = Selector("[id='vehicleMake']");
        this.model = Selector("[id='vehicleModel']");
        this.yearSelect = Selector("[id='vehicleYear']");
        this.yearOption = Selector("[id='vehicleYear'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.state_Select = Selector("[id='driverLicenceState']");
        this.state_Option=Selector("[id='driverLicenceState'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.licensePlate = Selector("[id='vehicleLicencePlate']");
        this.costNew = Selector("[id='vehicleCostNew']");
        
    }
    async typeVin(vin) {
        await helper.typeText(this.vin, vin);
    }
    async typeMake(make) {
        await helper.typeText(this.make, make);
    }
    async typeModel(model) {
        await helper.typeText(this.model, model);
    }
    async selectYear(option) {
        await helper.selectDropdown(this.yearSelect,this.yearOption, option);
    }
    async typeLicensePlate(licensePlate) {
        await helper.typeText(this.licensePlate, licensePlate);
    }
    async typeCost(cost) {
        await helper.typeText(this.costNew, cost);
    }
    async selectState(option){
        await helper.selectDropdown(this.state_Select, this.state_Option, option);
    }
    async clickLicensePlate(){
        await helper.click(this.licensePlate);
    }

    async areVehiclePageFieldsMarkedWithAsterisk() {
        await assert.elementPresent(this.vin_asterisk, 'Vin field is not marked as required using asterisk');
        await assert.elementPresent(this.make_asterisk, 'Make field is not marked as required using asterisk');
        await assert.elementPresent(this.model_asterisk, 'Model field is not marked as required using asterisk');
        await assert.elementPresent(this.year_asterisk, 'Year field is not marked as required using asterisk');
        await assert.elementPresent(this.state_asterisk, 'State field is not marked as required using asterisk');
        await assert.elementPresent(this.cost_asterisk, 'Cost New field is not marked as required using asterisk');
    }

    async setVehicleDetails(data){
        await this.typeVin(data.VIN);
        await this.typeCost(data.VehicleCost);
        await this.typeLicensePlate(data.LicensePlate);
        await this.selectState(data.VehicleState);
        await this.selectYear(data.VehicleYear);
        await this.typeMake(data.Make);
        await this.typeModel(data.Model);
        await this.clickLicensePlate();
        
        
    }
    async areVehiclesDetailsSaved(data){    
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.vin),data.VIN,'VIN is not Correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.make),data.Make,'Make is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.model),data.Model,'Model is not correct');
        await assert.assertEqual(await helper.getTextAtLocator(this.yearSelect),data.VehicleYear,'year is not correct');
        await assert.assertEqual(await helper.getValueAttributeFromLocator(this.licensePlate),data.LicensePlate,'License Plate is not Correct');
        await assert.assertEqual(await helper.getTextAtLocator(this.state_Select),data.VehicleState,'State is not COrrect');
        await assert.assertEqual((await helper.getValueAttributeFromLocator(this.costNew)).replace(/,/g),(data.VehicleCost).toFixed(2),'Cost is not correct');


    }
    async withVehicleCost(data){
        await helper.typeText(data.VehicleCost)  
      }
}
