import { Selector,ClientFunction } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import { createRequireFromPath } from 'module';
import DataFetch from '../Data/DataFetch';


const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();

export default class EndorsementCoverages_PA {
    constructor() {
        this.medicalLimitValue = Selector("[id='ClauseTerm_[PAMedPayCov]_[0]']");
        this.medicalLimitOption = Selector("[id*='ClauseTerm_[PAMedPayCov]_[0]'] div[class*='TypeaheadMultiSelectField__menu'] div");
        this.checkedCoverages = Selector("[aria-checked='true']");
        this.checkedCoverageNames = Selector(" ");
        this.title = Selector("#pageTitle");
        
    }

    async setMedicalLimit(limit){
        await helper.selectDropdown(this.medicalLimitValue,this.medicalLimitOption,limit);
    }
    async verifyPageTitle(){
        await assert.assertEqual(await helper.getTextAtLocator(this.title),'Coverages','Coverage title is incorrect');
    }

    async validateMedicalLimitValue(data, policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        var lineCoverage = content.lobData.personalAuto.offerings[0].coverages.lineCoverages;
        var baseCovCount = content.lobData.personalAuto.offerings[0].coverages.lineCoverages.length;
        for (var i = 0; i < baseCovCount; i++) {
			var covItr = content.lobData.personalAuto.offerings[0].coverages.lineCoverages[i];
			if (content.lobData.personalAuto.offerings[0].coverages.lineCoverages[i].name == 'Medical Payments') {
				await assert.assertEqual((data.CovValue),(content.lobData.personalAuto.offerings[0].coverages.lineCoverages[i].terms[0].chosenTermValue),'Medical Limit was not updated');
			} 
        }
    }

    async uncheckCheckedCoverage(){
        const checkedCoverage = this.checkedCoverages.nth(0);
        var coverageToCheck = await helper.getTextAtLocator(checkedCoverage.parent('div'));
        await helper.click(Selector(checkedCoverage).parent('div'));
        return coverageToCheck;
    }


    async isLineCoverageSelected(covName,policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        var lineCovFromBackend = content.lobData.personalAuto.offerings[0].coverages.lineCoverages;
        var lineCovCount = content.lobData.personalAuto.offerings[0].coverages.lineCoverages.length;
        var covFlag = false;
        for(var i=0; i<lineCovCount; i++){
            var coverage = content.lobData.personalAuto.offerings[0].coverages.lineCoverages[i];
            if(coverage.name == covName && coverage.selected == 'true'){
                covFlag = true;
            }
        }

        return covFlag;
    }

    


    
    


   
  





}