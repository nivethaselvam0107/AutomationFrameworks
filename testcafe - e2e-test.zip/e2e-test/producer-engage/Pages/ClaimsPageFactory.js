import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import SelectPolicy from './SelectPolicy';
import NewClaimTypeOfIncidentPage from './NewClaimTypeOfIncidentPage';
import NewClaimDetailsPage from './NewClaimDetailsPage';
import NewClaimsDocumentPage from './NewClaimsDocumentPage';
import NewClaimContactDetails from './NewClaimContactDetailsPage';
import NewClaimClaimSummary from './NewClaimSummaryPage';
import NewClaimWhere from './NewClaimWherePage';
import NewClaimInjuryDetails from './NewClaimsInjuryDetails';
import NewClaimVehiclePage from './NewClaimVehiclePage';
import NewClaimRepairPage from './NewClaimRepairPage';
import NavBar from '../Pages/NavBar';
import AccountLanding from '../Pages/AccountsLanding';
import AccountSummary from '../Pages/AccountSummary';
import ClaimsTileView from '../Pages/ClaimsTileView';
import PolicySummary from '../Pages/PolicySummary';
import CommonLocators from '../../Utilities/CommonLocators';
import PolicyLanding from '../Pages/PolicyLanding';
import { content } from '../Data/DataFetch';



const policyLanding = new PolicyLanding();
const helper = new Helper();
const assert = new Assertion();
const selectPolicy = new SelectPolicy();
const type = new NewClaimTypeOfIncidentPage();
const detail = new NewClaimDetailsPage();
const document = new NewClaimsDocumentPage();
const contact = new NewClaimContactDetails();
const summary = new NewClaimClaimSummary();
const where = new NewClaimWhere();
const injury = new NewClaimInjuryDetails();
const vehicle = new NewClaimVehiclePage();
const repair = new NewClaimRepairPage();
const navBar = new NavBar();
const accountLanding = new AccountLanding();
const accountSummary = new AccountSummary();
const claimsTileView = new ClaimsTileView();
const policySummary = new PolicySummary();
const common = new CommonLocators();




export default class ClaimsPageFactory {

    constructor() {
       this.claimsListTable = Selector("[class*='Table-module__tableElement']");

        this.policyNum = Selector("title='Policy Number'");
    }
    async createTheftClaim(data, address) {
        await common.goNext();
        await t.wait(3000);
        await type.selectPAClaimType(data.ClaimSubType);
        await t.wait(3000);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput, address);
        await detail.withVehicleInvolved(data.VehicleDamaged);
        await detail.withTheftVehicleDamageDetails(data.TheftType);
        await detail.typeTheftAdditionalInfo(data.LossCause);
        await common.goNext();
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }
    async createOtherClaim(data) {
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await common.goNext();
    }
    async createCollisionWithPedestrianPAClaim(data) {
        await selectPolicy.clickNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await type.selectCollisionClaimType(data.ClaimTypeCollision);
        await type.clickNext();
        await detail.withLossLocation(data.LossLocationInput, data.Address);
        await detail.typeTheftAdditionalInfo(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await detail.clickNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();


    }
    async createGlassClaim(data,address) {
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput, address);
        await detail.selectVehicleDamaged(data.VehicleDamaged);
        await detail.typeGlassDescribeWhatHappened(data.LossCause);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }
    async createGlassClaimForVendorChoice(data,address) {
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput, address);
        await detail.selectVehicleDamaged(data.VehicleDamaged);
        await detail.typeGlassDescribeWhatHappened(data.LossCause);
        await common.goNext();
    }

    async createTheftClaimForVendorChoice(data,address) {
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput,address);
        await detail.withVehicleInvolved(data.VehicleDamaged);
        await detail.withTheftVehicleDamageDetails(data.TheftType);
        await detail.typeTheftAdditionalInfo(data.LossCause);
        await common.goNext();
    }
    async createGeneralClaim(data) {
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectGeneralClaimType(data.LossCause);
        await type.setGeneralLossDesc(data.LossDescription);
        await type.setGeneralDamageDesc(data.DamageDescription);
        await common.goNext();
        await where.selectPredefinedAddress();
        await common.goNext();
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }
    async createGeneralClaimFromPolicy(data) {
        await common.goNext();
        await type.selectGeneralClaimType(data.LossCause);
        await type.setGeneralLossDesc(data.LossDescription);
        await type.setGeneralDamageDesc(data.DamageDescription);
        await common.goNext();
        await where.selectPredefinedAddress();
        await common.goNext();
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();
    }
    async createGeneralClaimForIM(data,address) {
        await common.goNext();
        await type.selectGeneralClaimType(data.LossCause);
        await type.setGeneralLossDesc(data.LossDescription);
        await type.setGeneralDamageDesc(data.DamageDescription);
        await common.goNext();
        await where.selectPredefinedAddress();
        await where.selectAddress(address);
        await common.goNext();
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }
    async createCollisionClaimFromAccount(data,address) {
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await type.selectCollisionClaimType(data.ClaimTypeCollision);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput,address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleCollisionPoint(data.CollisionPoint);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await document.withNewContactPerson(data.FirstNameNewPerson, data.LastNameNewPerson, data.NewPersonHomePhone);
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }
   

    async createCollisionClaim(data, address) {
        await common.goNext();
        await t.wait(3000);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput,address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleCollisionPoint(data.CollisionPoint);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await document.withNewContactPerson(data.FirstNameNewPerson, data.LastNameNewPerson, data.NewPersonHomePhone);
        await common.goNext();
        await t.wait(4000);
        await common.goNext();
        await summary.clickSubmitClaim();
    }
    async createCollisionClaimTillAdditionalInformation(data, address) {
        await common.goNext();
        await t.wait(3000);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput,address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleCollisionPoint(data.CollisionPoint);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await document.withNewContactPerson(data.FirstNameNewPerson, data.LastNameNewPerson, data.NewPersonHomePhone);
        await common.goNext();

    }
    async createCollisionClaimTillAddInfoPage(data, address) {
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await type.selectCollisionClaimType(data.ClaimTypeCollision);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput,address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleCollisionPoint(data.CollisionPoint);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await document.withNewContactPerson(data.FirstNameNewPerson, data.LastNameNewPerson, data.NewPersonHomePhone);
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
    }
    
    async createCollisionClaimForVendorChoice(data, address) {
        await common.goNext();
        await type.selectPAClaimType(data.ClaimSubType);
        await type.selectCollisionClaimType(data.ClaimTypeCollision);
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput, address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleCollisionPoint(data.CollisionPoint);
        await common.goNext();
    }
    async createWCClaim(data) {
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectWCClaimType(data.LossCause);
        await type.setWCLossDesc(data.LossDescription);
        await type.setNotificationDateInThePast();
        await type.setInjuredEmployeeName(data.EmployeeFName, data.EmployeeLName);
        await type.setInjuredEmployeeAddress(data.City, data.ZipCode, data.State);
        await common.goNext();
        await injury.selectInjuryType(data.InjuryType);
        await injury.setDeathReport(false);
        await injury.setLostTimeFromWork(false);
        await injury.setMedicalTreatment(false);
        await common.goNext();
        await where.selectPredefinedAddress();
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await common.goNext();
        await summary.clickSubmitClaim();
    }

    async goToAccountsClaimsPage(policy) {
        await navBar.goToAccountsLanding();
        await accountLanding.showRecentlyCreated();
        await accountLanding.clickAccountNameLink(policy.accountNumber);
        await accountSummary.goToAccountsClaimsTile();
    }

    async goToAccountsClaimsPageTroughPolicies(policy) {
        await navBar.goToPoliciesLanding();
        await t.wait(3000);
        await policyLanding.showRecentlyIssued();
        await policySummary.goToPolicySummaryPage(policy.policyNum);
        await policySummary.goToclaimsTile();
    }

    async createPACollisionClaimTillConfirmationPage(data, address) {
        await claimsTileView.goToMakeAClaim();
        await selectPolicy.selectPolicy();
        await common.goNext();
        await detail.withLossLocation(data.LossLocationInput, address);
        await detail.typeDescribeWhatHappened(data.LossCause);
        await detail.withPropDamageDetails(data.WithPropDamage);
        await common.goNext();
        await vehicle.selectFirstAvailableDriver();
        await vehicle.selectFirstAvailableVehicle();
        await vehicle.setAirBagDeployStatus(data.AirBagDeploy);
        await vehicle.setVehicleRentalStatus(data.RentalStatus);
        await vehicle.setVehicleTowStatus(data.VehicleTowed);
        await vehicle.setEquiFailureStatus(data.EquipmentFailure);
        await vehicle.setVehicleSafetyToDrive(data.SafetyToDrive);
        await common.goNext();
        await repair.selectNoFacility();
        await common.goNext();
        await common.goNext();
        await contact.withContactHomeNum(data);
        await contact.goToSummary();
        await t.wait(2000);
        await summary.clickSubmitClaim();
    }
    async createHOCrimeClaimFromPolicy(data) {
        await claimsTileView.fileAClaimPolicy();
        await common.goNext();
        await type.selectHOClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.setCrimeDetails(data);
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();
    }
    async createHOCrimeClaimFromAccount(data) {
        await claimsTileView.clickfileAClaimAccount();
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectHOClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.setCrimeDetails(data);
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();
    }
   
    async createHOWaterClaimFromAccount(data){
        await claimsTileView.clickfileAClaimAccount();
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectHOClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.setWaterDamageDetails(data);
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();

    }
    async createHOFireClaimFromPolicy(data) {
        await claimsTileView.fileAClaimPolicy();
        await common.goNext();
        await type.selectHOClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.setFireDetails(data);
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();
    }
    async createHOFireClaimFromAccount(data) {
        await claimsTileView.fileAClaimPolicy();
        await selectPolicy.selectPolicy();
        await common.goNext();
        await type.selectHOClaimType(data.ClaimSubType);
        await common.goNext();
        await detail.setFireDetails(data);
        await common.goNext();
        await document.uploadDocFromFNOL(data.FileName);
        await common.goNext();
        await contact.goToSummary();
        await summary.clickSubmitClaim();
    }
    async createPACollisionDraftClaim(address) {
        await claimsTileView.goToMakeAClaim();
        await selectPolicy.selectPolicy();
        await common.goNext();
        await common.goNext();
        await detail.withOnlyCity(address);
        await common.pressCancel();
        await common.confirmCancel();
    }
}
