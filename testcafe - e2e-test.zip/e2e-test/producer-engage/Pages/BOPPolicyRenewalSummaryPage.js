import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const modal = new Modal();
var policyNumber;
const renewalWithdrawnMsg = "This renewal has been withdrawn.";
const renewalDraftedMessage1 ="The renewal for Businessowners Policy " +policyNumber+" has been successfully started."
const renewalQuotedMessage1 ="The renewal for Businessowners policy " +policyNumber+" is quoted. It will be bound automatically on";
const renewalQuotedMessage2 = "If you need to make a change, click Edit Renewal.";
const renewalQuotedMessage3 = "If you need to withdraw this renewal transaction, click Withdraw Renewal.";


export default class BOPPolicyRenewalSummaryPage {
    constructor() {
        this.status = Selector("#infoStatus");
        this.withdrawRenewalButton = Selector("#withdrawQuote");
        this.editRenewalButton = Selector("#continueQuote");
        this.renewalDetailsPageMessageLine1 = Selector("[class*='SuccessNotification_gwAlertContentHeading']");
        this.renewalDetailsPageMessageLine2 = Selector("[class*='SuccessNotification_gwAlertContentSubHeading']");
        this.renewalDetailsPageMessageLine3 = Selector("[class*='SuccessNotification_gwAlertContentInnerHeading']");
        this.warningInfo = Selector("#alertContentInfo");
        this.openActivitiesTile = Selector("[class*='TileComponent_gwTileTitle']").nth(1);
        this.summaryTile = Selector("[class*='TileComponent_gwTileTitle']").nth(0);
        this.notesTile = Selector("[class*='TileComponent_gwTileTitle']").nth(2);
        this.documentsTile = Selector("[class*='TileComponent_gwTileTitle']").nth(3);
        this.policyRenewalHeader = Selector("[class*='FormattedHeaderComponent_gwPageTitle']");
    }
    async editPolicyRenewal(){
        await helper.click(this.editRenewalButton);
    }
    async clickWithdrawRenewal(){
        await helper.click(this.withdrawRenewalButton);
        await modal.confirm();
    }
    async validateMessageOnRenewalDetailPage(policyNum){
        var message1 = renewalQuotedMessage1.replace(policyNumber,policyNum);
        await assert.hasText(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine1),message1,'The message on first line does not match on renewal detail page');
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine2),renewalQuotedMessage2,'The message on second line does not  match on renewal detail page');
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine3),renewalQuotedMessage3,'The message on third line does not match on renewal detail page');
    }
    async validateMessageOnDraftRenewalDetailPage(policyNum){
        var message1 = renewalDraftedMessage1.replace(policyNumber,policyNum);
        await assert.hasText(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine1),message1,'The message on first line does not match on renewal draft detail page');
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine2),renewalQuotedMessage2,'The message on second line does not  match on renewal detail page');
        await assert.assertEqual(await helper.getTextAtLocator(this.renewalDetailsPageMessageLine3),renewalQuotedMessage3,'The message on third line does not match on renewal detail page');
    }
    async validateTilesAndHeaderOnPolicyRenewalSummaryPage(){
        await assert.elementPresent(this.openActivitiesTile,'Open activites tile is not found');
        await assert.elementPresent(this.summaryTile,'Summary tile is not found');
        await assert.elementPresent(this.notesTile,'Notes tile is not found'); 
        await assert.elementPresent(this.documentsTile,'Document tile is not found'); 
        await assert.textContains(await helper.getTextAtLocator(this.policyRenewalHeader),'Renewal','The page header does not match');
    }
    async validateMessageOnWithdrawalRenewalDetailPage(){
        await assert.assertEqual(await helper.getTextAtLocator(this.warningInfo),renewalWithdrawnMsg,'Withdrawal message is incorrect');
    }
    async validatePolicyRenewalJobStatus(expectedStatus){
        await assert.assertEqual(await helper.getTextAtLocator(this.status),expectedStatus,'Renewal policy is not withdrawn');
    }
}