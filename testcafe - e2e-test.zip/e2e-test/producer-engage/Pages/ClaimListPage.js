import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction, t } from "testcafe";

const helper = new Helper();
const assert = new Assertion();

export default class ClaimListPage {
    constructor() {
        this.PAID_COL_SELECTOR = Selector("table[class*='Table-module'] th").nth(3);
        this.NET_INCURRED_COL_SELECTOR = Selector("table[class*='Table-module'] th").nth(4);
        this.CLAIMNUM_COL = Selector("table[class*='Table-module'] th").nth(0);
        this.DOL_COL = Selector("table[class*='Table-module'] th").nth(1);
        this.STATUS_COL =Selector("table[class*='Table-module'] th").nth(2);
        this.POLICY_COL = Selector("table[class*='Table-module'] th").nth(6);
        this.paidColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(5);
        this.netIncurredColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(6);
        this.claimNumColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(2);
        this.DOLColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(3);
        this.statusColClaimsLanding =Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(4);
        this.productColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(0);
        this.policyColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(7);
        this.accountColClaimsLanding = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']").nth(1);
        this.policyclaimTableHeader = Selector("table[class*='Table-module'] th");
        this.claimTableHeader = Selector("[id='recentlyViewedTableGrid'] [class*='rt-th text']");
        this.fileAClaimbutton = Selector("button[id='fileClaimButton']");
        this.fileAClaimAccountButton = Selector("button[id='fileClaimButton']");
        this.claimtableValue = Selector("table[class*='Table-module'] tbody tr");
        this.searchClaim = Selector("input[id='searchFilter']");
        this.claimList = Selector("table[class*='Table-module']");
        this.claimNumber=Selector("[title='Claim Number']");
        this.openClaimNumber=Selector("[href*='fnol-select-policy']");
        this.additionalInformationWizard=Selector("[class*='WizardSidebar_navigationButton']").nth(5);
    

    }
    async isClaimListPageLoaded() {
        await assert.elementPresent(this.PAID_COL_SELECTOR, "Claim list PAID column NOT visible");
        await assert.elementPresent(this.NET_INCURRED_COL_SELECTOR, "Claim list NET INCURRED column NOT visible");
        await assert.elementPresent(this.CLAIMNUM_COL, "Claim list CLAIM NUMBER column NOT visible");
        await assert.elementPresent(this.DOL_COL, "Claim list DATE OF LOSS column NOT visible");
        await assert.elementPresent(this.STATUS_COL, "Claim list STATUS column NOT visible");
    }

    
    async isClaimListPageLoadedOnPoliciesClaim() {
        await this.isClaimListPageLoaded();
        await assert.assertEqual(await this.policyclaimTableHeader.count, 5, 'Claim list number of columns is incorrect');
        await assert.elementPresent(this.fileAClaimbutton, 'File a claim button is not present');
        await assert.elementPresent(this.searchClaim, 'Search claim textbox is not present');

    }
    async isDraftClaimNotLoadedOnClaimsList(){
        await assert.elementNotPresent(this.claimtableValue);
    }

    async isClaimListPageLoadedOnAccountClaim() {
        await this.isClaimListPageLoaded();
        await assert.elementPresent(this.POLICY_COL, "Claim list STATUS column NOT visible");
        await assert.elementPresent(this.fileAClaimAccountButton, "File a Claim button not visible");
        await assert.elementPresent(this.searchClaim, "Search Text box is not displayed");
    }

    async isClaimListPageLoadedOnClaims() {
        await assert.elementPresent(this.paidColClaimsLanding, "Claim list PAID column NOT visible");
        await assert.elementPresent(this.netIncurredColClaimsLanding, "Claim list NET INCURRED column NOT visible");
        await assert.elementPresent(this.claimNumColClaimsLanding, "Claim list CLAIM NUMBER column NOT visible");
        await assert.elementPresent(this.DOLColClaimsLanding, "Claim list DATE OF LOSS column NOT visible");
        await assert.elementPresent(this.statusColClaimsLanding, "Claim list STATUS column NOT visible");
        await assert.elementPresent(this.productColClaimsLanding, "Claim list PRODUCT column NOT visible");
        await assert.elementPresent(this.policyColClaimsLanding, "Claim list STATUS column NOT visible");
        await assert.elementPresent(this.accountColClaimsLanding, 'Claim list ACCOUNT column NOT visible');
        await assert.assertEqual(await this.claimTableHeader.count, 8, 'Claim list number of columns is incorrect');
    }
    async filterClaimByTextSearch(searchValue) {
        await helper.typeText(this.searchClaim, searchValue);
    }
    async validateContainsClaim() {
        await assert.elementPresent(this.claimList, 'Claim list is not filtered as per number for General FNOL');
    }
    async openClaimSummary(){
       await helper.click(this.claimNumber);
    }
    async openClaim(){
        await helper.click(this.openClaimNumber);
    }
    async openClaimDetailsPage(claimNum){
        await this.searchclaim(claimNum);
        await this.openClaim(claimNum);
    }
    async clickAdditionalInformationWizard(){
        await helper.click(this.additionalInformationWizard);
    }
    async searchclaim(claimNum){
        await helper.typeText(this.searchClaim,claimNum);
    }
}