import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import DataFetch from "../Data/DataFetch";
import CommonLocators from '../../Utilities/CommonLocators';
import Modal from '../../Utilities/WidgetComponents/Modal';
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();
var addedMortgagee = "[id*='hoPolicyChangeMortgagee']";
const common = new CommonLocators();
const modal = new Modal();

export default class EndorsementMortgageePage {
    constructor() {
        this.nameModel = Selector("input[id*='CompanyName']");
        this.stateModel = Selector("div[id*='hoPolicyChangeStateId']:nth-child(1)");
        this.stateOption = Selector("div[id*='hoPolicyChangeStateId']:nth-child(1) div[class*='TypeaheadMultiSelectField__menu'] div");
        this.streetModel = Selector("input[id*='hoPolicyChangeStreetId']");
        this.cityModel = Selector("input[id*='hoPolicyChangeCityId']");
        this.zipModel = Selector("input[id*='hoPolicyChangeZipCodeId']");
        this.newMortgageeButton = Selector("[id='hoPolicyChangeAddMortgageeBtn']");
        this.editMortgageeButton = Selector("[class*='fas fa-edit Button-module']");
        this.removeMortgageeButton = Selector("[class*='fas fa-trash Button-module']");
    }

    async setNameValue(name){
        await helper.typeText(this.nameModel,name);
    }
    async setStateValue(state){
        await helper.selectDropdown(this.stateModel,this.stateOption,state);
    }
    async setStreetValue(street){
        await helper.typeText(this.streetModel,street);
    }
    async setCityValue(city){
        await helper.typeText(this.cityModel,city);
    }
    async setZipValue(zip){
        await helper.typeText(this.zipModel,zip);
    }
    
    async fillMortageeFormData(data){
        await this.setNameValue(data.MortGagee_Name);
        await this.setStateValue(data.MortGagee_State);
        await this.setStreetValue(data.MortGagee_Street);
        await this.setCityValue(data.MortGagee_City);
        await this.setZipValue(data.MortGagee_Zip);
        await common.goNext();

    }

    async isAddedMortgageePresent(title){
        await assert.elementPresent(Selector(addedMortgagee).withText(title),'Added Mortgagee title is not present');
    }
    async isMortgageeRemoved(title){
        await assert.elementNotPresent(Selector(addedMortgagee).withText(title),'Mortgagee is still present in the page');
    }

    async addNewMortgagee(){
        await helper.click(this.newMortgageeButton);
    }
    async isMortgageeAvailableInPolicyFromBackEnd(data,policy){
        var content = await dataFetch.getPolicyChangeData(policy);
        var mortProp = content.lobData.homeowners.coverables.additionalInterests;
        var count = content.lobData.homeowners.coverables.additionalInterests.length;
        var covFlag = false;
        for (var i=0; i<count; i++){
            var mortPropType = content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest;
            if(content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest.displayName == data.MortGagee_Name){
                var mortPropTypeAdd = content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest.primaryAddress;
                await assert.assertEqual(content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest.primaryAddress.city,data.MortGagee_City,'MortGagee is not applied to policy');
                await assert.assertEqual(content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest.primaryAddress.postalCode,data.MortGagee_Zip,'MortGagee is not applied to policy');
                await assert.assertEqual(content.lobData.homeowners.coverables.additionalInterests[i].policyAdditionalInterest.primaryAddress.addressLine1,data.MortGagee_Street,'MortGagee is not applied to policy');
                covFlag = true;

            }
        }
        return covFlag;
    }

    async clickEditMortgagee(){
        await helper.click(this.editMortgageeButton);
    }

    async clickRemoveMortgagee(){
        await helper.click(this.removeMortgageeButton);
        await modal.confirm();
    }
    
}