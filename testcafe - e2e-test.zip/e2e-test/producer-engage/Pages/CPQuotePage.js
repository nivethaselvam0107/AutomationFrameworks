import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Modal from '../../Utilities/WidgetComponents/Modal';
const data = require('../Data/PE_PA_Data.json');
const dataCP =require('../Data/PE_CP_Data.json');

const helper = new Helper();
const assert = new Assertion();
const modal= new Modal();
var QUOTE_ALERT_INCREASE_MSG= "There is an increase in the premium\n" +
"The new premium is now $newPremium. This is an increase of $changePremium on the current premium and will be reflected in upcoming invoices.";

export default class CPBOPQuotePage {


    constructor() {

        this.print_Button=Selector("[id='printPage']");

    }
    async isCPQuotePageLoaded(){
        await assert.elementPresent(this.print_Button,"Quote page not displayed");

    }
    validateTransactionQuotePageForIncrease(policyNum)
    {

    }
}
