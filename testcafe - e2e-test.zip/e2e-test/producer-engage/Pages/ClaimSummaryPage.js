import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";
import { Selector, ClientFunction } from "testcafe";
import DataFetch from "../Data/DataFetch";
const helper = new Helper();
const assert = new Assertion();
const dataFetch = new DataFetch();
export default class ClaimSummaryPage {
    constructor() {
        this.PARTIES_INVOLVEMENT_ROW = Selector("[id='partiesInvolved'] tbody tr");
        this.SUMMARY_SECTION = Selector("div[id='summaryDetailsDiv']");
        this.ADJUSTER_SECTION = Selector("div[id='adjusterContainer']")
        this.VENDORS_SECTION = Selector("div[id='partyTableContainer']")
        this.policy_Number_Value = Selector("#policyNumber");
        this.account_Number_Value = Selector("#accountNumber");
        this.claimStatus = Selector("#claimStatus");
        this.dateOfLossValue = Selector("#dateOfLoss");
        this.reporterValue = Selector("#reportedBy");
        this.lossLocationValue = Selector("#lossLocation");
        this.adjusterNameValue = Selector("#adjusterName");
        this.adjusterContactValue = Selector("#adjusterPhone");
        this.dateNotifiesValue = Selector("#employerNotified");
        this.docTab = Selector("[id*='documentsTab']");
        this.noteTab = Selector("[id*='notesTab']");
        this.policyLink = Selector("[id='policyNumber'] a");
        this.accountNumberLink = Selector("[id='accountNumber'] a");
        this.accountNameLink = Selector("[class*='digitalRow Table-module__row__'] [href*='/claims/']");
        this.partiesInvolvedName = Selector("[class*='gw-heading']");
        this.claimsPage = Selector("[class*='ClaimDetails_claimDetails__']");
        this.primaryContactValue = Selector("#primaryContact");
        this.vehicleMake = Selector("[id='vehicleDetailsDataTable']").find(" [class*='rt-td DataTable-module__tableCell']").nth(1);
        this.vehicleModel = Selector("[id='vehicleDetailsDataTable']").find(" [class*='rt-td DataTable-module__tableCell']").nth(2);
        this.vehicleyear = Selector("[id='vehicleDetailsDataTable']").find(" [class*='rt-td DataTable-module__tableCell']").nth(3);
        this.vehicleLicensePlate = Selector("[id='vehicleDetailsDataTable']").find(" [class*='rt-td DataTable-module__tableCell']").nth(4);
    }

    async isHOPageDisplayedCorrectly() {
        await assert.elementPresent(this.SUMMARY_SECTION, "Summary section is not present");
        await assert.elementPresent(this.ADJUSTER_SECTION, "Adjuster section is not present");
        await assert.elementPresent(this.VENDORS_SECTION, "Vendor section is not present");

    }
    async isBOPageDisplayedCorrectly() {
        await assert.elementPresent(this.SUMMARY_SECTION, "Summary section is not present");
        await assert.elementPresent(this.ADJUSTER_SECTION, "Adjuster section is not present");
        await assert.elementPresent(this.VENDORS_SECTION, "Vendor section is not present");

    }
    async isPAPageDisplayedCorrectly() {
        await assert.elementPresent(this.SUMMARY_SECTION, "Summary section is not present");
        await assert.elementPresent(this.ADJUSTER_SECTION, "Adjuster section is not present");
        await assert.elementPresent(this.VENDORS_SECTION, "Vendor section is not present");
    }
    async getClaimSummaryDataFromUI(claimType) {
        var value = [];
        value.push(await this.policy_Number_Value.innerText);
        value.push(await this.account_Number_Value.innerText);
        value.push((await helper.getTextAtLocator(this.claimStatus)).toLowerCase());
       value.push(await helper.getTextAtLocator(this.reporterValue));

        if (claimType == 'WorkersComp') {
             value.push(await helper.getTextAtLocator(this.primaryContactValue));
            var date = new Date(await helper.getTextAtLocator(this.dateNotifiesValue));
            var dateNotified = await helper.formatDate(date);
            value.pop(3);
            value.push(await helper.getTextAtLocator(this.adjusterNameValue));
            value.push(await helper.getTextAtLocator(this.adjusterContactValue));
            value.push(dateNotified);
        }
        if (claimType == 'PersonalAuto') {
            value.push(await helper.getTextAtLocator(this.adjusterNameValue));
            value.push(await helper.getTextAtLocator(this.adjusterContactValue));
            value.push(await helper.getTextAtLocator(this.vehicleMake));
            value.push(await helper.getTextAtLocator(this.vehicleyear));
            value.push(await helper.getTextAtLocator(this.vehicleModel));
        }
        return value;

    }

    async getPartiesInvolvedDataFromUI() {
        var partiesData = [];
        var temp = {};
        var row = await this.PARTIES_INVOLVEMENT_ROW.count;
        for (let i = 0; i < row; i+2) {
            var name = await helper.getTextAtLocator(Selector("[id='partyTableContainer'] tbody td").nth(i));
            var involvement = await helper.getTextAtLocator(Selector("[id='partyTableContainer'] tbody td").nth(i+1));
            var roles = involvement.split(",");
            roles.forEach(element => {
                if (element == 'Witness') {
                    temp.witnessDisplayName = name;
                }
                if (element == 'Covered Party') {
                    temp.CoveredDisplayName = name;
                }
                if (element == 'Insured') {
                    temp.insuredDisplayName = name;
                }
                if (element == 'Main Contact') {
                    temp.mainContactDisplayName = name;
                }
                if (element == 'Reporter') {
                    temp.reporterDisplayName = name;
                }
                if (element == 'Service Vendor') {
                    temp.VendorName = name;
                }
                partiesData.push(temp);
            });
        }
        return partiesData;

    }
    async getClaimSummaryDataFromBackEnd(claimNumber, claimType) {
        var content = await dataFetch.getClaimData(claimNumber);
        var info = [];
        info.push(content.policy.policyNumber);
        info.push(content.policy.accountNumber);
        info.push((content.claimState).toLowerCase());
        info.push(content.mainContact.displayName);
        info.push(content.adjuster.displayName);
        info.push(content.adjuster.phoneNumber);
        if (claimType == 'WorkersComp') {
            var date = new Date(content.lobs.workersComp.dateReportedToEmployer);
            var dateNotified = await helper.formatDate(date);
            info.push(dateNotified);
        }
        if (claimType == 'PersonalAuto') {
            info.push(content.lobs.personalAuto.vehicles[0].make);
            var vehicleYear = content.lobs.personalAuto.vehicles[0].year;
            info.push(vehicleYear.toString());
            info.push(content.lobs.personalAuto.vehicles[0].model);
        }
        return info;
    }
    async getClaimSummaryAgentDataFromBackEnd(claimNumber) {
        var content = await dataFetch.getAgentClaimData(claimNumber);
        var info = [];
        info.push(content.policy.policyNumber);
        info.push(content.policy.accountNumber);
        info.push(content.claimState);
        info.push(content.claimReporter.reportedBy.displayName);
        info.push(content.lossLocation.displayName);
        info.push(content.adjuster.displayName);
        info.push(content.adjuster.phoneNumber);
        info.push(content.lobs.personalAuto.vehicles[0].make);
        info.push((content.lobs.personalAuto.vehicles[0].year).toString());
        info.push(content.lobs.personalAuto.vehicles[0].model);
        return info;
    }
    async isClaimSummaryDataMatchingWithBackEnd(uiValue, backendValue) {
        if (JSON.stringify(uiValue) == JSON.stringify(backendValue))
            return true;
        else
            return false;

    }
    async isClaimSummaryDataForAgentMatchingWithBackEnd(uiValue, backendValue) {
        if (JSON.stringify(uiValue) == JSON.stringify(backendValue))
            return true;
        else
            return false;

    }

    async openDocTab() {
        await helper.click(this.docTab);
    }
    async openNoteTab() {
        await helper.click(this.noteTab);
    }
    async clickPolicyNumber() {
        await helper.click(this.policyLink);
    }
    async clickAccountNumber() {
        await helper.click(this.accountNumberLink);
    }

    async getPartiesInvolvedDataFromBackEnd(claimNumber) {
        var content = await dataFetch.getAgentClaimData(claimNumber);
        var info = [];
        var count = content.relatedContacts.length;
        for (var i = 0; i < count; i++) {
            if (content.relatedContacts[i].displayName == content.mainContact.displayName) {
                info.push(content.relatedContacts[i].displayName);
                var address1 = content.relatedContacts[i].primaryAddress.addressLine1;
                var address2 = content.relatedContacts[i].primaryAddress.addressLine2;
                var city = content.relatedContacts[i].primaryAddress.city;
                var state = content.relatedContacts[i].primaryAddress.state;
                var postal = content.relatedContacts[i].primaryAddress.postalCode;
                var address = address1 + "," + address2.trim() + "," + city + "," + state + postal;
                info.push(address.replace(/\s+/g, ""));
                info.push(content.relatedContacts[i].homeNumber);
                if (content.relatedContacts[i].workNumber == undefined) {
                    info.push("");
                } else {
                    info.push(content.relatedContacts[i].workNumber);
                }
                info.push(content.relatedContacts[i].cellNumber);
                info.push(content.relatedContacts[i].emailAddress1);
            }

        }
        return info;


    }

    async clickInvolvedPartiesByAccountName(claimNumber) {
        var content = await dataFetch.getAgentClaimData(claimNumber);
        var accountName = content.mainContact.displayName;
        var count = await this.accountNameLink.count;
        for (var i = 0; i < count; i++) {
            if (accountName == await helper.getTextAtLocator(this.accountNameLink.nth(i))) {
                await helper.click(this.accountNameLink.nth(i));
            }
        }
    }

    async isClaimSummaryPageLoaded() {
        await assert.elementPresent(this.claimsPage, 'Claim summary page was not loaded');
    }















}


