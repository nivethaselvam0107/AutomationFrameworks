import { Selector, t } from "testcafe";
import Helper from "../../Utilities/Helper";
import Assertion from "../../Utilities/Assertions";

const helper = new Helper();
const assert = new Assertion();

export default class YourHomePage {
  constructor() {
    this.home_Estimation_Value = Selector("#estimatedValueOfHome");
    this.Home_Max_Value_Val_Error = Selector("div[id*='estimatedValueOfHome'][role='alert']");
    this.homeType_Select = Selector("[id='homeType']");
    this.homeType_Option = Selector("[id='homeType'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.specifyWho_OccupiesHouse_Select = Selector("[id='occupiesHome']");
    this.specifyWho_OccupiesHouse_Option = Selector("[id='occupiesHome'] div[class*='TypeaheadMultiSelectField__menu'] div");
    this.distance_FireHydyrant_within500ft = Selector("[id='distanceToFireHydrant'] [class*='left']");
    this.distance_FireStation_within5miles = Selector("[id='distanceToFireStation'] [class*='left']");
    this.commercial_Property_No = Selector("[id='commercialProperty'] [class*='right']");
    this.commercial_Property_Yes = Selector("[id='commercialProperty'] [class*='left']");
    this.fire_OR_FloodHazard = Selector("[id='floodingOfFireHazaed'] [class*='right']");
    this.fireHazard_No = Selector("[id='floodingOfFireHazaed'] [data-value='false']");
    this.fireHazard_Yes = Selector("[id='floodingOfFireHazaed'] [data-value='true']");
    this.location_Type = Selector("#locationType");
    this.residence_Type = Selector("#residenceType");
    this.residence_Type_Select = this.residence_Type.find("option");
  }

  async withHomeEstimationValue(estimationvalue) {
    await helper.typeText(this.home_Estimation_Value, estimationvalue);
    await helper.pressTab();
  }
  async withDistanceToCommercialProperty() {
    await helper.click(this.commercial_Property_Yes);
  }
  async withFireORFloodHazard() {
    await helper.click(this.fireHazard_No);
  }
  async selectDistanceToFireHydrant() {
    await helper.click(this.distance_FireHydyrant_within500ft);
  }
  async selectDistanceToFireStn() {
    await helper.click(this.distance_FireStation_within5miles);
  }
  async withHomeUsageAs(home) {
    await helper.selectDropdown(this.homeType_Select, this.homeType_Option, home);
  }
  async withHomeOccupancy(occupiedhouse) {
    await helper.selectDropdown(this.specifyWho_OccupiesHouse_Select, this.specifyWho_OccupiesHouse_Option, occupiedhouse);
  }
  async setYourHomePageDetails(dataHO) {
    await this.withHomeEstimationValue(dataHO.EstimationHomeValue);
    await this.selectDistanceToFireHydrant();
    await this.selectDistanceToFireStn();
    await this.withDistanceToCommercialProperty();
    await this.withFireORFloodHazard();
    await this.withHomeUsageAs(dataHO.HomeType);
    await this.withHomeOccupancy(dataHO.SpecifyWhoOccupiesHome);
  }
  async isHomeEstimationFieldMarkedWithMAXValueError(text) {
    await assert.assertEqual(
      this.Home_Max_Value_Val_Error.innerText,
      text,
      "Home Estimation is not marked with Max value Error"
    );
  }
  async areYourHomePageFieldsValuesAreSaved(data) {
    await assert.assertEqual((await helper.getValueAttributeFromLocator(this.home_Estimation_Value)).replace(',', ''), parseFloat(data.EstimationHomeValue).toFixed(2), "Home Field value is not matched");
    await assert.assertEqual(await helper.getTextAtLocator(this.location_Type), data.Location, "Location type Field value is not matched");
    await assert.assertEqual(await helper.getTextAtLocator(this.residence_Type), data.Residence, "Residence type Field value is not matched");
    await assert.assertAttributeValue(
      '#distanceToFireHydrant > [class*="ToggleField-module__active"]',
      'data-value',
      data.FireHydrantValue,
      'Incorrect value selected for Distance to Fire Hydrant'
    );
    await assert.assertAttributeValue(
      '#distanceToFireStation > [class*="ToggleField-module__active"]',
      'data-value',
      data.FireStationValue,
      'Incorrect value selected for Distance To Fire Station'
    );
    await assert.assertAttributeValue(
      '#commercialProperty > [class*="ToggleField-module__active"]',
      'data-value',
      data.CommercialValue,
      'Incorrect value selected for Within 300ft of commercial property'
    );
    await assert.assertAttributeValue(
      '#floodingOfFireHazaed > [class*="ToggleField-module__active"]',
      'data-value',
      data.HazardValue,
      'Incorrect value selected for Flooding or Fire Hazard'
    );

    await assert.assertEqual(await helper.getTextAtLocator(this.homeType_Select), data.HomeType, "Home usage value is not matched");
    await assert.assertEqual(await helper.getTextAtLocator(this.specifyWho_OccupiesHouse_Select), data.SpecifyWhoOccupiesHome, "Home occupancy value is not matched");

  }


}
