import { Selector, t } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
const data = require('../Data/PE_Data.json');

const helper = new Helper();
const assert = new Assertion();
export default class AlertHandler {
    constructor() {
        this.popupHeader = Selector("div[class*='modalTitle']");
        this.popupErrorMsg = Selector("div[class*='message'] p");
        this.yesButton = Selector("[class*='modalFooter'] button[class*= 'Button-module__primary']");
        this.noButton = Selector("[role='document'] [class*='Button-module__tertiary']");
        this.popUpCloseBtn = Selector("button[class*='modalButton']");
    
    }
    async isFailedToUploadPopUpDisplayed(){
        await t.wait(3000);
        await assert.assertEqual(this.popupHeader.innerText,'Error','Pop up did not  display for same file upload');
        await assert.assertEqual(this.popupErrorMsg.innerText,'Failed to upload file, either you do not have permission or a file exists with the same name.','Pop up content did not match')
    }
    async clickYes() {
        await helper.click(this.yesButton);
    }
    async clickNo() {
        await helper.click(this.noButton);
    }
    async closeAlert() {
        await helper.click(this.yesButton);
    }
}
