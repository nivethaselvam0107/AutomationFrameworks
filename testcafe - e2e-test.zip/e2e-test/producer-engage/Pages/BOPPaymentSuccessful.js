import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import CommonLocators from '../../Utilities/CommonLocators';
import PolicySummary from '../Pages/PolicySummary';

const helper = new Helper();
const assert = new Assertion();
const commonLocators = new CommonLocators();
const policySummary = new PolicySummary();

export default class BOPPaymentSuccessful {
    constructor() {
        this.accountNum = Selector("[id='accountNumberLink']");
        this.policyNum = Selector("[id='policyNumberLink']");
    }
    async clickPolicyNumber(){
        await helper.click(this.policyNum);
    }
    async validatePolicySummaryPage(){
        var Policy = await helper.getTextAtLocator(this.policyNum);
        await this.clickPolicyNumber();
        await policySummary.validatePolicySummaryPageLoaded(Policy);
    }

    async getPolicyNumber(){
        var policyNumber = await helper.getTextAtLocator(this.policyNum);
        return policyNumber;
    }

}