import { Selector, t ,ClientFunction} from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import moment from 'moment';
import CommonLocators from '../../Utilities/CommonLocators';
const helper = new Helper();
const assert = new Assertion();
const common = new CommonLocators();
var ptype;
var policyTypeicon="img[title="+ptype+"]";
export default class SelectPolicy {
    constructor() {
        this.lossOccurDate = Selector("input[id='lossDateId']");
        this.policyNumberRadio = Selector("[for*='product']");
        this.policyNumList = Selector("table[class*='Table'] tbody td").nth(1);
    }
    async selectPolicy() {
        await helper.click(this.policyNumberRadio);
    }

    async selectPolicyByPolicyType(policyType){
        var policyicon = policyTypeicon.replace(ptype,policyType);
        var policyNumberInputRadio = Selector(policyicon).parent("input[name='PolicyItem']");
        await helper.click(policyNumberInputRadio);
    }
    async removeClaimDateOfLoss(){
        await helper.removeText(this.lossOccurDate);
    }
    async validateNextButtonIsDisabled() {
        await assert.isElementNotClickable(common.nextButton,'disabled','Button is enabled');
    }
    async withClaimDateOfLossInFuture() {
        var date = moment().add(1, 'day');
        var futureDate = date.format('L');
        var currentTime = moment();
        var time = moment(currentTime).format("hh:mm a");
        var DateTime = futureDate+" "+time;
        await helper.typeText(this.lossOccurDate,DateTime);
    }

    async isPolicyListedForSelection(policyNumber){
        var policyNumInList = await helper.getTextAtLocator(this.policyNumList);
        if (policyNumber == policyNumInList){
            return true;
        }else{
            return false;
        }
    }



}