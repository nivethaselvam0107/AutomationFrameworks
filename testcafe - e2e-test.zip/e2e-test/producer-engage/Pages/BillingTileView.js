import { Selector } from 'testcafe'
import Helper from '../../Utilities/Helper';
import Assertion from '../../Utilities/Assertions';
import Tiles from './Tiles';
const tile = new Tiles();
const data = require('../Data/PE_Data.json');
const helper = new Helper();
const assert = new Assertion();

export default class BillingTileview {
    constructor() {
        this.billingAccountNumber = Selector("[id='accountTilesTitleHeader']");
        this.pastdue = Selector("[id*='SummaryPastDue'] span")
        this.totalDue = Selector("[id*='SummaryTotalDue'] span")
        this.currentpayment = Selector("[id*='SummaryCurrentPayment'] span");
        this.collateralrequirement = Selector("[id*='SummaryCollateralRequirement'] span");
        this.collateralheld = Selector("[id*='SummaryCollateralHeld'] span");
        this.policiesheader = Selector("[id*='BillingPolicyOwnedTitleText']");
        this.policynumber = Selector("[class*='digitalRow Table'] th:nth-child(1)");
        this.product = Selector("[class*='digitalRow Table'] th:nth-child(2)");
        this.effectivedate= Selector("[class*='digitalRow Table'] th:nth-child(3)");
        this.expdate = Selector("[class*='digitalRow Table'] th:nth-child(4)");
        this.billedamount = Selector("[class*='digitalRow Table'] th:nth-child(5)");
        this.past = Selector("[class*='digitalRow Table'] th:nth-child(6)");
        this.unbilled = Selector("[class*='digitalRow Table'] th:nth-child(7)");
        this.altbillingacc = Selector("[class*='digitalRow Table'] th:nth-child(8)");
        this.status = Selector("[class*='digitalRow Table'] th:nth-child(9)");
    }
    async validateBillingTileUIComponentsGPA(accountNumber) {
    await assert.textContains(await helper.getTextAtLocator(this.billingAccountNumber),accountNumber,'Billing Account number is not present');
    await assert.assertEqual(await helper.getTextAtLocator(this.pastdue), 'Past Due', 'Past Due is not present');
    await assert.assertEqual(await helper.getTextAtLocator(this.totalDue), 'Total Due', 'Total Due is not present');
    await assert.assertEqual(await helper.getTextAtLocator(this.currentpayment), 'Current Payment', 'Current Payment is not present');
    await assert.assertEqual(await helper.getTextAtLocator(this.collateralrequirement), 'Collateral Requirement', 'Collateral Requirement is not present');
    await assert.assertEqual(await helper.getTextAtLocator(this.collateralheld), 'Collateral Held', 'Collateral Held is not present');
    await assert.assertEqual((await helper.getTextAtLocator(this.policiesheader)).replace(/\t/g, ''), 'Policies Owned by this Account', 'Mismatch in Header: Policies Owned by this Account');
    await assert.assertEqual((await helper.getTextAtLocator(this.policynumber)).replace(/\t/g, ''), 'POLICY NUMBER', 'Mismatch in POLICY Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.product)).replace(/\t/g, ''), 'PRODUCT', 'Mismatch in PRODUCT Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.effectivedate)).replace(/\t/g, ''), 'EFF DATE', 'Mismatch in EFF DATE Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.expdate)).replace(/\t/g, ''), 'EXP DATE', 'Mismatch in EXP DATE Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.billedamount)).replace(/\t/g, ''), 'BILLED AMOUNT', 'Mismatch in BILLED AMOUNT Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.past)).replace(/\t/g, ''), 'PAST DUE', 'Mismatch in PAST DUE Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.unbilled)).replace(/\t/g, ''), 'UNBILLED', 'Mismatch in UNBILLED Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.altbillingacc)).replace(/\t/g, ''), 'ALT BILLING ACCOUNT', 'Mismatch in ALT BILLING ACCOUNT Header');
    await assert.assertEqual((await helper.getTextAtLocator(this.status)).replace(/\t/g, ''), 'STATUS', 'Mismatch in STATUS Header');
    }


}
