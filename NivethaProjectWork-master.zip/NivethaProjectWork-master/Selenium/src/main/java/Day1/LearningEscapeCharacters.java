package Day1;

public class LearningEscapeCharacters{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int integer=07;
		float decimal=21.7f;
		char character='s';
		String string="Nivetha";
		boolean yesorno=false;
		System.out.println("this program is to print the data types");
		System.out.println(integer);
		System.out.println(decimal);
		System.out.println(character);
		System.out.println(string);
		System.out.println(yesorno);
		
		

	}

}
           