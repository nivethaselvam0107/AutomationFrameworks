package codingChallenge;

import java.util.Scanner;

public class Fibonacci {
	public static void main(String[] args)
	{
		int number,n1;
		Scanner scobj= new Scanner(System.in);
		System.out.println("enter the number to find the fibonacci series");
		number=scobj.nextInt();
		
		
	}

}
