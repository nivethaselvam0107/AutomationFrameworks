package explore;

public class Learning_ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
char ascii=30;
int num=ascii;
for (int i=0;i<100;i++)
{
System.out.println(num +":"+"\t"+ascii);
ascii+=1;
num++;
}
	}

}
