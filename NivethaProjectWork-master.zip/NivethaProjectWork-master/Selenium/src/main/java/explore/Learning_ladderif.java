package explore;


public class Learning_ladderif {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String signal ="Orange";
		if (signal=="Orange")
			System.out.println("Get Ready");
		else if(signal=="Green")
			System.out.println("Go");
		else if (signal =="Red")
			System.out.println("Stop");
		else
			System.out.println("switched off. signal is not functioning");
	}
}
