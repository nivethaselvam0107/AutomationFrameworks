package explore;

public class operators{
	public static void main(String [] args) {
	
		String operators="Multiplication";
		int n1=877;
		float n2=67.87f;
		switch(operators)
		{
		case "addition":
			System.out.println("");
		}
	}
	
}

