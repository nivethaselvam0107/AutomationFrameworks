package explore;

public class Learning_ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
long n=358764589;
if (n%2==0)
	System.out.println("The number is even"+n);
else
	System.out.println("The number is odd:"+"\t"+n);
	}
}
