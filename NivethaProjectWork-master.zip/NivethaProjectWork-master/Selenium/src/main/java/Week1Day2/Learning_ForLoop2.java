package Week1Day2;

public class Learning_ForLoop2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<=1000;i=i+2) {
			System.out.println(i);
		}

	}

}
