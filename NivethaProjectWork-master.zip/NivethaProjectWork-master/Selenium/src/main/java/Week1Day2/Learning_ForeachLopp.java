package Week1Day2;

public class Learning_ForeachLopp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []digits= {234,42,68,96,26,95};
		for(int sum:digits) {
			System.out.println(sum);
			sum=sum;
		}
	}

}
