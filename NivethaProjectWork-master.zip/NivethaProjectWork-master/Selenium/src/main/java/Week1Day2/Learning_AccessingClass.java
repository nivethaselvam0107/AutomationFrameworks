package Week1Day2;

public class Learning_AccessingClass {

	public int addition(int n1, int n2) {
		return(n1+n2);
	}
	 int subtraction(int n1, int n2) {
		return(n1-n2);
	}
	 int multiplication(int n1, int n2) {
		return(n1*n2);
	}
	private int divide(int n1,int n2) {
		return(n1/n2);
	}

	public static void main(String[] args) {
		//System.out.println(addition(4,7));
		//System.out.println(subtraction(30,27));
		//System.out.println(multiplication(34,2));
		//System.out.println(divide(72,5));

	}


}
