import Login from '../pages/loginPage';
import navBar from '../pages/navBar';
import AccountsLanding from '../pages/accountsLanding';
import PolicyLanding from '../pages/policyLanding';
import ClaimsLanding from '../pages/claimsLanding';
import ActivitiesLanding from '../pages/activitiesLanding';
import AgentDashboard from '../pages/agentDashboard';

const login = new Login();
const nav = new navBar();
const accountsLanding = new AccountsLanding();
const policiesLanding = new PolicyLanding();
const claimsLanding = new ClaimsLanding();
const activitiesLanding = new ActivitiesLanding();
const dashboard = new AgentDashboard();

fixture`Landing Page`;
test('TC3296: Verify Account landing page in gateway ', async t => {
    await login.login();
    await nav.goToAccountsLanding();
    await accountsLanding.checkTitle();
    await accountsLanding.checkDefaultTile();
});

test('TC3297: Verify Policy landing page in gateway', async t => {
    await login.login();
    await nav.goToPoliciesLanding();
    await policiesLanding.checkTitle();
    await policiesLanding.checkDefaultTile();
});
test('TC3298: Verify Claims landing page in gateway', async t => {
    await login.login();
    await nav.goToClaimsLanding();
    await claimsLanding.checkTitle();
    await claimsLanding.checkDefaultTile();
});
test('TC3299: Verify Activities landing page in gateway', async t => {
    await login.login();
    await nav.goToActivitiesLanding();
    await activitiesLanding.checkTitle();
    await activitiesLanding.checkDefaultTile();
});

test('TC3306 : Verify user can view activities under Activites list on Dashboard', async t => {
    await login.login();
    await dashboard.verifyActivitiesForNext7daySections();
});
