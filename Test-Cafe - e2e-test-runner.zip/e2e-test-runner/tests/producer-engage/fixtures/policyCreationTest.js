import Login from '../../utilities/Login';
import NavBar from '../pages/NavBar';
import AccountSearch from '../pages/AccountSearch';
import AccountCreate from '../pages/AccountCreate';
import QualificationPage from '../../quote-and-buy/Pages/QualificationPage';
import DriversPage from '../../quote-and-buy/Pages/DriversPage';
import VehiclesPage from '../../quote-and-buy/Pages/VehiclesPage';
import CommonLocators from '../../utilities/CommonLocators';
const data = require('../data/policyCreationSampleData.json');
const dataQnB = require('../../quote-and-buy/data/QnB_PA_Data.json');

const login = new Login();
const nav = new NavBar();
const accountsearch = new AccountSearch();
const accountcreate = new AccountCreate();
const qualipage = new QualificationPage();
const driverspage = new DriversPage();
const vehicles = new VehiclesPage();
const common = new CommonLocators();
var firstName = data.FirstName.toUpperCase();
var lastName = data.LastName.toUpperCase();

fixture`Policy Creation`
test('Mandatory Validation for Vehicles page on Personal Auto', async t => {
   await login.login();
   await nav.clickStartNewQuote();
   await accountsearch.clickPersonal();
   await accountsearch.typeFirstName(data.FirstName);
   await accountsearch.typeLastName(data.LastName);
   await accountsearch.clickSearchButton();
   await accountsearch.clickContinueAsNewcustomer();
   await accountcreate.typeAddressLine1(data.AddressLine1);
   await accountcreate.typeCity(data.City);
   await accountcreate.typeZipCode(data.Zip);
   await accountcreate.selectState(data.State);
   await accountcreate.selectProducerCode(data.ProducerCode);
   await accountcreate.clickNext();
   await accountcreate.selectNewState(data.State);
   await accountcreate.selectnewProducerCode(data.ProducerCode);
   await accountcreate.selectProductCode(data.ProductCode);
   await accountcreate.clickSubmit(); // Account Creation Successful.
   await qualipage.validateAccountName(`${firstName}` + " " + `${lastName}`);
   await qualipage.selectCurrentlyInsured(dataQnB.InsuranceStatus);
   await common.goNext();
   await driverspage.typeDOB(dataQnB.DriverDOB)
   await driverspage.selectLicenseState(dataQnB.DriverLicenseState);
   await driverspage.selectLicenseYear(dataQnB.FirstYearLicensed);
   await driverspage.typeLicenseNumber(dataQnB.DriverLicenseNum);
   await common.goNext();
   //Validate if mandatory asterisk are available in Vehicles page
   await vehicles.areVehiclePageFieldsMarkedWithAsterisk();
})
