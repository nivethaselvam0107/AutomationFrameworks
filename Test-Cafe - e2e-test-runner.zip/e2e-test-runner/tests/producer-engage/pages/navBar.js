import { Selector } from 'testcafe';
import Helper from '../../utilities/helper';

const helper = new Helper();

export default class NavBar {
    constructor() {
        this.startNewQuote = Selector("div[class*='startNewQuote']");
        this.accountTab = Selector("[class*='gw-horizontal'] [ui-sref='accounts.index']");
        this.policiesTab = Selector("[class*='gw-horizontal'] [ui-sref='policies.index']");
        this.claimTab = Selector("[class*='gw-horizontal'] [ui-sref='claims']");
        this.activities = Selector("[class*='gw-horizontal'] [ui-sref='activities.index']");

    }

    async clickStartNewQuote() {
        await helper.click(this.startNewQuote);
    }
    async goToAccountsLanding() {
        await helper.click(this.accountTab);
    }
    async goToPoliciesLanding() {
        await helper.click(this.policiesTab);
    }
    async goToClaimsLanding() {
        await helper.click(this.claimTab);
    }
    async goToActivitiesLanding() {
        await helper.click(this.activities);
    }

}
