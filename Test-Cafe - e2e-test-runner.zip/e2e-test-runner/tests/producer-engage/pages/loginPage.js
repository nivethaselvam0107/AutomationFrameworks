/* eslint-disable */
import { Selector, Role, t } from 'testcafe';
import Helper from '../../utilities/helper';
const data = require('../data/loginSampleData.json5');
const helper = new Helper();
const username = Selector("input[ng-model*='username']");
const password = Selector("input[ng-model*='password']");
const signin = Selector("button[ng-click*='login']");
const url = process.env.TEST_ENV_URL;

const role = Role(url, async t => {
    await t.maximizeWindow();
    await helper.typeText(username, data.username);
    await helper.typeText(password, data.password);
    await helper.click(signin);
}, { preserveUrl: true });

export default class LoginPage {
    async login() {
        await t.useRole(role);
    }
}
