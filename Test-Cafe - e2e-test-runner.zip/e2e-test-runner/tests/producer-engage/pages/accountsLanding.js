import { Selector } from 'testcafe'
import Assertions from '../../utilities/Assertions';
const data = require('../data/landingPageSampleData.json5');

const assert = new Assertions();

export default class AccountsLanding {
    constructor() {
        this.title = Selector("h1");
        this.defaultTitle = Selector("div[class*='gw-tile-title']");

    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.accountsTitle,'Accounts landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, data.defaultTitle,'Recently Viewed is not default tile');
    }
}
