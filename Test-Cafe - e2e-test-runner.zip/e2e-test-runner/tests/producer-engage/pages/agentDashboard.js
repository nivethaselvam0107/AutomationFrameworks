import { Selector } from 'testcafe'
import Helper from '../../utilities/helper'
import Assertions from '../../utilities/assertions';

const helper = new Helper();
const assert = new Assertions();

export default class AgentDashboard {
    constructor() {
        this.expand_activity_button = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-expand-activity]");
        this.activities_for_next_7_days = Selector("[gw-test-gateway-activityscheduledirective-activity-schedule-open-activities-for-next-7-days]");
        this.activity_priority = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-priority]");
        this.activity_duedate = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-due-to-date]");
        this.activity_subject = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-subject]");
        this.activity_assignedTo = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-assigned-to]");
        this.activity_note = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-notes]");
        this.activity_status = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-status]");
        this.activity_details = Selector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-details]");
    }

    async expandFirstActivity() {
        await helper.click(this.expand_activity_button.nth(1));
    }

    async verifyActivitiesForNext7daySections() {
        await assert.elementPresent(this.activities_for_next_7_days, 'Activities for next 7 days are not Present');
        await assert.elementPresent(this.activity_priority, 'Priority is not Present');
        await assert.elementPresent(this.activity_duedate, 'Due Date is not Present');
        await assert.elementPresent(this.activity_status, 'Status is not Present');
        await assert.elementPresent(this.activity_assignedTo, 'Assigned to is not Present');
        await assert.elementPresent(this.activity_note, 'Notes are not Present');
        await assert.elementPresent(this.activity_subject, 'Subject is not Present');

    }
}
