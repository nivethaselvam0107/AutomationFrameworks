import { Selector } from 'testcafe'
import Assertions from '../../utilities/assertions';
const data = require('../data/landingPageSampleData.json5');

const assert = new Assertions();

export default class ActivitiesLanding {
    constructor() {
        this.title = Selector("h1[class*='gw-titles-title']");
        this.defaultTitle = Selector("div[class*='gw-tile-title']");
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.activitiesTitle,'Activities landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText, data.activitiesDefaultTitle,'Your Open is not default tile');
    }
}
