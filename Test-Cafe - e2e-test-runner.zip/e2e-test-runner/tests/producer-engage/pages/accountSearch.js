import { Selector } from 'testcafe';
import Helper from '../../utilities/helper'

const helper = new Helper();

export default class AccountSearch {
    constructor() {
        this.commercial = Selector("label[for*='company'][class='gw-first']");
        this.personal = Selector("label[for*='person'][class='gw-second']");
        this.firstName = Selector("div[model*='firstName'] [type='text']");
        this.lastName = Selector("div[model*='lastName'] [type='text']");
        this.searchButton = Selector("button[value='Search']");
        this.createNewAccount = Selector("button[ng-click*='newQuote']");
    }

    async clickCommercial() {
        await helper.click(this.commercial);
    }
    async clickPersonal() {
        await helper.click(this.personal);
    }
    async typeFirstName(firstname) {
        await helper.typeText(this.firstName, firstname)
    }
    async typeLastName(lastname) {
        await helper.typeText(this.lastName, lastname)
    }
    async clickSearchButton() {
        await helper.click(this.searchButton);
    }
    async clickContinueAsNewcustomer() {
        await helper.click(this.createNewAccount);
    }
}
