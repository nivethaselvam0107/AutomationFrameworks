import { Selector } from 'testcafe'
import Assertions from '../../utilities/assertions';
const data = require('../data/landingPageSampleData.json5');

const assert = new Assertions();

export default class PolicyLanding {
    constructor() {
        this.title = Selector("h1[class*='gw-titles-title']");
        this.defaultTitle = Selector("div[class*='gw-tile-title']");
    }
    async checkTitle() {
        await assert.elementPresent(this.title, 'Title is not present');
        await assert.assertEqual(this.title.innerText, data.policyTitle,'Policies landing page title mismatch');
    }

    async checkDefaultTile() {
        await assert.assertEqual(this.defaultTitle.innerText,data.defaultTitle,'Recently Viewed was not default tile');
    }
}
