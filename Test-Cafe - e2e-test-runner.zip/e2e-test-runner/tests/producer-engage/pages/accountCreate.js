import { Selector } from 'testcafe';
import Helper from '../../utilities/helper';

const helper = new Helper();

export default class AccountCreate {
    constructor() {
        this.addressLine1 = Selector("gw-pl-input-ctrl[model*='addressLine1'] [type='text']");
        this.city = Selector("gw-pl-input-ctrl[model*='city'] [type='text']");
        this.zipCode = Selector("gw-pl-input-ctrl[model*='postalCode'] [type='text']");

        this.state_select = Selector("div[gw-viewmodel-ref='primaryAddress.state'] [class*='select']");
        this.state_option = this.state_select.find('option');

        this.producerCode_select = Selector("select[name='ProducerCode']");
        this.producerCode_option = this.producerCode_select.find('option');

        this.nextButton = Selector("button[type='submit']");

        this.newsub_state_select = Selector("select[gw-pl-select*='newSubmissionView.state.value']");
        this.newsub_state_option = this.newsub_state_select.find('option');

        this.newsub_producerCode_select = Selector("select[id='ProducerCode']");
        this.newsub_producerCode_option = this.newsub_producerCode_select.find('option');

        this.productCode_select = Selector("select[id='ProductCode']");
        this.productCode_option = this.productCode_select.find('option');

        this.submitButton = Selector("button[ng-click*='onClick()'][type*='submit']");
    }

    async typeAddressLine1(addressLine1) {
        await helper.typeText(this.addressLine1, addressLine1);
    }

    async typeCity(city) {
        await helper.typeText(this.city, city);
    }

    async typeZipCode(zipcode) {
        await helper.typeText(this.zipCode, zipcode);
    }

    async selectState(option) {
        await helper.selectDropdown(this.state_select, option);
    }

    async selectProducerCode(option) {
        await helper.selectDropdown(this.producerCode_select, option);
    }

    async clickNext() {
        await helper.click(this.nextButton);
    }

    async selectNewState(option) {
        await helper.selectDropdown(this.newsub_state_select, option);
    }

    async selectnewProducerCode(option) {
        await helper.selectDropdown(this.newsub_producerCode_select, option);
    }

    async selectProductCode(option) {
        await helper.selectDropdown(this.productCode_select, option);
    }

    async clickSubmit() {
        await helper.click(this.submitButton);
    }
}
