import { Selector, t } from 'testcafe';

export default class Assertion {
    async assertEqual(actual, expected, message) {
        await t.expect(actual)
            .eql(expected, message);
    }

    async assertNotEqual(actual, expected, message) {
        await t.expect(actual)
            .notEql(expected, message);
    }

    async assertContains(actual, expected, message) {
        await t.expect(actual)
            .contains(expected, message);
    }

    async elementPresent(locator, message) {
        await t.expect(locator.exists)
            .ok(message);
    }

    async elementNotPresent(locator) {
        await t.expect(locator.exists).notOk(`Error: The element ${locator} exists when it should not`);
    }

    async assertAttributeValue(element, attribute, expected, message) {
        const attributeValue = await Selector(element).getAttribute(attribute);
        await this.assertEqual(attributeValue, expected, message);
    }
}
