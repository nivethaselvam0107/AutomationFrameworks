import { Selector } from 'testcafe';
import Helper from './helper';
import Assertions from '../utilities/assertions';

const helper = new Helper();
const assert = new Assertions();

export default class CommonLocators {
    constructor() {
        this.nextButton = Selector('#gw-wizard-Next');
        this.cancelButton = Selector('#gw-wizard-cancel');
        this.previousButton = Selector('#gw-wizard-previous');
        this.selectedDate = Selector('div.react-datepicker__day--selected');
    }

    async goNext() {
        await helper.click(this.nextButton);
    }

    async goPrevious() {
        await helper.click(this.previousButton);
    }

    async clickCancel() {
        await helper.click(this.cancelButton);
    }

    async isNextButtonDisabled(expectedButtonState) {
        await assert.assertEqual(this.nextButton.hasAttribute('disabled'), expectedButtonState);
    }
}
