import { t, Selector, ClientFunction } from 'testcafe';

export default class Helper {

    getLocation = ClientFunction(() => document.location.href);

    // Type Text
    async typeText(locator, textValue) {
        await t.typeText(locator, textValue, {
            replace: true
        });
    }

    async removeText(locator) {
        await t.selectText(locator).pressKey('delete');
    }

    async pressKey(key) {
        await t.pressKey(key);
    }

    // Click
    async click(locator) {
        await t.click(locator);
    }

    // Select Dropdown
    async selectDropdown(locatorSelect, selection) {
        const selectedOption = locatorSelect.find('div[class*=option]').withText(selection);
        await t.click(locatorSelect);
        await t.click(selectedOption);
    }

    // Select button option
    async selectButtonOption(selector, option) {
        const optionToSelect = selector.withAttribute('data-value', option);
        await t.click(optionToSelect);
    }

    async clickButtonWithText(textValue) {
        const buttonWithText = Selector('button').withText(textValue);
        await this.click(buttonWithText);
    }

    async getAlertMessage(selectorWithAlert) {
        await Selector(selectorWithAlert);
        return Selector(selectorWithAlert).sibling().innerText;
    }

    async removeRequiredTextAndValidate(fieldSelector) {
        await this.removeText(fieldSelector);
        await this.pressKey('tab');
        await this.pressKey('esc');
        await t.expect(
            await this.getAlertMessage(fieldSelector)
        ).eql('This is a required field', `Incorrect alert message displayed for required field${fieldSelector}`);
    }

    async verifyNextIsGrayedOut() {
        await t.expect(Selector('#gw-wizard-Next').hasAttribute('disabled'))
            .eql(true, 'Next is not grayed out');
    }
}
