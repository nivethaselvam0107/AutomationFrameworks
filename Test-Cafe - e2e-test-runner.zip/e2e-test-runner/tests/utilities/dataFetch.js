import { JsonRPCService } from 'gw-portals-transport-js';

/**
 * This file is where all communication calls with the server should take place
 */
export default {
    async getQuoteData(zipCode, submissionNumber) {
        const endpoint = `${process.env.TEST_ENV_URL}/quote/quote`;
        const dataObj = {
            quoteID: submissionNumber,
            postalCode: zipCode
        };
        return JsonRPCService.send(endpoint, 'retrieve', [dataObj]);
    }
};
