import LandingPage from '../../pages/common/landingPage';
import commonSampleData from '../../data/common/sampleData.json5';
import YourInfoPage from '../../pages/pa/yourInfoPage';
import paSampleData from '../../data/pa/sampleData.json5';
import QualificationPage from '../../pages/pa/qualificationPage';
import DriverPage from '../../pages/pa/driverPage';
import VehiclePage from '../../pages/pa/vehiclesPage';
import QuotePage from '../../pages/pa/quotePage';
import PolicyInformationPage from '../../pages/pa/policyInformationPage';

const moment = require('moment');

const landingPage = new LandingPage();
const yourInfoPage = new YourInfoPage();
const qualPage = new QualificationPage();
const driverPage = new DriverPage();
const vehiclePage = new VehiclePage();
const quotePage = new QuotePage();
const policyInfoPage = new PolicyInformationPage();

let periodStartDate = moment();
// 'l' argument is moment alias for formatting MM/DD/YYYY
periodStartDate = periodStartDate.format('l');

const TEST_URL = process.env.TEST_ENV_URL;
fixture`Quote and Buy Landing Page`
    .page`${TEST_URL}`;

// FIXME: https://guidewirejira.atlassian.net/browse/BASDA-1690
test.skip('PA Quote Coverage Update', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    await qualPage.checkDefaultFieldsShowOnQualificationPage();
    await qualPage.fillRequiredFields(
        paSampleData.currentlyInsured.label
    );
    await qualPage.pressNextButton();
    await driverPage.checkDefaultFieldsShowOnDriverPage();
    await driverPage.fillRequiredFields(
        paSampleData.defaultDriverGender,
        paSampleData.defaultDriverLicenseNumber,
        paSampleData.defaultDriverLicenseState,
        paSampleData.defaultDriverYearFirstLicensed
    );
    await driverPage.pressNextButton();
    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
    await vehiclePage.fillAllFields(
        paSampleData.vehicle1Vin,
        paSampleData.vehicle1LicensePlate,
        paSampleData.vehicle1State,
        paSampleData.vehicle1CostNew
    );
    await vehiclePage.pressNextButton();
    await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.checkAllCoveragesUnchecked();
    await quotePage.pressPremiumRecalculationButton();
    await quotePage.pressPremiumButton();
    await policyInfoPage.pressPreviousButton();
    await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.checkBasicRecalculationButton();
    await quotePage.checkStandardRecalculationButton();
}).meta({
    DigitalTestcaseID: 'TC6489',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});
