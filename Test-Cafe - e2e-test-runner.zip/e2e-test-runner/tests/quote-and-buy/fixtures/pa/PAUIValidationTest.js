import { t } from 'testcafe';
import LandingPage from '../../pages/common/landingPage';
import YourInfoPage from '../../pages/pa/yourInfoPage';
import paSampleData from '../../data/pa/sampleData.json5';
import commonSampleData from '../../data/common/sampleData.json5';
import QualificationPage from '../../pages/pa/qualificationPage';
import DriverPage from '../../pages/pa/driverPage';
import VehiclePage from '../../pages/pa/vehiclesPage';
import QuotePage from '../../pages/pa/quotePage';
import PolicyInformationPage from '../../pages/pa/policyInformationPage';
import PaymentDetailsPage from '../../pages/pa/paymentDetailsPage';
import SuccessDetailsPage from '../../pages/pa/successDetailsPage';
import dataFetch from '../../../utilities/dataFetch';
import Assertions from '../../../utilities/assertions';
import QuoteInfoBar from '../../pages/common/quoteInfoBar';

const moment = require('moment');

const landingPage = new LandingPage();
const yourInfoPage = new YourInfoPage();
const qualPage = new QualificationPage();
const driverPage = new DriverPage();
const vehiclePage = new VehiclePage();
const quotePage = new QuotePage();
const policyInfoPage = new PolicyInformationPage();
const paymentPage = new PaymentDetailsPage();
const successPage = new SuccessDetailsPage();
const quoteInfoBar = new QuoteInfoBar();
const assert = new Assertions();

let periodStartDate = moment();
// 'l' argument is moment alias for formatting MM/DD/YYYY
periodStartDate = periodStartDate.format('l');

const TEST_URL = process.env.TEST_ENV_URL;
fixture`PAUIValidationTest`.page`${TEST_URL}`;

test('PA - Landing Page Mandatory Zip Code Validation', async () => {
    await landingPage.startQuote('PersonalAuto', '');
    await landingPage.checkPANoZipCodeAlertMessage();
}).meta({
    DigitalTestcaseID: 'TC4761',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('PA Qualification Page Loading', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    await qualPage.checkDefaultFieldsShowOnQualificationPage();
    await qualPage.fillAllFields(
        paSampleData.currentlyInsured.label,
        paSampleData.licenseSuspended,
        paSampleData.licenseCancelled,
        paSampleData.convictedForMovingTrafficViolationsInLast3Years,
        paSampleData.coverageCancelledDeclinedOrNonRenewedInLast3Years
    );
    await qualPage.confirmNoIsSelected();
    await qualPage.pressNextButton();
    await driverPage.checkDefaultFieldsShowOnDriverPage();
}).meta({
    DigitalTestcaseID: 'TC5651',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('PA Quote Coverage Update', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    await qualPage.checkDefaultFieldsShowOnQualificationPage();
    await qualPage.fillRequiredFields(
        paSampleData.currentlyInsured.label
    );
    await qualPage.pressNextButton();
    await driverPage.checkDefaultFieldsShowOnDriverPage();
    await driverPage.fillRequiredFields(
        paSampleData.defaultDriverGender,
        paSampleData.defaultDriverLicenseNumber,
        paSampleData.defaultDriverLicenseState,
        paSampleData.defaultDriverYearFirstLicensed
    );
    await driverPage.pressNextButton();
    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
    await vehiclePage.fillAllFields(
        paSampleData.vehicle1Vin,
        paSampleData.vehicle1LicensePlate,
        paSampleData.vehicle1State,
        paSampleData.vehicle1CostNew
    );
    await vehiclePage.pressNextButton();
    await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.pressBasicButton();
    await policyInfoPage.checkDefaultFieldsShowOnPolicyInformationPage();
    await policyInfoPage.fillRequiredFields(
        commonSampleData.phoneNumber
    );
    await policyInfoPage.pressNextButton();
    await t.wait(5000);
    await paymentPage.checkDefaultFieldsShowOnPaymentDetailsPage();
    await paymentPage.fillRequiredFields(
        paSampleData.paymentMethod,
        paSampleData.bankAccountNumber,
        paSampleData.routingNumber,
        paSampleData.bankName
    );
    await paymentPage.pressNextButton();
    await successPage.checkDefaultFieldsShowOnSuccessDetailsPage();
    await successPage.checkOpenAccordion();
}).meta({
    DigitalTestcaseID: 'TC5659',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('PA Your Information page - Save Point', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    const submissionId = await quoteInfoBar.getQuoteID();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await yourInfoPage.verifyYourInformation(
        response,
        submissionId,
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        commonSampleData.state.value,
        paSampleData.dateOfBirth,
        'Draft'
    );
}).meta({
    DigitalTestcaseID: 'TC5648',
    Regression: 'true',
    Platform: 'all',
    Application: 'PA'
});

// currently this test only checks the required fields on the Driver page
test.skip('PA - Verify Vehicles page - Save Point', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    await qualPage.checkDefaultFieldsShowOnQualificationPage();
    await qualPage.fillAllFields(
        paSampleData.currentlyInsured.label,
        paSampleData.licenseSuspended,
        paSampleData.licenseCancelled,
        paSampleData.convictedForMovingTrafficViolationsInLast3Years,
        paSampleData.coverageCancelledDeclinedOrNonRenewedInLast3Years
    );
    await qualPage.pressNextButton();
    await driverPage.checkDefaultFieldsShowOnDriverPage();
    await driverPage.fillAllFields(
        paSampleData.defaultDriverFirstName,
        paSampleData.defaultDriverLastName,
        paSampleData.defaultDriverDateOfBirth,
        paSampleData.defaultDriverGender,
        paSampleData.defaultDriverLicenseNumber,
        paSampleData.defaultDriverLicenseState,
        paSampleData.defaultDriverYearFirstLicensed
    );
    await driverPage.pressNextButton();
    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
    await vehiclePage.fillAllFields(
        paSampleData.vehicle1Vin,
        paSampleData.vehicle1LicensePlate,
        paSampleData.vehicle1State,
        paSampleData.vehicle1CostNew
    );
    await vehiclePage.pressNextButton();
    const submissionId = await quoteInfoBar.getQuoteID();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await yourInfoPage.verifyYourInformation(
        response,
        submissionId,
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        commonSampleData.state.value,
        paSampleData.dateOfBirth,
        'Quoted'
    );
    await qualPage.verifyQualificationInputs(
        response,
        paSampleData.currentlyInsured.value,
        paSampleData.licenseSuspended,
        paSampleData.licenseCancelled,
        paSampleData.convictedForMovingTrafficViolationsInLast3Years,
        paSampleData.coverageCancelledDeclinedOrNonRenewedInLast3Years
    );
    await driverPage.verifyDriverDetails(
        response,
        paSampleData.defaultDriverGender,
        paSampleData.defaultDriverLicenseNumber,
        paSampleData.defaultDriverLicenseStateID,
        paSampleData.defaultDriverYearFirstLicensed
    );
    await vehiclePage.verifyVehicleData(
        response,
        paSampleData.vehicle1Vin,
        paSampleData.vehicle1Make,
        paSampleData.vehicle1Model,
        paSampleData.vehicle1Year,
        paSampleData.vehicle1LicensePlate,
        paSampleData.vehicle1StateID,
        paSampleData.vehicle1CostNew
    );
}).meta({
    DigitalTestcaseID: 'TC5654',
    Regression: 'true',
    Platform: 'all',
    Application: 'PA'
});

// FIXME - Skipping test due to a failure because of ID's using the iterable component
test.skip('PA Additional Drivers Page Mandatory Fields Validation', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.pressNextButton();
    await qualPage.checkDefaultFieldsShowOnQualificationPage();
    await qualPage.fillRequiredFields(
        paSampleData.currentlyInsured.label
    );
    await qualPage.pressNextButton();
    await driverPage.checkDefaultFieldsShowOnDriverPage();
    await driverPage.fillRequiredFields(
        paSampleData.defaultDriverGender,
        paSampleData.defaultDriverLicenseNumber,
        paSampleData.defaultDriverLicenseState,
        paSampleData.defaultDriverYearFirstLicensed
    );
    await driverPage.pressAddDriverButton();
    await driverPage.checkNextButtonIsGreyedOut();
    await driverPage.AddExtraDriverAndVerifyNextGreyedOut(
        paSampleData.additionalDriverFirstName,
        paSampleData.additionalDriverLastName,
        paSampleData.additionalDriverDateOfBirth,
        paSampleData.additionalDriverGender,
        paSampleData.additionalDriverLicenseNumber,
        paSampleData.additionalDriverLicenseState,
        paSampleData.additionalDriverYearFirstLicensed,
    );
    await driverPage.pressNextButton();
    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
}).meta({
    DigitalTestcaseID: 'TC5679',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('PA Verify user can not move forward in wizard', async () => {
    await landingPage.startQuote('PersonalAuto', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillYourInfoData(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        paSampleData.dateOfBirth,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.testQuoteNav();
    await assert.elementNotPresent(quotePage.paQuoteTitle);
}).meta({
    DigitalTestcaseID: 'TC5668',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('TC4762 PA - invalid ZIP code on landing page', async () => {
    await landingPage.startQuote('PersonalAuto', '000');
    await landingPage.checkPAZipCodeAlertMessage();
}).meta({
    DigitalTestcaseID: 'TC4762',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});
