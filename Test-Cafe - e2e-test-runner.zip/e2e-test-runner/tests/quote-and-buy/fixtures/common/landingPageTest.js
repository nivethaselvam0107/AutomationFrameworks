import LandingPage from '../../pages/common/landingPage';

const landingPage = new LandingPage();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`Quote and Buy Landing Page`
    .page`${TEST_URL}`;

test('Default fields and components render on load', async () => {
    await landingPage.checkDefaultFieldsShowOnLandingPage();
}).meta({Regression: 'true' , Platform: 'all', Application : "QnB" });

test('Correct fields and components render when personal/business toggle is selected', async () => {
    await landingPage.clickBusinessOptionInToggle();
    await landingPage.checkBusinessFieldsShow();

    await landingPage.clickPersonalOptionInToggle();
    await landingPage.checkPersonalFieldsShow();
}).meta({Regression: 'true' , Platform: 'all', Application : "QnB" });

test('Inline error message is shown when start quote is selected without entering a zip code', async () => {
    await landingPage.startPAQuote();
    await landingPage.checkPANoZipCodeAlertMessage();

    await landingPage.startHOQuote();
    await landingPage.checkHONoZipCodeAlertMessage();

    await landingPage.clickBusinessOptionInToggle();

    await landingPage.startBOPQuote();
    await landingPage.checkBopNoZipCodeAlertMessage();
}).meta({Regression: 'true' , Platform: 'all', Application : "QnB" });

test('Retrieve Quote default fields show for each LOB', async () => {
    await landingPage.clickRetrieveQuoteLink('PersonalAuto');
    await landingPage.checkRetrieveQuoteFieldsShow();
    await landingPage.cancelRetrieveQuote();

    await landingPage.clickRetrieveQuoteLink('HomeOwners');
    await landingPage.checkRetrieveQuoteFieldsShow();
    await landingPage.cancelRetrieveQuote();

    await landingPage.clickBusinessOptionInToggle();

    await landingPage.clickRetrieveQuoteLink('BusinessOwners');
    await landingPage.checkRetrieveQuoteFieldsShow();
    await landingPage.cancelRetrieveQuote();
}).meta({Regression: 'true' , Platform: 'all', Application : "QnB" });
