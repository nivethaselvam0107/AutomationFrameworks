import { RequestLogger } from 'testcafe';
import LandingPage from '../../pages/common/landingPage';
import YourInfoPage from '../../pages/bop/yourInfoPage';
import commonSampleData from '../../data/common/sampleData.json5';
import bopSampleData from '../../data/bop/sampleData.json5';
import QualificationPage from '../../pages/bop/qualificationPage';
import GeneralCoveragesPage from '../../pages/bop/generalCoveragesPage';
import AdditionalCoveragesPage from '../../pages/bop/additionalCoveragesPage';
import LocationsAndBuildingsPage from '../../pages/bop/locationsAndBuildingsPage';
import PolicyInformationPage from '../../pages/bop/policyInformationPage';
import AdditionalInformationPage from '../../pages/bop/additionalInformationPage';
import QuotePage from '../../pages/bop/quotePage';
import PaymentDetailsPage from '../../pages/common/paymentDetailsPage';

const landingPage = new LandingPage();
const yourInfoPage = new YourInfoPage();
const qualificationPage = new QualificationPage();
const generalCoveragesPage = new GeneralCoveragesPage();
const additionalCoveragesPage = new AdditionalCoveragesPage();
const locationsAndBuildingsPage = new LocationsAndBuildingsPage();
const policyInformationPage = new PolicyInformationPage();
const quotePage = new QuotePage();
const paymentDetailsPage = new PaymentDetailsPage();
const additionalInformationPage = new AdditionalInformationPage();
const logger = RequestLogger({ url: `${process.env.TEST_ENV_URL}/quote/quote`, method: 'post' }, {
    logResponseHeaders: true,
    logRequestBody: true,
    logResponseBody: true,
    stringifyRequestBody: true
});
const moment = require('moment');

let periodStartDate = moment();
periodStartDate = periodStartDate.format('l');


fixture`BOP Validation tests`
    .page(process.env.TEST_ENV_URL);

test('Verify invalid ZIP code for BOP', async () => {
    await landingPage.startQuote('BusinessOwners', '0');
    await landingPage.checkBopZipCodeAlertMessage();
}).meta({
    DigitalTestcaseID: 'TC3318',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('BOP Remove Primary Location', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3
    );
    let tomorrowDate = moment().add(1, 'days');
    // 'l' argument is moment alias for formatting MM/DD/YYYY
    tomorrowDate = tomorrowDate.format('l');
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        tomorrowDate
    );
    await yourInfoPage.yourInfoNext();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.verifyPrimaryDeleteIconIsNotPresent();
}).meta({
    DigitalTestcaseID: 'TC4239',
    PortfolioTestcaseID: 'PORT-2692',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('Going back in the wizard with a Business Owners policy', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
    );
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        periodStartDate
    );
    await yourInfoPage.yourInfoNext();
    await qualificationPage.clickYesForLeasedAndCompCarried();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.changeCoverages(
        bopSampleData.liability.pdDeductible,
        bopSampleData.specialCoveragePackages.option,
        bopSampleData.policywidePropertyDeductible.optionCoveragesDeductible,
        bopSampleData.policywidePropertyDeductible.causeOfLoss
    );
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.selectAdditionalComputerCoverages(
        bopSampleData.crimeComputerFundsTransferFraud.limit,
        bopSampleData.professionsPrintersErrorsAndOmissions.grossSales
    );
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.addBuilding(
        bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionType,
        bopSampleData.numberStories,
        bopSampleData.totalArea,
        bopSampleData.percentSprinkled,
        bopSampleData.alarmType,
        bopSampleData.businessPersonalPropertyLimit,
        bopSampleData.buildingLimit
    );
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    await yourInfoPage.clickSideBarYourInfo();
    await yourInfoPage.verifyYourInfoDataIsRetained(
        commonSampleData.companyName,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        commonSampleData.postalCode,
        bopSampleData.state.label,
        commonSampleData.email,
        periodStartDate,
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType
    );
    await qualificationPage.clickSideBarQualificationPage();
    await qualificationPage.verifyQualificationDataIsRetained();
    await generalCoveragesPage.clickSideBarGeneralCoveragesPage();
    await generalCoveragesPage.verifyGeneralCoveragesDataIsRetained(
        bopSampleData.liability.limits,
        bopSampleData.liability.pdDeductible,
        bopSampleData.liability.pdDeductibleType,
        bopSampleData.tenantsFireLiability.limit,
        bopSampleData.specialCoveragePackages.option,
        bopSampleData.policywidePropertyDeductible.propertyBaseDeductible,
        bopSampleData.policywidePropertyDeductible.optionCoveragesDeductible,
        bopSampleData.policywidePropertyDeductible.glassDeductible,
        bopSampleData.policywidePropertyDeductible.propertyOptionalDeductible,
        bopSampleData.policywidePropertyDeductible.causeOfLoss
    );
    await additionalCoveragesPage.clickSideBarAdditionalCoveragesPage();
    await additionalCoveragesPage.verifyAdditionalCoveragesDataIsRetained(
        bopSampleData.crimeComputerFundsTransferFraud.limit,
        bopSampleData.professionsPrintersErrorsAndOmissions.grossSales
    );
    await locationsAndBuildingsPage.clickSideBarLocationsAndBuildingPage();
    await locationsAndBuildingsPage.verifyLocationAndBuildingDataIsRetained(
        commonSampleData.addressLine1,
        commonSampleData.city,
        commonSampleData.state.value,
        bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionTypeCode,
        bopSampleData.numberStories,
        bopSampleData.totalArea,
        bopSampleData.percentSprinkledCode,
        bopSampleData.alarmTypeCode,
        bopSampleData.businessPersonalPropertyLimit,
        bopSampleData.buildingLimit
    );
}).meta({
    PortfolioTestcaseID: 'PORT-2182',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip.requestHooks(logger)('Coverage Dependencies:Additional Coverage Sync', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
    );
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        periodStartDate
    );
    await yourInfoPage.yourInfoNext();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.selectAndVerifyGeneralCoverageDependencies(logger);
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.selectAndVerifyAdditionalCoverageDependencies(logger);
}).meta({
    PortfolioTestcaseID: 'PORT-2695',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('Coverage Dependencies:Limits Check On Coverages Of Building', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3
    );
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        periodStartDate
    );
    await yourInfoPage.yourInfoNext();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.openAddBuildingScreen();
    await locationsAndBuildingsPage.addBuildingBasicDetails(
        bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionType,
    );
    await locationsAndBuildingsPage.validateAddBuildingCoverageLimits();
}).meta({
    PortfolioTestcaseID: 'PORT-2697',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('BOP Policy Mandatory Fields validation', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3
    );
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        periodStartDate
    );
    await yourInfoPage.editTextAndCheckValidationMessage();
    await yourInfoPage.verifyNextIsGrayedOut();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3
    );
    await yourInfoPage.yourInfoNext();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.openAddBuildingScreen();
    await locationsAndBuildingsPage.addBuildingBasicDetails(
        bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionType,
    );
    await locationsAndBuildingsPage.addBuildingGeneralCoverageLimits(
        bopSampleData.businessPersonalPropertyLimit,
        bopSampleData.buildingLimit
    );
    await locationsAndBuildingsPage.buildingPageRemoveTextAndValidateRequiredFields();
    await locationsAndBuildingsPage.verifyAddBuildingIsGrayedOut();
    await locationsAndBuildingsPage.addBuildingBasicDetails(
        bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionType,
    );
    await locationsAndBuildingsPage.addBuildingGeneralCoverageLimits(
        bopSampleData.businessPersonalPropertyLimit,
        bopSampleData.buildingLimit
    );
    await locationsAndBuildingsPage.clickAddBuilding();
    await locationsAndBuildingsPage.addLocationRequiredData(
        bopSampleData.addressLine1,
        bopSampleData.city,
        bopSampleData.zipCode,
        bopSampleData.state.label
    );
    await locationsAndBuildingsPage.locationPageRemoveTextAndValidateRequiredFields();
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    await quotePage.quotePageNext();
    await additionalInformationPage.enterPhoneNumber(commonSampleData.phoneNumber);
    await additionalInformationPage.additionalInformationNext();
    await policyInformationPage.removeTextAndValidateRequiredFields();
    await policyInformationPage.enterPolicyInformationData(
        commonSampleData.email,
        commonSampleData.phoneNumber
    );
    await policyInformationPage.policyInformationNext();
    await paymentDetailsPage.selectCheckingAccountPaymentPlan(
        commonSampleData.paymentMethodBank,
        commonSampleData.accountNumber,
        commonSampleData.routingNumber,
        commonSampleData.bankName,
        commonSampleData.paymentPlan
    );
    await paymentDetailsPage.removeTextAndValidateRequiredFields();
    await paymentDetailsPage.verifyNextIsGrayedOut();
}).meta({
    DigitalTestcaseID: 'TC4240, TC3321, TC3319, TC3320, TC3322',
    PortfolioTestcaseID: 'PORT-1942',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});
