import { t } from 'testcafe';
import LandingPage from '../../pages/common/landingPage';
import QuoteInfoBar from '../../pages/common/quoteInfoBar';
import YourInfoPage from '../../pages/bop/yourInfoPage';
import QualificationPage from '../../pages/bop/qualificationPage';
import GeneralCoveragesPage from '../../pages/bop/generalCoveragesPage';
import AdditionalCoveragesPage from '../../pages/bop/additionalCoveragesPage';
import LocationsAndBuildingsPage from '../../pages/bop/locationsAndBuildingsPage';
import QuotePage from '../../pages/bop/quotePage';
import AdditionalInformationPage from '../../pages/bop/additionalInformationPage';
import PaymentDetailsPage from '../../pages/common/paymentDetailsPage';
import PolicyInformationPage from '../../pages/bop/policyInformationPage';
import SuccessPage from '../../pages/bop/successPage';
import commonSampleData from '../../data/common/sampleData.json5';
import bopSampleData from '../../data/bop/sampleData.json5';
import dataFetch from '../../../utilities/dataFetch';

const landingPage = new LandingPage();
const quoteInfoBar = new QuoteInfoBar();
const yourInfoPage = new YourInfoPage();
const qualificationPage = new QualificationPage();
const generalCoveragesPage = new GeneralCoveragesPage();
const additionalCoveragesPage = new AdditionalCoveragesPage();
const locationsAndBuildingsPage = new LocationsAndBuildingsPage();
const additionalInformationPage = new AdditionalInformationPage();
const policyInformationPage = new PolicyInformationPage();
const paymentDetailsPage = new PaymentDetailsPage();
const quotePage = new QuotePage();
const successPage = new SuccessPage();

const moment = require('moment');

let todayDate = moment();
let tomorrowDate = moment().add(1, 'days');
let nextYearDate = todayDate.clone().add(1, 'years');
// 'L' argument is moment alias for formatting MM/DD/YYYY
todayDate = todayDate.format('L');
nextYearDate = nextYearDate.format('L');
tomorrowDate = tomorrowDate.format('MMM D, YYYY');

async function yourInfo(startDate) {
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.companyName,
        commonSampleData.email,
        commonSampleData.city,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
    );
    await yourInfoPage.fillYourQuoteInfo(
        bopSampleData.organisationType,
        bopSampleData.smallBusinessType,
        startDate
    );
    await yourInfoPage.yourInfoNext();
}

async function addBuilding() {
    await locationsAndBuildingsPage.addBuilding(bopSampleData.propertyClassCode.label,
        bopSampleData.premium,
        bopSampleData.yearBuilt,
        bopSampleData.constructionType,
        bopSampleData.numberStories,
        bopSampleData.totalArea,
        bopSampleData.percentSprinkled,
        bopSampleData.alarmType,
        bopSampleData.businessPersonalPropertyLimit,
        bopSampleData.buildingLimit);
}

fixture`BOP Flow saving points`
    .page(process.env.TEST_ENV_URL);

test('Add Location', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfo(todayDate);
    await qualificationPage.checkDefaultFieldsShowOnQualificationPage();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.checkDefaultFieldsShowOnGeneralCoveragesPage();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.checkDefaultFieldsShowOnAdditionalCoveragesPage();
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.checkDefaultFieldsShowOnLocationsAndBuildingsPage();
    await locationsAndBuildingsPage.addLocation(
        bopSampleData.addressLine1,
        bopSampleData.addressLine2,
        bopSampleData.addressLine3,
        bopSampleData.city,
        bopSampleData.zipCode,
        bopSampleData.state.label,
        bopSampleData.locationCode,
        bopSampleData.phoneNumber,
        bopSampleData.fireProtection.label
    );
    const submissionId = await quoteInfoBar.getQuoteID();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    const secondLocation = response.lobData.businessOwners.coverables.locations.find(
        (element) => element.isPrimary === false
    );
    await locationsAndBuildingsPage.verifySecondLocation(
        secondLocation,
        bopSampleData.addressLine1,
        bopSampleData.city,
        bopSampleData.zipCode,
        bopSampleData.state.value,
        bopSampleData.locationCode,
        bopSampleData.phoneNumber,
        bopSampleData.fireProtection.value
    );
}).meta({
    DigitalTestcaseID: 'TC5021',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('Delete Location', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfo(todayDate);
    await qualificationPage.checkDefaultFieldsShowOnQualificationPage();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.checkDefaultFieldsShowOnGeneralCoveragesPage();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.checkDefaultFieldsShowOnAdditionalCoveragesPage();
    await additionalCoveragesPage.additionalCoverageNext();
    await locationsAndBuildingsPage.checkDefaultFieldsShowOnLocationsAndBuildingsPage();
    await locationsAndBuildingsPage.addLocation(
        bopSampleData.addressLine1,
        bopSampleData.addressLine2,
        bopSampleData.addressLine3,
        bopSampleData.city,
        bopSampleData.zipCode,
        bopSampleData.state.label,
        bopSampleData.locationCode,
        bopSampleData.phoneNumber,
        bopSampleData.fireProtection.label
    );
    const submissionId = await quoteInfoBar.getQuoteID();
    let response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    const secondLocation = response.lobData.businessOwners.coverables.locations.find(
        (element) => element.isPrimary === false
    );
    await locationsAndBuildingsPage.verifySecondLocation(
        secondLocation,
        bopSampleData.addressLine1,
        bopSampleData.city,
        bopSampleData.zipCode,
        bopSampleData.state.value,
        bopSampleData.locationCode,
        bopSampleData.phoneNumber,
        bopSampleData.fireProtection.value
    );
    await locationsAndBuildingsPage.deleteSecondLocation();
    response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await locationsAndBuildingsPage.verifySecondLocationDeleted(
        response.lobData.businessOwners.coverables.locations
    );
}).meta({
    DigitalTestcaseID: 'TC5022',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('Add info page saving point', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfo(todayDate);
    await qualificationPage.checkDefaultFieldsShowOnQualificationPage();
    const submissionId = await quoteInfoBar.getQuoteID();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await yourInfoPage.verifyPolicyInfo(
        response,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        bopSampleData.state.value,
        commonSampleData.postalCode,
        commonSampleData.companyName,
        bopSampleData.addressType,
    );
    await yourInfoPage.verifyQuoteInfo(
        response,
        submissionId,
        bopSampleData.termType,
        todayDate,
        nextYearDate,
        bopSampleData.smallBusinessType,
        bopSampleData.organisationType,
        commonSampleData.email,
        'Draft'
    );
}).meta({
    DigitalTestcaseID: 'TC4621',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('Qualification page saving point', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfo(todayDate);
    await qualificationPage.checkDefaultFieldsShowOnQualificationPage();
    const submissionId = await quoteInfoBar.getQuoteID();
    await qualificationPage.clickYesForLeasedAndCompCarried();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.checkDefaultFieldsShowOnGeneralCoveragesPage();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await qualificationPage.verifyYesForLeasedAndCompCarried(
        response.lobData.businessOwners.preQualQuestionSets[0].answers
    );
}).meta({
    DigitalTestcaseID: 'TC4623',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('General coverages page saving point', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfoPage.checkDefaultFieldsShowOnYourInfoPage();
    await yourInfo(todayDate);
    await qualificationPage.checkDefaultFieldsShowOnQualificationPage();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.checkDefaultFieldsShowOnGeneralCoveragesPage();
    await generalCoveragesPage.changeCoverages(
        bopSampleData.liability.pdDeductible,
        bopSampleData.specialCoveragePackages.option,
        bopSampleData.policywidePropertyDeductible.optionCoveragesDeductible,
        bopSampleData.policywidePropertyDeductible.causeOfLoss
    );
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.checkDefaultFieldsShowOnAdditionalCoveragesPage();
    const submissionId = await quoteInfoBar.getQuoteID();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await generalCoveragesPage.verifyChangesToCoverage(response.lobData.businessOwners.coverages);
}).meta({
    DigitalTestcaseID: 'TC4927',
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('Quote Page saving Point', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(tomorrowDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await addBuilding();
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    // await quotePage.checkDefaultFieldsShowOnQuotePage();
    const submissionId = await quoteInfoBar.getQuoteID();
    const quotePremiumTotal = await quotePage.getQuoteTotalPremium();
    const quoteTaxTotal = await quotePage.getQuoteTotalTax();
    const quoteCostTotal = await quotePage.getQuoteTotalCost();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    const policyStartDate = moment().add(1, 'days');
    const policyEndDate = policyStartDate.clone().add(1, 'years');
    await yourInfoPage.verifyPolicyInfo(
        response,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        bopSampleData.state.value,
        commonSampleData.postalCode,
        commonSampleData.companyName,
        bopSampleData.addressType,
    );
    await yourInfoPage.verifyQuoteInfo(
        response,
        submissionId,
        bopSampleData.termType,
        policyStartDate,
        policyEndDate,
        bopSampleData.smallBusinessType,
        bopSampleData.organisationType,
        commonSampleData.email,
        'Quoted'
    );
    await quotePage.verifyQuoteTotals(
        response,
        submissionId,
        quotePremiumTotal,
        quoteTaxTotal,
        quoteCostTotal
    );
}).meta({
    DigitalTestcaseID: 'TC5024',
    PortfolioTestcaseID: 'PORT-2018',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('Add Building', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(todayDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    const submissionId = await quoteInfoBar.getQuoteID();
    await addBuilding();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await locationsAndBuildingsPage.verifyBuildingAdded(
        response.lobData.businessOwners.coverables.locations[0].buildings,
        bopSampleData.propertyClassCode.code,
        bopSampleData.premium
    );
}).meta({
    DigitalTestcaseID: 'TC4700',
    PortfolioTestcaseID: 'PORT-2018',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test('Remove Building', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(todayDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    const submissionId = await quoteInfoBar.getQuoteID();
    await addBuilding();
    await addBuilding();
    let response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await locationsAndBuildingsPage.verifyTwoBuildingsAdded(
        response.lobData.businessOwners.coverables.locations[0].buildings
    );
    await locationsAndBuildingsPage.deleteFirstBuilding();
    response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await locationsAndBuildingsPage.verifyBuildingDeleted(
        response.lobData.businessOwners.coverables.locations[0].buildings
    );
}).meta({
    DigitalTestcaseID: 'TC4682',
    PortfolioTestcaseID: 'PORT-2018',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('Policy info Page saving Point', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(tomorrowDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await addBuilding();
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.quotePageNext();
    await additionalInformationPage.additionalInformationNext();
    await policyInformationPage.checkDefaultFieldsShowOnPolicyInformationPage();
    await policyInformationPage.verifyInitialPolicyInfo(
        tomorrowDate,
        commonSampleData.companyName,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        bopSampleData.state.value,
        commonSampleData.postalCode
    );
    await policyInformationPage.changePolicyInfo(
        commonSampleData.SecondryEmail, bopSampleData.secondPhoneNumber
    );
    const submissionId = await quoteInfoBar.getQuoteID();
    await policyInformationPage.policyInformationNext();
    await t.wait(5000);
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await policyInformationPage.verifyChangedPolicyInfo(
        response.baseData.accountHolder,
        commonSampleData.SecondryEmail,
        bopSampleData.secondPhoneNumber
    );
    await paymentDetailsPage.checkDefaultFieldsShowOnPaymentDetailsPage();
}).meta({
    DigitalTestcaseID: 'TC5025',
    PortfolioTestcaseID: 'PORT-2018',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});

test.skip('payment saving point-Bank account checking', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(tomorrowDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await addBuilding();
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    // await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.quotePageNext();
    await additionalInformationPage.enterPhoneNumber(commonSampleData.phoneNumber);
    await additionalInformationPage.additionalInformationNext();
    await policyInformationPage.checkDefaultFieldsShowOnPolicyInformationPage();
    await policyInformationPage.changePolicyInfo(
        commonSampleData.SecondryEmail, bopSampleData.secondPhoneNumber
    );
    const submissionId = await quoteInfoBar.getQuoteID();
    await policyInformationPage.policyInformationNext();
    await t.wait(5000);
    await paymentDetailsPage.checkDefaultFieldsShowOnPaymentDetailsPage();
    await paymentDetailsPage.selectCheckingAccountPaymentPlan(
        commonSampleData.paymentMethodBank,
        commonSampleData.accountNumber,
        commonSampleData.routingNumber,
        commonSampleData.bankName,
        commonSampleData.paymentPlan
    );
    await paymentDetailsPage.paymentDetailsPageNext();
    await successPage.checkDefaultFieldsShowOnSuccessPage();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await successPage.verifyPaymentPlan(
        response.bindData.paymentPlans[0], commonSampleData.paymentPlan
    );
}).meta({
    DigitalTestcaseID: 'TC5026',
    PortfolioTestcaseID: 'PORT-1689',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});


test.skip('payment saving point-Credit Card', async () => {
    await landingPage.startQuote('BusinessOwners', commonSampleData.postalCode);
    await yourInfo(tomorrowDate);
    await qualificationPage.clickNoForAllFields();
    await qualificationPage.qualificationNext();
    await generalCoveragesPage.generalCoveragesNext();
    await additionalCoveragesPage.additionalCoverageNext();
    await addBuilding();
    await locationsAndBuildingsPage.LocationsAndBuildingsNext();
    // await quotePage.checkDefaultFieldsShowOnQuotePage();
    await quotePage.quotePageNext();
    await additionalInformationPage.enterPhoneNumber(commonSampleData.phoneNumber);
    await additionalInformationPage.additionalInformationNext();
    await policyInformationPage.checkDefaultFieldsShowOnPolicyInformationPage();
    await policyInformationPage.changePolicyInfo(
        commonSampleData.SecondryEmail, bopSampleData.secondPhoneNumber
    );
    const submissionId = await quoteInfoBar.getQuoteID();
    await policyInformationPage.policyInformationNext();
    await t.wait(5000);
    await paymentDetailsPage.checkDefaultFieldsShowOnPaymentDetailsPage();
    await paymentDetailsPage.selectCreditCardPaymentPlan(
        commonSampleData.paymentMethodCreditCard,
        commonSampleData.cardIssuer,
        commonSampleData.creditCardNumber,
        commonSampleData.expirationMonth,
        commonSampleData.expirationYear,
        commonSampleData.paymentPlan
    );
    await paymentDetailsPage.paymentDetailsPageNext();
    await successPage.checkDefaultFieldsShowOnSuccessPage();
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await successPage.verifyPaymentPlan(
        response.bindData.paymentPlans[0], commonSampleData.paymentPlan
    );
}).meta({
    DigitalTestcaseID: 'TC6159',
    PortfolioTestcaseID: 'PORT-2018',
    Regression: 'true',
    UAT: 'true',
    Platform: 'all',
    Application: 'QnB'
});
