import LandingPage from '../../../pages/common/landingPage';
import YourBusinessPage from '../../../pages/gtp/yourBusinessPage';
import CommonLocators from '../../../../utilities/commonLocators';
import YourAddressPage from "../../../pages/gtp/yourAddressPage";
import QuestionsPage from "../../../pages/gtp/questionsPage";
import RecommendationsPage from "../../../pages/gtp/recommendationsPage";

const landingPage = new LandingPage();
const yourBusinessPage = new YourBusinessPage();
const yourAddressPage = new YourAddressPage();
const questionsPage = new QuestionsPage();
const recommendationsPage = new RecommendationsPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`GTP UI Testing - Recommendations Page`
    .page`${TEST_URL}`;

test.skip('Verify \'Get Quote\' button is present for the Business Owners Quote', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.selectAllQuestions();
    await commonLocators.goNext();

    await recommendationsPage.checkDefaultFieldsShowOnRecommendationsPage();
    await recommendationsPage.verifyGetQuoteButtonExistsForBOPRecommendation();
}).meta({Platform: 'all', Application : "QnB" });

test('Verify Commercial Auto quote is not recommended if the \'Van or Truck\' question is not selected', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.selectAllQuestionsExceptForVanOrTruck();
    await commonLocators.goNext();

    await recommendationsPage.verifyCommercialAutoIsNotRecommmended();
}).meta({Platform: 'all', Application : "QnB" });
