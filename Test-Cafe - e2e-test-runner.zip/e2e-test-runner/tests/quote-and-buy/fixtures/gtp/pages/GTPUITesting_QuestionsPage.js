import LandingPage from '../../../pages/common/landingPage';
import YourBusinessPage from '../../../pages/gtp/yourBusinessPage';
import CommonPage from '../../../pages/gtp/commonPage';
import CommonLocators from '../../../../utilities/commonLocators';
import YourAddressPage from "../../../pages/gtp/yourAddressPage";
import QuestionsPage from "../../../pages/gtp/questionsPage";

const landingPage = new LandingPage();
const yourBusinessPage = new YourBusinessPage();
const yourAddressPage = new YourAddressPage();
const questionsPage = new QuestionsPage();
const commonPage = new CommonPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`GTP UI Testing - Questions Page`
    .page`${TEST_URL}`;

test('Verify continue button is disabled on page entry', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await commonLocators.isNextButtonDisabled(true);
}).meta({Platform: 'all', Application : "QnB" });

test('Verify help text shows for each question when the help icon is clicked', async () => {
    await landingPage.startQuote('GuidanceToProduct');
    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.selectAllHelpIcons();
    await questionsPage.verifyAllHelpTextShows()
}).meta({Platform: 'all', Application : "QnB" });

test('Data is retained when going forward and back in the flow', async () => {
    await landingPage.startQuote('GuidanceToProduct');
    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.selectAllQuestions();
    await commonLocators.goNext();

    await commonPage.editQuestions();
    await questionsPage.verifyQuestionsAreChecked();
}).meta({Platform: 'all', Application : "QnB" });

test('Verify icons selected on the questions page are shown on the recommendations page', async () => {
    await landingPage.startQuote('GuidanceToProduct');
    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.partiallySelectQuestions();
    await commonLocators.goNext();

    await commonPage.verifyCorrectQuestionIconsAreDisplayed();
}).meta({Platform: 'all', Application : "QnB" });
