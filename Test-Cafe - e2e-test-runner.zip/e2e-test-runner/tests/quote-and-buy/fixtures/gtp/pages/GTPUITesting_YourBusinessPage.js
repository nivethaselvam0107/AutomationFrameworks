import LandingPage from '../../../pages/common/landingPage';
import YourBusinessPage from '../../../pages/gtp/yourBusinessPage';
import CommonPage from '../../../pages/gtp/commonPage';
import CommonLocators from '../../../../utilities/commonLocators';

const landingPage = new LandingPage();
const yourBusinessPage = new YourBusinessPage();
const commonPage = new CommonPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`GTP UI Testing - Your Business Page`
    .page`${TEST_URL}`;

test('Verify continue button is disabled on page entry', async () => {
    await landingPage.startQuote('GuidanceToProduct');
    await commonLocators.isNextButtonDisabled(true);
}).meta({Platform: 'all', Application : "QnB" });

test('Verify continue button and error messages behave as expected', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.isNextButtonDisabled(false);

    await yourBusinessPage.clearBusinessSelection();
    await commonLocators.isNextButtonDisabled(true);
    await yourBusinessPage.verifyErrorMessageIsShown();
    await yourBusinessPage.selectBusinessOption2FromTypeahead();
    await commonLocators.isNextButtonDisabled(false);
}).meta({Platform: 'all', Application : "QnB" });

test('Data is retained when going forward and back in the flow', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();
    await commonPage.editBusiness();

    await yourBusinessPage.verifyBusinessSelectionIsRetained();
}).meta({Platform: 'all', Application : "QnB" });
