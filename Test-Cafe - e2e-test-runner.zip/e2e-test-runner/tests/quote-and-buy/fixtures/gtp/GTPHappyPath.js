import LandingPage from '../../pages/common/landingPage';
import YourBusinessPage from '../../pages/gtp/yourBusinessPage';
import YourAddressPage from '../../pages/gtp/yourAddressPage';
import QuestionsPage from '../../pages/gtp/questionsPage';
import RecommendationsPage from '../../pages/gtp/recommendationsPage';
import CommonLocators from '../../../utilities/commonLocators';

const landingPage = new LandingPage();
const yourBusinessPage = new YourBusinessPage();
const yourAddressPage = new YourAddressPage();
const questionsPage = new QuestionsPage();
const recommendationsPage = new RecommendationsPage();

const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`GTP Happy Path`
    .page`${TEST_URL}`;

test('Default fields for the flow render and I can get a quote', async () => {
    await landingPage.startQuote('GuidanceToProduct');

    await yourBusinessPage.checkDefaultFieldsShowOnYourBusinessPage();
    await yourBusinessPage.selectBusinessOption1FromTypeahead();
    await commonLocators.goNext();

    await yourAddressPage.checkDefaultFieldsShowOnYourAddressPage();
    await yourAddressPage.enterAddressLookupData();
    await yourAddressPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await questionsPage.checkDefaultFieldsShowOnQuestionsPage();
    await questionsPage.selectAllQuestions();
    await commonLocators.goNext();

    await recommendationsPage.checkDefaultFieldsShowOnRecommendationsPage();
    await recommendationsPage.startABopQuote();

    await recommendationsPage.checkYourInfoPageFieldsMatchDataEnteredInGTPFlow();
}).meta({Platform: 'all', Application : "QnB" });

