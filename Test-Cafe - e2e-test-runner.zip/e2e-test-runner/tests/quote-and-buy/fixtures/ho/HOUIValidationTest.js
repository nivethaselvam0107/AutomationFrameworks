import LandingPage from '../../pages/common/landingPage';
import YourInfoPage from '../../pages/ho/yourInfoPage';
import commonSampleData from '../../data/common/sampleData.json5';
import hoSampleData from '../../data/ho/sampleData.json5';
import HopQualificationPage from '../../pages/ho/hopQualificationPage';
import YourHomePage from '../../pages/ho/yourHomePage';
import Construction from '../../pages/ho/constructionPage';
import Discount from '../../pages/ho/discountPage';

const landingPage = new LandingPage();
const yourInfoPage = new YourInfoPage();
const hopQualificationPage = new HopQualificationPage();
const yourHomePage = new YourHomePage();
const constructionPage = new Construction();
const discountPage = new Discount();

const moment = require('moment');

let periodStartDate = moment();
periodStartDate = periodStartDate.format('l');


const TEST_URL = process.env.TEST_ENV_URL;
fixture`HOUIValidationTest`.page`${TEST_URL}`;

test('HO - invalid ZIP code on landing page', async () => {
    await landingPage.startQuote('HomeOwners', '000');
    await landingPage.checkHOZipCodeAlertMessage();
}).meta({
    Regression: 'true',
    Platform: 'all',
    Application: 'QnB'
});


test('HO - Going back in the wizard Homeowners policy', async () => {
    await landingPage.startQuote('HomeOwners', '94404');
    await yourInfoPage.clickEnterAddressManually();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.yourInfoNext();
    await hopQualificationPage.setQualificationValues(
        hoSampleData.whoOccupiesDwelling,
        hoSampleData.occupyFullTime
    );
    await hopQualificationPage.qualificationNext();
    await yourHomePage.setYourHomeValues(
        hoSampleData.estimatedValueOfHome.value,
        hoSampleData.locationType.label,
        hoSampleData.residenceType.label,
        hoSampleData.distanceToFireHydrant,
        hoSampleData.distanceToFireStation,
        hoSampleData.within300ftOfCommercialProperty,
        hoSampleData.floodingOrFireHazard,
        hoSampleData.homeType,
        hoSampleData.specifyWhoOccupies.label
    );
    await yourHomePage.yourHomeNext();
    await constructionPage.setConstructionValues(
        hoSampleData.yearBuilt,
        hoSampleData.numberOfStories,
        hoSampleData.garage,
        hoSampleData.constructionType,
        hoSampleData.foundationType,
        hoSampleData.roof,
        hoSampleData.plumbing,
        hoSampleData.primaryHeating.label,
        hoSampleData.secondaryHeating,
        hoSampleData.wiring,
        hoSampleData.electricalSystem.label,
    );
    await constructionPage.constructionNext();
    await discountPage.setDiscountValues(
        hoSampleData.fireExtinguishers,
        hoSampleData.burglarAlarm,
        hoSampleData.fireAlarmMonitored,
        hoSampleData.smokeAlarms,
        hoSampleData.alarmsOnAllFloor,
        hoSampleData.deadBolts,
        hoSampleData.numberOfDeadbolts,
        hoSampleData.residenceVisible,
        hoSampleData.sprinklerSystemType
    );
    await discountPage.discountNext();
    await yourInfoPage.clickSideBarYourInfo();
    await yourInfoPage.verifyYourInfoDataIsRetained(
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        commonSampleData.postalCode,
        commonSampleData.state.label,
        periodStartDate,
    );
    await hopQualificationPage.clickSideBarQualification();
    await hopQualificationPage.verifyQualificationDataIsRetained(
        hoSampleData.whoOccupiesDwelling,
        hoSampleData.occupyFullTime
    );
    await yourHomePage.clickSideBarYourHome();
    await yourHomePage.verifyYourHomeDataIsRetained(
        hoSampleData.estimatedValueOfHome.label,
        hoSampleData.locationType.label,
        hoSampleData.residenceType.label,
        hoSampleData.distanceToFireHydrant,
        hoSampleData.distanceToFireStation,
        hoSampleData.within300ftOfCommercialProperty,
        hoSampleData.floodingOrFireHazard,
        hoSampleData.homeType,
        hoSampleData.specifyWhoOccupies.label
    );
    await constructionPage.clickSideBarConstruction();
    await constructionPage.verifyConstructionDataIsRetained(
        hoSampleData.yearBuilt,
        hoSampleData.numberOfStories,
        hoSampleData.garage,
        hoSampleData.constructionType,
        hoSampleData.foundationType,
        hoSampleData.roof,
        hoSampleData.plumbing,
        hoSampleData.primaryHeating.label,
        hoSampleData.secondaryHeating,
        hoSampleData.wiring,
        hoSampleData.electricalSystem.label,
    );
    await discountPage.clickSideBarDiscount();
    await discountPage.verifyDiscountDataIsRetained(
        hoSampleData.fireExtinguishers,
        hoSampleData.burglarAlarm,
        hoSampleData.fireAlarmMonitored,
        hoSampleData.smokeAlarms,
        hoSampleData.alarmsOnAllFloor,
        hoSampleData.deadBolts,
        hoSampleData.numberOfDeadbolts,
        hoSampleData.residenceVisible,
        hoSampleData.sprinklerSystemType
    );
}).meta({
    PortfolioTestcaseID: 'PORT-2016',
    Regression: 'true',
    UAT: 'true',
    Platform: 'Granite',
    Application: 'QnB'
});
