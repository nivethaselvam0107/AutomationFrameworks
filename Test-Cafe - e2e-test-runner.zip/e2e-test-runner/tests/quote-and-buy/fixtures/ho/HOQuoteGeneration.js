import LandingPage from '../../pages/common/landingPage';
import QuoteInfoBar from '../../pages/common/quoteInfoBar';
import YourInfoPage from '../../pages/ho/yourInfoPage';
import commonSampleData from '../../data/common/sampleData.json5';
import hoSampleData from '../../data/ho/sampleData.json5';
import HopQualificationPage from '../../pages/ho/hopQualificationPage';
import YourHomePage from '../../pages/ho/yourHomePage';
import Construction from '../../pages/ho/constructionPage';
import Discount from '../../pages/ho/discountPage';
import QuotePage from '../../pages/ho/quotePage';
import PolicyInformationPage from '../../pages/ho/policyInformationPage';
import PaymentDetailsPage from '../../pages/common/paymentDetailsPage';
import SuccessDetailsPage from '../../pages/ho/successDetailsPage';
import dataFetch from '../../../utilities/dataFetch';


const landingPage = new LandingPage();
const quoteInfoBar = new QuoteInfoBar();
const yourInfoPage = new YourInfoPage();
const hopQualificationPage = new HopQualificationPage();
const yourHomePage = new YourHomePage();
const constructionPage = new Construction();
const discountPage = new Discount();
const quotePage = new QuotePage();
const policyInformationPage = new PolicyInformationPage();
const paymentDetailsPage = new PaymentDetailsPage();
const successDetailsPage = new SuccessDetailsPage();

const moment = require('moment');

let periodStartDate = moment();
let periodEndDate = periodStartDate.clone().add(1, 'years');
// 'l' argument is moment alias for formatting MM/DD/YYYY
periodEndDate = periodEndDate.format('l');
periodStartDate = periodStartDate.format('l');

const TEST_URL = process.env.TEST_ENV_URL;
fixture`HOQuoteGeneration`.page`${TEST_URL}`;


test('HO - Verify Payment Method - Credit Card', async () => {
    await landingPage.startQuote('HomeOwners', '94404');
    await yourInfoPage.clickEnterAddressManually();
    await yourInfoPage.fillBasicInfo(
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        periodStartDate
    );
    await yourInfoPage.yourInfoNext();
    await hopQualificationPage.setQualificationValues(
        hoSampleData.whoOccupiesDwelling,
        hoSampleData.occupyFullTime
    );
    await hopQualificationPage.qualificationNext();
    const submissionId = await quoteInfoBar.getQuoteID();
    await yourHomePage.setYourHomeValues(
        hoSampleData.estimatedValueOfHome.value,
        hoSampleData.locationType.label,
        hoSampleData.residenceType.label,
        hoSampleData.distanceToFireHydrant,
        hoSampleData.distanceToFireStation,
        hoSampleData.within300ftOfCommercialProperty,
        hoSampleData.floodingOrFireHazard,
        hoSampleData.homeType,
        hoSampleData.specifyWhoOccupies.label
    );
    await yourHomePage.yourHomeNext();
    await constructionPage.setConstructionValues(
        hoSampleData.yearBuilt,
        hoSampleData.numberOfStories,
        hoSampleData.garage,
        hoSampleData.constructionType,
        hoSampleData.foundationType,
        hoSampleData.roof,
        hoSampleData.plumbing,
        hoSampleData.primaryHeating.label,
        hoSampleData.secondaryHeating,
        hoSampleData.wiring,
        hoSampleData.electricalSystem.label,
    );
    await constructionPage.constructionNext();
    await discountPage.setDiscountValues(
        hoSampleData.fireExtinguishers,
        hoSampleData.burglarAlarm,
        hoSampleData.fireAlarmMonitored,
        hoSampleData.smokeAlarms,
        hoSampleData.alarmsOnAllFloor,
        hoSampleData.deadBolts,
        hoSampleData.numberOfDeadbolts,
        hoSampleData.residenceVisible,
        hoSampleData.sprinklerSystemType
    );
    await discountPage.discountNext();
    const quoteFullAmount = await quotePage.getQuoteFullAmount();
    const quoteMonthlyAmount = await quotePage.getQuoteMonthlyAmount();
    const policyStartDate = await quotePage.getPolicyStartDate();
    await quotePage.clickBuyNowButton();
    await policyInformationPage.setPolicyInfoValues(
        commonSampleData.firstName,
        commonSampleData.lastName,
        commonSampleData.email,
        commonSampleData.phoneNumber
    );
    await policyInformationPage.policyInformationNext();
    await paymentDetailsPage.selectCheckingAccountPaymentPlan(
        commonSampleData.paymentMethodBank,
        commonSampleData.accountNumber,
        commonSampleData.routingNumber,
        commonSampleData.bankName,
        commonSampleData.paymentPlan
    );
    await paymentDetailsPage.paymentDetailsPageNext();
    // Extracting values from Success Page
    const accountNumber = await successDetailsPage.getAccountNumber();
    const policyNumber = await successDetailsPage.getPolicyNumber();
    const policyEffectiveDate = await successDetailsPage.getPolicyEffectiveDate();
    const policyPeriodStartDate = await successDetailsPage.getPolicyPeriodStartDate();
    const policyPeriodEndDate = await successDetailsPage.getPolicyPeriodEndDate();
    const policyTotalAmount = await successDetailsPage.getPolicyTotalAmount();
    const paymentPlanName = await successDetailsPage.getPolicyPaymentPlanName();
    const currentPayment = await successDetailsPage.getPolicyCurrentPayment();
    await successDetailsPage.openInformationAccordion();
    const firstName = await successDetailsPage.getFirstName();
    const lastName = await successDetailsPage.getLastName();
    const email = await successDetailsPage.getEmail();
    await successDetailsPage.openHouseAccordion();
    const houseAddressLine1 = await successDetailsPage.getHouseAddressLine1();
    const houseAddressLine2 = await successDetailsPage.getHouseAddressLine2();
    const houseAddressLine3 = await successDetailsPage.getHouseAddressLine3();
    const houseAddressCity = await successDetailsPage.getHouseAddressCity();
    const houseAddressState = await successDetailsPage.getHouseAddressState();
    const houseAddressPostalCode = await successDetailsPage.getHouseAddressZip();
    // Retrieving data from API
    const response = await dataFetch.getQuoteData(commonSampleData.postalCode, submissionId);
    await yourInfoPage.verifyYourInfo(
        response,
        commonSampleData.email,
        commonSampleData.addressLine1,
        commonSampleData.addressLine2,
        commonSampleData.addressLine3,
        commonSampleData.city,
        commonSampleData.state.value,
        commonSampleData.postalCode,
    );
    await hopQualificationPage.verifyQualificationInfo(
        response,
        hoSampleData.haveADog,
        hoSampleData.propertyVacant,
        hoSampleData.whoOccupiesDwelling,
        hoSampleData.occupyFullTime,
        hoSampleData.haveSwimmingPool
    );
    await yourHomePage.verifyYourHomeInfo(
        response,
        submissionId,
        hoSampleData.estimatedValueOfHome.value,
        hoSampleData.locationType.value,
        hoSampleData.residenceType.value,
        hoSampleData.distanceToFireHydrant,
        hoSampleData.distanceToFireStation,
        hoSampleData.within300ftOfCommercialProperty,
        hoSampleData.floodingOrFireHazard,
        hoSampleData.homeType,
        hoSampleData.specifyWhoOccupies.value
    );
    await constructionPage.verifyConstructionInfo(
        response,
        submissionId,
        hoSampleData.yearBuilt,
        hoSampleData.numberOfStories,
        hoSampleData.garage,
        hoSampleData.constructionType,
        hoSampleData.foundationType,
        hoSampleData.roof,
        hoSampleData.plumbing,
        hoSampleData.primaryHeating.value,
        hoSampleData.secondaryHeating,
        hoSampleData.wiring,
        hoSampleData.electricalSystem.value,
    );
    await discountPage.verifyDiscountInfo(
        response,
        submissionId,
        hoSampleData.fireExtinguishers,
        hoSampleData.burglarAlarm,
        hoSampleData.burglarAlarmType.value,
        hoSampleData.fireAlarmMonitored,
        hoSampleData.smokeAlarms,
        hoSampleData.alarmsOnAllFloor,
        hoSampleData.deadBolts,
        hoSampleData.numberOfDeadbolts,
        hoSampleData.residenceVisible,
        hoSampleData.sprinklerSystemType
    );
    await quotePage.verifyHoQuoteInfo(
        response,
        submissionId,
        quoteMonthlyAmount,
        quoteFullAmount,
        periodStartDate,
        policyStartDate,
        'Bound'
    );
    await successDetailsPage.verifyPolicySummary(
        response,
        policyNumber,
        accountNumber,
        periodStartDate,
        periodEndDate,
        policyEffectiveDate,
        policyPeriodStartDate,
        policyPeriodEndDate,
        policyTotalAmount,
        paymentPlanName,
        currentPayment
    );
    await successDetailsPage.verifyInformation(
        firstName,
        lastName,
        email
    );
    await successDetailsPage.verifyHouseData(
        houseAddressLine1,
        houseAddressLine2,
        houseAddressLine3,
        houseAddressCity,
        houseAddressState,
        houseAddressPostalCode
    );
}).meta({
    DigitalTestcaseID: 'TC5001',
    PortfolioTestcaseID: 'PORT-1687',
    Regression: 'true',
    UAT: 'true',
    Platform: 'Granite',
    Application: 'QnB'
});
