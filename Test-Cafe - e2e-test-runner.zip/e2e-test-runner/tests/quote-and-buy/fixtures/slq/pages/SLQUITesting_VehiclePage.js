import LandingPage from '../../../pages/common/landingPage';
import VehiclePage from '../../../pages/slq/vehiclePage';
import Helper from '../../../../utilities/helper';
import CommonLocators from '../../../../utilities/commonLocators';

const landingPage = new LandingPage();
const vehiclePage = new VehiclePage();

const helper = new Helper();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`SLQ UI Testing - Vehicle Page`
    .page`${TEST_URL}`;

test('Correct fields show when toggle is changed and toggle is set to "Make, Model, Year" on flow entry', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.checkMakeModelYearToggleIsSelected();

    await vehiclePage.clickVinLookupOptionInToggle();
    await vehiclePage.checkVinLookupFieldsShow();

    await vehiclePage.clickManualEntryOptionInToggle();
    await vehiclePage.checkManualEntryFieldsShow();
}).meta({Platform: 'all', Application : "QnB" });


test('Ensure Wizard Next button is disabled on Page Entry', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.clickVinLookupOptionInToggle();
    await commonLocators.isNextButtonDisabled(true);

    await vehiclePage.clickManualEntryOptionInToggle();
    await commonLocators.isNextButtonDisabled(true);
}).meta({Platform: 'all', Application : "QnB" });


test('Selecting all dropdown required values changes the state of the next button', async () => {
    await landingPage.startQuote('QuickQuote');

    await commonLocators.isNextButtonDisabled(true);

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.isNextButtonDisabled(false);
}).meta({Platform: 'all', Application : "QnB" });

test('Entering valid vin values changes the state of the next button and populates readonly values of the vehicles details', async () => {
    await landingPage.startQuote('QuickQuote');

    await commonLocators.isNextButtonDisabled(true);

    await vehiclePage.clickVinLookupOptionInToggle();
    await vehiclePage.enterVIN();
    await helper.pressKey('tab');
    await vehiclePage.vehicleDetailsArePopulatedAndAreReadonly();
    await vehiclePage.vehicleDetailsArePopulatedWithCorrectVehicleData();
    // FIXME: When this defect has been fixed re-visit the test
    // await commonLocators.isNextButtonDisabled(false);
}).meta({Platform: 'all', Application : "QnB" });

test('Page state is maintained when moving forwards and backwards in the flow', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();
    await commonLocators.goPrevious();

    await vehiclePage.verifyManualEntrySelectionHasBeenRetained();
}).meta({Platform: 'all', Application : "QnB" });
