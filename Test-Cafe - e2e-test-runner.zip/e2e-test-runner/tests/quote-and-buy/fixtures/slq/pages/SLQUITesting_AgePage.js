import LandingPage from '../../../pages/common/landingPage';
import VehiclePage from '../../../pages/slq/vehiclePage';
import LocationPage from '../../../pages/slq/locationPage';
import YourAgePage from '../../../pages/slq/yourAgePage';
import CommonLocators from '../../../../utilities/commonLocators';

const landingPage = new LandingPage();
const vehiclePage = new VehiclePage();
const locationPage = new LocationPage();
const yourAgePage = new YourAgePage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`SLQ UI Testing - Age Page`
    .page`${TEST_URL}`;

test('Next button is disabled on the Your Age Page when completed/terms have not been agreed', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await commonLocators.isNextButtonDisabled(true);
    await yourAgePage.agreeToTermsAndConditions();
    await commonLocators.isNextButtonDisabled(false);
    await yourAgePage.agreeToTermsAndConditions();
    await commonLocators.isNextButtonDisabled(true);
}).meta({Platform: 'all', Application : "QnB" });

test('Stepper input respects min-max age constraints and increases/decreases in value as expected', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await yourAgePage.verifyDriverAgeIsSetToMin();
    await yourAgePage.verifyMinusButtonIsDisabled();

    await yourAgePage.enterDriverAge('100');
    await yourAgePage.verifyPlusButtonIsDisabled();

    await yourAgePage.enterDriverAge('30');
    await yourAgePage.clickOnIncreaseStepperButton(1);
    await yourAgePage.verifyInputHasExpectedValue('31');
    await yourAgePage.clickOnDecreaseStepperButton(2);
    await yourAgePage.verifyInputHasExpectedValue('29');
}).meta({Platform: 'all', Application : "QnB" });

test('Page state is maintained when moving forwards and backwards in the flow', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await yourAgePage.enterDriverAge('30');
    await yourAgePage.agreeToTermsAndConditions();

    await commonLocators.goNext();
    await commonLocators.goPrevious();
    await yourAgePage.verifyInputHasExpectedValue('30');
    await yourAgePage.verifyTermsAndConditionsAreChecked();
}).meta({Platform: 'all', Application : "QnB" });
