import LandingPage from '../../../pages/common/landingPage';
import VehiclePage from '../../../pages/slq/vehiclePage';
import LocationPage from '../../../pages/slq/locationPage';
import YourAgePage from '../../../pages/slq/yourAgePage';
import EstimationPage from '../../../pages/slq/estimatePage';
import CommonLocators from '../../../../utilities/commonLocators';

const landingPage = new LandingPage();
const vehiclePage = new VehiclePage();
const locationPage = new LocationPage();
const yourAgePage = new YourAgePage();

const estimationPage = new EstimationPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`SLQ UI Testing - Estimation Page`
    .page`${TEST_URL}`;

test('Modal appears when email address has been sent', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await yourAgePage.enterDriverAge('30');
    await yourAgePage.agreeToTermsAndConditions();
    await commonLocators.goNext();

    await estimationPage.enterEmailAddress();
    await estimationPage.sendEmail();
    await estimationPage.verifySuccessModalAppears();
}).meta({Platform: 'all', Application : "QnB" });

test('Clicking on Start Over will bring you to the vehicles page', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await yourAgePage.enterDriverAge('30');
    await yourAgePage.agreeToTermsAndConditions();
    await commonLocators.goNext();

    await estimationPage.clickStartOverLink();
    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
}).meta({Platform: 'all', Application : "QnB" });
