import LandingPage from '../../../pages/common/landingPage';
import VehiclePage from '../../../pages/slq/vehiclePage';
import LocationPage from '../../../pages/slq/locationPage';
import CommonLocators from '../../../../utilities/commonLocators';

const landingPage = new LandingPage();
const vehiclePage = new VehiclePage();
const locationPage = new LocationPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`SLQ UI Testing - Location Page`
    .page`${TEST_URL}`;

test('Google map shows when a value has been selected from the dropdown and next button is disabled when expected', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await commonLocators.isNextButtonDisabled(true);

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await locationPage.verifyMapShows();
    await commonLocators.isNextButtonDisabled(false);
}).meta({Platform: 'all', Application : "QnB" });

test('Page state is maintained when moving forwards and backwards in the flow', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();
    await commonLocators.goPrevious();
    await locationPage.checkAddressFieldsShowInAddressFoundState();
    await locationPage.checkAddressLookupFieldContainsExpectedData();

    await locationPage.clearTypeaheadData();

    await locationPage.switchToManualEntryMode();
    await locationPage.enterManualData();
    await commonLocators.goNext();
    await commonLocators.goPrevious();
    await locationPage.checkManualAddressFieldsShow();
    await locationPage.checkManualAddressFieldsContainExpectedData();
}).meta({Platform: 'all', Application : "QnB" });
