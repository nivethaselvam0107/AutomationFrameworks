import LandingPage from '../../pages/common/landingPage';
import VehiclePage from '../../pages/slq/vehiclePage';
import LocationPage from '../../pages/slq/locationPage';
import YourAgePage from '../../pages/slq/yourAgePage';
import EstimationPage from '../../pages/slq/estimatePage';
import CommonLocators from '../../../utilities/commonLocators';
import dataFetch from '../../../utilities/dataFetch';
import slqSampleData from '../../data/slq/sampleData.json5';

const landingPage = new LandingPage();
const vehiclePage = new VehiclePage();
const locationPage = new LocationPage();
const yourAgePage = new YourAgePage();

const estimationPage = new EstimationPage();
const commonLocators = new CommonLocators();

const TEST_URL = process.env.TEST_ENV_URL;
fixture`SLQ Happy Path`
    .page`${TEST_URL}`;

test('Default fields for the flow render and I can get a quote', async () => {
    await landingPage.startQuote('QuickQuote');

    await vehiclePage.checkDefaultFieldsShowOnVehiclePage();
    await vehiclePage.selectVehicleMake();
    await vehiclePage.selectVehicleModel();
    await vehiclePage.selectVehicleYear();
    await commonLocators.goNext();

    await locationPage.checkDefaultFieldsShowOnLocationPage();
    await locationPage.enterAddressLookupData();
    await locationPage.selectAddressFromTypeahead();
    await commonLocators.goNext();

    await yourAgePage.checkDefaultFieldsShowOnAgePage();
    // Change default age to 25 to avoid UW issues being thrown
    await yourAgePage.clickOnIncreaseStepperButton(9);
    await yourAgePage.agreeToTermsAndConditions();
    await commonLocators.goNext();

    await estimationPage.checkDefaultFieldsShow();
    const submissionNumber = await estimationPage.getSubmissionNumber();
    const newSubmissionNumber = submissionNumber.replace(/[^0-9]/g,'');

    const response = await dataFetch.getQuoteData(slqSampleData.postalCode, newSubmissionNumber);
    await estimationPage.verifyRetrievedSubmissionIsQuoted(response.quoteData.offeredQuotes[0]);
}).meta({Platform: 'all', Application : "QnB" });

