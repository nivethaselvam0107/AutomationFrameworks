import {Selector, t} from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import slqSampleData from '../../data/slq/sampleData.json5';

const helper = new Helper();
const assert = new Assertions();

export default class LocationPage {
    constructor() {
        this.slqNavigationButtons = Selector('#slqNavigationButtons');
        this.slqLocationPageTitle = Selector('#slqYourLocationPage');

        this.slqLocationPageAddressLookup = Selector('#slqAddressLookup');
        this.slqLocationPageAddressNotInListLink = Selector('#addressNotInList');
        this.slqLocationPageInformationText = Selector('#informationText');
        this.slqLocationPageGoogleMap = Selector('#googleMapContainer');
        this.slqLocationPageClearTypeaheadSearchIcon = Selector('#slqAddressLookup_clearTypeaheadSearch');
        this.slqLocationPageTypeaheadResultList = Selector('#slqAddressLookup_typeaheadDropdownList');

        this.slqLocationPageAddressLine1 = Selector('#addressLine1');
        this.slqLocationPageCity = Selector('#city');
        this.slqLocationPagePostalCode = Selector('#postalCode');
        this.slqLocationPageState = Selector('#state');
        this.slqLocationPageBackToAddressSearchLink = Selector('#backToAddressSearch');
    }

    /**
     * Helper methods start
     */
    async switchToManualEntryMode() {
        await helper.click(this.slqLocationPageAddressNotInListLink);
    }

    async switchToAddressLookupMode() {
        await helper.click(this.slqLocationPageBackToAddressSearchLink);
    }

    async enterAddressLookupData() {
        await t.typeText(this.slqLocationPageAddressLookup, slqSampleData.addressTypeaheadData);
        // FIXME - the below is a workaround to simulate a keydown event as this is what the onchange triggers on
        await helper.pressKey('space');
    }

    async selectAddressFromTypeahead() {
        const optionToSelect = this.slqLocationPageTypeaheadResultList.find('li').withAttribute('role', 'option').withText(slqSampleData.typeaheadAddressSearchResult);
        await t.click(optionToSelect);
    }

    async enterManualData() {
        await helper.typeText(this.slqLocationPageAddressLine1, slqSampleData.addressLine1);
        await helper.typeText(this.slqLocationPageCity, slqSampleData.city);
        await helper.typeText(this.slqLocationPagePostalCode, slqSampleData.postalCode);
        await helper.selectDropdown(this.slqLocationPageState, slqSampleData.state);
    }

    async clearTypeaheadData() {
        await helper.click(this.slqLocationPageClearTypeaheadSearchIcon);
    }

    /**
     * Test methods start
     */
    async checkDefaultFieldsShowOnLocationPage() {
        await assert.elementPresent(this.slqNavigationButtons, 'Navigation buttons are not present');
        await assert.elementPresent(this.slqLocationPageTitle, 'Title is not present');

        await this.checkAddressLookupFieldsShow()
    }

    async checkAddressLookupFieldsShow() {
        await assert.elementPresent(this.slqLocationPageAddressLookup, 'Address Lookup field shows');
        await assert.elementPresent(this.slqLocationPageAddressNotInListLink, 'Address not in this list link shows');
        await assert.elementPresent(this.slqLocationPageInformationText, 'Information text shows');
    }

    async checkAddressFieldsShowInAddressFoundState() {
        await assert.elementPresent(this.slqLocationPageAddressLookup, 'Address Lookup field shows');
        await assert.elementPresent(this.slqLocationPageGoogleMap, 'Google Map shows');
    }

    async checkManualAddressFieldsShow() {
        await assert.elementPresent(this.slqLocationPageAddressLine1, 'Address Line 1 field shows');
        await assert.elementPresent(this.slqLocationPageCity, 'City field shows');
        await assert.elementPresent(this.slqLocationPagePostalCode, 'Postal Code field shows');
        await assert.elementPresent(this.slqLocationPageState, 'State field shows');
        await assert.elementPresent(this.slqLocationPageBackToAddressSearchLink, 'Back text shows');
    }

    async checkAddressLookupFieldContainsExpectedData() {
        await assert.assertEqual(this.slqLocationPageAddressLookup.getAttribute('value'), slqSampleData.typeaheadAddressSearchResult);
    }

    async checkManualAddressFieldsContainExpectedData() {
        await assert.assertEqual(this.slqLocationPageAddressLine1.getAttribute('value'), slqSampleData.addressLine1);
        await assert.assertEqual(this.slqLocationPageCity.getAttribute('value'), slqSampleData.city);
        await assert.assertEqual(this.slqLocationPagePostalCode.getAttribute('value'), slqSampleData.postalCode);
        await assert.assertEqual(this.slqLocationPageState.innerText, slqSampleData.state);
    }

    async verifyMapShows() {
        await assert.elementPresent(this.slqLocationPageGoogleMap, 'Google map is not present');
    }
}
