import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import slqSampleData from '../../data/slq/sampleData.json5';

const helper = new Helper();
const assert = new Assertions();

export default class YourAgePage {
    constructor() {
        this.slqNavigationButtons = Selector('#slqNavigationButtons');
        this.slqAgePageTitle = Selector('#slqYourAgePage');

        this.slqAgeInputField = Selector('#youngestDriverAge');
        this.slqAgeStepperMinusButton = Selector('button').withAttribute('aria-label', 'Decrease value');
        this.slqAgeStepperPlusButton = Selector('button').withAttribute('aria-label', 'Increase value');
        this.slqAgeTermsAndConditionsCheckbox = Selector('span').withAttribute('aria-label', 'I agree to: Terms and Conditions');
    }

    /**
     * Helper methods start
     */
    async clickOnIncreaseStepperButton(times) {
        for (let i=0; i < times; i++) {
            await helper.click(this.slqAgeStepperPlusButton)
        }
    }

    async clickOnDecreaseStepperButton(times) {
        for (let i=0; i < times; i++) {
            await helper.click(this.slqAgeStepperMinusButton)
        }
    }

    async agreeToTermsAndConditions() {
        await helper.click(this.slqAgeTermsAndConditionsCheckbox);
    }

    async enterDriverAge(driverAge = slqSampleData.driverAge) {
        await helper.typeText(this.slqAgeInputField, driverAge);
    }

    /**
     * Test methods start
     */
    async checkDefaultFieldsShowOnAgePage() {
        await assert.elementPresent(this.slqNavigationButtons, 'Navigation buttons are not present');
        await assert.elementPresent(this.slqAgePageTitle, 'Title is not present');

        await assert.elementPresent(this.slqAgeInputField, 'Age input field is not present');
        await assert.elementPresent(this.slqAgeStepperMinusButton, 'Selector minus button is not present');
        await assert.elementPresent(this.slqAgeStepperPlusButton, 'Selector plus is not present');
        await assert.elementPresent(this.slqAgeTermsAndConditionsCheckbox, 'Terms and conditions checkbox is not present');
    }

    async verifyMinusButtonIsDisabled() {
        await assert.assertEqual(this.slqAgeStepperMinusButton.hasAttribute('disabled'), true);
    }

    async verifyPlusButtonIsDisabled() {
        await assert.assertEqual(this.slqAgeStepperPlusButton.hasAttribute('disabled'), true);
    }

    async verifyInputHasExpectedValue(expectedValue) {
        await assert.assertEqual(this.slqAgeInputField.getAttribute('value'), expectedValue);
    }

    async verifyDriverAgeIsSetToMin() {
        await assert.assertEqual(this.slqAgeInputField.getAttribute('value'), slqSampleData.minDriverAge);
    }

    async verifyTermsAndConditionsAreChecked() {
        await assert.assertEqual(this.slqAgeTermsAndConditionsCheckbox.getAttribute('aria-checked'), 'true');
    }

}
