import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import slqSampleData from '../../data/slq/sampleData.json5';

const helper = new Helper();
const assert = new Assertions();

export default class EstimatePage {
    constructor() {
        this.slqNavigationButtons = Selector('#slqNavigationButtons');
        this.slqEstimationPageStartOverLink = Selector('#slqStartOverLink');
        this.slqEstimationPageTitle = Selector('#slqEstimationPageTitle');

        this.slqEstimationPageImage = Selector('#slqEstimationImage');
        this.slqEstimationMonthlyCostContainer = Selector('#slqEstimationMonthlyCostContainer');
        this.slqEstimationAnnualCostContainer = Selector('#slqEstimationAnnualCostContainer');

        this.slqEstimationPageInformationText = Selector('#slqInformationTextContainer');
        this.slqEstimationPageEmailAddressInput = Selector('#slqEmailAddressInput');
        this.slqEstimationPageSendEmailButton = Selector('#slqSendEmailButton');
        this.slqEstimationPageInformationNotification = Selector('#informationText');

        this.slqEstimationPageModal = Selector('#modalProvider');
        this.slqEstimationPageModalQuoteEmailed = Selector('div').withText('Quote Emailed');
        this.slqEstimatePageModalOKBUtton = Selector('button').withText('Ok');
    }

    /**
     * Helper methods start
     */
    async enterEmailAddress() {
        await helper.typeText(this.slqEstimationPageEmailAddressInput, slqSampleData.emailAddress);
    }

    async clickStartOverLink() {
        await helper.click(this.slqEstimationPageStartOverLink);
    }

    async sendEmail() {
        await helper.click(this.slqEstimationPageSendEmailButton);
    }

    async getSubmissionNumber() {
        const submissionNumberAndTextDescription = await Selector('#slqSendToYourEmailDetail');
        return submissionNumberAndTextDescription.innerText;
    }

    /**
     * Test methods start
     */
    async checkDefaultFieldsShow() {
        await assert.elementPresent(this.slqNavigationButtons, 'Navigation buttons show');
        await assert.elementPresent(this.slqEstimationPageStartOverLink, 'Start Over link shows');
        await assert.elementPresent(this.slqEstimationPageTitle, 'Page title shows');
        await assert.elementPresent(this.slqEstimationPageImage, 'Your Quote image shows');
        await assert.elementPresent(this.slqEstimationMonthlyCostContainer, 'Monthly Cost Container shows');
        await assert.elementPresent(this.slqEstimationAnnualCostContainer, 'Annual Cost Container shows');
        await assert.elementPresent(this.slqEstimationPageInformationText, 'Information text container shows');
        await assert.elementPresent(this.slqEstimationPageEmailAddressInput, 'Email Address input shows');
        await assert.elementPresent(this.slqEstimationPageSendEmailButton, 'Send email button shows');
        await assert.elementPresent(this.slqEstimationPageInformationNotification, 'Information Notification shows');
    }

    async verifyRetrievedSubmissionIsQuoted(offeredQuote) {
        await assert.assertEqual(offeredQuote.status, 'Quoted', 'Offered Quote is not in a Quoted state');
    }

    async verifySuccessModalAppears() {
        await assert.elementPresent(this.slqEstimationPageModal, 'Modal appears');
        await assert.elementPresent(this.slqEstimationPageModalQuoteEmailed, 'Modal title appears');
        await assert.elementPresent(this.slqEstimatePageModalOKBUtton, 'Ok button appears');
    }
}
