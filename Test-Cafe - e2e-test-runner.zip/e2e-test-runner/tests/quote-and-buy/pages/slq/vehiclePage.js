import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import slqSampleData from '../../data/slq/sampleData.json5';

const helper = new Helper();
const assert = new Assertions();

export default class VehiclePage {
    constructor() {
        this.slqNavigationButtons = Selector('#slqNavigationButtons');
        this.slqVehiclePageTitle = Selector('#slqYourVehiclePage');

        this.slqVehiclePageVehicleTypeToggle = Selector('#vehicleEntryType');
        this.slqVehiclePageMakeModelYearSelector = Selector('button').withText('Make, Model, Year');
        this.slqVehiclePageEnterVINSelector = Selector('button').withText('or Enter VIN');

        this.slqVehiclePageMakeDropdown = Selector('#make');
        this.slqVehiclePageModelDropdown = Selector('#model');
        this.slqVehiclePageYearDropdown = Selector('#year');

        this.slqVehiclePageVINInputField = Selector('#vehicleVin');
        this.slqVehiclePageVINPrefilVehicleMake = Selector('#vehicleMake');
        this.slqVehiclePageVINPrefilVehicleModel = Selector('#vehicleModel');
        this.slqVehiclePageVINPrefilVehicleYear = Selector('#vehicleYear');
        this.slqVehiclePageVINInfoText = Selector('#vinInfoText');
    }

    /**
     * Helper methods start
     */
    async clickManualEntryOptionInToggle() {
        await helper.click(this.slqVehiclePageMakeModelYearSelector, { timeout: 30000 });
    }

    async clickVinLookupOptionInToggle() {
        await helper.click(this.slqVehiclePageEnterVINSelector, { timeout: 30000 });
    }

    async selectVehicleMake() {
        await helper.selectDropdown(this.slqVehiclePageMakeDropdown, slqSampleData.slqVehicleMake);
    }

    async selectVehicleModel() {
        await helper.selectDropdown(this.slqVehiclePageModelDropdown, slqSampleData.slqVehicleModel);
    }

    async selectVehicleYear() {
        await helper.selectDropdown(this.slqVehiclePageYearDropdown, slqSampleData.slqVehicleYear);
    }

    async enterVIN() {
        await helper.typeText(this.slqVehiclePageVINInputField, slqSampleData.slqVehicleVIN);
    }

    /**
     * Test methods start
     */
    async checkDefaultFieldsShowOnVehiclePage() {
        await assert.elementPresent(this.slqNavigationButtons, 'Navigation buttons are not present');
        await assert.elementPresent(this.slqVehiclePageTitle, 'Title is not present');

        await assert.elementPresent(this.slqVehiclePageVehicleTypeToggle, 'Vehicle type toggle is not present');
        await assert.elementPresent(this.slqVehiclePageMakeModelYearSelector, 'Make, Model, Year selector is not present');
        await assert.elementPresent(this.slqVehiclePageEnterVINSelector, 'Vin Lookup toggle is not present');

        await this.checkManualEntryFieldsShow();
    }

    async checkManualEntryFieldsShow() {
        await assert.elementPresent(this.slqVehiclePageMakeDropdown, 'Vehicle Make dropdown is not present');
        await assert.elementPresent(this.slqVehiclePageModelDropdown, 'Vehicle Model dropdown is not present');
        await assert.elementPresent(this.slqVehiclePageYearDropdown, 'Vehicle Year dropdown is not present');
    }

    async checkMakeModelYearToggleIsSelected() {
        await assert.assertEqual(this.slqVehiclePageMakeModelYearSelector.getAttribute('data-value'), 'true');
    }

    async checkVinLookupFieldsShow() {
        await assert.elementPresent(this.slqVehiclePageVINInputField, 'VIN Input Field is not present');
        await assert.elementPresent(this.slqVehiclePageVINInfoText, 'VIN Info Text is not present');
    }

    async verifyManualEntrySelectionHasBeenRetained() {
        await assert.assertEqual(this.slqVehiclePageMakeDropdown.innerText, slqSampleData.slqVehicleMake);
        await assert.assertEqual(this.slqVehiclePageModelDropdown.innerText, slqSampleData.slqVehicleModel);
        await assert.assertEqual(this.slqVehiclePageYearDropdown.innerText, slqSampleData.slqVehicleYear);
    }

    async vehicleDetailsArePopulatedAndAreReadonly() {
        await assert.elementPresent(this.slqVehiclePageVINPrefilVehicleMake, 'Vehicle Make is not present');
        await assert.elementPresent(this.slqVehiclePageVINPrefilVehicleModel, 'Vehicle Model is not present');
        await assert.elementPresent(this.slqVehiclePageVINPrefilVehicleYear, 'Vehicle Year is not present');

        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleMake.getAttribute('data-read-only'), 'true');
        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleModel.getAttribute('data-read-only'), 'true');
        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleYear.getAttribute('data-read-only'), 'true');
    }

    async vehicleDetailsArePopulatedWithCorrectVehicleData() {
        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleMake.innerText, slqSampleData.slqVehicleMake);
        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleModel.innerText, slqSampleData.slqVehicleModel);
        await assert.assertEqual(this.slqVehiclePageVINPrefilVehicleYear.innerText, slqSampleData.slqVehicleYear);
    }

}
