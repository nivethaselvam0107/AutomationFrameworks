/* eslint-disable class-methods-use-this */
import { Selector } from 'testcafe';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const commonLocators = new CommonLocators();

export default class additionalInformationPage {
    constructor() {
        this.bopAdditionalInformationTitle = Selector('#additionalInformationPage');
        this.bopAdditionalInformationPhoneNumber = Selector('#phoneNumberFieldTitle_\\[0\\]');
    }

    async enterPhoneNumber(phoneNumber) {
        await helper.typeText(this.bopAdditionalInformationPhoneNumber, phoneNumber);
    }

    async additionalInformationNext() {
        await commonLocators.goNext();
    }
}
