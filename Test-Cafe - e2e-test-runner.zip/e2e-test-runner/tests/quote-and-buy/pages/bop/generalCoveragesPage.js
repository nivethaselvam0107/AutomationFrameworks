/* eslint-disable class-methods-use-this */
import { Selector } from 'testcafe';
import _ from 'lodash';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class generalCoveragesPage {
    constructor() {
        this.bopGeneralCoveragesTitle = Selector('#generalCoveragesPageTitle');
        this.bopGeneralCoveragesGuestLiabilityCoveragesGuestProperty = Selector('#_BOPGuestPropCov').nextSibling();
        this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertyLimitPerGuest = Selector('select[id*="ClauseTerm_[BOPGuestPropCov]_[0]"]');
        this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertyOccurrenceLimit = Selector('select[id*="ClauseTerm_[BOPGuestPropCov]_[1]"]');
        this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertySafeDeposit = Selector('#_BOPGuestSafeDepCov').nextSibling();
        this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertySafeDepositLimit = Selector('select[id*="ClauseTerm_[BOPGuestSafeDepCov]_[0]"]');
        this.bopGeneralCoveragesLiabilityLimitsOccurrence = Selector('#ClauseTerm_\\[BOPLiabilityCov\\]_\\[0\\]');
        this.bopGeneralCoveragesPdDeductable = Selector('#ClauseTerm_\\[BOPLiabilityCov\\]_\\[1\\]');
        this.bopGeneralCoveragesPdDeductableType = Selector('#ClauseTerm_\\[BOPLiabilityCov\\]_\\[2\\]');
        this.bopGeneralCoveragesTenantsFireLiabilityLimit = Selector('#ClauseTerm_\\[BOPTenantFireCov\\]_\\[0\\]');
        this.bopGeneralCoveragesBOPPersAdvertInjury = Selector('span[aria-label="Personal and Advertising Injury"]');
        this.bopGeneralCoveragesSpecialCoverages = Selector('#ClauseTerm_\\[BOPAdditionalCov\\]_\\[0\\]');
        this.bopGeneralCoveragesNonOwnedAutoLiability = Selector('span[aria-label="Non-owned Auto Liability"]');
        this.bopGeneralCoveragesHiredAuto = Selector('span[aria-label="Hired Auto"]');
        this.bopGeneralCoveragesPropertyCoverages = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[1\\]');
        this.bopGeneralCoveragesPropertyPropertyBaseDeductible = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[0\\]');
        this.bopGeneralCoveragesPropertyOptionalCoveragesDeductibl = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[1\\]');
        this.bopGeneralCoveragesPropertyGlassDeductible = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[2\\]');
        this.bopGeneralCoveragesPropertyPropertyOptionalDeductible = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[3\\]');
        this.bopGeneralCoveragesPropertyCauseOfLoss = Selector('#ClauseTerm_\\[BOPPropertyCov\\]_\\[4\\]');
    }

    async checkDefaultFieldsShowOnGeneralCoveragesPage() {
        await assert.elementPresent(this.bopGeneralCoveragesTitle, 'Title is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async changeCoverages(pdDeductible, option, optionCoveragesDeductible, causeOfLoss) {
        await helper.selectDropdown(this.bopGeneralCoveragesPdDeductable, pdDeductible);
        await helper.click(this.bopGeneralCoveragesBOPPersAdvertInjury);
        await helper.selectDropdown(this.bopGeneralCoveragesSpecialCoverages, option);
        await helper.click(this.bopGeneralCoveragesNonOwnedAutoLiability);
        await helper.click(this.bopGeneralCoveragesHiredAuto);
        await helper.selectDropdown(
            this.bopGeneralCoveragesPropertyCoverages, optionCoveragesDeductible
        );
        await helper.selectDropdown(this.bopGeneralCoveragesPropertyCauseOfLoss, causeOfLoss);
    }

    async verifyChangesToCoverage(response) {
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPPersAdvertInj').selected, false, 'Personal and Injury coverage was not deselected');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPHiredAuto').selected, true, 'Hired auto was not selected');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPNonOwnedAutoCov').selected, true, 'Non owned auto liability was not selected');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPAdditionalCov').terms[0].chosenTermValue, 'Merchant\'s Risk Pack', 'special coverage package do not match');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPPropertyCov').terms.find((elem) => elem.publicID === 'BOPPropertyCovCauseOfLoss').chosenTermValue, 'Named Perils', 'Cause of loss do not match');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPPropertyCov').terms.find((elem) => elem.publicID === 'BOPOptCovDed').chosenTermValue, '2,500', 'Optional coverage deductible do not match');
        await assert.assertEqual(response.lobCoverages.find((element) => element.publicID === 'BOPLiabilityCov').terms.find((elem) => elem.publicID === 'BOPLiabPDDeductible').chosenTermValue, '250', 'PD deductable did not match');
    }


    async generalCoveragesNext() {
        await commonLocators.goNext();
    }

    async clickSideBarGeneralCoveragesPage() {
        await helper.clickButtonWithText('General Coverages');
    }

    async getLiabilityLimitValue() {
        await this.bopGeneralCoveragesLiabilityLimitsOccurrence;
        return this.bopGeneralCoveragesLiabilityLimitsOccurrence.prevSibling().innerText;
    }

    async getLiabilityPdDeductible() {
        await this.bopGeneralCoveragesPdDeductable;
        return this.bopGeneralCoveragesPdDeductable.prevSibling().innerText;
    }

    async getLiabilityPdDeductibleType() {
        await this.bopGeneralCoveragesPdDeductableType;
        return this.bopGeneralCoveragesPdDeductableType.prevSibling().innerText;
    }

    async getTenantsFireLiabilityLimit() {
        await this.bopGeneralCoveragesTenantsFireLiabilityLimit;
        return this.bopGeneralCoveragesTenantsFireLiabilityLimit.prevSibling().innerText;
    }

    async getSpecialCoveragePackage() {
        await this.bopGeneralCoveragesSpecialCoverages;
        return this.bopGeneralCoveragesSpecialCoverages.prevSibling().innerText;
    }

    async getPropertyBaseDeductible() {
        await this.bopGeneralCoveragesPropertyPropertyBaseDeductible;
        return this.bopGeneralCoveragesPropertyPropertyBaseDeductible.prevSibling().innerText;
    }

    async getOptionalCoveragesDeductible() {
        await this.bopGeneralCoveragesPropertyOptionalCoveragesDeductibl;
        return this.bopGeneralCoveragesPropertyOptionalCoveragesDeductibl.prevSibling().innerText;
    }

    async getGlassDeductible() {
        await this.bopGeneralCoveragesPropertyGlassDeductible;
        return this.bopGeneralCoveragesPropertyGlassDeductible.prevSibling().innerText;
    }

    async getPropertyOptionalDeductible() {
        await this.bopGeneralCoveragesPropertyPropertyOptionalDeductible;
        return this.bopGeneralCoveragesPropertyPropertyOptionalDeductible.prevSibling().innerText;
    }

    async getCauseOfLoss() {
        await this.bopGeneralCoveragesPropertyCauseOfLoss;
        return this.bopGeneralCoveragesPropertyCauseOfLoss.prevSibling().innerText;
    }

    async verifyGeneralCoveragesDataIsRetained(
        limits,
        pdDeductible,
        pdDeductibleType,
        tenantsFireLiability,
        specialCoveragePackages,
        propertyBaseDeductible,
        optionCoveragesDeductible,
        glassDeductible,
        propertyOptionalDeductible,
        causeOfLoss
    ) {
        await assert.assertEqual(await this.getLiabilityLimitValue(), limits, 'Incorrect value for Limits: Occurrence / Prod Agg / Gen Agg');
        await assert.assertEqual(await this.getLiabilityPdDeductible(), pdDeductible, 'Incorrect value for PD Deductible');
        await assert.assertEqual(await this.getLiabilityPdDeductibleType(), pdDeductibleType, 'Incorrect value for PD Deductible Type');
        await assert.assertEqual(await this.getTenantsFireLiabilityLimit(), tenantsFireLiability, 'Incorrect value for Tenants Fire Liability Limit');
        await assert.assertAttributeValue(await this.bopGeneralCoveragesBOPPersAdvertInjury, 'aria-checked', 'false', 'Personal and Advertising Injury is checked');
        await assert.assertEqual(await this.getSpecialCoveragePackage(), specialCoveragePackages, 'Incorrect value for Special Coverage Packages');
        await assert.assertAttributeValue(await this.bopGeneralCoveragesNonOwnedAutoLiability, 'aria-checked', 'true', 'Non Owned Auto Liability not checked');
        await assert.assertAttributeValue(await this.bopGeneralCoveragesHiredAuto, 'aria-checked', 'true', 'Hired Auto not checked');
        await assert.assertEqual(await this.getPropertyBaseDeductible(), propertyBaseDeductible, 'Incorrect value for Property Base Deductible');
        await assert.assertEqual(await this.getOptionalCoveragesDeductible(), optionCoveragesDeductible, 'Incorrect value for Optional Coverages Deductible');
        await assert.assertEqual(await this.getGlassDeductible(), glassDeductible, 'Incorrect value for Glass Deductible');
        await assert.assertEqual(await this.getPropertyOptionalDeductible(), propertyOptionalDeductible, 'Incorrect value for Property Optional Deductible');
        await assert.assertEqual(await this.getCauseOfLoss(), causeOfLoss, 'Incorrect value for Cause Of Loss');
    }

    async selectAndVerifyGeneralCoverageDependencies(logger) {
        await helper.click(this.bopGeneralCoveragesGuestLiabilityCoveragesGuestProperty);
        await assert.elementPresent(
            this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertyLimitPerGuest,
            'Guest Property - limit per Guest not displayed'
        );
        await this.verifyCoverageDependenciesCall(logger);
        await assert.elementPresent(
            this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertyOccurrenceLimit,
            'Guests Property Occurrence Limit not displayed'
        );
        await helper.click(this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertySafeDeposit);
        await assert.elementPresent(
            this.bopGeneralCoveragesGuestLiabilityCoveragesGuestPropertySafeDepositLimit,
            'Guest Property - Safe Deposit Limit not displayed'
        );
        await this.verifyCoverageDependenciesCall(logger);
    }

    async verifyCoverageDependenciesCall(logger) {
        const lastNetworkRequest = _.last(logger.requests);
        await assert.assertEqual(lastNetworkRequest.response.statusCode.toString(), '200', 'Update Coverage call has incorrect response code');
        await assert.assertContains(lastNetworkRequest.request.body, 'updateCoverages', 'Update Coverage call has wrong method');
    }
}
