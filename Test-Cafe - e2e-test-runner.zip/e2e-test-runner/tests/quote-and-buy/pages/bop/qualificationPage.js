/* eslint-disable class-methods-use-this */
import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const assert = new Assertions();
const commonLocators = new CommonLocators();
const helper = new Helper();

export default class qualificationPage {
    constructor() {
        this.bopQualificationTitle = Selector('#questionSets_questionSetHeader');
        this.bopQualificationPolicyRejected = Selector('#PolicyRejected');
        this.bopQualificationForeclosure = Selector('#Foreclosure');
        this.bopQualificationCatastrophe = Selector('#Catastrophe');
        this.bopQualificationApplicantArson = Selector('#ApplicantArson');
        this.bopQualificationPersonnelIssues = Selector('#PersonnelIssues');
        this.bopQualificationOtherInsurance = Selector('#OtherInsurance');
        this.bopQualificationOtherBusiness2 = Selector('#OtherBusiness2');
        this.bopQualificationFireCode = Selector('#FireCode');
        this.bopQualificationFlammables = Selector('#Flammables');
        this.bopQualificationHazardousMaterial = Selector('#HazardousMaterial');
        this.bopQualificationManufacturing = Selector('#Manufacturing');
        this.bopQualificationRentEquipment = Selector('#RentEquipment');
        this.bopQualificationLeaseEmployees = Selector('#LeaseEmployees');
        this.bopQualificationBOPBusinessownersPreQualWorkersComp = Selector('#BOPBusinessownersPreQualWorkersComp');
        this.bopQualificationSubContractors = Selector('#SubContractors');
        this.bopQualificationAthleticTeams = Selector('#AthleticTeams');
    }

    async checkDefaultFieldsShowOnQualificationPage() {
        await assert.elementPresent(this.bopQualificationTitle, 'Title is not present');
        await assert.elementPresent(this.bopQualificationPolicyRejected, 'PolicyRejected question is not present');
        await assert.elementPresent(this.bopQualificationForeclosure, 'Foreclosure question is not present');
        await assert.elementPresent(this.bopQualificationCatastrophe, 'Catastrophe question is not present');
        await assert.elementPresent(this.bopQualificationApplicantArson, 'ApplicantArson question is not present');
        await assert.elementPresent(this.bopQualificationPersonnelIssues, 'PersonnelIssues question is not present');
        await assert.elementPresent(this.bopQualificationOtherInsurance, 'OtherInsurance question is not present');
        await assert.elementPresent(this.bopQualificationOtherBusiness2, 'OtherBusiness2 question is not present');
        await assert.elementPresent(this.bopQualificationFireCode, 'FireCode question is not present');
        await assert.elementPresent(this.bopQualificationFlammables, 'Flammables question is not present');
        await assert.elementPresent(this.bopQualificationHazardousMaterial, 'HazardousMaterial question is not present');
        await assert.elementPresent(this.bopQualificationManufacturing, 'Manufacturing question is not present');
        await assert.elementPresent(this.bopQualificationRentEquipment, 'RentEquipment question is not present');
        await assert.elementPresent(this.bopQualificationLeaseEmployees, 'Employees question is not present');
        await assert.elementPresent(this.bopQualificationBOPBusinessownersPreQualWorkersComp, 'BOPBusinessownersPreQualWorkersComp question is not present');
        await assert.elementPresent(this.bopQualificationSubContractors, 'SubContractors question is not present');
        await assert.elementPresent(this.bopQualificationAthleticTeams, 'AthleticTeams question is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async clickNoForAllFields() {
        await helper.click(this.bopQualificationPolicyRejected.child('button').withText('No'));
        await helper.click(this.bopQualificationCatastrophe.child('button').withText('No'));
        await helper.click(this.bopQualificationApplicantArson.child('button').withText('No'));
        await helper.click(this.bopQualificationForeclosure.child('button').withText('No'));
        await helper.click(this.bopQualificationPersonnelIssues.child('button').withText('No'));
        await helper.click(this.bopQualificationOtherInsurance.child('button').withText('No'));
        await helper.click(this.bopQualificationOtherBusiness2.child('button').withText('No'));
        await helper.click(this.bopQualificationFireCode.child('button').withText('No'));
        await helper.click(this.bopQualificationFlammables.child('button').withText('No'));
        await helper.click(this.bopQualificationHazardousMaterial.child('button').withText('No'));
        await helper.click(this.bopQualificationManufacturing.child('button').withText('No'));
        await helper.click(this.bopQualificationRentEquipment.child('button').withText('No'));
        await helper.click(this.bopQualificationLeaseEmployees.child('button').withText('No'));
        await helper.click(this.bopQualificationBOPBusinessownersPreQualWorkersComp.child('button').withText('No'));
        await helper.click(this.bopQualificationSubContractors.child('button').withText('No'));
        await helper.click(this.bopQualificationAthleticTeams.child('button').withText('No'));
    }

    async clickYesForLeasedAndCompCarried() {
        await helper.click(this.bopQualificationLeaseEmployees.child('button').withText('Yes'));
        await helper.click(this.bopQualificationBOPBusinessownersPreQualWorkersComp.child('button').withText('Yes'));
        await helper.click(this.bopQualificationPolicyRejected.child('button').withText('No'));
        await helper.click(this.bopQualificationCatastrophe.child('button').withText('No'));
        await helper.click(this.bopQualificationApplicantArson.child('button').withText('No'));
        await helper.click(this.bopQualificationForeclosure.child('button').withText('No'));
        await helper.click(this.bopQualificationPersonnelIssues.child('button').withText('No'));
        await helper.click(this.bopQualificationOtherInsurance.child('button').withText('No'));
        await helper.click(this.bopQualificationOtherBusiness2.child('button').withText('No'));
        await helper.click(this.bopQualificationFireCode.child('button').withText('No'));
        await helper.click(this.bopQualificationFlammables.child('button').withText('No'));
        await helper.click(this.bopQualificationHazardousMaterial.child('button').withText('No'));
        await helper.click(this.bopQualificationManufacturing.child('button').withText('No'));
        await helper.click(this.bopQualificationRentEquipment.child('button').withText('No'));
        await helper.click(this.bopQualificationSubContractors.child('button').withText('No'));
        await helper.click(this.bopQualificationAthleticTeams.child('button').withText('No'));
    }

    async verifyYesForLeasedAndCompCarried(response) {
        await assert.assertEqual(response.RentEquipment, 'false', 'rent equipment is not false');
        await assert.assertEqual(response.PolicyRejected, 'false', 'policy Rejected is not false');
        await assert.assertEqual(response.Foreclosure, 'false', 'Force closure is not false');
        await assert.assertEqual(response.HazardousMaterial, 'false', 'hazardous material is not false');
        await assert.assertEqual(response.AthleticTeams, 'false', 'athletic team is not false');
        await assert.assertEqual(response.Flammables, 'false', 'flammables is not false');
        await assert.assertEqual(response.OtherBusiness2, 'false', 'other business is not false');
        await assert.assertEqual(response.LeaseEmployees, 'true', 'lease is not true');
        await assert.assertEqual(response.PersonnelIssues, 'false', 'personnel issues is not false');
        await assert.assertEqual(response.ApplicantArson, 'false', 'applicant arson is not false');
        await assert.assertEqual(response.Catastrophe, 'false', 'catastrophe is not false');
        await assert.assertEqual(response.BOPBusinessownersPreQualWorkersComp, 'true', 'workers comp is not true');
        await assert.assertEqual(response.SubContractors, 'false', 'subcontractors is not false');
        await assert.assertEqual(response.FireCode, 'false', 'firecode is not false');
        await assert.assertEqual(response.Manufacturing, 'false', 'manufacturing is not false');
        await assert.assertEqual(response.OtherInsurance, 'false', 'other insurance is not false');
    }

    async verifyQualificationDataIsRetained() {
        await assert.assertAttributeValue('#PolicyRejected > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Policy Rejected');
        await assert.assertAttributeValue('#Foreclosure > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Foreclosure');
        await assert.assertAttributeValue('#Catastrophe > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Catastrophe');
        await assert.assertAttributeValue('#ApplicantArson > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Applicant Arson');
        await assert.assertAttributeValue('#PersonnelIssues > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Personnel Issues');
        await assert.assertAttributeValue('#OtherInsurance > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Other Insurance');
        await assert.assertAttributeValue('#OtherBusiness2 > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Other Business2');
        await assert.assertAttributeValue('#FireCode > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for FireCode');
        await assert.assertAttributeValue('#Flammables > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Flammables');
        await assert.assertAttributeValue('#HazardousMaterial > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Hazardous Material');
        await assert.assertAttributeValue('#Manufacturing > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Manufacturing');
        await assert.assertAttributeValue('#RentEquipment > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for Rent Equipment');
        await assert.assertAttributeValue('#LeaseEmployees [class*="ToggleField-module__active"]', 'data-value', 'true', 'Incorrect value selected for Lease Employees');
        await assert.assertAttributeValue('#BOPBusinessownersPreQualWorkersComp > [class*="ToggleField-module__active"]', 'data-value', 'true', 'Incorrect value selected for Workers Comp');
        await assert.assertAttributeValue('#SubContractors > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for SubContractors');
        await assert.assertAttributeValue('#AthleticTeams > [class*="ToggleField-module__active"]', 'data-value', 'false', 'Incorrect value selected for AthleticTeams');
    }


    async qualificationNext() {
        await commonLocators.goNext();
    }

    async clickSideBarQualificationPage() {
        await helper.clickButtonWithText('Qualification');
    }
}
