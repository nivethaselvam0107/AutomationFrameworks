import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class yourInfoPage {
    constructor() {
        this.bopYourInfoTitle = Selector('#yourInfoPage');
        this.bopYourInfoCompanyName = Selector('#companyName');
        this.bopYourInfoAddressLine1 = Selector('#addressLine1');
        this.bopYourInfoAddressLine2 = Selector('#addressLine2');
        this.bopYourInfoAddressLine3 = Selector('#addressLine3');
        this.bopYourInfoCity = Selector('#city');
        this.bopYourInfoZipCode = Selector('#zipCode');
        this.bopYourInfoState = Selector('#state');
        this.bopYourInfoEmail = Selector('#email');
        this.bopYourInfoSecondaryTitle = Selector('#forYourQuote');
        this.bopYourInfoStartDate = Selector('#startDate');
        this.bopYourInfoOrganizationType = Selector('#organisationType');
        this.bopYourInfoSmallBusinessType = Selector('#smallBusinessType');
    }

    async checkDefaultFieldsShowOnYourInfoPage() {
        await assert.elementPresent(this.bopYourInfoTitle, 'Title is not present');
        await assert.elementPresent(this.bopYourInfoCompanyName, 'Company Name is not present');
        await assert.elementPresent(this.bopYourInfoAddressLine1, 'Address Line 1 is not present');
        await assert.elementPresent(this.bopYourInfoAddressLine2, 'Address Line 2 is not present');
        await assert.elementPresent(this.bopYourInfoAddressLine3, 'Address Line 3 is not present');
        await assert.elementPresent(this.bopYourInfoCity, 'City is not present');
        await assert.elementPresent(this.bopYourInfoZipCode, 'Zip Code is not present');
        await assert.elementPresent(this.bopYourInfoState, 'State is not present');
        await assert.elementPresent(this.bopYourInfoSecondaryTitle, 'Secondary title is not present');
        await assert.elementPresent(this.bopYourInfoStartDate, 'Start Date is not present');
        await assert.elementPresent(this.bopYourInfoOrganizationType, 'Organization Type is not present');
        await assert.elementPresent(this.bopYourInfoSmallBusinessType, 'Small Business Type is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async fillBasicInfo(companyName, email, city, addressLine1, addressLine2, addressLine3) {
        await helper.typeText(this.bopYourInfoCompanyName, companyName);
        await helper.typeText(this.bopYourInfoCity, city);
        await helper.typeText(this.bopYourInfoAddressLine1, addressLine1);
        await helper.typeText(this.bopYourInfoAddressLine2, addressLine2);
        await helper.typeText(this.bopYourInfoAddressLine3, addressLine3);
        await helper.typeText(this.bopYourInfoEmail, email);
    }

    async fillYourQuoteInfo(organizationType, smallBusinessType, coverageDate) {
        await helper.selectDropdown(this.bopYourInfoOrganizationType, organizationType);
        await helper.selectDropdown(this.bopYourInfoSmallBusinessType, smallBusinessType);
        await helper.typeText(this.bopYourInfoStartDate, coverageDate);
        await helper.click(commonLocators.selectedDate);
    }

    async yourInfoNext() {
        await commonLocators.goNext();
    }

    async verifyPolicyInfo(response, addressLine1, addressLine2, addressLine3, city, stateCode, ZipCode, companyName, addressType) {
        const stateAndZipCode = `${stateCode} ${ZipCode}`;
        const policyAddress = [addressLine1, addressLine2, addressLine3, city, stateAndZipCode].join(', ');
        await assert.assertEqual(response.baseData.policyAddress.state, stateCode, 'state do not match');
        await assert.assertEqual(response.baseData.policyAddress.displayName, policyAddress, 'policyAddress do not match');
        await assert.assertEqual(response.baseData.policyAddress.city, city, 'city do not match');
        await assert.assertEqual(response.baseData.policyAddress.postalCode, ZipCode, 'zipCode do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine1, addressLine1, 'addressLine1 do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine2, addressLine2, 'addressLine2 do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine3, addressLine3, 'addressLine3 do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressType, addressType, 'address Type do not match');
        await assert.assertEqual(response.baseData.accountHolder.contactName, companyName, 'Company name do not match');
    }

    async verifyQuoteInfo(response, quoteID, termType, startDate, endDate, smallBusinessType, organisationType, email, periodStatus) {
        startDate = new Date(startDate);
        endDate = new Date(endDate);
        await assert.assertEqual(response.quoteID, quoteID, 'Quote ID does not match');
        await assert.assertEqual(response.baseData.termType, termType, 'term type do not match');
        await assert.assertEqual(response.baseData.periodStartDate.day, startDate.getDate(), 'start day do not match');
        await assert.assertEqual(response.baseData.periodStartDate.month, startDate.getMonth(), 'start month do not match');
        await assert.assertEqual(response.baseData.periodStartDate.year, startDate.getFullYear(), 'start year do not match');
        await assert.assertEqual(response.baseData.periodEndDate.day, endDate.getDate(), 'end day do not match');
        await assert.assertEqual(response.baseData.periodEndDate.month, endDate.getMonth(), 'end month do not match');
        await assert.assertEqual(response.baseData.periodEndDate.year, endDate.getFullYear(), 'end year do not match');
        await assert.assertEqual(response.lobData.businessOwners.smallBusinessType, smallBusinessType.toLowerCase(), 'small business type do not match');
        await assert.assertEqual(response.lobData.businessOwners.accountOrgType, organisationType.toLowerCase(), 'small business type do not match');
        await assert.assertEqual(response.baseData.accountHolder.emailAddress1, email, 'small business type do not match');
        await assert.assertEqual(response.baseData.periodStatus, periodStatus, 'Period Status does not match');
    }

    async clickSideBarYourInfo() {
        await helper.clickButtonWithText('Your Info');
    }

    async getCompanyName() {
        await this.bopYourInfoCompanyName;
        return this.bopYourInfoCompanyName.value;
    }

    async getAddressLine1() {
        await this.bopYourInfoAddressLine1;
        return this.bopYourInfoAddressLine1.value;
    }

    async getAddressLine2() {
        await this.bopYourInfoAddressLine2;
        return this.bopYourInfoAddressLine2.value;
    }

    async getAddressLine3() {
        await this.bopYourInfoAddressLine3;
        return this.bopYourInfoAddressLine3.value;
    }

    async getAddressCity() {
        await this.bopYourInfoCity;
        return this.bopYourInfoCity.value;
    }

    async getAddressZipCode() {
        await this.bopYourInfoZipCode;
        return this.bopYourInfoZipCode.innerText;
    }

    async getAddressState() {
        await this.bopYourInfoState;
        return this.bopYourInfoState.innerText;
    }

    async getEmailAddress() {
        await this.bopYourInfoEmail;
        return this.bopYourInfoEmail.value;
    }

    async getCoverageStartDate() {
        await this.bopYourInfoStartDate;
        return this.bopYourInfoStartDate.value;
    }

    async getOrganizationType() {
        await this.bopYourInfoOrganizationType;
        return this.bopYourInfoOrganizationType.prevSibling(0).innerText;
    }

    async getSmallBusinessType() {
        await this.bopYourInfoSmallBusinessType;
        return this.bopYourInfoSmallBusinessType.prevSibling(0).innerText;
    }

    async verifyYourInfoDataIsRetained(companyName, addressLine1, addressLine2, addressLine3, city, postalCode, state, email, periodStartDate, organisationType, smallBusinessType) {
        await assert.assertEqual(await this.getCompanyName(), companyName, 'Company Name does not match');
        await assert.assertEqual(await this.getAddressLine1(), addressLine1, 'Address Line 1 does not match');
        await assert.assertEqual(await this.getAddressLine2(), addressLine2, 'Address Line 2 does not match');
        await assert.assertEqual(await this.getAddressLine3(), addressLine3, 'Address Line 3 does not match');
        await assert.assertEqual(await this.getAddressCity(), city, 'City does not match');
        await assert.assertEqual(await this.getAddressZipCode(), postalCode, 'Address Postal Code does not match');
        await assert.assertEqual(await this.getAddressState(), state, 'Address State does not match');
        await assert.assertEqual(await this.getEmailAddress(), email, 'Email Address does not match');
        await assert.assertEqual(await Date(this.getCoverageStartDate()), Date(periodStartDate), 'Period Start Date does not match');
        await assert.assertEqual(await this.getOrganizationType(), organisationType, 'Organisation Type does not match');
        await assert.assertEqual(await this.getSmallBusinessType(), smallBusinessType, 'Small Business Selection does not match');
    }

    async editTextAndCheckValidationMessage() {
        await helper.removeRequiredTextAndValidate(this.bopYourInfoCompanyName);
        await helper.removeRequiredTextAndValidate(this.bopYourInfoCity);
        await helper.removeRequiredTextAndValidate(this.bopYourInfoAddressLine1);
        await helper.removeRequiredTextAndValidate(this.bopYourInfoEmail);
        await this.inputIncorrectEmailFormatAndValidate(this.bopYourInfoEmail);
    }

    async inputIncorrectEmailFormatAndValidate(bopYourInfoEmail) {
        await helper.typeText(bopYourInfoEmail, 'abc');
        await helper.pressKey('tab');
        await helper.pressKey('esc');
        await assert.assertEqual(
            await helper.getAlertMessage(bopYourInfoEmail),
            'Value must be a valid email address',
            'Incorrect alert message displayed for incorrect email format'
        );
    }

    async verifyNextIsGrayedOut() {
        await helper.verifyNextIsGrayedOut()
    }
}
