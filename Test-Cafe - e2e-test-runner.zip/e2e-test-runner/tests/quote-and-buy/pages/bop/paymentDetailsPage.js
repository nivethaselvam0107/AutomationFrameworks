import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from "../../../utilities/commonLocators";
const helper = new Helper();

const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class paymentDetailsPage {
    constructor() {
        this.bopPaymentDetailsTitle = Selector('#paymentDetailsPage');
        this.bopPaymentDetailsPaymentPlan = Selector('label[for="plan_bc:12"]');
        this.bopPaymentDetailsPaymentMethod = Selector('#paymentOptions');
        this.bopPaymentDetailsCheckingButton = Selector('button[data-value="checking"');
        this.bopPaymentDetailsAccountNumber = Selector('#accountNumber');
        this.bopPaymentDetailsRoutingNumber = Selector('#abaNumber');
        this.bopPaymentDetailsBankName = Selector('#bankName');
        this.bopPaymentDetailsCardIssuer = Selector('#creditCardIssuer');
        this.bopPaymentDetailsCardNumber = Selector('#creditCardNumber');
        this.bopPaymentDetailsExpirationMonth = Selector('#expirationMonth');
        this.bopPaymentDetailsExpirationYear = Selector('#expirationYear');

    }

    async checkDefaultFieldsShowOnPaymentDetailsPage() {
        await assert.elementPresent(this.bopPaymentDetailsTitle, 'Title is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Finish Button is not present');
    }

    async selectCheckingAccountPaymentPlan(accountNumber,routingNumber,bankName,paymentPlan){
        await helper.click(Selector(`label[for=\"${paymentPlan.value}\"]`));
        await helper.selectDropdown(this.bopPaymentDetailsPaymentMethod,'Bank Account');
        await helper.click(this.bopPaymentDetailsCheckingButton);
        await helper.typeText(this.bopPaymentDetailsAccountNumber,accountNumber);
        await helper.typeText(this.bopPaymentDetailsRoutingNumber,routingNumber);
        await helper.typeText(this.bopPaymentDetailsBankName,bankName)
    }

    async selectCreditCardPaymentPlan(cardIssuer,creditCardNumber,expirationMonth,expirationYear,paymentPlan){
        await helper.click(Selector(`label[for=\"${paymentPlan.value}\"]`));
        await helper.selectDropdown(this.bopPaymentDetailsPaymentMethod,'Credit Card');
        await helper.selectDropdown(this.bopPaymentDetailsCardIssuer,cardIssuer);
        await helper.typeText(this.bopPaymentDetailsCardNumber,creditCardNumber);
        await helper.selectDropdown(this.bopPaymentDetailsExpirationMonth,expirationMonth);
        await helper.selectDropdown(this.bopPaymentDetailsExpirationYear,expirationYear);
    }

    async paymentDetailsPageNext(){
        await commonLocators.goNext();
    }
}
