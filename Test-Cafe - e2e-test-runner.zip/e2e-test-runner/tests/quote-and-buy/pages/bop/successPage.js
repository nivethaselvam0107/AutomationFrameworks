import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const assert = new Assertions();


export default class successPage {
    constructor() {
        this.bopSuccessTitle = Selector('#bopSuccessDetailsPage');
    }

    async checkDefaultFieldsShowOnSuccessPage(){
        await assert.elementPresent(this.bopSuccessTitle, 'Title on Success page is not displayed');
    }

    async verifyPaymentPlan(response,paymentPlan){
        await assert.assertEqual(response.name,paymentPlan.label,'Payment plan do not match');
    }
}