import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import CommonLocators from '../../../utilities/commonLocators';
import Helper from '../../../utilities/helper';
import generalCoveragesPage from './generalCoveragesPage';

const generalCoverages = new generalCoveragesPage();
const commonLocators = new CommonLocators();
const assert = new Assertions();
const helper = new Helper();

export default class additionalCoveragesPage {
    constructor() {
        this.bopAdditionalCoveragesTitle = Selector('#additionalCoveragesPageTitle');
        this.bopAdditionalCoveragesGuestLiabilityCoveragesLiabilityPollutionLimitedLiabilityExtension = Selector('#_BOPPollutionCov').nextSibling();
        this.bopAdditionalCoveragesGuestLiabilityCoveragesLimitedPollutionLiabilityAggLimit = Selector('input[id*="ClauseTerm_[BOPPollutionCov]_[0]"]');
        this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeeBenefitsLiability = Selector('#_BOPEmpBenefits').nextSibling();
        this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeesBenefitsEachEmployeeLimit = Selector('input[id*="ClauseTerm_[BOPEmpBenefits]_[0]"]');
        this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeesBenefitsAggLimit = Selector('input[id*="ClauseTerm_[BOPEmpBenefits]_[1]"]');
        this.bopAdditionalCoveragesGuestLiabilityCoveragesEachEmployeeDeductible = Selector('select[id*="ClauseTerm_[BOPEmpBenefits]_[2]"]');
        this.bopAdditionalCoveragesGuestLiabilityCoveragesRetroactiveDate = Selector('input[id*="ClauseTerm_[BOPEmpBenefits]_[3]"]');
        this.bopAdditionalCoveragesComputerLimitedLiabilityCoverage = Selector('#_BOPY2KLimitedCov').nextSibling();
        this.bopAdditionalCoveragesComputerFundsTransferFraud = Selector('#_BOPComputerFraudCov').nextSibling();
        this.bopAdditionalCoveragesComputerFraudLimit = Selector('select[id*="ClauseTerm_[BOPComputerFraudCov]_[0]"]');
        this.bopAdditionalCoveragesPrintersErrorsAndOmissions = Selector('#_BOPPrinterCov').nextSibling();
        this.bopAdditionalCoveragesPrintersErrorsAndOmissionsGrossSales = Selector('input[id*="ClauseTerm_[BOPPrinterCov]_[0]"]');
    }

    async checkDefaultFieldsShowOnAdditionalCoveragesPage() {
        await assert.elementPresent(this.bopAdditionalCoveragesTitle, 'Additional Coverages Title is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async selectAdditionalComputerCoverages(crimeComputerFunds, professionsPrinterSales) {
        await helper.click(this.bopAdditionalCoveragesComputerLimitedLiabilityCoverage);
        await helper.click(this.bopAdditionalCoveragesComputerFundsTransferFraud);
        await helper.selectDropdown(this.bopAdditionalCoveragesComputerFraudLimit, crimeComputerFunds);
        await helper.click(this.bopAdditionalCoveragesPrintersErrorsAndOmissions);
        await helper.typeText(this.bopAdditionalCoveragesPrintersErrorsAndOmissionsGrossSales, professionsPrinterSales);
    }

    async additionalCoverageNext() {
        await commonLocators.goNext();
    }

    async getComputerFraudLimit() {
        await this.bopAdditionalCoveragesComputerFraudLimit;
        return this.bopAdditionalCoveragesComputerFraudLimit.prevSibling().innerText;
    }

    async getPrintersErrorsAndOmissionsGrossSales() {
        await this.bopAdditionalCoveragesPrintersErrorsAndOmissionsGrossSales;
        return this.bopAdditionalCoveragesPrintersErrorsAndOmissionsGrossSales.value;
    }

    async clickSideBarAdditionalCoveragesPage() {
        await helper.clickButtonWithText('Additional Coverages');
    }

    async verifyAdditionalCoveragesDataIsRetained(fundsTransferFraudLimit, grossSales) {
        await assert.assertAttributeValue(await this.bopAdditionalCoveragesComputerLimitedLiabilityCoverage, 'aria-checked', 'true', 'Computer Limited Liability Coverage is not checked');
        await assert.assertAttributeValue(await this.bopAdditionalCoveragesComputerFundsTransferFraud, 'aria-checked', 'true', 'Computer/Funds Transfer Fraud is not checked');
        await assert.assertEqual(await this.getComputerFraudLimit(), fundsTransferFraudLimit, 'Incorrect value for Computer Fraud Limit');
        await assert.assertAttributeValue(await this.bopAdditionalCoveragesPrintersErrorsAndOmissions, 'aria-checked', 'true', 'Printers Errors and Omissions is not checked');
        await assert.assertEqual(await this.getPrintersErrorsAndOmissionsGrossSales(), grossSales, 'Incorrect value for Printers Errors and Omissions Gross Sales');
    }

    async selectAndVerifyAdditionalCoverageDependencies(logger) {
        await helper.click(this.bopAdditionalCoveragesGuestLiabilityCoveragesLiabilityPollutionLimitedLiabilityExtension);
        await assert.elementPresent(
            this.bopAdditionalCoveragesGuestLiabilityCoveragesLimitedPollutionLiabilityAggLimit,
            'Limited Pollution Liability Agg Limit not displayed'
        );
        await generalCoverages.verifyCoverageDependenciesCall(logger);
        await helper.click(this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeeBenefitsLiability);
        await assert.elementPresent(
            this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeesBenefitsEachEmployeeLimit,
            'Employees Benefits Each Employee Limit not displayed'
        );
        await assert.elementPresent(
            this.bopAdditionalCoveragesGuestLiabilityCoveragesEmployeesBenefitsAggLimit,
            'Employees Benefits Agg Limit not displayed'
        );
        await assert.elementPresent(
            this.bopAdditionalCoveragesGuestLiabilityCoveragesEachEmployeeDeductible,
            'Employees Benefits Each Employee Deductible not displayed'
        );
        await assert.elementPresent(
            this.bopAdditionalCoveragesGuestLiabilityCoveragesRetroactiveDate,
            'Retroactive Date not displayed'
        );
        await generalCoverages.verifyCoverageDependenciesCall(logger);
    }
}
