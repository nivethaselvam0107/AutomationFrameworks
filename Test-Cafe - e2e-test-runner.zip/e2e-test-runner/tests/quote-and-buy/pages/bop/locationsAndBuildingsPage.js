/* eslint-disable class-methods-use-this */
import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class locationsAndBuildingsPage {
    constructor() {
        this.bopLocationsAndBuildingsLocationAccordion = Selector('#locationAccordionCard_\\[0\\]');
        this.bopLocationsAndBuildingsAddBuildingButton = Selector('#addBuildingButton_\\[0\\]');
        this.bopLocationsAndBuildingsPropertyClassCode = Selector('#propertyClassCode');
        this.bopLocationsAndBuildingsPremium = Selector('#premiumBasicAmount');
        this.bopLocationsAndBuildingsYearBuilt = Selector('#yearBuilt');
        this.bopLocationsAndBuildingsConstructionType = Selector('#constructionType');
        this.bopLocationsAndBuildingsNumberOfStories = Selector('#numberOfStories');
        this.bopLocationsAndBuildingsTotalAreaExcludingBasement = Selector('#totalAreaExcludingBasement');
        this.bopLocationsAndBuildingsPercentageSprinklered = Selector('#percentageSprinklered');
        this.bopLocationsAndBuildingsAlarm = Selector('#alarm');
        this.bopLocationsAndBuildingsAlarmType = Selector('#alarmType');
        this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit = Selector('input[id*="ClauseTerm_[BOPPersonalPropCov]_[0]"]');
        this.bopLocationsAndBuildingsBuildingLimit = Selector('input[id*="ClauseTerm_[BOPBuildingCov]_[1]"]');
        this.bopLocationsAndBuildingsAddLocation = Selector('#addLocation');
        this.bopLocationsAndBuildingsaddressLine1 = Selector('#addressLine1');
        this.bopLocationsAndBuildingsaddressLine2 = Selector('#addressLine2');
        this.bopLocationsAndBuildingsaddressLine3 = Selector('#addressLine3');
        this.bopLocationsAndBuildingsCity = Selector('#city');
        this.bopLocationsAndBuildingsState = Selector('#state');
        this.bopLocationsAndBuildingsZipCode = Selector('#zipCode');
        this.bopLocationsAndBuildingsLocationCode = Selector('#locationCode');
        this.bopLocationsAndBuildingsPhoneNumber = Selector('#phoneNumber');
        this.bopLocationsAndBuildingsFireProtection = Selector('#fireProtection');
        this.bopLocationsAndBuildingsDeleteBuilding = Selector('#locationAccordionCard_\\[0\\] button').nth(1);
        this.bopLocationsAndBuildingsLocationAddButton = Selector('#locationAddButton');
        this.bopLocationsAndBuildingsPrimaryLocationAccordionButton = Selector('div[id*="locationAccordionCard_[0]"][role=button]');
        this.bopLocationsAndBuildingsSecondLocationAccordionButton = Selector('#locationAccordionCard_\\[1\\] i[role="button"]');
        this.bopLocationsAndBuildingsSecondLocationDeleteButton = Selector('#locationAccordionCard_\\[1\\] button').nth(0);
        this.bopLocationsAndBuildingsLocationDeleteTitle = Selector('div').withText('Remove Location?');
        this.bopLocationsAndBuildingsBuildingDeleteTitle = Selector('div').withText('Remove Building?');
        this.bopLocationsAndBuildingsLocationDeleteButton = Selector('[class*="fas fa-trash"]');
        this.bopLocationsAndBuildingsLocationBuildingEditButton = Selector('#undefined_editBuilding');
        this.bopLocationsAndBuildingsLocation = Selector('#location');
        this.bopLocationsAndBuildingsPageAddBuilding = Selector('#addBuilding');
        this.bopLocationsAndBuildingsGeneralCoveragesTitle = Selector('#GeneralCoverages');
        this.bopLocationsAndBuildingsCoveragesValuablePapers = Selector('#_BOPValuablePapersCov').parent();
        this.bopLocationsAndBuildingsCoveragesValuablePapersOnPremisesLimit = Selector('input[id*="ClauseTerm_[BOPValuablePapersCov]_[0]"]');
        this.bopLocationsAndBuildingsCoveragesValuablePapersOffPremisesLimit = Selector('input[id*="ClauseTerm_[BOPValuablePapersCov]_[1]"]');
        this.bopLocationsAndBuildingsCoveragesAccountsReceivable = Selector('#_BOPReceivablesCov').parent();
        this.bopLocationsAndBuildingsCoveragesAccountsReceivableOnPremisesLimit = Selector('input[id*="ClauseTerm_[BOPReceivablesCov]_[0]"]');
        this.bopLocationsAndBuildingsCoveragesAccountsReceivableOffPremisesLimit = Selector('input[id*="ClauseTerm_[BOPReceivablesCov]_[1]"]');
        this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTitle = Selector('h2[class*="BuildingScreen_title"]');
        this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiability = Selector('#_BOPTenantsLiabilityCov').parent();
        this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiabilityLimit = Selector('input[id*="ClauseTerm_[BOPTenantsLiabilityCov]_[0]"]');
    }

    async checkDefaultFieldsShowOnLocationsAndBuildingsPage() {
        await assert.elementPresent(this.bopLocationsAndBuildingsLocationAccordion, 'location accordion is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async addBuilding(
        propertyClassCode,
        premium,
        yearBuilt,
        constructionType,
        numberStories,
        totalArea,
        percentSprinkled,
        alarmType,
        businessPersonalPropertyLimit,
        buildingLimit
    ) {
        await this.openAddBuildingScreen();
        await this.addBuildingBasicDetails(propertyClassCode, premium, yearBuilt, constructionType);
        await helper.typeText(this.bopLocationsAndBuildingsNumberOfStories, numberStories);
        await helper.typeText(this.bopLocationsAndBuildingsTotalAreaExcludingBasement, totalArea);
        await helper.selectDropdown(
            this.bopLocationsAndBuildingsPercentageSprinklered, percentSprinkled
        );
        await helper.clickButtonWithText('Yes');
        await helper.click(this.bopLocationsAndBuildingsAlarm.child('button').withText('Yes'));
        await helper.selectDropdown(this.bopLocationsAndBuildingsAlarmType, alarmType);
        await this.addBuildingGeneralCoverageLimits(businessPersonalPropertyLimit, buildingLimit);
        await this.clickAddBuilding();
    }

    async clickAddBuilding() {
        // FIXME https://guidewirejira.atlassian.net/browse/BASDA-1602 sync problem on building page
        await t.click(Selector('#clause_category'));
        await t.wait(6000);
        await helper.click(this.bopLocationsAndBuildingsPageAddBuilding);
    }

    async addBuildingGeneralCoverageLimits(businessPersonalPropertyLimit, buildingLimit) {
        await t.typeText(this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit,
            businessPersonalPropertyLimit);
        await t.typeText(this.bopLocationsAndBuildingsBuildingLimit, buildingLimit);
    }

    async addLocation(
        addressLine1,
        addressLine2,
        addressLine3,
        city,
        zipCode,
        state,
        locationCode,
        phoneNumber,
        fireProtection
    ) {
        await this.addLocationRequiredData(addressLine1, city, zipCode, state);
        await helper.typeText(this.bopLocationsAndBuildingsaddressLine2, addressLine2);
        await helper.typeText(this.bopLocationsAndBuildingsaddressLine3, addressLine3);
        await helper.typeText(this.bopLocationsAndBuildingsLocationCode, locationCode);
        await helper.typeText(this.bopLocationsAndBuildingsPhoneNumber, phoneNumber);
        await helper.selectDropdown(this.bopLocationsAndBuildingsFireProtection, fireProtection);
        await helper.click(this.bopLocationsAndBuildingsLocationAddButton);
    }

    async addLocationRequiredData(addressLine1, city, zipCode, state) {
        await helper.click(this.bopLocationsAndBuildingsAddLocation);
        await helper.typeText(this.bopLocationsAndBuildingsaddressLine1, addressLine1);
        await helper.typeText(this.bopLocationsAndBuildingsCity, city);
        await helper.typeText(this.bopLocationsAndBuildingsZipCode, zipCode);
        await helper.selectDropdown(this.bopLocationsAndBuildingsState, state);
    }

    async LocationsAndBuildingsNext() {
        await commonLocators.goNext();
    }

    async verifySecondLocation(
        response, addressLine1, city, zipCode, state, locationCode, phoneNumber, fireProtection
    ) {
        await assert.assertEqual(response.address.addressLine1, addressLine1, 'addressLine1 do not match');
        await assert.assertEqual(response.address.city, city, 'Cities do not match');
        await assert.assertEqual(response.address.state, state, 'State do not match');
        await assert.assertEqual(response.address.postalCode, zipCode, 'Zip code do not match');
        await assert.assertEqual(response.locationCode, locationCode, 'Location code do not match');
        await assert.assertEqual(response.phone, phoneNumber, 'Phone number do not match');
        await assert.assertEqual(response.fireProtection, fireProtection, 'Fire Protection do not match');
    }

    async deleteSecondLocation() {
        await helper.click(this.bopLocationsAndBuildingsSecondLocationAccordionButton);
        await helper.click(this.bopLocationsAndBuildingsSecondLocationDeleteButton);
        await assert.elementPresent(this.bopLocationsAndBuildingsLocationDeleteTitle);
        await helper.clickButtonWithText('Ok');
    }

    async verifySecondLocationDeleted(response) {
        await assert.assertEqual(response.length, 1, 'There is more than one location');
        await assert.assertEqual(response[0].isPrimary, true, 'the location stored is not the primary location');
    }

    async verifyPrimaryDeleteIconIsNotPresent() {
        await helper.click(this.bopLocationsAndBuildingsPrimaryLocationAccordionButton);
        await helper.click(this.bopLocationsAndBuildingsPrimaryLocationAccordionButton);
        await assert.elementNotPresent(this.bopLocationsAndBuildingsLocationDeleteButton);
    }

    async verifyBuildingAdded(response, classCode, basisAmount) {
        await assert.assertNotEqual(response.length, 0, 'No Building was added');
        await assert.assertEqual(response[0].classCode.code, classCode, 'Class code do not match');
        await assert.assertEqual(response[0].basisAmount.toString(), basisAmount, 'Basis amount do not match');
    }

    async verifyTwoBuildingsAdded(response) {
        await assert.assertEqual(response.length, 2, 'No Building was added');
    }

    async deleteFirstBuilding() {
        await helper.click(this.bopLocationsAndBuildingsDeleteBuilding);
        await assert.elementPresent(this.bopLocationsAndBuildingsBuildingDeleteTitle);
        await helper.clickButtonWithText('Ok');
    }

    async verifyBuildingDeleted(response) {
        await assert.assertEqual(response.length, 1, 'Number of Building did not equal 1');
        await assert.assertEqual(response[0].buildingNumber, 2, 'First building did get removed');
    }

    async clickSideBarLocationsAndBuildingPage() {
        await helper.clickButtonWithText('Locations and Buildings');
    }

    async getLocation() {
        await this.bopLocationsAndBuildingsLocation;
        return this.bopLocationsAndBuildingsLocation.innerText;
    }

    async getPropertyClassCode() {
        await this.bopLocationsAndBuildingsPropertyClassCode;
        return this.bopLocationsAndBuildingsPropertyClassCode.innerText;
    }

    async getPremiumBasisAmount() {
        await this.bopLocationsAndBuildingsPremium;
        return this.bopLocationsAndBuildingsPremium.value;
    }

    async getYearBuilt() {
        await this.bopLocationsAndBuildingsYearBuilt;
        return this.bopLocationsAndBuildingsYearBuilt.value;
    }

    async getConstructionType() {
        await this.bopLocationsAndBuildingsConstructionType;
        return this.bopLocationsAndBuildingsConstructionType.value;
    }

    async getNumberOfStories() {
        await this.bopLocationsAndBuildingsNumberOfStories;
        return this.bopLocationsAndBuildingsNumberOfStories.value;
    }

    async getTotalArea() {
        await this.bopLocationsAndBuildingsTotalAreaExcludingBasement;
        return this.bopLocationsAndBuildingsTotalAreaExcludingBasement.value;
    }

    async getPercentageSprinklered() {
        await this.bopLocationsAndBuildingsPercentageSprinklered;
        return this.bopLocationsAndBuildingsPercentageSprinklered.value;
    }

    async getAlarmType() {
        await this.bopLocationsAndBuildingsAlarmType;
        return this.bopLocationsAndBuildingsAlarmType.value;
    }

    async getBusinessPersonalPropertyLimit() {
        await this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit;
        return this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit.value;
    }

    async getBuildingLimit() {
        await this.bopLocationsAndBuildingsBuildingLimit;
        return this.bopLocationsAndBuildingsBuildingLimit.value;
    }

    async verifyLocationAndBuildingDataIsRetained(
        addressLine1,
        city,
        state,
        propertyClassCode,
        premium,
        yearBuilt,
        constructionType,
        numberStories,
        totalArea,
        percentSprinkled,
        alarmType,
        businessPersonalPropertyLimit,
        buildingLimit
    ) {
        const locationAddress = [addressLine1, city, state].join(', ');
        await helper.click(this.bopLocationsAndBuildingsLocationBuildingEditButton);
        await assert.assertEqual(await this.getLocation(), locationAddress, 'Location Address does not match');
        await assert.assertEqual(await this.getPropertyClassCode(), propertyClassCode, 'Property Class Code does not match');
        await assert.assertEqual(await this.getPremiumBasisAmount(), premium, 'Premium Basis Amount does not match');
        await assert.assertEqual(await this.getYearBuilt(), yearBuilt, 'Year Built does not match');
        await assert.assertEqual(await this.getConstructionType(), constructionType, 'Construction Type does not match');
        await assert.assertEqual(await this.getNumberOfStories(), numberStories, 'Number Of Stories does not match');
        await assert.assertEqual(await this.getTotalArea(), totalArea, 'Total Area does not match');
        await assert.assertEqual(await this.getPercentageSprinklered(), percentSprinkled, 'Percentage Sprinklered does not match');
        await assert.assertEqual(await this.getAlarmType(), alarmType, 'Alarm Type does not match');
        await assert.assertEqual(await this.getBusinessPersonalPropertyLimit(), businessPersonalPropertyLimit, 'Business Personal Property Limit does not match');
        await assert.assertEqual(await this.getBuildingLimit(), buildingLimit, 'Building Limit does not match');
    }

    async addBuildingBasicDetails(propertyClassCode, premium, yearBuilt, constructionType) {
        await helper.typeText(this.bopLocationsAndBuildingsPropertyClassCode, propertyClassCode);
        await t.pressKey('enter');
        await helper.typeText(this.bopLocationsAndBuildingsPremium, premium);
        await helper.typeText(this.bopLocationsAndBuildingsYearBuilt, yearBuilt);
        await helper.selectDropdown(
            this.bopLocationsAndBuildingsConstructionType, constructionType
        );
    }

    async getAlertMessage(selectorWithAlert) {
        await Selector(selectorWithAlert);
        return Selector(selectorWithAlert).sibling().innerText;
    }

    async validateCoverageMinMaxLimit(fieldSelector) {
        await helper.typeText(fieldSelector, '0');
        await helper.click(this.bopLocationsAndBuildingsGeneralCoveragesTitle);
        await assert.assertEqual(
            await this.getAlertMessage(fieldSelector),
            'The value must be between 1 and 3000000',
            'Incorrect alert message displayed for Limit'
        );
        await helper.typeText(fieldSelector, '3000001');
        await helper.click(this.bopLocationsAndBuildingsGeneralCoveragesTitle);
        await assert.assertEqual(
            await this.getAlertMessage(fieldSelector),
            'The value must be between 1 and 3000000',
            'Incorrect alert message displayed for Limit'
        );
    }

    async openAddBuildingScreen() {
        await helper.click(this.bopLocationsAndBuildingsAddBuildingButton);
    }

    async validateOnPremisesLimit(checkBoxSelector, limitFieldSelector) {
        await helper.click(checkBoxSelector);
        await helper.typeText(limitFieldSelector, '9999');
        await helper.click(this.bopLocationsAndBuildingsGeneralCoveragesTitle);
        await assert.assertEqual(
            await this.getAlertMessage(limitFieldSelector),
            'The minimum allowed value is 10000',
            'Incorrect alert message displayed for Limit'
        );
    }

    async validateTenantsLiabilityLimit() {
        await helper.click(this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTitle);
        await helper.click(this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiability);
        await helper.typeText(this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiabilityLimit, '50000');
        await helper.click(this.bopLocationsAndBuildingsGeneralCoveragesTitle);
        await assert.assertEqual(
            await this.getAlertMessage(
                this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiabilityLimit
            ),
            'The minimum allowed value is 50001',
            'Incorrect alert message displayed for Papers On Premises Limit'
        );
        await helper.typeText(this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiabilityLimit, '1000001');
        await helper.click(this.bopLocationsAndBuildingsGeneralCoveragesTitle);
        await assert.assertEqual(
            await this.getAlertMessage(
                this.bopLocationsAndBuildingsGeneralAdditionalCoveragesTenantsLiabilityLimit
            ),
            'The maximum allowed value is 1000000',
            'Incorrect alert message displayed for Papers On Premises Limit'
        );
    }


    async validateAddBuildingCoverageLimits() {
        await this.validateCoverageMinMaxLimit(
            this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit
        );
        // FIXME: https://guidewirejira.atlassian.net/browse/BASDA-1938 uncomment below when defect is fixed
        // await this.validateCoverageMinMaxLimit(
        // this.bopLocationsAndBuildingsBuildingLimit
        // );
        await this.validateOnPremisesLimit(
            this.bopLocationsAndBuildingsCoveragesValuablePapers,
            this.bopLocationsAndBuildingsCoveragesValuablePapersOnPremisesLimit
        );
        await this.validateOnPremisesLimit(
            this.bopLocationsAndBuildingsCoveragesAccountsReceivable,
            this.bopLocationsAndBuildingsCoveragesAccountsReceivableOnPremisesLimit
        );
        await this.validateTenantsLiabilityLimit();
    }

    async buildingPageRemoveTextAndValidateRequiredFields() {
        await helper.removeRequiredTextAndValidate(this.bopLocationsAndBuildingsBuildingLimit);
        await helper.removeRequiredTextAndValidate(
            this.bopLocationsAndBuildingsBusinessPersonalPropertyLimit
        );
        await helper.removeRequiredTextAndValidate(this.bopLocationsAndBuildingsPremium);
    }

    async verifyAddBuildingIsGrayedOut() {
        await assert.assertEqual(this.bopLocationsAndBuildingsPageAddBuilding.hasAttribute('disabled'),
            true, 'Add building button not grayed out');
    }

    async locationPageRemoveTextAndValidateRequiredFields() {
        await helper.removeRequiredTextAndValidate(this.bopLocationsAndBuildingsaddressLine1);
        await helper.removeRequiredTextAndValidate(this.bopLocationsAndBuildingsCity);
        await helper.removeRequiredTextAndValidate(this.bopLocationsAndBuildingsZipCode);
        await helper.clickButtonWithText('Back');
    }
}
