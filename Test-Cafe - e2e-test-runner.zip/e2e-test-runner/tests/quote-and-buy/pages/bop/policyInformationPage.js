import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class policyInformationPage {
    constructor() {
        this.bopPolicyInformationTitle = Selector('#bopPolicyInfoPageTitle');
        this.bopPolicyInformationStartDate = Selector('#startDate');
        this.bopPolicyInformationPrimaryInsured = Selector('#primaryInsured');
        this.bopPolicyInformationAddress = Selector('#address');
        this.bopPolicyInformationSameBillingAddressToggle = Selector('#sameBillingAddress>[data-value]');
        this.bopPolicyInformationBillingAddressFields = Selector('#billingAddressFields');
        this.bopPolicyInformationBillingAddressLine1 = Selector('#addressLine1');
        this.bopPolicyInformationBillingAddressLine2 = Selector('#addressLine2');
        this.bopPolicyInformationBillingAddressLine3 = Selector('#addressLine3');
        this.bopPolicyInformationBillingAddressCity = Selector('#city');
        this.bopPolicyInformationEmail = Selector('#email');
        this.bopPolicyInformationPhone = Selector('#phone');
    }

    async checkDefaultFieldsShowOnPolicyInformationPage() {
        await assert.elementPresent(this.bopPolicyInformationTitle, 'Title is not present');
        await assert.elementPresent(this.bopPolicyInformationStartDate, 'Start Date is not present');
        await assert.elementPresent(this.bopPolicyInformationPrimaryInsured, 'Primary Insured is not present');
        await assert.elementPresent(this.bopPolicyInformationEmail, 'Email is not present');
        await assert.elementPresent(this.bopPolicyInformationPhone, 'Phone is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async policyInformationNext() {
        await commonLocators.goNext();
    }

    async verifyInitialPolicyInfo(startDate, primaryInsured, addressLine1, addressLine2, addressLine3, city, stateCode, ZipCode) {
        const stateAndZipCode = `${stateCode} ${ZipCode}`;
        const policyAddress = [addressLine1, addressLine2, addressLine3, city, stateAndZipCode].join(', ');
        await assert.assertEqual(this.bopPolicyInformationStartDate.innerText, startDate, 'start date do not match');
        await assert.assertEqual(this.bopPolicyInformationPrimaryInsured.innerText, primaryInsured, 'primary insured do not match');
        await assert.assertEqual(this.bopPolicyInformationAddress.innerText, policyAddress, 'address do not match');
    }

    async changePolicyInfo(email, phoneNumber) {
        await helper.typeText(this.bopPolicyInformationEmail, email);
        await helper.removeText(this.bopPolicyInformationPhone);
        await helper.typeText(this.bopPolicyInformationPhone, phoneNumber);
    }

    async verifyChangedPolicyInfo(response, email, phoneNumber) {
        await assert.assertEqual(response.emailAddress1, email, 'email do not match');
        await assert.assertEqual(response.workNumber, phoneNumber, 'phone number do not match');
    }

    async removeTextAndValidateRequiredFields() {
        await helper.selectButtonOption(this.bopPolicyInformationSameBillingAddressToggle, 'false');
        await helper.removeRequiredTextAndValidate(this.bopPolicyInformationBillingAddressLine1);
        await helper.removeRequiredTextAndValidate(this.bopPolicyInformationBillingAddressCity);
        await helper.removeRequiredTextAndValidate(this.bopPolicyInformationEmail);
        await helper.removeRequiredTextAndValidate(this.bopPolicyInformationPhone);
        await this.inputIncorrectEmailFormatAndValidate(this.bopPolicyInformationEmail);
    }

    async inputIncorrectEmailFormatAndValidate(bopYourInfoEmail) {
        await helper.typeText(bopYourInfoEmail, 'abc');
        await helper.pressKey('tab');
        await assert.assertEqual(
            await helper.getAlertMessage(bopYourInfoEmail),
            'Value must be a valid email address',
            'Incorrect alert message displayed for incorrect email format'
        );
    }

    async enterPolicyInformationData(email, phoneNumber) {
        await helper.selectButtonOption(this.bopPolicyInformationSameBillingAddressToggle, 'true');
        await this.changePolicyInfo(email, phoneNumber);
    }
}
