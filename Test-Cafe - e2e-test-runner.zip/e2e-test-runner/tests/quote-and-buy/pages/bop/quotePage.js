import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();

const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class quotePage {
    constructor() {
        this.bopQuoteTitle = Selector('#bopQuotePageTitle');
        this.bopQuoteStartDate = Selector('#startDate');
        this.bopQuoteTotalPremium = Selector('div[class*=digitalContentContainer ]>span>span').nth(0);
        this.bopQuoteTotalTax = Selector('div[class*=digitalContentContainer ]>span>span').nth(1);
        this.bopQuoteTotalCost = Selector('div[class*=digitalContentContainer ]>span>span').nth(2);
        this.bopQuotePolicyPeriodDateRange = Selector('#policyPeriodDateRange');
        this.bopQuoteEditCoveragesLink = Selector('#editCoveragesLink');
    }

    async checkDefaultFieldsShowOnQuotePage() {
        await assert.elementPresent(this.bopQuoteTitle, 'Title is not present');
        await assert.elementPresent(this.bopQuoteStartDate, 'Start Date is not present');
        await assert.elementPresent(this.bopQuoteTotalPremium, 'Total Premium is not present');
        await assert.elementPresent(this.bopQuoteTotalTax, 'Total Tax is not present');
        await assert.elementPresent(this.bopQuoteTotalCost, 'Total Cost is not present');
        await assert.elementPresent(this.bopQuotePolicyPeriodDateRange, 'Policy Period Date Range is not present');
        await assert.elementPresent(this.bopQuoteEditCoveragesLink, 'Edit Coverages link is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async getQuoteTotalPremium() {
        return this.bopQuoteTotalPremium.innerText;
    }

    async getQuoteTotalTax() {
        return this.bopQuoteTotalTax.innerText;
    }

    async getQuoteTotalCost() {
        return this.bopQuoteTotalCost.innerText;
    }

    async getQuoteStartDate() {
        return this.bopQuoteStartDate.innerText;
    }

    async quotePageNext() {
        await commonLocators.goNext();
    }

    async verifyQuoteTotals(response, quoteID, quotePremiumTotal, quoteTaxTotal, quoteCostTotal) {
        quotePremiumTotal = parseFloat(quotePremiumTotal.replace('USD', '').replace(',', ''));
        quoteTaxTotal = parseFloat(quoteTaxTotal.replace('USD', '').replace(',', ''));
        quoteCostTotal = parseFloat(quoteCostTotal.replace('USD', '').replace(',', ''));
        await assert.assertEqual(response.quoteID, quoteID, 'Quote ID does not match');
        await assert.assertEqual(response.quoteData.offeredQuotes[0].premium.totalBeforeTaxes.amount, quotePremiumTotal, 'Premium Total does not match');
        await assert.assertEqual(response.quoteData.offeredQuotes[0].premium.taxes.amount, quoteTaxTotal, 'Tax Total does not match');
        await assert.assertEqual(response.quoteData.offeredQuotes[0].premium.total.amount, quoteCostTotal, 'Cost Total does not match');
    }
}
