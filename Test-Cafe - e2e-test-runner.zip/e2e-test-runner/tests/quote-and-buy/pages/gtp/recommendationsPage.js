import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import gtpSampleData from "../../data/gtp/sampleData.json5";

const assert = new Assertions();
const helper = new Helper();

export default class recommendationsPage {
    constructor() {
        this.recommendationsTitle = Selector('#title');

        this.businessImage = Selector('#productImage_\\[0\\]');
        this.businessTitle = Selector('#productTitle_\\[0\\]');
        this.businessDescription = Selector('#productDescription_\\[0\\]');
        this.businessGetQuoteButton = Selector('#getQuote_\\[0\\]');

        this.commercialAutoImage = Selector('#productImage_\\[1\\]');
        this.commercialAutoTitle = Selector('#productTitle_\\[1\\]');
        this.commercialAutoDescription = Selector('#productDescription_\\[1\\]');
        this.commercialAutoTalkToAgentButton = Selector('#talkToAnAgent_\\[1\\]');

        this.workersCompensationImage = Selector('#productImage_\\[2\\]');
        this.workersCompensationTitle = Selector('#productTitle_\\[2\\]');
        this.workersCompensationDescription = Selector('#productDescription_\\[2\\]');
        this.workersCompensationTalkToAgentButton = Selector('#talkToAnAgent_\\[2\\]');

        this.bopYourInfoAddressLine1 = Selector('#addressLine1');
        this.bopYourInfoCity = Selector('#city');
        this.bopYourInfoZipCode = Selector('#zipCode');
        this.bopYourInfoState = Selector('#state');
    }

    async checkDefaultFieldsShowOnRecommendationsPage() {
        await assert.elementPresent(this.recommendationsTitle, 'Van or Truck Question is not present');

        await assert.elementPresent(this.businessImage, 'Business Owners image is not present');
        await assert.elementPresent(this.businessTitle, 'Business Owners title is not present');
        await assert.elementPresent(this.businessDescription, 'Business Owners description is not present');
        await assert.elementPresent(this.businessGetQuoteButton, 'Business Owners get quote button is not present');

        await assert.elementPresent(this.commercialAutoImage, 'Commercial Auto image is not present');
        await assert.elementPresent(this.commercialAutoTitle, 'Commercial Auto title is not present');
        await assert.elementPresent(this.commercialAutoDescription, 'Commercial Auto description is not present');
        await assert.elementPresent(this.commercialAutoTalkToAgentButton, 'Commercial Auto talk to agent button is not present');

        await assert.elementPresent(this.workersCompensationImage, 'Workers Compensation image is not present');
        await assert.elementPresent(this.workersCompensationTitle, 'Workers Compensation title is not present');
        await assert.elementPresent(this.workersCompensationDescription, 'Workers Compensation description is not present');
        await assert.elementPresent(this.workersCompensationTalkToAgentButton, 'Workers Compensation talk to agent button is not present');
    }

    async checkYourInfoPageFieldsMatchDataEnteredInGTPFlow() {
        await assert.assertEqual(this.bopYourInfoAddressLine1.getAttribute('value'), gtpSampleData.addressLine1);
        await assert.assertEqual(this.bopYourInfoCity.getAttribute('value'), gtpSampleData.city);
        await assert.assertEqual(this.bopYourInfoZipCode.innerText, gtpSampleData.postalCode);
        await assert.assertEqual(this.bopYourInfoState.innerText, gtpSampleData.state);
    }

    async verifyGetQuoteButtonExistsForBOPRecommendation() {
        await assert.assertEqual(this.businessGetQuoteButton.innerText, 'Get Quote');
    }

    async verifyCommercialAutoIsNotRecommmended() {
        const commercialAutoRecommendation = await Selector('div').withText('Commercial Auto');
        await assert.elementNotPresent(commercialAutoRecommendation, 'Commercial Auto Policy is present when it should not be');
    }

    async startABopQuote() {
        await helper.click(this.businessGetQuoteButton);
    }
}
