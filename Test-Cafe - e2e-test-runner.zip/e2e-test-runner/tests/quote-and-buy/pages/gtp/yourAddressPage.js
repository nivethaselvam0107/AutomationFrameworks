import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import gtpSampleData from "../../data/gtp/sampleData.json5";
import Helper from '../../../utilities/helper';

const assert = new Assertions();
const helper = new Helper();

export default class yourAddressPage {
    constructor() {
        this.gtpAddressInput = Selector('#gtpAddressLookup');
        this.gtpSearchRequiredFieldErrorMessage = Selector('#gtpAddressLookup').nextSibling(0);
        this.gtpAddressPageTypeaheadResultList = Selector('#gtpAddressLookup_typeaheadDropdownList');
        this.gtpAddressNotInThisList = Selector('#addressNotInList');
        this.gtpAddressHeader = Selector('#addressHeader');
        this.gtpAddressLine1 = Selector('#addressLine1');
        this.gtpAddressLine2 = Selector('#addressLine2');
        this.gtpAddressLine3 = Selector('#addressLine3');
        this.gtpCity = Selector('#city');
        this.gtpPostalCode = Selector('#zipCode');
        this.gtpState = Selector('#state');
        this.gtpBackToAddressSearch = Selector('#backToAddressSearch');
        this.gtpClearTypeaheadSearchResultButton = Selector('#gtpAddressLookup_clearTypeaheadSearch');
    }

    async checkDefaultFieldsShowOnYourAddressPage() {
        await assert.elementPresent(this.gtpAddressInput, 'Address input is not present');
        await assert.elementPresent(this.gtpAddressNotInThisList, 'Address not in this list link is not present');
    }

    async checkManualAddressFieldsShowOnYourAddressPage() {
        await assert.elementPresent(this.gtpAddressHeader, 'Address header is not present');
        await assert.elementPresent(this.gtpAddressLine1, 'Address Line 1 is not present');
        await assert.elementPresent(this.gtpAddressLine2, 'Address Line 2 is not present');
        await assert.elementPresent(this.gtpAddressLine3, 'Address Line 3 is not present');
        await assert.elementPresent(this.gtpCity, 'City is not present');
        await assert.elementPresent(this.gtpPostalCode, 'Postal Code is not present');
        await assert.elementPresent(this.gtpState, 'State is not present');
        await assert.elementPresent(this.gtpBackToAddressSearch, 'Back to address search link is not present');
    }

    async clearTypeaheadSelection() {
        await helper.click(this.gtpClearTypeaheadSearchResultButton);
    }

    async enterAddressLookupData() {
        await t.typeText(this.gtpAddressInput, gtpSampleData.addressTypeaheadData);
        // FIXME - the below is a workaround to simulate a keydown event as this is what the onchange triggers on
        await helper.pressKey('space');
    }

    async selectAddressFromTypeahead() {
        const optionToSelect = this.gtpAddressPageTypeaheadResultList.find('li').withAttribute('role', 'option').withText(gtpSampleData.typeaheadAddressSearchResult1);
        await t.click(optionToSelect);
    }

    async switchToManualAddressEntryMode() {
        await helper.click(this.gtpAddressNotInThisList)
    }

    async verifyTypeaheadHasExpectedData() {
        const typeaheadValue = this.gtpAddressInput.getAttribute('value');
        await assert.assertEqual(typeaheadValue, gtpSampleData.typeaheadAddressSearchResult1)
    }

    async switchToAddressLookupMode() {
        await helper.click(this.gtpBackToAddressSearch)
    }

    async fillManualAddressData() {
        await helper.typeText(this.gtpAddressLine1, gtpSampleData.yourAddressPageManualEnteredAddressLine1);
        await helper.typeText(this.gtpCity, gtpSampleData.yourAddressPageManualEnteredCity);
        await helper.typeText(this.gtpPostalCode, gtpSampleData.yourAddressPageManualEnteredPostalCode);
        await helper.selectDropdown(this.gtpState, gtpSampleData.yourAddressPageManualEnteredState);
    }

    async verifyManualAddressEnteredExistsInTypeahead() {
        const typeaheadValue = this.gtpAddressInput.getAttribute('value');
        await assert.assertEqual(typeaheadValue, gtpSampleData.yourAddressPageFullAddress);
    }

    async verifyTypeaheadRequiredFieldErrorMessageIsShown() {
        await assert.elementPresent(this.gtpSearchRequiredFieldErrorMessage, 'Required field error message is shown' );
        await assert.assertEqual(this.gtpSearchRequiredFieldErrorMessage.innerText, 'This is a required field');
    }

    async verifyTypeaheadEnteredDataExistsInManualMode() {
        const addressLine1Value = this.gtpAddressLine1.getAttribute('value');
        const cityValue = this.gtpCity.getAttribute('value');
        const postalCodeValue = this.gtpPostalCode.getAttribute('value');
        const stateValue = this.gtpState.innerText;
        await assert.assertEqual(addressLine1Value, gtpSampleData.yourAddressPageTypeaheadEnteredAddressLine1);
        await assert.assertEqual(cityValue, gtpSampleData.yourAddressPageTypeaheadEnteredCity);
        await assert.assertEqual(postalCodeValue, gtpSampleData.yourAddressPageTypeaheadEnteredPostalCode);
        await assert.assertEqual(stateValue, gtpSampleData.yourAddressPageTypeaheadEnteredState);
    }
}
