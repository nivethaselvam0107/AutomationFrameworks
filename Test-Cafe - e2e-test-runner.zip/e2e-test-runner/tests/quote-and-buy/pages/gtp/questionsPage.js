import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const assert = new Assertions();
const helper = new Helper();

export default class questionsPage {
    constructor() {
        this.vanOrTruckQuestion = Selector('#question_01');
        this.vanOrTruckQuestionIcon = Selector('#question_01').find('.fa-truck');
        this.vanOrTruckQuestionTitle = this.vanOrTruckQuestion.find('span').withText('Van or Truck');
        this.vanOrTruckQuestionHelpIcon = this.vanOrTruckQuestion.find('button').child(0);
        this.vanOrTruckQuestionHelpText = this.vanOrTruckQuestion.find('span').withText('Select if your business uses one or more vans or trucks.');
        this.vanOrTruckQuestionValue = Selector('#questionCheckbox_01').nextSibling(0);

        this.businessPropertyQuestion = Selector('#question_02');
        this.businessPropertyQuestionIcon = this.businessPropertyQuestion.find('.fa-building');
        this.businessPropertyQuestionTitle = this.businessPropertyQuestion.find('span').withText('Business Property');
        this.businessPropertyQuestionHelpIcon = this.businessPropertyQuestion.find('button').child(0);
        this.businessPropertyQuestionHelpText = this.businessPropertyQuestion.find('span').withText('Select if you own or rent premises and you want to insure them against damage.');
        this.businessPropertyQuestionValue = Selector('#questionCheckbox_02').nextSibling(0);

        this.stockQuestion = Selector('#question_04');
        this.stockQuestionIcon = this.stockQuestion.find('.fa-barcode');
        this.stockQuestionTitle = this.stockQuestion.find('span').withText('Stock');
        this.stockQuestionHelpIcon = this.stockQuestion.find('button').child(0);
        this.stockQuestionHelpText = this.stockQuestion.find('span').withText('Select if you’ve got goods stored on your premises.');
        this.stockQuestionValue = Selector('#questionCheckbox_04').nextSibling(0);

        this.visitorsOrVisitingQuestion = Selector('#question_08');
        this.visitorsOrVisitingQuestionIcon = this.visitorsOrVisitingQuestion.find('.fa-plane');
        this.visitorsOrVisitingQuestionTitle = this.visitorsOrVisitingQuestion.find('span').withText('Visitors or Visiting');
        this.visitorsOrVisitingQuestionHelpIcon = this.visitorsOrVisitingQuestion.find('button').child(0);
        this.visitorsOrVisitingQuestionHelpText = this.visitorsOrVisitingQuestion.find('span').withText('Select if you visit clients or customers visit your premises.');
        this.visitorsOrVisitingQuestionValue = Selector('#questionCheckbox_08').nextSibling(0);

        this.employeesQuestion = Selector('#question_06');
        this.employeesQuestionIcon = this.employeesQuestion.find('.fa-users');
        this.employeesQuestionTitle = this.employeesQuestion.find('span').withText('Employees');
        this.employeesQuestionHelpIcon = this.employeesQuestion.find('button').child(0);
        this.employeesQuestionHelpText = this.employeesQuestion.find('span').withText('Tell us if you have staff working for you, either full- or part-time.');
        this.employeesQuestionValue = Selector('#questionCheckbox_06').nextSibling(0);

        this.provideAdviceQuestion = Selector('#question_11');
        this.provideAdviceQuestionIcon = this.provideAdviceQuestion.find('.fa-compass');
        this.provideAdviceQuestionTitle = this.provideAdviceQuestion.find('span').withText('Provide Advice');
        this.provideAdviceQuestionHelpIcon = this.provideAdviceQuestion.find('button').child(0);
        this.provideAdviceQuestionHelpText = this.provideAdviceQuestion.find('span').withText('Select this if you provide advice and consultancy to clients, or if people rely on your professional expertise');
        this.provideAdviceQuestionValue = Selector('#questionCheckbox_11').nextSibling(0);

        this.provideAServiceQuestion = Selector('#question_12');
        this.provideAServiceQuestionIcon = this.provideAServiceQuestion.find('.fa-phone');
        this.provideAServiceQuestionTitle = this.provideAServiceQuestion.find('span').withText('Provide a Service');
        this.provideAServiceQuestionHelpIcon = this.provideAServiceQuestion.find('button').child(0);
        this.provideAServiceQuestionHelpText = this.provideAServiceQuestion.find('span').withText('If you provide an expert service to clients or customers, like business consultancy or accountancy, you should choose this');
        this.provideAServiceQuestionValue = Selector('#questionCheckbox_12').nextSibling(0);
    }

    async checkDefaultFieldsShowOnQuestionsPage() {
        await assert.elementPresent(this.vanOrTruckQuestion, 'Van or Truck Question is not present');
        await assert.elementPresent(this.vanOrTruckQuestionIcon, 'Van or Truck Question Icon is not present');
        await assert.elementPresent(this.vanOrTruckQuestionTitle, 'Van or Truck Question Title is not present');
        await assert.elementPresent(this.vanOrTruckQuestionHelpIcon, 'Van or Truck Question Help Icon is not present');

        await assert.elementPresent(this.businessPropertyQuestion, 'Business Property Question is not present');
        await assert.elementPresent(this.businessPropertyQuestionIcon, 'Business Property Question Icon is not present');
        await assert.elementPresent(this.businessPropertyQuestionTitle, 'Business Property Question Title is not present');
        await assert.elementPresent(this.businessPropertyQuestionHelpIcon, 'Business Property Question Help Icon is not present');

        await assert.elementPresent(this.stockQuestion, 'Stock Question is not present');
        await assert.elementPresent(this.stockQuestionIcon, 'Stock Question icon is not present');
        await assert.elementPresent(this.stockQuestionTitle, 'Stock Question Title is not present');
        await assert.elementPresent(this.stockQuestionHelpIcon, 'Stock Question Help Icon is not present');

        await assert.elementPresent(this.visitorsOrVisitingQuestion, 'Visitors or Visiting Question is not present');
        await assert.elementPresent(this.visitorsOrVisitingQuestionIcon, 'Visitors or Visiting Question Icon is not present');
        await assert.elementPresent(this.visitorsOrVisitingQuestionTitle, 'Visitors or Visiting Question Title is not present');
        await assert.elementPresent(this.visitorsOrVisitingQuestionHelpIcon, 'Visitors or Visiting Question Help Icon is not present');

        await assert.elementPresent(this.employeesQuestion, 'Employees Question is not present');
        await assert.elementPresent(this.employeesQuestionIcon, 'Employees Question Icon is not present');
        await assert.elementPresent(this.employeesQuestionTitle, 'Employees Question Title is not present');
        await assert.elementPresent(this.employeesQuestionHelpIcon, 'Employees Question Help Icon is not present');

        await assert.elementPresent(this.provideAdviceQuestion, 'Provide Advice Question is not present');
        await assert.elementPresent(this.provideAdviceQuestionIcon, 'Provide Advice Question Icon is not present');
        await assert.elementPresent(this.provideAdviceQuestionTitle, 'Provide Advice Question Title is not present');
        await assert.elementPresent(this.provideAdviceQuestionHelpIcon, 'Provide Advice Question Help Icon is not present');

        await assert.elementPresent(this.provideAServiceQuestion, 'Provide a Service Question is not present');
        await assert.elementPresent(this.provideAServiceQuestionIcon, 'Provide a Service Question Icon is not present');
        await assert.elementPresent(this.provideAServiceQuestionTitle, 'Provide a Service Question Title is not present');
        await assert.elementPresent(this.provideAServiceQuestionHelpIcon, 'Provide a Service Question Help Icon is not present');
    }

    async selectAllHelpIcons() {
        await helper.click(this.vanOrTruckQuestionHelpIcon);
        await helper.click(this.businessPropertyQuestionHelpIcon);
        await helper.click(this.stockQuestionHelpIcon);
        await helper.click(this.visitorsOrVisitingQuestionHelpIcon);
        await helper.click(this.employeesQuestionHelpIcon);
        await helper.click(this.provideAdviceQuestionHelpIcon);
        await helper.click(this.provideAServiceQuestionHelpIcon);
    }

    async verifyAllHelpTextShows() {
        await assert.elementPresent(this.vanOrTruckQuestionHelpText, 'Van or Truck Question Help Text is not present');
        await assert.elementPresent(this.businessPropertyQuestionHelpText, 'Business Property Question Help Text is not present');
        await assert.elementPresent(this.stockQuestionHelpText, 'Stock Question Help Text is not present');
        await assert.elementPresent(this.visitorsOrVisitingQuestionHelpText, 'Visitors or Visiting Question Help Text is not present');
        await assert.elementPresent(this.employeesQuestionHelpText, 'Employees Question Help Text is not present');
        await assert.elementPresent(this.provideAdviceQuestionHelpText, 'Provide Advice Question Help Text is not present');
        await assert.elementPresent(this.provideAServiceQuestionHelpText, 'Provide a Service Question Help Text is not present');
    }

    async selectAllQuestions() {
        await helper.click(this.vanOrTruckQuestion);
        await helper.click(this.businessPropertyQuestion);
        await helper.click(this.stockQuestion);
        await helper.click(this.visitorsOrVisitingQuestion);
        await helper.click(this.employeesQuestion);
        await helper.click(this.provideAdviceQuestion);
        await helper.click(this.provideAServiceQuestion);
    }

    async selectAllQuestionsExceptForVanOrTruck() {
        await helper.click(this.businessPropertyQuestion);
        await helper.click(this.stockQuestion);
        await helper.click(this.visitorsOrVisitingQuestion);
        await helper.click(this.employeesQuestion);
        await helper.click(this.provideAdviceQuestion);
        await helper.click(this.provideAServiceQuestion);
    }

    async partiallySelectQuestions() {
        await helper.click(this.vanOrTruckQuestion);
        await helper.click(this.businessPropertyQuestion);
        await helper.click(this.provideAServiceQuestion);
    }

    async verifyQuestionsAreChecked() {
        await assert.assertEqual(this.vanOrTruckQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.businessPropertyQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.stockQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.visitorsOrVisitingQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.employeesQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.provideAdviceQuestionValue.getAttribute('aria-checked'), 'true');
        await assert.assertEqual(this.provideAServiceQuestionValue.getAttribute('aria-checked'), 'true');
    }
}
