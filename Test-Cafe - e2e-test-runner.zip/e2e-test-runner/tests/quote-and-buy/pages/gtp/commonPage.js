import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const assert = new Assertions();
const helper = new Helper();

export default class commonPage {
    constructor() {
        this.gtpEditBusinessButton = Selector('button').withAttribute('aria-label', 'Your business:');
        this.gtpEditAddressButton = Selector('button').withAttribute('aria-label', 'Your address:');
        this.gtpEditQuestionsButton = Selector('button').withAttribute('aria-label', 'You\'ve selected the following:');

        this.vanOrtruckQuestionIcon = Selector('div').find('.fa-truck');
        this.businessPropertyQuestionIcon = Selector('div').find('.fa-building');
        this.stockQuestionIcon = Selector('div').find('.fa-barcode');
        this.visitorsOrVisitingQuestionIcon = Selector('div').find('.fa-plane');
        this.employeesQuestionIcon = Selector('div').find('.fa-users');
        this.provideAdviceQuestionIcon = Selector('div').find('.fa-compass');
        this.provideAServiceQuestionIcon = Selector('div').find('.fa-phone');
    }

    async editBusiness() {
        await helper.click(this.gtpEditBusinessButton);
    }

    async editAddress() {
        await helper.click(this.gtpEditAddressButton);
    }

    async editQuestions() {
        await helper.click(this.gtpEditQuestionsButton);
    }

    async verifyCorrectQuestionIconsAreDisplayed() {
        await assert.elementPresent(this.vanOrtruckQuestionIcon, 'Van or Truck Question Icon is not present');
        await assert.elementPresent(this.businessPropertyQuestionIcon, 'Business Property Question Icon is not present');
        await assert.elementPresent(this.provideAServiceQuestionIcon, 'Provide a Service Question Icon is not present');

        await assert.elementNotPresent(this.stockQuestionIcon, 'Stock Question Icon is present when it should not be');
        await assert.elementNotPresent(this.visitorsOrVisitingQuestionIcon, 'Visitors or Visiting Question icon is present when it should not be');
        await assert.elementNotPresent(this.employeesQuestionIcon, 'Employees Question icon is present when it should not be');
        await assert.elementNotPresent(this.provideAdviceQuestionIcon, 'Provide a Service Question icon is present when it should not be');
    }

}
