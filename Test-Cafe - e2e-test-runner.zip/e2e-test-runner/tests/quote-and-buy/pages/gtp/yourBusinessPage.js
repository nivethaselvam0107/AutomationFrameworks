import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import gtpSampleData from '../../data/gtp/sampleData.json5';

const assert = new Assertions();
const helper = new Helper();

export default class yourBusinessPage {
    constructor() {
        this.gtpYourBusiness = Selector('#yourBusiness');
        this.gtpClearBusinessButton = Selector('svg').withAttribute('viewBox', '0 0 20 20');
        this.requiredFieldErrorMessage = Selector('#yourBusiness').nextSibling(0);
    }

    async checkDefaultFieldsShowOnYourBusinessPage() {
        await assert.elementPresent(this.gtpYourBusiness, 'Your business input is not present');
    }

    async selectBusinessOption1FromTypeahead() {
        await helper.selectDropdown(this.gtpYourBusiness, gtpSampleData.yourBusiness1);
    }

    async selectBusinessOption2FromTypeahead() {
        await helper.selectDropdown(this.gtpYourBusiness, gtpSampleData.yourBusiness2);
    }

    async clearBusinessSelection() {
        await helper.click(this.gtpClearBusinessButton);
    }

    async verifyErrorMessageIsShown() {
        await assert.elementPresent(this.requiredFieldErrorMessage, 'Required field error message is shown' );
        await assert.assertEqual(this.requiredFieldErrorMessage.innerText, 'This is a required field');
    }

    async verifyBusinessSelectionIsRetained() {
        await assert.assertEqual(this.gtpYourBusiness.innerText, gtpSampleData.yourBusiness1);
    }
}
