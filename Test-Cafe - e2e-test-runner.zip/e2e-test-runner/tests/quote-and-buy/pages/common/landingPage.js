import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const helper = new Helper();
const assert = new Assertions();

export default class LandingPage {
    constructor() {
        this.landingPageToggle = Selector('#lobTypeToggle');
        this.landingPageToggleBusinessButton = Selector('button').withText('Business');
        this.landingPageTogglePersonalButton = Selector('button').withText('Personal');

        this.paZipCodeInput = Selector('#personalAutoLOB_input');
        this.hoZipCodeInput = Selector('#homeownersLOB_input');
        this.bopZipCodeInput = Selector('#businessOwnersLOB_input');

        this.retrieveQuoteZipCodeInput = Selector('#retrieveQuoteZipCodeInput');
        this.retrieveQuoteSubmissionIDInput = Selector('#retrieveQuoteSubmissionIDInput');

        this.retrieveQuoteContinueButton = Selector('#retrieveQuoteContinueButton');
        this.retrieveQuoteCancelButton = Selector('#retrieveQuoteCancelButton');

        this.paRetrieveQuoteLink = Selector('#personalAutoLOB_retrieve_quote');
        this.hoRetrieveQuoteLink = Selector('#homeownersLOB_retrieve_quote');
        this.bopRetrieveQuoteLink = Selector('#businessOwnersLOB_retrieve_quote');

        this.paStartQuoteButton = Selector('#personalAutoLOB_start_quote');
        this.slqStartQuoteButton = Selector('#quickQuoteLOB_start_quote');
        this.hoStartQuoteButton = Selector('#homeownersLOB_start_quote');
        this.bopStartQuoteButton = Selector('#businessOwnersLOB_start_quote');
        this.gtpStartQuoteButton = Selector('#guidanceToProductLOB_start_quote');

        this.bopZipCodeAlert = Selector('div[id*="businessOwnersLOB_input"]>div');
        this.paZipCodeAlert = Selector('div[id*="personalAutoLOB_input"]>div');
        this.hoZipCodeAlert = Selector('div[id*="homeownersLOB_input"]>div');

        this.personalAutoContainer = Selector('#personalAutoLOB_container');
        this.quickQuoteContainer = Selector('#quickQuoteLOB_container');
        this.homeownersContainer = Selector('#homeownersLOB_container');
        this.businessownersContainer = Selector('#businessOwnersLOB_container');
        this.guidanceToProductContainer = Selector('#guidanceToProductLOB_container');
        this.retrieveQuoteContainer = Selector('#retrieveQuoteContainer');
    }

    async checkDefaultFieldsShowOnLandingPage() {
        await assert.elementPresent(this.landingPageToggle, 'Toggle is not present');

        await assert.elementPresent(this.landingPageToggleBusinessButton, 'Personal selector is not present');
        await assert.elementPresent(this.landingPageTogglePersonalButton, 'Business selector is not present');

        await this.checkPersonalFieldsShow();
    }

    async checkPersonalFieldsShow() {
        await assert.elementPresent(this.personalAutoContainer, 'Personal Auto is not present');
        await assert.elementPresent(this.quickQuoteContainer, 'Quick Quote is not present');
        await assert.elementPresent(this.homeownersContainer, 'Homeowners is not present');

        await assert.elementPresent(this.paZipCodeInput, 'Personal Auto zip code input field is not present');
        await assert.elementPresent(this.hoZipCodeInput, 'Homeowners zip code input field is not present');

        await assert.elementPresent(this.paRetrieveQuoteLink, 'Personal Auto retrieve quote link is not present');
        await assert.elementPresent(this.hoRetrieveQuoteLink, 'Homeowners retrieve quote link is not present');

        await assert.elementPresent(this.paStartQuoteButton, 'Business Owners Start Quote Button is not present');
        await assert.elementPresent(this.slqStartQuoteButton, 'Quick Quotes Start Quote Button is not present');
        await assert.elementPresent(this.hoStartQuoteButton, 'Business Owners Start Quote Button is not present');
    }

    async checkBusinessFieldsShow() {
        await assert.elementPresent(this.businessownersContainer, 'Business Owners is not present');
        await assert.elementPresent(this.guidanceToProductContainer, 'Guidance to Product is not present');

        await assert.elementPresent(this.bopZipCodeInput, 'Business Owners zip code input field is not present');

        await assert.elementPresent(this.bopRetrieveQuoteLink, 'Business Owners retrieve quote link is not present');

        await assert.elementPresent(this.bopStartQuoteButton, 'Business Owners Start Quote Button is not present');
        await assert.elementPresent(this.gtpStartQuoteButton, 'Guidance To Products Start Quote Button is not present');
    }

    async checkRetrieveQuoteFieldsShow() {
        await assert.elementPresent(this.retrieveQuoteContainer, 'Retrieve Quote is not present');

        await assert.elementPresent(this.retrieveQuoteZipCodeInput, 'Retrieve Quote zip code input field is not present');
        await assert.elementPresent(this.retrieveQuoteSubmissionIDInput, 'Retrieve Quote submission id input field is not present');

        await assert.elementPresent(this.retrieveQuoteContinueButton, 'Retrieve Quote Continue Button is not present');
        await assert.elementPresent(this.retrieveQuoteCancelButton, 'Retrieve Quote Cancel Button is not present');
    }

    async checkBopZipCodeAlertMessage(){
        await assert.elementPresent(this.bopZipCodeAlert,"BOP zip code alert message is not present");
        await assert.assertEqual(this.bopZipCodeAlert.innerText,"Please enter a valid ZIP code.","Incorrect Zip code error" );
    }

    async checkBopNoZipCodeAlertMessage(){
        await assert.elementPresent(this.bopZipCodeAlert,"BOP zip code alert message is not present");
        await assert.assertEqual(this.bopZipCodeAlert.innerText,"Please enter a ZIP code.","Incorrect Zip code error" );
    }

    async checkPAZipCodeAlertMessage(){
        await assert.elementPresent(this.paZipCodeAlert,"PA zip code alert message is not present");
        await assert.assertEqual(this.paZipCodeAlert.innerText,"Please enter a valid ZIP code.","Incorrect Zip code error" );
    }

    async checkPANoZipCodeAlertMessage(){
        await assert.elementPresent(this.paZipCodeAlert,"PA zip code alert message is not present");
        await assert.assertEqual(this.paZipCodeAlert.innerText,"Please enter a ZIP code.","Zip code entered when expecting none" );
    }

    async checkHOZipCodeAlertMessage(){
        await assert.elementPresent(this.hoZipCodeAlert,"HO Zip Code alert message is not present");
        await assert.assertEqual(this.hoZipCodeAlert.innerText,"Please enter a valid ZIP code.","Incorrect Zip code error" );
    }

    async checkHONoZipCodeAlertMessage(){
        await assert.elementPresent(this.hoZipCodeAlert,"HO Zip Code alert message is not present");
        await assert.assertEqual(this.hoZipCodeAlert.innerText,"Please enter a ZIP code.","Incorrect Zip code error" );
    }

    async clickPersonalOptionInToggle() {
        await helper.click(this.landingPageTogglePersonalButton, { timeout: 30000 });
    }

    async clickBusinessOptionInToggle() {
        await helper.click(this.landingPageToggleBusinessButton, { timeout: 30000 });
    }

    fillPostalCode(lob, value) {
        switch (lob) {
            case 'BusinessOwners':
                helper.typeText(this.bopZipCodeInput, value);
                break;
            case 'PersonalAuto':
                helper.typeText(this.paZipCodeInput, value);
                break;
            case 'HomeOwners':
                helper.typeText(this.hoZipCodeInput, value);
                break;
            default:
                break;
        }
    }

    async startBOPQuote() {
        await helper.click(this.bopStartQuoteButton);
    }

    async startPAQuote() {
        await helper.click(this.paStartQuoteButton);
    }

    async startHOQuote() {
        await helper.click(this.hoStartQuoteButton);
    }

    async startSLQQuote() {
        await helper.click(this.slqStartQuoteButton);
    }

    async startGTPQuote() {
        await helper.click(this.gtpStartQuoteButton);
    }

    async cancelRetrieveQuote() {
        await helper.click(this.retrieveQuoteCancelButton);
    }

    async clickRetrieveQuoteLink(lob) {
        switch (lob) {
            case 'BusinessOwners':
                helper.click(this.bopRetrieveQuoteLink());
                break;
            case 'PersonalAuto':
                helper.click(this.paRetrieveQuoteLink());
                break;
            case 'HomeOwners':
                helper.click(this.hoRetrieveQuoteLink());
                break;
            default:
                throw new Error('Unknown LOB: ' + lob);
        }
    }

    async startQuote(lob, value = undefined) {
        switch (lob) {
            case 'BusinessOwners':
                await helper.clickButtonWithText('Business');
                await this.fillPostalCode('BusinessOwners', value);
                await this.startBOPQuote();
                break;
            case 'PersonalAuto':
                await helper.clickButtonWithText('Personal');
                await this.fillPostalCode('PersonalAuto', value);
                await this.startPAQuote();
                break;
            case 'HomeOwners':
                await helper.clickButtonWithText('Personal');
                await this.fillPostalCode('HomeOwners', value);
                await this.startHOQuote();
                break;
            case 'QuickQuote':
                await helper.clickButtonWithText('Personal');
                await this.startSLQQuote();
                break;
            case 'GuidanceToProduct':
                await helper.clickButtonWithText('Business');
                await this.startGTPQuote();
                break;
            default:
                throw new Error('Unknown LOB: ' + lob);
        }
    }
}
