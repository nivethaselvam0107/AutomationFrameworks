import { t, Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class paymentDetailsPage {
    constructor() {
        this.commonPaymentDetailsTitle = Selector('#paymentDetailsPage');
        this.commonPaymentDetailsPaymentPlan = Selector('label[for="plan_bc:12"]');
        this.commonPaymentDetailsPaymentMethod = Selector('#paymentOptions');
        this.commonPaymentDetailsCheckingButton = Selector('button[data-value="checking"');
        this.commonPaymentDetailsAccountNumber = Selector('#accountNumber');
        this.commonPaymentDetailsRoutingNumber = Selector('#abaNumber');
        this.commonPaymentDetailsBankName = Selector('#bankName');
        this.commonPaymentDetailsCardIssuer = Selector('#creditCardIssuer');
        this.commonPaymentDetailsCardNumber = Selector('#creditCardNumber');
        this.commonPaymentDetailsExpirationMonth = Selector('#expirationMonth');
        this.commonPaymentDetailsExpirationYear = Selector('#expirationYear');
        this.commonPaymentDetailsAvgMonthlyPremium = Selector('#paymentDetails').withText('Average Monthly Premium');
        this.commonPaymentDetailsTotalPremium = Selector('#paymentDetails').withText('Total Premium');
    }

    async checkDefaultFieldsShowOnPaymentDetailsPage() {
        await assert.elementPresent(this.commonPaymentDetailsTitle, 'Payment Details Title is not present');
        await assert.elementPresent(this.commonPaymentDetailsPaymentMethod, 'Payment options field is not present');
        await assert.elementPresent(this.commonPaymentDetailsAccountNumber, 'Account number field is not present');
        await assert.elementPresent(this.commonPaymentDetailsRoutingNumber, 'Routing (aba) number field is not present');
        await assert.elementPresent(this.commonPaymentDetailsAccountNumber, 'Account name field is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(this.commonPaymentDetailsAvgMonthlyPremium, 'Average monthly premium is not present');
        await assert.elementPresent(this.commonPaymentDetailsTotalPremium, 'Total premium is not present');
    }

    async selectCheckingAccountPaymentPlan(paymentMethod, accountNumber, routingNumber, bankName, paymentPlan) {
        await t.wait(5000);
        await helper.click(Selector(`label[for="${paymentPlan.value}"]`));
        await helper.selectDropdown(this.commonPaymentDetailsPaymentMethod, paymentMethod);
        await helper.click(this.commonPaymentDetailsCheckingButton);
        await helper.typeText(this.commonPaymentDetailsAccountNumber, accountNumber);
        await helper.typeText(this.commonPaymentDetailsRoutingNumber, routingNumber);
        await helper.typeText(this.commonPaymentDetailsBankName, bankName);
    }

    async selectCreditCardPaymentPlan(paymentMethod, cardIssuer, creditCardNumber, expirationMonth, expirationYear, paymentPlan) {
        await helper.click(Selector(`label[for="${paymentPlan.value}"]`));
        await helper.selectDropdown(this.commonPaymentDetailsPaymentMethod, paymentMethod);
        await helper.selectDropdown(this.commonPaymentDetailsCardIssuer, cardIssuer);
        await helper.typeText(this.commonPaymentDetailsCardNumber, creditCardNumber);
        await helper.selectDropdown(this.commonPaymentDetailsExpirationMonth, expirationMonth);
        await helper.selectDropdown(this.commonPaymentDetailsExpirationYear, expirationYear);
    }

    async paymentDetailsPageNext() {
        await commonLocators.goNext();
    }

    async removeTextAndValidateRequiredFields() {
        await helper.removeRequiredTextAndValidate(this.commonPaymentDetailsAccountNumber);
        await helper.removeRequiredTextAndValidate(this.commonPaymentDetailsRoutingNumber);
        await helper.removeRequiredTextAndValidate(this.commonPaymentDetailsBankName);
        await helper.selectDropdown(this.commonPaymentDetailsPaymentMethod, 'Credit Card');
        // FIXME: https://guidewirejira.atlassian.net/browse/BASDA-2002 Credit card number not required
        // await helper.removeRequiredTextAndValidate(this.commonPaymentDetailsCardNumber);
    }

    async verifyNextIsGrayedOut() {
        await helper.verifyNextIsGrayedOut();
    }
}
