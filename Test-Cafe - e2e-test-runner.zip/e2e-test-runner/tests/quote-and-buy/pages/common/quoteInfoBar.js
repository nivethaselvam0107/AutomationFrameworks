import { Selector } from 'testcafe';

export default class QuoteInfoBar {
    constructor() {
        this.quoteIDFromQuoteInfoBar = Selector('#contextSubmissionId');

    }

    async getQuoteID() {
        await this.quoteIDFromQuoteInfoBar.innerText;
        return this.quoteIDFromQuoteInfoBar.innerText;
    }


}
