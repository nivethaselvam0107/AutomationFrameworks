import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const assert = new Assertions();
const helper = new Helper();
const commonLocators = new CommonLocators();

export default class paymentDetailsPage {
    constructor() {
        this.paPaymentDetailsTitle = Selector('#paymentDetailsPage');
        this.paPaymentDetailsPaymentOptions = Selector('#paymentOptions');
        this.paPaymentDetailsAccountNumber = Selector('#accountNumber');
        this.paPaymentDetailsAbaNumber = Selector('#abaNumber');
        this.paPaymentDetailsAccountName = Selector('#bankName');
        this.paPaymentDetailsCardIssuer = Selector('#creditCardIssuer');
        this.paPaymentDetailsCardNumber = Selector('#creditCardNumber');
        this.paPaymentDetailsCardExpirationMonth = Selector('#expirationMonth');
        this.paPaymentDetailsCardExpirationYear = Selector('#expirationYear');
        this.paPaymentDetailsAvgMonthlyPremium = Selector('#paymentDetails').withText('Average Monthly Premium');
        this.paPaymentDetailsTotalPremium = Selector('#paymentDetails').withText('Total Premium');
    }

    async checkDefaultFieldsShowOnPaymentDetailsPage() {
        await assert.elementPresent(this.paPaymentDetailsTitle, 'Payment Details Title is not present');
        await assert.elementPresent(this.paPaymentDetailsPaymentOptions, 'Payment options field is not present');
        await assert.elementPresent(this.paPaymentDetailsAccountNumber, 'Account number field is not present');
        await assert.elementPresent(this.paPaymentDetailsAbaNumber, 'Routing (aba) number field is not present');
        await assert.elementPresent(this.paPaymentDetailsAccountName, 'Account name field is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
        await assert.elementPresent(this.paPaymentDetailsAvgMonthlyPremium, 'Average monthly premium is not present');
        await assert.elementPresent(this.paPaymentDetailsTotalPremium, 'Total premium is not present');
    }

    async pressNextButton(){
        await commonLocators.goNext();
    }

    async fillRequiredFields(paymentOption, accountNumber, abaNumber, accountName){
        await helper.selectDropdown(this.paPaymentDetailsPaymentOptions, paymentOption);
        await helper.typeText(this.paPaymentDetailsAccountNumber,accountNumber);
        await helper.typeText(this.paPaymentDetailsAbaNumber,abaNumber);
        await helper.typeText(this.paPaymentDetailsAccountName,accountName);
    }

    async fillRequiredFieldsCreditCard(cardIssuer, ccNumber, expirationMonth, expirationYear){
        await helper.selectDropdown(this.paPaymentDetailsPaymentOptions, 'Credit Card');
        await assert.elementPresent(this.paPaymentDetailsCardIssuer, 'Card issuer is not present');
        await assert.elementPresent(this.paPaymentDetailsCardNumber, 'Card number is not present');
        await assert.elementPresent(this.paPaymentDetailsCardExpirationMonth, 'Card expiration month is not present');
        await assert.elementPresent(this.paPaymentDetailsCardExpirationYear, 'Card expiration year is not present');
        await helper.selectDropdown(this.paPaymentDetailsCardIssuer, cardIssuer);
        await helper.typeText(this.paPaymentDetailsCardNumber, ccNumber);
        await helper.selectDropdown(this.paPaymentDetailsCardExpirationMonth, expirationMonth);
        await helper.selectDropdown(this.paPaymentDetailsCardExpirationYear, expirationYear);
    }

        
}
