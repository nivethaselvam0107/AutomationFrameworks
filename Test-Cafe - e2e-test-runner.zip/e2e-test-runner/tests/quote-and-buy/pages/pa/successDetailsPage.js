import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const assert = new Assertions();
const helper = new Helper();

export default class SuccessDetailsPage {
    constructor() {
        this.paSuccessDetailsTitle = Selector('#paSuccessDetailsPage');
        this.paSuccessDetailsDriver = Selector('#driverAccordion');
        this.paSuccessDetailsVehicle = Selector('#vehicleAccordion');
        this.paSuccessDetailsCoverage = Selector('#coverageAccordion');
        this.paSuccessDetailsContact = Selector('#contactAccordion');
    }

    async checkDefaultFieldsShowOnSuccessDetailsPage() {
        await assert.elementPresent(this.paSuccessDetailsTitle, 'Title is not present');
        await assert.elementPresent(this.paSuccessDetailsDriver, 'Driver details accordion is not present');
        await assert.elementPresent(this.paSuccessDetailsVehicle, 'Vehicles details accordion is not present');
        await assert.elementPresent(this.paSuccessDetailsCoverage, 'Coverage details accordion is not present');
        await assert.elementPresent(this.paSuccessDetailsContact, 'Contact details accordion is not present');
    }

    async checkOpenAccordion(){
        await helper.click(this.paSuccessDetailsDriver);
        await assert.elementPresent(this.paSuccessDetailsDriver.filter('div[class*="Accordion-module__isOpen"]'), 'the details driver accordion expanded was not found');
        await helper.click(this.paSuccessDetailsVehicle);
        await assert.elementPresent(this.paSuccessDetailsVehicle.filter('div[class*="Accordion-module__isOpen"]'), 'the details vehicle accordion expanded was not found');
        await helper.click(this.paSuccessDetailsCoverage);
        await assert.elementPresent(this.paSuccessDetailsCoverage.filter('div[class*="Accordion-module__isOpen"]'), 'the details coverage accordion expanded was not found');
        await helper.click(this.paSuccessDetailsContact);
        await assert.elementPresent(this.paSuccessDetailsContact.filter('div[class*="Accordion-module__isOpen"]'), 'the details contact accordion expanded was not found');
    }

}
