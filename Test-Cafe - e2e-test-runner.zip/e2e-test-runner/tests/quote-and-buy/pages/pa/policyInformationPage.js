import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const assert = new Assertions();
const helper = new Helper();
const commonLocators = new CommonLocators();

export default class policyInformationPage {
    constructor() {
        this.paPolicyInformationTitle = Selector('#paPolicyInfoPage');
        this.paPolicyInformationPhoneNumber = Selector('#phoneNumber');
        this.paPolicyInformationEmail = Selector('#emailAddress');
    }

    async checkDefaultFieldsShowOnPolicyInformationPage() {
        await assert.elementPresent(this.paPolicyInformationTitle, 'Title is not present');
        await assert.elementPresent(this.paPolicyInformationPhoneNumber, 'Phone number field is not present');
        await assert.elementPresent(this.paPolicyInformationEmail, 'Email field is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
    }

    async pressNextButton(){
        await commonLocators.goNext();
    }

    async pressPreviousButton() {
        await commonLocators.goPrevious();
    }

    async fillRequiredFields(phoneNumber){
        await helper.typeText(this.paPolicyInformationPhoneNumber, phoneNumber)
    }

    async fillAllFields(phoneNumber, emailAddress){
        await helper.typeText(this.paPolicyInformationPhoneNumber, phoneNumber);
        await helper.typeText(this.paPolicyInformationEmail, emailAddress)
    }
}
