import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const assert = new Assertions();
const helper = new Helper();
const commonLocators = new CommonLocators();

export default class driverPage {
    constructor() {
        this.paDriverTitle = Selector('#paDriverTitle_\\[0\\]');
        this.paDriverFirstName = Selector('#driverFirstName');
        this.paDriverLastName = Selector('#driverLastName');
        this.paDriverDateOfBirth = Selector('#driverDateOfBirth');
        this.paDriverGender = Selector('#driverGender');
        this.paDriverLicenseNumber = Selector('#driverLicenseNumber');
        this.paDriverLicenseState = Selector('#driverLicenceState');
        this.paDriverLicenseYear = Selector("#driverYearFirstLicenced");
        this.paVehicleAddDriverButton = Selector('#addDriver');

        this.paDriverExtraDriverFirstName1 = Selector('input[id*="driverFirstName_[1]"]');
        this.paDriverExtraDriverLastName1 = Selector('input[id*="driverLastName_[1]"]');
        this.paDriverExtraDriverDateOfBirth1 = Selector('input[id*="driverDateOfBirth_[1]"]');
        this.paDriverExtraDriverGender1 = Selector('select[id*="driverGender_[1]"]');
        this.paDriverExtraDriverLicenseNumber1 = Selector('input[id*="driverLicenceNumber_[1]"]');
        this.paDriverExtraDriverLicenseState1 = Selector('select[id*="driverLicenceState_[1]"]');
        this.paDriverExtraDriverLicenseYear1 = Selector('select[id*="driverYearFirstLicenced_[1]"]');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnDriverPage() {
        await assert.elementPresent(this.paDriverTitle, 'Title is not present');
        await assert.elementPresent(this.paDriverGender, 'Gender is not present');
        await assert.elementPresent(this.paDriverLicenseState, 'Licence State is not present');
        await assert.elementPresent(this.paDriverLicenseNumber, 'Licence Number is not present');
        await assert.elementPresent(this.paDriverLicenseYear, 'Licence Year is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
    }

    async fillRequiredFields(gender, licenseNumber, licenseState, licenseYear) {
        await helper.selectDropdown(this.paDriverGender, gender);
        await helper.typeText(this.paDriverLicenseNumber, licenseNumber);
        await helper.selectDropdown(this.paDriverLicenseState, licenseState);
        await helper.selectDropdown(this.paDriverLicenseYear, licenseYear);
    }

    async fillAllFields(firstName, lastName, dob, gender, licenseNumber, licenseState, licenseYear) {
        await helper.typeText(this.paDriverFirstName, firstName);
        await helper.typeText(this.paDriverLastName, lastName);
        await helper.selectDropdown(this.paDriverGender, gender);
        await helper.typeText(this.paDriverLicenseNumber, licenseNumber);
        await helper.selectDropdown(this.paDriverLicenseState, licenseState);
        await helper.selectDropdown(this.paDriverLicenseYear, licenseYear);
        await helper.typeText(this.paDriverDateOfBirth, dob);
    }

    async AddExtraDriverAndVerifyNextGreyedOut(firstName, lastName, dob, gender, licenseNumber, licenseState, licenseYear) {
        await helper.typeText(this.paDriverExtraDriverFirstName1, firstName);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.typeText(this.paDriverExtraDriverLastName1, lastName);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.typeText(this.paDriverExtraDriverDateOfBirth1, dob);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.selectDropdown(this.paDriverExtraDriverGender1, gender);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.typeText(this.paDriverExtraDriverLicenseNumber1, licenseNumber);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.selectDropdown(this.paDriverExtraDriverLicenseState1, licenseState);
        await this.isGreyedOut(commonLocators.nextButton);
        await helper.selectDropdown(this.paDriverExtraDriverLicenseYear1, licenseYear);
    }

    async pressNextButton() {
        await commonLocators.goNext();
    }

    async pressAddDriverButton() {
        await helper.click(this.paVehicleAddDriverButton);
    }

    async isGreyedOut(button) {
        await t.expect(button.hasAttribute('disabled')).ok();
    }

    async verifyDriverDetails(response, defaultDriverGender, defaultDriverLicenseNumber, defaultDriverLicenseStateID, defaultDriverYearFirstLicensed) {
        const responseFromAPI = response.lobData.personalAuto.coverables.drivers[0];
        await assert.assertEqual(responseFromAPI.gender, defaultDriverGender,
            'The gender in policy center is not the same as the submissionID');
        await assert.assertEqual(responseFromAPI.licenseNumber, defaultDriverLicenseNumber,
            'The license number in policy center is not the same as the submissionID');
        await assert.assertEqual(responseFromAPI.licenseState, defaultDriverLicenseStateID,
            'The license state in policy center is not the same as the submissionID');
        await assert.assertEqual(responseFromAPI.yearLicensed.toString(),
            defaultDriverYearFirstLicensed, 'The license year in policy center is not the same as the submissionID');
    }

    async checkNextButtonIsGreyedOut() {
        await this.isGreyedOut(commonLocators.nextButton);
    }
}
