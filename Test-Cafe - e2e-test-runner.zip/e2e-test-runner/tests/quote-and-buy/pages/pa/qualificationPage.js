import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';
import paSampleData from '../../data/pa/sampleData.json5';

const assert = new Assertions();
const helper = new Helper();

const commonLocators = new CommonLocators();

export default class qualificationPage {
    constructor() {
        this.paQualificationTitle = Selector('#questionSets_questionSetHeader');
        this.paQualificationCurrentlyInsured = Selector('#PACurrentlyInsured');
        this.paQualificationCurrentSuspense = Selector('#CurrentSuspense>[data-value]');
        this.paQualificationSuspense = Selector('#Suspense>[data-value]');
        this.paQualificationMovingViolation2 = Selector('#MovingViolations2>[data-value]');
        this.paQualificationPriorDeclinedPolicy = Selector('#PriorDeclinedPolicy>[data-value]');
    }

    async checkDefaultFieldsShowOnQualificationPage() {
        await assert.elementPresent(this.paQualificationTitle, 'Title is not present');
        await assert.elementPresent(this.paQualificationCurrentlyInsured, 'Currently Insured is not present');
        await assert.elementPresent(this.paQualificationSuspense, 'Suspense is not present');
        await assert.elementPresent(this.paQualificationCurrentSuspense, 'Current Suspense is not present');
        await assert.elementPresent(this.paQualificationMovingViolation2, 'Moving Violation is not present');
        await assert.elementPresent(this.paQualificationPriorDeclinedPolicy, 'Prior declined policy is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async pressNextButton() {
        await commonLocators.goNext();
    }

    async fillRequiredFields(currentlyInsured) {
        await helper.selectDropdown(this.paQualificationCurrentlyInsured, currentlyInsured);
    }

    async fillAllFields(currentlyInsured, currentSuspense, suspense, movingViolation3Year, declinedPolicy3Year) {
        await helper.selectDropdown(this.paQualificationCurrentlyInsured, currentlyInsured);
        await helper.selectButtonOption(this.paQualificationCurrentSuspense, currentSuspense);
        await helper.selectButtonOption(this.paQualificationSuspense, suspense);
        await helper.selectButtonOption(this.paQualificationMovingViolation2, movingViolation3Year);
        await helper.selectButtonOption(this.paQualificationPriorDeclinedPolicy, declinedPolicy3Year);
    }

    async verifyQualificationInputs(response, currentlyInsured, licenseSuspended, licenseCancelled, convictedForMovingTrafficViolationsInLast3Years, coverageCancelledDeclinedOrNonRenewedInLast3Years) {
        const responseFromAPI = response.lobData.personalAuto.preQualQuestionSets[0].answers;
        await assert.assertEqual(responseFromAPI.PACurrentlyInsured, currentlyInsured,
            'The currently insured status does not match');
        await assert.assertEqual(responseFromAPI.CurrentSuspense,
            licenseSuspended, 'The license suspended status does not match');
        await assert.assertEqual(responseFromAPI.Suspense,
            licenseCancelled, 'The license cancelled status does not match');
        await assert.assertEqual(responseFromAPI.MovingViolations2,
            convictedForMovingTrafficViolationsInLast3Years, 'The traffic violation status does not match');
        await assert.assertEqual(responseFromAPI.PriorDeclinedPolicy,
            coverageCancelledDeclinedOrNonRenewedInLast3Years, 'The coverage declined status does not match');
    }

    async isNoActive(selector, message) {
        await assert.elementPresent(selector.withText('No').filter('button[class*="ToggleField-module__active"]'), message);
    }

    async confirmNoIsSelected() {
        await this.isNoActive(this.paQualificationSuspense, 'The suspended button is not no');
        await this.isNoActive(this.paQualificationCurrentSuspense, 'The currently suspended button is not no');
        await this.isNoActive(this.paQualificationMovingViolation2, 'The moving violation in last three years button is not no');
        await this.isNoActive(this.paQualificationPriorDeclinedPolicy, 'The prior declined policy in last three years button is not no');
    }
}
