import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';

const assert = new Assertions();
const helper = new Helper();

export default class quotePage {
    constructor() {
        this.paQuoteTitle = Selector('h2').withAttribute('id', 'paQuotePage');
        this.paQuoteBasicProgram = Selector('#buyNowButton_\\[0\\]');
        this.paQuotePremiumProgram = Selector('#buyNowButton_\\[1\\]');
        this.paQuoteStandardProgram = Selector('#buyNowButton_\\[2\\]');
        this.paQuoteBasicUninsuredBodilyInjury = Selector('span[aria-label="Uninsured Motorist - Bodily Injury"]');
        this.paQuoteBasicUninsuredPropertyDamage = Selector('span[aria-label="Uninsured Motorist - Property Damage"]');
        this.paQuoteBasicUnderPropertyDamage = Selector('span[aria-label="Underinsured Motorist - Property Damage"]');
        this.paQuoteBasicComprehensive = Selector('span[aria-label="Comprehensive"]');
        this.paQuoteBasicTowing = Selector('span[aria-label="Towing and Labor"]');
        this.paQuoteBasicRental = Selector('span[aria-label="Rental Reimbursement"]');
        this.paQuoteBasicCollision = Selector('span[aria-label="Collision"]');
        this.paQuotePremiumUninsuredPropertyDamage= Selector('span[aria-label="Uninsured Motorist - Property Damage"]').nth(1);
        this.paQuotePremiumUnderPropertyDamage = Selector('span[aria-label="Underinsured Motorist - Property Damage"]').nth(1);
        this.paQuoteStandardUninsuredPropertyDamage= Selector('span[aria-label="Uninsured Motorist - Property Damage"]').nth(2);
        this.paQuoteStandardUnderPropertyDamage = Selector('span[aria-label="Underinsured Motorist - Property Damage"]').nth(2);
        this.paQuoteBasicRecalculate = Selector('#recalculateButton_\\[0\\]');
        this.paQuotePremiumRecalculate = Selector('#recalculateButton_\\[1\\]');
        this.paQuoteStandardRecalculate = Selector('#recalculateButton_\\[2\\]');
    }

    async checkDefaultFieldsShowOnQuotePage() {
        await assert.elementPresent(this.paQuoteTitle, 'Title is not present');
        await assert.elementPresent(this.paQuoteBasicProgram, 'Basic program button is not present');
        await assert.elementPresent(this.paQuotePremiumProgram, 'Premium program button is not present');
        await assert.elementPresent(this.paQuoteStandardProgram, 'Standard program button is not present');
        await assert.elementPresent(this.paQuoteBasicUninsuredBodilyInjury, 'Checkbox for uninsured motorist - bodily injury is not present');
        await assert.elementPresent(this.paQuoteBasicUninsuredPropertyDamage, 'Checkbox for uninsured motorist - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicUnderPropertyDamage, 'Checkbox for under-insured motorist - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicComprehensive, 'Checkbox for basic comprehensive - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicTowing, 'Checkbox for basic towing - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicRental, 'Checkbox for basic rental - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicCollision, 'Checkbox for basic collision - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicUninsuredPropertyDamage, 'Checkbox for uninsured motorist - property damage is not present');
        await assert.elementPresent(this.paQuoteBasicUnderPropertyDamage, 'Checkbox for under-insured motorist - property damage is not present');
        await assert.elementPresent(this.paQuotePremiumUninsuredPropertyDamage, 'Checkbox for premium uninsured motorist - property damage is not present');
        await assert.elementPresent(this.paQuotePremiumUnderPropertyDamage, 'Checkbox for premium under-insured motorist - property damage is not present');
        await assert.elementPresent(this.paQuoteStandardUninsuredPropertyDamage, 'Checkbox for standard uninsured motorist - property damage is not present');
        await assert.elementPresent(this.paQuoteStandardUnderPropertyDamage, 'Checkbox for standard under-insured motorist - property damage is not present');
    }

    async pressBasicButton(){
        await helper.click(this.paQuoteBasicProgram)
    }

    async pressBasicRecalculationButton(){
        checkBasicRecalculationButton();
        await helper.click(this.paQuoteBasicRecalculate);
    }

    async checkBasicRecalculationButton(){
        await assert.elementPresent(this.paQuoteBasicRecalculate, 'Basic recalculation button is not present');
    }

    async pressStandardButton(){
        await helper.click(this.paQuoteStandardProgram)
    }

    async pressStandardRecalculationButton(){
        this.checkStandardRecalculationButton();
        await helper.click(this.paQuoteStandardRecalculate);
    }

    async checkStandardRecalculationButton(){
        await assert.elementPresent(this.paQuoteStandardRecalculate, 'Standard recalculation button is not present');
    }

    async pressPremiumButton(){
        await helper.click(this.paQuotePremiumProgram)
    }

    async pressPremiumRecalculationButton(){
        this.checkPremiumRecalculationButton();
        await helper.click(this.paQuotePremiumRecalculate);
    }

    async checkPremiumRecalculationButton(){
        await assert.elementPresent(this.paQuotePremiumRecalculate, 'Premium recalculation button is not present');
    }

    async checkAllCoveragesUnchecked(){
        await helper.click(this.paQuoteBasicUninsuredBodilyInjury);
        await helper.click(this.paQuoteBasicUninsuredPropertyDamage);
        await helper.click(this.paQuoteBasicUnderPropertyDamage);
        await helper.click(this.paQuotePremiumUninsuredPropertyDamage);
        await helper.click(this.paQuotePremiumUnderPropertyDamage);
        await helper.click(this.paQuoteStandardUninsuredPropertyDamage);
        await helper.click(this.paQuoteStandardUnderPropertyDamage);
        await helper.click(this.paQuoteBasicComprehensive);
        await helper.click(this.paQuoteBasicTowing);
        await helper.click(this.paQuoteBasicRental);
        await helper.click(this.paQuoteBasicCollision);
    }
}
