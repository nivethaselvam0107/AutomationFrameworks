import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';
import paSampleData from "../../data/pa/sampleData.json5";

const assert = new Assertions();
const helper = new Helper();
const commonLocators = new CommonLocators();

export default class vehiclePage {
    constructor() {
        this.paVehicleTitle = Selector('#paVehicleTitle_\\[0\\]');
        this.paVehicleVin = Selector('#vehicleVin');
        this.paVehicleMake = Selector('#vehicleMake');
        this.paVehicleModel = Selector('#vehicleModel');
        this.paVehicleYear = Selector('#vehicleYear');
        this.paVehicleLicensePlate = Selector('#vehicleLicencePlate');
        this.paVehicleState = Selector('#driverLicenceState');
        this.paVehicleCostNew = Selector('#vehicleCostNew');
    }

    async checkDefaultFieldsShowOnVehiclePage() {
        await assert.elementPresent(this.paVehicleTitle, 'Title is not present');
        await assert.elementPresent(this.paVehicleVin, 'Vin is not present');
        await assert.elementPresent(this.paVehicleMake, 'Make is not present');
        await assert.elementPresent(this.paVehicleModel, 'Model is not present');
        await assert.elementPresent(this.paVehicleYear, 'Year is not present');
        await assert.elementPresent(this.paVehicleLicensePlate, 'License plate is not present');
        await assert.elementPresent(this.paVehicleState, 'State is not present');
        await assert.elementPresent(this.paVehicleCostNew, 'Cost new is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
        await assert.elementPresent(commonLocators.previousButton, 'Wizard Previous Button is not present');
    }

    async fillAllFields(vin, licensePlate, state, costNew) {
        await helper.typeText(this.paVehicleVin, vin);
        await helper.typeText(this.paVehicleLicensePlate, licensePlate);
        await helper.selectDropdown(this.paVehicleState, state);
        await helper.typeText(this.paVehicleCostNew, costNew);
    }

    async pressNextButton() {
        await commonLocators.goNext();
    }

    async fillRequiredFields(year, state, costNew) {
        await helper.selectDropdown(this.paVehicleYear, year);
        await helper.selectDropdown(this.paVehicleState, state);
        await helper.typeText(this.paVehicleCostNew, costNew);
    }

    async verifyVehicleData(response, vehicle1Vin, vehicle1Make, vehicle1Model, vehicle1Year, vehicle1LicensePlate, vehicle1StateID, vehicle1CostNew) {
        const responseFromAPI = response.lobData.personalAuto.coverables.vehicles[0];
        await assert.assertEqual(responseFromAPI.vin, vehicle1Vin,
            'The vin in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.make, vehicle1Make,
            'The vehicle make in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.model, vehicle1Model,
            'The model in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.year.toString(), vehicle1Year,
            'The year in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.license, vehicle1LicensePlate,
            'The vin in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.licenseState, vehicle1StateID,
            'The state code in policy center is not the same as in the portal');
        await assert.assertEqual(responseFromAPI.costNew.amount.toString(),
            vehicle1CostNew, 'The cost new of the vehicle in policy center is not the same as in the portal');
    }
}
