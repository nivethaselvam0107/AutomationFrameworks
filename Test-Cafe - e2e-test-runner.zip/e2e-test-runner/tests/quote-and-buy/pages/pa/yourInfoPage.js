import { Selector, t } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';
import commonSampleData from "../../data/common/sampleData.json5";
import paSampleData from "../../data/pa/sampleData.json5";

const assert = new Assertions();
const helper = new Helper();
const commonLocators = new CommonLocators();

export default class yourInfoPage {
    constructor() {
        this.paYourInfoTitle = Selector('#paYourInfoPage');
        this.paYourInfoFirstName = Selector('#firstName');
        this.paYourInfoLastName = Selector('#lastName');
        this.paYourInfoEmailAddress = Selector('#emailAddress');
        this.paYourInfoDateOfBirth = Selector('#dateOfBirth');
        this.paYourInfoAddressLine1 = Selector('#addressLine1');
        this.paYourInfoAddressLine2 = Selector('#addressLine2');
        this.paYourInfoAddressLine3 = Selector('#addressLine3');
        this.paYourInfoCity = Selector('#city');
        this.paYourInfoStartDate = Selector('#periodStartDate');
        this.paYourInfoQuotePageSidebarLink = Selector('li').withText('Quote');
        this.paYourInfoManualAddress = Selector('#linkToManualAddress');
    }

    async checkDefaultFieldsShowOnYourInfoPage() {
        await assert.elementPresent(this.paYourInfoTitle, 'Title is not present');
        await assert.elementPresent(this.paYourInfoFirstName, 'First Name is not present');
        await assert.elementPresent(this.paYourInfoLastName, 'Last Name is not present');
        await assert.elementPresent(this.paYourInfoEmailAddress, 'Email Address is not present');
        await assert.elementPresent(this.paYourInfoDateOfBirth, 'Date of birth is not present');
        await assert.elementPresent(this.paYourInfoManualAddress, 'Button to change to manual address is not present');
        await assert.elementPresent(this.paYourInfoStartDate, 'Start Date is not present');
        await assert.elementPresent(this.paYourInfoQuotePageSidebarLink, 'Side bar quote is not present');
        await assert.elementPresent(commonLocators.cancelButton, 'Wizard Cancel Button is not present');
        await assert.elementPresent(commonLocators.nextButton, 'Wizard Next Button is not present');
    }

    async fillYourInfoData(firstName, lastName, email, dateOfBirth, addressLine1, addressLine2, addressLine3, city, coverageStartDate) {
        await helper.typeText(this.paYourInfoFirstName, firstName);
        await helper.typeText(this.paYourInfoLastName, lastName);
        await helper.typeText(this.paYourInfoEmailAddress, email);
        await helper.click(this.paYourInfoManualAddress);
        await assert.elementPresent(this.paYourInfoAddressLine1, 'Address Line 1 is not present');
        await assert.elementPresent(this.paYourInfoAddressLine2, 'Address Line 2 is not present');
        await assert.elementPresent(this.paYourInfoAddressLine3, 'Address Line 3 is not present');
        await assert.elementPresent(this.paYourInfoCity, 'City is not present');
        await helper.typeText(this.paYourInfoAddressLine1, addressLine1);
        await helper.typeText(this.paYourInfoAddressLine2, addressLine2);
        await helper.typeText(this.paYourInfoAddressLine3, addressLine3);
        await helper.typeText(this.paYourInfoCity, city);
        await helper.typeText(this.paYourInfoStartDate, coverageStartDate);
        await helper.typeText(this.paYourInfoDateOfBirth, dateOfBirth);
    }

    async pressNextButton() {
        await commonLocators.goNext();
    }

    async testQuoteNav() {
        await helper.click(this.paYourInfoQuotePageSidebarLink);
    }

    async verifyYourInformation(response, submissionId, firstName, lastName, email, addressLine1, addressLine2, addressLine3, city, state, dateOfBirth, status) {
        await assert.assertEqual(response.quoteID, submissionId,
            'The quoteID in policy center is not the same as the submissionID');
        await assert.assertEqual(response.baseData.accountHolder.firstName,
            firstName, 'The first name in pc and the portal differ');
        await assert.assertEqual(response.baseData.accountHolder.lastName,
            lastName, 'The last name in pc and the portal differ');
        await assert.assertEqual(response.baseData.accountHolder.emailAddress1,
            email, 'The email address in pc and the portal differ');
        await assert.assertEqual(response.baseData.policyAddress.addressLine1,
            addressLine1, 'The first address line in pc and the portal differ');
        await assert.assertEqual(response.baseData.policyAddress.addressLine2,
            addressLine2, 'The second address line in pc and the portal differ');
        await assert.assertEqual(response.baseData.policyAddress.addressLine3,
            addressLine3, 'The third address line in pc and the portal differ');
        await assert.assertEqual(response.baseData.policyAddress.city,
            city, 'The city in pc and the portal differ');
        await assert.assertEqual(response.baseData.policyAddress.state,
            state, 'The state in pc and the portal differ');
        const date = new Date(dateOfBirth);
        await assert.assertEqual(response.baseData.accountHolder.dateOfBirth.day, date.getDate(),
            'The day of the date of birth does not match');
        await assert.assertEqual(response.baseData.accountHolder.dateOfBirth.month, date.getMonth(),
            'The month of the date of birth does not match');
        await assert.assertEqual(response.baseData.accountHolder.dateOfBirth.year, date.getFullYear(),
            'The year of the date of birth does not match');
        await assert.assertEqual(response.baseData.periodStatus,
            status, 'The status of the submission in policy center is not Draft');
    }
}
