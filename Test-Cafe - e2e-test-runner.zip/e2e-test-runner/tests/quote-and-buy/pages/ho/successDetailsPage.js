import {t, Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import commonSampleData from '../../data/common/sampleData.json5';

const assert = new Assertions();
const helper = new Helper();

export default class successDetailsPage {
    constructor() {
        this.hoSuccessPaymentSuccessfulTitle = Selector('#hoSuccessDetailsPage');
        this.hoSuccessConfirmationText = Selector('#confirmationText');
        this.hoSuccessPaymentPolicySummaryTitle = Selector('#policySummary');
        this.hoSuccessAccountNumber = Selector('#accountNumberInput');
        this.hoSuccessPolicyNumber = Selector('#policyNumberInput');
        this.hoSuccessEffectiveDate = Selector('#effectiveDate');
        this.hoSuccessStartDateInRange = Selector('#effectiveDate_startDateInRange');
        this.hoSuccessEndDateInRange = Selector('#effectiveDate_endDateInRange');
        this.hoSuccessPolicyTotalAmount = Selector('span[class*="CurrencyField-module"]>span').nth(0);
        this.hoSuccessPaymentPlanName = Selector('#paymentPlanName');
        this.hoSuccessCurrentPayment = Selector('span[class*="CurrencyField-module"]>span').nth(1);
        this.hoSuccessInformationAccordion = Selector('#yourInfoAccordion');
        this.hoSuccessInformationFirstName = Selector('#firstName');
        this.hoSuccessInformationLastName = Selector('#lastName');
        this.hoSuccessInformationEmail = Selector('#emailAddress');
        this.hoSuccessYourHouseAccordion = Selector('#yourHouseAccordion');
        this.hoSuccessYourHouseAddressLine1 = Selector('#addressLine1');
        this.hoSuccessYourHouseAddressLine2 = Selector('#addressLine2');
        this.hoSuccessYourHouseAddressLine3 = Selector('#addressLine3');
        this.hoSuccessYourHouseAddressCity = Selector('#city');
        this.hoSuccessYourHouseAddressState = Selector('#state');
        this.hoSuccessYourHouseAddressZipCode = Selector('#postalCode');
        this.hoSuccessYourCoveragesAccordion = Selector('#yourCoveragesAccordion');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async getAccountNumber() {
        await t.wait(5000);
        await this.hoSuccessAccountNumber;
        return this.hoSuccessAccountNumber.innerText;
    }

    async getPolicyNumber() {
        await this.hoSuccessPolicyNumber;
        return this.hoSuccessPolicyNumber.innerText;
    }

    async getPolicyEffectiveDate() {
        await this.hoSuccessEffectiveDate;
        return this.hoSuccessEffectiveDate.innerText;
    }

    async getPolicyPeriodStartDate() {
        await this.hoSuccessStartDateInRange;
        return this.hoSuccessStartDateInRange.innerText;
    }

    async getPolicyPeriodEndDate() {
        await this.hoSuccessEndDateInRange;
        return this.hoSuccessEndDateInRange.innerText;
    }

    async getPolicyTotalAmount() {
        await this.hoSuccessPolicyTotalAmount;
        return this.hoSuccessPolicyTotalAmount.innerText;
    }

    async getPolicyPaymentPlanName() {
        await this.hoSuccessPaymentPlanName;
        return this.hoSuccessPaymentPlanName.innerText;
    }

    async getPolicyCurrentPayment() {
        await this.hoSuccessCurrentPayment;
        return this.hoSuccessCurrentPayment.innerText;
    }

    async verifyPolicySummary(response, policyNumber, accountNumber, periodStartDate, periodEndDate, policyEffectiveDate, policyPeriodStartDate, policyPeriodEndDate, policyTotalAmount, paymentPlanName, currentPayment) {
        const quoteDataFromBackend = response.bindData;
        policyTotalAmount = parseFloat(policyTotalAmount.replace('USD', '').replace(',', ''));
        currentPayment = parseFloat(currentPayment.replace('USD', '').replace(',', ''));
        await assert.assertEqual(quoteDataFromBackend.accountNumber, accountNumber, 'Account Number does not match');
        await assert.assertEqual(quoteDataFromBackend.policyNumber, policyNumber, 'Quote ID does not match');
        await assert.assertEqual(new Date(policyEffectiveDate), new Date(periodStartDate), 'Policy Effective date does not match');
        await assert.assertEqual(new Date(policyPeriodStartDate), new Date(periodStartDate), 'Policy Period Start date does not match');
        await assert.assertEqual(new Date(policyPeriodEndDate), new Date(periodEndDate), 'Policy Period End date does not match');
        await assert.assertEqual(quoteDataFromBackend.paymentPlans[0].total.amount, policyTotalAmount, 'Full Premium does not match');
        await assert.assertEqual(paymentPlanName, commonSampleData.paymentPlan.label, 'Payment Plan does not match');
        await assert.assertEqual(quoteDataFromBackend.paymentPlans[0].downPayment.amount, currentPayment, 'Monthly Premium does not match');
    }

    async openInformationAccordion() {
        helper.click(this.hoSuccessInformationAccordion);
    }

    async getFirstName() {
        await this.hoSuccessInformationFirstName;
        return this.hoSuccessInformationFirstName.innerText;
    }

    async getLastName() {
        await this.hoSuccessInformationLastName;
        return this.hoSuccessInformationLastName.innerText;
    }

    async getEmail() {
        await this.hoSuccessInformationEmail;
        return this.hoSuccessInformationEmail.innerText;
    }

    async verifyInformation(firstName, lastName, email) {
        await assert.assertEqual(firstName, commonSampleData.firstName, 'First Name on Information section does not match');
        await assert.assertEqual(lastName, commonSampleData.lastName, 'Last Name on Information section does not match');
        await assert.assertEqual(email, commonSampleData.email, 'Email on Information section does not match');
    }

    async openHouseAccordion() {
        helper.click(this.hoSuccessYourHouseAccordion);
    }

    async getHouseAddressLine1() {
        await this.hoSuccessYourHouseAddressLine1;
        return this.hoSuccessYourHouseAddressLine1.innerText;
    }

    async getHouseAddressLine2() {
        await this.hoSuccessYourHouseAddressLine2;
        return this.hoSuccessYourHouseAddressLine2.innerText;
    }

    async getHouseAddressLine3() {
        await this.hoSuccessYourHouseAddressLine3;
        return this.hoSuccessYourHouseAddressLine3.innerText;
    }

    async getHouseAddressCity() {
        await this.hoSuccessYourHouseAddressCity;
        return this.hoSuccessYourHouseAddressCity.innerText;
    }

    async getHouseAddressState() {
        await this.hoSuccessYourHouseAddressState;
        return this.hoSuccessYourHouseAddressState.innerText;
    }

    async getHouseAddressZip() {
        await this.hoSuccessYourHouseAddressZipCode;
        return this.hoSuccessYourHouseAddressZipCode.innerText;
    }

    async verifyHouseData(houseAddressLine1, houseAddressLine2, houseAddressLine3, houseAddressCity, houseAddressState, houseAddressPostalCode) {
        await assert.assertEqual(houseAddressLine1, commonSampleData.addressLine1, 'Address Line 1 on House section does not match');
        await assert.assertEqual(houseAddressLine2, commonSampleData.addressLine2, 'Address Line 2 on House section does not match');
        await assert.assertEqual(houseAddressLine3, commonSampleData.addressLine3, 'Address Line 3 on House section does not match');
        await assert.assertEqual(houseAddressCity, commonSampleData.city, 'Address City on House section does not match');
        await assert.assertEqual(houseAddressState, commonSampleData.state.label, 'Address State on House section does not match');
        await assert.assertEqual(houseAddressPostalCode, commonSampleData.postalCode, 'Address Postal Code on House section does not match');
    }
}
