import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class yourHomePage {
    constructor() {
        this.hoYourHomeTitle = Selector('#yourHomePage');
        this.hoYourHomeEstimatedValue = Selector('#estimatedValueOfHome');
        this.hoYourHomeLocationType = Selector('#locationType');
        this.hoYourHomeResidenceType = Selector('#residenceType');
        this.hoYourHomeDistanceToFireHydrant = Selector('#distanceToFireHydrant>[data-value]');
        this.hoYourHomeDistanceToFireHydrant250 = Selector('#distanceToFireHydrant>[data-value="250"]');
        this.hoYourHomeDistanceToFireHydrant750 = Selector('#distanceToFireHydrant>[data-value="750"]');
        this.hoYourHomeDistanceToFireStation = Selector('#distanceToFireStation>[data-value]');
        this.hoYourHomeDistanceToFireStationIn5Miles = Selector('#distanceToFireStation>[data-value="3"]');
        this.hoYourHomeDistanceToFireStationOver5Miles = Selector('#distanceToFireStation>[data-value="5"]');
        this.hoYourHomeWith300ftOfCommercialProperty = Selector('#commercialProperty>[data-value]');
        this.hoYourHomeWith300ftOfCommercialPropertyYes = Selector('#commercialProperty>[data-value=true]');
        this.hoYourHomeWith300ftOfCommercialPropertyNo = Selector('#commercialProperty>[data-value=false]');
        this.hoYourHomeFloodOrFireHazard = Selector('#floodingOfFireHazaed>[data-value]');
        this.hoYourHomeFloodOrFireHazardYes = Selector('#floodingOfFireHazaed>[data-value=true]');
        this.hoYourHomeFloodOrFireHazardNo = Selector('#floodingOfFireHazaed>[data-value=false]');
        this.hoYourHomeType = Selector('#homeType');
        this.hoYourHomeOccupiesHome = Selector('#occupiesHome');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async setYourHomeValues(estimatedValueOfHome, locationType, residenceType, distanceToFireHydrant, distanceToFireStation, within300ftOfCommercialProperty, floodingOrFireHazard, homeType, specifyWhoOccupies) {
        await helper.typeText(this.hoYourHomeEstimatedValue, estimatedValueOfHome);
        await helper.selectDropdown(this.hoYourHomeLocationType, locationType);
        await helper.selectDropdown(this.hoYourHomeResidenceType, residenceType);
        await helper.selectButtonOption(this.hoYourHomeDistanceToFireHydrant, distanceToFireHydrant);
        await helper.selectButtonOption(this.hoYourHomeDistanceToFireStation, distanceToFireStation);
        await helper.selectButtonOption(this.hoYourHomeWith300ftOfCommercialProperty, within300ftOfCommercialProperty);
        await helper.selectButtonOption(this.hoYourHomeFloodOrFireHazard, floodingOrFireHazard);
        await helper.selectDropdown(this.hoYourHomeType, homeType);
        await helper.selectDropdown(this.hoYourHomeOccupiesHome, specifyWhoOccupies);
    }

    async yourHomeNext() {
        await commonLocators.goNext();
    }

    async verifyYourHomeInfo(response, submissionId, estimatedValueOfHome, locationType, residenceType, distanceToFireHydrant, distanceToFireStation, within300ftOfCommercialProperty, floodingOrFireHazard, homeType, specifyWhoOccupies) {
        const responseFromBackend = response.lobData.homeowners.coverables.yourHome;
        await assert.assertEqual(response.quoteID, submissionId, 'Quote ID does not match');
        await assert.assertEqual(responseFromBackend.replacementCost, Number(estimatedValueOfHome), 'Estimated Value does not match');
        await assert.assertEqual(responseFromBackend.dwellingLocation, locationType, 'Location Type does not match');
        await assert.assertEqual(responseFromBackend.residenceType, residenceType, 'Residence Type does not match');
        await assert.assertEqual(responseFromBackend.distanceToFireHydrant, Number(distanceToFireHydrant), 'Distance to Fire Hydrant does not match');
        await assert.assertEqual(responseFromBackend.distanceToFireStation, Number(distanceToFireStation), 'Distance to Fire Station does not match');
        await assert.assertEqual(responseFromBackend.nearCommercial.toString(), within300ftOfCommercialProperty, 'Response to Within 300ft of commercial property does not match');
        await assert.assertEqual(responseFromBackend.floodingOrFireHazard.toString(), floodingOrFireHazard, 'Response to Flooding or Fire Hazard does not match');
        await assert.assertEqual(responseFromBackend.dwellingUsage, homeType.toLowerCase(), 'Home Type does not match');
        await assert.assertEqual(responseFromBackend.occupancy, specifyWhoOccupies, 'Who occupies the home does not match');
    }

    async clickSideBarYourHome() {
        await helper.clickButtonWithText('Home');
    }

    async getEstimatedValueOfHome() {
        await this.hoYourHomeEstimatedValue;
        return this.hoYourHomeEstimatedValue.value;
    }

    async getLocationType() {
        await this.hoYourHomeLocationType;
        return this.hoYourHomeLocationType.innerText;
    }

    async getResidenceType() {
        await this.hoYourHomeResidenceType;
        return this.hoYourHomeResidenceType.innerText;
    }

    async getHomeType() {
        await this.hoYourHomeType;
        return this.hoYourHomeType.innerText;
    }

    async getWhoOccupiesHome() {
        await this.hoYourHomeOccupiesHome;
        return this.hoYourHomeOccupiesHome.innerText;
    }

    async verifyYourHomeDataIsRetained(
        estimatedValueOfHome,
        locationType,
        residenceType,
        distanceToFireHydrant,
        distanceToFireStation,
        within300ftOfCommercialProperty,
        floodingOrFireHazard,
        homeType,
        specifyWhoOccupies
    ) {
        await assert.assertEqual(await this.getEstimatedValueOfHome(),
            estimatedValueOfHome, 'Estimated Value of Your Home does not match');
        await assert.assertEqual(await this.getLocationType(), locationType, 'Location Type does not match');
        await assert.assertEqual(await this.getResidenceType(), residenceType, 'Residence Type does not match');
        await assert.assertAttributeValue(
            '#distanceToFireHydrant > [class*="ToggleField-module__active"]',
            'data-value',
            distanceToFireHydrant,
            'Incorrect value selected for Distance to Fire Hydrant'
        );
        await assert.assertAttributeValue(
            '#distanceToFireStation > [class*="ToggleField-module__active"]',
            'data-value',
            distanceToFireStation,
            'Incorrect value selected for Distance To Fire Station'
        );
        await assert.assertAttributeValue(
            '#commercialProperty > [class*="ToggleField-module__active"]',
            'data-value',
            within300ftOfCommercialProperty,
            'Incorrect value selected for Within 300ft of commercial property'
        );
        await assert.assertAttributeValue(
            '#floodingOfFireHazaed > [class*="ToggleField-module__active"]',
            'data-value',
            floodingOrFireHazard,
            'Incorrect value selected for Flooding or Fire Hazard'
        );
        await assert.assertEqual(await this.getHomeType(), homeType, 'Home Type does not match');
        await assert.assertEqual(await this.getWhoOccupiesHome(), specifyWhoOccupies, 'Specify who occupies the home does not match');
    }
}
