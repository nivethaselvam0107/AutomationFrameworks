export default class paymentDetailsPage {
    constructor() {
        console.log('Constructor for the payment details page');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }
}
