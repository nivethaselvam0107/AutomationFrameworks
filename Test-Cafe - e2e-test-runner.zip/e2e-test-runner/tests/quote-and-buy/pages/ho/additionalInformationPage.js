import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class additionalInformationPage {
    constructor() {
        this.hoAdditionalInformationTitle = Selector('#accountHolderContactInfoHeader');
        this.hoAdditionalInformationEmail = Selector('#contactEmail');
        this.hoAdditionalInformationPhone = Selector('#phoneNumber');
        this.hoAdditionalInformationAdditionalTitle = Selector('#additionalOptionalHeader');
        this.hoAdditionalInformationRoomersOrBorders = Selector('#roomersOrBorders>[data-value]');
        this.hoAdditionalInformationFireplaceOrWoodStove = Selector('#fireplaceOrWoodStove>[data-value]');
        this.hoAdditionalInformationSwimmingPool = Selector('#swimmingPool>[data-value]');
        this.hoAdditionalInformationTrampoline = Selector('#trampoline>[data-value]');
        this.hoAdditionalInformationWaterLeakage = Selector('#waterLeakage>[data-value]');
    }

    async getEmailValue() {
        await this.hoAdditionalInformationEmail;
        return this.hoAdditionalInformationEmail.value;
    }

    async setAccountHolderValues(email, phoneNumber) {
        await assert.assertEqual(await this.getEmailValue(), email, 'Expected email to be pre populated');
        await helper.typeText(this.hoAdditionalInformationPhone, phoneNumber);
    }

    async additionalInformationNext() {
        await commonLocators.goNext();
    }
}
