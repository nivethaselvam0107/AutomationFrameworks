import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class discountPage {
    constructor() {
        this.hoDiscountTitle = Selector('#hoDiscountTitle');
        this.hoDiscountFireExtinguishers = Selector('#fireExtinguishers');
        this.hoDiscountBurglarAlarm = Selector('#burglarAlarm>[data-value]');
        this.hoDiscountBurglarAlarmYes = Selector('#burglarAlarm>[data-value=true]');
        this.hoDiscountBurglarAlarmNo = Selector('#burglarAlarm>[data-value=false]');
        this.hoDiscountBurglarAlarmNone = Selector('#burglarAlarmType_none');
        this.hoDiscountBurglarAlarmLocal = Selector('#burglarAlarmType_local');
        this.hoDiscountBurglarAlarmCentralStation = Selector('label[for="burglarAlarmType_central"]');
        this.hoDiscountBurglarAlarmPoliceStation = Selector('#burglarAlarmType_police');
        this.hoDiscountFireAlarmReportingToMonitoringCenter = Selector('#fireAlarmReportingToMonitoringCenter>[data-value]');
        this.hoDiscountFireAlarmReportingToMonitoringCenterYes = Selector('#fireAlarmReportingToMonitoringCenter>[data-value=true]');
        this.hoDiscountFireAlarmReportingToMonitoringCenterNo = Selector('#fireAlarmReportingToMonitoringCenter>[data-value=false]');
        this.hoDiscountSmokeAlarm = Selector('#smokeAlarm>[data-value]');
        this.hoDiscountSmokeAlarmYes = Selector('#smokeAlarm>[data-value=true]');
        this.hoDiscountSmokeAlarmNo = Selector('#smokeAlarm>[data-value=false]');
        this.hoDiscountSmokeAlarmOnAllFloors = Selector('#smokeAlarmOnAllFloors>[data-value]');
        this.hoDiscountSmokeAlarmOnAllFloorsYes = Selector('#smokeAlarmOnAllFloors>[data-value=true]');
        this.hoDiscountSmokeAlarmOnAllFloorsNo = Selector('#smokeAlarmOnAllFloors>[data-value=false]');
        this.hoDiscountDeadbolts = Selector('#deadbolts>[data-value]');
        this.hoDiscountDeadboltsYes = Selector('#deadbolts>[data-value=true]');
        this.hoDiscountDeadboltsNo = Selector('#deadbolts>[data-value=false]');
        this.hoDiscountNumberOfDeadbolts = Selector('#numberOfDeadbolts');
        this.hoDiscountResidenceVisibleToNeighbors = Selector('#residenceVisibleToNeighbors>[data-value]');
        this.hoDiscountResidenceVisibleToNeighborsYes = Selector('#residenceVisibleToNeighbors>[data-value=true]');
        this.hoDiscountResidenceVisibleToNeighborsNo = Selector('#residenceVisibleToNeighbors>[data-value=false]');
        this.hoDiscountSprinklerSystemType = Selector('#sprinklerSystemType');
        this.hoDiscountRoomerBoardersYes = Selector('#roomersOrBorders>[data-value=true]');
        this.hoDiscountRoomerBoardersNo = Selector('#roomersOrBorders>[data-value=false]');
        this.hoDiscountFireplaceorWoodStoveYes = Selector('#fireplaceOrWoodStove>[data-value=true]');
        this.hoDiscountFireplaceorWoodStoveNo = Selector('#fireplaceOrWoodStove>[data-value=false]');
        this.hoDiscountSwimmingPoolYes = Selector('#swimmingPool>[data-value=true]');
        this.hoDiscountSwimmingPoolNo = Selector('#swimmingPool>[data-value=false]');
        this.hoDiscountWaterLeakageYes = Selector('#knownWaterLeakageInfo>[data-value=true]');
        this.hoDiscountWaterLeakageNo = Selector('#knownWaterLeakageInfo>[data-value=false]');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    // FIXME: This is Granite specific, refactor for other platforms
    async setDiscountValues(fireExtinguishers, burglarAlarm, fireAlarmMonitored, smokeAlarms, alarmsOnAllFloor, deadBolts, numberOfDeadbolts, residenceVisible, sprinklerSystemType) {
        await helper.typeText(this.hoDiscountFireExtinguishers, fireExtinguishers);
        await helper.selectButtonOption(this.hoDiscountBurglarAlarm, burglarAlarm);
        await helper.click(this.hoDiscountBurglarAlarmCentralStation);
        await helper.selectButtonOption(this.hoDiscountFireAlarmReportingToMonitoringCenter, fireAlarmMonitored);
        await helper.selectButtonOption(this.hoDiscountSmokeAlarm, smokeAlarms);
        await helper.selectButtonOption(this.hoDiscountSmokeAlarmOnAllFloors, alarmsOnAllFloor);
        await helper.selectButtonOption(this.hoDiscountDeadbolts, deadBolts);
        // await helper.typeText(this.hoDiscountNumberOfDeadbolts, numberOfDeadbolts);
        await helper.selectButtonOption(this.hoDiscountResidenceVisibleToNeighbors, residenceVisible);
        await helper.selectDropdown(this.hoDiscountSprinklerSystemType, sprinklerSystemType);
    }
    async discountNext() {
        await commonLocators.goNext();
    }

    // FIXME: This is Granite specific, refactor for other platforms
    async verifyDiscountInfo(response, submissionId, fireExtinguishers, burglarAlarm, burglarAlarmType, fireAlarmMonitored, smokeAlarms, alarmsOnAllFloor, deadBolts, numberOfDeadbolts, residenceVisible, sprinklerSystemType) {
        const responseFromBackend = response.lobData.homeowners.coverables.rating;
        await assert.assertEqual(response.quoteID, submissionId, 'Quote ID does not match');
        await assert.assertEqual(responseFromBackend.fireExtinguishers, Number(fireExtinguishers), 'Amount of Fire Extinguishers does not match');
        await assert.assertEqual(responseFromBackend.burglarAlarm.toString(), burglarAlarm, 'Burglar Alarm does not match');
        await assert.assertEqual(responseFromBackend.burglarAlarmType, burglarAlarmType, 'Burglar Alarm Type does not match');
        await assert.assertEqual(responseFromBackend.fireAlarm.toString(), fireAlarmMonitored, 'Fire Alarm Monitored does not match');
        await assert.assertEqual(responseFromBackend.smokeAlarm.toString(), smokeAlarms, 'Smoke Alarm does not match');
        await assert.assertEqual(responseFromBackend.smokeAlarmOnAllFloors.toString(), alarmsOnAllFloor, 'Smoke Alarm on all floors does not match');
        await assert.assertEqual(responseFromBackend.deadbolts.toString(), deadBolts, 'Deadbolts question does not match');
        // await assert.assertEqual(responseFromBackend.deadboltsNumber, Number(numberOfDeadbolts), 'Number of deadbolts does not match');
        await assert.assertEqual(responseFromBackend.visibleToNeighbors.toString(), residenceVisible, 'Residence Visible does not match');
        await assert.assertEqual(responseFromBackend.sprinklerSystemType, sprinklerSystemType.toLowerCase(), 'Sprinkler System Type does not match');
    }

    async clickSideBarDiscount() {
        await helper.clickButtonWithText('Discount');
    }

    async getNumberOfFireExtinguishers() {
        await this.hoDiscountFireExtinguishers;
        return this.hoDiscountFireExtinguishers.value;
    }

    async getSprinklerSystemType() {
        await this.hoDiscountSprinklerSystemType;
        return this.hoDiscountSprinklerSystemType.innerText;
    }

    async verifyDiscountDataIsRetained(
        fireExtinguishers,
        burglarAlarm,
        fireAlarmMonitored,
        smokeAlarms,
        alarmsOnAllFloor,
        deadBolts,
        numberOfDeadbolts,
        residenceVisible,
        sprinklerSystemType) {
        await assert.assertEqual(await this.getNumberOfFireExtinguishers(), fireExtinguishers, 'Number Of Fire Extinguishers does not match');
        await assert.assertAttributeValue(
            '#burglarAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            burglarAlarm,
            'Incorrect value selected for Burglar Alarm'
        );
        await assert.assertAttributeValue(
            '#fireAlarmReportingToMonitoringCenter > [class*="ToggleField-module__active"]',
            'data-value',
            fireAlarmMonitored,
            'Incorrect value selected for Fire Alarm Reporting To Monitoring Center'
        );
        await assert.assertAttributeValue(
            '#smokeAlarm > [class*="ToggleField-module__active"]',
            'data-value',
            smokeAlarms,
            'Incorrect value selected for Smoke Alarms'
        );
        await assert.assertAttributeValue(
            '#deadbolts > [class*="ToggleField-module__active"]',
            'data-value',
            deadBolts,
            'Incorrect value selected for Deadbolts'
        );
        await assert.assertAttributeValue(
            '#residenceVisibleToNeighbors > [class*="ToggleField-module__active"]',
            'data-value',
            residenceVisible,
            'Incorrect value selected for Residence Visible to Neighbours'
        );
        await assert.assertEqual(await this.getSprinklerSystemType(), sprinklerSystemType, 'Sprinkler System Type does not match');
    }
}