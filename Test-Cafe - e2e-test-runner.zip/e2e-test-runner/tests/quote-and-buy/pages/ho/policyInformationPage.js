import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class policyInformationPage {
    constructor() {
        this.hopolicyInformationTitle = Selector('#hoDiscountPage');
        this.hopolicyInformationStartDate = Selector('#startDate');
        this.hopolicyInformationAddress = Selector('#address');
        this.hopolicyInformationSameBillingAddress = Selector('#sameBillingAddress>[data-value]');
        this.hopolicyInformationFirstName = Selector('#firstName');
        this.hopolicyInformationLastName = Selector('#lastName');
        this.hopolicyInformationEmail = Selector('#email');
        this.hopolicyInformationPhone = Selector('#phone');
        this.hopolicyInformationCoveragesTitle = Selector('#hoPolicyInfoCoveragesTitle');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async setPolicyInfoValues(firstName, lastName, email, phoneNumber) {
        await helper.typeText(this.hopolicyInformationFirstName, firstName);
        await helper.typeText(this.hopolicyInformationLastName, lastName);
        await assert.assertEqual(this.hopolicyInformationEmail.value, email, 'Email was not pre populated');
        await helper.typeText(this.hopolicyInformationPhone, phoneNumber);
    }

    async policyInformationNext() {
        await commonLocators.goNext();
    }
}
