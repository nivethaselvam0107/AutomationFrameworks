import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class hopQualificationPage {
    constructor() {
        this.hoQualificationTitle = Selector('#questionSets_questionSetHeader');
        this.hoQualificationHaveADogYes = Selector('#HOPPreQualDog>[data-value=true]');
        this.hoQualificationHaveADogNo = Selector('#HOPPreQualDog>[data-value=false]');
        this.hoQualificationPropertyVacantYes = Selector('#HOPPreQualPropVacant>[data-value=true]');
        this.hoQualificationPropertyVacantNo = Selector('#HOPPreQualPropVacant>[data-value=false]');
        this.hoQualificationWhoOccupiesThisDwelling = Selector('#HOPPreQualOccupant');
        this.hoQualificationOccupyFullTime = Selector('#HOPPreQualOccupyFullTime>[data-value]');
        this.hoQualificationOccupyFullTimeYes = Selector('#HOPPreQualOccupyFullTime>[data-value=true]');
        this.hoQualificationOccupyFullTimeNo = Selector('#HOPPreQualOccupyFullTime>[data-value=false]');
        this.hoQualificationHaveASwimmingPoolYes = Selector('#HOPPreQualSwimmingPool>[data-value=true]');
        this.hoQualificationHaveASwimmingPoolNo = Selector('#HOPPreQualSwimmingPool>[data-value=false]');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async setDwellingOccupancy(whoOccupiesDwelling) {
        await helper.selectDropdown(this.hoQualificationWhoOccupiesThisDwelling, whoOccupiesDwelling);
    }

    async setOccupancyFullTime(occupyFullTime) {
        await helper.selectButtonOption((this.hoQualificationOccupyFullTime), occupyFullTime);
    }

    async qualificationNext() {
        await commonLocators.goNext();
    }

    async setQualificationValues(whoOccupiesDwelling, occupyFullTime) {
        await this.setDwellingOccupancy(whoOccupiesDwelling);
        await this.setOccupancyFullTime(occupyFullTime);
    }

    async verifyQualificationInfo(response, haveADog, propertyVacant, whoOccupiesDwelling, occupyFullTime, haveSwimmingPool) {
        const responseFromBackendCall = response.lobData.homeowners.preQualQuestionSets[0].answers;
        await assert.assertEqual(responseFromBackendCall.HOPPreQualDog, haveADog, 'Incorrect response to Do you have a Dog');
        await assert.assertEqual(responseFromBackendCall.HOPPreQualPropVacant, propertyVacant, 'Incorrect response to Is Property Vacant');
        await assert.assertContains(responseFromBackendCall.HOPPreQualOccupant, whoOccupiesDwelling, 'Incorrect response to Who occupies this dwelling');
        await assert.assertEqual(responseFromBackendCall.HOPPreQualOccupyFullTime, occupyFullTime, 'Incorrect response to occupy this dwelling full time');
        await assert.assertEqual(responseFromBackendCall.HOPPreQualSwimmingPool, haveSwimmingPool, 'Incorrect response to Do you have a Dog');
    }

    async clickSideBarQualification() {
        await helper.clickButtonWithText('Qualification');
    }

    async getWhoOccupiesDwelling() {
        await this.hoQualificationWhoOccupiesThisDwelling;
        return this.hoQualificationWhoOccupiesThisDwelling.innerText;
    }

    async verifyQualificationDataIsRetained(whoOccupiesDwelling, occupyFullTime) {
        await assert.assertAttributeValue(
            '#HOPPreQualDog > [class*="ToggleField-module__active"]',
            'data-value',
            'false',
            'Incorrect value selected for Do you have a dog'
        );
        await assert.assertAttributeValue(
            '#HOPPreQualPropVacant > [class*="ToggleField-module__active"]',
            'data-value',
            'false',
            'Incorrect value selected for Is this property vacant'
        );
        await assert.assertEqual(
            await this.getWhoOccupiesDwelling(),
            whoOccupiesDwelling,
            'Who occupies this dwelling does not match'
        );
        await assert.assertAttributeValue(
            '#HOPPreQualOccupyFullTime > [class*="ToggleField-module__active"]',
            'data-value',
            occupyFullTime,
            'Incorrect value selected for Do you occupy this dwelling full time'
        );
        await assert.assertAttributeValue(
            '#HOPPreQualSwimmingPool > [class*="ToggleField-module__active"]',
            'data-value',
            'false',
            'Incorrect value selected for Do you occupy this dwelling full time'
        );
    }
}
