import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class yourInfoPage {
    constructor() {
        this.hoYourInfoTitle = Selector('#hoYourInfoTitle');
        this.hoYourInfoEmail = Selector('#emailAddress');
        this.hoYourInfoEnterAddressManuallyLink = Selector('#linkToManualAddress');
        this.hoYourInfoHomeAddress = Selector('#addresslookupSearch');
        this.hoYourInfoHomeAddressSearchButton = Selector('#searchButton');
        this.hoYourInfoHomeFirstAddressFound = Selector('#addressesFound_0');
        this.hoYourInfoAddressLine1 = Selector('#addressLine1');
        this.hoYourInfoAddressLine2 = Selector('#addressLine2');
        this.hoYourInfoAddressLine3 = Selector('#addressLine3');
        this.hoYourInfoCity = Selector('#city');
        this.hoYourInfoZipCode = Selector('#postalCode');
        this.hoYourInfoState = Selector('#state');
        this.hoYourInfoStartDate = Selector('#periodStartDate');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async fillBasicInfo(email, addressLine1, addressLine2, addressLine3, city, periodStartDate) {
        await helper.typeText(this.hoYourInfoEmail, email);
        await helper.typeText(this.hoYourInfoAddressLine1, addressLine1);
        await helper.typeText(this.hoYourInfoAddressLine2, addressLine2);
        await helper.typeText(this.hoYourInfoAddressLine3, addressLine3);
        await helper.typeText(this.hoYourInfoCity, city);
        await helper.typeText(this.hoYourInfoStartDate, periodStartDate);
    }

    async clickEnterAddressManually() {
        await helper.click(this.hoYourInfoEnterAddressManuallyLink);
    }

    async yourInfoNext() {
        await commonLocators.goNext();
    }

    async verifyYourInfo(response, email, addressLine1, addressLine2, addressLine3, city, stateCode, ZipCode) {
        const stateAndZipCode = `${stateCode} ${ZipCode}`;
        const policyAddressDisplayName = [addressLine1,addressLine2,addressLine3,city,stateAndZipCode].join(', ');
        await assert.assertEqual(response.baseData.policyAddress.state,stateCode,'state do not match');
        await assert.assertEqual(response.baseData.policyAddress.displayName,policyAddressDisplayName,'policyAddress do not match');
        await assert.assertEqual(response.baseData.policyAddress.city,city,'city do not match');
        await assert.assertEqual(response.baseData.policyAddress.postalCode,ZipCode,'zipCode do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine1,addressLine1,'addressLine1 do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine2,addressLine2,'addressLine2 do not match');
        await assert.assertEqual(response.baseData.policyAddress.addressLine3,addressLine3,'addressLine3 do not match');
    }

    async clickSideBarYourInfo() {
        await helper.clickButtonWithText('Your Info');
    }

    async getAddressLine1() {
        await this.hoYourInfoAddressLine1;
        return this.hoYourInfoAddressLine1.value;
    }

    async getAddressLine2() {
        await this.hoYourInfoAddressLine2;
        return this.hoYourInfoAddressLine2.value;
    }

    async getAddressLine3() {
        await this.hoYourInfoAddressLine3;
        return this.hoYourInfoAddressLine3.value;
    }

    async getAddressCity() {
        await this.hoYourInfoCity;
        return this.hoYourInfoCity.value;
    }

    async getAddressZipCode() {
        await this.hoYourInfoZipCode;
        return this.hoYourInfoZipCode.innerText;
    }

    async getAddressState() {
        await this.hoYourInfoState;
        return this.hoYourInfoState.innerText;
    }

    async getEmailAddress() {
        await this.hoYourInfoEmail;
        return this.hoYourInfoEmail.value;
    }

    async getCoverageStartDate() {
        await this.hoYourInfoStartDate;
        return this.hoYourInfoStartDate.value;
    }


    async verifyYourInfoDataIsRetained(email, addressLine1, addressLine2, addressLine3, city, postalCode, state, periodStartDate) {
        await assert.assertEqual(await this.getEmailAddress(), email, 'Email Address does not match');
        await assert.assertEqual(await this.getAddressLine1(), addressLine1, 'Address Line 1 does not match');
        await assert.assertEqual(await this.getAddressLine2(), addressLine2, 'Address Line 2 does not match');
        await assert.assertEqual(await this.getAddressLine3(), addressLine3, 'Address Line 3 does not match');
        await assert.assertEqual(await this.getAddressCity(), city, 'City does not match');
        await assert.assertEqual(await this.getAddressZipCode(), postalCode, 'Address Postal Code does not match');
        await assert.assertEqual(await this.getAddressState(), state, 'Address State does not match');
        await assert.assertEqual(await Date(this.getCoverageStartDate()), Date(periodStartDate), 'Period Start Date does not match');
    }
}
