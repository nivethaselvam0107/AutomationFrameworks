import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();


export default class constructionPage {
    constructor() {
        this.hoConstructionTitle = Selector('#hoConstructionTitle');
        this.hoConstructionDetailsTitle = Selector('#hoConstructionDetailsContainerTitle');
        this.hoConstructionYearBuilt = Selector('#yearBuilt');
        this.hoConstructionNumberOfStories = Selector('#numberOfStories');
        this.hoConstructionGarage = Selector('#hasGarage>[data-value]');
        this.hoConstructionGarageNo = Selector('#hasGarage>[data-value=true]');
        this.hoConstructionGarageAttached = Selector('#hasGarage>[data-value=false]');
        this.hoConstructionConstructionType = Selector('#constructionType');
        this.hoConstructionFoundationType = Selector('#foundationType');
        this.hoConstructionRoofTitle = Selector('#hoRoofContainerTitle');
        this.hoConstructionRoofComposite = Selector('#roofType_composite');
        this.hoConstructionRoofAsphalt = Selector('#roofType_asphalt');
        this.hoConstructionRoofWood = Selector('#roofType_wood');
        this.hoConstructionRoofMetal = Selector('#roofType_metal');
        this.hoConstructionRoofTarAndGravel = Selector('#roofType_targravel');
        this.hoConstructionRoofSlate = Selector('label[for*="roofType_slate"]');
        this.hoConstructionRoofTile = Selector('#roofType_tile');
        this.hoConstructionRoofOther = Selector('#roofType_other');
        this.hoConstructionSelectedRoofType = Selector('div').withAttribute('aria-checked', 'true').prevSibling(0);
        this.hoConstructionRoofUpgraded = Selector('#roofUpgrade');
        this.hoConstructionPlumbingTitle = Selector('#hoPlumbingContainerTitle');
        this.hoConstructionPlumbing = Selector('#plumbing');
        this.hoConstructionPlumbingUpgrade = Selector('#plumbingUpgrade');
        this.hoConstructionHeatingTitle = Selector('#hoHeatingContainerTitle');
        this.hoConstructionPrimaryHeating = Selector('#primaryHeating');
        this.hoConstructionSecondaryHeating = Selector('#secondaryHeating>[data-value]');
        this.hoConstructionSecondaryHeatingYes = Selector('#secondaryHeating>[data-value=true]');
        this.hoConstructionSecondaryHeatingNo = Selector('#secondaryHeating>[data-value=false]');
        this.hoConstructionHeatingUpgrade = Selector('#heatingUpgrade');
        this.hoConstructionElectricalTitle = Selector('#hoElectricalContainerTitle');
        this.hoConstructionElectricalWiring = Selector('#wiring');
        this.hoConstructionElectricalSystem = Selector('#electricalSystem');
        this.hoConstructionWiringUpgrade = Selector('#electricalUpgrade');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async setConstructionValues(yearBuilt, numberOfStories, garage, constructionType, foundationType, roof, plumbing, primaryHeating, secondaryHeating, wiring, electricalSysyem) {
        await helper.typeText(this.hoConstructionYearBuilt, yearBuilt);
        await helper.typeText(this.hoConstructionNumberOfStories, numberOfStories);
        await helper.selectButtonOption(this.hoConstructionGarage, garage);
        await helper.selectDropdown(this.hoConstructionConstructionType, constructionType);
        await helper.selectDropdown(this.hoConstructionFoundationType, foundationType);
        await helper.click(this.hoConstructionRoofSlate);
        await helper.selectDropdown(this.hoConstructionPlumbing, plumbing);
        await helper.selectDropdown(this.hoConstructionPrimaryHeating, primaryHeating);
        await helper.selectButtonOption(this.hoConstructionSecondaryHeating, secondaryHeating);
        await helper.selectDropdown(this.hoConstructionElectricalWiring, wiring);
        await helper.selectDropdown(this.hoConstructionElectricalSystem, electricalSysyem);
    }

    async constructionNext() {
        await commonLocators.goNext();
    }

    async verifyConstructionInfo(response, submissionId, yearBuilt, numberOfStories, garage, constructionType, foundationType, roof, plumbing, primaryHeating, secondaryHeating, wiring, electricalSystem) {
        const responseFromBackend = response.lobData.homeowners.coverables.construction;
        await assert.assertEqual(response.quoteID, submissionId, 'Quote ID does not match');
        await assert.assertEqual(responseFromBackend.yearBuilt, Number(yearBuilt), 'Year Built does not match');
        await assert.assertEqual(responseFromBackend.storiesNumber, Number(numberOfStories), 'Number of stories does not match');
        await assert.assertEqual(responseFromBackend.hasGarage.toString(), garage, 'Garage value does not match');
        await assert.assertEqual(responseFromBackend.constructionType, constructionType.toLowerCase(), 'Construction Type does not match');
        await assert.assertEqual(responseFromBackend.foundationType, foundationType, 'Foundation Type does not match');
        await assert.assertEqual(responseFromBackend.roofType, roof.toLowerCase(), 'Roof Type does not match');
        await assert.assertEqual(responseFromBackend.plumbingType, plumbing.toLowerCase(), 'Plumbing Type does not match');
        await assert.assertEqual(responseFromBackend.primaryHeatingType, primaryHeating, 'Primary Heating Type does not match');
        await assert.assertEqual(responseFromBackend.secondaryHeatingExists.toString(), secondaryHeating, 'Secondary Heating Type does not match');
        await assert.assertEqual(responseFromBackend.wiringType, wiring.toLowerCase(), 'Wiring Type does not match');
        await assert.assertEqual(responseFromBackend.electricalType, electricalSystem, 'Electrical Type does not match');
    }

    async clickSideBarConstruction() {
        await helper.clickButtonWithText('Construction');
    }

    async getYearBuilt() {
        await this.hoConstructionYearBuilt;
        return this.hoConstructionYearBuilt.value;
    }

    async getNumberOfStories() {
        await this.hoConstructionNumberOfStories;
        return this.hoConstructionNumberOfStories.value;
    }

    async getConstructionType() {
        await this.hoConstructionConstructionType;
        return this.hoConstructionConstructionType.innerText;
    }

    async getFoundationType() {
        await this.hoConstructionFoundationType;
        return this.hoConstructionFoundationType.innerText;
    }

    async getSelectedRoofType() {
        await this.hoConstructionSelectedRoofType;
        return this.hoConstructionSelectedRoofType.getAttribute('value');
    }

    async getPlumbing() {
        await this.hoConstructionPlumbing;
        return this.hoConstructionPlumbing.innerText;
    }

    async getPrimaryHeating() {
        await this.hoConstructionPrimaryHeating;
        return this.hoConstructionPrimaryHeating.innerText;
    }

    async getWiring() {
        await this.hoConstructionElectricalWiring;
        return this.hoConstructionElectricalWiring.innerText;
    }

    async getElectricalSystem() {
        await this.hoConstructionElectricalSystem;
        return this.hoConstructionElectricalSystem.innerText;
    }

    async verifyConstructionDataIsRetained(
        yearBuilt,
        numberOfStories,
        garage,
        constructionType,
        foundationType,
        roof,
        plumbing,
        primaryHeating,
        secondaryHeating,
        wiring,
        electricalSystem
    ) {
        await assert.assertEqual(await this.getYearBuilt(), yearBuilt, 'Year Built does not match');
        await assert.assertEqual(await this.getNumberOfStories(), numberOfStories, 'Number Of Stories does not match');
        await assert.assertAttributeValue(
            '#hasGarage > [class*="ToggleField-module__active"]',
            'data-value',
            garage,
            'Incorrect value selected for Garage'
        );
        await assert.assertEqual(await this.getConstructionType(), constructionType, 'Construction Type does not match');
        await assert.assertEqual(await this.getFoundationType(), foundationType, 'Foundation Type does not match');
        await assert.assertEqual(await this.getSelectedRoofType(), roof.toLowerCase(), 'Roof Type does not match');
        await assert.assertEqual(await this.getPlumbing(), plumbing, 'Plumbing value does not match');
        await assert.assertEqual(await this.getPrimaryHeating(), primaryHeating, 'Primary Heating does not match');
        await assert.assertAttributeValue(
            '#secondaryHeating > [class*="ToggleField-module__active"]',
            'data-value',
            secondaryHeating,
            'Incorrect value selected for Secondary Heating'
        );
        await assert.assertEqual(await this.getWiring(), wiring, 'Electrical Wiring does not match');
        await assert.assertEqual(await this.getElectricalSystem(), electricalSystem, 'Electrical System does not match');
    }
}
