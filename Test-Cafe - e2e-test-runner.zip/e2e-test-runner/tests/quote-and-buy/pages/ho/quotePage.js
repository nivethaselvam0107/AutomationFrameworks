import { Selector } from 'testcafe';
import Assertions from '../../../utilities/assertions';
import Helper from '../../../utilities/helper';
import CommonLocators from '../../../utilities/commonLocators';

const helper = new Helper();
const assert = new Assertions();
const commonLocators = new CommonLocators();

export default class quotePage {
    constructor() {
        this.hoQuoteTitle = Selector('#hoQuoteTitle');
        this.hoQuotePolicyStartDate = Selector('#startDate');
        this.hoQuotePaymentToggleMonthly = Selector('#paymentToggle>[data-value=monthly]');
        this.hoQuotePaymentTogglePayInFull = Selector('#paymentToggle>[data-value=annually]');
        this.hoQuoteQuoteAmount = Selector('span[class*="CurrencyField-module"]>span');
        this.hoQuoteFullQuoteAmount = Selector('span[class*="CurrencyField-module"]>span');
        this.hoQuoteBuyNowButton = Selector('button[id*="buyNowButton_[0]"]');
    }

    // eslint-disable-next-line class-methods-use-this
    async checkDefaultFieldsShowOnYourInfoPage() {
        console.log('Check to see if default fields exists as a basic check');
    }

    async getQuoteMonthlyAmount() {
        await helper.click(this.hoQuotePaymentToggleMonthly);
        return this.hoQuoteQuoteAmount.innerText;
    }

    async getQuoteFullAmount() {
        await helper.click(this.hoQuotePaymentTogglePayInFull);
        return this.hoQuoteQuoteAmount.innerText;
    }

    async clickBuyNowButton() {
        await helper.click(this.hoQuoteBuyNowButton);
    }

    async getPolicyStartDate() {
        await this.hoQuotePolicyStartDate;
        return this.hoQuotePolicyStartDate.innerText;
    }

    async verifyHoQuoteInfo(response, submissionId, quoteMonthlyAmount, quoteFullAmount, periodStartDate, policyStartDate, submissionStatus) {
        const quoteDataFromBackend = response.quoteData.offeredQuotes[0];
        quoteMonthlyAmount = parseFloat(quoteMonthlyAmount.replace('USD', '').replace(',', ''));
        quoteFullAmount = parseFloat(quoteFullAmount.replace('USD', '').replace(',', ''));
        await assert.assertEqual(response.quoteID, submissionId, 'Quote ID does not match');
        await assert.assertEqual(quoteDataFromBackend.status, submissionStatus, 'Period Status does not match');
        await assert.assertEqual(quoteDataFromBackend.premium.monthlyPremium.amount, quoteMonthlyAmount, 'Monthly Premium does not match');
        await assert.assertEqual(quoteDataFromBackend.premium.total.amount, quoteFullAmount, 'Full Premium does not match');
        await assert.assertEqual(new Date(periodStartDate), new Date(policyStartDate), 'Policy Start date does not match');
    }
}
