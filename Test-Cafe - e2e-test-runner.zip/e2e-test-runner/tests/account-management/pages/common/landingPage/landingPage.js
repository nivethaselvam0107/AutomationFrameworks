import { Selector } from 'testcafe';
import Assertions from '../../../../utilities/assertions';

const assert = new Assertions();

export default class LoginComponentPage {
    constructor() {
        this.balanceTile = Selector("#balanceContainer");
        this.nextBillTile = Selector("#nextBillContainer");
        this.lastPaymentTile = Selector("#lastPaymentContainer");

        this.renewalNotification = Selector("#renewalNotification");

        this.policyTable = Selector("#tableContainer table");

        this.quickLinksContainer = Selector("#quickLinksContainer");
        this.printAnIDCardLink = Selector("#printAnIDCardLink");
        this.makeAPaymentLink = Selector("#makeAPaymentLink");
        this.setupAutomatedPaymentsLink = Selector("#setupAutomatedPaymentsLink");
        this.updateMyDetailsLink = Selector("#updateMyDetailsLink");
        this.changeMyPolicyLink = Selector("#changeMyPolicyLink");
        this.fileAClaimLink = Selector("#fileAClaimLink");
        this.getAPAQuote = Selector("#getAPAQuote");
        this.getAHOQuote = Selector("#getAHOQuote");

        this.personalisedOfferContainer = Selector("#offerContainer");

        this.contactSidebarWidget = Selector("#contactSidebarWidget");
        this.twitterSidebarWidget = Selector("#twitterSidebarWidget");
        this.youtubeSidebarWidget = Selector("#youtubeSidebarWidget");
        this.facebookSidebarWidget = Selector("#facebookSidebarWidget");
    }

    async checkDefaultFieldsExistForNonRenewalAccount() {
        await assert.elementPresent(this.balanceTile, 'My Balance tile is not present');
        await assert.elementPresent(this.nextBillTile, 'My Next Bill tile is not present');
        await assert.elementPresent(this.lastPaymentTile, 'My Last Payment tile is not present');

        await assert.elementNotPresent(this.renewalNotification);
        await assert.elementPresent(this.policyTable, 'Policy table is not present');

        await assert.elementPresent(this.quickLinksContainer, 'Quick link container is not present');
        await assert.elementNotPresent(this.printAnIDCardLink);
        await assert.elementPresent(this.makeAPaymentLink, 'Make a payment link is not present');
        await assert.elementPresent(this.setupAutomatedPaymentsLink, 'Setup automated payment link is not present');
        await assert.elementPresent(this.updateMyDetailsLink, 'Update my details link is not present');
        await assert.elementPresent(this.changeMyPolicyLink, 'Change my policy link is not present');
        await assert.elementPresent(this.fileAClaimLink, 'File a claim link is not present');
        await assert.elementPresent(this.getAPAQuote, 'Get a Personal Auto quote link is not present');
        await assert.elementPresent(this.getAHOQuote, 'Get a Homeowners quote link is not present');

        await assert.elementNotPresent(this.personalisedOfferContainer);

        await assert.elementPresent(this.contactSidebarWidget, 'Contact Media Sidebar widget is not present');
        await assert.elementPresent(this.twitterSidebarWidget, 'Twitter Media Sidebar widget is not present');
        await assert.elementPresent(this.youtubeSidebarWidget, 'Youtube Media Sidebar widget is not present');
        await assert.elementPresent(this.facebookSidebarWidget, 'Facebook Media Sidebar widget is not present');
    }
}
