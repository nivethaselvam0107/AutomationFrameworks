import { Selector } from 'testcafe';
import Assertions from '../../../../utilities/assertions';
import Helper from '../../../../utilities/helper';

const helper = new Helper();
const assert = new Assertions();

export default class HeaderComponent {
    constructor() {
        this.logo = Selector("#headerImage");
        this.faqHeaderLink = Selector("#faqHeaderLink");
        this.languageSelect = Selector("#languageSelect");
        this.dropdownMenuTrigger = Selector("#dropdownMenu_Trigger");
        this.userLoggedIn = this.dropdownMenuTrigger.find("#dropdownMenu_userName");
        this.dropdownMenuAccountLink = Selector("#accountLink");
        this.dropdownMenuLogOutLink = Selector("#logOutLink");
    }

    async checkDefaultFieldsExistForNonRenewalAccount() {
        await assert.elementPresent(this.logo, 'Logo is not present');
        await assert.elementPresent(this.faqHeaderLink, 'FAQ link is not present');
        await assert.elementPresent(this.languageSelect, 'Language select is not present');
        await assert.elementPresent(this.dropdownMenuTrigger, 'Dropdown menu is not present');
        await assert.elementPresent(this.userLoggedIn, 'User email is not present');
        await assert.elementPresent(this.dropdownMenuAccountLink, 'Account link in dropdown is not present');
        await assert.elementPresent(this.dropdownMenuLogOutLink, 'Log out link in dropdown is not present');
    }

    async clickLogo() {
        await helper.click(this.logo);
    }

    async logout() {
        await helper.click(this.dropdownMenuTrigger);
        await helper.click(this.dropdownMenuLogOutLink);
        await assert.assertEqual(helper.getLocation(), `${process.env.TEST_ENV_URL}/login-page`, 'Incorrect page');
    }

    async goToAccountsPage() {
        await helper.click(this.dropdownMenuTrigger);
        await helper.click(this.dropdownMenuAccountLink);
    }

    async changeLanguageByCode(newLanguageCode) {
        await t
            .click(this.languageSelect)
            .click(this.languageSelect.find(`option[value="${newLanguageCode}"]`));
    }
}
