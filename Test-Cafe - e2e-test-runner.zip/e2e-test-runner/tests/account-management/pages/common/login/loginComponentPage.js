import { Selector, ClientFunction, t } from 'testcafe';
import Assertions from '../../../../utilities/assertions';
import Helper from '../../../../utilities/helper';

const helper = new Helper();
const assert = new Assertions();

export default class LoginComponentPage {
    constructor() {
        this.loginUsernameInput = Selector("#username");
        this.loginPasswordInput = Selector("#password");

        this.forgotPasswordLink = Selector("#linkToForgotPassword");
        this.signUpLink = Selector("#signUpLink");

        this.signInButton = Selector("#signIn");
    }

    async checkMainLoginComponents() {
        await assert.elementPresent(this.signInButton, 'Login Component Sign In button is present');
        await assert.elementPresent(this.loginUsernameInput, 'Login Component username input is present');
        await assert.elementPresent(this.loginPasswordInput, 'Login Component password input is present');
    }

    async fillUserAndPassword(username, password) {
        // get the last segment of a URL and check if the user has been redirected
        // after clicking the sign in button
        const getLocation = ClientFunction(() => {
            return document.location.href.substring(document.location.href.lastIndexOf('/') + 1)
        });

        await helper.typeText(this.loginUsernameInput, username);
        await helper.typeText(this.loginPasswordInput, password);
        await helper.click(this.signInButton);
        await t.expect(helper.getLocation()).contains('home');
    }
}
