import LoginComponentPage from '../../../pages/common/login/loginComponentPage';
import sampleData from '../../../data/login/sampleData.json5';

const loginComponentPage = new LoginComponentPage();

const isVersion = process.env.IS_VERSION;
const platformData = sampleData[isVersion];

const TEST_URL = process.env.TEST_ENV_URL;
fixture`Customer Engage AccountManagement Login Component Page`
    .page`${TEST_URL}`;

test('Default fields and components render on load', async () => {
    await loginComponentPage.checkMainLoginComponents();
    await loginComponentPage.fillUserAndPassword(platformData.username, platformData.password);
}).meta({Regression: 'true' , Platform: 'all', Application : "AMP" });