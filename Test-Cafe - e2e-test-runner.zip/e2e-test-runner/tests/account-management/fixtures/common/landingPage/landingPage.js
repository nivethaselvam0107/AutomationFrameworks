import LandingPage from '../../../pages/common/landingPage/landingPage';
import LoginComponentPage from '../../../pages/common/login/loginComponentPage';
import HeaderComponent from '../../../pages/common/header/header';
import sampleData from '../../../data/login/sampleData.json5';

const headerComponent = new HeaderComponent();
const landingPage = new LandingPage();
const loginComponentPage = new LoginComponentPage();

const isVersion = process.env.IS_VERSION;
const platformData = sampleData[isVersion];

const TEST_URL = process.env.TEST_ENV_URL;
fixture`Customer Engage AccountManagement Landing Page`
    .page`${TEST_URL}`;

test('Default fields and components render on load', async () => {
    await loginComponentPage.fillUserAndPassword(platformData.username, platformData.password);
    await landingPage.checkDefaultFieldsExistForNonRenewalAccount();
    await headerComponent.logout();
}).meta({Regression: 'true' , Platform: 'all', Application : "AMP" });