#HW Enterprise Enage E2E Tests 

By default, when running any of the below commands, the tests execute against your localhost.
Tests are run per application. 
You can run e2e tests against an external url by adding extra parameters to the run command. These are outlined below.

## Installing Dependencies

cd e2e-test-runner

npm install

## Running Quote and Buy E2E Tests

cd e2e-test-runner

npm run e2e-quote-and-buy

## Running Producer Engage E2E Tests

cd e2e-test-runner

npm run e2e-producer-engage

## Running against an external host
By default the external host is going to use the following url - `https://online-<ENV>.host.net/<APP>-<PLATFORM>`;

The params you must provide to run against an external host matching the above params is as follows...

--env ['develop', 'test', 'master', 'localhost'] - localhost by default

--app ['quote-and-buy', 'producer-engage'] - passed in by default when specifying which portal you want to build against

--platform ['emerald', 'ferrite', 'granite'] - only used when the environment is not localhost

## Examples

Build against - https://online-master.host.net/quote-and-buy-granite/

npm run e2e-quote-and-buy --env='develop' --platform='granite'

Build against - https://online-develop.host.net/producer-engage-ferrite/

npm run e2e-producer-engage --env='develop' --platform='ferrite'

## Filtering tests to be executed
Test or Fixtures can be tagged using the Meta Function. This allows us to add extra information to the test or fixture.
An example of the tags we use are :
    DigitalTestcaseID: 'TC5024',
    Regression: 'true',
    UAT: 'true',
    Platform: 'Granite'
These either reference the Test Case ID or a Test Set.
The --metaFilter option is used in the command line in order to filter tests based on the parameters.  

## Examples

npm run e2e-quote-and-buy -- --metaFilter UAT=true     