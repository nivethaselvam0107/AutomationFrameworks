module.exports = {
  "root": true,
  "parser": "babel-eslint",
  "plugins": [
    "testcafe"
  ],
  "extends": "plugin:testcafe/recommended"
}