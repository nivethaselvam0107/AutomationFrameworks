#!/bin/sh
echo "Setting Path"
export PATH='$PATH:/Users/dgangwar/Documents/android-sdk-macosx/platform-tools/:/Users/dgangwar/Documents/android-sdk-macosx/tools'
echo "Export ANDROID_HOME"
export PATH='export ANDROID_HOME=/Users/dgangwar/Documents/android-sdk-macosx/'
