#!/bin/bash

ios_webkit_debug_proxy -c 96d0729b517b58f1035f4f8697cbc84feeb3d0df:27753 -d &
appium --session-override --show-ios-log --tmp /tmp/iphone/ -p 4725 --bootstrap-port 4464 --webkit-debug-proxy-port 27753 &

ios_webkit_debug_proxy -c ff57ed38b4cf9b3cdc4a42620f68fc14da954aff:27754 -d&
appium -U ff57ed38b4cf9b3cdc4a42620f68fc14da954aff --show-ios-log --tmp /tmp/ipad/ --bootstrap-port 4465 --webkit-debug-proxy-port 27754 &

ios_webkit_debug_proxy -c 9cefc2be7b07573e19cb934875bc17d883c325ba:27755 -d > iphone6s_webkit.log &
appium --session-override --show-ios-log --tmp /tmp/iphone/ -p 4726 --bootstrap-port 4466 --webkit-debug-proxy-port 27755  --webdriveragent-port 8201 > iphone6s_appium.log &

ios_webkit_debug_proxy -c 5eae0eeac2a5186bc8c69c203ea42a2c8c5f2210:27756 -d > ipadair2_webkit.log &
appium --session-override --show-ios-log --tmp /tmp/ipad/ -p 4727 --bootstrap-port 4467 --webkit-debug-proxy-port 27756 --webdriveragent-port 8202 > ipadair2_appium.log &

appium -p 4999 -U R32D1026TXE &

appium -p 4998 -U 01a7484b032f89c5 &

appium -p 4997 -bp 2251 -U 2fa9a7d5 --webdriveragent-port 8203 > galaxytabs2.log &

appium -p 4996 -bp 2252 -U LGH840807128cb --webdriveragent-port 8204 > lgg5.log  &
