# For running test use  

ant TestDev -DgroupName=Smoke -Dhost.name=mmportal17.guidewire.com

groupName  - > Name of the Test Group
host.name	- > Application host value

# SonarQube plugin

This plugin will help improve code quality.
 
1. Please use our sonar server of KDC http://sonar-kdc.guidewire.com:9000/
2. Project name :  Portals-Automation

To run sonar scaner use : 
mvn clean verify sonar:sonar -Dsonar.host.url=http://sonar-kdc.guidewire.com:9000
