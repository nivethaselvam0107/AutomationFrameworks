package com.guidewire.multhithreading;

import com.guidewire.data.BasicAuthenticator;
import com.guidewire.data.BearerAuthenticator;
import com.thetransactioncompany.jsonrpc2.JSONRPC2Request;
import com.thetransactioncompany.jsonrpc2.JSONRPC2Response;
import com.thetransactioncompany.jsonrpc2.client.ConnectionConfigurator;
import com.thetransactioncompany.jsonrpc2.client.JSONRPC2Session;
import com.thetransactioncompany.jsonrpc2.client.JSONRPC2SessionException;
import org.apache.log4j.Logger;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.UUID;

public final class JsonRpcExecutor {

    private static final Logger LOGGER = Logger.getLogger(JsonRpcExecutor.class);
    private static final JsonRpcExecutor INSTANCE = new JsonRpcExecutor();

    public static JsonRpcExecutor getInstance() {
        return INSTANCE;
    }

    public synchronized String jsonRpcCallWithCredentials(final List<Object> params, final String method, final String url, final String login, final String password) throws MalformedURLException, JSONRPC2SessionException {
        LOGGER.info("Retrieving data from backend. Params:\n\tusername: " + login +
            "\n\tparameters: " + params +
            "\n\tmethod name: " + method +
            "\n\turl: " + url);

        BasicAuthenticator authConfigurator = null;
        if(!login.isEmpty()) {
            authConfigurator = new BasicAuthenticator();
            authConfigurator.setCredentials(login, password);
        }
        return jsonRpcCall(params, method, url, authConfigurator);
    }

    public synchronized String jsonRpcCallWithToken(final List<Object> params, final String method, final String url, final String token) throws MalformedURLException, JSONRPC2SessionException {
        LOGGER.info("Retrieving data from backend using access token. Params:" +
            "\n\tparameters: " + params +
            "\n\tmethod name: " + method +
            "\n\turl: " + url);

        BearerAuthenticator authConfigurator = null;
        if(!token.isEmpty()) {
            authConfigurator = new BearerAuthenticator();
            authConfigurator.setToken(token);
        }
        return jsonRpcCall(params, method, url, authConfigurator);
    }

    private synchronized String jsonRpcCall(final List<Object> params, final String method, final String url, ConnectionConfigurator authConfigurator) throws MalformedURLException, JSONRPC2SessionException {
        JSONRPC2Session session = new JSONRPC2Session( new URL(url) );

        session.getOptions().setRequestContentType("application/json; charset=UTF-8");
        session.getOptions().acceptCookies(true);
        String[] allowedTypes = new String[]{"text/html", "application/json", "text/plain"};
        session.getOptions().setAllowedResponseContentTypes(allowedTypes);

        session.setConnectionConfigurator(authConfigurator);

        JSONRPC2Request requestOut = new JSONRPC2Request(method, params, UUID.randomUUID().toString());
        LOGGER.info("Retrieve data from backend, request: \n\t" + requestOut.toJSONString());

        JSONRPC2Response response = session.send(requestOut);
        LOGGER.info("Data retrieved from backend:\n\t" + response);
        return response.getResult().toString();
    }
}
