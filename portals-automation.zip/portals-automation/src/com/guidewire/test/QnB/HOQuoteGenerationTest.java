package com.guidewire.test.QnB;

import com.guidewire.widgetcomponents.Modal;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.portals.qnb.pages.ConstructionPage;
import com.guidewire.portals.qnb.pages.DiscountPage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.YourHomePage;
import com.guidewire.portals.qnb.pages.ZipCodePage;


public class HOQuoteGenerationTest {

	Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());
	Logger logger = Logger.getLogger(this.getClass().getName());

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Qualification Checks - Q1
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Any coverage declined, cancelled or non-renewed in past 5 years? YES
					4. Any business conducted on the premises? No.
					5. Click Next
					6. Complete the Your Home page.
					7. Complete the Construction page.
					8. Complete the discount page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. Yes slider selected.
					4. No slider selected.
					5.  The Your Home page is loaded.
					6. The construction page is loaded.
					7. The discount page is loaded.
					8. Verify Quote page is loaded and quote is generated. 
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4977 @ Qualification Checks - Q1")
	public void testQuoteGenerationWithCoverageDeclinedinLast5Years(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation With Coverage Declined in Last 5 Years is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status");
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Qualification Checks - Q2.
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Any coverage declined, cancelled or non-renewed in past 5 years? NO
					4. Any business conducted on the premises? YES.
					5. Type of Business - Day/Child Care
					6. Click Next
					7. Complete the Your Home page.
					8. Complete the Construction page.
					9. Complete the discount page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. No slider selected.
					4. Yes slider selected.
					5. Day/Child Care is selected.
					6. The Your Home page is loaded.
					7. The construction page is loaded.
					8. The discount page is loaded.
					9. Verify Quote page is loaded and quote is generated. 
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4978 @ Qualification Checks - Q2")
	public void testQuoteGenerationWithBusinessOnPremises(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation WithBusiness On Premises is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Rental property check - No Quote.
	  
	             Step actions :- 
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Enter 500000 in Estimated house value.
					5. Location Type - In City Limits
					6. Residence Type - 1 Family Residence
					7. Distance to Fire Hydrant - Within 500ft
					8. Distance to Fire Station - Within 5 miles.
					9. Within 300ft of Commercial property - No.
					10. Flooding/Fire Hazard - No.
					11. Use your home as a - Rental Property
					12. Your Home is - Tenant Occupied
					13. Click on Next.
					14. Complete the Construction page.
					15. Complete the discount page
	  
	             Expected Results :- 
					1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. N/A
					5. In City Limits selected
					6. 1 Family Residence is selected.
					7. Slider is on the "Within 500ft" position
					8. Slider is on the "Within 5 miles" position
					9. Slider is on the "No" position
					10. Slider is on the "No" position
					11. "Rental Property" is selected.
					12. "Tenant Occupied" is selected
					13. Construction page is loaded.
					14. The discount page is loaded.
					15. Verify Quote is not generated. - Cannot Proceed
					
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4979 @ Rental property check - No Quote")
	public void testQuoteGenerationWithRentalProperty(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToDiscountPage().goNext();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isCanNotProcessAlertDisplayed().shouldBeTrue("Quote with Rental Property is possible");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Max Home value.
	  
	             Step actions :- 
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Enter 2000000000 in Estimated house value.
					5. Location Type - In City Limits
					6. Residence Type - 1 Family Residence
					7. Distance to Fire Hydrant - Within 500ft
					8. Distance to Fire Station - Within 5 miles.
					9. Within 300ft of Commercial property - No.
					10. Flooding/Fire Hazard - No.
					11. Use your home as a - Primary
					12. Your Home is - Owner Occupied
					13. Click on Next.
					14. Complete the Construction page.
					15. Complete the discount page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. N/A
					5. In City Limits selected
					6. 1 Family Residence is selected.
					7. Slider is on the "Within 500ft" position
					8. Slider is on the "Within 5 miles" position
					9. Slider is on the "No" position
					10. Slider is on the "No" position
					11. "Primary" is selected.
					12. "Owner Occupied" is selected
					13. Construction page is loaded.
					14. The discount page is loaded.
					15. Verify Quote page is loaded and quote is generated.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4980 @ Max Home value")
	public void testQuoteGenerationWithMaxHouseValue(String browserName) throws Exception {
		pagefactory.setHOPolicyDataAndValidateQuoteGenerated().shouldBeTrue("Max House value Quote is not generated");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status when quote is generated with Max house value.");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Max Home value validation.
	  
	             Step actions :- 
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Enter 2000000001 in Estimated house value.
					5. Location Type - In City Limits
					6. Residence Type - 1 Family Residence
					7. Distance to Fire Hydrant - Within 500ft
					8. Distance to Fire Station - Within 5 miles.
					9. Within 300ft of Commercial property - No.
					10. Flooding/Fire Hazard - No.
					11. Use your home as a - Primary
					12. Your Home is - Owner Occupied
					13. Click on Next.
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. N/A
					5. In City Limits selected
					6. 1 Family Residence is selected.
					7. Slider is on the "Within 500ft" position
					8. Slider is on the "Within 5 miles" position
					9. Slider is on the "No" position
					10. Slider is on the "No" position
					11. "Primary" is selected.
					12. "Owner Occupied" is selected
					13. Validation message  - "Maximum value is 2000000000" is displayed. User can not proceed through the wizard.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" } , description = "TC4981 @ Max Home value validation")
	public void testQuoteGenerationWithMaxHouseValidation(String browserName) throws Exception {
		ThreadLocalObject.getData().put("HomeValue", "2000000001");
		YourHomePage homePage = pagefactory.setHOPolicyDataUpToYourHomePage().goNext();
		homePage.isHomeEstimationFieldMarkedWithMAXValueError()
				.shouldBeEqual("House Value is not marked with max value error");
		homePage.goNext().isYourHomePageLoaded().shouldBeTrue("Construction page is displayed when max value validation was still present");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Your Home page -  non default choices, should get quote
	  
	             Step actions :- 
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Enter 1000000 in Estimated house value.
					5. Location Type - In Fire District
					6. Residence Type - 2 Family Residence
					7. Distance to Fire Hydrant - Over 500ft
					8. Distance to Fire Station - Over 5 miles.
					9. Within 300ft of Commercial property - Yes.
					10. Flooding/Fire Hazard - Yes.
					11. Use your home as a - Secondary.
					12. Your Home is - Non-Owner Occupancy.
					13. Click on Next
					14. Complete the Construction Page
					15. Complete Discount page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. N/A
					5. In Fire District is selected
					6. 2 Family Residence is selected.
					7. Slider is on the "Over 500ft" position
					8. Slider is on the "Over 5 miles" position
					9. Slider is on the "Yes" position
					10. Slider is on the "Yes" position
					11. "Secondary" is selected.
					12. "Non-Owner Occupancy" is selected
					13. Construction page is loaded.
					14. Discount page is loaded
					15. Quote page is loaded with a quotation value.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4982 @ Your Home page -  non default choices, should get quote")
	public void testQuoteGenerationWithNonDefaultValueOnYourHomePage(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation With Non Default Data on Your Home page is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Construction Page - non default choices should get quote.
	  
	             Step actions :- 
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Complete the Your Home page
					5. Year Build - 1999
					6. Number of Stories - 5+
					7. Garage - Attached Garage
					8. Construction Type - Log
					9. Foundation Type - Full Basement
					10. Roof - Other 
					11. Specify other - Felt
					12. Plumbing - PVC
					13. Primary Heating - Other 
					14. Specify other - Solid Fuel
					15. Secondary Heating - No
					16. Electrical Wiring - Knob & Tube
					17. Electrical system - Fuses
					18. Click Next
					19. Complete Discount page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 5+ is selected
					7. Attached Garage radio button is selected.
					8. "Log" is selected
					9. "Full Basement" is selected
					10. "Other" is selected
					11. "Felt" is in the Specify other textbox.
					12. "PVC" is selected.
					13. "Other" is selected.
					14. "Solid Fuel" is in the Specify other textbox.
					15. "No" radio slider selected.
					16. "Knob & Tube" is selected.
					17. "Fuses" is selected
					18. Discount page is loaded.
					19. Quote page is loaded with a quotation value
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE" }, description = "TC4983 @ Construction Page - non default choices should get quote.")
	public void testQuoteGenerationWithNonDefaultValueOnConstructionPage(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation With Non Default Data on Construction page is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Additional discounts should still produce a quote.
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Fire Extinguishers in Your Home - YES
					7. Burglar Alarm - YES
					8. Specify Type: Central Station
					9. Fire Alarm Reporting To Monitoring Center  - YES
					10. Smoke Alarms - YES
					11. Alarms are on all floors - YES
					12. Deadbolts - YES
					13. Residence Visible to Neighbours - YES
					14. Sprinkler System Type - None
					15. Expand Additional (optional) link
					16. Roomers or Boarders - Yes
					17. Specify number of boarders - 2
					18. Number of Units - 1
					19. Fireplace or Wood Stove - No
					20. Swimming Pool - No
					21. Trampoline - No
					22. Water leakage or flooding in the past 5 years? - Yes
					23. Click Next
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. YES is selected.
					7. YES is selected.
					8. Central Station is selected.
					9. YES is selected.
					10. YES is selected.
					11. YES is selected.
					12. YES is selected.
					13. YES is selected.
					14. None is selected.
					15. Addtionals discounts are displayed.
					16. YES is selected.
					17. 2 is filled in.
					18. 1 Unit is selected
					19. No is selected.
					20. No is selected.
					21. No is selected.
					22. YES is selected.
					23. Quote page is loaded with a quotation value
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4985 @ Additional discounts should still produce a quote.")
	public void testQuoteGenerationWithAdditionalDiscountPageData(String browserName) throws Exception {
		pagefactory.setHOPolicyDataUpToAdditionalDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation with additional Discount page data is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status when Quote is created with additional data");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- No Discounts - Should still get a quote
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Fire Extinguishers in Your Home - No
					7. Burglar Alarm - No
					8. Fire Alarm Reporting To Monitoring Center  - No
					9. Smoke Alarms - No
					10. Deadbolts - No
					11. Residence Visible to Neighbours - No
					12. Sprinkler System Type - None
					13. Click Next
	  
	             Expected Results :- 
					1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. No is selected.
					7. No is selected.
					8. No is selected.
					9. No is selected.
					10. No is selected.
					11. No is selected.
					12. None is selected.
					13. Quote page is loaded with a quotation value
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4984 @ No Discounts - Should still get a quote.")
	public void testQuoteGenerationWithNoDiscountPageData(String browserName) throws Exception {
		pagefactory.setHOPolicyDataAndValidateQuoteGenerated().shouldBeTrue("Quote Generation without additional Discount page data is not possible.");
		QuoteInfoBar.isSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status when Quote is created without additional Discount data");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Roof upgrade not before construction year
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page
					5. Year Build - 2005
					6. Number of Stories - 1
					7. Garage - No Garage
					8. Construction Type - Concrete
					9. Foundation Type - Slab
					10. Roof - Composition Shingles....
					11. Check "Roofing Upgraded" checkup.
					12. Enter 2004 for the year
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 1 is selected
					7. No Garage radio button is selected.
					8. "Concrete" is selected
					9. "Slab" is selected
					10. "Composition Shingles...." is selected
					11. Year textbox appears.
					12. Validation message - "Value must not be lesser than year of construction build 2005"
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke"}, description = "TC4988 @ Roof upgrade not before construction year")
	public void testRoofUpgradeYearValidationOnConstructionpage(String browserName) {
		pagefactory.setHOPolicyDataUpToConstructionPage().withRoofUpgradeYear().goNext().isRoofUpGradeMarkedWithError().shouldBeEqual("Roof upgrade year field is not marked with error when upgrade year value is before Construction date");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Plumbing upgrade not before construction year
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page
					5. Year Build - 2005
					6. Number of Stories - 1
					7. Garage - No Garage
					8. Construction Type - Concrete
					9. Foundation Type - Slab
					10. Plumbing - PVC
					11. Check "Plumbing Upgraded" checkup.
					12. Enter 2004 for the year
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 1 is selected
					7. No Garage radio button is selected.
					8. "Concrete" is selected
					9. "Slab" is selected
					10. "PVC" is selected
					11. Year textbox appears.
					12. Validation message - "Value must not be lesser than year of construction build 2005"
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke"}, description = "TC4989 @ Plumbing upgrade not before construction year")
	public void testPlumbingUpgradeYearValidationOnConstructionpage(String browserName) {
		pagefactory.setHOPolicyDataUpToConstructionPage().withPlumbingUpgradeYear().goNext().isPlumbingUpGradeMarkedWithError().shouldBeEqual("Roof upgrade year field is not marked with error when upgrade year value is before Construction date");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Heating upgrade not before construction year
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page
					5. Year Build - 2005
					6. Number of Stories - 1
					7. Garage - No Garage
					8. Construction Type - Concrete
					9. Foundation Type - Slab
					10. Heating - Electricity
					11. Secondary Heating - No
					12. Check "Heating Upgraded" checkup.
					13. Enter 2004 for the year
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 1 is selected
					7. No Garage radio button is selected.
					8. "Concrete"" is selected
					9. "lab" is selected
					10. "Electricity" is selected
					11. No is selected
					12. Year textbox appears.
					13. Validation message - "Value must not be lesser than year of construction build 2005"
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4990 @ Heating upgrade not before construction year")
	public void testHeatingUpgradeYearValidationOnConstructionpage(String browserName) {
		pagefactory.setHOPolicyDataUpToConstructionPage().withHeatingUpgradeYear().goNext().isHeatingUpGradeMarkedWithError().shouldBeEqual("Roof upgrade year field is not marked with error when upgrade year value is before Construction date");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Electrical upgrade not before construction year
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page
					5. Year Build - 2005
					6. Number of Stories - 1
					7. Garage - No Garage
					8. Construction Type - Concrete
					9. Foundation Type - Slab
					10. Electrical Wiring - Copper
					11. Electrical system - Circuit Breaker
					12. Check "Plumbing Upgraded" checkup.
					13. Enter 2004 for the year
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 1 is selected
					7. No Garage radio button is selected.
					8. "Concrete" is selected
					9. "Slab" is selected
					10. "Copper" is selected
					11. Circuit Breaker is selected
					12. Year textbox appears.
					13. Validation message - "Value must not be lesser than year of construction build 2005"
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Smoke" }, description = "TC4991 @ Electrical upgrade not before construction year")
	public void testElectricalUpgradeYearValidationOnConstructionpage(String browserName) {
		pagefactory.setHOPolicyDataUpToConstructionPage().withWiringUpgradeYear().goNext().isElectricalWiringUpGradeMarkedWithError().shouldBeEqual("Wiring upgrade year field is not marked with error when upgrade year value is before Construction date");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Payment Method - Credit Card
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Keep defaults
					8. Click on ""Buy Base Policy"".
					9. Is the Billing Address the same as the above address? - Yes
					10. Provide a Phone number.
					11. Click Next.
					12. Choose a payment plan eg "Monthly 10".
					13. Payment Method: Credit Card
					14. Card Issuer: American Express
					15. Provide payment details. Credit Card Number, Expiration Date.
					16. Click on Purchase
					17. Login to PC and verify data is correct and valid.
					18. Verify submission status
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded, Base tab is selected, Monthly is selected by default.
					7. Pay in Full is selected.
					8. The policy Info page is loaded.
					9. Yes is selected.
					10. Phone number should be populated.
					11. Policy info page is selected.
					12. Monthly 10 plan should be selected. 
					13. Credit Card is selected.
					14. American Express is selected
					15. Payment details form should be fill in correctly without validation messages.
					16. Confirmation page is displayed.
					17. All data entered during the submission process should be in the PC as you entered it in the portal.
					18. The Submission will be complete and there will be a policy number assigned.
	@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC5001 @ Verify Payment Method - Credit Card")
	public void testBasicQuotePurchaseWithCreditCard(String browserName) throws Exception {
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocTypeValue", "prot");
		}
		else {
			ThreadLocalObject.getData().put("LocTypeValue", "city");
		}
		ThreadLocalObject.getData().put("DistanceToFireHydrantValue", "250");
		PaymentDetailsPage paymentDetailsPage = pagefactory.setHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.payMonthlyPremiumWithCreditCard().purchasePolicy().validateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber)
		.shouldBeTrue("Policy details are not matched with backend when purchanged using ");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Payment Method - Bank Account - Savings
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Keep defaults
					8. Click on "Buy Base Policy".
					9. Is the Billing Address the same as the above address? - Yes
					10. Provide a Phone number.
					11. Click Next.
					12. Choose a payment plan eg "Monthly 10".
					13. Payment Method: Bank Account
					14. Account Type : Saving
					15. Provide payment details. Account Number, Routing, Bank Name.
					16. Click on Purchase
					17. Login to PC and verify data is correct and valid.
					18. Verify submission status
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded, Base tab is selected, Monthly is selected by default.
					7. Pay in Full is selected.
					8. The policy Info page is loaded.
					9. Yes is selected.
					10. Phone number should be populated.
					11. Policy info page is selected.
					12. Monthly 10 plan should be selected. 
					13. Bank Account is selected.
					14. Account Type Saving is selected.
					15. Payment details form should be fill in correctly without validation messages.
					16. Confirmation page is displayed.
					17. All data entered during the submission process should be in the PC as you entered it in the portal.
					18. The Submission will be complete and there will be a policy number assigned.
	@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE" }, description = "TC5000 @ Verify Payment Method - Bank Account - Savings")
	public void testBasicQuotePurchaseWithSavingBankAccount(String browserName) throws Exception {
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocTypeValue", "prot");
		}
		else {
			ThreadLocalObject.getData().put("LocTypeValue", "city");
		}
		ThreadLocalObject.getData().put("DistanceToFireHydrantValue", "250");
		PaymentDetailsPage paymentDetailsPage = pagefactory.setHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.payMonthlyPremiumWithSavingsBankAccount().purchasePolicy()
				.validateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber)
				.shouldBeTrue("Policy details are not matched with backend");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Payment Method - Bank Account - Checking
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Keep defaults
					8. Click on "Buy Base Policy".
					9. Is the Billing Address the same as the above address? - Yes
					10. Provide a Phone number.
					11. Click Next.
					12. Choose a payment plan eg "Monthly 10".
					13. Payment Method: Bank Account
					14. Account Type : Checking 
					15. Provide payment details. Account Number, Routing, Bank Name.
					16. Click on Purchase
					17. Login to PC and verify data is correct and valid.
					18. Verify submission status"
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded, Base tab is selected, Monthly is selected by default.
					7. Pay in Full is selected.
					8. The policy Info page is loaded.
					9. Yes is selected.
					10. Phone number should be populated.
					11. Policy info page is selected.
					12. Monthly 10 plan should be selected. 
					13. Bank Account is selected.
					14. Account Type Checking is selected.
					15. Payment details form should be fill in correctly without validation messages.
					16. Confirmation page is displayed.
					17. All data entered during the submission process should be in the PC as you entered it in the portal.
					18. The Submission will be complete and there will be a policy number assigned."
	@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE_EMR" }, description = "TC4999 @ Verify Payment Method - Bank Account - Checking")
	public void testBasicQuotePurchaseWithCheckingBankAccount(String browserName) throws Exception {
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocTypeValue", "prot");
		}
		else {
			ThreadLocalObject.getData().put("LocTypeValue", "city");
		}
		ThreadLocalObject.getData().put("DistanceToFireHydrantValue", "250");
		PaymentDetailsPage paymentDetailsPage = pagefactory.setHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.payMonthlyPremiumWithCheckingBankAccount().purchasePolicy()
				.validateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber)
				.shouldBeTrue("Policy details are not matched with backend");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Pay In Full payment plan
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Select "Pay In Full"
					8. Click on "Buy Base Policy".
					9. Provide a phone number.
					10. Click Next on Policy Info.
					11. Provide payment details. Payment Method, Account Type, Account Number, Routing, Bank Name.
					12. Click on Purchase.
					13. Login to PC and search for the policy number.
					14. Verify submission status
					15. Click on Billing under the Tools header.
					16. Verify Payment Plan.
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded, Base tab is selected, Monthly is selected by default.
					7. Pay in Full is selected.
					8. The policy Info page is loaded.
					9. Phone is populated.
					10. Payment Details page is loaded. "F Annual 100% Down, 0 Max installments" should be the payment plan, which is a one off payment plan.
					11. Payment details form should be filled in correctly without validation messages.
					12. "Processing Payment" is displayed. Confirmation page appears with all the details including the policy number.
					13. The policy should be loaded, All data entered during the submission process should be in the PC as you entered it in the portal.
					14. The Submission will be complete and "In Force".
					15. Billing page is displayed
					16. Payment plan is also set to "F Annual 100% Down, 0 Max installments".
	 * @throws Exception 
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4992 @ Pay In Full payment plan", enabled = false)
	public void validatePayInFullPlanName(String browserName) throws Exception {
			PaymentDetailsPage paymentDetailsPage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithAnnualPremium().goToPolicyInfoPage().setPolicyInfoPageDetails().goToPaymentDetailsPage();
			paymentDetailsPage.isPolicyPlanNameEqualTo().shouldBeEqual("Payment Plan Name is not Correct");
			String refereNumber = new QuoteInfoBar().getSubmissionNumber();
			PolicyConfirmationPage confirmationPage = paymentDetailsPage	.payAnnualPremiumWithCheckingBankAccount().purchasePolicy();
			String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
			confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
			confirmationPage.validateHOPolicySummaryDetails(jsonData).shouldBeTrue("Policy details are not matched with backend");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Retrieve a Quote
	 * 
	              Expected :
	             		1. Complete the landing page
						2. Complete Your Info page
						3. Complete Qualification page
						4. Complete the Your Home page.
						5. Complete the Construction page.
						6. Note the Submission number and Click Cancel
						7. Click Yes on Cancel Submission confirmation
						8. Retrieve a Quote - Enter the ZIP and submission number and click on Go!

	             Actual :
	           			1. The Your Information page is loaded.
						2. The Qualification page is loaded.
						3. The Your Home page is loaded.
						4. The construction page is loaded.
						5. The discount page is loaded.
						6. Cancel Submission popup appears.
						7. User is returned to the landing page.
						8. You should be returned to the Discount page and data previously entered should be saved.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE" }, description = "TC4975 @ Retrieve a Quote")
	public void testHOQuoteRetrival(String browserName) {
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocType", "In Protected Suburb");
		} else {
			ThreadLocalObject.getData().put("LocType", "In protected suburb");
		}
		pagefactory.setHOPolicyDataUpToConstructionPageWithUpgradeYear().goToDiscountPage();
		String refeNumber = new QuoteInfoBar().getSubmissionNumber();
		new DiscountPage().pressCancelAndConfirm();
		new ZipCodePage().isZipCodePageOpened().shouldBeTrue("Zip Code page is not opened");
		pagefactory.getZipCodePage().openRetriveQuotePage().setQuoteRetrivalDetails(refeNumber).retriveQuote();
		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		new DiscountPage().isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		leftNavigationMenuHandler.gotoConstructionPage();
		new Modal().confirm();
		new ConstructionPage().areConstructionPageDetailsSaved().shouldBeTrue("Construction page details are not saved");
		leftNavigationMenuHandler.gotoYourHomePage().areYourHomePageFieldsValuesAreSaved().shouldBeTrue("Your Home page details are not saved");
		leftNavigationMenuHandler.gotoQualificationPage().areHOQualificationAnswersSaved().shouldBeTrue("Qualification page details are not saved");
		leftNavigationMenuHandler.gotoYourInfoPage().areYourInfoPageDetailsSaved().shouldBeTrue("Your Info page details are not saved");

	}

	
	
}
