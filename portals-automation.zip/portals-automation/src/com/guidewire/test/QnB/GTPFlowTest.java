package com.guidewire.test.QnB;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;


/**
 * Created by dfedo on 07/06/2017.
 */
public class GTPFlowTest {
    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" },enabled = false, description = "TC2855 GTP: Commercial - Businessowners")
    public void testGTPCommercialBusinessowners(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .clickGetQuoteButton();
        new YourInfoPage().isYourInfoPageLoaded().shouldBeTrue("Quote wizard was not opened");
        new YourInfoPage().validateGTPRedirectionComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC2858 GTP: Commercial - Populated Form")
    public void testGTPAddressPopulatedForm(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        getToBusinessModelOptions()
                .validateAddressOnSummaryForm();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC2859 GTP: Address Section - Empty Form")
    public void testGTPAddressEmptyForm(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Police Protectio");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "Empty Form, Test, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        pagefactory.getZipCodePage()
                .goToBusinessTab()
                .goToGuidanceProductPage()
                .typeWhatBusinessAreYouIn()
                .clickContinueButton()
                .clickMyAddressIsntInTheListLink()
                .fillAddressMandatoryFieldsInAddressForm()
                .clickBackToSearchLink()
                .clickMyAddressIsntInTheListLink()
                .clickContinueButton()
                .validateAddressOnSummaryForm();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" },enabled = false, description = "TC2860 GTP: Questions on business - Commercial Auto")
    public void testGTPQuestionsOnBusinessCommercialAuto(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Van or Truck");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" },enabled = false, description = "TC2861 GTP: Questions on business - Businessowners")
    public void testGTPQuestionsOnBusinessBusinessowners(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection()
                .clickGetQuoteButton();
        new YourInfoPage().isYourInfoPageLoaded().shouldBeTrue("Quote wizard was not opened");
        new YourInfoPage().validateGTPRedirectionComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" },enabled = false, description = "TC2862 GTP: Questions on business - Workers Compensation")
    public void testGTPQuestionsOnBusinessWorkersCompensation(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5029 GTP: Retail - Workers Compensation")
    public void testGTPRetailWorkersCompensation(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "FURNITURE AND HOUSEHOLD GOODS-RETAI");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5028 GTP: Retail - Commercial Auto")
    public void testGTPRetailCommercialAuto(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Boat Dealer");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Van or Truck");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5043 GTP: Retail - Questions")
    public void testGTPConstructionRetail(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "FURNITURE AND HOUSEHOLD GOODS-RETAI");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        getToBusinessModelOptions()
                .isContinueButtonDisabled().shouldBeEqual("Continue button is not disabled.");
        new GuidanceProductPage().validateAllFurnitureBusinessLines();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5041 GTP: Construction - Questions")
    public void testGTPConstructionQuestions(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        getToBusinessModelOptions()
                .isContinueButtonDisabled().shouldBeEqual("Continue button is not disabled.");
        new GuidanceProductPage().validateAllPlumbingBusinessLines();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5036 GTP: Construction - Commercial Auto")
    public void testConstructionCommercialAuto(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Van or Truck");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5037 GTP: Construction - Workers Compensation")
    public void testConstructionWorkersCompensation(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5042 GTP: Services - Questions")
    public void testGTPServicesQuestions(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Recreational Vehicle Parks and Campground");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        getToBusinessModelOptions()
                .isContinueButtonDisabled().shouldBeEqual("Continue button is not disabled.");
        new GuidanceProductPage().validateAllRecreationalServiceLines();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5033 GTP: Workers Compensation")
    public void testGTPServicesWorkersCompensation(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Recreational Vehicle Parks and Campground");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5034 GTP: Services - Everything")
    public void testGTPServicesEverything(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Recreational Vehicle Parks and Campground");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkAllBusinessModelCheckboxes()
                .clickContinueButton()
                .validateBusinessModelIcons("Services")
                .validateAllBusinessModelSummaryBlocks(false);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5045 GTP: Other - Questions")
    public void testGTPOtherQuestions(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Police Protectio");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        getToBusinessModelOptions()
                .isContinueButtonDisabled().shouldBeEqual("Continue button is not disabled.");
        new GuidanceProductPage().validateAllPoliceProtectionLines();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5047 GTP: Other - Commercial Auto")
    public void testGTPOtherCommercialAuto(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Iron Ore");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Van or Truck");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5048 GTP: Other - Workers Compensation")
    public void testGTPOtherWorkersCompensation(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Iron Ore");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("STATE_EXPECTED","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Employees");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .validateProductOfferingSection();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6107 GTP: Your Info Prefilled - Businessowners")
    public void testYourInfoPrefilledBusinessowners(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .clickGetQuoteButton();
        new YourInfoPage().isYourInfoPageLoaded().shouldBeTrue("Quote wizard was not opened");
        new YourInfoPage().validatePrefilledDataFrom();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6108 GTP: Edit Address From Summary")
    public void testEditAddressFromSummary(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickEditAddressButton()
                .clickMyAddressIsntInTheListLink()
                .fillAddressMandatoryFieldsInAddressForm("Guidance","To","Product","Testing","90102")
                .clickContinueButton()
                .validateEditedAddressOnSummaryForm("Guidance","To","Product","Testing","CA","90102");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6114 GTP: Other - Businessowners Flow")
    public void testOtherBusinessownersFlow(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Police Protectio");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Provide a Service");

        getToQuote();
        String policyNumber = new Pagefactory().setDataTillBOPPaymentDetailPageAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6113 GTP: Services - Businessowners Flow")
    public void testServicesBusinessownersFlow(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Recreational Vehicle Parks and Campground");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Equipment");

        getToQuote();
        String policyNumber = new Pagefactory().setDataTillBOPPaymentDetailPageAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6112 GTP: Retail - Businessowners Flow")
    public void testRetailBusinessownersFlow(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "FURNITURE AND HOUSEHOLD GOODS-RETAI");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Contents");

        getToQuote();
        String policyNumber = new Pagefactory().setDataTillBOPPaymentDetailPageAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6111 GTP: Construction - Businessowners Flow")
    public void testConstructionBusinessownersFlow(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Plumbing, Heating and air-conditionin");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");

        getToQuote();
        String policyNumber = new Pagefactory().setDataTillBOPPaymentDetailPageAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6160 GTP: Your Info Advanced Prefill - Businessowners")
    public void testYourInfoAdvancedPrefillBusinessowners(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Carpentry Wor");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        ThreadLocalObject.getData().put("State","California");
        ThreadLocalObject.getData().put("BUSINESS_MODEL", "Business Property");
        pagefactory.getZipCodePage()
                .goToBusinessTab()
                .goToGuidanceProductPage()
                .typeWhatBusinessAreYouIn()
                .clickContinueButton()
                .clickMyAddressIsntInTheListLink()
                .fillAddressMandatoryFieldsInAddressForm("AL1","AL2","AL3","Testing","90102")
                .clickContinueButton()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .clickGetQuoteButton();
        new YourInfoPage().isYourInfoPageLoaded().shouldBeTrue("Quote wizard was not opened");
        new YourInfoPage().validatePrefilledDataFrom("AL1","AL2","AL3","Testing","90102");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5050 GTP: Other - Everything")
    public void testOtherEverything(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Police Protectio");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        getToBusinessModelOptions()
                .checkAllBusinessModelCheckboxes()
                .clickContinueButton()
                .validateBusinessModelIcons("Other")
                .validateAllBusinessModelSummaryBlocks(true);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5030 GTP: Retail - Everything")
    public void testGTPRetailEverything(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Boat Dealer");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        getToBusinessModelOptions()
                .checkAllBusinessModelCheckboxes()
                .clickContinueButton()
                .validateBusinessModelIcons("Retail")
                .validateAllBusinessModelSummaryBlocks(true);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5038 GTP: Construction - Everything")
    public void testGTPConstructionEverything(String browserName) {
        ThreadLocalObject.getData().put("BUSINESS_DESCRIPTION", "Carpentry Wor");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS", "1001 E Hillsdale Blvd #800");
        ThreadLocalObject.getData().put("BUSINESS_ADDRESS_EXPECTED", "1001 E Hillsdale Blvd #800, Foster City, CA, 94404");
        getToBusinessModelOptions()
                .checkAllBusinessModelCheckboxes()
                .clickContinueButton()
                .validateBusinessModelIcons("Construction")
                .validateAllBusinessModelSummaryBlocks(true);
    }

    private GuidanceProductPage getToBusinessModelOptions(){
        return pagefactory.getZipCodePage()
                .goToBusinessTab()
                .goToGuidanceProductPage()
                .typeWhatBusinessAreYouIn()
                .clickContinueButton()
                .typeBusinessAddress()
                .clickContinueButton();
    }

    private void getToQuote(){
        getToBusinessModelOptions()
                .checkBusinessModelCheckbox()
                .clickContinueButton()
                .clickGetQuoteButton();
    }
}
