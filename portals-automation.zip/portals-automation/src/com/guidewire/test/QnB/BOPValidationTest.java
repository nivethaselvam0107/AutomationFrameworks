package com.guidewire.test.QnB;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;


public class BOPValidationTest {


    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3318 BOP - Verify invalid ZIP code for BOP on landing page")
    public void testInvalidZipCodeBOPPolicy(String browserName) {
        pagefactory.getZipCodePage().goToBusinessTab().setZipCodePageDetails().goNext().isZipCodeFieldMakedWithInvalidZipError()
                .shouldBeTrue("Zip Code message is not matched");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC1977 BOP - Your Info Mandatory Validation")
    public void testBOPYourInfoPageMandatoryField(String browserName) {
        YourInfoPage infoPage = pagefactory.getZipCodePage().goToBusinessTab().setZipCodePageDetails().goToYourInfoPage();
        infoPage.goNext().areYourPageFieldsMakedWithMandatoryError()
                .shouldBeTrue("Your Info Page fields are not marked with error message");
        infoPage.areYourPageFieldsMakedWithAsterisk().shouldBeTrue();
    }
    
  //DE4763
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "TC4240: BOP Policy Info Page Validation-Mandatory Fields")
    public void testBOPPolicyInfoMandatoryFields(String browserName) throws Exception {
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();

        pagefactory.getCPBOPPolicyInfoPage();

        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();

        cpbopPolicyInfoPage.setPhoneField("").setEmailField("").setBillingAddress().clickNext();

        cpbopPolicyInfoPage.isPhoneFieldMarkedWithError().shouldBeEqual("Phone number field not marked with error properly");
        cpbopPolicyInfoPage.isEmailFieldMarkedWithError().shouldBeEqual("Email field not marked with error properly");


    }
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "TC5023:BOP No building for second location validation", enabled=false)
    public void testNoBuildingForSecondLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isBuildingAdded().shouldBeTrue("Building not added");

        buildingsAndLocationsPage
        .getNewLocationForm()
                .setLocationData(false)
                .saveBOPLocation();

        buildingsAndLocationsPage.isLocationPresent().shouldBeTrue("Location not added properly");

        buildingsAndLocationsPage
        .clickNext();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isNoBuildingPopUpDisplayed().shouldBeEqual("No Building added to a location error pop up not displayed");
        alertHandler.isNoBuildingAddedErrorEqualsTo().shouldBeEqual("Alert message did not match");

    }
}
