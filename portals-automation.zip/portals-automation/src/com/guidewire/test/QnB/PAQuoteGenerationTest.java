package com.guidewire.test.QnB;

import java.util.Map;

import com.guidewire.common.util.PropertiesReader;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

public class PAQuoteGenerationTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify < 25 year old can not be quoted
	 
	             Actual :- 
	        			1. Complete the landing page
					2. Enter all the required fields - Attempt to enter a DOB within the last 25 years. Click on Next.
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. Click Ok on the message
					7. Login to PC and search for the reference number and step through the quote process.
	 
	            Expected :- 
		            1. ZIP code is populated. 
		            2. The car icon is highlighted. 
		            3. The Vehicle Your Information page is loaded.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "TC5660 @ Verify < 25 year old can not be quoted" )
	public void testQuoteGenerationWithDriverUnder25(String browserName) throws Exception {
		ThreadLocalObject.getData().put("DOB", DateUtil.getPastDateUsingYear(-20));
		PAQuotePage paQuotePage = pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		paQuotePage.buyPremiumPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage()
			.setPhoneNumber()
			.goToPaymentDetailsPage()
			.payMonthlyPremiumWithSavingsBankAccount()
			.goNext();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isCanNotPurchaseQuoteAlertDisplayed().shouldBeTrue("Can Not Purchase quote alert pop up is not displayed");
		alertHandler.validateCanNotPurchaseQuotePopUpContent().shouldBeEqual("Alert Message is not matched");
		ContactUsPage contactUsPage = alertHandler.closeAlert();
		contactUsPage.isContactPageDisplayed().shouldBeTrue("Contact Us Page is not displayed");
		contactUsPage.validateContactPageError().shouldBeTrue("Error mesage is not matched");
		Map<String, String> uwIssues = ParseQuoteData.getQuoteUWIssuesDataFromBackEnd(DataFetch.getQuoteUWIssues(contactUsPage.getQuoteReferenceNumber()));
		new Validation(uwIssues.containsKey("Primary Driver under 25")).shouldBeTrue("Blocking Bind - Primary Driver under 25 UW issue is not present in the list");
		new Validation(uwIssues.containsKey("Driver under 25")).shouldBeTrue("Informational UW - Driver under 25 UW issue is not present in the list");
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify UW issue if driver has coverage declined	
	 
	             Actual :- 
	        			1. Complete the Landing page
					2. Complete the Your Info page
					3. Qualification page - Answer ""Not Known"" to Are you currently insured?
					4. Answer ""Yes"" to ""Has any policy or coverage been declined, canceled, or non-renewed during the prior 3 years?"" and click Next.
					5. Complete the Drivers page
					6. Complete Vehicles Page.
					7. Click Ok on the message.
					8. Login to PC and search for the reference number and step through the quote process.
	 
	            Expected :- 
		           1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. No Update.
					4. The drivers page is loaded.
					5. The vehicles page is loaded.
					6. The Quote page is loaded informing user ""Sorry, based on the data entered this quote cannot be completed online. Please click the ok button for details on continuing the quote with one of our agents.
					6. User is provided with reference number.
					7. When you get to the Risk Analysis page on within PC, you will be notified of underwriting issue, "Policy has been declined, canceled, or non-renewed during the prior 3 years"
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "QB-PA-015 @ Verify UW issue if driver has coverage declined" )
	public void testQuoteDriverCoverageDeclined(String browserName) throws Exception {
		PAQuotePage paQuotePage = pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		paQuotePage.buyPremiumPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage()
			.setPhoneNumber()
			.goToPaymentDetailsPage()
			.payMonthlyPremiumWithSavingsBankAccount()
			.goNext();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isCanNotPurchaseQuoteAlertDisplayed().shouldBeTrue("Can Not Purchase quote alert pop up is not displayed");
		alertHandler.validateCanNotPurchaseQuotePopUpContent().shouldBeEqual("Alert Message is not matched");
		ContactUsPage contactUsPage = alertHandler.closeAlert();
		contactUsPage.isContactPageDisplayed().shouldBeTrue("Contact Us Page is not displayed");
		contactUsPage.validateContactPageError().shouldBeTrue("Error mesage is not matched");
		Map<String, String> uwIssues = ParseQuoteData.getQuoteUWIssuesDataFromBackEnd(DataFetch.getQuoteUWIssues(contactUsPage.getQuoteReferenceNumber()));
		new Validation(uwIssues.containsKey("Policy has been declined, canceled, or non-renewed during the prior 3 years")).shouldBeTrue("Policy has been declined, canceled, or non-renewed during the prior 3 years UW issue is not present in the list");
	}
	
	//TODO for annual payment
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify user can continue a Draft submission using the submission number
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. Note the ""Auto Insurance Quote"" number in the header. Now click on Quote & Buy Portal link.
					7. Fill in the zip code, click on the car symbol and enter the Quote number in the Quote testbox and click go!
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The landing page is loaded again.
					7. The user will be returned to the page where they left off i.e. the Quote page and all details will be saved from the previous sesssion.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" } , description = "QB-PA-023 @ Verify user can continue a Draft submission using the submission number")
	public void testUserCanContinueWithDraftQuote(String browserName) {
		pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage().setVehicleDetails()
				.goToPAQuotePage();
		
		String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.goToLandingPage();		
		alertHandler.isCancelSubmissionPopUpDisplayed().shouldBeEqual("Cancel Submission Alert pop up is not displayed");
		alertHandler.validateCancelQuoteSubmissionPopUpContent().shouldBeEqual("Alert Message is not matched");
		ZipCodePage page = alertHandler.closeAlertOnly();
		page.openRetriveQuotePage().setQuoteRetrivalDetails(refereNumber).retriveQuote();
		new QuoteInfoBar().hideQuoteRefSection();
		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		leftNavigationMenuHandler.gotoVehiclePage().areVehiclesDetailsSaved().shouldBeTrue("Vehicle details are not matched");
		leftNavigationMenuHandler.gotoDriverPage().areDriverDetailsSaved().shouldBeTrue("Driver details are not saved");
		leftNavigationMenuHandler.gotoQualificationPage().arePAQualificationAnswersSaved().shouldBeTrue("Qualification answers are not saved");
		leftNavigationMenuHandler.gotoYourInfoPage().areYourInfoPageDetailsSaved().shouldBeTrue("Your Infor Page details are saved");
		
		pagefactory.getYourInfoPage().withCoverage(DateUtil.getPastDateUsingYear(0)).goToQualificationPage().goToDriverDetailsPage().goToVehicleDetailsPage().goToPAQuotePage().buyStandardPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
		.purchasePolicy().isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation is not displayed");
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify vehicle value > 100,000 is not quotable
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page
					5. Vehicles page is loaded. Fill in all the required fields - VIN, Make, Model, Year, License Plate, State.
					6. Enter Cost new as 100001.
					7. Click No - Note the quote number in the top header.
					8. Login to PC and search for the Quote number that was generated above.
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Vehicles page is loaded.
					5. The fields should be successfully populated.
					6. Field is populated successfully without validation messages.
					7. Pop up message - ""Calculating Quote"" will appear.
					8. On the Risk Analysis page under blocking bind - High-value vehicle.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5661 @ Verify vehicle value <= 100,000 is not quotable" )
	public void testQuoteGenerationWithVehicleCostOver100K(String browserName) throws Exception {
		ThreadLocalObject.getData().put("VehicleCost", "100001");
		PAQuotePage paQuotePage = pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		paQuotePage.buyPremiumPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage()
			.setPhoneNumber()
			.goToPaymentDetailsPage()
			.payMonthlyPremiumWithSavingsBankAccount()
			.goNext();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isCanNotPurchaseQuoteAlertDisplayed().shouldBeTrue("Can Not Purchase quote alert pop up is not displayed");
		alertHandler.validateCanNotPurchaseQuotePopUpContent().shouldBeEqual("Alert Message is not matched");
		ContactUsPage contactUsPage = alertHandler.closeAlert();
		contactUsPage.isContactPageDisplayed().shouldBeTrue("Contact Us Page is not displayed");
		contactUsPage.validateContactPageError().shouldBeTrue("Error mesage is not matched");
		Map<String, String> uwIssues = ParseQuoteData.getQuoteUWIssuesDataFromBackEnd(DataFetch.getQuoteUWIssues(contactUsPage.getQuoteReferenceNumber()));
		new Validation(uwIssues.containsKey("High-value vehicle")).shouldBeTrue("High-value vehicle UW issue is not present in the list");
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify vehicle value <= 100,000 is quotable
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page
					5. Vehicles page is loaded. Fill in all the required fields - VIN, Make, Model, Year, License Plate, State.
					6. Enter Cost new as 100000.
					7. Click No 
					8. Continue as normal
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Vehicles page is loaded.
					5. The fields should be successfully populated.
					6. Field is populated successfully without validation messages.
					7. Pop up message - ""Calculating Quote"" will appear and a quote in generated and the Quote page is succesfully loaded.
					8. The full quote process is concluded and the policy is created as normal."
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "SANITY_DIA"}, description = "TC5663 @ Verify vehicle value <= 100,000 is quotable")
	public void testQuoteGenerationWithVehicleCostUpto100K(String browserName) {
		PAQuotePage paQuotePage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage()
				.setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToDriverDetailsPage()
				.setPrimaryDriverDetails().goToVehicleDetailsPage().setVehicleDetails().withVehicleCost("100000")
				.goToPAQuotePage();
		paQuotePage.isQuotePageLoaded().shouldBeTrue("PA Quote is not generated for valid Vehicle cost");

		PolicyConfirmationPage confirmationPage = paQuotePage.buyStandardPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
				.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation is not displayed");
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Purchase Standard Premium
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click ""Buy Standard Policy"".
					7. On the Policy Information page provide a Phone Number if needed and Click Next.
					8. Verify page layout.
					9. Choose a payment plan eg ""Monthly 10"".
					10. Provide payment details. Payment Method, Account Type, Account Number, Routing, Bank Name.
					11. Click on Purchase
					12. Login to PC and verify data is correct and valid.
					13. Verify Policy Offering on policy summary page."
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details.
					7. The Payment Details page loads
					8. Monthly payment and total premium should be displayed. A table of payment plans should be displayed. Payment options section should also be present. There should be no payment plan choosen by default.
					9. Monthly 10 plan should be highlighted.
					10. Payment details form should be fill in correctly without validation messages.
					11. Confirmation page is displayed.
					12. All data entered during the submission process should be in the PC as you entered it in the portal.
					13. The offering is - Standard Program."
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE"}  , description = "TC5664 @ PA - Purchase Standard Premium")
	public void testStandardQuotePolicyPurchase(String browserName) throws Exception {
		PAQuotePage paQuotePage  = pagefactory.getZipCodePage().setZipCodePageDetails()
				.goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage()
				.setVehicleDetails().goToPAQuotePage();
				String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		
		PolicyConfirmationPage confirmationPage =	paQuotePage.buyStandardPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount()
				.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();
		confirmationPage.isPolicyOfferingNameEqualTo(DataConstant.STANDARD_PROGRAM, ParseQuoteData.getPolicyOfferingName(jsonData)).shouldBeEqual("Offering name is not correct");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Payment Method - Bank Account - Checkings
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click ""Buy Basic Policy"".
					7. On the Policy Information page Click Next.
					8. Verify page layout.
					9. Choose a payment plan eg ""Monthly 10"".
					10. Payment Method: Bank Account
					11. Account Type : Checking
					12. Provide payment details. Account Number, Routing, Bank Name.
					13. Click on Purchase
					14. Login to PC and verify data is correct and valid.
					15. Verify submission status"
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details.
					7. The Payment Details page loads
					8. Monthly payment and total premium should be displayed. A table of payment plans should be displayed. Payment options section should also be present. There should be no payment plan choosen by default.
					9. Monthly 10 plan should be highlighted.
					10. Bank Account is selected.
					11. Account Type Checking is selected.
					12. Payment details form should be fill in correctly without validation messages.
					13. Confirmation page is displayed.
					14. All data entered during the submission process should be in the PC as you entered it in the portal.
					15. The Submission will be complete and there will be a policy number assigned."
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }  , description = "TC5670 @ Verify Payment Method - Bank Account - Checkings")
	public void testPayByCheckingBankAccount(String browserName) throws Exception {
		PAQuotePage paQuotePage  = pagefactory.getZipCodePage().setZipCodePageDetails()
				.goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage()
				.setVehicleDetails().goToPAQuotePage();
				String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		PaymentDetailsPage paymentDetailsPage = paQuotePage.buyStandardPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount();
		paymentDetailsPage.isCheckingBankAccountSelected().shouldBeTrue("Checking bank account type is not selected.");
		PolicyConfirmationPage confirmationPage =	paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();
		confirmationPage.isPolicyNumberEqualTo(jsonData).shouldBeEqual("Policy number is not assigned to quote");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Purchase Premium Premium
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click ""Buy Premium Policy"".
					7. On the Policy Information page provide phone number and Click Next.
					8. Verify page layout.
					9. Choose a payment plan eg ""Monthly 10"".
					10. Provide payment details. Payment Method, Account Type, Account Number, Routing, Bank Name.
					11. Click on Purchase
					12. Login to PC and verify data is correct and valid.
					13. Verify Policy Offering on policy summary page"
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details.
					7. The Payment Details page loads
					8. Monthly payment and total premium should be displayed. A table of payment plans should be displayed. Payment options section should also be present. There should be no payment plan choosen by default.
					9. Monthly 10 plan should be highlighted.
					10. Payment details form should be fill in correctly without validation messages.
					11. Confirmation page is displayed.
					12. All data entered during the submission process should be in the PC as you entered it in the portal.
					13. The offering is - Premium Program..
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "SMOKE"}, description = "TC5665 @ PA - Purchase Premium Premium")
	public void testPremiumQuotePolicyPurchase(String browserName) throws Exception {
		PAQuotePage paQuotePage  = pagefactory.getZipCodePage().setZipCodePageDetails()
				.goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage()
				.setVehicleDetails().goToPAQuotePage();
				String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
				PolicyConfirmationPage confirmationPage =	paQuotePage.buyPremiumPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
				.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();
		confirmationPage.isPolicyOfferingNameEqualTo(DataConstant.PREMIUM_PROGRAM, ParseQuoteData.getPolicyOfferingName(jsonData)).shouldBeEqual("Offering name is not correct");
	}
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Payment Method - Bank Account - Savings
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click ""Buy Basic Policy"".
					7. On the Policy Information page Click Next.
					8. Verify page layout.
					9. Choose a payment plan eg ""Monthly 10"".
					10. Payment Method: Bank Account
					11. Account Type : Saving
					12. Provide payment details. Account Number, Routing, Bank Name.
					13. Click on Purchase
					14. Login to PC and verify data is correct and valid.
					15. Verify submission status
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details.
					7. The Payment Details page loads
					8. Monthly payment and total premium should be displayed. A table of payment plans should be displayed. Payment options section should also be present. There should be no payment plan choosen by default.
					9. Monthly 10 plan should be highlighted.
					10. Bank Account is selected.
					11. Account Type Saving is selected.
					12. Payment details form should be fill in correctly without validation messages.
					13. Confirmation page is displayed.
					14. All data entered during the submission process should be in the PC as you entered it in the portal.
					15. The Submission will be complete and there will be a policy number assigned.
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "SMOKE" }, description = "TC5671 @ Verify Payment Method - Bank Account - Savings")
	public void testPayBySavingBankAccount(String browserName) throws Exception {
		PAQuotePage paQuotePage  = pagefactory.getZipCodePage().setZipCodePageDetails()
				.goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage()
				.setVehicleDetails().goToPAQuotePage();
				String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
				PaymentDetailsPage paymentDetailsPage =	paQuotePage.buyPremiumPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount();
				paymentDetailsPage.isSavingBankAccountSelected().shouldBeTrue("Saving bank account type is not selected.");
		PolicyConfirmationPage confirmationPage =paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();
		confirmationPage.isPolicyNumberEqualTo(jsonData).shouldBeEqual("Policy number is not assigned to quote");
	}
	
/**@formatter:off
 * @param browserName
  
 		Test Description :- Verify Payment Method - Credit Card	
		
					Step actions :- 
						1. Complete the landing page
						2. Complete Your Info page
						3. Complete Qualification page
						4. Complete the Drivers page.
						5. Complete the vehicles page and click No.
						6. On quote page click ""Buy Basic Policy"".
						7. On the Policy Information page Click Next.
						8. Verify page layout.
						9. Choose a payment plan eg ""Monthly 10"".
						10. Payment Method: Credit Card
						11. Card Issuer : American Express
						12. Provide Credit Card Number and Expiration Date. 
						13. Click on Purchase
						14. Login to PC and verify data is correct and valid.
						15. Verify submission status"
					
					Expected Results :- 
						1. The Your Information page is loaded.
						2. The Qualification page is loaded.
						3. The Drivers page is loaded.
						4. The vehicles page is loaded.
						5. Quote page is loaded.
						6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details.
						7. The Payment Details page loads
						8. Monthly payment and total premium should be displayed. A table of payment plans should be displayed. Payment options section should also be present. There should be no payment plan choosen by default.
						9. Monthly 10 plan should be highlighted.
						10. Payment method should be Credit Card.
						11. Card Issuer should be American Express
						12. Details entered successfully
						13. Confirmation page is displayed.
						14. All data entered during the submission process should be in the PC as you entered it in the portal.
						15. The Submission will be complete and there will be a policy number assigned.""
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC5672 @ Verify Payment Method - Credit Card")
	public void testPolicyPurchaseWithCreditCard(String browserName) throws Exception {
		PAQuotePage paQuotePage  =  pagefactory.getZipCodePage().setZipCodePageDetails()
				.goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
				.goToDriverDetailsPage().setPrimaryDriverDetails().goToVehicleDetailsPage()
				.setVehicleDetails().goToPAQuotePage();
				String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
			PaymentDetailsPage paymentDetailsPage = paQuotePage.buyPremiumPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCreditCard();
			paymentDetailsPage.validateCardIssuerName().shouldBeEqual("Card issuer name is not correct");
				PolicyConfirmationPage confirmationPage =  paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();
		confirmationPage.isPolicyNumberEqualTo(jsonData).shouldBeEqual("Policy number is not assigned to quote");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8871 @ Verify Personalisation - landing page - lp1", enabled = false)
	public void testLandingPagePersonalisationLP1(String browserName) throws Exception {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("getting Personalised Landing Page Option 1");
        driver.get(PropertiesReader.getURL(ThreadLocalObject.getSuitenName()) + "/lp1");
		PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
		landingPage.verifyLandingPageOneElements();
        landingPage.clickGetStartedButton();
        testPolicyPurchaseWithCreditCard(browserName);
	}

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8872 @ Verify Personalisation - landing page - lp2", enabled = false)
    public void testLandingPagePersonalisationLP2(String browserName) throws Exception {
        WebDriver driver = ThreadLocalObject.getDriver();
        logger.info("getting Personalised Landing Page Option 2");
        driver.get(PropertiesReader.getURL(ThreadLocalObject.getSuitenName()) + "/lp2");
        PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
        landingPage.verifyLandingPageTwoElements();
        landingPage.clickGetStartedButton();
        testPolicyPurchaseWithCreditCard(browserName);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8869 @ Verify Personalisation - Campaign Codes - Promotion1")
    public void testLandingPagePersonalisationPromo1(String browserName) throws Exception {
        PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
        logger.info("Verifying Promotion option 1");
        landingPage.promoRedirect(1);
        landingPage.verifyLandingPageOneElements();
        landingPage.clickGetStartedButton();
        testPolicyPurchaseWithCreditCard(browserName);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8870 @ Verify Personalisation - Campaign Codes - Promotion2")
    public void testLandingPagePersonalisationPromo2(String browserName) throws Exception {
        PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
        logger.info("Verifying Promotion option 2");
        landingPage.promoRedirect(2);
        landingPage.verifyLandingPageTwoElements();
        landingPage.clickGetStartedButton();
        testPolicyPurchaseWithCreditCard(browserName);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8867 @ Verify Personalisation - Dynamic Branding - gateway-cobranded")
    public void testPersonalisationDynamicBrandingGateway(String browserName) throws Exception {
        PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
        logger.info("Verifying Dynamic Branding - gateway-cobranded");
        landingPage.dynamicBrandingRedirect("gateway-cobranded");
        landingPage.verifyDynamicBrandingGatewayElements();
        testPolicyPurchaseWithCreditCard(browserName);
    }

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC8866 @ Verify Personalisation - Dynamic Branding - millennials")
	public void testPersonalisationDynamicBrandingMillennials(String browserName) throws Exception {
		PersonalisedLandingPage landingPage = new PersonalisedLandingPage();
		logger.info("Verifying Dynamic Branding - millennials");
		landingPage.dynamicBrandingRedirect("millennials");
		landingPage.verifyDynamicBrandingMillennialsElements();
		testPolicyPurchaseWithCreditCard(browserName);
	}


}
