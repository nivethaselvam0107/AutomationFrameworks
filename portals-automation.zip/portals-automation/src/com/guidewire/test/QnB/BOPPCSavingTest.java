package com.guidewire.test.QnB;


import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class BOPPCSavingTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6159 BOP - Payment Details Saving Point - Credit Card")
    public void testBOPPaymentDetailsMandatoryFieldsCreditCard(String browserName) throws Exception {
        BOPPCSaving.testBOPPaymentDetailsMandatoryFieldsCreditCard(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6154 BOP - Payment Details Saving Point - Bank Account Saving")
    public void testBOPPaymentDetailsSavingPointBankAccountSaving(String browserName) throws Exception {
        BOPPCSaving.testBOPPaymentDetailsSavingPointBankAccountSaving(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5026 BOP - Payment Details Saving Point - Bank Account Checking")
    public void testBOPPaymentDetailsSavingPointBankAccountChecking(String browserName) throws Exception {
        BOPPCSaving.testBOPPaymentDetailsSavingPointBankAccountChecking(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5024 BOP - Quote Saving Point")
    public void testBOPQuoteSavingPoint(String browserName) throws Exception {
        BOPPCSaving.testBOPQuoteSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5025 BOP - Policy Info Saving Point")
    public void testBOPPolicyInfoSavingPoint(String browserName) throws Exception {
        BOPPCSaving.testBOPPolicyInfoSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4682 BOP - Remove Building")
    public void testBOPRemoveBuilding(String browserName) throws Exception {
        BOPPCSaving.testBOPRemoveBuilding(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4700 BOP - Add Building")
    public void testBOPAddBuilding(String browserName) throws Exception {
        BOPPCSaving.testBOPAddBuilding(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5021 BOP - Add Location")
    public void testBOPAddLocation(String browserName) throws Exception {
        BOPPCSaving.testBOPAddLocation(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5022 BOP - Remove Location")
    public void testBOPRemoveLocation(String browserName) throws Exception {
        BOPPCSaving.testBOPRemoveLocation(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4621 BOP - Your Info Page Saving Point")
    public void testBOPYourInfoPageSavingPoint(String browserName) throws Exception {
        BOPPCSaving.testBOPYourInfoPageSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4623 BOP - Qualification Page Saving Point")
    public void testBOPQualificationPageSavingPoint(String browserName) throws Exception {
        BOPPCSaving.testBOPQualificationPageSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(enabled = false, groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5979 BOP - Confirmation Saving Point")
    public void testBOPConfirmationSavingPoint(String browserName) throws Exception {
        // Validation for Coverages is missing, leaving this test case for now
        BOPPCSaving.testBOPConfirmationSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(enabled = false, groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4965 BOP - Additional Coverages Saving Point")
    public void testBOPAdditionalCoveragesSavingPoint(String browserName) throws Exception {
        // Could not automate due to sync issues
        BOPPCSaving.testBOPAdditionalCoveragesSavingPoint(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4927 BOP - General Coverages Saving Point")
    public void testBOPGeneralCoveragesSavingPoint(String browserName) throws Exception {
        BOPPCSaving.testBOPGeneralCoveragesSavingPoint(browserName);
    }

}

