package com.guidewire.test.QnB;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.ITestContext;
import org.testng.ITest;
import java.lang.reflect.Method;


public class INowHOQuoteGenerationTest {

	private static ThreadLocal<String> testNames = new ThreadLocal<String>();

	Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11109 @ Qualification Checks - Number of claims in last 3 years 2")
	public void testQuoteGenerationWithBusinessOnPremises(String browserName) throws Exception {
		pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded()
				.shouldBeTrue("Quote Generation With Number of claims 2 in last 3 years is not possible.");
		QuoteInfoBar.isiNowSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11151 @ No Discounts - Should still get a quote.")
	public void testQuoteGenerationWithNoDiscountPageData(String browserName) throws Exception {
		pagefactory.setiNowHOPolicyDataUpToDiscountPageWithNoDiscounts().shouldBeTrue("Quote Generation without additional Discounts is not possible.");
		QuoteInfoBar.isiNowSubmissionInQuotedStatus().shouldBeEqual("Submission is not in Quote Status when Quote is created without additional Discount data");
	}


	@Parameters("browserName")
	@Test(groups = { "REG_INOW" } , description = "Verify Payment Method - Credit Card")
	public void testBasicQuotePurchaseWithCreditCard(String browserName) throws Exception {
		PaymentDetailsPage paymentDetailsPage = pagefactory.setiNowHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.iNowPayMonthlyPremiumWithCreditCard().purchasePolicy().iNowValidateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber)
		.shouldBeTrue("Policy details are not matched with backend when purchanged using ");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "Verify Payment Method - Bank Account - Savings")
	public void testBasicQuotePurchaseWithSavingBankAccount(String browserName) throws Exception {
		PaymentDetailsPage paymentDetailsPage = pagefactory.setiNowHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.iNowPayMonthlyPremiumWithSavingsBankAccount().purchasePolicy()
				.iNowValidateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber)
				.shouldBeTrue("Policy details are not matched with backend");
	}


	@Test(dataProvider = "paymentPlans", groups = { "REG_INOW"}, description = "Verify Payment Method - Bank Account - Checking")
	public void testBasicQuotePurchaseWithCheckingBankAccount(String browserName, String paymentPlan) throws Exception {
		logger.info("Browser Name: " + browserName);
		logger.info("PaymentPlan Name: " + paymentPlan);
		PaymentDetailsPage paymentDetailsPage = pagefactory.setiNowHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment()
				.goToPaymentDetailsPage();
		String refereNumber = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage.iNowPayMonthlyPremiumWithCheckingBankAccount(paymentPlan).purchasePolicy()
				.iNowValidateHOConfirmationPageAndQuoteDataWithBackEnd(refereNumber, paymentPlan)
				.shouldBeTrue("Policy details are not matched with backend");
	}
	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11195 @ Pay In Full payment plan")
	public void validatePayInFullPlanName(String browserName) throws Exception {
			PaymentDetailsPage paymentDetailsPage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithAnnualPremium().goToPolicyInfoPage().setInowPolicyInfoPageDetails().goToPaymentDetailsPage();
			paymentDetailsPage.isINowPolicyPlanNameEqualTo().shouldBeEqual("Payment Plan Name is not Correct");
			String refereNumber = new QuoteInfoBar().getSubmissionNumber();
			PolicyConfirmationPage confirmationPage = paymentDetailsPage	.iNowPayAnnualPremiumWithCheckingBankAccount().purchasePolicy();
			//String jsonData = DataFetch.getiNowQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
			confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
			//confirmationPage.validateHOPolicySummaryDetails(jsonData).shouldBeTrue("Policy details are not matched with backend");
	}

	@DataProvider(name = "paymentPlans")
	public Object[][] provideData(Method m) {
		Object[][] plans = {
				{"chrome", "Direct Bill Pay In Full"},
				{"chrome", "Direct Bill 2 Payments"},
				{"chrome", "Direct Bill 4 Payments"},
				{"chrome", "Direct Bill 4 Payments With Down Payment"},
				{"chrome", "Direct Bill 12 Payments"},
				{"chrome", "Direct Bill 12 Payments Day Of Month"},
				{"chrome", "Automated Pay In Full"},
				{"chrome", "Automated 2 Payments"},
				{"chrome", "Automated 4 Payments"},
				{"chrome", "Automated 12 Payments"},
				{"chrome", "Agent Bill Pay In Full"},
				{"chrome", "Agent Bill 12 Payments"}
		};
		return plans;

	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11091 @ Retrieve a Quote at Discount page")
	public void testHOQuoteRetrival(String browserName) {
		pagefactory.setiNowHOPolicyDataUpToDiscountPage();
		String refeNumber = new QuoteInfoBar().getSubmissionNumber();
		new DiscountPage().pressCancelAndConfirm();
		new ZipCodePage().isHOOnlyZipCodePageOpened().shouldBeTrue("Zip Code page is not opened");
		pagefactory.getHoOnlyZipCodePage().openRetriveQuotePage().setQuoteRetrivalDetails(refeNumber).retriveQuote();
		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		new DiscountPage().isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW"}, description = "TC11091 @ Retrieve a Quote from Quote page")
	public void testHOQuoteRetrivalFromQuotePage(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage();
		hoQuotePage.isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		hoQuotePage.validateHOQuotePageLayout().shouldBeTrue();
		String refeNumber = new QuoteInfoBar().getSubmissionNumber();
		hoQuotePage.clickOnHeaderGWAndConfirmCancel();
		new ZipCodePage().isHOOnlyZipCodePageOpened().shouldBeTrue("Zip Code page is not opened");

		pagefactory.getHoOnlyZipCodePage().openRetriveQuotePage().setQuoteRetrivalDetails(refeNumber).retriveQuote();
		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		new HOQuotePage().isHOQuotePageLoaded().shouldBeTrue("Quote page loaded");
	}

}
