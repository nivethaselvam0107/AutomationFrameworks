package com.guidewire.test.QnB;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.portals.qnb.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

/**
 * Created by jkrawczyk-koca on 7/5/2017.
 */
public class BOPValidationCommon {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "GPA--585:BusinessownersLocations&BuildingsPageValidation-MandatoryFieldsAddBuilding" +
            ", TC3319: BOP Locations & Buildings Page Validation - Mandatory Fields Add Building ")
    public void testBOPAddBuildingMandatoryFields(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();
        String suite = ThreadLocalObject.getSuitenName();


       pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isPropClassCodeFieldMarkedWithError().shouldBeEqual("Error message is not marked correctly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "GPA--586:BusinessownersLocations&BuildingsPageValidation-MandatoryFieldsAddLocation," +
            "TC3320: BOP Locations & Buildings-Mandatory Fields Add Location")
    public void testBOPAddLocationMandatoryFields(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewLocationForm()
                .saveBOPLocation();
        buildingsAndLocationsPage.isAddressLine1MarkedWithError().shouldBeEqual("Address Line1 not marked with error properly");
        buildingsAndLocationsPage.isCityMarkedWithError().shouldBeEqual("City not marked with error properly");
        buildingsAndLocationsPage.isZipcodeMarkedWithError().shouldBeEqual("ZIP Code not marked with error properly");
        buildingsAndLocationsPage.isStateMarkedWithError().shouldBeEqual("State not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"  }, description = "GPA--595:BusinessownersPaymentDetailsPageValidation-BankAccountMandatoryFields," +
            "TC3321: BOP Payment Details - Bank Account Mandatory Fields")
    public void testBOPPaymentDetailsMandatoryFieldsBankAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPPolicyInfoPageAndGoNext();

        pagefactory.getPaymentDetails()
                .setPaymentMethod(data.get("PaymentMethodBank"))
                .clickNext();

        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.isAccountNumberMarkedWithError().shouldBeEqual("Account number field not marked with error properly");
        paymentDetailsPage.isRoutingNumberMarkedWithError().shouldBeEqual("Routing number field not marked with error properly");
        paymentDetailsPage.isBankNameMarkedWithError().shouldBeEqual("Bank Name field not marked with error properly");

    }
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "GPA--596:BusinessownersPaymentDetailsPageValidation-CreditCardMandatoryFields," +
            "TC3322: BOP Payment Details-Credit Card Mandatory Fields")
    public void testBOPPaymentDetailsMandatoryFieldsCreditCard(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();


        pagefactory.setDataTillBOPPolicyInfoPageAndGoNext();

        pagefactory.getPaymentDetails()
                .setPaymentMethod(data.get("PaymentMethodCredit"))
                .clickNext();

        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.isCreditCardNumberMarkedWithMandatoryError().shouldBeEqual("Credit card number field not marked with error properly");
        paymentDetailsPage.isExpirationDateMarkedWithError().shouldBeEqual("Expiration date field not marked with error properly");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "GPA--583:BusinessownersRemovePrimaryLocation," +
            "TC4229: BOP Remove Primary Location")
    public void testBOPRemovePrimaryLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage();

        buildingsAndLocationsPage.isRemoveIconAvailableForPrimaryLocation().shouldBeFalse("Remove icon is present");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA" }, description = "GPA--584:BusinessownersLocations&BuildingsPageValidation-NoBuildingAdded, GPA--672:BusinessownersLocations&BuildingsPageValidation-NoBuildingAdded," +
            "TC2848: Locations and Buildings - No buildings Mandatory Validation")
    public void testBOPNoBuildingValidation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPAddCvgAndGoNext();

        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isNoBuildingPopUpDisplayed().shouldBeEqual("No Building added to a location error pop up not displayed");
        alertHandler.isNoBuildingAddedErrorEqualsTo().shouldBeEqual("Alert message did not match");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "GPA--618:BusinessownersAddContractorToolsMandatoryFields," +
            "TC4232: BOP Add Contractor Tools Mandatory Fields")
    public void testBOPAddContractorToolSIMandatoryFields(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setBOPEntryPoint();

        pagefactory.setDataTillBOPQualAndGoNext();

        BOPGeneralCoveragesPage bopGeneralCoveragesPage = pagefactory
                .getBOPGenCoveragePage()
                .clickOnAddContractorTools()
                .clickOnAdd();

        bopGeneralCoveragesPage.isDescriptionMarkedWithError().shouldBeEqual("Description field not makred with error properly");
        bopGeneralCoveragesPage.isInsuredValueMarkedWithError().shouldBeEqual("Description field not makred with error properly");
    }

}
