package com.guidewire.test.QnB;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;

import java.util.Arrays;
import java.util.List;

public class GTCPAFlowTest{

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC4961 @ Reset Button for Standard Program - Pay in Full")
    public void testResetButtonForStandardProgramPayinFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(true);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(Double.parseDouble(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").replace("$", "")), Double.parseDouble(new PAQuotePage().getProgramPriceFromBackend(jsonData,true))).shouldBeEqual("Program Price doesn't equals to expected");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC4960 @ Reset Button for Premium Program - Pay in Full")
    public void testResetButtonForPremiumProgramPayinFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(true);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(Double.parseDouble(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").replace("$", "")), Double.parseDouble(new PAQuotePage().getProgramPriceFromBackend(jsonData,true))).shouldBeEqual("Program Price doesn't equals to expected");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC4959 @ Reset Button for Standard Program - Pay in Full")
    public void testResetButtonForBasicProgramPayinFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(true);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").contains(new PAQuotePage().getProgramPriceFromBackend(jsonData,true))).shouldBeTrue("Program Price doesn't equals to expected");
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6478 @ Reset Button for Standard Program - Monthly")
    public void testResetButtonForStandardProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(false);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").contains(new PAQuotePage().getProgramPriceFromBackend(jsonData,false))).shouldBeTrue("Program Price doesn't equals to expected");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6479 @ Reset Button for Premium Program - Monthly")
    public void testResetButtonForPremiumProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(false);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").contains(new PAQuotePage().getProgramPriceFromBackend(jsonData,false))).shouldBeTrue("Program Price doesn't equals to expected");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6484 @ Reset Button for Basic Program - Monthly")
    public void testResetButtonForBasicProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeAndResetCoverage(false);
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        paQuotePage.validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price is equal to expected");
        paQuotePage.validateStandardMexicoCoverageStatus(ThreadLocalObject.getData().get("MexicoCoverageChecked"));
        paQuotePage.clickRecalculateButton()
                .validateOfferingPrice(ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price is not equal to expected");
        jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("OfferingPrice").replace(",","").contains(new PAQuotePage().getProgramPriceFromBackend(jsonData,false))).shouldBeTrue("Program Price doesn't equals to expected");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4774 @ Quote Premium Update with Coverages Changes -Standard Program - Monthly")
    public void testQuotePremiumUpdateCoveragesChangesStandardProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = getToQuotePageChangeCoverage(false);
        ThreadLocalObject.getData().put("Program","Premium");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Standard");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6485 @ Quote Premium Update with Coverages Changes -Standard Program - Pay in Full")
    public void testQuotePremiumUpdateCoveragesChangesStandardProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = this.getToQuotePageChangeCoverage(true);
        ThreadLocalObject.getData().put("Program","Premium");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Standard");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6486 @ Quote Premium Update with Coverages Changes -Basic Program - Pay in Full")
    public void testQuotePremiumUpdateCoveragesChangesBasicProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        PAQuotePage paQuotePage  = getToQuotePageChangeCoverage(true);
        ThreadLocalObject.getData().put("Program","Premium");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Basic");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6488 @ Quote Premium Update with Coverages Changes -Premium Program - Pay in Full")
    public void testQuotePremiumUpdateCoveragesChangesPremiumProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = getToQuotePageChangeCoverage(true);
        ThreadLocalObject.getData().put("Program","Standard");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Premium");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6489 @ Quote Premium Update with Coverages Changes -Premium Program - Monthly")
    public void testQuotePremiumUpdateCoveragesChangesPremiumProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = getToQuotePageChangeCoverage(false);
        ThreadLocalObject.getData().put("Program","Standard");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Premium");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC6487 @ Quote Premium Update with Coverages Changes -Basic Program - Monthly")
    public void testQuotePremiumUpdateCoveragesChangesBasicProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePageChangeCoverage(false);
        ThreadLocalObject.getData().put("Program","Premium");
        paQuotePage.clickMexicoCoverageCheckbox();
        ThreadLocalObject.getData().put("Program","Basic");
        this.changeAndBuyProgramCoverageVerifyChanges();
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6162 @ Coverages Colorado State Dependencies for Premium Program - Monthly")
    public void testCoveragesColoradoStateDependenciesForPremiumProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("ZipCode","80001");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setUninsuredMotoristPropertyDamageDropdown("25,000")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/15");
        expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6476 @ Coverages Colorado State Dependencies for Premium Program - Pay in Full")
    public void testCoveragesColoradoStateDependenciesForPremiumProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("City","Arvada");
        ThreadLocalObject.getData().put("ZipCode","80001");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();
        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setUninsuredMotoristPropertyDamageDropdown("25,000")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/15");
        expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC5544 @ Coverages Colorado State Dependencies for Basic Program - Pay in Full")
    public void testCoveragesColoradoStateDependenciesForBasicProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("ZipCode","80001");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();

        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/25");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6475 @ Coverages Colorado State Dependencies for Basic Program - Monthly")
    public void testCoveragesColoradoStateDependenciesForBasicProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("ZipCode","80001");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/25");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6161 @ Coverages Colorado State Dependencies for Standard Program - Pay in Full")
    public void testCoveragesColoradoStateDependenciesForStandardProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("ZipCode","80001");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();

        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setUninsuredMotoristPropertyDamageDropdown("25,000")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/15");
        expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6472 @ Coverages Colorado State Dependencies for Standard Program - Monthly")
    public void testCoveragesColoradoStateDependenciesForStandardProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        ThreadLocalObject.getData().put("State","Colorado");
        ThreadLocalObject.getData().put("ZipCode","80001");
        ThreadLocalObject.getData().put("City","Arvada");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.clickUninsuredMotoristPropertyDamageCheckbox();
        List<String> expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setUninsuredMotoristPropertyDamageDropdown("25,000")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL");
        expected_values = Arrays.asList("Please Select", "15,000", "25,000","50,000","100,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values)
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("25/50/15");
        expected_values = Arrays.asList("Please Select", "15,000");
        paQuotePage.validateUninsuredMotoristPropertyDamageDropdownValues(expected_values);
    }



    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4963 @ Coverages Dependencies for Standard Program - Pay in Full")
    public void testCoveragesDependenciesStandardProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();

        paQuotePage.setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6474 @ Coverages Dependencies for Standard Program - Monthly")
    public void testCoveragesDependenciesStandardProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Standard");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4962 @ Coverages Dependencies for Premium Program - Pay in Full")
    public void testCoveragesDependenciesPremiumProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();

        paQuotePage.setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6477 @ Coverages Dependencies for Premium Program - Monthly")
    public void testCoveragesDependenciesPremiumProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Premium");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC6473 @ Coverages Dependencies for Basic Program - Monthly")
    public void testCoveragesDependenciesBasicProgramMonthly(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = getToQuotePage();

        paQuotePage.setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4773 @ Coverages Dependencies for Basic Program - Pay in Full")
    public void testCoveragesDependenciesBasicProgramPayFull(String browserName) throws Exception {
        ThreadLocalObject.getData().put("Program","Basic");
        PAQuotePage paQuotePage  = getToQuotePage().clickPayInFullTab();

        paQuotePage.setValueToLiabilityBodilyInjuryAndPropertyDamage("1M CSL")
                .setUninsuredMotoristBodilyInjuryDropdown("30/60")
                .setValueToLiabilityBodilyInjuryAndPropertyDamage("15/30/5");
        List<String> expected_values =  Arrays.asList("Please Select", "15/30");
        paQuotePage.validateUninsuredMotoristBodilyInjuryDropdownValues(expected_values);
    }


    private PAQuotePage getToQuotePageChangeAndResetCoverage(Boolean withPayFull){
        PAQuotePage paQuotePage = this.getToQuotePage();
        if (withPayFull){
            paQuotePage.clickPayInFullTab();
        }
        paQuotePage.getOfferingPrice()
                .isStandardMexicoCoverageChecked()
                .clickMexicoCoverageCheckbox()
                .clickResetCoverages();
        return paQuotePage;
    }

    private PAQuotePage getToQuotePage(){
        return pagefactory.getZipCodePage().setZipCodePageDetails()
                .goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails()
                .goToDriverDetailsPage().setPrimaryDriverDetails().setLIcenseState(ThreadLocalObject.getData().get("State")).goToVehicleDetailsPage()
                .setVehicleDetails().goToPAQuotePage();
    }

    private PAQuotePage getToQuotePageChangeCoverage(Boolean withPayFull){
        PAQuotePage paQuotePage = this.getToQuotePage();
        if (withPayFull){
            paQuotePage.clickPayInFullTab();
        }
        paQuotePage.clickMexicoCoverageCheckbox();
        return paQuotePage;
    }

    private void changeAndBuyProgramCoverageVerifyChanges(){
        new PAQuotePage().getOfferingPrice()
                .clickMexicoCoverageCheckbox()
                .clickRecalculateButton()
                .clickBuyNowButton()
                .goPrevWithAlert();
        new PAQuotePage().validateBuyNowAndResetButtons();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new PAQuotePage().getStatusFromBackend(jsonData), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");

    }
}