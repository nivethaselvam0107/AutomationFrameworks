package com.guidewire.test.QnB;

import java.util.Calendar;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.pages.DriverDetailsPage;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.portals.qnb.pages.QuickQuotePage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.VehicleDetailsPage;
import com.guidewire.portals.qnb.pages.YourInfoPage;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.AddressSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.DriverSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.QuickQuoteSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.VehicleSection;


/**
 * Created by jkrawczyk-koca on 1/4/2017.
 */
public class QuickQuoteTest {

    Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());
    Logger logger = Logger.getLogger(this.getClass().getName());


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4701: Quote using lookups" )
    public void testQuickQuoteTestQuoteUsingLookups(String browserName) throws Exception
    {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        quickQuotePage.getQuickQuoteSection().validateQuoteDataRetrived();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4702: Quote without lookups" )
    public void testQuickQuoteTestQuoteWithoutLookups(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().withMake().withModel().withYear().clickNext();
        quickQuotePage.getAddressSection().setAddress().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        quickQuotePage.getQuickQuoteSection().validateQuoteDataRetrived();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4703: Quick Quote Driver Section Mandatory Validation" )
    public void testQuickQuoteDriverSectionMandatoryValidation(String browserName) throws Exception
    {
        this.setQuickQuoteData().put("Age", " ");
        this.setQuickQuoteData().put("Email", " ");
        this.setQuickQuoteData().put("VIN","123456789");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond"  }, description = "TC4704: Quick Quote Empty VIN Validation")
    public void testQuickQuoteEmptyVINValidation(String browserName) {
        this.setQuickQuoteData().put("VIN", "");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4705: Quick Quote Invalid VIN Validation")
    public void testQuickQuoteInvalidVINValidation(String browserName) {
        HashMap<String, String> data = ThreadLocalObject.getData();
        this.setQuickQuoteData().put("VIN", "123");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4706: Quick Quote Vehicle Details Mandatory Validation")
    public void testQuickQuoteVehicleDetailsMandatoryValidation(String browserName) {
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4707: Driver below 16 - minus sign" )
    public void testQuickQuoteDriverBelow16MinusSign(String browserName)
    {
    	this.setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "16");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        DriverSection driverSection = quickQuotePage.getDriverSection();
        driverSection.isAgeDecrementButtonDisabled().shouldBeTrue("Driver age decrement button is not disabled");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7132: Driver 15 age - manual entry" )
    public void testQuickQuoteDriverAge15(String browserName)
    {
    	this.setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "15");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        DriverSection driverSection = quickQuotePage.getDriverSection();
        driverSection.setDriverDetails().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7130: Driver 101 age - manual entry" )
    public void testQuickQuoteDriverAge101(String browserName)
    {
    	this.setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "101");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        DriverSection driverSection = quickQuotePage.getDriverSection();
        driverSection.setDriverDetails().isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
       
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7131: Driver 101 age - plus sign" )
    public void testQuickQuoteDriverAge101PlusSign(String browserName)
    {
    	this.setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "101");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        DriverSection driverSection = quickQuotePage.getDriverSection();
        driverSection.setDriverDetails().isAgeIncrementtButtonDisabled().shouldBeTrue("Age increment button is not disabled");
       
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7133: 	Driver under 25" )
    public void testQuickQuoteTestDriver25(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "24");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        quickQuotePage.getQuickQuoteSection().validateUWIssue("Primary Driver under 25");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4709: Driver 100" )
    public void testQuickQuoteTestDriver100(String browserName) throws Exception
    {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("Age", "100");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        quickQuotePage.getQuickQuoteSection().validateQuoteDataRetrived();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4710 Quick Quote Email Format Validation")
    public void testQuickQuoteEmailFormatValidation(String browserName) {
    	 this.setQuickQuoteData();
         setQuickQuoteData().put("VIN","123456789");
         QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
         quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
         quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
         quickQuotePage.getDriverSection().setDriverDetails().clickNext();
         QuickQuoteSection quickQuoteSection =  quickQuotePage.getQuickQuoteSection();
         quickQuoteSection.validateIncorrectEmailFormat("dgdg@gm");
         quickQuoteSection.validateCorrectEmailFormat("jsmith@guidewire.com");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4712 Your Info Screen prefilled")
    public void testQuickQuoteYourInfoScreenPrefilled(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        setQuickQuoteData().put("Email","dgang@test.com");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().setVIN().searchVIN().clickNext();
        quickQuotePage.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        QuickQuoteSection quickQuoteSection =  quickQuotePage.getQuickQuoteSection();
        quickQuoteSection.setEmail().emailQuote().clickNext();
        new YourInfoPage().validateQuickQuoteDataPreFilledOnYourInfoPage();

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4713: Vehicle prefill - car without vin")
    public void testQuickQuoteVehiclePrefillCarWithoutVin(String browserName)
    {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.generateQuickQuoteWithoutVIN();
        VehicleDetailsPage details = new YourInfoPage()
        	.setYourInfoPageDetails()
        	.goToQualificationPage()
        	.setQualificationPageDetails()
        	.goToDriverDetailsPage()
        	.setPrimaryDriverDetails()
        	.goToVehicleDetailsPage();
        details.validateQuickQuoteDataPreFilledOnVehiclesDetailsPage(false);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4722: Verify user can edit after quote is generated",  enabled = false)
    public void testQuickQuoteEditQuickQuote(String browserName) throws Exception {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        this.setQuickQuoteData().put("FirstName", "John");
        this.setQuickQuoteData().put("LastName", "Ray");
        String dob = DateUtil.getPastDateUsingYear(-25);
        this.setQuickQuoteData().put("DOB",dob);
        this.setQuickQuoteData().put("LicensePlate", "123456");
        this.setQuickQuoteData().put("DriverLicenseNum", "123456");
        QuickQuotePage quickQuotePage = pagefactory.getQuickQuotePage().generateQuickQuote();
        quickQuotePage.getQuickQuoteSection().editQuote();
        quickQuotePage.getAddressSection().clickEditBtn().editCityAddress();
        quickQuotePage.getQuickQuoteSection().quote();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4714: Verify if Vehicle Information is prefilled - car with vin")
    public void testQuickQuoteVehicleInformationPrefilledCarWithVin(String browserName)
   {
    	 this.setQuickQuoteData().put("VIN","123456789");
         pagefactory.getQuickQuotePage().generateQuickQuote();
         VehicleDetailsPage details = new YourInfoPage()
         	.setYourInfoPageDetails()
         	.goToQualificationPage()
         	.setQualificationPageDetails()
         	.goToDriverDetailsPage()
         	.setPrimaryDriverDetails()
         	.goToVehicleDetailsPage();
         details.validateQuickQuoteDataPreFilledOnVehiclesDetailsPage(true);
         	
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4716: Quick Quote - Buy Basic.")
    public void testQuickQuoteBuyBasic(String browserName) throws Exception
    {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        ThreadLocalObject.getData().put("FirstName","Dharmesh");
        ThreadLocalObject.getData().put("LastName","Gangwar");
        ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
        ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
        ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
        pagefactory.getQuickQuotePage().generateQuickQuote();
        PAQuotePage paQuotePage =  new YourInfoPage()
        	.setYourInfoPageDetails()
        	.goToQualificationPage()
        	.setQualificationPageDetails()
        	.goToDriverDetailsPage()
        	.setPrimaryDriverDetails()
        	.goToVehicleDetailsPage()
        	.setQuickQuoteVehicleDetails()
        	.goToPAQuotePage();
        	String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		PaymentDetailsPage paymentDetailsPage =	paQuotePage.buyBasePolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();	
		confirmationPage.isPolicyOfferingNameEqualTo(DataConstant.BASIC_QUOTE_LABEL, ParseQuoteData.getPolicyOfferingName(jsonData)).shouldBeEqual("Offering name is not correct");
     }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4724: Verify user can complete quote and buy standard program.")
    public void testQuickQuoteBuyStandard(String browserName) throws Exception
    {
    	 this.setQuickQuoteData();
         setQuickQuoteData().put("VIN","123456789");
         ThreadLocalObject.getData().put("FirstName","Dharmesh");
         ThreadLocalObject.getData().put("LastName","Gangwar");
         ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
         ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
         ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
         pagefactory.getQuickQuotePage().generateQuickQuote();
         PAQuotePage paQuotePage =  new YourInfoPage()
         	.setYourInfoPageDetails()
         	.goToQualificationPage()
         	.setQualificationPageDetails()
         	.goToDriverDetailsPage()
         	.setPrimaryDriverDetails()
         	.goToVehicleDetailsPage()
         	.setQuickQuoteVehicleDetails()
         	.goToPAQuotePage();
         	String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
 		PaymentDetailsPage paymentDetailsPage =	paQuotePage.buyStandardPolicyWithMonthlyPayment()
 		.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount();
 		PolicyConfirmationPage confirmationPage =paymentDetailsPage.purchasePolicy();
 		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
 		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
 		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();	
 		confirmationPage.isPolicyOfferingNameEqualTo(DataConstant.STANDARD_PROGRAM, ParseQuoteData.getPolicyOfferingName(jsonData)).shouldBeEqual("Offering name is not correct");
     }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4725: Verify user can complete quote and buy premium program.")
    public void testQuickQuoteBuyPremium(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        ThreadLocalObject.getData().put("FirstName","Dharmesh");
        ThreadLocalObject.getData().put("LastName","Gangwar");
        ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
        ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
        ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
        pagefactory.getQuickQuotePage().generateQuickQuote();
        PAQuotePage paQuotePage =  new YourInfoPage()
        	.setYourInfoPageDetails()
        	.goToQualificationPage()
        	.setQualificationPageDetails()
        	.goToDriverDetailsPage()
        	.setPrimaryDriverDetails()
        	.goToVehicleDetailsPage()
        	.setQuickQuoteVehicleDetails()
        	.goToPAQuotePage();
        	String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		PaymentDetailsPage paymentDetailsPage =	paQuotePage.buyPremiumPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.validatePAPolicyDataWithBackEnd(jsonData).shouldBeTrue();	
		confirmationPage.isPolicyOfferingNameEqualTo(DataConstant.PREMIUM_PROGRAM, ParseQuoteData.getPolicyOfferingName(jsonData)).shouldBeEqual("Offering name is not correct");
     }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4727: Verify user can complete quote and use credit card for payment.")
    public void testQuickQuotePaymentByCreditCard(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        ThreadLocalObject.getData().put("FirstName","Dharmesh");
        ThreadLocalObject.getData().put("LastName","Gangwar");
        ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
        ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
        ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
        pagefactory.getQuickQuotePage().generateQuickQuote();
        PAQuotePage paQuotePage =  new YourInfoPage()
        	.setYourInfoPageDetails()
        	.goToQualificationPage()
        	.setQualificationPageDetails()
        	.goToDriverDetailsPage()
        	.setPrimaryDriverDetails()
        	.goToVehicleDetailsPage()
        	.setQuickQuoteVehicleDetails()
        	.goToPAQuotePage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
		PaymentDetailsPage paymentDetailsPage =	paQuotePage.buyPremiumPolicyWithMonthlyPayment()
		.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage().payMonthlyPremiumWithCheckingBankAccount();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		confirmationPage.isPolicyPaymentPlanNameEqualTo(jsonData).shouldBeEqual("Payment plan is incorrect");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4728: Verify user can email quote information", enabled = false)
    public void testQuickQuoteEmailQuickQuote(String browserName)
    {
        this.setQuickQuoteData();
        setQuickQuoteData().put("VIN","123456789");
        QuickQuotePage quickQuotePage = pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().searchVehicleDetailsByVin();
        quickQuotePage.getAddressSection().setAddressDetails();
        quickQuotePage.getDriverSection().setDriverDetails();
        quickQuotePage.getQuickQuoteSection().quote().emailQuote();
    }


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4729: Verify user can add second driver to a quote")
    public void testQuickQuoteSecondDriver(String browserName) throws Exception
    {
        this.setQuickQuoteData().put("VIN","123456789");
        ThreadLocalObject.getData().put("FirstName","Dharmesh");
        ThreadLocalObject.getData().put("LastName","Gangwar");
        ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
        ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
        ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
        pagefactory.getQuickQuotePage().generateQuickQuote();
        QualificationPage qualificationPage =  new YourInfoPage().setYourInfoPageDetails().goToQualificationPage().setCurrentInsuranceStatus("Yes");
        PaymentDetailsPage paymentDetailsPage = qualificationPage
        		.goToDriverDetailsPage()
        		.setPrimaryDriverDetails()
        		.withNewDriver()
        		.goToVehicleDetailsPage()
        		.withVIN()
        		.withVehicleCost("10000")
        		.goToPAQuotePage()
        		.buyPremiumPolicyWithMonthlyPayment()
        		.goToPAPolicyInfoPage()
        		.setPhoneNumber()
        		.goToPaymentDetailsPage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        PolicyConfirmationPage confirmationPage = paymentDetailsPage
        		.setPaymentPlan("A Monthly 10% Down, 9 Max installments")
        		.setPaymentMethod("Credit Card")
        		.setCardNumber("344555666777778")
        		.setExpirationDate("January", "2020")
        		.purchasePolicy();
		DriverDetailsPage.areNewDriverDetailsMatchingBackEnd(DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber));
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4730: Verify user can add second vehicle to a quote")
    public void testQuickQuoteSecondVehicle(String browserName) throws Exception
    {
    	 this.setQuickQuoteData().put("VIN","123456789");
         ThreadLocalObject.getData().put("FirstName","Dharmesh");
         ThreadLocalObject.getData().put("LastName","Gangwar");
         ThreadLocalObject.getData().put("DriverFirstName", "Dharmesh");
         ThreadLocalObject.getData().put("DriverLastName", "Gangwar");
         ThreadLocalObject.getData().put("PolicyHolderDisplayName", "Dharmesh Gangwar");
         pagefactory.getQuickQuotePage().generateQuickQuote();
        QualificationPage qualificationPage =  new YourInfoPage().setYourInfoPageDetails().goToQualificationPage().setCurrentInsuranceStatus("Yes");
        PaymentDetailsPage paymentDetailsPage = qualificationPage
        			.goToDriverDetailsPage()
        			.setPrimaryDriverDetails()
        			.goToVehicleDetailsPage()
        			.withVIN()
        			.withVehicleCost("1000")
        			.withNewVehicle()
        			.goToPAQuotePage()
        			.buyPremiumPolicyWithMonthlyPayment()
        			.goToPAPolicyInfoPage()
        			.setPhoneNumber("34567890123")
        			.goToPaymentDetailsPage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        paymentDetailsPage.payMonthlyPremiumWithCreditCard().purchasePolicy();
        String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(ParseQuoteData.getAllVehicleDetailsFromBackEnd(jsonData).size(), 2).shouldBeEqual("Vehicle count is not correct");
        VehicleDetailsPage.areVehicleDetailsMatchingBackEndFilterByVIN(jsonData);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7126: Address not in the list - Mandatory Fields Validation" )
    public void testQuickQuoteAddressNotInListMandatoryFields(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().withMake().withModel().withYear().clickNext();
        AddressSection addressSection = quickQuotePage.getAddressSection();
        addressSection.clickAddressNotInList();
        addressSection.isNextButtonDisabled().shouldBeEqual();
        addressSection.setZipCode().setCity().setStreet().setState().isNextButtonDisabled().shouldNotBeEqual();
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7128: Going back in wizard with manual address" )
    public void testQuickQuoteGoBackInWizardWithManualAddress(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().withMake().withModel().withYear().clickNext();
        quickQuotePage.getAddressSection().clickAddressNotInList().setZipCode().setCity().setStreet().setState().clickNext();
        quickQuotePage.getDriverSection().setDriverDetails().clickNext();
        QuickQuoteSection quickQuoteSection =  quickQuotePage.getQuickQuoteSection();
        quickQuoteSection.setEmail().emailQuote().goPrev();
        DriverSection driverSection = quickQuotePage.getDriverSection();
        		driverSection.isDriverAgeEqualsTo().shouldBeEqual();
        		driverSection.goPrev();
        AddressSection addressSection = quickQuotePage.getAddressSection();
        		addressSection.validateAddressData();
        		addressSection.goPrev();
        VehicleSection vehicleSection = quickQuotePage.getVehicleSection();
        vehicleSection.validateVehicleDataRetrived(false);
        
    }
    
   
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC7127: 	Back to Address Search check" )
    public void testQuickQuoteAddressSearchNavigation(String browserName) throws Exception
    {
    	this.setQuickQuoteData();
        QuickQuotePage quickQuotePage =  pagefactory.getQuickQuotePage();
        quickQuotePage.getVehicleSection().withMake().withModel().withYear().clickNext();
        AddressSection addressSection = quickQuotePage.getAddressSection();
        addressSection.clickAddressNotInList().validateAddressManualEntryFormDisplayed();
        addressSection.clickBackToAddressSearch();
    }

    private HashMap<String, String> setQuickQuoteData()
    {
    	 HashMap<String, String> data = ThreadLocalObject.getData();
         data.put("Make","Toyota");
         data.put("Model","Avensis");
         data.put("VehicleYear","2013");
         data.put("Age","35");
         data.put("Email","dummy@email.dummy");
         data.put("AddressLine1","1001 E Hillsdale Blvd #800");
         data.put("State","California");
         data.put("City","Foster City");
         data.put("ZipCode","94404");
         data.put("PolicyType", "PersonalAuto");
         data.put("PolicyType", "PersonalAuto");
         data.put("Quote_Cov_Date", DateUtil.getCurrentDateMMDDYYYY());
         data.put("DriverGendor", "Male");
         data.put("FirstYearLicensed", Integer.toString(Calendar.getInstance().get(Calendar.YEAR)));
         data.put("DriverLicenseState", "California");
         data.put("FirstName", "0dummyname0");
         data.put("LastName", "0dummyname0");
         data.put("DriverFirstName", "0dummyname0");
         data.put("DriverLastName", "0dummyname0");
         data.put("AccidentNum", "0");
         data.put("ViolationNum", "0");
         data.put("DriverGendor", "Male");
         data.put("PolicyHolderDisplayName", "0dummyname0 0dummyname0");
         data.put("AddressType", "home");
         data.put("DriverGendor", "Male");
         data.put("DriverGendor", "Male");
         data.put("PolicyType", "PersonalAuto");
         data.put("Street", "123, test street");
         return data;
    }

}
