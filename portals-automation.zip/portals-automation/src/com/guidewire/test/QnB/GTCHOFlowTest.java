package com.guidewire.test.QnB;

import com.guidewire.capabilities.fnol.model.component.WizardNavBar;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created by dfedo on 02/08/2017.
 */
public class GTCHOFlowTest {

    Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6282 @ Reset Button for HO Quote - Monthly")
    public void testResetButtonForHOQuoteMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage();

        new HOQuotePage().clickPersonalInjuryCheckbox()
                .setValueToHomeownersOtherStructures("40%")
                .clickRecalculateButton()
                .clickResetCoverages()
                .isPersonalInjuryChecked()
                .validateActualValueOfHomeownersOtherStructures("10%");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("PersonalInjury"), "false").shouldBeEqual("Personal Injury is checked while it shouldn't");
        new HOQuotePage().clickRecalculateButton();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6542 @ Reset Button for HO Quote -  Pay in Full")
    public void testResetButtonForHOQuotePayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().clickPayInFullTab();

        new HOQuotePage().clickPersonalInjuryCheckbox()
                .setValueToHomeownersOtherStructures("40%")
                .clickRecalculateButton()
                .clickResetCoverages()
                .isPersonalInjuryChecked()
                .validateActualValueOfHomeownersOtherStructures("10%");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new Validation(ThreadLocalObject.getData().get("PersonalInjury"), "false").shouldBeEqual("Personal Injury is checked while it shouldn't");
        new HOQuotePage().clickRecalculateButton();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6491 @ Retrieve HO Quote Page without making changes")
    public void testRetrieveHOQuotePageWithoutMakingChanges(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new HOQuotePage().validateHOQuotePageLayout();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6835 @ Retrieve HO Quote Page after making changes without Recalculating - Monthly")
    public void testRetrieveHOQuotePageAfterMakingChangesWithoutRecalculatingMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new HOQuotePage().clickLimitedFungiWetDryRotBacteriaCheckbox()
                .setValueToHomeownersOtherStructures("20%");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new DiscountPage().goToHOQuotePage();

        new HOQuotePage().isLimitedFungiWetDryRotBacteriaChecked()
                .validateActualValueOfHomeownersOtherStructures("20%")
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        new Validation( Integer.parseInt(ThreadLocalObject.getData().get("OfferingPrice").replace("$","").replace(".","")) > Integer.parseInt(offeringPrice.replace("$","").replace(".","")) ).shouldBeTrue("Price was not recalculated");
        new Validation(ThreadLocalObject.getData().get("LimitedFungiWetDryRotBacteria"),"false").shouldBeEqual("Limited Fungi Wet Dry Rot Bacteria is not checked while it should.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6493 @ Retrieve HO Quote Page after making changes without Recalculating - Pay in Full")
    public void testRetrieveHOQuotePageAfterMakingChangesWithoutRecalculatingPayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new HOQuotePage().clickLimitedFungiWetDryRotBacteriaCheckbox()
                .setValueToHomeownersOtherStructures("20%");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new DiscountPage().goToHOQuotePage().clickPayInFullTab();

        new HOQuotePage().isLimitedFungiWetDryRotBacteriaChecked()
                .validateActualValueOfHomeownersOtherStructures("20%")
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        new Validation( Integer.parseInt(ThreadLocalObject.getData().get("OfferingPrice").replace("$","").replace(",","").replace(".","")) > Integer.parseInt(offeringPrice.replace("$","").replace(",","").replace(".","")) ).shouldBeTrue("Price was not recalculated");
        new Validation(ThreadLocalObject.getData().get("LimitedFungiWetDryRotBacteria"),"false").shouldBeEqual("Limited Fungi Wet Dry Rot Bacteria is not checked while it should.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6834 @ Retrieve HO Quote Page after making changes after Recalculating - Monthly")
    public void testRetrieveHOQuotePageAfterMakingChangesAfterRecalculatingMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new HOQuotePage().clickLimitedFungiWetDryRotBacteriaCheckbox()
                .setValueToHomeownersOtherStructures("20%")
                .clickRecalculateButton();

        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);

        new HOQuotePage().isLimitedFungiWetDryRotBacteriaChecked()
                .validateActualValueOfHomeownersOtherStructures("20%")
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        new Validation( Integer.parseInt(ThreadLocalObject.getData().get("OfferingPrice").replace("$","").replace(",","").replace(".","")) > Integer.parseInt(offeringPrice.replace("$","").replace(",","").replace(".","")) ).shouldBeTrue("Price was not recalculated");
        new Validation(ThreadLocalObject.getData().get("LimitedFungiWetDryRotBacteria"),"false").shouldBeEqual("Limited Fungi Wet Dry Rot Bacteria is not checked while it should.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6834 @ Retrieve HO Quote Page after making changes after Recalculating - Pay in Full")
    public void testRetrieveHOQuotePageAfterMakingChangesAfterRecalculatingPayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new HOQuotePage().clickLimitedFungiWetDryRotBacteriaCheckbox()
                .setValueToHomeownersOtherStructures("20%")
                .clickRecalculateButton();

        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);

        new HOQuotePage().clickPayInFullTab()
                .isLimitedFungiWetDryRotBacteriaChecked()
                .validateActualValueOfHomeownersOtherStructures("20%")
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        new Validation( Integer.parseInt(ThreadLocalObject.getData().get("OfferingPrice").replace("$","").replace(",","").replace(".","")) > Integer.parseInt(offeringPrice.replace("$","").replace(",","").replace(".","")) ).shouldBeTrue("Price was not recalculated");
        new Validation(ThreadLocalObject.getData().get("LimitedFungiWetDryRotBacteria"),"false").shouldBeEqual("Limited Fungi Wet Dry Rot Bacteria is not checked while it should.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }



    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6215 @ HO Coverages Save on Policy Info - Monthly")
    public void testHOCoveragesSaveOnPolicyInfoMonthly(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("RoofType", "comp");
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage();

        new HOQuotePage().clickPersonalInjuryCheckbox()
                .clickRecalculateButton()
                .clickBuyNowButton()
                .isPersonalInjuryCovarageSaved().shouldBeEqual("Personal Injury is not presented on Policy Info page ");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6836 @ HO Coverages Save on Policy Info - Pay In Full")
    public void testHOCoveragesSaveOnPolicyInfoPayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage().clickPayInFullTab();

        new HOQuotePage().clickPersonalInjuryCheckbox()
                .clickRecalculateButton()
                .clickBuyNowButton()
                .isPersonalInjuryCovarageSaved().shouldBeEqual("Personal Injury is not presented on Policy Info page ");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6494 @ Monthly: Going back in wizard to Discount Page without making changes on Quote")
    public void testMonthlyGoingBackInWizardToDiscountPageWithoutMakingChangesOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6848 @ Pay in Full: Going back in wizard to Discount Page without making changes on Quote")
    public void testPayFullGoingBackInWizardToDiscountPageWithoutMakingChangesOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        DiscountPage discountPage = new LeftNavigationMenuHandler().gotoDiscountPage();
        discountPage.goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6847 @ Pay in Full: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testPayFullGoingBackInWizardToDiscountPageWithMakingChangesAndnotSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .setValueToHomeownersDwellingHomeownersPersonalLiability("200,000");
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateActualValueOfHomeownersPersonalLiability("200,000")
                .validateRecalculateButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price wasn't changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6845 @ Monthly: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testMonthlyGoingBackInWizardToDiscountPageWithMakingChangesAndnotSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .setValueToHomeownersDwellingHomeownersPersonalLiability("200,000");
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .validateActualValueOfHomeownersPersonalLiability("200,000")
                .validateRecalculateButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price wasn't changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6846 @ Monthly: Going back in wizard to Discount Page with making changes and selecting Recalculate on Quote")
    public void testMonthlyGoingBackInWizardToDiscountPageWithMakingChangesAndSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .setValueToHomeownersHomeownersLossOfUse("50%")
                .clickRecalculateButton()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .validateActualValueOfHomeownersLossOfUse("50%")
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price wasn't changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Quoted");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite"}, description = "TC6495 @ Pay Full: Going back in wizard to Discount Page with making changes and selecting Recalculate on Quote")
    public void testPayFullGoingBackInWizardToDiscountPageWithMakingChangesAndSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .setValueToHomeownersHomeownersLossOfUse("50%")
                .clickRecalculateButton()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateActualValueOfHomeownersLossOfUse("50%")
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price wasn't changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

}
