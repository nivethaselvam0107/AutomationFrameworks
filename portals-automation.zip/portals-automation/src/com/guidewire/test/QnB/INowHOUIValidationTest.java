package com.guidewire.test.QnB;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class INowHOUIValidationTest {

	Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11015 @ Verify HO Icon functionality")
	public void testHOYourInfoPageLoading(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.isYourInfoPageLoaded().shouldBeTrue("Your Info page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11031 & 32 @ HO Your Info Page Mandatory Fields Validation")
	public void testHOYourInfoPageMandatoryFields(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.goNext().areiNowDefaultYourPageFieldsMakedWithMandatoryError().shouldBeTrue();
		infoPage.areINowDefaultYourPageFieldsMakedWithAsterisk().shouldBeTrue();
	}
	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11087 @ HO Your Info Page Google address search")
	public void testHOYourInfoPageGoogleAddressSearch(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setYourInfoPageWithGoogleAddressSearchDetails().goToQualificationPage();
		String quoteDataBackEnd = DataFetch.getINowQuoteAsJsonData();
		infoPage.areYourInfoPageDataMatchingWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("Your Info page details are not matching back end.");
		QuoteInfoBar.isSubmissionInDraftStatus(quoteDataBackEnd).shouldBeEqual("Submission is not in Draft status");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "HO Your Info Page Google search And Verify Address fields")
	public void testHOYourInfoPageGoogleSearchAndVerifyAddressFields(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setYourInfoPageWithGoogleAddressSearchDetails().isAddressFieldsArePopulated();
		infoPage.goToQualificationPage();
		String quoteDataBackEnd = DataFetch.getINowQuoteAsJsonData();
		infoPage.areYourInfoPageDataMatchingWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("Your Info page details are not matching back end.");
		QuoteInfoBar.isSubmissionInDraftStatus(quoteDataBackEnd).shouldBeEqual("Submission is not in Draft status");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11299 @ Verify the HO Your Information page - Save Point & QB-465:HOP Verify the Landing page when choosing HO")
	public void testHOYourInfoPageSavePoint(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setYourInfoPageDetails().goToQualificationPage();
		String quoteDataBackEnd = DataFetch.getINowQuoteAsJsonData();
		infoPage.areYourInfoPageDataMatchingWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("Your Info page details are not matching back end.");
		QuoteInfoBar.isSubmissionInDraftStatus(quoteDataBackEnd).shouldBeEqual("Submission is not in Draft status");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11034 @ Verify the HO Qualification page")
	public void testQualificationPageLoadingAndDataVerification(String browserName) throws Exception {
		QualificationPage qualificationPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("Qualification page is not loaded");
		qualificationPage.setQualificationPageDetails().areHOQualificationAnswersSaved()
				.shouldBeTrue("HO Qualification answers are not saved");
		qualificationPage.goToYourHomePage().isInowYourHomePageLoaded().shouldBeTrue("Your Home page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11036 @ HO Qualification Page Mandatory Fields Validation")
	public void testHOQualificationPageMandatoryFields(String browserName) throws Exception {
		QualificationPage qualificationPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("Qualification page is not loaded");
		qualificationPage.goNext().areHOQualificationPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Qualification page mandatory fields are not marked with error");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11037 @ Verify the Your Home page")
	public void testHOYourHomePageLoadingAndDataVerification(String browserName) throws Exception {
		YourHomePage homePage = pagefactory.setINowHOPolicyDataUpToQualificationPage().goToYourHomePage();
		homePage.isInowYourHomePageLoaded().shouldBeTrue("Your home page is not loaded");
		homePage.setiNowYourHomePageDetails().areINowYourHomePageFieldsValuesAreSaved()
				.shouldBeTrue("HO Your Home values are not saved");
		homePage.goToConstructionPage().isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11038 @ Verify HO Your Home - mandatory fields")
	public void testHOYourHomePageMandatoryFields(String browserName) throws Exception {
		YourHomePage homePage = pagefactory.setINowHOPolicyDataUpToQualificationPage().goToYourHomePage().cleariNowYourHomePageDetails();
		homePage.goNext().areINowYourHomePageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Your Home page mandatory fields are not marked with error");
		homePage.areINowYourHomePageMandatoryFieldsMakedWithAsterisk().shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" } , description = "TC11055 @ Verify Construction page")
	public void testHOConstructionPageLoadingAndDataVerification(String browserName) {
		ConstructionPage constructionPage = pagefactory.setiNowHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.setiNowConstructionPageDetails().areInowConstructionPageDetailsSaved()
				.shouldBeTrue("Construction page details are not saved");
		constructionPage.goToDiscountPage().isInowDiscountPageLoaded().shouldBeTrue("Construction Page should be loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11056 @ Verify Construction page - mandatory fields")
	public void testHOConstructionPageMandatoryFields(String browserName) {
		ConstructionPage constructionPage = pagefactory.setiNowHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.goNext().areInowConstructionPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Construction page fields are not marked with error");
		constructionPage.areInowConstructionPageMandatoryFieldsMakedWithAsterisk()
		.shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11057 @ Verify the Discount page")
	public void testHODiscountPageLoadingAndDataVerification(String browserName) throws Exception {
		DiscountPage discountPage = pagefactory.setiNowHOPolicyDataUpToConstructionPage().goToDiscountPage();
		discountPage.isInowDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.setiNowDiscountPageDetails();
		discountPage.areInowDiscountPageValueSaved().shouldBeTrue("Discount page details are not saved");
		discountPage.goToHOQuotePage().isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11058 @ Verify Discount page - mandatory fields")
	public void testHODiscountMandatoryFieldsValidation(String browserName) throws Exception {
		DiscountPage discountPage = pagefactory.setiNowHOPolicyDataUpToConstructionPage().goToDiscountPage();
		discountPage.isInowDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.goNext().areInowHODiscountPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Discount page fields are not marked with error");
		discountPage.areInowDiscountPageMandatoryFieldsMakedWithAsterisk()
				.shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "Verify the Discount page - Save Point")
	public void testHODiscountPageSavePoint(String browserName) throws Exception {
		DiscountPage discountPage = pagefactory.setiNowHOPolicyDataUpToConstructionPage().goToDiscountPage();
		discountPage.isInowDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.setiNowDiscountPageDetails();
		discountPage.areInowDiscountPageValueSaved().shouldBeTrue("Discount page details are not saved");
		discountPage.goToHOQuotePage().isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		String jsonData = DataFetch.getINowQuoteAsJsonData();
		QuoteInfoBar.isSubmissionInQuotedStatus(jsonData).shouldBeEqual("Submission is not in Quote status");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW"}, description = "TC11108 @ Verify the Quote page")
	public void testHOQuotePageLoadingAndBaseCoverageValidation(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage();
		hoQuotePage.isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		hoQuotePage.validateHOQuotePageLayout().shouldBeTrue();
		hoQuotePage.areInowHOQuoteBaseCoverageDataMatchingWithBackEnd()
				.shouldBeTrue("HO Base Coverage value are not matched with the Back End");
		hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().isHOPolicyInfoPageLoaded()
				.shouldBeTrue("HO Policy info page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW"}, description = "Quote page change Base Coverage and save to exit quote")
	public void testHOQuotePageChangeBaseCoverageAndSave(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage();
		hoQuotePage.isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		hoQuotePage.validateHOQuotePageLayout().shouldBeTrue();
		hoQuotePage.setInowLimit_HO_DWEL_Value("499999");
		hoQuotePage.isRecalculateButtonAppears().shouldBeTrue("Re-Calculate Button not appears");
		hoQuotePage.clickOnHeaderGWAndConfirmCancel();
		new ZipCodePage().isHOOnlyZipCodePageOpened().shouldBeTrue("Zip Code page is not opened");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11210 @ Verify the HO Policy Info page")
	public void testHOPolicyInfoPageLoadingAndCoverageValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
		String quoteDataBackEnd = DataFetch.getINowQuoteAsJsonData();
		hoPolicyInfoPage.validateCoverageDateWithBackEnd(quoteDataBackEnd)
		.shouldBeEqual("Policy Coverage start date is not matched on policy Info page");
		hoPolicyInfoPage.validatePolicyAddressWithBackEnd(quoteDataBackEnd)
				.shouldBeEqual("Policy address is not matched on policy Info page");
		hoPolicyInfoPage.validatePrimaryInsuredPersonNameWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("Primary Insured Person name is not mactched on policy Info page");
		hoPolicyInfoPage.validatePolicyAddressWithBackEnd(quoteDataBackEnd)
				.shouldBeEqual("Policy Address is not mactched on policy Info page");
		hoPolicyInfoPage.areInowReadOnlyHOQuoteBaseCoverageDataMatchingWithBackEnd()
				.shouldBeTrue("HO Base Coverage value are not matched with the Back End on the policy info page.");
		hoPolicyInfoPage.isPolicyBillingAddressOptionSelectedByDefault()
				.shouldBeTrue("Billing addess option is not selected Yes by default");
		hoPolicyInfoPage.setInowPolicyInfoPageDetails().isReadOnlyEmailExists().shouldBeEqual("Billing Email doesn't exists");
		hoPolicyInfoPage.isPhoneSaved().shouldBeEqual("Email field is not saved");
		hoPolicyInfoPage.goToPaymentDetailsPage().isPaymentDetailsPageLoaded()
				.shouldBeTrue("Policy Payment page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11207 @ Verify the HO Policy Info page - mandatory fields.")
	public void testHOPolicyInfoPageMandatoryFieldsValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage()
					.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");

		hoPolicyInfoPage.goNext().isPhoneNumberFieldMakedWithError().shouldBeEqual("Mandatory field error is not matched for Phone Number field");
	}

	/*
		javax.net.ssl.SSLHandshakeException: sun.security.validator.ValidatorException:
	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "Verify Confirmation Page")
	public void testHOPolicyConfirmationPageLoadingAndDetailsValidation(String browserName) throws Exception {
		pagefactory.quoteAndBuyInowHOBasePolicyWithMonthlySavingAccountPayment().validateINowHOPolicyConfirmationPageDetailsWithBackEnd().shouldBeTrue();
	}
    */

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC11300 @ Verify the coverage must start in a future date.")
	public void testHOPolicyEffectiveDateMustBeFuture(String browserName) {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setYourInfoPageDetails()
				.withCoverage(DateUtil.getPastDateUsingDays()).goNext().isCoverageDateFutureErrorPresent()
				.shouldBeEqual("Coverage Details must be in Future Error is not present");
	}


	@Parameters("browserName")
	@Test(enabled =false, groups = { "REG_INOW" }, description = "TC4267 @ HO Policy Info Email Validation")
	public void testHOPolicyInfoPageEmailFormatFieldValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
		hoPolicyInfoPage.setEmailAddress("abc").setPhoneNumber().goNext().isEmailFieldMarkedWithFormatError().shouldBeEqual("Format field error is not matched for Email field");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_INOW" }, description = "TC4267 @ Verify the HO Policy Info for email validation")
	public void testHOYourInfoPageEmailFormatFieldValidation(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.isYourInfoPageLoaded().shouldBeTrue("Your Info page is not loaded");
		infoPage.withEmail().goNext().isEmailFieldMarkedWithFormatError().shouldBeEqual("Format field error is not matched for Email field");
	}

}
