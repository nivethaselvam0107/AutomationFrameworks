package com.guidewire.test.QnB;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;

public class TestDevelopement {

	 Pagefactory pagefactory = new Pagefactory();
	 Logger logger = Logger.getLogger(this.getClass().getName());


	 @Parameters("browserName")
	    @Test(groups = {"Regression"}, enabled = true)
	    public void testTryPolicyWithFutureBoundEndorsement(String browserName) {
	        SeleniumCommands seleniumCommands = new SeleniumCommands();
	        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
	        EndorsementPage endorsementPage = accountSummaryPage.
	                changeMyPolicy().
	                selectPolicy().
	                selectEffectiveDate(2).
	                selectVehicle().
	                selectAction("Add").
	                fillFormData().
	                assignDriverByIndex(0).
	                submit();
	        endorsementPage.completeCoverage().complete().quote().buy().confirm().clickBackToHomeButton();
	        String secondDate = ThreadLocalObject.getData().get("EFFECTIVE_DATE_SECOND");
	        accountSummaryPage.changeMyPolicy().selectPolicy();
	        endorsementPage.isEffectiveDateEnabled().shouldBeFalse();
	    }
	 
}