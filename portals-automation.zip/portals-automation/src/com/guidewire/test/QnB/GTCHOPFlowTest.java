package com.guidewire.test.QnB;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.QuoteScheduledPropertyItem;
import com.guidewire.portals.qnb.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

/**
 * Created by dfedo on 08/08/2017.
 */
public class GTCHOPFlowTest {

    Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());
    Logger logger = Logger.getLogger(this.getClass().getName());


    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6865 @ HOP Reset Button for HO Quote - Monthly")
    public void testHOPResetButtonForHOQuoteMonthly(String browserName) throws Exception {
        HOQuotePage hoQuotePage = pagefactory
                .setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage();

        new HOQuotePage().setValueToOtherStructuresCauseOfLoss("Special Perils")
                .setValueToLossOfUseProhibitedUse("45 Days")
                .clickRecalculateButton()
                .clickResetCoverages()
                .validateLossOfUseProhibitedUse("14 Days");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().clickRecalculateButton();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6866 @ HOP Reset Button for HO Quote - Monthly")
    public void testHOPResetButtonForHOQuotePayFull(String browserName) throws Exception {
        HOQuotePage hoQuotePage = pagefactory
                .setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage().clickPayInFullTab();
        new HOQuotePage().setValueToOtherStructuresCauseOfLoss("Special Perils")
                .setValueToLossOfUseProhibitedUse("45 Days")
                .clickRecalculateButton()
                .clickResetCoverages()
                .validateLossOfUseProhibitedUse("14 Days");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().clickRecalculateButton();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"}, description = "TC6855 @ Monthly: HOP Going back in wizard to Discount Page without making changes on Quote")
    public void testHOPMonthlyGoingBackInWizardToDiscountPageWithoutMakingChangesOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6856 @ Pay in Full: HOP Going back in wizard to Discount Page without making changes on Quote")
    public void testHOPPayFullGoingBackInWizardToDiscountPageWithoutMakingChangesOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }



    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6854 @ HOP Pay In Full: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testHOPPayFullGoingBackInWizardToDiscountPageWithMakingChangesAndnotSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .clickPersonalInjuryNoTabForHOP()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .setValueToAdditionalCoveragesLossAssessment("$5,000")
                .addPersonalPropertyGranite();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6853 @ HOP Monthly: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testHOPMonthlyGoingBackInWizardToDiscountPageWithMakingChangesAndnotSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .clickPersonalInjuryNoTabForHOP()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .setValueToAdditionalCoveragesLossAssessment("$5,000")
                .addPersonalPropertyGranite();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice().clickRecalculateButton()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6852 @ HOP Monthly: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testHOPMonthlyGoingBackInWizardToDiscountPageWithMakingChangesAndSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .clickPersonalInjuryNoTabForHOP()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .setValueToAdditionalCoveragesLossAssessment("$5,000")
                .addPersonalPropertyGranite()
                .clickRecalculateButton();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6851 @ HOP Pay Full: Going back in wizard to Discount Page with making changes and not selecting Recalculate on Quote")
    public void testHOPPayFullGoingBackInWizardToDiscountPageWithMakingChangesAndSelectingRecalculateOnQuote(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .clickPersonalInjuryNoTabForHOP()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .setValueToAdditionalCoveragesLossAssessment("$5,000")
                .addPersonalPropertyGranite()
                .clickRecalculateButton();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        new LeftNavigationMenuHandler().gotoDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateBuyNowButtonIsPresented();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new Validation(offeringPrice,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not changed.");
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"}, description = "TC6857 @ HOP Retrieve HO Quote Page after making changes after Recalculating - Pay in Full")
    public void testHOPRetrieveHOQuotePageAfterMakingchangesAfterRecalculatingPayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .clickRecalculateButton()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new HOQuotePage().clickPayInFullTab()
                .getOfferingPrice()
                .validateHOQuotePageLayout();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().validateBuyNowButtonIsPresented();
        new HOQuotePage().validateCoverageEPersonalLiabilityLimit("$300,000");
        new Validation(offeringPrice ,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"}, description = "TC6858 @ HOP Retrieve HO Quote Page after making changes after Recalculating - Monthly")
    public void testHOPRetrieveHOQuotePageAfterMakingchangesAfterRecalculatingMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000")
                .clickRecalculateButton()
                .getOfferingPrice();
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new HOQuotePage().getOfferingPrice()
                .validateHOQuotePageLayout();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().validateBuyNowButtonIsPresented();
        new HOQuotePage().validateCoverageEPersonalLiabilityLimit("$300,000");
        new Validation(offeringPrice ,ThreadLocalObject.getData().get("OfferingPrice")).shouldBeEqual("Offering price was changed.");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6859 @ HOP Retrieve Quote Page after making changes without Recalculating - Pay in Full")
    public void testHOPRetrieveQuotePageAfterMakingchangesWithoutRecalculatingPayFull(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000");
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new DiscountPage().goToHOQuotePage();
        new HOQuotePage()
                .clickPayInFullTab()
                .getOfferingPrice()
                .validateHOQuotePageLayout();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().validateBuyNowButtonIsPresented();
        new HOQuotePage().validateCoverageEPersonalLiabilityLimit("$300,000");
        new Validation(offeringPrice ,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not recalculated changed.");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6860 @ HOP Retrieve Quote Page after making changes without Recalculating - Monthly")
    public void testHOPRetrieveQuotePageAfterMakingchangesWithoutRecalculatingMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage()
                .getOfferingPrice()
                .setValueToCoverageEPersonalLiabilityLimit("$300,000");
        String offeringPrice = ThreadLocalObject.getData().get("OfferingPrice");
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Draft").shouldBeEqual("Program Status doesn't equals to Draft");
        new DiscountPage().goToHOQuotePage();
        new HOQuotePage()
                .getOfferingPrice()
                .validateHOQuotePageLayout();
        new Validation(new HOQuotePage().getStatusFromBackend(refereNumber), "Quoted").shouldBeEqual("Program Status doesn't equals to Draft");
        new HOQuotePage().validateBuyNowButtonIsPresented();
        new HOQuotePage().validateCoverageEPersonalLiabilityLimit("$300,000");
        new Validation(offeringPrice ,ThreadLocalObject.getData().get("OfferingPrice")).shouldNotBeEqual("Offering price was not recalculated changed.");
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"}, description = "TC6861 @ HOP Retrieve Quote Page without making changes")
    public void testHOPRetrieveQuotePageWithoutMakingChanges(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        new QuotePage().clickMenuButton();
        pagefactory.retrieveQuote(refereNumber);
        new HOQuotePage("").validateHOQuotePageLayout();
    }

    @Parameters("browserName")
    @Test(groups = {"Ferrite91","Granite"},enabled = true, description = "TC6862 @ HOP Coverages Save on Policy Info - Monthly")
    public void testHOCoveragesSaveOnPolicyInfoMonthly(String browserName) throws Exception {
        pagefactory.setHOPolicyDataUpToDiscountPage()
                .goToHOQuotePage();
        new HOQuotePage().setValueToDwellingValuationMethod("Actual cash value")
                .clickRecalculateButton()
                .clickBuyNowButton()
               .validateDwellingValuationMethod("Actual cash value");

    }

}
