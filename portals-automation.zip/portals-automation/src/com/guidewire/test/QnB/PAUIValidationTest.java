package com.guidewire.test.QnB;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.portals.qnb.pages.DriverDetailsPage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.PAPolicyInfoPage;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.VehicleDetailsPage;
import com.guidewire.portals.qnb.pages.YourInfoPage;
import com.guidewire.portals.qnb.pages.ZipCodePage;

public class PAUIValidationTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	/**@formatter:off
	 * @param browserName
	  
	  Test Description :- Verify the Landing page
	  
	            Actual :- 
	            	 1. Leave the zipcode field empty and click on the car icon.
	            	 2. Click on Go!.
	 
	            Expected :- 
	              1. The car icon is highlighted.. 
	              2. The error message "Please enter a ZIP code" should be displayed.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4761 @ PA - Landing Page Mandatory Zip Code Validation")
	public void testZipCodePageLoadingAndMandatoryFields(String browserName) {
		ZipCodePage zipCodePage = pagefactory.getZipCodePage();
		zipCodePage.goNext().isZipCodeFieldMakedWithError()
				.shouldBeEqual("Zip code Fields are not marked with error message");
	}
	/**@formatter:off
	 * @param browserName

	Test Description :- Verify the Landing page

	Actual :-
	1. Enter 0 in the zipcode field and click on the car icon.
	2. Click on Go!.

	Expected :-
	1. The car icon is highlighted..
	2. The error message "Value must be a valid postal code" should be displayed.

	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4762 @ PA - invalid ZIP code on landing page.")
	public void testInvalidZipCode(String browserName) {
		pagefactory.getZipCodePage().setZipCodePageDetails().goNext().isZipCodeFieldMakedWithInvalidZipError().shouldBeTrue("Zip Code message is not matched");
	}


	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify the Landing page
	 * 
	 *            Actual :- 
	 *            1. Enter a valid ZIP Code.
	 *            2. Click on the car icon.
	 *            3. Click on Go!.
	 * 
	 *            Expected :- 
	 *            1. ZIP code is populated. 
	 *            2. The car icon is highlighted. 
	 *            3. The Vehicle Your Information page is loaded.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE"}, description = "QB-PA-001 @ Verify the Landing page")
	public void testPAYourInfoPageLoading(String browserName) {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setAddressManually().isYourInfoPageLoaded().shouldBeTrue("Your Info Page is not Loaded");
	}

	/**
	 * @formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Your Information page - mandatory fields	
	 * 
	 *            Actual :- 
	 *            1. Complete the landing page 
	 *            2. Click the Next button.
	 * 
	 *            Expected :- 
	 *            1. The Your Information page is loaded. 
	 *            2. Verify that all field labels with a red * have the following message,
	 *            This is a required field. The following fields should have
	 *            this message. First Name, Last Name, Date of Birth, Address 1,
	 *            City, State, Email Address and coverage start."
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC5650 @ Verify Your Information page - mandatory fields")
	public void testPAYourInfoPageMandatoryField(String browserName) {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setAddressManually().goNext().areYourPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Your Info Page fields are not marked with error message");
		infoPage.areYourPageFieldsMakedWithAsterisk().shouldBeTrue();
	}

	/**
	 @formatter:off
	 @param browserName
	 	Test Description :- Verify the Qualification page
	 
	           	Actual :- 
	            		1. Complete the Landing page
					2. Complete the Your Info page
					3. Answer ""No-New-Driver"" to Are you currently insured?
					4. Answer No (default) to the 4 questions.
					5. Click Next.
	 
	           Expected :- 
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. No - New Driver appears in the field.
					4. Radio sliders are all in the No position.
					5. The Drivers page is loaded.
	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5651 @ PA - Verify the Qualification page")
	public void testPAQualificationPageLoading(String browserName) {
		QualificationPage qualificationPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage()
				.setYourInfoPageDetails().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("QualificationPage Page is not Loaded");
		qualificationPage.setQualificationPageDetails().arePAQualificationAnswersSaved()
				.shouldBeTrue("Qualification Page answers are not saved");
		qualificationPage.goToDriverDetailsPage().isDriverPageLoaded().shouldBeTrue("Driver Page Page is not Loaded");
	}

	/**
	 @formatter:off
	 @param browserName
	 	Test Description :- Verify the Drivers page
	 
	           	Actual :- 
	            		1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Verify the following fields are not editable - First Name, Last Name and Date of Birth
					5. Enter data in the following fields - Gender, Drivers License, License State, Year First licenesed, Number of violations, Number of accidents.
					6. Click on No
	 
	           Expected :- 
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. Fields must not be editable. 
					5. Fields will be populated.
					6. Vehicles page is loaded.
	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5652 @ PA - Verify the Drivers page")
	public void testPADriverPageLoading(String browserName) {
		DriverDetailsPage driverDetailsPage = pagefactory.setPAPolicyDataUpToQualificationPage()
				.goToDriverDetailsPage();
		driverDetailsPage.isDriverPageLoaded().shouldBeTrue("Driver Page Page is not Loaded");
		driverDetailsPage.arePrimaryDriverDetailsNonEditable().shouldBeTrue();
		driverDetailsPage.setPrimaryDriverDetails().areDriverDetailsSaved()
				.shouldBeTrue("Driver Details are not saved");
		driverDetailsPage.goToVehicleDetailsPage().isVehiclePageLoaded().shouldBeTrue("Vehicle page is not loaded");
	}

	/**
	 @formatter:off
	 @param browserName
	 	Test Description :- Verify Drivers page - mandatory fields
	 
	           	Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. On the Drivers page, click Next
	 
	           Expected :- 
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. Verify that all field labels with a red * have the following message, ""This is a required field"". The following fields should have this message. Gender, Drivers License, License State, Year First licenesed, Number of violations, Number of accidents."
	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5653 @ PA - Verify Drivers page - mandatory fields validation")
	public void testPADriverPageMandatoryFields(String browserName) {
		DriverDetailsPage driverDetailsPage = pagefactory.setPAPolicyDataUpToQualificationPage()
				.goToDriverDetailsPage();
		//driverDetailsPage.areDriverPageFieldsMarkedWithMandatoryError().shouldBeTrue();
		driverDetailsPage.areDriverPageFieldsMarkedWithAsterisk().shouldBeTrue();
	}

	/**
	 @formatter:off
	 @param browserName
	 	Test Description :- Verify Vehicles page - mandatory fields
	 
	           	Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. On the vehicles page, click No
	 
	           Expected :- 
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Verify that all field labels with a red * have the following message, ""This is a required field"". The following fields should have this message. - VIN, Make, Model, Year, License Plate, State, Cost New.
	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"} , description = "TC5655 @ PA - Verify Vehicles page - mandatory fields")
	public void testPAVehiclePageMandatoryFields(String browserName) {
		VehicleDetailsPage vehicleDetailsPage = pagefactory.setPAPolicyDataUpToDriverPage().goToVehicleDetailsPage();
		vehicleDetailsPage.isVehiclePageLoaded().shouldBeTrue("Vehicle Page Page is not Loaded");
//		vehicleDetailsPage.goNext().areVehiclePageFieldsMarkedWithMandatoryError()
//				.shouldBeTrue("Vehicle Page fields are not marked with error message");
		vehicleDetailsPage.areVehiclePageFieldsMarkedWithAsterisk()
		.shouldBeTrue("Vehicle Page mandatory fields are not marked with asterisk");
//		vehicleDetailsPage.setVehicleDetails().withVehicleCost("ABC")
//				.isCostNewFieldMakedWithNumberFormatError().shouldBeEqual("Number format error is not present");
//		vehicleDetailsPage.withVehicleCost().areVehiclesDetailsSaved().shouldBeTrue("Vehicle Details are not saved");
	}

	/**
	 @formatter:off
	 @param browserName
	 	Test Description :- Verify Policy Info page
	 
	           	Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click ""Buy Basic Policy"".
					7. Provide a Phone Number if is it not already present.
					8. Click Next
	 
	           Expected :- 
					1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. The Policy Information page will be loaded containing Coverage Start Date , Vehicles, Drivers and Contact details, verify these details are correct.
					7. No validation message should appear.
					8. The Payment Details page loads
	 * @throws Exception 
	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC5657 @  PA - Verify Policy Info page")
	public void testPAPolicyInfoPageLoadingAndDataVerification(String browserName) throws Exception {
		pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage()
				.buyBasePolicyWithMonthlyPayment().goToPAPolicyInfoPage().setPolicyInfoPageDetails().validatePolicyInfoPageDetails().shouldBeTrue();
		new PAPolicyInfoPage().goToPaymentDetailsPage().isPaymentDetailsPageLoaded().shouldBeTrue("Policy payment page is not opened");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :-
	 * 
	 *             Actual :- 
	 *             1. Complete the landing page
	 *             2. Complete Your Info page 
	 *             3. Complete Qualification page 
	 *             4. Complete the Drivers page. 
	 *             5. Complete the vehicles page and click No. 
	 *             6. On quote page click ""Buy Basic Policy"". 
	 *             7. On the Policy Information page Click Next. 
	 *             8. Verify page layout. 
	 *             9. Choose a payment plan eg ""Monthly 10"". 
	 *             10. Provide payment details. Payment Method, Account Type, Account Number, Routing, Bank Name. 
	 *             11. Click on Purchase 
	 *             12. Login to PC and verify data is correct and valid. 
	 *             13. Verify submission status
	 * 
	 *             Expected :-
	 * 
	 *             1. The Your Information page is loaded. 
	 *             2. The Qualification page is loaded. 
	 *             3. The Drivers page is loaded. 
	 *             4. The vehicles page is loaded. 
	 *             5. Quote page is loaded. 
	 *             6. The Policy Information page will be loaded containing Coverage
	 *             	   Start Date , Vehicles, Drivers and Contact details. 
	 *             7. The Payment Details page loads 
	 *             8. Monthly payment and total premium should be displayed. A table of payment plans should
	 *                 be displayed. Payment options section should also be present. There should be no payment plan choosen by default. 
	 *             9. Monthly 10 plan should be highlighted. 
	 *             10. Payment details form should be fill in correctly without validation messages.
	 *             11. Confirmation page is displayed. 
	 *             12. All data entered during the submission process should be in the PC as you
	 *            	 	entered it in the portal. 
	 *             13. The Submission will be complete and there will be a policy number assigned."
	 *@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC5658 @ PA - Verify Payment Details page. - Save Point")
	public void testPAPaymentDetailsPageSavePoint(String browserName) throws Exception {
		PAQuotePage paQuotePage = pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PAPolicyInfoPage paPolicyInfoPage = paQuotePage.buyBasePolicyWithMonthlyPayment().goToPAPolicyInfoPage();
		paPolicyInfoPage.validatePolicyInfoPageDetails()
				.shouldBeTrue("Policy Infor page details are not matched with backend");
		PolicyConfirmationPage policyConfirmationPage = paPolicyInfoPage.setPolicyInfoPageDetails()
				.goToPaymentDetailsPage().payAnnualPremiumWithSavingsBankAccount().setPaymentPlan().purchasePolicy();
		policyConfirmationPage.isPolicyConfirmationPageDisplayed()
				.shouldBeTrue("Policy Confirmation page is not displayed");
		String quoteData = DataFetch.getQuoteAsJsonData(quoteNum);
		policyConfirmationPage.validatePAPolicySummaryDetails(quoteData)
				.shouldBeTrue("Policy Summary details are not matched");
		new QualificationPage().arePAQualificationAnswersMatchingBackEnd(quoteData)
				.shouldBeTrue("Qualification answers are not matching with Back End");
		DriverDetailsPage.areDriverDetailsMatchingBackEnd(quoteData)
				.shouldBeTrue("Driver Details are not matching with Back End");
		VehicleDetailsPage.areVehicleDetailsMatchingBackEnd(quoteData)
				.shouldBeTrue("Vehicle Details are not matching with Back End");
	}

	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify Confirmation Page.
	  
	             Step actions :- 
	             	1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. On quote page click "Buy Basic Policy".
					7. On the Policy Information page Click Next.
					8. Click on Purchase
					9. Verify the Confirmation page
	  
	             Expected Results :- 
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. Policy Info page will be loaded.
					7. Payment details page will be loaded.
					8. Confirmation page will be loaded.
					9. Confirmation page will contain the policy summary, the following sections will be expandable (closed by default) Driver Details, Vehicle Details, Coverage Premium Details, Contact Information Details.
*/
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC5659 @ Verify PA Confirmation Page")
	public void testPAPolicyConfirmationPageDetails(String browserName) throws Exception {
		pagefactory.quoteAndBuyPABasePolicyWithMonthlySavingAccountPayment().validatePAConfirmationPageDetails();
	}

	/**
	 * @formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify the effective date must be in the future
	 
	             Actual :- 
	            		1. Complete the landing page.
					2. Enter all the required fields - First Name, Last Name, Date of Birth, Address 1, City, State, Email Address.
					3. Attempt to start the coverage in the past
	
	             Expected :- 
		            1. Your Information page is loaded successfully.
					2. All fields are entered successfully.
					3. "Value must be a date in the future"" must be displayed.
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5649 @ Verify the effective date must be in the future")
	public void testPAPolicyEffectiveDateMustBeFuture(String browserName) {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage()
				.setYourInfoPageDetails().withCoverage(DateUtil.getPastDateUsingDays());
		infoPage.goNext();
		infoPage.isCoverageDateFutureErrorPresent()
				.shouldBeEqual("Coverage Details must be in Future Error is not present");
	}

	/**
	 * @formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Verify the Your Information page - Save Point
	 
	             Actual :- 
	            		1. Complete the landing page.
					2. Enter all the required fields - First Name, Last Name, Date of Birth, Address 1, City, State, Email Address and coverage start.
					3. Click on Next
					4. Login to PC and search for the Quote number that was generated above.
					5. Verify the submission status."
	
	             Expected :- 
		            1. Your Information page is loaded successfully.
					2. All fields are entered successfully.
					3. The Qualification page is loaded, note the auto Insurance Quote number in the header.
					4. This is a save point so all data which you have enter so far should be saved to the PC in draft format. The Information saved in the Your Info page will be present in the Account Summary page.
					5. Submission status should be Draft.
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5648 @ Verify the Your Information page - Save Point")
	public void testPASubmissionAfterYourInfoSavePoint(String browserName) throws Exception {
		pagefactory.setPolicyDataUpToYourInfoPage().goToQualificationPage();
		pagefactory.getYourInfoPage().areYourInfoPageDataMatchingWithBackEnd()
				.shouldBeTrue("Your Info details are not saved in back end");
		QuoteInfoBar.isSubmissionInDraftStatus().shouldBeEqual("Submission status is not Draft");
	}

	/**
	 * @formatter:off
 		@param browserName
	 	Test Description :- Verify Vehicles page - Save Point
	 
	             Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page
					5. Vehicles page is loaded. Fill in all the required fields - VIN, Make, Model, Year, License Plate, State, Cost New.
					6. Click No - Note the quote number in the top header.
					7. Login to PC and search for the Quote number that was generated above.
					8. Verify the submission status.
	
	             Expected :- 
		            1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Vehicles page is loaded.
					5. The fields should be successfully populated.
					6. Pop up message - ""Calculating Quote"" will appear.
					7. All information entered up to the quote stage should be entered in PC, verify that this data is correct.
					8. Status of the submission should be "Quoted"
		@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "TC5654 @ PA - Verify Vehicles page - Save Point")
	public void testPASubmissionAfterVehiclePageSavePoint(String browserName) throws Exception {
		pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		String jsondata = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				new QuoteInfoBar().getSubmissionNumber());
		new QualificationPage().arePAQualificationAnswersMatchingBackEnd(jsondata)
				.shouldBeTrue("Qualification answers are not matching with Back End");
		DriverDetailsPage.areDriverDetailsMatchingBackEnd(jsondata)
				.shouldBeTrue("Driver Details are not matching with Back End");
		VehicleDetailsPage.areVehicleDetailsMatchingBackEnd(jsondata)
				.shouldBeTrue("Vehicle Details are not matching with Back End");
		QuoteInfoBar.isSubmissionInQuotedStatus(jsondata).shouldBeEqual("Submission status is not Quoted");
	}

	/**
	 * @formatter:off
 		@param browserName
	 	Test Description :- Verify user can move back in wizard
	 
	             Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. Click on the ""Your Info"" link on the wizard.
	
	             Expected :- 
		            1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. Verify the ""Your Info"" page is loaded and the details are saved as when you logged them.
		@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC5667 @ Verify user can move back in wizard")
	public void testUserCanGoBackToPreviousScreen(String browserName) {
		pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage().buyStandardPolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage().setPhoneNumber().goToPaymentDetailsPage();
		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		leftNavigationMenuHandler.gotoPaymentDetailsPage().isPaymentDetailsPageLoaded()
				.shouldBeTrue("Payment details page is not loaded");
		PAPolicyInfoPage pInfo = (PAPolicyInfoPage) leftNavigationMenuHandler.gotoPolicyInfo();
		pInfo.isPAPolicyInfoPageLoaded().shouldBeTrue("PA Policy Info page is not opened");
		PAQuotePage pAQuotepage = (PAQuotePage) leftNavigationMenuHandler.gotoQuotePage();
		pAQuotepage.isQuotePageLoaded().shouldBeTrue("PA Quote page is not displayed");
		leftNavigationMenuHandler.gotoVehiclePage().isVehiclePageLoaded().shouldBeTrue("Driver Page is not loaded");
		leftNavigationMenuHandler.gotoDriverPage().isDriverPageLoaded().shouldBeTrue("Driver Page is not loaded");
		leftNavigationMenuHandler.gotoQualificationPage().isQualificationPageLoaded()
				.shouldBeTrue("Qualification page is not loaded");
		leftNavigationMenuHandler.gotoYourInfoPage().isYourInfoPageLoaded()
				.shouldBeTrue("Your Info page is not loaded");
	}

	/**
	 * @formatter:off
 		@param browserName
	 	Test Description :- Retrieve a Quote - validation
	 
	         	Step actions :- :- 
	            		1. Enter a zip code, an incorrect Quote number and Click Go!
	
	            Expected Result:- 
		           	1. Error popup appears - "Sorry, but we can't seem to locate a quote with that number and that ZIP code. Please try again."
		           	
		@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "QB-PA-047 @ Retrieve a Quote - validation")
	public void testQuoteRetrivalUsingInvaliddata(String browserName) {
		pagefactory.getZipCodePage().openRetriveQuotePage().setQuoteRetrivalDetails("XYZ").retriveQuote();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isZipCodeRetrivalErrorPopUpDisplayed()
				.shouldBeEqual("Zip code retrival Error Pop up is not displayed");
		alertHandler.isZipCodeRetrivalErrorPopUpContentEqualsTo()
				.shouldBeEqual("Zip code retrival Error Pop up Content is not matched");
	}

	/**
	 * @formatter:off
 		@param browserName
	 	Test Description :- Verify the Quote page
	 
	             Actual :- 
	            		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Drivers page.
					5. Complete the vehicles page and click No.
					6. Verify 4 Quote options are available.
					7. Two radio buttons for payment method should be availble.
					8. Coverages should be listed.
					9. By default Basic policy should be choosen.
					10. Verify banner on quote page contains correct details.
	
	             Expected :- 
		           	1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The vehicles page is loaded.
					5. Quote page is loaded.
					6. Basic, Standard, Premium and Custom.
					7. Pay in Full and Monthly Installments (Choosen by default)
					8. General coverages and vehicle specific coverages should be listed.
					9. Basic Quote button is highlighted and Buy button will be named ""Buy Now ".
					10. The Banner should contain a Quote number, Location, Vehicles and Drivers included in the quote.
		@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5656 @ Verify the PA Quote page", enabled = false)
	public void validatePAQuotePageDetails(String browserName) throws Exception {
		PAQuotePage paQuotePage = pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage();
		paQuotePage.isQuotePageLoaded().shouldBeTrue("Quote Page is not loaded");
		String jsondata = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				new QuoteInfoBar().getSubmissionNumber());
		paQuotePage.validatePAQuotePageBanner(jsondata).shouldBeTrue();
		paQuotePage.validatePAQuotePageLayout().shouldBeTrue();
		paQuotePage.areBaseCoverageDetailsMatchingBackEnd(jsondata)
				.shouldBeTrue("PA Base coverage details are not matched");
		paQuotePage.areStandardCoverageDetailsMatchingBackEnd(jsondata)
				.shouldBeTrue("PA Standard coverage details are not matched");
		paQuotePage.arePremiumCoverageDetailsMatchingBackEnd(jsondata)
				.shouldBeTrue("PA Premium coverage details are not matched");
	}

	/**
	 @formatter:off
	 @param browserName
	 Test Description :- Verify the Qualification page

	 Actual :-
	 1. Complete the Landing page for vehicle quote
	 2. Complete the Your Info page
	 3.Select Yes for "Have you or any other driver been convicted for moving traffic violations within the past 3 years?
	 If 'Yes' please explain.".
	 4. Click Next.

	 Expected :-
	 1. The Your Information page is loaded.
	 2. The Qualification page is loaded.
	 3. "Please provide the driver name and explain the conviction." mandatory field should appear.
	 4. Error message "This is a required field" should display for "Please provide the driver name and explain the conviction."

	 @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5611 @ PA Qualification page Mandatory fields validation")
	public void testPAQualificationPageMandatoryField(String browserName) {
		QualificationPage qualificationPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage()
				.setYourInfoPageDetails().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("QualificationPage Page is not Loaded");
		qualificationPage.setTrafficeViolationHistory().goNext();
		qualificationPage.isConvictionDetailsFieldMarkedWithMandatoryError().shouldBeEqual("Driver conviction details field is not marked with mandatory error message");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5679 @ Additional Driver Mandatory Fields Validation")
	public void testPAAdditionalDriverPageMandatoryFields(String browserName) {
		//Exisiting defect DE2808
		DriverDetailsPage driverDetailsPage = pagefactory.setPAPolicyDataUpToQualificationPage()
				.goToDriverDetailsPage();
		driverDetailsPage
				.setPrimaryDriverDetails()
				.clickYes()
				.areAdditionalDriverPageFieldsMarkedWithAsterisk().shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" } , description = "TC5677 @ Verify Vehicles page - mandatory fields")
	public void testPAVehiclePageAdditionalVehicleMandatoryFields(String browserName) {
		VehicleDetailsPage vehicleDetailsPage = pagefactory.setPAPolicyDataUpToDriverPage().goToVehicleDetailsPage();
		vehicleDetailsPage.isVehiclePageLoaded().shouldBeTrue("Vehicle Page Page is not Loaded");
		vehicleDetailsPage
				.setVehicleDetails()
				.clickYes();
		vehicleDetailsPage
				.areVehiclePageFieldsMarkedWithAsterisk().shouldBeTrue();
		vehicleDetailsPage.isNextButtonDisabled().shouldBeEqual("Next button is not disabled");
		ThreadLocalObject.getData().put("VIN", "12345678");
		vehicleDetailsPage.setVehicleDetails();
		vehicleDetailsPage.setVehicleDetails().isNextButtonDisabled().shouldNotBeEqual("Next button is disabled");
	}

	/**
	 * @formatter:off
 		@param browserName
	 	Test Description :- NO MANUAL TEST YET
	 
	         	Step actions :- 
	
	            Expected Result:- 
		           	
		@formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" } , description = "No test is available for mapping")
	public void validatePolicyInfoPageMandatoryFields(String browserName) throws Exception {
		pagefactory.setPAPolicyDataUpToVehiclePage().goToPAQuotePage()
				.buyBasePolicyWithMonthlyPayment().goToPAPolicyInfoPage().goNext().isPhoneNumberFieldMakedWithError().shouldBeEqual("Phone number is not marked with mandatory error");
				

	}
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC5668: Moving forward in wizard")
	public void testUserCannotGoForwardToNextScreen(String browserName) {

		QualificationPage qualificationPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage()
				.setYourInfoPageDetails().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("QualificationPage Page is not Loaded");

		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		leftNavigationMenuHandler.isQuotePageDisabled().shouldBeTrue("PA Quote link is enabled");
	}
}