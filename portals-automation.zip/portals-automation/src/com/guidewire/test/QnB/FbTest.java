package com.guidewire.test.QnB;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.portals.qnb.pages.FbPage;
import com.guidewire.portals.qnb.pages.Pagefactory;

public class FbTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = {"Fb"})
	public void testShareContentOnFacebook() {

		FbPage fbPage = pagefactory.quoteAndBuyHOBasePolicyWithMonthlySavingAccountPayment().shareOnFacebook();

		fbPage.typePostText("My text is here");
		fbPage.verifyElementsVisibleOnFbSharePopup().shouldBeTrue("FB elements are NOT present on the popup.");
		fbPage.verifyFbTagsValuesOnFbSharePopup().shouldBeTrue("FB meta-tag content NOT present on the popup");
		fbPage.postOnFacebook();
	}
}
