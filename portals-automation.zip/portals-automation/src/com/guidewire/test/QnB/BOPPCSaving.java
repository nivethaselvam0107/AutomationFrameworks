package com.guidewire.test.QnB;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.pages.CPBOPPolicyInfoPage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;

/**
 * Created by brudroju on 14/08/2017.
 */
public class BOPPCSaving {
    private static Logger LOGGER = Logger.getLogger(BOPPCSaving.class);

    public static void testBOPPaymentDetailsMandatoryFieldsCreditCard(String browserName) throws Exception {
        LOGGER.info("Running Test: TC6159 BOP - Payment Details Saving Point - Credit Card");
        new BOPPCSaving().setData();
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("PaymentMethod", "Credit Card");
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        pagefactory.getCPBOPPolicyInfoPage();
        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.setPhoneField("51234567789").setEmailField("asdfasd@asd.com").setBillingAddress().clickNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.setPaymentPlan().setPaymentMethod(data.get("PaymentMethod")).setCardIssuer(data.get("CreditCardIssuer")).setCardNumber(data.get("CreditCardNumber")).setExpirationDate(data.get("CreditCardExpirationDateMonth"),data.get("CreditCardExpirationDateYear")).purchasePolicy();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("PAYMENT_PLAN_NAME"), data.get("PaymentPlan")).shouldBeEqual("Mismatch in Monthly Plan");
    }

    public static void testBOPPaymentDetailsSavingPointBankAccountSaving(String browserName) throws Exception {
        LOGGER.info("Running Test: TC6154 BOP - Payment Details Saving Point - Bank Account Saving");
        new BOPPCSaving().setData();
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        pagefactory.getCPBOPPolicyInfoPage();
        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.setPhoneField().setEmailField().setBillingAddress().clickNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.setPaymentPlan().setBankPaymentMethod().selectSavingAccountType().setAccountNumber().setABARoutingNumber().setBankName().purchasePolicy();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("PAYMENT_PLAN_NAME"), data.get("PaymentPlan") ).shouldBeEqual("Mismatch in Monthly Plan");
    }

    public static void testBOPPaymentDetailsSavingPointBankAccountChecking(String browserName) throws Exception {
        LOGGER.info("Running Test: TC5026 BOP - Payment Details Saving Point - Bank Account Checking");
        new BOPPCSaving().setData();
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        pagefactory.getCPBOPPolicyInfoPage();
        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.setPhoneField().setEmailField().setBillingAddress().clickNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.setPaymentPlan().setBankPaymentMethod().selectCheckingAccountType().setAccountNumber().setABARoutingNumber().setBankName().purchasePolicy();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("PAYMENT_PLAN_NAME"), data.get("PaymentPlan") ).shouldBeEqual("Mismatch in Monthly Plan");
    }

    public static void testBOPQuoteSavingPoint(String browserName) throws Exception {
        LOGGER.info("Running Test: TC5024 BOP - Quote Saving Point");
        HashMap<String, String> data = ThreadLocalObject.getData();
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(backEndData.get("COV_START_DATE"), DateUtil.formatDateTo(data.get("Quote_Cov_Date"), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in Start Date");
        new Validation(backEndData.get("COV_END_DATE"), DateUtil.formatDateTo(DateUtil.getFutureDate(366), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in End Date");
        new Validation(backEndData.get("PrimaryAddress"), data.get("PrimaryAddress")).shouldBeEqual("Primary Address did not match");
        new Validation(backEndData.get("AddressType"), "business").shouldBeEqual("Address type did not match");
        new Validation(backEndData.get("QUOTE_ANNUAL_VALUE"), data.get("QUOTE_TOTAL_COST")).shouldBeEqual("Premium Value did not match");
        new Validation(backEndData.get("QUOTE_ANNUAL_BEFORE_TAX_VALUE"), data.get("QUOTE_TOTAL_PREMIUM")).shouldBeEqual("Premium Value before tax did not match");
        new Validation(backEndData.get("QUOTE_TAXES"), data.get("QUOTE_TAXES")).shouldBeEqual("Taxes did not match");
    }

    public static void testBOPPolicyInfoSavingPoint(String browserName) throws Exception {
        LOGGER.info("Running Test: TC5025 BOP - Policy Info Saving Point");
        HashMap<String, String> data = ThreadLocalObject.getData();
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("COV_START_DATE"), DateUtil.formatDateTo(data.get("Quote_Cov_Date"), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in Start Date");
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("COV_END_DATE"), DateUtil.formatDateTo(DateUtil.getFutureDate(366), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in End Date");
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("PrimaryAddress"), data.get("PrimaryAddress")).shouldBeEqual("Primary Address did not match");
        pagefactory.getCPBOPPolicyInfoPage();
        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.setPhoneField().setEmailField().setBillingAddress().clickNext();
        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.setPaymentPlan().setBankPaymentMethod().selectSavingAccountType().setAccountNumber().setABARoutingNumber().setBankName().purchasePolicy();
        jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("EmailAddress"),data.get("Email") ).shouldBeEqual("Mismatch in Email Address");
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("PhoneNumber").replace("-",""), data.get("Phone")).shouldBeEqual("Mismatch in Phone Number");
    }

    public static void testBOPAddBuilding(String browserName) throws Exception {
        LOGGER.info("Running Test: TC4700 BOP - Add Building");
        Pagefactory pagefactory = new Pagefactory();
        new BOPPCSaving().setData();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPAddBld();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("NumberOfBuildings"), "2").shouldBeEqual("Mismatch in number of buildings, building not added");
    }

    public static void testBOPRemoveBuilding(String browserName) throws Exception {
        LOGGER.info("Running Test: TC4682 BOP - Remove Building");
        Pagefactory pagefactory = new Pagefactory();
        new BOPPCSaving().setData();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPAddBld();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("NumberOfBuildings"), "2").shouldBeEqual("Mismatch in number of buildings, building not added");
        pagefactory.removeBuilding();
        refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("NumberOfBuildings"), "1").shouldBeEqual("Mismatch in number of buildings, building not removed");
    }

    public static void testBOPAddLocation(String browserName) throws Exception {
        // Neeed to check with Address 2 and 3 with Dharmesh, not retruning data from Backend, Location Issues
        LOGGER.info("Running Test: TC5021 BOP - Add Location");
        HashMap<String, String> data = ThreadLocalObject.getData();
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataToAddLocation();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        StringBuilder sb = new StringBuilder();
        sb.append(" ");
        sb.append(data.get("NewLocation_AddressLine1"));
        sb.append(" ");
        /*sb.append(data.get("NewLocation_AddressLine2"));
        sb.append(" ");
        sb.append(data.get("NewLocation_AddressLine3"));
        sb.append(" ");*/
        sb.append(data.get("NewLocation_City"));
        sb.append(" ");
        sb.append(data.get("StateValue"));
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(backEndData.get("NewLocation_AddressLine").trim(), sb.toString().trim()).shouldBeEqual("Mismatch in Address for New Location");
        new Validation(backEndData.get("NewLocation_LocationCode"),data.get("NewLocation_LocationCode")).shouldBeEqual("Mismatch in New Location, Location Code");
        new Validation(backEndData.get("NewLocation_Phone").replaceAll("-", ""), data.get("NewLocation_Phone")).shouldBeEqual("Mismatch in Phone Number for New Location");
        new Validation(backEndData.get("NewLocation_FireProtection"), "1").shouldBeEqual("Mismatch in fire protection for New Location");
        new Validation(backEndData.get("LOCATION_SIZE"), "2").shouldBeEqual("Location Not Added");

    }

    public static void testBOPRemoveLocation(String browserName) throws Exception {
        LOGGER.info("Running Test: TC5022 BOP - Remove Location");
        HashMap<String, String> data = ThreadLocalObject.getData();
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataToAddRemoveLocation();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData).get("LOCATION_SIZE"), "1").shouldBeEqual("Location Not Removed");
    }

    public static void testBOPYourInfoPageSavingPoint(String browserName) throws Exception {
        LOGGER.info("Running Test: TC4621 BOP - Your Info Page Saving Point");
        HashMap<String, String> data = ThreadLocalObject.getData();
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillYourInfoPage();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        String emailID="asdfasd@asd.com";
        String contactName="SampleCompany";
        String addressType="business";
        String termType = "Annual";
        String smallBusinessType = "wholesale";
        String accountOrgType = "llc";

        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);
        new Validation(backEndData.get("CompanyName"),contactName).shouldBeEqual("Mismatch in Company Name");
        new Validation(backEndData.get("TermType"), termType).shouldBeEqual("Term Type did not match");
        new Validation(backEndData.get("COV_START_DATE"), DateUtil.formatDateTo(data.get("Quote_Cov_Date"), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in Start Date");
        new Validation(backEndData.get("COV_END_DATE"), DateUtil.formatDateTo(DateUtil.getFutureDate(366), "MMMMM d, YYYY" )).shouldBeEqual("Mismatch in End Date");
        new Validation(backEndData.get("SmallBusinessType"), smallBusinessType).shouldBeEqual("Small Business Type did not match");
        new Validation(backEndData.get("AccountOrgType"), accountOrgType).shouldBeEqual("Organization Type did not match");
        new Validation(backEndData.get("emailID"), emailID).shouldBeEqual("Mismatch in Email Address");
        new Validation(backEndData.get("AddressType"), addressType).shouldBeEqual("Address Type did not match");
        new Validation(backEndData.get("PrimaryAddress"), data.get("PrimaryAddress")).shouldBeEqual("Primary Address did not match");
    }

    public static void testBOPQualificationPageSavingPoint(String browserName) throws Exception {
        LOGGER.info("Running Test: TC4623 BOP - Qualification Page Saving Point");

        String rentEquipment = "false";
        String policyRejected = "false" ;
        String foreClosure = "false" ;
        String hazardousMaterial = "false" ;
        String athleticTeams = "false" ;
        String flammables = "false" ;
        String otherBusiness2 = "false" ;
        String leaseEmployees = "true" ;
        String personnelIssues = "false" ;
        String subContractorCerts = "null" ;
        String applicantArson = "false" ;
        String catastrophe = "false" ;
        String subContractors = "false" ;
        String manufacturing = "false" ;
        String fireCode = "false" ;
        String otherInsurance = "false" ;
        String workersComp = "true" ;

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillQualificationPageSavingPoint();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);

        new Validation(backEndData.get("rentEquipment"),rentEquipment).shouldBeEqual("Mismatch in Rent Equipment Question");
        new Validation(backEndData.get("policyRejected"),policyRejected).shouldBeEqual("Mismatch in Policy Rejected Question");
        new Validation(backEndData.get("foreClosure"),foreClosure).shouldBeEqual("Mismatch in fore Closure Equipment Question");
        new Validation(backEndData.get("hazardousMaterial"),hazardousMaterial).shouldBeEqual("Mismatch in hazardousMaterial Question");
        new Validation(backEndData.get("athleticTeams"),athleticTeams).shouldBeEqual("Mismatch in athleticTeams Question");
        new Validation(backEndData.get("flammables"),flammables).shouldBeEqual("Mismatch in flammables Question");
        new Validation(backEndData.get("otherBusiness2"),otherBusiness2).shouldBeEqual("Mismatch in otherBusiness2 Question");
        new Validation(backEndData.get("leaseEmployees"),leaseEmployees).shouldBeEqual("Mismatch in leaseEmployees Question");
        new Validation(backEndData.get("personnelIssues"),personnelIssues).shouldBeEqual("Mismatch in personnelIssues Question");
        new Validation(backEndData.get("subContractorCerts"),subContractorCerts).shouldBeEqual("Mismatch in subContractorCerts Question");
        new Validation(backEndData.get("applicantArson"),applicantArson).shouldBeEqual("Mismatch in applicantArson Question");
        new Validation(backEndData.get("catastrophe"),catastrophe).shouldBeEqual("Mismatch in catastrophe Question");
        new Validation(backEndData.get("subContractors"),subContractors).shouldBeEqual("Mismatch in subContractors Question");
        new Validation(backEndData.get("manufacturing"),manufacturing).shouldBeEqual("Mismatch in manufacturing Question");
        new Validation(backEndData.get("fireCode"),fireCode).shouldBeEqual("Mismatch in fireCode Question");
        new Validation(backEndData.get("otherInsurance"),rentEquipment).shouldBeEqual("Mismatch in otherInsurance Question");
        new Validation(backEndData.get("otherInsurance"),otherInsurance).shouldBeEqual("Mismatch in otherInsurance Question");
        new Validation(backEndData.get("workersComp"),workersComp).shouldBeEqual("Mismatch in workersComp Question");
    }

    public static void testBOPConfirmationSavingPoint(String browserName) throws Exception {
        // Confirm Validation for Coverages and Contact Information
        LOGGER.info("Running Test: TC5979 BOP - Confirmation Saving Point");
        new BOPPCSaving().setData();
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("Quote_Cov_Date", DateUtil.getFutureDate(1));
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataTillBOPQuotePageAndGoNext();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        pagefactory.getCPBOPPolicyInfoPage();
        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.setPhoneField().setEmailField().setBillingAddress().clickNext();
        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.setPaymentPlan().setBankPaymentMethod().selectSavingAccountType().setAccountNumber().setABARoutingNumber().setBankName().purchasePolicy();
        PolicyConfirmationPage pcp = pagefactory.getConfirmationPage();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEnd(jsonData);
        HashMap<String, String> uiData = pcp.getPolicySummary();
        new Validation(backEndData.get("ACCOUNT_NUMBER"),uiData.get(("ACCOUNT_NUMBER"))).shouldBeEqual("Mismatch in account number");
        new Validation(backEndData.get("POLICY_NUMBER"),uiData.get(("POLICY_NUMBER"))).shouldBeEqual("Mismatch in policy number");
        new Validation(backEndData.get("POLICY_PERIOD"),uiData.get(("POLICY_PERIOD"))).shouldBeEqual("Mismatch in policy period");
        new Validation(uiData.get("POLICY_TOTAL_AMOUNT").contains(backEndData.get("POLICY_TOTAL_AMOUNT"))).shouldBeTrue("Mismatch in policy total amount");
        new Validation(backEndData.get("PAYMENT_PLAN_NAME"),uiData.get(("PAYMENT_PLAN_NAME"))).shouldBeEqual("Mismatch in payment plan nam");
        new Validation(uiData.get("POLICY_CURRENT_PAYMENT").contains(backEndData.get("POLICY_CURRENT_PAYMENT"))).shouldBeTrue("Mismatch in policy current payment");

    }

    public static void testBOPAdditionalCoveragesSavingPoint(String browserName) throws Exception {
        // Issues not saving data: Failing
        LOGGER.info("Running Test: TC4965 BOP - Additional Coverages Saving Point");
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataForAdditionalCoveragesSavingPoint();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEnd(jsonData);
    }

    public static void testBOPGeneralCoveragesSavingPoint(String browserName) throws Exception {
        LOGGER.info("Running Test: TC4927 BOP - General Coverages Saving Point");
        new BOPPCSaving().setData();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setBOPEntryPoint();
        pagefactory.setDataForGeneralCoveragesSavingPoint();
        String refereNumber  = new QuoteInfoBar().getSubmissionNumber();
        String jsonData =  DataFetch.getQuoteAsJsonData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
        HashMap<String, String> backEndData = new ParseQuoteData().getPolicySummaryDataFromBackEndForBOP(jsonData);

        String PERSONAL_ADVERTISING_INJURY_SELECTED = "false";
        String PD_DEDUCTIBLE_VALUE = "250";
        String SPECIAL_COVERAGE_PACKAGE = "[Merchant's Risk Pack]";
        String HIRED_AUTO_SELECTED = "true";
        String NON_OWNED_AUTO_LIABILITY_SELECTED = "true";
        String PROP_COV_DEDUCATABLE = "2500";
        String CAUSE_OF_LOSS = "Named Perils";
        new Validation(backEndData.get("PERSONAL_ADVERTISING_INJURY_SELECTED"),PERSONAL_ADVERTISING_INJURY_SELECTED).shouldBeEqual("Mismatch in PERSONAL_ADVERTISING_INJURY_SELECTED");
        new Validation(backEndData.get("PD_DEDUCTIBLE_VALUE"),PD_DEDUCTIBLE_VALUE).shouldBeEqual("Mismatch in PD_DEDUCTIBLE_VALUE");
        new Validation(backEndData.get("SPECIAL_COVERAGE_PACKAGE"),SPECIAL_COVERAGE_PACKAGE).shouldBeEqual("Mismatch in SPECIAL_COVERAGE_PACKAGE");
        new Validation(backEndData.get("HIRED_AUTO_SELECTED"),HIRED_AUTO_SELECTED).shouldBeEqual("Mismatch in HIRED_AUTO_SELECTED");
        new Validation(backEndData.get("NON_OWNED_AUTO_LIABILITY_SELECTED"),NON_OWNED_AUTO_LIABILITY_SELECTED).shouldBeEqual("Mismatch in NON_OWNED_AUTO_LIABILITY_SELECTED");
        new Validation(backEndData.get("PROP_COV_DEDUCATABLE"),PROP_COV_DEDUCATABLE).shouldBeEqual("Mismatch in PROP_COV_DEDUCATABLE");
        new Validation(backEndData.get("CAUSE_OF_LOSS"),CAUSE_OF_LOSS).shouldBeEqual("Mismatch in CAUSE_OF_LOSS");
    }


    private void setData(){
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("Phone", "5123456778");
        data.put("Email", "asdfasd@asd.com");
        data.put("PaymentPlan","Monthly 10" );
        data.put("AccountNumber", "123456");
        data.put("RoutingNumber", "2563");
        data.put("BankName", "AIB");
        data.put("Quote_Cov_Date", DateUtil.getFutureDate(1));
        data.put("NewLocation_AddressLine1", "Street 1");
        data.put("NewLocation_AddressLine2", "Street 2");
        data.put("NewLocation_AddressLine3", "Street 3");
        data.put("NewLocation_City", "Foster City");
        data.put("NewLocation_ZipCode", "94404");
        data.put("NewLocation_State", "California");
        data.put("NewLocation_LocationCode", "2500");
        data.put("NewLocation_Phone", "5897456321");
        data.put("NewLocation_FireProtection", "Superior");
        data.put("CreditCardIssuer", "MasterCard");
        data.put("CreditCardNumber", "7894561236589525");
        data.put("CreditCardExpirationDateMonth", "June");
        data.put("CreditCardExpirationDateYear", "2020");
        if(System.getProperty("platform").equalsIgnoreCase("Diamond")){
        	data.put("PrimaryAddress", data.get("AddressLine1") + " " + data.get("AddressLine2") + " " + data.get("City") + " " + data.get("StateValue") + " "+ data.get("ZipCode"));
        } else {
        	data.put("PrimaryAddress", data.get("AddressLine1") + " " + data.get("AddressLine2") + " " + data.get("AddressLine3") + " " +data.get("City") + " " + data.get("StateValue") + " "+ data.get("ZipCode"));
        }
      }

}
