package com.guidewire.test.QnB;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.ConstructionPage;
import com.guidewire.portals.qnb.pages.DiscountPage;
import com.guidewire.portals.qnb.pages.HOPolicyInfoPage;
import com.guidewire.portals.qnb.pages.HOQuotePage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.YourHomePage;
import com.guidewire.portals.qnb.pages.YourInfoPage;

public class HOUIValidationTest {

	Pagefactory pagefactory = new Pagefactory(ThreadLocalObject.getData());

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify HO Icon functionality
	 * 
	 *             Step actions :
		 *             1. Enter a valid ZIP Code. 
		 *             2. Click on the House icon. 
		 *             3. Click on Go!
	 *             
	 *             Expected Results :
		 *             1. ZIP code is populated. 
		 *             2. The house icon is highlighted. 
		 *             3. The HO Your Information page is loaded.
	 *             
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5617 @ Verify HO Icon functionality")
	public void testHOYourInfoPageLoading(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setAddressManually().isYourInfoPageLoaded().shouldBeTrue("Your Info page is not loaded");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Your Information page - mandatory fields
	 * 
	 *             Step actions :
	               	1. Complete the landing page
					2. Click the Next button"
	 *             
	 *            Expected Results :
	 *           	1. The Your Information page is loaded.
					2. Verify that all field labels with a red * have the following message, This is a required field. 
						The following fields should have this message. First Name, Last Name, Address Line 1, City, State, Email Address and Coverage start."
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4270 @ HO Your Info Page Mandatory Fields Validation")
	public void testHOYourInfoPageMandatoryFields(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setAddressManually().goNext().areYourPageFieldsMakedWithMandatoryError().shouldBeTrue();
		infoPage.areYourPageFieldsMakedWithAsterisk().shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the HO Your Information page - Save Point
	 * 
	 *             Step actions :
	               1. Complete the landing page.
				   2. Enter all the required fields - First Name, Last Name, Address 1, City, State, Email Address and coverage start.
				   3. Click on Next
                   4. Login to PC and search for the Quote number that was generated above.
                   5. Verify the submission status."
	 *             
	 *            Expected Results :
	 *            1. Your Information page is loaded successfully.
                   2. The Zip Code will be auto filled from landing page.
                   3. The Qualification page is loaded, note the Homeowners Insurance Quote number in the header.
                   4. This is a save point so all data which you have enter so far should be saved to the PC in draft format. The Infomation saved in the Your Info page will be present in the Account Summary page.
                   5. Submission status should be Draft."
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "HOP" }, description = "TC4266 @ Verify the HO Your Information page - Save Point & QB-465:HOP Verify the Landing page when choosing HO")
	public void testHOYourInfoPageSavePoint(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setYourInfoPageDetails().goToQualificationPage();
		String quoteDataBackEnd = DataFetch.getQuoteAsJsonData();
		infoPage.areYourInfoPageDataMatchingWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("Your Info page details are not matching back end.");
		QuoteInfoBar.isSubmissionInDraftStatus(quoteDataBackEnd).shouldBeEqual("Submission is not in Draft status");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the HO Qualification page
	 * 
	 *             Step actions :
	               	1. Complete the Landing page
					2. Complete the Your Info page
					3. Answer "No" to "Any coverage declined…."
					4. Answer "No" to "Any business conducted..."
					5. Click Next.
	 *             
	 *            Expected Results :
	 *            	1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. Radio slider is in the No position.
					4. Radio slider is in the No position.
					5. The "Your Home" page is loaded.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4272 @ Verify the HO Qualification page")
	public void testQualificationPageLoadingAndDataVerification(String browserName) throws Exception {
		QualificationPage qualificationPage = pagefactory.setHOPolicyDataUpToYourInfoPage().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("Qualification page is not loaded");
		qualificationPage.setQualificationPageDetails().areHOQualificationAnswersSaved()
				.shouldBeTrue("HO Qualification answers are not saved");
		qualificationPage.goToYourHomePage().isYourHomePageLoaded().shouldBeTrue("Your Home page is not loaded");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- 
	 
	            Expected :
					1. Complete the Landing page
					2. Complete the Your Info page
					3. Click on Next on Qualification page without providing details.
	              
	            Actual :
	            		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. Error message "This is a required field" should be displayed for "Any coverage declined, cancelled or non-renewed in past 5 years?" and "Any business conducted on the premises?"
	            
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC5612 @ HO Qualification Page Mandatory Fields Validation")
	public void testHOQualificationPageMandatoryFields(String browserName) throws Exception {
		QualificationPage qualificationPage = pagefactory.setHOPolicyDataUpToYourInfoPage().goToQualificationPage();
		qualificationPage.isQualificationPageLoaded().shouldBeTrue("Qualification page is not loaded");
		qualificationPage.goNext().areHOQualificationPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Qualification page mandatory fields are not marked with error");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the Your Home page
	 * 
	              Step actions :
	             	1. Complete the Landing page
					2. Complete the Your Info page
					3. Complete the Qualification page
					4. Enter 500000 in Estimated house value.
					5. Location Type - In City Limits
					6. Residence Type - 1 Family Residence
					7. Distance to Fire Hydrant - Within 500ft
					8. Distance to Fire Station - Within 5 miles.
					9. Within 300ft of Commercial property - No.
					10. Flooding/Fire Hazard - No.
					11. Use your home as a - Primary.						
					12. Your Home is - Owner Occupied
					13. Click on Next"

	             Expected Results :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. N/A
					5. In City Limits selected
					6. 1 Family Residence is selected.
					7. Slider is on the ""Within 500ft"" position
					8. Slider is on the ""Within 5 miles"" position
					9. Slider is on the ""No"" position
					10. Slider is on the ""No"" position
					11. "Primary"" is selected.
					12. ""Owner Occupied"" is selected
					13. Construction page is loaded."
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4273 @ Verify the Your Home page")
	public void testHOYourHomePageLoadingAndDataVerification(String browserName) throws Exception {
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocType", "In Protected Suburb");
		}
		YourHomePage homePage = pagefactory.setHOPolicyDataUpToQualificationPage().goToYourHomePage();
		homePage.isYourHomePageLoaded().shouldBeTrue("Your home page is not loaded");
		homePage.setYourHomePageDetails().areYourHomePageFieldsValuesAreSaved()
				.shouldBeTrue("HO Your Home values are not saved");
		homePage.goToConstructionPage().isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify HO Your Home - mandatory fields
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. On the Your Home page, click Next"

	             
	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. Verify that all field labels with a red * have the following message, ""This is a required field".
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4276 @ Verify HO Your Home - mandatory fields")
	public void testHOYourHomePageMandatoryFields(String browserName) throws Exception {
		YourHomePage homePage = pagefactory.setHOPolicyDataUpToQualificationPage().goToYourHomePage();
		homePage.goNext().areYourHomePageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Your Home page mandatory fields are not marked with error");
		homePage.areYourHomePageMandatoryFieldsMakedWithAsterisk().shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Construction page
	 
	             Step actions  :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page
					5. Year Build - 1999
					6. Number of Stories - 1
					7. Garage - No Garage
					8. Construction Type - Concrete
					9. Foundation Type - Slab
					10. Roof - Composition Shingles....
					11. Plumbing - Copper
					12. Heating - Electricity
					13. Secondary Heating - Yes
					14. Electrical Wiring - Copper
					15. Electrical system - Circuit Breaker
					16. Click Next"

	             
	             Expected Results :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Drivers page is loaded.
					4. The Construction page is loaded.
					5. N/A
					6. 1 is selected
					7. No Garage radio button is selected.
					8. "Concrete" is selected
					9. "Slab" is selected
					10. "Composition Shingles...." is selected
					11. "Copper" is selected.
					12. "Electricity" is selected.
					13. "Yes" radio slider selected.
					14. "Copper" is selected.
					15. "Circuit Breaker" is selected
					16. Discount page is loaded."
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC4966 @ Verify Construction page")
	public void testHOConstructionPageLoadingAndDataVerification(String browserName) {
		ConstructionPage constructionPage = pagefactory.setHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.setConstructionPageDetails().areConstructionPageDetailsSaved()
				.shouldBeTrue("Construction page details are not saved");
		constructionPage.goToDiscountPage().isDiscountPageLoaded().shouldBeTrue("Construction Page should be loaded");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Construction page - mandatory fields
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Click Next on the Construction page"

	             
	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. Verify that all field labels with a red * have the following message, "This is a required field".
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4273 @ Verify Construction page - mandatory fields")
	public void testHOConstructionPageMandatoryFields(String browserName) {
		ConstructionPage constructionPage = pagefactory.setHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.goNext().areConstructionPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Construction page fields are not marked with error");
		constructionPage.areConstructionPageMandatoryFieldsMakedWithAsterisk()
		.shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the Discount page
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Fire Extinguishers in Your Home - YES
					7. Burglar Alarm - YES
					8. Specify Type: Central Station
					9. Fire Alarm Reporting To Monitoring Center  - YES
					10. Smoke Alarms - YES
					11. Alarms are on all floors - YES
					12. Deadbolts - YES 
						 Enter number of deadbolts
					13. Residence Visible to Neighbours - YES
					14. Sprinkler System Type - None
					15. Click Next

	             
	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. YES is selected.
					7. YES is selected.
					8. Central Station is selected.
					9. YES is selected.
					10. YES is selected.
					11. YES is selected.
					12. YES is selected.
					13. YES is selected.
					14. None is selected.
					15. Quote page is loaded.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4967 @ Verify the Discount page")
	public void testHODiscountPageLoadingAndDataVerification(String browserName) throws Exception {
		DiscountPage discountPage = pagefactory.setHOPolicyDataUpToConstructionPage().withUpgradeYear()
				.goToDiscountPage();
		discountPage.isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.setDiscountPageDetails().withAdditionalDiscountDetails();
		discountPage.areDiscountPageValueSaved().shouldBeTrue("Discount page details are not saved");
		discountPage.areAdditionalDiscountPageValueSaved().shouldBeTrue("Additional discount details are not saved");
		discountPage.goToHOQuotePage().isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the Discount page - Save Point
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Fire Extinguishers in Your Home - YES
					7. Burglar Alarm - YES
					8. Specify Type: Central Station
					9. Fire Alarm Reporting To Monitoring Center  - YES
					10. Smoke Alarms - YES
					11. Alarms are on all floors - YES
					12. Deadbolts - YES
					13. Residence Visible to Neighbours - YES
					14. Sprinkler System Type - None
					15. Click Next
					16. Login to PC and search for the submission number.
					17. Verify submission status

	             
	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. YES is selected.
					7. YES is selected.
					8. Central Station is selected.
					9. YES is selected.
					10. YES is selected.
					11. YES is selected.
					12. YES is selected.
					13. YES is selected.
					14. None is selected.
					15. Quote page is loaded.
					16. All data entered per submission form should be present and correct in PC.
					17. Submission should have a draft status.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4968 @ Verify the Discount page - Save Point")
	public void testHODiscountPageSavePoint(String browserName) throws Exception {
		ThreadLocalObject.getData().put("DistanceToFireHydrantValue", "250");
		if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocTypeValue", "prot");
		}
		DiscountPage discountPage = pagefactory.setHOPolicyDataUpToConstructionPage().withUpgradeYear()
				.goToDiscountPage();
		discountPage.isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.setDiscountPageDetails().withAdditionalDiscountDetails();
		discountPage.goToHOQuotePage().isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		String jsonData = DataFetch.getQuoteAsJsonData();
		//QuoteInfoBar.isSubmissionInQuotedStatus(jsonData).shouldBeEqual("Submission is not in Quote status");
		discountPage.areDiscountPageDetailsWithAdditionalMatchingBackEnd(jsonData)
				.shouldBeTrue("Discount page details are not saved");
		new ConstructionPage().areConstructionPageDetailsMatchingBackEnd(jsonData)
				.shouldBeTrue("Construction page details are not saved");
		new YourHomePage().areYourHomePageFieldsValuesMatchingBackEnd(jsonData)
				.shouldBeTrue("Home page details are not saved");
		new YourInfoPage().areYourInfoPageDataMatchingWithBackEnd(jsonData).shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Additional discounts validation checks
	 
	             Step actions  :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Fire Extinguishers in Your Home - YES
					7. Burglar Alarm - YES
					8. Specify Type: Central Station
					9. Fire Alarm Reporting To Monitoring Center  - YES
					10. Smoke Alarms - YES
					11. Alarms are on all floors - YES
					12. Deadbolts - YES
					13. Residence Visible to Neighbours - YES
					14. Sprinkler System Type - None
					15. Expand Additional (optional) link
					16. Roomers or Boarders - Yes
					17. Number of Units - 1
					18. Fireplace or Wood Stove - Yes
					19. Swimming Pool - Yes
					20. Trampoline - Yes
					21. Water leakage or flooding in the past 5 years? - Yes
					22. Click Next

	             Expected Results :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. YES is selected.
					7. YES is selected.
					8. Central Station is selected.
					9. YES is selected.
					10. YES is selected.
					11. YES is selected.
					12. YES is selected.
					13. YES is selected.
					14. None is selected.
					15. Addtionals discounts are displayed.
					16. "Specify number of boarders" is displayed
					17. 1 Unit is selected
					18. "Specify number of fireplaces or wood stoves" is displayed.
					19. "Is the property fenced?". is displayed. "Is there a diving board?" is displayed.
					20. "Trampoline has a safety net". is displayed.
					21. YES is selected.
					22. "This is a required field" validation message appears. Submission will not proceed due to validation messages.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4986 @ Additional Discounts Validation")
	public void testHODiscountMandatoryFieldsValidation(String browserName) throws Exception {
		DiscountPage discountPage = pagefactory.setHOPolicyDataUpToConstructionPage().withUpgradeYear()
				.goToDiscountPage();
		discountPage.isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		discountPage.goNext().areHODiscountPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Discount page fields are not marked with error");
		discountPage.expandAdditionalPage().generateErrorMSgForAdditionalFields();
		discountPage.areHOAdditionalDiscountPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Additional Discount fields are not marked with error");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the Quote page
	 
	             Step actions  :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Verify the coverages.
					8. Click on Buy Base Policy

	             Expected Results :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded, Base quote and Monthly payment option should be selected by default. 
					7. All the coverages should be listed.
					8. Updating quote pop up appears. Then the Policy Info page is loaded.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE_EMR" }, description = "TC4969 @ Verify the Quote page")
	public void testHOQuotePageLoadingAndBaseCoverageValidation(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage();
		hoQuotePage.isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not loaded");
		hoQuotePage.validateHOQuotePageLayout().shouldBeTrue();
		hoQuotePage.areHOQuoteBaseCoverageDataMatchingWithBackEnd()
				.shouldBeTrue("HO Base Coverage value are not matched with the Back End");
		hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().isHOPolicyInfoPageLoaded()
				.shouldBeTrue("HO Policy info page is not loaded");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the HO Policy Info page
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Complete the Quote page.
					8. Verify the Coverage start date is correct.
					9. Verify Primary Insured, Address and coverages are correct.
					10. Is Billing address.... ? Yes
					11. Enter an Email address is empty.
					12. Enter a Phone number is empty.
					13. Click Next

	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded
					7. The Policy Info page is loaded.
					8. The coverage start date should be as entered in the "Your Info" page.
					9. Primary Insured, Address and coverages should be as entered previously.
					10. Yes is selected.
					11. Email field is populated.
					12. Phone field is populated.
					13. Payment details page is loaded.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4970 @ Verify the HO Policy Info page")
	public void testHOPolicyInfoPageLoadingAndCoverageValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
		String quoteDataBackEnd = DataFetch.getQuoteAsJsonData();
		hoPolicyInfoPage.validateCoverageDateWithBackEnd(quoteDataBackEnd)
		.shouldBeEqual("Policy Coverage start date is not matched on policy Info page");
		hoPolicyInfoPage.validatePolicyAddressWithBackEnd(quoteDataBackEnd)
				.shouldBeEqual("Policy address is not matched on policy Info page");
		hoPolicyInfoPage.validatePrimaryInsuredPersonNameWithBackEnd(quoteDataBackEnd)
				.shouldBeEqual("Primary Insured Person name is not mactched on policy Info page");
		hoPolicyInfoPage.validatePolicyAddressWithBackEnd(quoteDataBackEnd)
				.shouldBeEqual("Primary Insured Person name is not mactched on policy Info page");
		hoPolicyInfoPage.areHOQuoteBaseCoverageDataMatchingWithBackEnd(quoteDataBackEnd)
				.shouldBeTrue("HO Base Coverage value are not matched with the Back End on the policy info page.");
		hoPolicyInfoPage.isPolicyBillingAddressOptionSelectedByDefault()
				.shouldBeTrue("Billing addess option is is not selected Yes by default");
		hoPolicyInfoPage.setPolicyInfoPageDetails().isEmailSaved().shouldBeEqual("Email value is not saved");
		hoPolicyInfoPage.isPhoneSaved().shouldBeEqual("Email field is not saved");
		hoPolicyInfoPage.goToPaymentDetailsPage().isPaymentDetailsPageLoaded()
				.shouldBeTrue("Policy Payment page is not loaded");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the HO Policy Info page - mandatory fields.
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Complete the Quote page.
					8. Click Next on Policy Info

	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded
					7. The Policy Info page is loaded.
					8. "This is a required field" should appear at blank mandatory fields.
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4971 @ Verify the HO Policy Info page - mandatory fields.")
	public void testHOPolicyInfoPageMandatoryFieldsValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
				hoPolicyInfoPage.goNext().isPhoneNumberFieldMakedWithError().shouldBeEqual("Mandatory field error is not matched for Phone Number field");
	}
	
	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Payment Details page. - Mandatory fields
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Complete the Quote page.
					8. Click Next on Policy Info
					9. Click on Next

	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded
					7. The Policy Info page is loaded.
					8. The Payment Details page loads, Avg Monthly and Total Premium is displayed. There should be no payment plan choosen by default. The payment option form should be displayed also.
					9. "Please choose a payment plan" popup appears and mandatory fields have "This is a required field".
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "SMOKE_EMR" }, description = "QB-PA-043 @ Verify Payment Details page. - Mandatory fields")
	public void testHOPaymentPlanPageLoadingAndValidation(String browserName) throws Exception {
		PaymentDetailsPage paymentDetailsPage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails()
				.goToPaymentDetailsPage();
		paymentDetailsPage.isPaymentDetailsPageLoaded().shouldBeTrue("Payment Details page is not loaded");
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		String jsonQuotedata = DataFetch.getQuoteAsJsonData(quoteNum);
		paymentDetailsPage.isAnnualPremiumEqualsTo(jsonQuotedata).shouldBeEqual("Annual premium is not equal");
		paymentDetailsPage.isMonthlyPermiumEqualsTo(jsonQuotedata).shouldBeEqual("Monthly premium is not equal");
		paymentDetailsPage.goNext();
//		No Payment plan pop up is displayed now
//		paymentDetailsPage.isChoosePaymentPlanConfirmationPresent()
//				.shouldBeTrue("Choose payment plan pop is not present");
		//paymentDetailsPage.validateChoosePaymentPlanConfirmationText().shouldBeTrue();
		paymentDetailsPage.areBankPaymentFieldsMarkedWithMandatoryError()
				.shouldBeTrue("Bank details fields are not marked in error");
		paymentDetailsPage.setPaymentMethod("Credit Card").areCreditCardPaymentFieldsMarkedWithMandatoryError()
				.shouldBeTrue("Credit card details fields are not marked in error");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Payment Details page. - Save Point
	 
	             Expected :
	           		1. Complete the landing page
					2. Complete Your Info page
					3. Complete Qualification page
					4. Complete the Your Home page.
					5. Complete the Construction page.
					6. Complete the Discount page.
					7. Complete the Quote page.
					8. Click Next on Policy Info
					9. Choose a payment plan eg ""A Monthly 10% Down, 9 Max installments"".
					10. Provide payment details. Payment Method, Account Type, Account Number, Routing, Bank Name.
					11. Click on Purchase.
					12. Login to PC and search for the policy number.
					13. Verify submission status"

	             Actual :
	           		1. The Your Information page is loaded.
					2. The Qualification page is loaded.
					3. The Your Home page is loaded.
					4. The construction page is loaded.
					5. The discount page is loaded.
					6. The Quote page is loaded
					7. The Policy Info page is loaded.
					8. The Payment Details page loads, Avg Monthly and Total Premium is displayed. There should be no payment plan choosen by default. The payment option form should be displayed also.
					9. "A Monthly 10% Down, 9 Max installments" radio button should be highlighted.
					10. Payment details form should be filled in correctly without validation messages.
					11. "Processing Payment" is displayed. Confirmation page appears with all the details including the policy number.
					12. The policy should be loaded, All data entered during the submission process should be in the PC as you entered it in the portal.
					13. The Submission will be complete and "In Force".
							              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4973 @ Verify Payment Details page. - Save Point")
	public void testHOPolicyPaymentPageSavePoint(String browserName) throws Exception {
		ThreadLocalObject.getData().put("DistanceToFireHydrantValue", "250");
    if (System.getProperty("platform").equalsIgnoreCase("granite")){
			ThreadLocalObject.getData().put("LocTypeValue", "prot");
		}
		HOQuotePage hoQuotePage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PaymentDetailsPage paymentDetailsPage = hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage()
				.setPolicyInfoPageDetails().goToPaymentDetailsPage();
		String jsonQuotedata = DataFetch.getQuoteAsJsonData(quoteNum);
		paymentDetailsPage.isAnnualPremiumEqualsTo(jsonQuotedata).shouldBeEqual("Annual premium is not equal");
		paymentDetailsPage.isMonthlyPermiumEqualsTo(jsonQuotedata).shouldBeEqual("Monthly premium is not equal");
		paymentDetailsPage.payMonthlyPremiumWithSavingsBankAccount();
		paymentDetailsPage.isPaymentPlanSelected().shouldBeTrue("Payment plan is not selected");
		PolicyConfirmationPage confirmationPage = paymentDetailsPage.purchasePolicy();
		confirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page is not loaded");
		String jsonQuotedataAfterBinding = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicyQuoteDataWithBackEnd(jsonQuotedataAfterBinding)
				.shouldBeTrue("Policy details are not matched with backend");
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotedataAfterBinding).shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify Confirmation Page.
	 
	             Expected :
		           		1. Complete the landing page
						2. Complete Your Info page
						3. Complete Qualification page
						4. Complete the Your Home page.
						5. Complete the Construction page.
						6. Complete the Discount page.
						7. Complete the Quote page.
						8. Complete the Policy Info.
						9. Complete the Payment details page.

	             Actual :
	           			1. The Your Information page is loaded.
						2. The Qualification page is loaded.
						3. The Your Home page is loaded.
						4. The construction page is loaded.
						5. The discount page is loaded.
						6. The Quote page is loaded
						7. The Policy Info page is loaded.
						8. The Payment Details page is loaded.
						9. The confirmation page is displayed containing Policy Summary, Your Info, Your House and Your Coverages.
							              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4974 @ Verify Confirmation Page")
	public void testHOPolicyConfirmationPageLoadingAndDetailsValidation(String browserName) throws Exception {
		pagefactory.quoteAndBuyHOBasePolicyWithMonthlySavingAccountPayment().validateHOPolicyConfirmationPageDetailsWithBackEnd().shouldBeTrue();
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Verify the coverage must start in a future date.
	 * 
	 *             Expected :
	               1. Complete the landing page.
				   2. Enter all the required fields - First Name, Last Name, Address 1, City, State, Email Address.
				   3. Click on the date picker and attempt to choose a date in the past."
	 *            
	 *            Actual :
	 *            1. Your Information page is loaded successfully.
				  2. All fields are entered successfully.
				  3. Dates in the past will be disabled or ""Value must be a date in the future"" will be displayed."
	              
	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4268 @ Verify the coverage must start in a future date.")
	public void testHOPolicyEffectiveDateMustBeFuture(String browserName) {
		pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.withCoverage(DateUtil.getPastDateUsingDays()).goNext().isCoverageDateFutureErrorPresent()
				.shouldBeEqual("Coverage Details must be in Future Error is not present");
	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Your Home page - numeric field validation for "Estimated value of Home"
	 *
	Step actions :
	1. Complete the landing page for property quote
	2. Complete the Your Info page
	3. Complete the Qualification page
	4. Enter abc in Estimated house value.
	5. Click somewhere on the page or on the next field - Location Type

	Expected Results :
	1. Your Information page is loaded.
	2. The Qualification page is loaded.
	3. The Your Home page is loaded.
	4. N/A
	5. Error message "Please enter numbers only" should be displayed.

	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = " TC4277 @ Your Home page – numeric field validation for Estimated value of Home")
	public void testHOYourHomePageEstimatedHomeValueIsNumericOnly(String browserName) throws Exception {
		ThreadLocalObject.getData().put("HomeValue", "XYZ");
		YourHomePage homePage = pagefactory.setHOPolicyDataUpToYourHomePage();
		homePage.isYourHomePageLoaded().shouldBeTrue("Your home page is not loaded");
		//homePage.isHomeEstimationValueFieldMarkedWithNumericError().shouldBeEqual("Estimated Home Value field should be numeric only");

	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Construction Page - mandatory field validation for Specify Type (Roof, Plumbing, Heating, Electrical) "
	 *
	Step actions :
	1. Complete the landing page for property quote
	2. Complete the Your Info page
	3. Complete the Qualification page
	4. Complete the Your Home page
	5. Year Build - 1999
	6. Number of Stories - 5+
	7. Garage - Attached Garage
	8. Construction Type - Log
	9. Foundation Type - Full Basement
	10. Roof - Other
	11. Plumbing - Other
	12. Primary Heating - Other
	13. Secondary Heating - No
	14. Electrical Wiring - Other
	15. Electrical system - Other
	16. Click Next


	Expected Results :
	1. Your Information page is loaded.
	2. The Qualification page is loaded.
	3. The Your Home page is loaded.
	4. The Construction page is loaded.
	5. N/A
	6. 5+ is selected
	7. Attached Garage radio button is selected.
	8. "Log" is selected
	9. "Full Basement" is selected
	10. "Other" is selected
	11. "Other" is selected.
	12. "Other" is selected.
	13. "No" radio slider selected.
	14. "Other" is selected.
	15. "Other" is selected
	16. Error message "This is a required field" should appear for below fields.

	Roof - Specify Other

	Plumbing - Specify Other

	Primary Heating - Specify Other

	Electrical Wiring - Specify Other

	Electrical System - Specify Other


	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite"}, description = " TC4275 @ Construction Page - mandatory field validation for Specify Type (Roof, Plumbing, Heating, Electrical) ")
	public void testHOConstructionPageMandatoryFieldsForSpecifyOther(String browserName) throws Exception {
		ConstructionPage constructionPage = pagefactory.setHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.setConstructionPageDetails().goNext();
		constructionPage.expandRoofSection().isRoofMarkedWithError().shouldBeEqual("Roof Type field is not marked with mandatory error message");
		constructionPage.expandPlumbingSection().isPlumbingOtherTypeFieldmarkedWithError().shouldBeEqual("Plumbing Type field is not marked with mandatory error message");
		constructionPage.expandHeatingSection().isHeatingTypeOtherFieldmarkedWithError().shouldBeEqual("Heating Type field is not marked with mandatory error message");
		constructionPage.expandElectricSection().isElectricalWiringTypeOtherFieldmarkedWithError().shouldBeEqual("Electrical Wiring field is not marked with mandatory error message");
		constructionPage.expandElectricSection().isElectricalSystemTypeOtherFieldmarkedWithError().shouldBeEqual("Electrical System field is not marked with mandatory error message");

		}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Construction Page - mandatory field validation for Upgraded Year (Roof, Plumbing, Heating, Electrical)
	 *
	Step actions :
	1. Complete the landing page for property quote
	2. Complete the Your Info page
	3. Complete the Qualification page
	4. Complete the Your Home page
	5. Year Build - 1999
	6. Number of Stories - 5+
	7. Garage - Attached Garage
	8. Construction Type - Log
	9. Foundation Type - Full Basement
	10. Roof - Tile Concrete
	11. Roofing Upgraded - Yes
	12. Plumbing - PVC
	13. Plumbing Upgraded - Yes
	14. Primary Heating - Electricity
	15. Secondary Heating - No
	16. Heating Upgraded - Yes
	17. Electrical Wiring - Copper
	18. Electrical system - Circuit Breaker
	19. Wiring Upgraded - Yes
	20. Click Next

	Expected Results :
	1. Your Information page is loaded.
	2. The Qualification page is loaded.
	3. The Your Home page is loaded.
	4. The Construction page is loaded.
	5. N/A
	6. 5+ is selected
	7. Attached Garage radio button is selected.
	8. "Log" is selected
	9. "Full Basement" is selected
	10. "Tile Concrete" is selected
	11. "Roofing Upgraded" selected
	12. "PVC" is selected.
	13. Plumbing Upgraded is selected.
	14. "Electricity" is selected.
	15. "No" radio slider selected.
	16. Heating Upgraded is selected
	17. "Copper" is selected.
	18. "Circuit Breaker" is selected
	19. Wiring Upgraded is selected
	20. Error message "This is a required field" should appear for below fields.

	Roof - Year

	Plumbing - Year

	Heating - Year

	Electrical - Year




	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = " TC4273 @ Construction Page - mandatory field validation for Upgraded Year (Roof, Plumbing, Heating, Electrical) ")
	public void testHOConstructionPageMandatoryFieldsForUpgradedYear(String browserName) throws Exception {
		ConstructionPage constructionPage = pagefactory.setHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.setConstructionPageDetailsWithUpgradedYear().goNext();
		constructionPage.expandRoofSection().isRoofUpgradedMarkedWithMandatoryError().shouldBeEqual("Roofing Upgraded Year field is not marked with mandatory error message");
		constructionPage.expandPlumbingSection().isPlumbingUpgradedMarkedWithMandatoryError().shouldBeEqual("Plumbing Upgraded Year field is not marked with mandatory error message");
		constructionPage.expandHeatingSection().isHeatingUpgradedMarkedWithMandatoryError().shouldBeEqual("Heating Upgraded Year field is not marked with mandatory error message");
		constructionPage.expandElectricSection().isElectricalWiringUpgradeMarkedWithMandatoryError().shouldBeEqual("Wiring Upgraded Year field is not marked with mandatory error message");

	}

	/**
	 * @param browserName
	 * @throws Exception
	 * @formatter:off
	 * Test Description :- Construction Page - mandatory field validation for Upgraded Year (Roof, Plumbing, Heating, Electrical)
	 *
	Step actions :
	1. Complete the landing page for property quote
	2. Complete the Your Info page
	3. Complete the Qualification page
	4. Complete the Your Home page
	5. Year Build - 1999
	6. Number of Stories - 5+
	7. Garage - Attached Garage
	8. Construction Type - Log
	9. Foundation Type - Full Basement
	10. Roof - Tile Concrete
	11. Roofing Upgraded - Yes
	12. Enter 'abc' in the Year field.
	13. Plumbing - PVC
	14. Plumbing Upgraded - Yes
	15. Enter 'abc' in Year field
	16. Primary Heating - Electricity
	17. Secondary Heating - No
	18. Heating Upgraded - Yes
	19. Enter 'abc' in Year field.
	20. Electrical Wiring - Copper
	21. Electrical system - Circuit Breaker
	22. Wiring Upgraded - Yes
	23. Enter 'abc' in Year field.


	Expected Results :
	1. Your Information page is loaded.
	2. The Qualification page is loaded.
	3. The Your Home page is loaded.
	4. The Construction page is loaded.
	5. N/A
	6. 5+ is selected
	7. Attached Garage radio button is selected.
	8. "Log" is selected
	9. "Full Basement" is selected
	10. "Tile Concrete" is selected
	11. "Roofing Upgraded" selected
	12. Error message "Please enter numbers only" should be displayed.
	13. "PVC" is selected.
	14. Plumbing Upgraded is selected.
	15. Error message "Please enter numbers only" should be displayed.
	16. "Electricity" is selected.
	17. "No" radio slider selected.
	18. Heating Upgraded is selected
	19. Enter 'abc' in Year field.
	20. "Copper" is selected.
	21. "Circuit Breaker" is selected
	22. Wiring Upgraded is selected
	23. Error message "Please enter numbers only" should be displayed.
	24. Error message "This is a required field" should appear for below fields.

	 * @formatter:on
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = " TC4271 @ Construction Page - numeric values only validation for Upgraded Year (Roof, Plumbing, Heating, Electrical) ", enabled = false)
	public void testHOConstructionPageNumericFieldsValidationForUpgradedYear(String browserName) throws Exception {
		ConstructionPage constructionPage = pagefactory.setHOPolicyDataUpToYourHomePage().goToConstructionPage();
		constructionPage.isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		constructionPage.setConstructionPageDetailsWithUpgradedYear();
		constructionPage.expandRoofSection().isRoofUpgradedMarkedWithNumericError().shouldBeEqual("Roofing Upgraded Year field is not marked with numeric error message");
		constructionPage.expandPlumbingSection().isPlumbingUpgradedMarkedWithNumericError().shouldBeEqual("Plumbing Upgraded Year field is not marked with numeric error message");
		constructionPage.expandHeatingSection().isHeatingUpgradedMarkedWithNumericError().shouldBeEqual("Heating Upgraded Year field is not marked with numeric error message");
		constructionPage.expandElectricSection().isElectricalWiringUpgradeMarkedWithNumericError().shouldBeEqual("Wiring Upgraded Year field is not marked with numeric error message");

	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4267 @ HO Policy Info Email Validation")
	public void testHOPolicyInfoPageEmailFormatFieldValidation(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage = pagefactory.setHOPolicyDataUpToDiscountPage().goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
		hoPolicyInfoPage.setEmailAddress("abc").setPhoneNumber().goNext().isEmailFieldMarkedWithFormatError().shouldBeEqual("Format field error is not matched for Email field");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4267 @ Verify the HO Policy Info for email validation")
	public void testHOYourInfoPageEmailFormatFieldValidation(String browserName) throws Exception {
		YourInfoPage infoPage = pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage();
		infoPage.setAddressManually().isYourInfoPageLoaded().shouldBeTrue("Your Info page is not loaded");
		infoPage.setYourInfoPageDetails().goNext().isEmailFieldMarkedWithFormatError().shouldBeEqual("Format field error is not matched for Email field");
	}

		/**
         * @param browserName
         * @throws Exception
         * @formatter:off
         * Test Description :- NO MANUAL TEST ADDED YET
         *
         *             Expected :

         *
         *            Actual :
         *

         * @formatter:on
         */

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "No Manual Test for mapping")
	public void testHOBackScreenNavigation(String browserName) {
		pagefactory.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setYourHomePageDetails()
				.goToConstructionPage().setConstructionPageDetails().goToDiscountPage().setDiscountPageDetails()
				.goToHOQuotePage().buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails()
				.goToPaymentDetailsPage().isPaymentDetailsPageLoaded()
				.shouldBeTrue("Payment Details pag is not loaded");

		LeftNavigationMenuHandler leftNavigationMenuHandler = new LeftNavigationMenuHandler();
		HOPolicyInfoPage hoPolicyInfoPage = (HOPolicyInfoPage) leftNavigationMenuHandler.gotoPolicyInfo();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info page is not loaded");
		HOQuotePage hoQuotePage = (HOQuotePage) leftNavigationMenuHandler.gotoQuotePage();
		hoQuotePage.isHOQuotePageLoaded().shouldBeTrue("HO Quote page is not Loaded");
		DiscountPage discountPage = leftNavigationMenuHandler.gotoDiscountPage();
		discountPage.isDiscountPageLoaded().shouldBeTrue("Discount page is not loaded");
		leftNavigationMenuHandler.gotoConstructionPage();
		new ConstructionPage().isConstructionPageLoaded().shouldBeTrue("Construction page is not loaded");
		leftNavigationMenuHandler.gotoYourHomePage().isYourHomePageLoaded()
				.shouldBeTrue("Your Home page is not loaded");
		leftNavigationMenuHandler.gotoQualificationPage().isQualificationPageLoaded()
				.shouldBeTrue("Qualification page is not loaded");
		leftNavigationMenuHandler.gotoYourInfoPage().isYourInfoPageLoaded()
				.shouldBeTrue("Your Info page is not loaded");
	}

}
