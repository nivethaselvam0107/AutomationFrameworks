package com.guidewire.test.claimportal.producer;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;

public class CP_ClaimListPageUIValidationTest {
	CPPageFactory cpPageFactory = new CPPageFactory();
	
	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "REG_DIA"})
	public void testNetIncurredColumnSortingAsc(String browserName) {
		cpPageFactory
				.login()
				.validateClaimListNetIncurredColIsSortedAsc()
				.shouldBeTrue("Claim list, sort ASC on column NET INCURRED failed.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "REG_DIA"})
	public void testNetIncurredColumnSortingDesc(String browserName) {
		cpPageFactory
				.login()
				.validateClaimListNetIncurredColIsSortedDesc()
				.shouldBeTrue("Claim list, sort DESC on column NET INCURRED failed.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "REG_DIA"})
	public void testPaidColumnSortingAsc(String browserName) {
		cpPageFactory
				.login()
				.validateClaimListPaidColIsSortedAsc()
				.shouldBeTrue("Claim list, sort ASC on column PAID failed.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "REG_DIA"})
	public void testPaidColumnSortingDesc(String browserName) {
		cpPageFactory
				.login()
				.validateClaimListPaidColIsSortedDesc()
				.shouldBeTrue("Claim list, sort DESC on column PAID failed.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testClaimDetailsBackendCallForFinancialData(String browserName) throws Exception {
		new LoginPage().login();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		String claimNum = claimListPage.getOpenClaimIds().get(0);

		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.isClaimDetailsDataBackendCallsContainingFinancialData(claimNum);
	}
}
