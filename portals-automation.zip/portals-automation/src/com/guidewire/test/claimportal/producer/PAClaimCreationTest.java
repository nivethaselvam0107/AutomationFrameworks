package com.guidewire.test.claimportal.producer;

import com.guidewire.common.selenium.ThreadLocalObject;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.util.DateUtil;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;

public class PAClaimCreationTest 
{
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "SMOKE" }, description = "TC5313")
	public void testPACollisionClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.validateClaimNumberFormat(claimNum).shouldBeTrue("Claim Number format is not correct");
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA",  "SMOKE"  }, description = "TC5317")
	public void testPATheftClaimCreationWithAudioStolen(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createTheftClaim().withContactHomeNum().
				goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA",  "SMOKE"  }, description = "TC5316")
	public void testPATheftClaimCreationWithVehicleStolen(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createTheftClaim().withContactHomeNum().
				goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5318")
	public void testPAGlassClaimCreation(String browserName) throws Exception {
		ThreadLocalObject.getData().put("VehicleDamaged","Acura RSX 2001");
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createGlassClaim().withContactHomeNum().
				goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA",  "SMOKE"  }, description = "TC5319")
	public void testPAOtherClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		ContactUSPage contactUSPage = cpPageFactory.createPAOtherClaim();
		contactUSPage.isContactUsPageLoaded().shouldBeTrue("Contactus Page is not loaded");
		contactUSPage.goToClaimPageCP().isClaimListPageLoaded().shouldBeTrue("Claim Page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5392")
	public void testFutureDateErrorForClaim(String browserName) throws Exception {
		cpPageFactory.login().fileAClaim().withClaimDateOfLoss(DateUtil.getDateIn12HrsFormat(1)).selectPolicy().hideDoL().validateDateOfLossFieldError().shouldBeEqual("Future date error message is not correct");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5408")
	public void testUserCanNotFileAClaimWithOutPolicySelection(String browserName) throws Exception {
		cpPageFactory.login().fileAClaim().isNextButtonDisabledBeforePolicySelection().shouldBeEqual("Next button is not disabled before policy selection");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5320")
	public void testPAClaimCollisionWithPedestrianCreation(String browserName) throws Exception {
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.validateClaimNumberFormat(claimNum).shouldBeTrue("Claim Number format is not correct");
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5321")
	public void testPAClaimCollisionWhileTurningLeftCreation(String browserName) throws Exception {
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.validateClaimNumberFormat(claimNum).shouldBeTrue("Claim Number format is not correct");
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5322")
	public void testPAMischiefAndVandalismClaimCreation(String browserName) throws Exception {
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.validateClaimNumberFormat(claimNum).shouldBeTrue("Claim Number format is not correct");
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}

}
