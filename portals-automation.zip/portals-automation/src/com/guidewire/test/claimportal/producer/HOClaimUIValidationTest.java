package com.guidewire.test.claimportal.producer;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.util.DateUtil;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;

public class HOClaimUIValidationTest {
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "TC5382")
	public void testHOClaimCreationDraft(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().withNewContactPerson().goNext().withNewContactPerson();
		String draftNum = claimContactPersonPage.getDraftClaimNumber();
		claimContactPersonPage.cancelClaim();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" })
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOFireClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for fire claim");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOWaterClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for Water Claim");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOCrimeClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToCrimeDetailsPage().setCrimeDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for crime claim");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void testHOWaterClaimNewPersonAddedIsAvailableOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().withNewContactPerson().goNext();
		claimContactPersonPage.validateNewlyCreatedPersonListing().shouldBeTrue("Newly Create Person on Document page is not listed on Contact person page");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void testHOFireClaimNewPersonAddedIsAvailableOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().withNewContactPerson().goNext();
		claimContactPersonPage.validateNewlyCreatedPersonListing().shouldBeTrue("Newly Create Person on Document page is not listed on Contact person page");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void testHOFireClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
				CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
				claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue(claimNum + "Claim is not listed");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void testHOWaterClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
				CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
				claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue(claimNum + "Claim is not listed");
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "")
	public void testHOCrimeClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToCrimeDetailsPage().setCrimeDetails().goNext().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
				CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
				claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue(claimNum + "Claim is not listed");
	}
	
	 @Parameters("browserName")
		@Test(groups = {  "REG_EMR" }, description = "TC5391")
		public void validateNoPolicyListedWhenDOLNotMatching(String browserName) throws Exception {
		 NewClaimDOLPage neClaimDOLPage = cpPageFactory.login().fileAClaim().searchByPolicyType();
				 neClaimDOLPage.clickSearchButton();
				 neClaimDOLPage.withClaimDateOfLoss(DateUtil.getDateIn12HrsFormat(-30));
				 neClaimDOLPage.verifyNoPolicyListingWhenDOLNotMatchingPolicyValidity().shouldBeEqual("No Policy Listed error message is not correct");
		}
}
