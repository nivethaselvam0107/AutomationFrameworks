package com.guidewire.test.claimportal.producer;

import org.joda.time.DateTime;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;

public class PolicySearchTest {
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5400")
	public void testPolicySearchByFirstName(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchPolicyByFirstName()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5401")
	public void testPolicySearchByLastName(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchPolicyByLastName()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5402")
	public void testPolicySearchByCityName(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchPolicyByCity()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5404")
	public void testPolicySearchByStateName(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchPolicyByState()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5405")
	public void testPolicySearchByPolicyType(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchByPolicyType()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "Db1" }, description = "TC5403")
	public void testPolicySearchByZipCode(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.searchPolicyByZipCode()
				.withValidValue()
				.isPolicyListedForSelection()
				.shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = {"FNOL"}, description = "TC3599")
	public void testPolicySearchWithInvalidValue(String browserName) throws Exception {
		String[] specialCharsText = {".", ":", "?", ">", "/", "\\", "%", "#", "@", "!", ",", "!=", "=", "===", "+", "\\d", "\\w", "^", "$", "null", "<div>", "<div", "div>", "40chars_" + new String(new char[32]).replace("\0", "1"), "41chars_" + new String(new char[33]).replace("\0", "2")};

		NewClaimDOLPage claimDOLPage = ((ClaimListPage)cpPageFactory.loginOpenAM())
				.fileAClaim();
		for (String specialChar : specialCharsText) {
			claimDOLPage.searchPolicyByNumber(specialChar)
					.goNextWithInvalidPolicyValue()
					.verifySearchReturnedNoPolicyError()
					.shouldBeEqual(
					"CP-Agent policy search result for random text[" + specialChar + "] " +
					"DOES NOT return message:\n\t" + DataConstant.NO_POLICY_LISTED_ERROR
			);
			claimDOLPage.cancelClaim()
					.goToHome()
					.fileAClaim();
		}
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5406")
	public void testResettingPolicySearchFields(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.setAllPolicySearchText()
				.resetSearchData()
				.validatePolicyResetButton()
				.shouldBeTrue("Policy Search Data is not reset");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5407")
	public void testSearchingOnlyHOPolicy(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.setAllPolicySearchText("Foster City", "94404", "California", "Homeowners" )
				.withValidValue()
				.onlyHOPolicyListed()
				.shouldBeTrue("Policy type is not matched");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5409")
	public void testSearchingPolicyWithInvalidValues(String browserName) throws Exception {
		((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.setAllPolicySearchText()
				.withInvalidValue()
				.verifyNoPolicyListingWhenDOLNotMatchingPolicyValidity()
				.shouldBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5370")
	public void testClaimCreationWithPolicySearchByNumber(String browserName) throws Exception {
		String claimNum = ((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectHOClaimType()
				.goToWaterDamageDetailsPage()
				.setWaterDamageDetails()
				.goNext()
				.goNext()
				.withContactHomeNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		ClaimListPage claimListPage =  new ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim is not listed");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5371")
	public void testClaimCreationWithPolicySearchByFormData(String browserName) throws Exception {
		String claimNum = ((ClaimListPage) cpPageFactory.loginOpenAM())
				.fileAClaim()
				.setAllPolicySearchText("Foster City", "94404", "California", "Homeowners" )
				.withValidValue()
				.selectPolicyFromSearchResult()
				.goNext()
				.selectHOClaimType()
				.goToWaterDamageDetailsPage()
				.setWaterDamageDetails()
				.goNext()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		ClaimListPage claimListPage =  new ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"}, description = " ")
	public void testNextButtonAvailability(String browserName) throws Exception {
		String testData = "ABSTRACT_DATA_TEST";

		new LoginPage().login();
		NewClaimDOLPage dolPage =  new AccountSummaryPage().goToMakeAClaim();

		new Validation(dolPage.isNextEnabled()).shouldBeFalse("Next button should be disabled");

		dolPage.searchPolicyByNumber(testData);
		new Validation(dolPage.isNextEnabled()).shouldBeTrue("Next button should be enabled - date default, policy number provided");

		dolPage.withClaimDateOfLoss("");
		new Validation(dolPage.isNextEnabled()).shouldBeFalse("Next button should be disabled - no date");

		DateTime today = new DateTime();
		today = today.plusHours(3);
		dolPage.withClaimDateOfLoss(today);
		new Validation(dolPage.isNextEnabled()).shouldBeFalse("Next button should be disabled - date in future");

		today = today.minusDays(1);
		dolPage.withClaimDateOfLoss(today);
		new Validation(dolPage.isNextEnabled()).shouldBeTrue("Next button should be enabled - date in past");

		dolPage.withClaimDateOfLoss(testData);
		new Validation(dolPage.isNextEnabled()).shouldBeFalse("Next button should be disabled - not valid date");
	}
}
