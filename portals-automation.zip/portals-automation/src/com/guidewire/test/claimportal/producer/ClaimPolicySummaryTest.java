package com.guidewire.test.claimportal.producer;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.portals.claimportal.pages.*;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.PolicyDetailPage;
import com.guidewire.portals.claimportal.subpages.NotesTab;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class ClaimPolicySummaryTest {
	
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5185")
	public void validateVendorPopUpDetails(String browserName) throws Exception {
		CP_ClaimListPage claimListPage = cpPageFactory.login();
		claimListPage.filterClaimByTextSearch().validateVendorPopUpDetails().shouldBeTrue("Vendor pop details are not correct");
		claimListPage.openClaimSummary().areVendorDetailsOnPopUpCorrect().shouldBeTrue("Vendor Details are not correct");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5385")
	public void testClaimNotePageMandatoryFieldsError(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		ThreadLocalObject.getData().put("ClaimSearchValue",cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber());
		new CP_ClaimListPage().goToHome().filterClaimByTextSearch().openClaimSummary().openNoteTab().addNote().saveNotes().validateMandatoryFieldsErrorOnNotePage().shouldBeTrue("New Notes page mandatory fields's error message is not correct");
	}
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "SMOKE" }, description = "TC5325")
	public void testClaimNoteAddition(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createTheftClaim().withContactHomeNum().
				goToSummary().submitClaim().getClaimNumber();
		new NewClaimConfirmationPage().clickGoHomeButton();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.openNoteTab().addNote().addNoteDetails().openNoteTab().searchNote().isNotesAdded().shouldBeTrue("Note is not added correctly");
		claimSummaryPage.areNotesValueMatchingWithBackEnd(claimNum).shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "")
	public void testClaimNoteAdditionFromSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		ThreadLocalObject.getData().put("ClaimSearchValue",cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber());
		ClaimSummaryPage claimSummaryPage = ((ClaimListPage) cpPageFactory.loginOpenAM()).goToHome().filterClaimByTextSearch().openClaimSummary();
		claimSummaryPage.addNote().addNoteDetails().openNoteTab().searchNote().isNotesAdded().shouldBeTrue("Note is not added correctly");
		claimSummaryPage.areNotesValueMatchingWithBackEnd().shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5273")
	public void validatePolicyLevelCoverageDetailsPage(String browserName) throws Exception {
		CP_ClaimListPage claimListPage = cpPageFactory.login();
		PolicyDetailPage policyDetailPage = claimListPage.openPolicyDetailsPage();
		policyDetailPage.isPolicyDetailsPageLoaded().shouldBeTrue("Policy Details page is not loaded");
		policyDetailPage.arePAPolicyLevelCoverageDetailsAreMatchingBackEnd().shouldBeTrue("Policy Level Coverage details are not correct");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, enabled = false, description = "TC5324")
	public void validatePolicyVehicleCoverageDetailsPage(String browserName) throws Exception {
		ClaimListPage claimListPage = ((ClaimListPage)cpPageFactory.loginOpenAM());
		PolicyDetailPage policyDetailPage = claimListPage.openPolicyDetailsPage();
		policyDetailPage.isPolicyDetailsPageLoaded().shouldBeTrue("Policy Details page is not loaded");
		policyDetailPage.arePAPolicyVehicleCoverageDetailsAreMatchingBackEnd().shouldBeTrue("Vehicle Coverage details are not correct");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5398")
	public void testBackArrowButtonOnSummaryPage(String browserName) throws Exception {
		new LoginPage().login();
		new CP_ClaimListPage().filterClaimByTextSearch().openClaimSummary().goBackCP().isClaimListPageLoaded().shouldBeTrue("BackButton did not bring us to Claim list page");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5384")
	public void testHOClaimNoteAddition(String browserName) throws Exception {
		String claimNum = cpPageFactory.createWaterClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().openClaimSummary(claimNum);
		NotesTab notesTab = new NotesTab();
		notesTab.openTab();
		notesTab.addNote()
				.addNoteDetails();
		notesTab.openTab();
		notesTab.searchNote().isNotesAdded().shouldBeTrue("Note is not added correctly");
		claimSummaryPage.areNotesValueMatchingWithBackEnd(claimNum).shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = " ")
	public void testHOClaimNoteAdditionFromSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		ThreadLocalObject.getData().put("ClaimSearchValue",cpPageFactory.createHODefaultClaim().goToSummary().submitClaim().getClaimNumber());
		ClaimSummaryPage claimSummaryPage = new CP_ClaimListPage().goToHome().openClaimSummary();
		claimSummaryPage.addNote().addNoteDetails().openNoteTab().searchNote().isNotesAdded().shouldBeTrue("Note is not added correctly");
		claimSummaryPage.areNotesValueMatchingWithBackEnd().shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5327")
	public void testClaimNoteAdditionForAdjuster(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().addNotesForAdjuster().withNotesContent().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().openClaimSummary(claimNum);
		claimSummaryPage.areNotesValueMatchingWithBackEnd(claimNum).shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5394")
	public void validateHOPolicyLocationCoverageDetailsPage(String browserName) throws Exception {
		CP_ClaimListPage claimListPage = cpPageFactory.login();
		PolicyDetailPage policyDetailPage = claimListPage.openPolicyDetailsPage();
		policyDetailPage.isPolicyDetailsPageLoaded().shouldBeTrue("Policy Details page is not loaded");
		policyDetailPage.areHOPolicyLocationCoverageDetailsAreMatchingBackEnd().shouldBeTrue("Location Coverage details are not correct");
	}


	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .txt document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .txt file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5329")
	public void testDocUploadTXT(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("TXT file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("TXT file not present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .gif document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .gif file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "NO TEST CASE CURRENTLY IN TEST LINK")
	public void testDocUploadGIF(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("GIF file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("GIF file not present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .jpeg document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .jpeg file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5330")
	public void testDocUploadJPEG(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("JPEG file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("JPEG file not present in CC");
	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .png document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .png file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5328")
	public void testDocUploadPNG(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("PNG file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("PNG file not present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .doc document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .doc file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5332")
	public void testDocUploadDOC(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("DOC file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("DOC file not present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .docx document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .docx file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be dispayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5333")
	public void testDocUploadDOCX(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("DOCX file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("DOCX file present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .pdf document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .pdf file and click on Open
	6. Login to CC as superuser and verify under Claims->Documets page the newly added document is displayed

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5331")
	public void testDocUploadPDF(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("PDF file didn't upload");
		claimSummaryPage.isDocAddedMatchingWithBackEnd(claimNum).shouldBeTrue("PDF file not present in CC");

	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .html document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .html file and click on Open

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR"},description = "NO TEST CASE CURRENTLY IN TEST LINK")
	public void testDocUploadHTML(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for HTML file");
		alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user can upload a .html document to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on .html file and click on Open

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Document should be displayed under Documents tab
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "NO TEST CASE CURRENTLY IN TEST LINK")
	public void testDocUploadJS(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for JS file");
		alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
	}

	/**@formatter:off
	 * @param browserName
	 *
	 * Test Description : Verify user cannot upload 2 documents with same name to a personal auto claim

	Actual :-
	1. Login to Claim portal as producer(aproducer/password)
	2. Click on personal auto claim number with status as Open on Claims page
	3. Click on Documents Tab
	4. Click on Upload document button
	5. Click on any file and click on Open
	6. Click on upload document button again and upload the same file again

	Expected :-
	1. User should be logged into portal successfully. Claims page should be displayed
	2. Claims details page should be displayed.
	3. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
	4. Open window should be displayed
	5. Document should be uploaded successfully and should be listed on Documents page.
	6. Error popup window with 'Failed to upload file Internal data is displayed on landing screen on * ' message should be displayed. Note: '*' is the file name
	 */

	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5334")
	public void testSameDocUploadTwice(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = cpPageFactory.createCollisionClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		ClaimSummaryPage claimSummaryPage = claimListPage.goToHome().filterClaimByTextSearch(claimNum).openClaimSummary(claimNum);
		claimSummaryPage.openDocTab().uploadDocFromSummary().uploadDocFromSummary();
		AlertHandler alertHandler = new AlertHandler();
		alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for same document");
		alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
	}

}
