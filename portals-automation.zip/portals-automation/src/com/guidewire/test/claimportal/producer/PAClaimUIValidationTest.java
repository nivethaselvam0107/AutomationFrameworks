package com.guidewire.test.claimportal.producer;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimVehicleDriverPage;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class PAClaimUIValidationTest {
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5341")
	public void validateMandatoryFieldsOnClaimIncidentLocation(String browserName) throws Exception {
		NewClaimLocationPage incidentLocation = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext();
		incidentLocation.goToVehicleDriverPage();
		incidentLocation.validateCityFieldErrorMessage()
				.shouldBeEqual("Error message for City Field in Exact address section is not correct");
		incidentLocation.openCityOnlyLocationSection().validateCityFieldErrorMessage()
				.shouldBeEqual("Error message for City Field in City Only address section is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5342")
	public void validateMandatoryFieldsOnVehicleDriverPage(String browserName) throws Exception {
		NewClaimVehicleDriverPage vehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage();
		vehicleDriverPage.goNext();
		vehicleDriverPage.validateDriverDropDownFieldErrorMessage()
				.shouldBeEqual("Driver drop down field error message is not correct");
		vehicleDriverPage.validateVehicleDropDownFieldErrorMessage()
				.shouldBeEqual("Vehicle drop down field error message is not correct");
		vehicleDriverPage.selectOtherDriver().selectOtherVehicle().goNext();
		vehicleDriverPage.validateNewDriverMandatoryFieldsErrorMessage()
				.shouldBeTrue("Error message for Driver mandatory fields is not correct");
		vehicleDriverPage.validateNewVehicleMandatoryFieldsErrorMessage()
				.shouldBeTrue("Error message for Vehicle mandatory fields is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5339")
	public void validateMandatoryFieldsForPassengerOnVehicleDriverPage(String browserName) throws Exception {
		NewClaimVehicleDriverPage vehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage();
		vehicleDriverPage.addNewPassenger().goNext();
		vehicleDriverPage.validatePassengerMandatoryFieldsErrorMessage()
				.shouldBeTrue("Driver drop down field error message is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5340")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPage(String browserName) throws Exception {
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility();
		claimDocumentPage.addNewContactPerson().goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag()
				.shouldBeTrue("New Contact fields are not marked with error");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5343")
	public void validateExistingContactDetailsOnSummaryPage(String browserName) throws Exception {
		cpPageFactory.login().fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.selectCollisionClaimType().goNext().withOnlyCity().goToVehicleDriverPage().selectFirstAvailableDriver()
				.selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext().selectContact().withContactHomeNum().goToSummary()
				.validateExistingContactsDetailsOnSummaryPage().shouldBeEqual("Contact Person details is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5344")
	public void validateNewContactDetailsOnSummaryPage(String browserName) throws Exception {
		cpPageFactory.login().fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.selectCollisionClaimType().goNext().withOnlyCity().goToVehicleDriverPage().selectDriver()
				.selectVehicle().goToRepairChoicePage().selectNoFacility().goNext().withNewContactPerson().withContactHomeNum().goToSummary()
				.validateNewContactsDetailsOnSummaryPage().shouldBeEqual("New Contact Person details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5345")
	public void validateErrorMessageForMissingContactNumberOnContactPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext().withoutHomeNumber();
		claimContactPersonPage.withoutWorkNum().goNext();
		claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage()
				.shouldBeEqual("Contact Nu ber required error message is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5346")
	public void validateEmailErrorMessageOnContactPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext();
		claimContactPersonPage.validateEmailFieldOnSummaryPage().shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5347")
	public void validateMandatoryErrorMessageforNewContactOnContactPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext().addNewContact()
				.addNewContact().goNext();
		claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5350")
	public void testClaimIsNotSavedOnDOLPage(String browserName) throws Exception {
		((CP_ClaimListPage) cpPageFactory.login()).fileAClaim().cancelWizardCP().isClaimListPageLoaded()
				.shouldBeTrue("Claim list page is not displayed and Claim save opop is displayed");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5351")
	public void testClaimIsNotSavedOnWhatHappenedPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		((CP_ClaimListPage) cpPageFactory.login()).fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.cancelWizardCP().isClaimListPageLoaded()
				.shouldBeTrue("Claim list page is not displayed and Claim save opop is displayed");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5352")
	public void testClaimIsSavedAsDraftWhenCancelledOnWhatLocationPage(String browserName) throws Exception {
		NewClaimLocationPage claimLocationPage = ((CP_ClaimListPage) cpPageFactory.login()).fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext();
		String draftNum = claimLocationPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimLocationPage.cancelClaim();
		alertHandler.closeClaimSubmissionAlert();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5353")
	public void testClaimIsSavedAsDraftWhenCancelledOnVehicleDriverPage(String browserName) throws Exception {
		NewClaimVehicleDriverPage claimVehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().goToVehicleDriverPage();
		String draftNum = claimVehicleDriverPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimVehicleDriverPage.cancelClaim();
		alertHandler.closeClaimSubmissionAlert();
		ClaimListPage claimListPage = new ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5354")
	public void testClaimIsSavedAsDraftWhenCancelledOnDocumentPage(String browserName) throws Exception {
		NewClaimDocumentPage claimDocuemntPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().
				setAirBagDeployStatus().setEquiFailureStatus().setVehicleCollisionPoint().setVehicleRentalStatus().setVehicleSafetyToDrive().setVehicleTowStatus().goToRepairChoicePage().selectNoFacility();
		String draftNum = claimDocuemntPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimDocuemntPage.cancelClaim();
		alertHandler.closeClaimSubmissionAlert();
		ClaimListPage claimListPage = new ClaimListPage();
		claimListPage.validateDraftClaimNumberFormat(draftNum).shouldBeTrue("Draft Claim number format is not correct" + draftNum);
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
		((NewClaimVehicleDriverPage) claimListPage.openDraftClaim(draftNum)).goToVehicleDriverPage().areVehicleDriverDetailsAreSaved().shouldBeTrue("Vehicle driver details are not saved correctly");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5355")
	public void testClaimIsSavedAsDraftWhenCancelledOnContactPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().withVehicleInvolved()
				.withTheftVehicleDamageDetails().withClaimDescription().goToRepairChoicePage().selectNoFacility().withNewContactPerson().goNext();
		String draftNum = claimContactPersonPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimContactPersonPage.cancelClaim();
		ClaimListPage claimListPage = new ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
		((NewClaimLocationPage) claimListPage.openDraftClaim(draftNum)).goToRepairChoicePage().selectNoFacility().areNewPersonDetailsAreSaved().shouldBeTrue("New injured person's details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5356")
	public void testClaimIsSavedAsDraftWhenCancelledOnSummaryPage(String browserName) throws Exception {
		NewClaimSummaryPage claimSummaryPage = cpPageFactory.login().fileAClaim().selectPolicy()
				.goNext().selectPAClaimType().goNext().withVehicleInvolved().withExactAccidentAddress().goToRepairChoicePage().selectNoFacility().withNewContactPerson().goNext().selectContact().withContactCellNum()
				.goToSummary();
		String draftNum = claimSummaryPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimSummaryPage.cancelClaim();
		ClaimListPage claimListPage = new ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "SIGN_UP" }, description = " ")
	public void testClaimPortalProducerSignUp(String browserName) throws Exception {
		new LoginPage().goToSignUpPage().setSignUpData().clickSignUpButton().isSignUpSuccessful();
	}

}
