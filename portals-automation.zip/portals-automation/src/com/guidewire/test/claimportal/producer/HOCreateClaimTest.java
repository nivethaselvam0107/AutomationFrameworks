package com.guidewire.test.claimportal.producer;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;

public class HOCreateClaimTest {
	CPPageFactory cpPageFactory = new CPPageFactory();

	private void validateClaim(String claimNum) throws Exception {
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage
				.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim is not listed");

		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary
				.isClaimSummaryDataMatchingWithBackEnd(claimNum)
				.shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary
				.isClaimDetailsDataMatchingWithBackEnd(claimNum)
				.shouldBeTrue("Claim Details Data is not matched with Back End");
	}

	private void createHOFireClaim() throws Exception{
		String claimNum = cpPageFactory
				.createFireClaim()
				.withContactHomeNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		this.validateClaim(claimNum);
	}

	private void createHOWaterClaim() throws Exception{
		String claimNum = cpPageFactory
				.createWaterClaim()
				.withContactHomeNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		this.validateClaim(claimNum);
	}

	private void createHOCrimeClaim() throws Exception{
		String claimNum = cpPageFactory
				.createCrimeClaim()
				.withContactHomeNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		this.validateClaim(claimNum);
	}

	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" , "SMOKE" }, description = " ")
	public void testHOFireClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOFireClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" , "SMOKE"  }, description = "TC5374")
	public void testHOWaterClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOWaterClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR"  }, description = "TC5372")
	public void testHOFireDefaultClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOFireClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "TC5373")
	public void testHOFireClaimCreationWithInjured(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOFireClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "TC5375")
	public void testHOWaterClaimCreatioNonDefault(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOWaterClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" , "SMOKE" }, description = "TC5376")
	public void testHOCrimeClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOCrimeClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {  "REG_EMR" }, description = "TC5377")
	public void testHOCrimeClaimCreationNonDefault(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		this.createHOCrimeClaim();
	}
	
	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "SMOKE"}, description = "TC5378")
	public void testHOOtherClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		ContactUSPage contactUSPage = cpPageFactory.createHOOtherClaim();
		contactUSPage
				.isContactUsPageLoaded()
				.shouldBeTrue("Contactus Page is not loaded");
		contactUSPage
				.goToClaimPageCP()
				.isClaimListPageLoaded()
				.shouldBeTrue("Claim Page is not loaded");
	}
}