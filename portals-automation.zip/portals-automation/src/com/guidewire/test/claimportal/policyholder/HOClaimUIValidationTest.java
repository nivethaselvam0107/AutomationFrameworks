package com.guidewire.test.claimportal.policyholder;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.util.DateUtil;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class HOClaimUIValidationTest {
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5227")
	public void testHOClaimCreationDraft(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext().withNewContactPerson();
		String draftNum = claimContactPersonPage.getDraftClaimNumber();
		AlertHandler alertHandler = claimContactPersonPage.pressCancelClaim();
		alertHandler.isCancelSubmissionPopUpDisplayed().shouldBeEqual();
		alertHandler.closeAlert();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOFireClaim(String browserName) throws Exception {
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for fire claim");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5229")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOWaterClaim(String browserName) throws Exception {
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for Water Claim");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5230")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPageHOCrimeClaim(String browserName) throws Exception {
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToCrimeDetailsPage().setCrimeDetails().goNext().addNewContactPerson();
		claimDocumentPage.goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New person fields are not marked with error for crime claim");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC523")
	public void testHOWaterClaimNewPersonAddedIsAvailableOnContactPersonPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext();
		claimContactPersonPage.validateNewlyCreatedPersonListing().shouldBeTrue("Newly Create Person on Document page is not listed on Contact person page");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5231")
	public void testHOFireClaimNewPersonAddedIsAvailableOnContactPersonPage(String browserName) throws Exception {
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext();
		claimContactPersonPage.validateNewlyCreatedPersonListing().shouldBeTrue("Newly Create Person on Document page is not listed on Contact person page");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5234")
	public void testHOFireClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5235")
	public void testHOWaterClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToWaterDamageDetailsPage().setWaterDamageDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5236")
	public void testHOCrimeClaimMandatoryFieldsOnContactPersonPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToCrimeDetailsPage().setCrimeDetails().goNext().uploadDocFromFNOL().withNewContactPerson().goNext().addNewContact().goNext();
				claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
				claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number missing error message for New contact is not correct");
				String claimNum = claimContactPersonPage.setNewContactPersonDetails().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5247")
	public void validateNoPolicyListedWhenDOLNotMatching(String browserName) throws Exception {
		cpPageFactory.login().fileAClaim().withClaimDateOfLoss(DateUtil.getDateIn12HrsFormat(-30)).verifyNoPolicyListingWhenDOLNotMatchingPolicyValidity().shouldBeEqual("No Policy Listed error message is not correct");
	}
}
