package com.guidewire.test.claimportal.policyholder;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimVehicleDriverPage;

public class PAClaimUIValidationTest {
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5188")
	public void validateMandatoryFieldsOnClaimIncidentLocation(String browserName) throws Exception {
		NewClaimLocationPage incidentLocation = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext();
		incidentLocation.goToVehicleDriverPage();
		incidentLocation.validateCityFieldErrorMessage()
				.shouldBeEqual("Error message for City Field in Exact address section is not correct");
		incidentLocation.openCityOnlyLocationSection().validateCityFieldErrorMessage()
				.shouldBeEqual("Error message for City Field in City Only address section is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5189")
	public void validateMandatoryFieldsOnVehicleDriverPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimVehicleDriverPage vehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage();
		vehicleDriverPage.goNext();
		vehicleDriverPage.validateDriverDropDownFieldErrorMessage()
				.shouldBeEqual("Driver drop down field error message is not correct");
		vehicleDriverPage.validateVehicleDropDownFieldErrorMessage()
				.shouldBeEqual("Vehicle drop down field error message is not correct");
		vehicleDriverPage.selectOtherDriver().selectOtherVehicle().goNext();
		vehicleDriverPage.validateNewDriverMandatoryFieldsErrorMessage()
				.shouldBeTrue("Error message for Driver mandatory fields is not correct");
		vehicleDriverPage.validateNewVehicleMandatoryFieldsErrorMessage()
				.shouldBeTrue("Error message for Vehicle mandatory fields is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5186")
	public void validateMandatoryFieldsForPassengerOnVehicleDriverPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimVehicleDriverPage vehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage();
		vehicleDriverPage.addNewPassenger().goNext();
		vehicleDriverPage.validatePassengerMandatoryFieldsErrorMessage()
				.shouldBeTrue("Driver drop down field error message is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5187")
	public void validateMandatoryFieldsForPersonOnSupportDocumentPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimDocumentPage claimDocumentPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility();
		claimDocumentPage.addNewContactPerson().goNext();
		claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag()
				.shouldBeTrue("New Contact fields are not marked with error");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5190")
	public void validateExistingContactDetailsOnSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		cpPageFactory.login().fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.selectCollisionClaimType().goNext().withOnlyCity().goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle()
				.goToRepairChoicePage().selectNoFacility().goNext().selectContact().withContactHomeNum().goToSummary()
				.validateExistingContactsDetailsOnSummaryPage().shouldBeEqual("Contact Person details is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5191")
	public void validateNewContactDetailsOnSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		cpPageFactory.login().fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.selectCollisionClaimType().goNext().withOnlyCity().goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle()
				.goToRepairChoicePage().selectNoFacility().goNext().withNewContactPerson().withContactHomeNum().goToSummary()
				.validateNewContactsDetailsOnSummaryPage().shouldBeEqual("New Contact Person details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5192")
	public void validateErrorMessageForMissingContactNumberOnContactPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext();
		claimContactPersonPage.withoutCellNumber().goToSummary();
		claimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage()
				.shouldBeEqual("Contact Nu ber required error message is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC593")
	public void validateEmailErrorMessageOnContactPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext();
		claimContactPersonPage.validateEmailFieldOnSummaryPage().shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5194")
	public void validateMandatoryErrorMessageforNewContactOnContactPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().selectCollisionClaimType().goNext().withOnlyCity()
				.goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().goToRepairChoicePage().selectNoFacility().goNext().addNewContact()
				.addNewContact().goNext();
		claimContactPersonPage.validateMandatoryErrorMessageForNewPersonFields()
				.shouldBeTrue("Mandatory error message for New contact is not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5197")
	public void testClaimIsNotSavedOnDOLPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		cpPageFactory.login().fileAClaim().selectPolicy().cancelClaim().isClaimListPageLoaded()
				.shouldBeTrue("Claim list page is not displayed and Claim save opop is displayed");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5198")
	public void testClaimIsNotSavedOnWhatHappenedPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		cpPageFactory.login().fileAClaim().selectPolicy().goNext().selectPAClaimType()
				.cancelClaim().isClaimListPageLoaded()
				.shouldBeTrue("Claim list page is not displayed and Claim save opop is displayed");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "SIGN_UP" }, description = " ")
	public void testClaimPortalPolicyHolderSignUp(String browserName) throws Exception {
		new LoginPage().goToSignUpPage().setSignUpData().clickSignUpButton().isSignUpSuccessful();
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5199")
	public void testClaimIsSavedAsDraftWhenCancelledOnWhatLocationPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimLocationPage claimLocationPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext();
		String draftNum = claimLocationPage.getDraftClaimNumber();
		claimLocationPage.cancelClaim().closeSubmissionAlert();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5200")
	public void testClaimIsSavedAsDraftWhenCancelledOnVehicleDriverPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimVehicleDriverPage claimVehicleDriverPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().goToVehicleDriverPage();
		String draftNum = claimVehicleDriverPage.getDraftClaimNumber();
		claimVehicleDriverPage.cancelClaim().closeSubmissionAlert();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" , "SMOKE" }, description = "TC5201")
	public void testClaimIsSavedAsDraftWhenCancelledOnDocumentPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimDocumentPage claimDocuemntPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().goToVehicleDriverPage().selectFirstAvailableDriver().selectFirstAvailableVehicle().
				setAirBagDeployStatus().setEquiFailureStatus().setVehicleCollisionPoint().setVehicleRentalStatus().setVehicleSafetyToDrive().setVehicleTowStatus().goToRepairChoicePage().selectNoFacility();
		String draftNum = claimDocuemntPage.getDraftClaimNumber();
		claimDocuemntPage.cancelClaim().closeSubmissionAlert();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateDraftClaimNumberFormat(draftNum).shouldBeTrue("Draft Claim number format is not correct" + draftNum);
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
		((NewClaimVehicleDriverPage) claimListPage.openPADraftClaim(draftNum)).goToVehicleDriverPage().areVehicleDriverDetailsAreSaved().shouldBeTrue("Vehicle driver details are not saved correctly");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5202")
	public void testClaimIsSavedAsDraftWhenCancelledOnContactPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory.login().fileAClaim()
				.selectPolicy().goNext().selectPAClaimType().goNext().withExactAccidentAddress().withVehicleInvolved()
				.withTheftVehicleDamageDetails().withClaimDescription().goToRepairChoicePage().selectNoFacility().uploadDocFromFNOL().withNewContactPerson().goNext();
		String draftNum = claimContactPersonPage.getDraftClaimNumber();
		claimContactPersonPage.cancelClaim();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
		((NewClaimLocationPage) claimListPage.openPADraftClaim(draftNum)).goToRepairChoicePage().selectNoFacility().areNewPersonDetailsAreSaved().shouldBeTrue("New injured person's details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA" }, description = "TC5203")
	public void testClaimIsSavedAsDraftWhenCancelledOnSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		NewClaimSummaryPage claimSummaryPage = cpPageFactory.login().fileAClaim().selectPolicy()
				.goNext().selectPAClaimType().goNext().withVehicleInvolved().withExactAccidentAddress().goToDocumentPage().uploadDocFromFNOL().withNewContactPerson().goNext().withContactCellNum()
				.goToSummary();
		String draftNum = claimSummaryPage.getDraftClaimNumber();
		claimSummaryPage.cancelClaim();
		new CP_ClaimListPage().validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
	}

}
