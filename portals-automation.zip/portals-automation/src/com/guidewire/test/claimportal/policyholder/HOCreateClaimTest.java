package com.guidewire.test.claimportal.policyholder;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;

public class HOCreateClaimTest 
{
	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" , "SMOKE"}, description = "TC5222")
	public void testHOFireClaimCreation(String browserName) throws Exception {
		String claimNum = cpPageFactory.createFireClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"  , "SMOKE"  }, description = "TC5223")
	public void testHOWaterClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		String claimNum = cpPageFactory.createWaterClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5220")
	public void testHOFireDefaultClaimCreation(String browserName) throws Exception {
		String claimNum = cpPageFactory.createFireClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5221")
	public void testHOFireClaimCreationWithInjured(String browserName) throws Exception {
		String claimNum = cpPageFactory.createFireClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"}, description = "TC5223")
	public void testHOWaterClaimCreatioNonDefault(String browserName) throws Exception {
		String claimNum = cpPageFactory.createWaterClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR"  , "SMOKE" }, description = "TC5224")
	public void testHOCrimeClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		String claimNum = cpPageFactory.createCrimeClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5225")
	public void testHOCrimeClaimCreationNonDefault(String browserName) throws Exception {
		String claimNum = cpPageFactory.createCrimeClaim().withContactHomeNum().goToSummary().submitClaim().getClaimNumber();
		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data is not matched with Back End");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR",  "SMOKE" }, description = "TC5226")
	public void testHOOtherClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		ContactUSPage contactUSPage = cpPageFactory.createHOOtherClaim();
		contactUSPage.isContactUsPageLoaded().shouldBeTrue("Contactus Page is not loaded");
		contactUSPage.goToClaimPageCP().isClaimListPageLoaded().shouldBeTrue("Claim Page is not loaded");
	}
}