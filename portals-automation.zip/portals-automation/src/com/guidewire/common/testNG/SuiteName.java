package com.guidewire.common.testNG;

import com.guidewire.common.util.EnumHelper;

public enum SuiteName {

    CPPH("CP-PolicyHolder"),
    CPAGENT("CP-Producer"),
    CPVENDOR("CP-ClaimVendor"),
    CPVENDOR_SERVICE("CP-VendorService"),
    GPA("GPA"),
    QNB("QnB"),   
    AMP("AMP");

    private final String suiteName;

    SuiteName(final String suiteName) {
        this.suiteName = suiteName;
    }

    @Override
    public String toString() {
        return this.suiteName;
    }

    public static SuiteName fromString(String name) {
        return EnumHelper.fromString(SuiteName.class, name);
    }
}
