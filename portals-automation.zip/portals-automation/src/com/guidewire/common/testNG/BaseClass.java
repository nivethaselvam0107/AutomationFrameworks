package com.guidewire.common.testNG;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import com.guidewire.common.selenium.DriverManager;
import com.guidewire.common.selenium.ThreadLocalObject;

public class BaseClass {

	public HashMap<String, String> testData;
	@Parameters("browserName")
	@BeforeMethod
	public void beforeMethod(String browserName, Method method) {
		try {
//			testData = ReadTestData.getTestData(method.getName(), "QnB");
		} catch (Exception e) {
			e.printStackTrace();
		}
		WebDriver driver = DriverManager.getInstance().initDriver(browserName,method.getName());
		ThreadLocalObject.setWebDriver(driver);
		ThreadLocalObject.setData(testData);
		if(!(browserName.equals("iOS") || browserName.equals("android")))
			{
				driver.manage().window().maximize();
			}
		driver.get("http://mmportal8.guidewire.com/qnb-portal/dist/html/index.html#/home");
		Reporter.log("Before Method for "+ method.getName()  + " and " + Thread.currentThread().getName() );
	}

	@Parameters("browserName")
	@AfterMethod
	public void afterMethod(String browserName) {
		WebDriver driver = ThreadLocalObject.getDriver();
		ThreadLocalObject.resetData();
		driver.quit();
		ThreadLocalObject.removeWebDriver(driver);
	}
	
	@Parameters("browserName")
	void setUp(String browserName)
	{
		System.out.println(browserName);
	}
}
