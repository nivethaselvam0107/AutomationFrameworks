package com.guidewire.common.testNG;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.Rotatable;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.guidewire.capabilities.agent.data.AgentUserName;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.DriverManager;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.PropertiesReader;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.data.ReadTestData;

public class InvocationListner implements IInvokedMethodListener {

	Process iosProcess;
	Process iosWebKitProcess;
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		initializeLogger();
		HashMap<String, String> testDataFinal = null;

		String browserName = method.getTestMethod().getXmlTest().getAllParameters().get("browserName");
		BrowserType browserType = BrowserType.fromString(browserName);
		String testName = method.getTestMethod().getMethodName();
		String suiteNameFromParam = method.getTestMethod().getXmlTest().getAllParameters().get("suite");
		String suiteName = suiteNameFromParam != null ? suiteNameFromParam : method.getTestResult().getTestContext().getSuite().getXmlSuite().getName();

		ThreadLocalObject.setBrowserName(browserName);
		ThreadLocalObject.setTestName(testName);
		ThreadLocalObject.setSuitenName(suiteName);

		WebDriver driver = DriverManager
				.getInstance().initDriver(method.getTestMethod().getXmlTest().getAllParameters().get("browserName"), method.getTestMethod().getMethodName());
		ThreadLocalObject.setWebDriver(driver);


		try {
			testDataFinal = ReadTestData.getTestData(testName, ReadTestData.getSuiteDataFileName(suiteName));
			testDataFinal.put("Browser", browserName);
			testDataFinal.put("Suite", suiteName);
			testDataFinal.put("PWD", "password");
			ThreadLocalObject.setData(testDataFinal);
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (suiteName.equalsIgnoreCase(SuiteName.CPVENDOR.toString()))
		{

			// Will create these values in Sample Data as a new task
			String platform = System.getProperty("platform");
			if(platform.equalsIgnoreCase("Ferrite"))
			{
				testDataFinal.put("ClosedClaim","000-00-502874");
				testDataFinal.put("VendorCompanyName", "Chilton Auto 951");
				//testDataFinal.put("VendorCompanyName", "A+ Japanese Auto 664");
			}else if(platform.equalsIgnoreCase("Emerald"))
			{
				testDataFinal.put("ClosedClaim","000-00-319015");
				testDataFinal.put("VendorCompanyName", "Chilton Auto 872");

			}
		}
		
		if( System.getProperty("uid") != null && !System.getProperty("uid").equals("")) {
			testDataFinal.put("USER", System.getProperty("uid") );
			testDataFinal.put("USER_NAME", System.getProperty("uid"));
		}
		else {
			if(!suiteName.equalsIgnoreCase(SuiteName.GPA.toString())) {
				testDataFinal.put("USER", testDataFinal.get("USER") + "@" + System.getProperty("platform") + ".com");
				testDataFinal.put("USER_NAME",AgentUserName.getValueByUname(testDataFinal.get("USER")) );
			}
		}

		if(System.getProperty("pwd") !=null && !System.getProperty("pwd").equals("")) {
			if(suiteName.equalsIgnoreCase(SuiteName.GPA.toString())) {
				testDataFinal.put("PWD", "gw");
				testDataFinal.put("USER_NAME",AgentUserName.getValueByUname(System.getProperty("uid")) );
			}
			else
				testDataFinal.put("PWD", System.getProperty("pwd") );
		}

		if(browserName.equals("iPAD") || browserName.equals("iPhone6"))
		{
			//iosProcess = executeCommand("appium -p 4723 -U ff57ed38b4cf9b3cdc4a42620f68fc14da954aff --session-override -log iPad.log");
			//iosWebKitProcess = executeCommand("ios_webkit_debug_proxy -c  ff57ed38b4cf9b3cdc4a42620f68fc14da954aff:27753 -d");
		}

		if (!(BrowserType.mobile.contains(browserType))) {
			driver.manage().window().maximize();
		}

		if(suiteName.equalsIgnoreCase(SuiteName.CPPH.toString()) && testDataFinal.get("POLICY_NUM")!=null)
		{
			AuthorisationServer.assignPolicyToUser(testDataFinal.get("USER"), testDataFinal.get("POLICY_NUM"));
			new SeleniumCommands().logInfo(AuthorisationServer.getExistingPolicies(testDataFinal.get("USER")).toString());
		}

		if (! browserName.equals("MicrosoftEdge")) {
			Set cookies = driver.manage().getCookies();
			if (cookies.size() > 0)
				logger.info("Browser COOKIES:\n" + cookies.toString());
		}

		logger.info("TEST CASE [" + testName + "] DATA:\n" + testDataFinal);
		//driver.manage().deleteAllCookies();

		logger.info("Setting variables: \n\tbrowserName\t" + browserName + "\n" +
				"\ttestName\t" + testName + "\n" +
				"\tsuiteName\t" + suiteName + "\n" +
				"\turl\t\t" + PropertiesReader.getURL(suiteName));

		driver.get(PropertiesReader.getURL(suiteName));

		Reporter.log("Before Method for " + method.getTestMethod().getMethodName() + " and "
				+ Thread.currentThread().getName());
		rotateMobileViewToPortrait();
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
        deleteDynamicCreatedUser();
		ThreadLocalObject.resetData();
		ThreadLocalObject.resetBrowserName();
		ThreadLocalObject.resetTestNameName();
		ThreadLocalObject.resetData();
	}

	private void initializeLogger() {
		Properties logProperties = new Properties();

		try {
			// load our log4j properties / configuration file
			logProperties.load(new FileInputStream("src/log4j.properties"));
			PropertyConfigurator.configure(logProperties);
		} catch (IOException e) {
			throw new RuntimeException("Unable to load logging property ");
		}
	}
	
	public void rotateMobileViewToLandscape()
	{
		String browser = ThreadLocalObject.getBrowserName();
		if (BrowserType.mobile.contains(BrowserType.fromString(browser))) {
			WebDriver augmentedDriver = new Augmenter().augment(ThreadLocalObject.getDriver());
			((Rotatable) augmentedDriver).rotate(ScreenOrientation.LANDSCAPE);
		}
	}
	
	public void rotateMobileViewToPortrait()
	{
		String browser = ThreadLocalObject.getBrowserName();
		if (BrowserType.phone.contains(BrowserType.fromString(browser))) {
			WebDriver augmentedDriver = new Augmenter().augment(ThreadLocalObject.getDriver());
			((Rotatable) augmentedDriver).rotate(ScreenOrientation.PORTRAIT);
		} else {
			rotateMobileViewToLandscape();
		}
	}
	
	public String getURL(String application)
	{
		if(application.equals("CP-PolicyHolder"))
		{
			return DataConstant.CP_POLICYHOLDER_URL;
		}
		else if(application.equals("CP-Producer"))
		{
			return DataConstant.CP_PRODUCER_URL;
		}
		else if(application.equals("QnB"))
		{
			return DataConstant.QnB_URL;
		}
		
		return null;
	}
	
	private Process executeCommand(String command) {

		StringBuffer output = new StringBuffer();

		Process process = null;
		try {
			process = Runtime.getRuntime().exec(command);
			process.waitFor();
			BufferedReader reader = 
                            new BufferedReader(new InputStreamReader(process.getInputStream()));

                        String line = "";			
			while ((line = reader.readLine())!= null) {
				output.append(line + "\n");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return process;

	}
	
	private void removePolicyFromPolicyHolder() {
		if(ThreadLocalObject.getSuitenName().equals(SuiteName.CPPH.toString())) {
			HashMap<String, String> data = ThreadLocalObject.getData();
			String userName = data.get("USER");
			String policyNum = data.get(PolicyData.POLICY_NUM.toString());
			logger.info("Removing the policy assignment==> " + policyNum + " for the User - > " + userName);
			try {
				if (data.containsKey("PolicyAssignedToUser")) {
					AuthorisationServer.removePolicyFromExistingUser(userName, policyNum);
				}
			} catch (NullPointerException e) {
				logger.info("Dynamic policygenerator was not used for this test, so PolicyAssignedToUser flag was not set.");
			}
		}
	}
	
	private void deleteDynamicCreatedUser() {
		try {
			HashMap<String, String> data = ThreadLocalObject.getData();
			String userName = data.get("USER");
			if(data.containsKey("CreateUser"))
			{
				logger.info("Removing the dynamically generated policyholder user > "+  userName);
				AuthorisationServer.deleteUser(userName);
			}
		} catch (NullPointerException e) {
			logger.info("Problem in removing the dynamically generated policyholder user");
		}
	}
	
}