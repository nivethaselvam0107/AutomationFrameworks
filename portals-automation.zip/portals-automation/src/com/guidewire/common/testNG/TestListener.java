package com.guidewire.common.testNG;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.TestListenerAdapter;

import com.guidewire.common.selenium.ThreadLocalObject;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.coordinates.WebDriverCoordsProvider;
import ru.yandex.qatools.ashot.cropper.indent.BlurFilter;
import ru.yandex.qatools.ashot.cropper.indent.IndentCropper;

public class TestListener extends TestListenerAdapter {

	Logger logger = Logger.getLogger(this.getClass().getName());

	public TestListener() {
	}

	@Override
	public void onStart(ITestContext testContext) {
	}

	@Override
	public void onTestStart(ITestResult result) {
	}

	@Override
	public void onTestFailure(ITestResult result) {
		logger.info(result.getMethod().getMethodName() + " test case is failed.");
		result.getThrowable().printStackTrace();
		storeLatestResultForTest(result);
		try {
			if (result.getMethod().getXmlTest().getLocalParameters().get("browserName").equals("chrome")) {

				captureLogAndScreenShot(result);
			} else {
				captureLogAndScreenShotForFirefox(result);
			}
		} catch (Exception e) {
			logger.info("Error when capturing the screen shot.");
			e.printStackTrace();
		} finally {
			updateStatus("false");
			removeDriver();
		}
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		logger.info(result.getMethod().getMethodName() + " test case is passed.");
		updateStatus("true");
		removeDriver();
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// nothing
	}

	@Override
	public void onFinish(ITestContext testContext) {
        logger.info("Final report preparation.");
		Set<ITestResult> skippedTests = testContext.getSkippedTests().getAllResults();
		for (ITestResult temp : skippedTests) {
			if (testContext.getPassedTests().getAllMethods().contains(temp.getMethod())) {
				skippedTests.remove(temp);
			} else {
				if (testContext.getFailedTests().getAllMethods().contains(temp.getMethod())) {
					skippedTests.remove(temp);
				}
			}
		}
	}

	public String getClassName(String className) {
		String name = className.substring(className.lastIndexOf(".") + 1);
		return name;
	}

	public String getPackageName(ITestResult result) {
		String packageName = result.getTestClass().getName();
		String lastWord = packageName.substring(packageName.lastIndexOf(".") + 1);
		String name = lastWord.substring(0, 1).toUpperCase() + lastWord.substring(1);
		return name;
	}

	public void captureLogAndScreenShotForFirefox(ITestResult result) throws Exception {
		logger.info("Taking screenshot on test failure.");
		String screenShotDir = "Reports/"+ System.getProperty("suite.name") +"/ScreenShot/";
		logger.info("Driver is null - " + ThreadLocalObject.getDriver());
		WebDriver augmentedDriver = new Augmenter().augment(ThreadLocalObject.getDriver());
		File scrFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
		String file_name = screenShotDir + result.getMethod().getMethodName() + "-"
				+ result.getMethod().getXmlTest().getLocalParameters().get("browserName") + "-"
				+ System.currentTimeMillis() + ".png";
		FileUtils.copyFile(scrFile, new File(file_name));
		logger.info("Screenshot is located at: " + scrFile.getAbsolutePath());
		Reporter.log("<br> <img src="+ file_name + " /> <br>");
	}

	public void captureLogAndScreenShot(ITestResult result) throws Exception {
		logger.info("Taking screenshot on test failure.");
		logger.info("Driver is - " + ThreadLocalObject.getDriver());
		String screenShotDir = "Reports/"+ System.getProperty("suite.name") +"/ScreenShot/";
		String file_name = screenShotDir + result.getMethod().getMethodName() + "-"
				+ result.getMethod().getXmlTest().getLocalParameters().get("browserName") + "-"
				+ System.currentTimeMillis() + ".png";
		final Screenshot screenshot = new AShot().coordsProvider(new WebDriverCoordsProvider())
				.imageCropper(new IndentCropper() // overwriting cropper
						.addIndentFilter(new BlurFilter()))
				.takeScreenshot(ThreadLocalObject.getDriver());
		// = new AShot().shootingStrategy(new ViewportPastingStrategy(500))
		// .takeScreenshot(ThreadLocalDriver.getDriver());
		final BufferedImage image = screenshot.getImage();
		ImageIO.write(image, "PNG", new File(file_name));
		Reporter.log("<br> <img src="+ file_name + " /> <br>");
	}

	private static void removeDriver() {
		WebDriver driver = ThreadLocalObject.getDriver();
		 if (driver != null) {
		 driver.quit();
		 }
		ThreadLocalObject.removeWebDriver(driver);
	}
	
	private static void storeLatestResultForTest(ITestResult result) {
		if (result.getMethod().getRetryAnalyzer() != null) {
			RetryTestListner retryAnalyzer = (RetryTestListner)result.getMethod().getRetryAnalyzer();
            if(retryAnalyzer.isRetryAvailable()) {
            } else {
                result.setStatus(ITestResult.FAILURE);
            }
            Reporter.setCurrentTestResult(result);
        }
	}

	private void updateStatus(String status){
		if(!System.getProperty("sauce.run").equalsIgnoreCase("false")) {
			try {
				String userPassword = "sl_cumulus_dsb" + ":" + "3e17a46a-44d4-41de-9b25-37b45b93b726";
				String encoding = Base64.getEncoder().encodeToString(userPassword.getBytes("utf-8"));
				URL url = new URL("https://saucelabs.com/rest/v1/sl_cumulus_dsb/jobs/" + ((RemoteWebDriver) ThreadLocalObject.getDriver()).getSessionId().toString());
				HttpURLConnection conn = (HttpURLConnection) url.openConnection();

				conn.setDoOutput(true);
				conn.setRequestMethod("PUT");
				conn.setRequestProperty("Content-Type", "application/json");
				conn.setRequestProperty("Authorization", "Basic " + encoding);
				String input = "{\"passed\":" + status + "}";

				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes());
				os.flush();
				conn.getResponseCode();
				conn.disconnect();
			} catch (MalformedURLException e) {

				e.printStackTrace();

			} catch (IOException e) {

				e.printStackTrace();

			}
		}
	}

}
