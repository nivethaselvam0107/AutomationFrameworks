package com.guidewire.common.testNG;

import org.apache.log4j.Level;
import org.testng.Assert;

public class Validation {

	public Object actualResult;
	public Object expectedResult;
	org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(this.getClass().getName());

	public Validation(Object actualResult) {
		this.actualResult = actualResult;
	}

	public Validation(Object actualResult, Object expectedResult) {
		this.actualResult = actualResult;
		this.expectedResult = expectedResult;
	}

	/**
	 * Asserts True with assertion message
	 * 
	 * @param assertMessage
	 */
	public void shouldBeTrue(String assertMessage) {
		Assert.assertTrue((boolean) this.actualResult, assertMessage);
	}

	/**
	 * Asserts True without assertion message
	 */
	public void shouldBeTrue() {
		Assert.assertTrue((boolean) this.actualResult);
	}

	/**
	 * Asserts false without assertion message
	 */
	public void shouldBeFalse() {
		Assert.assertFalse((boolean) this.actualResult);
	}

	/**
	 * Asserts false with assertion message
	 * 
	 * @param assertMessage
	 */
	public void shouldBeFalse(String assertMessage) {
		Assert.assertFalse((boolean) this.actualResult, assertMessage);
	}

	/**
	 * Asserts equal with only expected results without assertion message
	 */
	public void shouldBeEqual() {
		Assert.assertEquals(this.actualResult, this.expectedResult);
	}

	/**
	 * Asserts equal with expected results with assertion message
	 *
	 * @param assertMessage
	 */
	public void shouldBeEqual(String assertMessage) {
		Assert.assertEquals(this.actualResult, this.expectedResult, assertMessage);
	}

	/**
	 * Asserts not equal with only expected results without assertion message
	 */
	public void shouldNotBeEqual() {
		Assert.assertNotEquals(this.actualResult, this.expectedResult);
	}

	/**
	 * Asserts not equal with expected results with assertion message
	 *
	 * @param assertMessage
	 */
	public void shouldNotBeEqual(String assertMessage) {
		Assert.assertNotEquals(this.actualResult, this.expectedResult, assertMessage);
	}
}