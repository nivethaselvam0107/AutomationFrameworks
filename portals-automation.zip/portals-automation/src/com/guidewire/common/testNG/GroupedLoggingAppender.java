/*
* Multi-threaded testing log will mess up each other, it's hard to find out which long belongs to which test
*
* This class act as a log4j Appender *and* testng reporter
*
*   - since it's log4j appender, all thread will call the same append function
*     then it write the log into different file based on the *current* thread id
*
*   - after all test, the testng reporter will be called, logs are merged here
*     using reporter just to ensure it's called after all tests are done
*
*
* Usage:
*
*  set your project's log4j.properties to include com.fayaa.testnglog.GroupedLoggingAppender as one of the logger
*
*  java -Doutputdir=/x/y/z/ org.testng.TestNG -reporter com.fayaa.testnglog.GroupedLoggingAppender your_testng.xml
*
*
* Other: same mechanism could be applied to other test/log library, or even other language
*
*/

package com.guidewire.common.testNG;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.annotations.Parameters;
import org.testng.xml.XmlSuite;

import com.guidewire.common.selenium.ThreadLocalObject;

public class GroupedLoggingAppender extends AppenderSkeleton implements IReporter {
   private final ConcurrentHashMap<Long, BufferedWriter> tid2file = new ConcurrentHashMap<Long, BufferedWriter>();

   private final String outputDir;
   private final String outputFile;
   private final String ext = ".threadlog.txt";

   public GroupedLoggingAppender() {

	   String portalName = System.getProperty("suite.name")!=null ? System.getProperty("suite.name") : "TestSuite";

       String outdir = "Reports/"+ portalName +"/Log/TestLog";
       if (!outdir.endsWith("/"))
           outdir += "/";
       outputDir = outdir;
       File dir = new File(outdir);
       if (!dir.exists()) dir.mkdirs();

       outputFile = outputDir + "output.log.grouped.txt";
       try {
           if (outputDir != null) {
               Files.deleteIfExists(FileSystems.getDefault().getPath(outputFile));
           }
       } catch (IOException e) {
           e.printStackTrace();
       }
   }

   @Override
   public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
       System.out.println("Reporter getting called! " + outputDir);
       // we don't do any report generation here, just clean up the log files
       mergeLogFiles();
   }

   @Override
   public void close() {
   }

   private void mergeLogFiles() {
       try {
           new File(outputFile).createNewFile();
           File file = new File(outputDir);
           File[] files = file.listFiles(new FileFilter() {
               @Override
               public boolean accept(File pathname) {
                   return pathname.getName().endsWith(ext);
               }
           });

           List<Path> paths = new ArrayList<Path>();
           for (File f : files) {
               Path path = f.toPath();
               paths.add(path);
           }
           Collections.sort(paths);
           Path pathAll = FileSystems.getDefault().getPath(outputFile);
           for (Path path : paths) {
               Files.write(pathAll, Files.readAllBytes(path), StandardOpenOption.APPEND, StandardOpenOption.CREATE);
               Files.delete(path);
           }
       } catch (IOException e) {
           e.printStackTrace();
           throw new RuntimeException(e);
       }
   }

   @Override
   public void append(LoggingEvent event) {
       if (outputDir == null)
           return; // by default nothing appended
       try {
    	   String msg = event.getMessage().toString();
    	   String browser = "";
    	   if(msg.contains("Browser-TestName:"))
    	   {
    		   browser = msg.split(":")[1];
    	   }
           long tid = Thread.currentThread().getId();
           BufferedWriter fw = tid2file.get(tid);
           String filepath = outputDir + ThreadLocalObject.getTestName()  + "-" + ThreadLocalObject.getBrowserName() + ext;
           if (fw == null) {
               new File(filepath).createNewFile();
               fw = new BufferedWriter(new FileWriter(filepath));
               tid2file.put(tid, fw);
           }
           fw.write(usingDateFormatterWithTimeZone(event.getTimeStamp()) + "-" + event.getLevel().toString() + "-" + event.getLoggerName()+"-->>" + event.getMessage().toString());
           fw.write("\n");
           fw.flush();
       } catch (IOException e) {
           e.printStackTrace();
           throw new RuntimeException(e);
       }
   }

   @Parameters("browserName")
   private String getFileNameFromThreadID() {
//       return String.format("%sthread_output_%04d%s", outputDir, tid, ext);
	   return String.format(Thread.currentThread().getName(), ext);
   }

   @Override
   public boolean requiresLayout() {
       return false;
   }
   
   private String usingDateFormatterWithTimeZone(long input){
       Date date = new Date(input);
       Calendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss z");
       sdf.setCalendar(cal);
       cal.setTime(date);
       return sdf.format(date);

   }
}

