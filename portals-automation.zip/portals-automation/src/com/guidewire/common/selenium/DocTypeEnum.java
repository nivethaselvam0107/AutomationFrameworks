package com.guidewire.common.selenium;

/**
 * Created by soverma on 19/09/2016.
 */
public class DocTypeEnum {

    enum FileType {
        PDF("resources/FileTypes/PDFFile.pdf"), PNG("resources/FileTypes/PNGFile.png"),
        DOC("resources/FileTypes/DOCFile.doc"), DOCX("resources/FileTypes/DOCXFile.docx"),
        JS("resources/FileTypes/JSFile.js"), TXT("resources/FileTypes/TXTFile.txt"),
        JPG("resources/FileTypes/JPGFile.jpg"), HTML("resources/FileTypes/HTMLFile.html"),
        GIF("resources/FileTypes/GIFFile.gif"), SAMPLE("resources/FileTypes/SAMPLEFile.docx");

        private String docPath;

        private FileType(String value) {
            this.docPath = value;
        }

        public String getValue() {
            return docPath;
        }
    }

}
