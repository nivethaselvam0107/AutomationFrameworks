package com.guidewire.common.selenium;

public final class DriverTimeout {

    private static final DriverTimeout INSTANCE = new DriverTimeout();

    private static int DEFAULT_WAIT_IN_SECONDS = 120;
    private static int DEFAULT_WAIT_IN_MILLIS = 120000;

    public static void setTimeout(int seconds) {
        INSTANCE.DEFAULT_WAIT_IN_MILLIS = seconds * 1000;
        INSTANCE.DEFAULT_WAIT_IN_SECONDS = seconds;
    }

    public static int getDefaultWaitInSeconds() {
        return new Integer(DEFAULT_WAIT_IN_SECONDS);
    }

    public static int getDefaultWaitInMillis() {
        return new Integer(DEFAULT_WAIT_IN_MILLIS);
    }
}
