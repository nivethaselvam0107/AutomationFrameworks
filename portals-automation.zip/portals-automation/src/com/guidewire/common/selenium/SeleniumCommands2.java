package com.guidewire.common.selenium;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;


public final class SeleniumCommands2
{

   private final int DEFAULT_WAIT_IN_SECONDS = 60;
   
   private final int DEFAULT_WAIT_IN_MILLIS = 60000;

   Logger logger = Logger.getLogger(this.getClass().getName());	
   String browsername = ThreadLocalObject.getBrowserName();
   public HashMap<String, String> testData = ThreadLocalObject.getData();
   
   // boolean helpers

   public void sendALTKeyCombinations(String key, String cssSelector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      driver.findElement(By.cssSelector(cssSelector)).sendKeys(Keys.chord(Keys.ALT, key));
   }

   /**
    * Checks the element is editable. Original field value will be retained at the end of this
    * method
    * If given element is not editable then the InvalidElementStateException is thrown
    * This exception is caught and can be returned false as the element is not editable
    * @param locator
    * @return
    * @ 
    */
   public boolean isEditable(final By locator) 
   {
      logger.info("Checking element is editable for: " + locator);
      try
      {
         String existingText = this.getTextAtLocator(locator);
         if (existingText == null || existingText.trim().isEmpty())
         {
            existingText = this.getAttributeValueAtLocator(locator, "value");
         }
         final String tempText = "IsEditable";
         this.clearTypeAndFocusOff(locator, tempText);
         String textAtLocator = this.getTextAtLocator(locator);
         if (textAtLocator == null || textAtLocator.trim().isEmpty())
         {
            textAtLocator = this.getAttributeValueAtLocator(locator, "value");
         }
         if (tempText.equals(textAtLocator.trim()))
         {
            this.clearTypeAndFocusOff(locator, existingText);
            return true;
         }
      }
      catch (InvalidElementStateException e) 
      {
         return false; // if exception return false
      }
      return false;
   }

   /**
    * @param elementIdentification
    * @param text
    * @return true if text present at given element or false if not
    * @ 
    */
   public boolean isTextPresent(final By locator, final String text) 
   {
      logger.info("Checking the given text is present at element: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      String elementText = driver.findElement(locator).getText();
      boolean flag = false;
      if (elementText.contains(text))
      {
         flag = true;
      }
      return flag;
   }

   /**
    * Checks the availability of an element on UI
    * 
    * @param locator
    * @return
    * @ 
    */
   public boolean isElementPresent(final By locator) 
   {
      logger.info("Checking element existency for " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();

      return driver.findElements(locator).size() > 0;

   }

   // Keyboard interactions

   /**
    * Presses the enter key on the given element
    * 
    * @param selector
    * @ 
    */
   public void pressEnterKey(final By selector) 
   {
      logger.info("Pressing Enter key on locator: " + selector);
//      this.type(selector, Keys.RETURN);
   }

   public void sendCTRLKeyCombinations(final String key, final String cssSelector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      driver.findElement(By.cssSelector(cssSelector)).sendKeys(Keys.chord(Keys.CONTROL, key));
   }

   /**
    * Presses the Tab key on the given element
    * 
    * @param selector
    * @ 
    */
   public void pressTabKey(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Pressing Tab key on locator: " + selector);
      driver.findElement(selector).sendKeys(Keys.TAB);
   }

   // GUI interaction methods

   /**
    * Refreshes current window handled by driver
    * @ 
    */
   public void refreshPage() 
   {
     // logger.info("Refreshing the current page");
      WebDriver driver = ThreadLocalObject.getDriver();
      driver.navigate().refresh();
   }

   /**
    * Temporary workaround for drag and drop until the default selenium's drag and drop works
    * Sometime the method may fail to do in try block but again it is tried in catch block.
    * 
    * @param fromSelector
    * @param toSelector
    * @ 
    * @throws InterruptedException
    * @throws AWTException
    */
   public void dragAndDropByRobot(final By fromSelector, final By toSelector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
     logger.info("Dragging element: " + fromSelector + " and dropping it on element: " + toSelector);
      WebElement from = driver.findElement(fromSelector);
      WebElement to = driver.findElement(toSelector);

      int fromX = from.getLocation().getX();
      int fromY = from.getLocation().getY();
      int toX = to.getLocation().getX();
      int toY = to.getLocation().getY();

      Robot robot;
//      try
//      {
//         robot = new Robot();
//
//         robot.mouseMove(fromX + PIXELS_40, fromY + PIXELS_40);
//         robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
//         robot.mouseMove(fromX + PIXELS_20, fromY + PIXELS_110);
//
//         Thread.sleep(WAIT_MILLIES_1000);
//         robot.mouseMove(toX, toY);
//         Thread.sleep(WAIT_MILLIES_1000);
//         robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
//         robot.mouseMove(fromX + PIXELS_20, fromY);
//         Thread.sleep(WAIT_MILLIES_1000);
//      }
//      catch (AWTException awt)
//      {
//
//      }
//      catch (InterruptedException e)
//      {
//         e.printStackTrace();
//      }
   }

   /**
    * Use this method get the focusoff from other elements. Search box on Ui is visible from all
    * views. we can use this for focusoff
    * @ 
    */
   public void focusOff() 
   {
   }

   /**
    * Gets all elements which match the given locator
    * 
    * @param locator
    * @return
    * @ 
    */
   public List<WebElement> getElements(final By locator) 
   {
	   logger.info("Getting all elements from: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      return driver.findElements(locator);
   }

   /**
    * Get a element which matches the given locator
    * 
    * @param locator
    * @return
    * @ 
    */
   public WebElement getElement(final By locator) 
   {
	   logger.info("Getting all elements from: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      return driver.findElement(locator);
   }
   
   
   /**
    * Clicks on the specified element
    * 
    * @param selector
    * @ 
    */
   public void click(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
	 logger.info("Clicking on locator: " + selector);
      this.waitForElementToBeClickable(selector);
	//  logger.log(Level.INFO, "Finding " + selector + " element ");
      WebElement element = driver.findElement(selector);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
      element.click();
   }
   
   
   
   /**
    * Clicks on the specified element using java script
    * 
    * @param selector
    * @ 
    */
   public void clickbyJS(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      this.waitForElementToExistAndScrollTO(selector);
      WebElement element = driver.findElement(selector);
      logger.info("BrowserName is : " + browsername);
      if(testData.get("Browser").equals("phantomjs"))
    		  {
    	  		element.click();
    		  }
      else
      {
    	  	((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
      }
      System.out.println(element.isDisplayed() );
   }
   
   public void doubleClick(final By selector) {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Double clicking on locator: " + selector);
      this.waitForElementToBeClickable(selector);
//     logger.log(Level.INFO, "Finding " + selector + " element ");
      WebElement element = driver.findElement(selector);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
      new Actions(driver).moveToElement(element).doubleClick(element).build().perform();
   }

   /**
    * @param locatorToClick
    * @param locatorToWait
    * @param waitInMilliSeconds
    * @ 
    */
   public void clickAndWaitForNextElement(final By locatorToClick, final By locatorToWait, int waitInMilliSeconds) 
   {
//      logger.info("Clicking on element: " + locatorToClick + " and waiting for next element: " + locatorToWait);
      this.click(locatorToClick);
      this.waitForElementToExist(locatorToWait);
   }

   /**
    * Is used to right click on given element
    * 
    * @param locator
    * @ 
    */
   public void rightClick(final By locator) 
   {
	  logger.info("Right clickinmg on element: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      WebElement rightClickOn = driver.findElement(locator);
      Actions action = new Actions(driver);
      action.moveToElement(rightClickOn).contextClick(rightClickOn).perform();
   }
   
   /**
    * Use this method to right click on first screen.
    * 
    * @throws AWTException
    * @ 
    */

   public void rightClickOnFirstScreenByRobot(final By locator) throws AWTException
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      WebElement elementToBeElementToBeRightClickOn = driver.findElement(locator);
      logger.info("Right click on the locator" + locator + "By Robot");
      int elementCenterXCoord = elementToBeElementToBeRightClickOn.getLocation().getX() + elementToBeElementToBeRightClickOn.getSize().getHeight()/2;
      int elementCenterYCoord = elementToBeElementToBeRightClickOn.getLocation().getX() + elementToBeElementToBeRightClickOn.getSize().getWidth()/2;
      System.out.println(elementCenterXCoord +" - "+ elementCenterYCoord );
      this.rightClickByRobot(elementCenterXCoord, elementCenterYCoord);
   }

   /**
    * Selects the first item from the context menu
    * @ 
    * 
    * @throws AWTException
    */
   
   /*
    * Use this method to right click on the Tile using Robot
    * @throws AWTException 
    */
   private void rightClickByRobot(final int x, final int y) throws AWTException
   {
      Robot robot = new Robot();
      robot.mouseMove(x, y);
      logger.info("Mouse Button Right click By Robot");
      robot.mousePress(InputEvent.BUTTON3_MASK);
      robot.mouseRelease(InputEvent.BUTTON3_MASK);
   }
   
   /**
    * Use this method to right click on the Tile using locator using Robot
    * @throws AWTException 
    * @ 
    */
   public void rightClickByRobot(final By locator) throws AWTException
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      WebElement elementToBerightClickOn = driver.findElement(locator);
      logger.info("Right click on the tile" + locator + "By Robot");
      this.rightClickByRobot(elementToBerightClickOn.getLocation().getX()+elementToBerightClickOn.getSize().getHeight()/2, elementToBerightClickOn.getLocation().getY()+elementToBerightClickOn.getSize().getWidth()/2);
   }
   
   public void pressTabAndEnterByRobot()  
   {
	   logger.info("Selecting the firest context menu item");
      Robot robot;
      try
      {
         robot = new Robot();
         robot.keyPress(KeyEvent.VK_TAB);
         robot.keyPress(KeyEvent.VK_ENTER);
         robot.keyRelease(KeyEvent.VK_TAB);
         robot.keyRelease(KeyEvent.VK_ENTER);
      }
      catch (AWTException e)
      {
      }
   }

   /**
    * Clicks on the element by ID which is virtually hidden. This method is used when element can be
    * clicked manually and not able to click with automation
    * @param id
    * @ 
    */
   public void clickOnHiddenElementById(final String id) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Clicking on hidden locator: " + id);
      this.waitForElementToBeClickable(By.id(id));
      //logger.log(Level.INFO, "Finding " + id + " element ");
      ((JavascriptExecutor) driver).executeScript("document.getElementById('" + id + "').click();");
   }

   /**
    * Clicks on the element by xpath which is virtually hidden. This method is used when element can
    * be clicked manually and not able to click with automation
    * 
    * @param xpath
    * @ 
    */
   public void clickOnHiddenElementByXpath(final By xpath) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Clicking on hidden locator: " + xpath);
      this.waitForElementToBeClickable(xpath);
//      logger.log(Level.INFO, "Finding " + xpath + " element ");

      WebElement element = driver.findElement(xpath);
      String js = "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";
      ((JavascriptExecutor) driver).executeScript(js, element);
      element.click();
   }

   /**
    * Clears the text and types and presses enter on a given text field
    * 
    * @param locator
    * @param text
    * @ 
    */
   public void clearTypeAndPressEnter(final By locator, String text) 
   {
      this.click(locator);
      this.clearTextfield(locator);
      this.type(locator, text);
      this.pressEnterKey(locator);
   }

   /**
    * Clears the text and types and focusoff on a given text field
    * 
    * @param locator
    * @param text
    * @ 
    */
   public void clearTypeAndFocusOff(final By locator, final String text) 
   {
      this.click(locator);
      this.clearTextfield(locator);
      this.type(locator, text);
      this.focusOff();
   }

   /**
    * Types the given text in to the text field locator
    * 
    * @param selector
    * @param text
    * @ 
    */
   public void type(final By selector, final String text) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
     // logger.log(Level.INFO, "Finding " + selector + " element ");
      this.waitForElementToBeClickable(selector);
      WebElement element = driver.findElement(selector);
      element.click();
      element.sendKeys(text);
      reType(driver, element, text);
   }
   
   /**
    * Types the given text in to the text field locator
    * 
    * @param selector
    * @param text
    * @ 
    */
   private void reType(WebDriver driver,  WebElement element, String text) 
   {
	   int i = 1;
	   while(i<=10 && !element.getAttribute("value").equals(text))
	   {
		   element.sendKeys(text);
		   //driver.manage().timeouts().implicitlyWait(100, TimeUnit.MILLISECONDS);
		   System.out.println("Retry for Typing");
		   i++;
	   }
     
   }

   /**
    * Clears the text in text field
    * 
    * @param selector
    * @ 
    */
   public void clearTextfield(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Clearing text field on locator: " + selector);
      this.waitForElementToBeClickable(selector);
      driver.findElement(selector).clear();
   }

   /**
    * Selenium`s default drag and drop method. Please ensure it is working as expected by you.
    * Otherwise use dragAndDropByRobot
    * 
    * @param fromSelector
    * @param toSelector
    * @ 
    * @throws FileNotFoundException
    */
   public void dragAndDrop(final String fromSelector, final String toSelector) 
   {
//      logger.info("Dragging element: " + fromSelector + " and dropping it on element: " + toSelector);
      WebDriver driver = ThreadLocalObject.getDriver();
      this.waitForElementToBeClickable(By.cssSelector(fromSelector));
      this.waitForElementToBeClickable(By.cssSelector(toSelector));

      String script;
      //script = FileHandler.readFileAsString("./resources/drag_and_drop_helper.js");
      JavascriptExecutor exec = (JavascriptExecutor) driver;
      //exec.executeScript(script);
      exec.executeScript("$('" + fromSelector + "').simulateDragDrop({ dropTarget: '" + toSelector + "'});");
   }

   /**
    * Selects the value from given drop down element with the text provided
    * 
    * @param selector
    * @param text
    * @ 
    */
   public void selectFromDropdown(final By selector, final String text) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Selecting " + selector + " element ");
      WebElement element = driver.findElement(selector);
      Select select = new Select(element);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
      select.selectByVisibleText(text);
   }

   /**
    * Selects the value from given drop down element with the index value provided
    * 
    * @param selector
    * @param index
    * @ 
    */
   public void selectFromDropdownByIndex(final By selector, final int index) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      //logger.log(Level.INFO, "Selecting " + selector + " element ");
      WebElement element = driver.findElement(selector);
      Select select = new Select(element);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
      select.selectByIndex(index);
   }

   /**
    * Gets the selected option from the given drop down locator
    * 
    * @param selector
    * @return
    * @ 
    */
   public String getSelectedOptionFromDropDown(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
//      logger.log(Level.INFO, "Getting selected option from " + selector + " element ");
      WebElement element = driver.findElement(selector);
      Select select = new Select(element);
      WebElement selectedOption = select.getFirstSelectedOption();
      return selectedOption.getText();
   }

   /**
    * Gets all available options from the given drop down locator
    * 
    * @param locator
    * @return
    * @ 
    */
   public List<String> getAllOptionsFromDropDown(final By locator) 
   {
     logger.info("Getting all options from dropdown element: " + locator);
      List<String> options = new LinkedList<>();
      WebDriver driver = ThreadLocalObject.getDriver();
      WebElement element = driver.findElement(locator);
      Select select = new Select(element);
      List<WebElement> selectedOptions = select.getAllSelectedOptions();
      for (WebElement selectedOption : selectedOptions)
      {
         options.add(selectedOption.getText());
      }
      return options;
   }

   /**
    * Gets the text lying at the locator
    * 
    * @param locator
    * @return
    * @ 
    * @throws Exception
    */
   public String getTextAtLocator(final By locator) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Getting text at locator: " + locator);
      this.waitForElementToBePresent(locator, DEFAULT_WAIT_IN_MILLIS);
      WebElement element = driver.findElement(locator);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
      return element.getText();
   }

   /**
    * Gets the value assigned to a given attribute at the locator
    * 
    * @param locator
    * @param attribute
    * @return
    * @ 
    */
   public String getAttributeValueAtLocator(final By locator, final String attribute) 
   {
      logger.info("Getting " + attribute + " attribute value at element: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      return driver.findElement(locator).getAttribute(attribute);
   }

   /**
    * Gets the text from clip board
    * 
    * @param locator
    * @return
    * @ 
    */
   public String getTextOfElementFromClipboard(final By locator) 
   {
//      logger.info("Getting clip board data typed and copied at element:  " + locator);
      this.type(locator, Keys.chord(Keys.CONTROL, "a"));
      this.type(locator, Keys.chord(Keys.CONTROL, "c"));
      try
      {
         return (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
      }
      catch (Exception e)
      {
    	  
      }
      return null;
   }

   /**
    * Gets the text at element by id which is virtually hidden. This method is used when normal
    * getTextAtLocator does not work
    * 
    * @param locator
    * @return
    * @ 
    */
   public String getTextAtHiddenLocator(final String id) 
   {
//      logger.info("Getting text at hidden element id: " + id);
      WebDriver driver = ThreadLocalObject.getDriver();
//      logger.info("Getting text at locator: " + id);
      String text = (String) ((JavascriptExecutor) driver).executeScript("return arguments[0].value;", driver.findElement(By.id(id)));
      return text;
   }

   /**
    * Mouse overed to the given element
    * 
    * @param locator
    * @ 
    */
   public void mouseOverToLocator(final By locator) 
   {
//      logger.info("Mouse moving to locator: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      WebElement overTo = driver.findElement(locator);
      Actions action = new Actions(driver);
      action.moveToElement(overTo).perform();
   }

   /**
    * @param windowTitle
    *           Switches to pop-up window.
    * @ 
    */
   public void switchToWindow(final String windowTitle) 
   {
//      logger.info("Swiching to window: " + windowTitle);
      WebDriver driver = ThreadLocalObject.getDriver();
      Set<String> windows = driver.getWindowHandles();
      for (String window : windows)
      {
         driver.switchTo().window(window);
         if (driver.getTitle().contains(windowTitle))
         {
            return;
         }
      }
   }

   /**
    * Switch back to main window from any pop-up
    * @ 
    */
   public void switchToMainWindow(final String mainWindowhandle) 
   {
//      logger.info("Swiching back to main window");
      WebDriver driver = ThreadLocalObject.getDriver();
      driver.switchTo().window(mainWindowhandle);
   }

   // wait methods

   /**
    * This method waits for element to be hidden for default time out
    * 
    * @param locator
    * @ 
    */
   public void waitForElementToBeHidden(final By locator) 
   {
     logger.info("Waiting for element to hidden for locator: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      Wait<WebDriver> wait = new WebDriverWait(driver, this.DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
   }

   /**
    * @ 
	 */
   public void waitForPageLoadingToComplete() 
   {
      logger.info("Waiting for page loading to finish");
      WebDriver driver = ThreadLocalObject.getDriver();
      ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>()
      {
         @Override
         public Boolean apply(WebDriver driver)
         {
            return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
         }
      };
      Wait<WebDriver> wait = new WebDriverWait(driver, 30);
      wait.until(expectation);
   }

   /**
    * Waits for element to completely disappear on UI
    * 
    * @param locator
    * @ 
    */
   public void waitForElementToDisappear(final By locator) 
   {
      logger.info("Waiting for element to disappear" + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      WebDriverWait wait = new WebDriverWait(driver, DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
   }

   /**
    * This method waits for element till the default time out
    * 
    * @param selector
    * @ 
    */
   public void waitForElementToExist(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Waiting for element to exist for locator: " + selector);
      Wait<WebDriver> wait = new WebDriverWait(driver, this.DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.presenceOfElementLocated(selector));
      //System.out.println("Element Present" + driver.findElement(selector).isDisplayed());
   }
   
   /**
    * This method waits for element till the default time out
    * 
    * @param selector
    * @ 
    */
   public void waitForElementToExistAndScrollTO(final By selector) 
   {
      WebDriver driver = ThreadLocalObject.getDriver();
      logger.info("Waiting for element to exist for locator: " + selector);
      Wait<WebDriver> wait = new WebDriverWait(driver, this.DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.presenceOfElementLocated(selector));
      WebElement element = driver.findElement(selector);
      ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ");");
   }

   /**
    * This method waits for element to be clickable for default time out
    * 
    * @param locator
    * @ 
    */
   public void waitForElementToBeClickable(final By locator) 
   {
      logger.info("Waiting for element to be clickable for locator: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      this.waitForElementToExist(locator);
      Wait<WebDriver> wait = new WebDriverWait(driver, this.DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.elementToBeClickable(locator));
      //System.out.println("Element Present" + driver.findElement(locator).isDisplayed());
   }

   /**
    * This method waits for element to be visible for default time out
    * 
    * @param locator
    * @ 
    */
   public void waitForElementToBeVisible(final By locator) 
   {
      logger.info("Waiting for element to be visible for locator: " + locator);
      WebDriver driver = ThreadLocalObject.getDriver();
      this.waitForElementToExist(locator);
      Wait<WebDriver> wait = new WebDriverWait(driver, this.DEFAULT_WAIT_IN_SECONDS);
      wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
      //System.out.println("Element Present" + driver.findElement(locator).isDisplayed());
   }

   /**
    * This method waits for elements for given milliseconds
    * 
    * @param locator
    * @param waitInMilliSeconds
    * @return
    * @ 
    * @throws InterruptedException
    * @throws Exception
    */
   public boolean waitForElementToBePresent(final By locator, final int waitInMilliSeconds) 
   {
     logger.info("Waiting for element to exist for locator: " + locator + " for milli: " + waitInMilliSeconds);
      WebDriver driver = ThreadLocalObject.getDriver();
      int wait = waitInMilliSeconds;
      int iterations = (wait / 250);
      long startmilliSec = System.currentTimeMillis();
      for (int i = 0; i < iterations; i++)
      {
         if ((System.currentTimeMillis() - startmilliSec) > wait)
            return false;
         List<WebElement> elements = driver.findElements(locator);
         if (elements != null && elements.size() > 0)
            return true;
         try
         {
            Thread.sleep(250);
         }
         catch (final InterruptedException e)
         {
            e.printStackTrace();
         }
      }
      return false;
   }
   
   /**
    * This method get all the Opened Windows list
    * @ 
    */
   public Set<String> getAllWindowOpened() 
   {
//      logger.info("Refreshing the current page");
      WebDriver driver = ThreadLocalObject.getDriver();
      return driver.getWindowHandles();
   }

}