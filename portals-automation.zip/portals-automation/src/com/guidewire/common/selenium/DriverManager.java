package com.guidewire.common.selenium;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
//import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.apache.log4j.Logger;
import com.guidewire.common.util.PropertiesReader;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class DriverManager {

	private static final Logger LOGGER = Logger.getLogger(DriverManager.class);
	private static final DriverManager INSTANCE = new DriverManager();

	public static DriverManager getInstance() {
		return INSTANCE;
	}

	public synchronized WebDriver initDriver(String browserName, String testName) {
		DesiredCapabilities desiredCapabilities = null;
		SafariOptions safariOptions = null;
		String driverPath = "";
		String url = "";
		BrowserType browser = BrowserType.fromString(browserName);

		switch(browser) {
			case FIREFOX:
				desiredCapabilities = new DesiredCapabilities().firefox();
				FirefoxProfile profile = new ProfilesIni().getProfile("default");
				desiredCapabilities.setCapability(FirefoxDriver.PROFILE, profile);
				desiredCapabilities.setCapability("acceptInsecureCerts", true);
				desiredCapabilities.setCapability("name", testName);
				desiredCapabilities.setBrowserName(browserName);
				desiredCapabilities.setCapability("marionette", true);
				url = setSauceLabConfiguration(desiredCapabilities);
				break;

			case CHROME:
				desiredCapabilities = new DesiredCapabilities().chrome();
				String[] switches = { "--disable-local-storage", "--verbose" };
				desiredCapabilities.setCapability("chrome.switches", switches);
				desiredCapabilities.setCapability("name", testName);
				url = setSauceLabConfiguration(desiredCapabilities);
				break;

			/*
			case PHANTOMJS:
				desiredCapabilities = new DesiredCapabilities();
				driverPath = PropertiesReader.getInstance().getPhantomJSPath();
				new File(driverPath).setExecutable(true);
				desiredCapabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY, driverPath);
				desiredCapabilities.setCapability("logLevel", "DEBUG");
				desiredCapabilities.setBrowserName(browserName);
				url = setSauceLabConfiguration(desiredCapabilities);
				break;
				*/

			case IE:
				desiredCapabilities = DesiredCapabilities.internetExplorer();
				driverPath = PropertiesReader.getInstance().getIEDriverPath();
				desiredCapabilities.setBrowserName(browserName);
				desiredCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
				desiredCapabilities.setCapability("ignoreZoomSetting", true);
				desiredCapabilities.setCapability("nativeEvents", false);
				desiredCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
				desiredCapabilities.setCapability("ignoreProtectedModeSettings", true);
				desiredCapabilities.setCapability("disable-popup-blocking", true);
				desiredCapabilities.setCapability("enablePersistentHover", true);
				url = setSauceLabConfiguration(desiredCapabilities);
				break;

			case EDGE:
				desiredCapabilities = DesiredCapabilities.edge();
				EdgeOptions edgeOptions = new EdgeOptions();
				edgeOptions.setPageLoadStrategy("eager");
				//File chromeDriver = new File("../resources/IEDriverServer.exe");
				//chromeDriver.setExecutable(true);
				desiredCapabilities.setBrowserName(browserName);
				desiredCapabilities.setCapability("ignoreZoomSetting", true);
				desiredCapabilities.setCapability("nativeEvents", true);
				desiredCapabilities.setCapability("acceptSslCerts", true);
				desiredCapabilities.setCapability("INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS", true);
				desiredCapabilities.setCapability("cssSelectorsEnabled", true);
				desiredCapabilities.setCapability("javascriptEnabled", true);
				desiredCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
				desiredCapabilities.setCapability("ignoreProtectedModeSettings", true);
				desiredCapabilities.setCapability("disable-popup-blocking", true);
				desiredCapabilities.setCapability("enablePersistentHover", true);
				url = setSauceLabConfiguration(desiredCapabilities);

				break;

			case NEXUS5:
				desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
				desiredCapabilities.setCapability("appiumVersion", "1.6.4");
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "8");
				desiredCapabilities.setCapability("deviceOrientation", "portrait");
				//desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "LG Nexus 5X");
				desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
				desiredCapabilities.setCapability("name", testName);
				//desiredCapabilities.setCapability("testobject_device", "Motorola Moto E2");
				url = setMobileSauceLabConfiguration(desiredCapabilities, "LG Nexus 5X");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumAndroidNexux5Port();
				break;

			case NEXUS10:
				desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.1");
				desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, PropertiesReader.getInstance().getAppiumAndroidNexux10Port());
				desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "LG Nexus 10");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumAndroidNexux10Port();
				break;

			case LGG5:
				desiredCapabilities = new DesiredCapabilities();
//				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
//				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6.0.1");
//				desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, browser.toString());
//				desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
//				desiredCapabilities.setCapability(MobileCapabilityType.UDID, "LGH840807128cb");
//				desiredCapabilities.setCapability(MobileCapabilityType.ROTATABLE, true);
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "LG Nexus 5X");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumAndroidLGG5Port();
				break;

			case IPHONE6:
				safariOptions = new SafariOptions();
				safariOptions.setUseCleanSession(true);
				desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
				//desiredCapabilities.setCapability("deviceName", "iPhone 6");
				desiredCapabilities.setCapability("platformName", "iOS");
				desiredCapabilities.setCapability("platformVersion", "10.3");
				desiredCapabilities.setCapability("browserName", "Safari");
				desiredCapabilities.setCapability("name", testName);
				desiredCapabilities.setCapability("rotatable", true);
				desiredCapabilities.setCapability("orientation", "PORTRAIT");
				url = setMobileSauceLabConfiguration(desiredCapabilities, "iPhone 6");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumiPhonePort();
				break;

			case IPHONE6S:
				safariOptions = new SafariOptions();
				safariOptions.setUseCleanSession(true);
				desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
				//desiredCapabilities.setCapability("deviceName", "iPhone 6s");
				desiredCapabilities.setCapability("platformName", "iOS");
				desiredCapabilities.setCapability("platformVersion", "10.3");
				desiredCapabilities.setCapability("browserName", "Safari");
				//desiredCapabilities.setCapability("udid", "9cefc2be7b07573e19cb934875bc17d883c325ba");
				desiredCapabilities.setCapability("rotatable", true);
				//desiredCapabilities.setCapability("xcodeOrgId", "VQ6G8ZBDLY");
				//desiredCapabilities.setCapability("xcodeSigningId", "iPhone Developer");
				desiredCapabilities.setCapability("autoWebView", false);
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "iPhone 6s");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumiPhone6sPort();
				break;

			case IPAD:
				safariOptions = new SafariOptions();
				safariOptions.setUseCleanSession(true);
				desiredCapabilities = DesiredCapabilities.safari();
				desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
				//desiredCapabilities.setCapability("deviceName", "iPad Air");
				desiredCapabilities.setCapability("platformName", "iOS");
				desiredCapabilities.setCapability("browserName", "Safari");
				desiredCapabilities.setCapability("platformVersion", "10.3");
				desiredCapabilities.setCapability("rotatable", true);
				desiredCapabilities.setCapability("orientation", "LANDSCAPE");
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "iPad Air");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumiPadPort();
				break;

			case IPADAIR2:
				safariOptions = new SafariOptions();
				safariOptions.setUseCleanSession(true);
				desiredCapabilities = DesiredCapabilities.safari();
				desiredCapabilities.setCapability(SafariOptions.CAPABILITY, safariOptions);
				//desiredCapabilities.setCapability("deviceName", "iPad Air 2");
				desiredCapabilities.setCapability("platformName", "iOS");
				desiredCapabilities.setCapability("platformVersion", "10.2");
				desiredCapabilities.setCapability("browserName", "Safari");
				//desiredCapabilities.setCapability("udid", "5eae0eeac2a5186bc8c69c203ea42a2c8c5f2210");
				desiredCapabilities.setCapability("rotatable", true);
				desiredCapabilities.setCapability("orientation", "LANDSCAPE");
				desiredCapabilities.setCapability("xcodeOrgId", "VQ6G8ZBDLY");
				desiredCapabilities.setCapability("xcodeSigningId", "iPhone Developer");
				desiredCapabilities.setCapability("autoWebView", false);
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "iPad Air 2");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumiPadAir2Port();
				break;

			case GALAXYTABS2:
				desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
				desiredCapabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6.0.1");
				desiredCapabilities.setCapability(MobileCapabilityType.DEVICE_NAME, browser.toString());
				desiredCapabilities.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
				//desiredCapabilities.setCapability(MobileCapabilityType.UDID, "2fa9a7d5");
				desiredCapabilities.setCapability(MobileCapabilityType.ROTATABLE, true);
				desiredCapabilities.setCapability("name", testName);
				url = setMobileSauceLabConfiguration(desiredCapabilities, "Galaxy Tab 2");
				//url = PropertiesReader.getInstance().getAppiumHost() + ":" + PropertiesReader.getInstance().getAppiumAndroidGalaxyTab2Port();
				break;
		}

		return INSTANCE.geWebDriver(browser, url, desiredCapabilities);
	}

	public synchronized void setCookie(String cookieName, String cookieValue) {
		Cookie cookie = INSTANCE.getCookie(cookieName);

		if(cookie != null) {
			ThreadLocalObject.getDriver().manage().deleteCookie(cookie);
		}
		cookie = new Cookie(cookieName, cookieValue);
		ThreadLocalObject.getDriver().manage().addCookie(cookie);
	}

	public Cookie getCookie(String cookieName) {
		return ThreadLocalObject.getDriver().manage().getCookieNamed(cookieName);
	}

	private WebDriver geWebDriver(BrowserType browser, String urlIn, DesiredCapabilities capabilities) {
		WebDriver driver = null;
		try {
			URL url = new URL("http://" + urlIn + "/wd/hub");
			//URL url = new URL("https://us1.appium.testobject.com/wd/hub");
			if (BrowserType.desktop.contains(browser)) {
				LOGGER.info("Setting RemoteWebDriver for " + browser.toString());
				driver = new RemoteWebDriver(url, capabilities);
			}
			else if(BrowserType.android.contains(browser)) {
				LOGGER.info("Setting AndroidDriver for " + browser.toString());
				driver = new AndroidDriver<>(url, capabilities);
			}
			else if (BrowserType.ios.contains(browser)) {
				LOGGER.info("Setting IOSDriver for " + browser.toString());
				driver = new IOSDriver(url, capabilities);
			}
			else {
				return null;
			}

		} catch (MalformedURLException e) {
			LOGGER.warn("URL IN: " + urlIn);
			e.printStackTrace();
		}
		return driver;
	}
	
	private String setSauceLabConfiguration(DesiredCapabilities cap) {
		if(System.getProperty("sauce.run")!=null && System.getProperty("sauce.run").equalsIgnoreCase("true")){
			cap.setCapability("tunnelIdentifier", System.getenv("TUNNEL_IDENTIFIER"));
			cap.setCapability("build", System.getenv("SAUCE_BUILD_NAME"));
			return PropertiesReader.getInstance().getSauceLabHub() + ":" + PropertiesReader.getInstance().getHubPort();
		}
		return PropertiesReader.getInstance().getHubHost() + ":" + PropertiesReader.getInstance().getHubPort();
	}
	
	private String setMobileSauceLabConfiguration(DesiredCapabilities cap, String deviceName) {
		if(System.getProperty("real.device")!= null && System.getProperty("real.device").equalsIgnoreCase("true")){
			cap.setCapability("testobject_device", deviceName);
			cap.setCapability("testobject_api_key", "710F950D82414BD68B93E9933BD3D917");
			return "https://eu1.appium.testobject.com/wd/hub";
		}
		cap.setCapability("tunnelIdentifier", System.getenv("TUNNEL_IDENTIFIER"));
		cap.setCapability("build", System.getenv("SAUCE_BUILD_NAME"));
		cap.setCapability("deviceName", deviceName);
		return PropertiesReader.getInstance().getSauceLabHub() + ":" + PropertiesReader.getInstance().getHubPort();
		
	}

}

