package com.guidewire.common.selenium;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;

public class ThreadLocalObject {

	private static final ThreadLocal<WebDriver> remoteWebDriver = new ThreadLocal<>();
	private static final ThreadLocal<HashMap<String, String>> localData = new ThreadLocal<>();
	private static final ThreadLocal<String> browserName = new ThreadLocal<>();
	private static final ThreadLocal<String> testName = new ThreadLocal<>();
	private static final ThreadLocal<String> quoteNumber = new ThreadLocal<>();
	private static final ThreadLocal<String> suiteName = new ThreadLocal<>();

	static {
		localData.set(new HashMap<>());
	}

	public static WebDriver getDriver() {
		return remoteWebDriver.get();
	}

	public static void setWebDriver(WebDriver driver) {
		remoteWebDriver.set(driver);
	}

	public static void removeWebDriver(WebDriver driver) {
		remoteWebDriver.remove();
	}

	public static HashMap<String, String> getData() {
		return localData.get();
	}

	public static void setData(HashMap<String, String> data) {
		localData.set(data);
	}

	public static void resetData() {
		localData.remove();
	}

	public static String getBrowserName() {
		return browserName.get();
	}

	public static void setBrowserName(String name) {
		browserName.set(name);
	}
	
	public static void setQuoteNum(String quoteNum) {
		quoteNumber.set(quoteNum);
	}
	
	public static String getQuoteNum() {
		return quoteNumber.get();
	}

	public static void resetBrowserName() {
		browserName.remove();
	}
	
	public static void resetQuoteNum(String quoteNum) {
		quoteNumber.remove();
	}

	public static String getTestName() {
		return testName.get();
	}

	public static void setTestName(String name) {
		testName.set(name);
	}

	public static void resetTestNameName() {
		testName.remove();
	}

	public static void setSuitenName(String sName) {
		suiteName.set(sName);
	}

	public static String getSuitenName() {
		return suiteName.get();
	}
	public static void resetSuiteName() {
		suiteName.remove();
	}
}