package com.guidewire.common.selenium;

/**
 * Created by mthangavelsamy on 03/08/2016.
 */
public class FrameWorkConstants {

    final public static  String GPA_SUITE="GPA";
}