package com.guidewire.common.selenium;

public enum Gender {

    MALE("Male"),
    FEMALE("Female");

    private final String gender;

    Gender(final String gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return this.gender;
    }
}
