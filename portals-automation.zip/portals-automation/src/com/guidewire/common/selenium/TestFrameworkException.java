package com.guidewire.common.selenium;

public class TestFrameworkException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8727629811976723976L;
	
	public TestFrameworkException(String message) {
		super(message);
	}
	
}