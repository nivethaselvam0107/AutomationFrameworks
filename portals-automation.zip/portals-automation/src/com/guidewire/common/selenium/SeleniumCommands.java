package com.guidewire.common.selenium;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.guidewire.capabilities.agent.data.DocumentData;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.qnb.pages.AlertHandler;

public final class SeleniumCommands {

	private final String JS_FOLDER_LOCATION = "../util/js/";

	private final String LEFT_RDBTN_LABLE = "label[for*='Left'][class='gw-first']";

	private final String RIGHT_RDBTN_LABLE = "label[for*='Right'][class='gw-second']";

	private final String LEFT_RDBTN_XPATH ="input[id*='Left']";

	private final String RIGHT_RDBTN_XPATH = "input[id*='Right']";

    By BODY = By.xpath("//body");

	By UPLOAD_BAR_CSS = By.cssSelector("[class*='gw-upload-progress-bar']");

	private String LOADER_CSS = "div[class='gw-loader ng-scope gw-loader_running'], [class='ng-isolate-scope']";
	
	private String UPLOADE_IMAGE_CHECK =  "[class='fa fa-check-square-o'], [class='fa fa-file'],  [class*='gw-file-upload-icon']";
	
	private String NOT_VALID_LOCATOR = "automation";

	Logger logger = Logger.getLogger(this.getClass().getName());
	String browsername = ThreadLocalObject.getBrowserName();
	public HashMap<String, String> testData = ThreadLocalObject.getData();

	// boolean helpers
	public SeleniumCommands() {
		this.pageWebElementLoader(this);
	}

	public URL getCurrentUrl() {
		String url = ThreadLocalObject.getDriver().getCurrentUrl();

		try {
			return new URL(url);
		} catch (MalformedURLException ignore) {
			return null;
		}
	}

	/**
	 * @param element
	 * @param text
	 * @return true if text present at given element or false if not @
	 */
	public boolean isTextPresent(final WebElement element, final String text) {
		logger.info(String.format("Checking '%s' is present in element: %s", text, element));
		return element.getText().contains(text);
	}
	
	/**
	 * Checks the availability of an element on UI
	 * 
	 * @param locator
	 * @return @
	 */
	public boolean isElementPresent(final By locator) {
		logger.info("Checking element existency for " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		boolean returnResult;
		try {
			returnResult = driver.findElements(locator).size() > 0;
		} catch (Exception e) {
			returnResult = false;
		}
		return returnResult;
	}

	/**
	 * Checks the availability of an element on UI
	 * 
	 * @param locator
	 * @return @
	 */
	public boolean isElementPresent(final WebElement locator) {
		logger.info("Checking element existency for " + locator);
		boolean returnResult;
		try {
			returnResult = locator.isDisplayed();
		} catch (Exception e) {
			returnResult = false;
		}
		return returnResult;

	}

	public boolean isElementNotPresent(final By locator) {
		logger.info("Checking element NON presence for " + locator);
		return ThreadLocalObject.getDriver().findElements(locator).isEmpty();
	}

	public void waitForElement(final By elementSelector, int... maxWaitTimeInSeconds) {
		int timeToWait = DriverTimeout.getDefaultWaitInMillis();
		if (maxWaitTimeInSeconds.length > 0) {
			timeToWait = maxWaitTimeInSeconds[0];
		}

		long timeStart = System.currentTimeMillis();
		long timeMax = 0;
		do {
			timeMax = timeStart + timeToWait;
		}
		while (this.isElementNotPresent(elementSelector) && System.currentTimeMillis() <= timeMax);
	}

	/**
	 * Checks if an element is visible on UI screen
	 *
	 * @param locator
	 * @return @
	 */
	public boolean isElementVisible(final By locator) {
		logger.info("Checking element visibility on page for " + locator);

		WebDriver driver = ThreadLocalObject.getDriver();
		WebElement element = driver.findElement(locator);

		String function = this.readFile(JS_FOLDER_LOCATION + "IsElementVisible.js");

		return (boolean) this.runJS(function, element);
	}

	public boolean isElementVisible(final WebElement element) {
		logger.info("Checking element visibility on page for " + element);

		String function = this.readFile(JS_FOLDER_LOCATION + "IsElementVisible.js");

		try {
			return (boolean) this.runJS(function, element);
		} catch(NoSuchElementException nse) {
			logger.warn("Element not found: " + element);
			return false;
		}
	}

	public boolean isElementVisible(final Object element) {
		if (element instanceof By) {
			return this.isElementVisible((By)element);
		} else if (element instanceof WebElement) {
			return this.isElementVisible((WebElement)element);
		} else {
			this.throwCastException(element);
			return false;
		}
	}

	/**
	 * Gets element scope and its scopeItem
	 *
	 * @param element
	 * @return @
	 */
	public Object getAngularScopeItem(final WebElement element, final String scopeItem) {
		logger.debug("Getting element angular scope[" + scopeItem + "] for " + element);
		Object angularScope = this.runJS(this.readFile(JS_FOLDER_LOCATION + "AngularScopeGetProperty.js"), element, scopeItem);
		return angularScope;
	}

	/**
	 * Waits till the loading sign disappears fron the page
	 *
	 * @return @
	 */
	public void waitTillPageIsLoaded() {
		logger.debug("Waiting loading sign to disappear... ");
		this.waitForElementToNotHaveClass(this.findElement(BODY), "div[class='gw-loader__progress-wrap']");
	}

	public String readFile(String fileName) {
		logger.debug("Reading file [ " + fileName + " ] -> toString()");
		URL url = getClass().getResource(fileName);
		List<String> resultList;
		String result = "";
		try {
			File file = new File(url.toURI());
			Path path = Paths.get(file.getAbsolutePath());
			resultList = Files.readAllLines(path);

			for (String line : resultList) {
				result += line + System.lineSeparator();
			}

		} catch (URISyntaxException e) {
			logger.warn(e);
		} catch (IOException e) {
			logger.warn(e);
		}
		logger.debug("FILE CONTENT: " + result);
		return result;
	}

	/**
	 * Checks if an element has children
	 *
	 * @param locator
	 * @return true if the element has any child elements, otherwise false
	 */
	public boolean doesElementHaveChildren(final By locator) {
		logger.info("Checking existency for " + locator + " child elements");
		WebElement selector;
		boolean returnResult = isElementPresent(locator);
		if (returnResult) {
			WebDriver driver = ThreadLocalObject.getDriver();
			selector = driver.findElement(locator);
			returnResult = selector.findElements(By.cssSelector("*:first-child>*")).size() > 0;
		}
		return returnResult;
	}

	/**
	 * Refreshes current window handled by driver @
	 */
	public void refreshPage() {
		WebDriver driver = ThreadLocalObject.getDriver();
		driver.navigate().refresh();
	}

	/**
	 * Use this method get the focusoff from other elements. Search box on Ui is
	 * visible from all views. we can use this for focusoff @
	 */
	public void focusOff() {
		clickbyJS(By.xpath("//h1 | //h2 | //body"));
	}

	/**
	 * Gets all elements which match the given locator
	 * 
	 * @param locator
	 * @return @
	 */
	public List<WebElement> getElements(final By locator) {
		logger.info("Getting all elements from: " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		return driver.findElements(locator);
	}

	public void getPageSource() {
		logger.info("Getting all elements from: ");
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info(driver.getPageSource());
	}

	/**
	 * Gets all elements which match the given locator
	 * 
	 * @param locator
	 * @return @
	 */
	public List<WebElement> getElements(final WebElement locator) {
		logger.info("Getting all elements from: " + locator);
		return locator.findElements(By.xpath("./."));
	}

	/**
	 * Get a element which matches the given locator
	 * 
	 * @param locator
	 * @return @
	 */
	public WebElement getElement(final By locator) {
		logger.info("Getting all elements from: " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		return driver.findElement(locator);
	}

	/**
	 * Clicks on the specified element
	 * 
	 * @param selector
	 * @
	 */
	public void click(final By selector) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Clicking on locator: " + selector);
		this.waitForElementToBeClickable(selector);
		WebElement element = driver.findElement(selector);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		element.click();
	}

	public void scrollTo(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Scrolling to element: " + element);
		this.waitForElementToBeClickable(element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
	}

	/**
	 * Clicks on the specified element
	 * 
	 * @param element
	 * @
	 */
	public void click(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Clicking on locator: " + element);
		this.waitForElementToBeEnabled(element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		element.click();
	}

	/**
	 * This method is helper / overload for click(final By locator) or click(final WebElement element)
	 * allow us use it for method reference in outer code.
	 * Example :
	 * elementList.forEach(seleniumCommandsInstance::click)
	 *
	 * @param locator
	 */
	public void click(final Object locator) {
		if (locator instanceof By) {
			this.click((By)locator);
		} else if (locator instanceof WebElement) {
			this.click((WebElement)locator);
		} else {
			this.throwCastException(locator);
		}
	}

	public void selectCheckBoxOrRadioBtn(final WebElement element, Boolean value) {
		WebDriver driver = ThreadLocalObject.getDriver();
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		boolean selection = element.isSelected();
		if (selection != value) {
			element.click();
		}
		element.click();
	}

	public void focus(WebElement element){
		WebDriver driver = ThreadLocalObject.getDriver();
		new Actions(driver).moveToElement(element).perform();
	}

	public WebElement selectLeftRadioButtonByRowIndex(int num) {
		logger.info("Clicking on left radio button at index: " + num);
		return this.findElements(By.cssSelector(LEFT_RDBTN_LABLE)).get(num);
	}

	public WebElement selectRightRadioButtonByRowIndex(int num) {
		logger.info("Clicking on right radio button at index: " + num);
		return this.findElements(By.cssSelector(RIGHT_RDBTN_LABLE)).get(num);
	}

	public WebElement getLeftRadioButtonValueByRowIndex(int num) {
		return this.findElements(By.cssSelector(LEFT_RDBTN_XPATH)).get(num);
	}

	public WebElement getRightRadioButtonValueByRowIndex(int num) {
		return this.findElements(By.cssSelector(RIGHT_RDBTN_XPATH)).get(num);
	}

	/**
	 * Clicks on the specified element using java script
	 * 
	 * @param element
	 * @
	 */
	public void clickbyJS(final WebElement element) {
		logger.info("Clicking by JavaScript on locator: " + element);
		WebDriver driver = ThreadLocalObject.getDriver();
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ");");
		if (ThreadLocalObject.getBrowserName().equals("phantomjs")) {
			element.click();
		} else {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * Clicks on the specified element using java script
	 * 
	 * @param locator
	 * @
	 */
	public void clickbyJS(final By locator) {
		WebDriver driver = ThreadLocalObject.getDriver();
		WebElement element = driver.findElement(locator);
		logger.info("Clicking by JavaScript on locator: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ");");
		if (ThreadLocalObject.getBrowserName().equals("phantomjs")) {
			System.out.println("In phantomjsS");
			element.click();
		} else {
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
		}
	}

	/**
	 * This method is helper / overload for clickbyJS(final By locator) or clickbyJS(final WebElement element)
	 * allow us use it for method reference in outer code.
	 * Example :
	 * elementList.forEach(seleniumCommandsInstance::clickbyJS)
	 *
	 * @param locator
	 */
	public void clickbyJS(final Object locator) {
		if (locator instanceof By) {
			this.clickbyJS((By)locator);
		} else if (locator instanceof WebElement) {
			this.clickbyJS((WebElement)locator);
		} else {
			this.throwCastException(locator);
		}
	}

	private void throwCastException(Object obj) {
		throw new ClassCastException("ERROR when cast " + obj.getClass().getName() + " -> ( org.openqa.selenium.By & org.openqa.selenium.WebElement )");
	}
    private void throwBiCastException(Object target, Object value) {
        throw new ClassCastException(
                "ERROR when cast "
                + target.getClass().getName()
                + " -> ( org.openqa.selenium.By & org.openqa.selenium.WebElement ) or class of value -> "
                + value.getClass().getName()
        );
    }

    /**
     * Gte text of the specified element using java script
     *
     * @param element
     * @
     */
    public String getTextOfTheLocatorByJS(final WebElement element) {
        logger.info("Clicking by JavaScript on locator: " + element);
        WebDriver driver = ThreadLocalObject.getDriver();
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ");");
        return ((JavascriptExecutor) driver).executeScript("return arguments[0].innerHTML", element).toString();
    }

	/**
	 * Types the given text in to the text field locator
	 * 
	 * @param element
	 * @param text
	 * @
	 */
	public void type(final WebElement element, final String text) {
		this.waitForElementToBeEnabled(element);
		String browser = ThreadLocalObject.getData().get("Browser");
		BrowserType browserType = BrowserType.fromString(browser);
		if (browserType.equals(BrowserType.IE)) {

			this.runJS("window.scrollTo(0," + element.getLocation().y + ")");
			try {
				element.click();
			} catch (WebDriverException e) {
				logger.info("Element not clickable");
			}
			element.sendKeys("");
			this.runJS("arguments[0].value='';", element);
			element.sendKeys(text);
		} else if (browserType.equals(BrowserType.NEXUS5) || browserType.equals(BrowserType.LGG5)) {

			this.runJS("window.scrollTo(0," + element.getLocation().y + ")");
			logger.info("Typing for " + browser);
			this.runJS("arguments[0].value='';", element);
			element.clear();
			element.sendKeys(text == null ? "" : text);
		} else {

			this.runJS("window.scrollTo(0," + element.getLocation().y + ")");
			try {
				element.click();
			} catch (WebDriverException e) {
				logger.info("Element not clickable");
			}
			element.clear();

			if (text == null) {
				if (browserType.equals(BrowserType.FIREFOX)) {
					element.sendKeys("");
				} else {
					element.sendKeys(Keys.NULL);
				}
			} else {
				element.sendKeys(text);
			}
		}

	}

	/**
	 * Types the given text in to the text field locator
	 * 
	 * @param selector
	 * @param text
	 * @
	 */
	public void type(final By selector, final String text) {
		WebDriver driver = ThreadLocalObject.getDriver();
		this.waitForElementToBeClickable(selector);
		WebElement element = driver.findElement(selector);
		try {
			element.click();
		} catch (WebDriverException e) {
			logger.info("Element not clickable");
		}
		element.clear();
		element.sendKeys(text);
	}

	public void type(final Object selector, final Object text) {
        if (selector instanceof WebElement && text instanceof String) {
            this.type((WebElement)selector,(String)text);
        } else if (selector instanceof By && text instanceof String) {
            this.type((By)selector,(String)text);
        } else {
            this.throwBiCastException(selector, text);
        }
    }

    public void typeByJS(final WebElement element, final String text) {
        this.waitForElementToBeEnabled(element);
        clickbyJS(element);
        this.runJS("arguments[0].value='" + text + "';", element);
        //element.sendKeys();
    }

	public void typeByJS(final By locator, final String text) {
		WebElement element = this.findElement(locator);
		this.waitForElementToBeEnabled(element);
		clickbyJS(element);
		this.runJS("arguments[0].value='" + text + "';", element);
		element.sendKeys();
	}

    public void typeByJS(final Object element, final Object text) {
        if (element instanceof WebElement && text instanceof String) {
            this.typeByJS((WebElement)element,(String)text);
        } else if (element instanceof By && text instanceof String) {
			this.typeByJS((By)element,(String)text);
		} else {
            this.throwBiCastException(element, text);
        }
    }

	/**
	 * Selects the value from given drop down element with the text provided
	 * 
	 * @param selector
	 * @param text
	 * @
	 */
	public void selectDropDownValueByText(final WebElement selector, final String text) {
		logger.info("Selecting drop down " + selector + " element  with " + text);
		WebDriver driver = ThreadLocalObject.getDriver();
		Select select = new Select(selector);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + selector.getLocation().y + ")");
		select.selectByVisibleText(text);
	}

	/**
	 * Selects the value from given drop down element with the text provided
	 *
	 * @param selector
	 * @param text
	 * @
	 */
	public void selectDropDownValueByTextWithOutScroll(final WebElement selector, final String text) {
		logger.info("Selecting drop down " + selector + " element  with " + text);
		WebDriver driver = ThreadLocalObject.getDriver();
		Select select = new Select(selector);
		select.selectByVisibleText(text);
	}

	/**
	 * Selects the value from given drop down element with the text provided
	 *
	 * @param selector
	 * @param text
	 * @
	 */
	public void selectDropDownValueByTextWithOutScroll(final By selector, final String text) {
		logger.info("Selecting drop down " + selector + " element  with " + text);
		WebDriver driver = ThreadLocalObject.getDriver();
		Select select = new Select(driver.findElement(selector));
		select.selectByVisibleText(text);
	}
	
	/**
	 * Selects the value from given drop down element with the text provided
	 * 
	 * @param selector
	 * @param text
	 * @
	 */
	public void selectDropDownValueByText(final By selector, final String text) {
		logger.info("Selecting drop down " + selector + " element  with " + text);
		WebDriver driver = ThreadLocalObject.getDriver();
		WebElement element = driver.findElement(selector);
		Select select = new Select(driver.findElement(selector));
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		select.selectByVisibleText(text);
	}

	public void selectDropDownValueByText(final Object selector, final Object text) {
		if (selector instanceof WebElement && text instanceof String) {
			this.selectDropDownValueByText((WebElement)selector,(String)text);
		} else if (selector instanceof By && text instanceof String) {
			this.selectDropDownValueByText((By)selector,(String)text);
		} else {
			this.throwBiCastException(selector, text);
		}
	}

	/**
	 * Selects the value from given drop down element with the index value
	 * provided
	 *
	 * @param element
	 * @param index
	 * @
	 */
	public void selectFromDropdownByIndex(final WebElement element, final int index) {
		WebDriver driver = ThreadLocalObject.getDriver();
		Select select = new Select(element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		select.selectByIndex(index);
	}
	
	/**
	 * Selects the value from given drop down element with the index value
	 * provided
	 *
	 * @param selector
	 * @param index
	 * @
	 */
	public void selectFromDropdownByIndex(final By selector, final int index) {
		WebDriver driver = ThreadLocalObject.getDriver();
		WebElement element = driver.findElement(selector);
		Select select = new Select(element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		select.selectByIndex(index);
	}

	/**
	 * Gets the selected option from the given drop down locator
	 * 
	 * @param element
	 * @return @
	 */
	public String getSelectedOptionFromDropDown(final WebElement element) {
		Select select = new Select(element);
		WebElement selectedOption = select.getFirstSelectedOption();
		return selectedOption.getText();
	}

	/**
	 * Gets the selected option from the given drop down locator
	 * 
	 * @param element
	 * @return @
	 */
	public String getSelectedOptionFromDropDown(final By element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		Select select = new Select(driver.findElement(element));
		WebElement selectedOption = select.getFirstSelectedOption();
		return selectedOption.getText();
	}

	/**
	 * Gets all available options from the given drop down locator
	 *
	 * @param element
	 * @return @
	 */
	public List<String> getAllOptionsFromDropDown(final WebElement element) {
		logger.info("Getting all options from dropdown element: " + element);
		List<String> options = new LinkedList<>();
		Select select = new Select(element);
		List<WebElement> selectedOptions = select.getOptions();
		for (WebElement selectedOption : selectedOptions) {
			options.add(selectedOption.getText());
		}
		return options;
	}

	/**
	 * Gets the text lying at the element
	 * 
	 * @param element
	 * @return
	 * @ @throws
	 *       Exception
	 */
	public String getTextAtLocator(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting text at locator: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.getText();
	}

	/**
	 * Gets the text lying at the locator
	 * 
	 * @param locator
	 * @return
	 * @ @throws
	 *       Exception
	 */
	public String getTextAtLocator(final By locator) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting text at locator: " + locator);
		final WebElement element = driver.findElement(locator);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.getText();
	}

	/**
	 * Return the Error message for the WebElement
	 *
	 * @param element
	 * @return
	 */
	public String getErrorMessageForDropdown(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting Error Message for Element: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.findElement(By.xpath("./following-sibling::div")).getText();
	}

	/**
	 * Return the Error message for the WebElement
	 * 
	 * @param element
	 * @return
	 */
	public String getErrorMessageForTxtBox(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting Error Message for Element: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.findElement(By.xpath("./following-sibling::div")).getText();
	}

	/**
	 * Return the Error message for the WebElement when it's parent sibling
	 *
	 * @param element
	 * @return
	 */
	public String getErrorMessageForParentSiblingTxtBox(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting Error Message for Element: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.findElement(By.xpath("./../../following-sibling::div")).getText();
	}

	/**
	 * Return the Error message for the WebElement
	 * 
	 * @param element
	 * @return
	 */
	public boolean checkAstrickForFields(final WebElement element) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting Error Message for Element: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.findElement(By.xpath("./following-sibling::span[contains(@class,'asterisk')]")).isDisplayed();
	}

	/**
	 * Return the Error message for the Date WebElement
	 * 
	 * @param element
	 * @return
	 */
	public String getErrorMessageForDatePicker(final WebElement element) {
		this.focusOff();
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Getting Error Message for Element: " + element);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		return element.findElement(By.xpath("./ancestor::div[@class='gw-controls']//div[@class='gw-inline-messages']//span")).getText();
	}

	/**
	 * Gets the value assigned to a given attribute at the locator
	 * 
	 * @param element
	 * @param attribute
	 * @return @
	 */
	public String getAttributeValueAtLocator(final WebElement element, final String attribute) {
		logger.info("Getting " + attribute + " attribute value at element: " + element);
		return element.getAttribute(attribute);
	}


	/**
	 * Gets the value assigned to a given attribute at the locator
	 * 
	 * @param element
	 * @param attribute
	 * @return @
	 */
	public String getAttributeValueAtLocator(final By element, final String attribute) {
		logger.info("Getting " + attribute + " attribute value at element: " + element);
		WebDriver driver = ThreadLocalObject.getDriver();
		return driver.findElement(element).getAttribute(attribute);
	}

	/**
	 * Gets the value assigned to a given attribute at the locator
	 * 
	 * @param element org.openqa.selenium.WebElement
	 * @return @
	 */
	public String getValueAttributeFromLocator(final WebElement element) {
		logger.info("Getting value attribute of element: " + element);
		return element.getAttribute("value");
	}

	/**
	 * Switch back to main window from any pop-up @
	 */
	public void switchToMainWindow(final String mainWindowhandle) {
		this.switchToWindowByHwnd(mainWindowhandle);
	}

	/**
	 * Switch to window by hwnd
	 */
	public void switchToWindowByHwnd(final String windowHandle) {
		WebDriver driver = ThreadLocalObject.getDriver();
		driver.switchTo().window(windowHandle);
	}

	public String getPopupHwnd(String mainWindowHandle) {
		for (String hwnd : this.getAllWindowOpened()) {
			if (!hwnd.equals(mainWindowHandle))
				return hwnd;
		}
		return null;
	}

	// wait methods

	/**
	 * This method waits for element to be hidden for default time out
	 * 
	 * @param locator
	 * @
	 */
	public void waitForElementToBeHidden(final By locator) {
		logger.info("Waiting for element to hidden for locator: " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	/**
	 * @
	 */
	public void waitForPageLoadingToComplete() {
		logger.info("Waiting for page loading to finish");
		WebDriver driver = ThreadLocalObject.getDriver();
		ExpectedCondition<Boolean> expectation = driver1 -> ((JavascriptExecutor) driver1)
				.executeScript("return document.readyState")
				.equals("complete");
		Wait<WebDriver> wait = new WebDriverWait(driver, 30);
		wait.until(expectation);
	}

	/**
	 * Waits for element to completely disappear on UI
	 * 
	 * @param locator
	 * @
	 */
	public void waitForElementToDisappear(final By locator) {
		logger.info("Waiting for element to disappear" + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	/**
	 * Waits for element to completely disappear on UI
	 * 
	 * @param locator
	 * @
	 */
	public void waitForElementToDisappear(final By locator, int timeInSecond) {
		logger.info("Waiting for element to disappear" + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, timeInSecond);
		wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
	}

	/**
	 * Waits for element to completely disappear on UI
	 * 
	 * @param element
	 * @
	 */
	public void waitForElementToDisappear(final WebElement element) {
		logger.info("Waiting for element to be enabled for locator: " + element);
		WebDriver driver = ThreadLocalObject.getDriver();
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until((ExpectedCondition<Boolean>) webDriver -> !element.isDisplayed());
	}

	/**
	 * This method waits for element till the default time out
	 * 
	 * @param selector
	 * @
	 */
	public void waitForElementToExist(final By selector) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Waiting for element to exist for locator: " + selector);
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.presenceOfElementLocated(selector));
	}

	/**
	 * This method waits for element till the default time out
	 * 
	 * @param selector
	 * @
	 */
	public void waitForElementToExistAndScrollTO(final By selector) {
		WebDriver driver = ThreadLocalObject.getDriver();
		logger.info("Waiting for element to exist for locator: " + selector);
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.presenceOfElementLocated(selector));
		WebElement element = driver.findElement(selector);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ");");
	}

	/**
	 * This method waits for element to be clickable for default time out
	 * 
	 * @param locator
	 * @
	 */
	public void waitForElementToBeClickable(final By locator) {
		WebDriver driver = ThreadLocalObject.getDriver();
		this.waitForElementToExist(locator);
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.elementToBeClickable(locator));
	}

	public void waitForElementToBeClickable(final WebElement element) {
		new WebDriverWait(ThreadLocalObject.getDriver(), DriverTimeout.getDefaultWaitInSeconds())
				.until(ExpectedConditions.elementToBeClickable(element));
	}

    public void waitForElementToBeClickable(final Object element) {
        if (element instanceof By) {
            this.waitForElementToBeClickable((By)element);
        } else if (element instanceof WebElement) {
            this.waitForElementToBeClickable((WebElement)element);
        } else {
            this.throwCastException(element);
        }
    }

	public boolean isElementClickable(final By locator) {
		WebDriver driver = ThreadLocalObject.getDriver();
		WebElement el = driver.findElement(locator);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 1);
			wait.until(ExpectedConditions.elementToBeClickable(el));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * This method waits for element to be visible for default time out
	 * 
	 * @param locator
	 * @
	 */
	public void waitForElementToBeVisible(final By locator) {
		logger.info("Waiting for element to be visible for locator: " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));

	}

	public void waitForElementToBeVisible(final WebElement element) {
		logger.info("Waiting for element to be visible for locator: " + element);
		WebDriver driver = ThreadLocalObject.getDriver();
		try {
			Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
			wait.until((ExpectedCondition<Boolean>) webDriver -> element.isDisplayed());
		} catch (Exception e) {
			Assert.fail("Element is not visible" + element);
		}
	}

    public void waitForElementToBeVisible(final Object element) {
        if (element instanceof By) {
            this.waitForElementToBeVisible((By)element);
        } else if (element instanceof WebElement) {
            this.waitForElementToBeVisible((WebElement)element);
        } else {
            this.throwCastException(element);
        }
    }

    /**
     * This method waits for element to be visible for default time out
     *
     * @param locator
     * @
     */
    public void waitForElementToBeVisible(final By locator, int timeInSecond) {
        logger.info("Waiting for element to be visible for locator: " + locator);
        WebDriver driver = ThreadLocalObject.getDriver();
        Wait<WebDriver> wait = new WebDriverWait(driver, timeInSecond);
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));

    }

    public void waitForElementToBeVisible(final WebElement locator, int timeInSecond) {
        logger.info("Waiting for element to be visible for locator: " + locator);
        WebDriver driver = ThreadLocalObject.getDriver();
        Wait<WebDriver> wait = new WebDriverWait(driver, timeInSecond);
        wait.until(ExpectedConditions.visibilityOf(locator));

    }

    public void waitForElementToBeVisible(final Object locator, Integer timeInSecond) {
        if (locator instanceof By && timeInSecond instanceof Integer) {
            this.waitForElementToBeVisible((By)locator, timeInSecond);
        } else if (locator instanceof WebElement && timeInSecond instanceof Integer) {
            this.waitForElementToBeVisible((WebElement)locator, timeInSecond);
        } else {
            this.throwBiCastException(locator, timeInSecond);
        }
    }


	private void wait(ExpectedCondition condition) {
		WebDriver driver = ThreadLocalObject.getDriver();
		new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds()).until(condition);
	}

	public void waitForElementToContainText(final WebElement element, String text) {
		logger.info(String.format("Waiting for text '%s' inside %s ", text, element));
		this.wait(ExpectedConditions.textToBePresentInElement(element, text));
	}

	public void waitForElementToContainAnyText(final WebElement element) {
		logger.info("Waiting for element to contain any text: " + element);
		this.wait(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver webDriver) {
				return element.getText().trim().length() > 0;
			}
		});
	}

	public void waitForElementSelectToHaveMoreValuesThan(final WebElement element, final int values) {
		final Select select = new Select(element);
		logger.info(String.format("Waiting for select to contain more than %d: %s", values, select));
		this.wait(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver webDriver) {
				return select.getOptions().size() > values;
			}
		});
	}

	public void waitForElementListHaveMoreValuesThan(final By element, final int values) {
		logger.info(String.format("Waiting for select to contain more than %d: %s", values, element));
		this.wait(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver webDriver) {
				return findElements(element).size() > values;
			}
		});
	}

	public void waitForElementListHaveLessValuesThan(final By element, final int values) {
		logger.info(String.format("Waiting for select to contain less than %d: %s", values, element));
		this.wait(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver webDriver) {
				return findElements(element).size() < values;
			}
		});
	}

	public void waitForElementToBeEnabled(final WebElement element) {
		logger.info("Waiting for element to be enabled for locator: " + element);
		WebDriver driver = ThreadLocalObject.getDriver();
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until((ExpectedCondition<Boolean>) webDriver -> element.isEnabled());
	}

	public void waitForElementToBeEnabled(final By locator) {
		logger.info("Waiting for element to be enabled for locator: " + locator);
		WebDriver driver = ThreadLocalObject.getDriver();
		final WebElement element = driver.findElement(locator);
		Wait<WebDriver> wait = new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds());
		wait.until((ExpectedCondition<Boolean>) webDriver -> element.isEnabled());
	}

	public void waitForElementToBeEnabled(final Object element) {
		if (element instanceof By) {
			this.waitForElementToBeEnabled((By)element);
		} else if (element instanceof WebElement) {
			this.waitForElementToBeEnabled((WebElement)element);
		} else {
			this.throwCastException(element);
		}
	}

	/**
	 * This method waits for elements for given milliseconds
	 * 
	 * @param locator org.openqa.selenium.By target
	 * @param waitInMilliSeconds milliseconds to wait
	 */
	public void waitForElementToBePresent(final By locator, final int waitInMilliSeconds) {
		logger.info("Waiting for element to exist for locator: " + locator + " for milli: " + waitInMilliSeconds);
		WebDriver driver = ThreadLocalObject.getDriver();
		new WebDriverWait(driver, waitInMilliSeconds / 1000).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				List<WebElement> elements = driver.findElements(locator);
				return elements != null && elements.size() > 0;
			}
		});
	}

	public void waitForElementToBePresent(final By locator) {
		logger.info("Waiting for element to exist for locator: " + locator + " for milli: " + DriverTimeout.getDefaultWaitInSeconds());
		WebDriver driver = ThreadLocalObject.getDriver();
		new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds() ).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				List<WebElement> elements = driver.findElements(locator);
				return elements != null && elements.size() > 0;
			}
		});
	}

	/**
	 * Please do not wait until loader will disappear.
	 * Just wait for element that you need.
	 */
	@Deprecated
	public void waitForLoaderToDisappearFromPage_OLD(int... timeout) {
		logger.info("Waiting for page not to have loader element");
		logger.info("Loader is present : " + this.isElementPresent(By.cssSelector(LOADER_CSS)));

		int timeCount = 10;
		if(timeout.length>0) {
			timeCount = timeout[0];
		}

		if (isElementPresent(By.cssSelector(LOADER_CSS))) {
			try {
				this.waitForElementToBeVisible(By.cssSelector(LOADER_CSS), timeCount);
			} catch (Exception e) {
                logger.debug(e);
			}
		}

		if (isElementPresent(By.cssSelector(LOADER_CSS))) {
			try {
				this.waitForElementToDisappear(By.cssSelector(LOADER_CSS), timeCount);
			} catch (Exception e) {
                logger.debug(e);

			}
		}

		this.waitForElementToNotHaveClass(this.findElement(BODY), "gw-loader");
		logger.info("Loader is present after[" + timeCount + "s] disappear check: " + this.isElementPresent(By.cssSelector(LOADER_CSS)));
	}
	
	//This is experimental function for loader dynamic waiting. 
	public void waitForLoaderToDisappearFromPage(int... timeout) {
		logger.info("Waiting for page not to have loader element");
		logInfo("Loader is present : " + this.isElementPresent(By.cssSelector(LOADER_CSS)));

		if (isElementPresent(By.cssSelector(LOADER_CSS))) {
			try {
				this.waitForElementToNotBeingContainedBy(this.findElement(BODY), By.cssSelector("[class*='gw-loader_running']"));
			} catch (Exception e) {
                logger.debug(e);
			}
		}
		logInfo("Loader is present after after wait: " + this.isElementPresent(By.cssSelector(LOADER_CSS)));
	}
	
	/**
	 * This method waits for for page to not have the loader element
	 * present
	 *
	 */
	public void staticWait(int timeout) {
		logger.info("Waiting for page not to have loader element");
		logger.info("Loader is present : " + this.isElementPresent(By.cssSelector(LOADER_CSS)));

		if (!isElementPresent(By.cssSelector(NOT_VALID_LOCATOR))) {
			try {
				this.waitForElementToBeVisible(By.cssSelector(NOT_VALID_LOCATOR), timeout);
			} catch (Exception e) {
                logger.debug(e);
			}
		}
		logger.info("Static wait till " + timeout );
	}


	/**
	 * This method waits for elements for given milliseconds
	 * 
	 * @param element org.openqa.seleniumWebElement
	 */
	public void waitForElementToBePresent(final WebElement element) {
		logger.info("Waiting for element to exist for locator: " + element + " for milli: " + DriverTimeout.getDefaultWaitInSeconds());
		WebDriver driver = ThreadLocalObject.getDriver();
		new WebDriverWait(driver, DriverTimeout.getDefaultWaitInSeconds() / 1000).until(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return element != null;
			}
		});
	}
	
	public void logInfo(String message) {
		logger.info("TEST NAME =====>>>>> [" + ThreadLocalObject.getTestName() + "]=====MESSAGE_LOG=====>>>>> [" + message + "]");
	}

	private ExpectedCondition<Boolean> getContainsClassCondition(final WebElement element, final String clazz) {
		return webDriver -> hasClass(element, clazz);
	}

	public void waitForElementToHaveClass(WebElement element, String clazz) {
		this.wait(getContainsClassCondition(element, clazz));
	}

	public void waitForElementToNotHaveClass(WebElement element, String clazz) {
		this.wait(ExpectedConditions.not(getContainsClassCondition(element, clazz)));
	}

	public void waitForElementToNotBeingContainedBy(WebElement containedElement, By filteringSelector) {
		this.wait(ExpectedConditions.not(new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver webDriver) {
				try {
					findByContainedElement(containedElement, filteringSelector);
					return true;
				} catch (NoSuchElementException ignore) {
					return false;
				}
			}
		}));
	}

	/**
	 * This method get all the Opened Windows list @
	 */
	public List<String> getAllWindowOpened() {
		WebDriver driver = ThreadLocalObject.getDriver();
		List<String> windowHandles = new ArrayList<>();
		windowHandles.addAll(driver.getWindowHandles());
		return windowHandles;
	}

	public WebElement findByContainedElement(WebElement containedElement, By filteringSelector) {
		while (true) {
			try {
				containedElement = containedElement.findElement(By.xpath(".."));
			} catch (NoSuchElementException e) {
				throw new NoSuchElementException("No such element found in the document");
			}

			try {
				return containedElement.findElement(filteringSelector);
			} catch (NoSuchElementException ignore) {
                logger.debug(ignore);
			}
		}
	}

	public WebElement findElement(By locator) {
		return ThreadLocalObject.getDriver().findElement(locator);
	}

	public WebElement findElement(WebElement element, By locator) {
		return element.findElement(locator);
	}

	public List<WebElement> findElements(WebElement element, By locator) {
		return element.findElements(locator);
	}

	public List<WebElement> findElements(By locator) {
		return ThreadLocalObject.getDriver().findElements(locator);
	}

	public boolean hasClass(WebElement element, String clazz) {
		logger.info("Checking if class attribute of the element " + element.getAttribute("class") + " contains " + clazz);
		return element.getAttribute("class").contains(clazz);
	}

	public Object runJS(String script, Object... element) {
		JavascriptExecutor js = (JavascriptExecutor) ThreadLocalObject.getDriver();
		return js.executeScript(script, element);
	}
	
	public void makeElementVisibleByJS(Object... element) {
	    logger.debug("Setting visibility of element to true by JS-=========================");
		this.runJS("arguments[0].style.visibility='visible';", element);
		this.runJS("arguments[0].style.display='inline';", element);
	}

	public void pageWebElementLoader(Object objClass) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), objClass);
	}

	public void setWindowDimensions(int x, int y) {
		ThreadLocalObject
                .getDriver()
                .manage()
                .window()
                .setSize(new Dimension(x, y));
	}

	public String getFileType(String docType) {
		for (DocTypeEnum.FileType fileType : DocTypeEnum.FileType.values()) {
			if (fileType.name().equals(docType)) {
				return fileType.getValue();
			}
		}
		return null;
	}
	
	public static String generateUUID() {
		return java.util.UUID.randomUUID().toString();
	}

	public void uploadClaimDoc(String uploadDocInput, String docType) {
		String suite = ThreadLocalObject.getSuitenName();
		if (suite.equals(SuiteName.GPA.toString())) {
            this.uploadDoc(uploadDocInput, docType, DataFetch.getDocUploadAgentClaimSessionId());
		  } else {
            this.uploadDoc(uploadDocInput, docType, DataFetch.getDocUploadClaimSessionId());
        }
	}

	public void uploadPolicyDoc(String uploadDocInput, String docType) {
		this.uploadDoc(uploadDocInput, docType, DataFetch.getDocUploadPolicySessionId());
	}

	private void uploadDoc(String uploadDocInput, String docType, String sessionId) {
		if (!BrowserType.mobile.contains(BrowserType.fromString(browsername))) {
			DriverManager.getInstance().setCookie("sessionID", sessionId);
			this.staticWait(4);
			WebElement element = findElement(By.cssSelector(uploadDocInput));
			WebDriver webDriver = ThreadLocalObject.getDriver();
			String browserName = ThreadLocalObject.getBrowserName();
			if (browserName.equalsIgnoreCase("internet explorer") || browserName.equalsIgnoreCase("firefox")) {
				JavascriptExecutor myExecutor = ((JavascriptExecutor) webDriver);
				myExecutor.executeScript("arguments[0].style.visibility='visible';", element);
				myExecutor.executeScript("arguments[0].style.display='inline';", element);
				LocalFileDetector detector = new LocalFileDetector();
				File f = detector.getLocalFile(getFileType(docType));
				this.setDocData(f);
				((RemoteWebElement) element).setFileDetector(detector);
				testData.put(DocumentData.DOC_NAME.toString(), f.getName());
				element.sendKeys(f.getAbsolutePath());

			} else if (ThreadLocalObject.getBrowserName().equalsIgnoreCase("chrome")) {
				LocalFileDetector detector = new LocalFileDetector();
				File f = detector.getLocalFile(getFileType(docType));
				testData.put(DocumentData.DOC_NAME.toString(), f.getName());
				this.setDocData(f);
				((RemoteWebElement) element).setFileDetector(detector);
				element.sendKeys(f.getAbsolutePath());
			} else if ( browserName.equalsIgnoreCase("MicrosoftEdge")){
				return;
			}
			if(!(docType.equalsIgnoreCase("html") || docType.equalsIgnoreCase("js")))
			{
				this.waitForElementToBeHidden(UPLOAD_BAR_CSS);
				this.waitForElementToBeVisible(By.cssSelector(UPLOADE_IMAGE_CHECK));
			} else {
				new AlertHandler().isFailedToUploadPopUpDisplayed();
			}
		}
	}

	private void setDocData(File f){
		testData.put("DOC_NAME", f.getName());
		testData.put("DOC_TYPE", "letter_received");
		testData.put("DOC_AUTHOR", ThreadLocalObject.getData().get("USER_NAME"));
	}

	public boolean isMobileView() {
		return ThreadLocalObject
				.getDriver()
				.manage()
				.window()
				.getSize()
				.getWidth() < 640;
	}

	public void waitRefreshWithAction(By refreshTarget, Object actionTarget, Consumer action) {
        this.waitRefreshWithAction(refreshTarget, actionTarget, action, this::waitForElementToBeClickable);
	}

    public void waitRefreshWithAction(By refreshTarget, Object actionTarget, Consumer action, Consumer finalTrigger) {
        action.accept(actionTarget);
		this.waitForElementRefresh(refreshTarget);
        finalTrigger.accept(refreshTarget);
    }

    public void waitRefreshWithAction(By refreshTarget, Object actionTarget, Object actionValue, BiConsumer action) {
        this.waitRefreshWithAction(refreshTarget, actionTarget, actionValue, action, this::waitForElementToBeClickable);
    }

    public void waitRefreshWithAction(By refreshTarget, Object actionTarget, Object actionValue, BiConsumer action, Consumer finalTrigger) {
        action.accept(actionTarget, actionValue);
        this.waitForElementRefresh(refreshTarget);
        finalTrigger.accept(refreshTarget);
    }

    private void waitForElementRefresh(final By refreshTarget) {
		WebElement watch = this.findElement(refreshTarget);
		boolean onPage = true;
		long timeStart = System.currentTimeMillis();
		int timeToWait = 2000;

		do {
			try {
				watch.getText();
			} catch (StaleElementReferenceException e) {
				onPage = false;
			} catch (WebDriverException wde) {
				if (wde.getMessage().contains("Element is no longer attached to the DOM")) {
					onPage = false;
				} else {
					throw wde;
				}
			}
		} while (onPage && (timeStart + timeToWait) >= System.currentTimeMillis());

		this.waitForElementToBePresent(refreshTarget);
	}
}
