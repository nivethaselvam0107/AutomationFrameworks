package com.guidewire.common.selenium;

import com.guidewire.common.util.EnumHelper;

public enum CarPart {

    FRONT_DOOR_LEFT("frontLeftDoor"),
    FRONT_DOOR_RIGHT("frontRightDoor"),
    REAR_DOOR_LEFT("rearLeftDoor"),
    REAR_DOOR_RIGHT("rearRightDoor"),

    FRONT_SIDE_LEFT("frontLeftSide"),
    FRONT_SIDE_RIGHT("frontRightSide"),

    FRONT_FENDER_LEFT("frontLeftFender"),
    FRONT_FENDER_RIGHT("frontRightFender"),

    QUARTER_PANEL_LEFT("leftQuarterPanel"),
    QUARTER_PANEL_RIGHT("rightQuarterPanel"),

    FRONT_PART("frontPart"),
    REAR_PART("rearPart"),

    ROOF("roof");

    private final String carPart;

    CarPart(final String carPart) {
        this.carPart = carPart;
    }

    @Override
    public String toString() {
        return this.carPart;
    }

    public static CarPart fromString(String name) {
        return EnumHelper.fromString(CarPart.class, name);
    }
}
