package com.guidewire.common.selenium;

import com.guidewire.common.util.EnumHelper;
import java.util.EnumSet;

public enum BrowserType {
    
    FIREFOX("firefox"),
    CHROME("chrome"),
    IE("internet explorer"),
    PHANTOMJS("phantomjs"),
    EDGE("MicrosoftEdge"),
    NEXUS5("NEXUS5"),
    NEXUS10("NEXUS10"),
    LGG5("LGG5"),
    IPHONE6("IPHONE6"),
    IPHONE6S("IPHONE6S"),
    IPAD("IPAD"),
    IPADAIR2("IPADAIR2"),
    GALAXYTABS2("GALAXYTABS2");

    public static EnumSet<BrowserType> desktop = EnumSet.of(FIREFOX, CHROME, IE, EDGE, PHANTOMJS);
    public static EnumSet<BrowserType> android = EnumSet.of(NEXUS5, NEXUS10, GALAXYTABS2, LGG5);
    public static EnumSet<BrowserType> ios = EnumSet.of(IPHONE6, IPHONE6S, IPAD, IPADAIR2);
    public static EnumSet<BrowserType> phone = EnumSet.of(IPHONE6, IPHONE6S, NEXUS5, LGG5);
    public static EnumSet<BrowserType> tablet = EnumSet.of(NEXUS10, IPAD, IPADAIR2, GALAXYTABS2);
    public static EnumSet<BrowserType> mobile = EnumSet.of(NEXUS5, NEXUS10, IPHONE6, IPHONE6S, IPAD, IPADAIR2, GALAXYTABS2, LGG5);

    private final String browserType;

    BrowserType(final String browserType) {
        this.browserType = browserType;    
    }

    @Override
    public String toString() {
        return this.browserType;
    }

    public static BrowserType fromString(String name) {
        return EnumHelper.fromString(BrowserType.class, name);
    }
}