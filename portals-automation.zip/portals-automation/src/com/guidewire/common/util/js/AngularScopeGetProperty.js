function getAngularScopeProperty (el, property) {

    var objScope = angular.element(arguments[0]).scope();
    return objScope.$eval(property);
};
return getAngularScopeProperty(arguments[0], arguments[1]);