package com.guidewire.common.util;

import java.text.ParseException;
import java.util.Map;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;

public class MapCompare {

	private static final Logger LOGGER = Logger.getLogger(MapCompare.class);
	private static final SeleniumCommands seleniumCommands = new SeleniumCommands();

	public static Validation compareMap(Map<String, String> map1, Map<String, String> map2) throws ParseException {
		// TODO : should check size of data (open after refactoring and checking other dependencies)
		/*new Validation(map1.entrySet().stream().count(), map2.entrySet().stream().count())
				.shouldBeEqual("Data sets does not match in size");*/
		return compareMap(map1, map2, null);
	}

	public static Validation compareMap(Map<String, String> map1, Map<String, String> map2, Map<String, Map<String,String>> dataTransformations) throws ParseException {
		seleniumCommands.logInfo("Map 1 \n" + map1);
		seleniumCommands.logInfo("\n Map 2 \n" + map2);
		
		if(map1.isEmpty() || map2.isEmpty()) {
			throw new ParseException("Data maps can not be compared as one of them is empty", 0);
		}
			
		map1.entrySet().stream().filter(entry -> map2.containsKey(entry.getKey())).forEach(entry -> {


			String valueFromUI = removeComa(removeBracket(removeCurrency(map1.get(entry.getKey()))));
			if (valueFromUI != null) {
				valueFromUI = valueFromUI
					.toLowerCase()
					.replaceAll("-", "");
			}
			else {
				valueFromUI = "";    
        	}
			String valueFromBackEnd = removeCurrency(removeComa(removeBracket(map2.get(entry.getKey()))));
			if (valueFromBackEnd != null) {
				valueFromBackEnd = valueFromBackEnd
						.toLowerCase()
						.replaceAll("[\\t\\n\\r]", " ")
						.replaceAll("-", "");
			}
			else {
				valueFromBackEnd = "";    
        	}
			LOGGER.info(entry.getKey() + " -> Back End value :- " + valueFromBackEnd + " ; UI value :- " + valueFromUI);

			boolean isNumber = false;
			try {
				isNumber = NumberUtils.isNumber(valueFromUI);
			} catch (NumberFormatException e) {
				LOGGER.info("Number format error was thrown" + e.getMessage());
			}
			if (isNumber) {
				new Validation(Double.parseDouble(valueFromUI), Double.parseDouble(valueFromBackEnd))
						.shouldBeEqual(entry.getKey() + " : Value is not matched");
			} else if (entry.getKey().equals(ClaimData.DATE_OF_LOSS.getValue())
					|| entry.getKey().equals(ClaimData.DATE_NOTIFIED.getValue())) {
				new Validation(valueFromUI.split(" ")[0].toLowerCase(), valueFromBackEnd.split(" ")[0].toLowerCase())
						.shouldBeEqual(entry.getKey() + " Month Value is not matched");
				new Validation(valueFromUI.split(" ")[1], valueFromBackEnd.split(" ")[1])
						.shouldBeEqual(entry.getKey() + " Month Value is not matched");
			} else {
				String entryKey = entry.getKey();
				String comparableValue = dataTransformations != null
						&& dataTransformations.containsKey(entryKey)
						&& dataTransformations.get(entryKey).containsKey(valueFromBackEnd)
						? dataTransformations.get(entryKey).get(valueFromBackEnd)
						: valueFromBackEnd;
				new Validation(valueFromUI, comparableValue)
						.shouldBeEqual(entry.getKey() + " Value is not matched");
			}
		});

		return new Validation(true);
	}

	private static String removeCurrency(String value) {
		if (value != null && value.contains("$")) {
			return value.replace("$", "");
		}
		return value;
	}

	private static String removeBracket(String value) {
		if (value != null && (value.contains("[") || value.contains("]"))) {
			return value.replace("[", "").replace("]", "");
		}
		else if (value != null && (value.contains("(") || value.contains(")"))) {
			return value.replace("(", "").replace(")", "");
		}
		return value;
	}

	private static String removeComa(String value) {
		if (value != null && value.contains(",")) {
			return value.replace(",", "");
		}
		return value;
	}
}
