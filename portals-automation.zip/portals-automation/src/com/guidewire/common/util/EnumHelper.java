package com.guidewire.common.util;

public class EnumHelper {

    private static <T extends Enum<T>> T valueOfIgnoreCase(Class<T> enumeration, String name) {
        for (T enumValue : enumeration.getEnumConstants()) {
            if (enumValue.toString().trim().equalsIgnoreCase(name.trim())) {
                return enumValue;
            }
        }

        throw new IllegalArgumentException(String.format(
                "There is no value with name '%s' in Enum %s",
                name, enumeration.getName()
        ));
    }

    public static <T extends Enum<T>> T fromString(Class<T> enumeration, String name) {
        return valueOfIgnoreCase(enumeration, name);
    }
}
