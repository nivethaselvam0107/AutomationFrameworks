package com.guidewire.common.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import com.guidewire.data.DataConstant;
import org.apache.commons.lang3.StringUtils;

public class PropertiesReader {
	private static PropertiesReader instance;
	private Properties properties;
	private static final String seleniumPropertyFile = "config.properties";
	public static String workingDir = System.getProperty("user.dir");
	private static final String fileDir = "resources";
	private static final String filePath = workingDir + File.separator + fileDir + File.separator + seleniumPropertyFile;
	public static PropertiesReader getInstance() {
		if (instance == null) {
			instance = new PropertiesReader();
			instance.init();
		}
		return instance;
	}
	
	
	private synchronized void init() {
		try {
			properties = new Properties();
			properties.load(new FileInputStream(filePath));
		} catch (final FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Can not find a selenium.property file. Please ensure the file exists - "
					+ filePath);
		} catch (final IOException e) {
			e.printStackTrace();
			System.out.println("Errors occured while loading file - "
					+ filePath);
		}
	}
	
	public String getHubHost() {
		return properties.getProperty("hub.host.name");
	}
	
	public String getRandomList(List<String> list) {
		Random random = new Random();
	    int index = random.nextInt(list.size());
	    return list.get(index);
	}
	
	public String getHubPort() {
		return properties.getProperty("hub.port");
	}
	
	public String getSauceLabHub() {
		return properties.getProperty("sauce.lab.hub.name");
	}
	
	public String getIE_Hub() {
		return properties.getProperty("ie.hub.ip");
	}
	
	public String getAppiumHost() {
		return properties.getProperty("appium.host.name");
	}

	public String getAppiumiPhonePort() {
		return properties.getProperty("appium.ios.iphone6.port");
	}

	public String getAppiumiPhone6sPort() {
		return properties.getProperty("appium.ios.iphone6s.port");
	}

	public String getAppiumiPadPort() {
		return properties.getProperty("appium.ios.ipad.port");
	}

	public String getAppiumiPadAir2Port() {
		return properties.getProperty("appium.ios.ipadair2.port");
	}

	public String getAppiumAndroidNexux10Port() {
		return properties.getProperty("appium.android.nenux10.port");
	}

	public String getAppiumAndroidLGG5Port() {
		return properties.getProperty("appium.android.lgg5.port");
	}

	public String getAppiumAndroidNexux5Port() {
		return properties.getProperty("appium.android.nenux5.port");
	}

	public String getAppiumAndroidGalaxyTab2Port() {
		return properties.getProperty("appium.android.galaxytab2.port");
	}

	public String getAndroidDeviceId() {
		return properties.getProperty("android.device.id");
	}
	
	public String getOSName() {
		return System.getProperty("os.name");
	}

	public String getChromeDriverPath() {
		if (PropertiesReader.getInstance().getOSName().contains("Mac")) {
			return PropertiesReader.getInstance().getChromeDriverPathMac();
		} else {
			return PropertiesReader.getInstance().getChromeDriverPathLinux();
		}
	}

	public String getIEDriverPath() {
		String path = System.getProperty("ie.exe");
		if (path == null || path.isEmpty()) {
			path = properties.getProperty("ie.exe");
		}
		return path;
	}

	public String getChromeDriverPathMac() {
		String path = System.getProperty("chrome.binary.mac");
		if (path == null || path.isEmpty()) {
			path = properties.getProperty("chrome.binary.mac");
		}
		return path;
	}
	public String getChromeDriverPathLinux() {
		String path = System.getProperty("chrome.binary.linux");
		if (path == null || path.isEmpty()) {
			path = properties.getProperty("chrome.binary.linux");
		}
		return path;
	}

	public String getPhantomJSPath() {
		if (PropertiesReader.getInstance().getOSName().contains("Mac")) {
			return PropertiesReader.getInstance().getPhantomJSPathMac();
		} else {
			return PropertiesReader.getInstance().getPhantomJSPathLinux();
		}
	}
	public String getPhantomJSPathMac() {
		String path = System.getProperty("phantomjs.binary.mac");
		if (path == null || path.isEmpty()) {
			path = properties.getProperty("phantomjs.binary.mac");
		}
		return path;
	}
	public String getPhantomJSPathLinux() {
		String path = System.getProperty("phantomjs.binary.linux");
		if (path == null || path.isEmpty()) {
			path = properties.getProperty("phantomjs.binary.linux");
		}
		return path;
	}

	public static String getURL(String application) {
		if (!StringUtils.isEmpty(System.getProperty("app.url"))) {
			return System.getProperty("app.url");
		}

		if(application.equals("CP-PolicyHolder")) {
			return DataConstant.CP_POLICYHOLDER_URL;
		}

		if(application.equals("QnB")) {
			return DataConstant.QnB_URL;
		}

		if(application.equals("GPA")) {
			return DataConstant.GPA_URL;
		}

		if(application.equals("CP-Producer")) {
			return DataConstant.CP_PRODUCER_URL;
		}

		if(application.equals("AMP")) {
			return DataConstant.AMP_URL;
		}

		return null;
	}

	public static String QualifiedUrl() {
		String fullyQualifiedUrl = System.getProperty("app.url");

		if (fullyQualifiedUrl.equals("")) {
			return null;
		}

		return fullyQualifiedUrl;
	}
}
