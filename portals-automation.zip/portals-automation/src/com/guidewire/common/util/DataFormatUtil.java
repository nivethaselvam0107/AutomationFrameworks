package com.guidewire.common.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.restassured.path.json.JsonPath;


public class DataFormatUtil {
	
	public static String getSubmisionStatusEqualsTo(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		Map object = path.getMap("$");
		// System.out.println(object);
		if (object.containsKey("quoteData")) {
			return "Quoted";
		} else {
			return "Draft";
		}
	}
	
	public static String isTransactionAvailable(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		Map object = path.getMap("$");
		if (object.containsKey("jobID")) {
			return "No Transaction Available";
		} else {
			return "Transaction is open";
		}
	}

	public static String getPolicyNumber(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return getNodeValue(path, "bindData", "policyNumber");
	}

	public static String upperCaseFirst(String value) {

		char[] array = value.toCharArray();
		array[0] = Character.toUpperCase(array[0]);
		return new String(array);
	}

	public static String getNodeValue(JsonPath path, String nodePath, String nodeName) {
		String value = null;
		try {
			value = path.setRoot(nodePath).get(nodeName).toString().replace(",", "");
		} catch (Exception e) {
		}
		return value;
	}
	
	public static String getNodeValue(JsonPath path, String pathString) {
		String value = null;
		try {
			value = path.getString(pathString);
		} catch (Exception e) {
		}
		return value;
	}
	
	public static void putData(HashMap<String, String> map, String key,  String value) {
		map.put(key, value);
	}

	public static void putData(HashMap<String, List<String>> map, String key, List<String> list) {
		if(list != null)
		{
			map.put(key, list);
		}
	}

}
