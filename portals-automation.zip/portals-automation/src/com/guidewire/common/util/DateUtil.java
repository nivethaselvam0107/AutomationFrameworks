package com.guidewire.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.format.ISODateTimeFormat;

import com.guidewire.common.selenium.SeleniumCommands;

public class DateUtil
{
	static SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	public static String getCurrentDate()
	{
		DateFormat dateFormat = new SimpleDateFormat("MMMMM d, YYYY");
		Date date = new Date();
		return dateFormat.format(date).toString();
	}
	
	public static String formatToDateTo(String format, String dateValue)
	{
		DateFormat dateFormat = new SimpleDateFormat(format);
		Date date = new Date(dateValue);
		return dateFormat.format(date).toString();
	}
	
	public static String getCurrentDateMMMDYYYY()
	{
		DateFormat dateFormat = new SimpleDateFormat("MMM d, YYYY");
		Date date = new Date();
		return dateFormat.format(date).toString();
	}
	
	public static String FormatDateTo(String isoDate)
	{
		DateTimeFormatter parser2 = ISODateTimeFormat.dateTimeNoMillis();
		DateTime  date = parser2.parseDateTime(isoDate);
		return date.getMonthOfYear()+"/"+date.getDayOfMonth()+"/"+date.getYear();
	}
	
	public static boolean checkISODateIsAfterToday(String isoDate)
	{
		DateTimeFormatter parser2 = ISODateTimeFormat.dateTimeNoMillis();
		DateTime  date = parser2.parseDateTime(isoDate);
		return date.isAfterNow();
	}
	
	public static String getFutureDate()
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 1);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		return dateFormat.format(cal.getTime()).toString();
	}
	
	public static String getFutureDate(int daysToChange)
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, daysToChange);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		return dateFormat.format(cal.getTime()).toString();
	}
	
	public static String getCurrentDateMMDDYYYY()
	{
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		Date date = new Date();
		return dateFormat.format(date).toString();
	}
	
	public static String getPastDateUsingDays()
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -7);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		return dateFormat.format(cal.getTime()).toString();
	}
	
	public static String getPastDateUsingYear(int num)
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, num);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");
		return dateFormat.format(cal.getTime()).toString();
	}
	
	public static String formatDateTo(String dateString, String dateFormat)
	{
		DateFormat format = new SimpleDateFormat(dateFormat);
		Date date = new Date(dateString);
		return format.format(date).toString();
	}
	
	public static String formatDateTo(String dateString, String fromDateFormat, String toDateFormat)
	{
		try {
			return new SimpleDateFormat(toDateFormat).format(new SimpleDateFormat(fromDateFormat).parse(dateString));
		} catch (ParseException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	public static String getDateFromISODateMMMdYYYY(String dateinisoFormat)
	{
		DateFormat dateFormat = new SimpleDateFormat("MMM d, YYYY");
		return dateFormat.format(new Date(FormatDateTo(dateinisoFormat))).toString();
	}
	
	public static String getDateFromISODateToMMDDYY(String dateinisoFormat)
	{
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YY");
		dateFormat.setLenient(true);
		String date =  FormatDateTo(dateinisoFormat).toString();
		String[] dateArray = date.split("/");
		String month = dateArray[0];
		String day = dateArray[1];
		String year = dateArray[2];
		month = month.startsWith("0")? month.substring(1) : month ;
		day = day.startsWith("0")? day.substring(1) : day ;
		year = year.substring(2);
		return (month + "/" + day + "/" + year);
	}
	
	public static String getDateFromISODateMMMMMMdYYYY(String dateinisoFormat)
	{
		DateFormat dateFormat = new SimpleDateFormat("MMMMM d, YYYY");
		return dateFormat.format(new Date(FormatDateTo(dateinisoFormat))).toString();
	}
	
	public static String getDateIn12HrsFormat(int num)
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, num);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY hh:mm aa");
		return dateFormat.format(cal.getTime()).toString();
	}

	public static String getLongDateIn12HrsFormat(String date)
	{
		return getFormattedDate(date, "MMMM dd YYYY hh:mm a");
	}

	public static String getFormattedDate(String date, String dateFormat) {
		DateTime dt = new DateTime(date);
		DateTimeFormatter fmt = DateTimeFormat.forPattern(dateFormat);
		return fmt.print(dt);
	}

	public static String getPastDateIn12HrsFormat(int num)
	{
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.HOUR, num);
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY hh:00 aa");
		return dateFormat.format(cal.getTime()).toString();
	}
	
	public static void main(String[] args) { 
	}
}
