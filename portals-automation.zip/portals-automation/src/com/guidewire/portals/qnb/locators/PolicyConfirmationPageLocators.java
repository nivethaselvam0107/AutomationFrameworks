package com.guidewire.portals.qnb.locators;

public class PolicyConfirmationPageLocators
{
	public PolicyConfirmationPageLocators() {
		// DO nothing
	}

	public static final String CONFIRMATION_PAGE_CSS = "div[class='gw-page gw-box gw-quote-confirmation ng-binding ng-scope']";
	

}
