package com.guidewire.portals.qnb.locators;

public class HOQuotePageLocators {
	
	public HOQuotePageLocators() {
		// DO nothing
	}

	public static final String BUY_BASE_POLICY_BTN_CSS = "button[ng-click='buyQuote()']";
	
	public static final String PRINT_POLICY_BTN_CSS = "span[class='fa fa-print']";

	public static final String QUOTE_OPTION_TILE_CSS = "gw-qnb-multiple-offering-view[quote-data]";
	
	public static final String QUOTE_OPTION_BASE_LBL_CSS = "ul[class*='gw-nav']  li div[class='offeringName ng-binding']";
	
	public static final String QUOTE_OPTION_BASE_COST_CSS = "ul[class*='gw-nav']  li div[class='offeringCost ng-binding']";
	
	public static final String QUOTE_OPTION_CUSTOM_LBL_CSS = " ul[class*='gw-nav']  li:nth-of-type(2) div[class='offeringName ng-binding']";
	
	public static final String QUOTE_OPTION_CUSTOM_COST_CSS = " ul[class*='gw-nav']  li:nth-of-type(2) div[class='offeringCost ng-binding']";
	
	public static final String MAIN_COVERAGE_PREMIUM_COST_CSS = "h4[class='coverage-header']:first-of-type span:nth-of-type(2)";
	
	public static final String BASE_MONTHLY_PREMIUM_COST_RBTN_CSS = "label[for='quoteTermFull0']";
	
	public static final String BASE_FULL_PREMIUM_COST_RBTN_CSS = "label[for='quoteTermSingle0']";
	
	public static final String BASE_POLICY_TILE_CSS = "li[ng-repeat='quote in quoteandbind.standardQuotes']";
	
	public static final String CUSTOM_POLICY_TILE_CSS = "li[ng-repeat='quote in quoteandbind.customQuotes']";
	
	
}
