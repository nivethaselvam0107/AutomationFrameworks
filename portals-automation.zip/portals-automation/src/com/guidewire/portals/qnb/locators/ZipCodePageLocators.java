package com.guidewire.portals.qnb.locators;

public class ZipCodePageLocators 
{
	
	private ZipCodePageLocators(){
	      // Do-nothing
	   }
	   
	   public static final String PA_ZIPCODE_TXT_ID = "//*[contains(@src,'personalauto.svg')]/ancestor::gw-available-products-and-features//input";
	   public static final String HO_ZIPCODE_TXT_ID = "//*[contains(@src,'homeowners.svg')]/ancestor::gw-available-products-and-features//input";

	   public static final String VEHICLE_POLICY_BTN_XPATH ="//*[@class='lob-type']/div[1]";
	   
	   public static final String HOME_POLICY_BTN_XPATH ="//*[@class='lob-type']/div[2]";
	   
	   public static final String GO_BTN_XPATH = "//button[contains(@ng-click, 'goToNewQuote(form)')]";
	   
	   public static final String QUOTEREF_TXT_ID ="QuoteIDRetrieve";
	   
	   public static final String ZIPAGE_HEADER_CSS ="[class=zip-box-wrapper]";
	   
	   public static final String QUOTEREF_MSG_CSS = "span.zip-code-go-text.ng-binding";

}
