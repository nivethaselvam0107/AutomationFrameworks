package com.guidewire.portals.qnb.locators;

public class HOCoverageDetailsLocators {
	
	public HOCoverageDetailsLocators() {
		// DO nothing
	}

	public static final String ALL_OTHER_PERIL_VALUE_CSS  = "td[title='All Other Perils']";
	
	public static final String HURR_PERCENT_VALUE_CSS  = "td[title='Hurricane Percentage']";
	
	public static final String WIND_OR_HAIL_PERCENT_VALUE_CSS  = "td[title='Wind or Hail Percentage']";
	
	public static final String HO_DWEL_LIMIT_VALUE_XPATH  = "//*[@title='Homeowners Dwelling']/../following-sibling::tr/td[@title='Limit']";
	
	public static final String HO_DWELNG_VALUATION_METHOD_VALUE_CSS  = "td[title='Valuation Method']";
	
	public static final String HO_OTH_STRUC_LIMIT_PERCENT_DWLNG_COVRG_VALUE_XPATH  = "//*[@title='Homeowners Other Structures']/../following-sibling::tr/td[@title='Limit - % of Dwelling Coverage']";
	
	public static final String HO_PERS_PROP_LIMIT_PERCENT_DWLNG_COVRG_VALUE_CSS  = "td[title='Limit - % of Dwelling Coverage']";
	
	public static final String HO_PERS_PROP_VALUATION_METHOD_VALUE_XPATH  = "//*[@title='Homeowners Personal Property']/../following-sibling::tr/td[@title='Limit - % of Dwelling Coverage']";
	
	public static final String HO_LOSS_OF_USE_VALUATION_METHOD_VALUE_XPATH  =	"//*[@title='Homeowners Loss Of Use']/../following-sibling::tr/td[@title='Limit - % of Dwelling Coverage']";

	public static final String HO_PERS_LIBILITY_LIMIT_VALUE_CSS  = "td[title='Liability Limit']";
	
	public static final String HO_MED_PAYMENT_LIMIT_VALUE_XPATH  = "//*[@title='Homeowners Medical Payments']/../following-sibling::tr/td[@title='Limit']";
	
	public static final String HO_ORDIDENCE_OR_LAW_VALUE_CSS  = "td[title='Homeowners Ordinance Or Law']";
	
	public static final String HO_ORDIDENCE_OR_LAW_LIMIT_VALUE_XPATH  = "//*[@title='Homeowners Ordinance Or Law']/../following-sibling::tr/td[@title='Limit']";
	
	public static final String FUNGIWET_BACT_SECTION_1_LIMIT_VALUE_CSS  = "td[title='Section I Limit']";
	
	public static final String FUNGIWET_BACT_SECTION_2_AGG_LIMIT_VALUE_CSS  = "td[title='Section II Aggregate Limit']";
	
}
