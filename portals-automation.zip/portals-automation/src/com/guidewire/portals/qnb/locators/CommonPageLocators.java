package com.guidewire.portals.qnb.locators;

public class CommonPageLocators
{

	public CommonPageLocators() {
		// DO nothing
	}
	
//	@FindBy(css = "[ng-click='setNextState(form)']")
//	private static  WebElement NEXT_BTN_CSS;

	public static final String NEXT_BTN_CSS = "[on-click='goToNext()']";
	
	public static final String CANCEL_QUOTE_BTN_CSS = "[on-click='goToCancel()']";

	public static final String PREVIOUS_QUOTE_BTN_CSS = "[on-click='goToPrevious()']";

}
