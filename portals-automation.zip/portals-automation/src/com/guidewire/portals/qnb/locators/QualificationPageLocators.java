package com.guidewire.portals.qnb.locators;

public class QualificationPageLocators {

	public QualificationPageLocators() {
		// DO nothing
	}

	//public static final String QUALIFICATION_PAGE_CSS = "[label='Any coverage declined, cancelled or non-renewed in past 5 years?']";
	
	public static final String QUALIFICATION_PAGE_XPATH = "//H2";

	public static final String COV_DECLINED_RBTN_NO_CSS = "label[class=gw-second][for=NoAnswer0]";

	public static final String COV_DECLINED_RBTN_YES_CSS = "label[class=gw-first][for=YesAnswer0]";

	public static final String COV_DECLINED_LBL_CSS = "label.control-label > span.ng-binding";

	public static final String BUSI_ON_PREM_RBTN_NO_CSS = "label[class=gw-second][for=NoAnswer1]";

	public static final String BUSI_ON_PREM_RBTN_YES_CSS = "label[class=gw-first][for=YesAnswer1]";

	public static final String BUSI_ON_PREM_LBL_CSS = "[class=gw-control-label][for=NoAnswer1]  span";

	public static final String BUSI_TYPE_DROP_NAME = "YesAnswer2";

	public static final String OTHR_REASON_LBL_CSS = "[ng-if='q.questionType === 'String''] span";

	public static final String OTHR_REASON_TXT_NAME = "Answer3";

	public static final String COV_DECLINED_SELECTED_OPTION = "Answer3";

	public static final String BUSINESS_ON_PREMISE_SELECTED_OPTION = "Answer3";
}
