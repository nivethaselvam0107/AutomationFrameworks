package com.guidewire.portals.qnb.locators;

public class DiscountPageLocators {

	public DiscountPageLocators() {
		// DO nothing
	}

	public static final String MANDATORY_FIELD_CLASS = "[class='gw-mandatory-group'], [view-model='$ctrl.ratingViewModel']";
			
	public static final String FIRE_EXT_YES_LBL_CSS = "div[label='Fire Extinguishers in Your Home'] label.gw-first";

	public static final String FIRE_EXT_NO_LBL_CSS = "div[label='Fire Extinguishers in Your Home'] label.second";

	public static final String BURG_ALARM_YES_LBL_CSS = "div[label='Burglar Alarm'] label.first";

	public static final String BURG_ALARM_NO_LBL_CSS = "div[label='Burglar Alarm'] label.second";
	
	public static final String BURG_ALARM_LOCAL_LBL_CSS = "div[label='Specify type:'] input + *";

	public static final String BURG_ALARM_CENTRAL_LBL_CSS = "label[for='BurglarAlarmType1']";
	
	public static final String BURG_ALARM_POLICE_LBL_CSS = "label[for='BurglarAlarmType2']";

	public static final String FIR_ALARM_REP_NO_LBL_CSS = "div[label='Fire Alarm Reporting To Monitoring Center'] label.second";

	public static final String FIR_ALARM_REP_YES_LBL_CSS = "div[label='Fire Alarm Reporting To Monitoring Center'] label.first";

	public static final String SMOKE_ALARM_NO_LBL_CSS = "div[label='Smoke Alarms'] label.second";

	public static final String SMOKE_ALARM_YES_LBL_CSS = "div[label='Smoke Alarms'] label.first";
	
	public static final String SMOKE_ALARM_ALLFLOOR_YES_LBL_CSS = "div[label='Alarms are on all floors'] label.first";
	
	public static final String SMOKE_ALARM_ALLFLOOR_NO_LBL_CSS = "div[label='Alarms are on all floors'] label.second";

	public static final String DEADBOLTS_NO_LBL_CSS = "div[label='Deadbolts'] label.second";

	public static final String DEADBOLTS_YES_LBL_CSS = "div[label='Deadbolts'] label.first";

	public static final String VISIBLE_TO_NEIGH_NO_LBL_CSS = "div[label='Residence Visible to Neighbours'] label.second";

	public static final String VISIBLE_TO_NEIGH_YES_LBL_CSS = "div[label='Residence Visible to Neighbours'] label.first";

	public static final String SPRINKLER_DROP_CSS = "div[label='Sprinkler System Type'] select";

	//Additional Details
	
	public static final String ADDITIONAL_DETAILS_SEC_CSS ="//div[@validation-form='ratingAdditionalForm']//h3";
	
	public static final String ADDITIONAL_DETAILS_EXPANDED_SEC_CSS ="//div[@validation-form='ratingAdditionalForm']//div[@class='panel-collapse collapse in']";
			
	public static final String ROOMR_OR_BORDR_NO_LBL_CSS = "label[for='RoomerBoardersNo']";

	public static final String ROOMR_OR_BORDR_YES_LBL_CSS = "label[for='RoomerBoardersYes']";
	
	public static final String ROOMR_OR_BORDR_NO_TXT_NAME = "RoomerBoardersNumber";

	public static final String FIREPLC_OR_WOODSTOV_NO_LBL_CSS = "label[for='FireplaceOrWoodStoveExistsNo']";

	public static final String FIREPLC_OR_WOODSTOV_YES_LBL_CSS = "label[for='FireplaceOrWoodStoveExistsYes']";
	
	public static final String FIREPLC_OR_WOODSTOV_NO_TXT_CSS = "label[for='FireplaceOrWoodStovesNumber']";

	public static final String POOL_YES_LBL_CSS = "label[for='SwimmingPoolExistsYes']";

	public static final String POOL_NO_LBL_CSS = "label[for='SwimmingPoolExistsNo']";
	
	public static final String POOL_FENCE_NO_LBL_CSS = "label[for='SwimmingPoolFencingYes']";
	
	public static final String POOL_FENCE_YES_LBL_CSS = "label[for='SwimmingPoolFencingYes']";
	
	public static final String POOL_DIVEBOARD_NO_LBL_CSS = "label[for='SwimmingPoolDivingBoardNo']";
	
	public static final String POOL_DIVEBOARD_YES_LBL_CSS = "label[for='SwimmingPoolDivingBoardYes']";

	public static final String TREMPOLINE_YES_LBL_CSS = "label[for='TrampolineExistsYes']";

	public static final String TREMPOLINE_NO_LBL_CSS = "label[for='TrampolineExistsNo']";
	
	public static final String TREMPOLINE_SAFTYNET_NO_LBL_CSS = "label[for='TrampolineSafetyNetNo']";
	
	public static final String TREMPOLINE_SAFTYNET_YES_LBL_CSS = "label[for='TrampolineSafetyNetYes']";

	public static final String WATER_LEAK_NO_LBL_CSS = "label[for='KnownWaterLeakageNo']";

	public static final String WATER_LEAK_YES_LBL_CSS = "label[for='KnownWaterLeakageYes']";
	
	public static final String WATER_LEAK_DESC_TXT_NAME = "KnownWaterLeakageDescription";
	
	public static final String UNIT_ONE_LBL_ID = "UnitsNumber0";
	
	public static final String UNIT_TWO_LBL_ID ="UnitsNumber0";

}
