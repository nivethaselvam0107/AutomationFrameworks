package com.guidewire.portals.qnb.locators;

public class PolicyInfoPageLocators {
	
	public PolicyInfoPageLocators() {
		// DO nothing
	}

	public static final String POLICY_INFO_PAGE_CSS = "[name='policyInfoForm']";
	
	public static final String COV_START_DATE_XPATH = "(//*[@class='control-group']/div[2])[3]";
	
	public static final String PRIMARY_INSURED_NAME_CSS = "(//*[@class='control-group']/div[2])[2]";
	
	public static final String ADDRESS_XPATH = "(//*[@class='control-group']/div[2])[11]";
	
	public static final String BILLING_ADDRESS_YES_CSS = "label[for='BillAndPolAddrsEqualNo']";
	
	public static final String BILLING_ADDRESS_NO_CSS = "label[for='BillAndPolAddrsEqualNo']";
	
	public static final String EMAIL_NAME = "ContactEmail";
	
	public static final String CONTACTNO_CSS ="div[label='Phone'] input";
	
	public static final String GONEXT_BTN_CSS = "[ng-click='setNextState(policyInfoForm)']";

}
