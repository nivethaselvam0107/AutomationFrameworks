package com.guidewire.portals.qnb.locators;

public class YourInfoPageLocators {
	public YourInfoPageLocators() {
		// Do nothing
	}

	public static final String YOURQUOTE_PAGE_HEADER_CSS = "h2";
	
	public static final String FIRSTNAME_LBL_CSS = "label[for='FirstName'] span";

	//public static final String FIRSTNAME_TXT_ID = "FirstName";
	
	public static final String FIRSTNAME_TXT_CSS = "div[label='First Name'] input";

	public static final String LASTNAME_LBL_CSS = "label[for='LastName'] span";

	//public static final String LASTNAME_TXT_ID = "LastName";
	
	public static final String LASTNAME_TXT_CSS = "div[label='Last Name'] input";

	public static final String ADDLINE1_LBL_CSS = "label[for='AddressLine1'] span";

//	public static final String ADDLINE1_TXT_ID = "AddressLine1";
	
	public static final String ADDLINE1_TXT_CSS = "div[label='Address Line 1'] input";
	
	public static final String ADDLINE12_LBL_CSS = "label[for='AddressLine2'] span";

	public static final String ADDLINE2_TXT_ID = "AddressLine2";

	public static final String CITY_LBL_CSS = "label[for='City'] span";

//	public static final String CITY_TXT_ID = "City";
	
	public static final String CITY_TXT_CSS = "div[label='City'] input";

	public static final String ZIP_LBL_CSS = "label[for='PostalCode'] span";

	public static final String ZIP_VALUE_XPATH = "//*[@id='PostalCode']/../span";
	
	public static final String STATE_LBL_CSS = "div[label='State'] span";

//	public static final String STATE_DROP_NAME = "State";
	
	public static final String STATE_DROP_CSS = "div[label='State'] select";
	
	public static final String EMAIL_LBL_CSS = "label[label='EmailAddress'] span";
	
	public static final String EMAIL_TXT_CSS = "div[label='Email Address'] input";

	public static final String DAY_DROP_NAME = "dateFieldsDay";
	
	public static final String MONTH_DROP_NAME = "dateFieldsMonth";

	public static final String YEAR_DROP_NAME = "dateFieldsYear";
	
	public static final String COVR_STARTDATE_TXT_CSS ="div[dto-object='submission'] span";

	
}
