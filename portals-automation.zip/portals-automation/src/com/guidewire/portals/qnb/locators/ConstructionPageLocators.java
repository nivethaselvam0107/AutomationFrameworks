package com.guidewire.portals.qnb.locators;

public class ConstructionPageLocators {

	public ConstructionPageLocators() {
		// Do nothing

	}

	public static final String YOURHOME_PAGE_HEADER_CSS = "h2";
	

	// CONSTRUCTION DETAILS FORM

	public static final String CONSTRUCTION_DETAILS_SEC_CSS = "div[validation-form='detailsForm'] h3, div[validation-form='detailsForm'] h2, [view-model='$ctrl.constructionViewModel']";

	public static final String BUILD_YEAR_TXT_CSS= "div[label='Year Build'] input";

	public static final String ESTIMATED_COST_LBL_CSS = "div[label='Year Build'] span";

	public static final String STORIES_DROP_CSS = "div[label='Number of Stories'] select";

	public static final String STORIES_LBL_CSS = "div[label='Number of Stories'] span";

	public static final String ATTACHED_GARAGE_RBTN_CSS = "input[id='HasGarageYes']";

	public static final String NO_GARAGE_RBTN_CSS = "input[id='HasGarageNo']";

	public static final String GARAGE_LBL_CSS = "div[label='Garage'] span";

	public static final String CONSTRUCTION_DROP_CSS = "div[label='Construction Type'] select";

	public static final String CONSTRUCTION_LBL_ID = "div[label='Construction Type'] span";

	public static final String FOUNDATION_LBL_ID = "div[label='Foundation Type'] span";

	public static final String FOUNDATION_DROP_CSS = "div[label='Foundation Type'] select";


	// ROOF DETAILS FORM

	public static final String ROOF_DETAILS_SEC_CSS= "div[validation-form='roofsForm'] h3, div[validation-form='roofsForm'] h2,  [name='validationForms[roofForm]'] > div";

	// Replace roofType with the type you want
	public static final String ROOF_TYPE_IMG_CSS = "input[name='RoofType'][value ='comp']";

	public static final String ROOF_UPGRADE_CHK_ID = "RoofUpgradeExists";

	public static final String ROOF_UPGRADE_LBL_ID = "RoofUpgradeExists";

	public static final String ROOF_UPGRADE_YEAR_TXT_NAME = "RoofUpgradeYear";
	
	public static final String ROOFTYPES_SEC_XPATH = "div[validation-form='roofsForm'] div[class='gw-panel-collapse gw-collapse gw-in'], [name='validationForms[roofForm]'] div[class*='gw-is-open']";

	// PLUMBING DETAILS FORM

	public static final String PLUMBING_DETAILS_SEC_CSS= "div[validation-form='plumbingForm'] h3, div[validation-form='plumbingForm'] h2,  [name='validationForms[plumbingForm]'] > div";

	public static final String PLUMBING_TYPE_DROP_CSS = "div[label='Plumbing'] select";

	public static final String PLUMBING_UPGRADE_CHK_ID = "PlumbingUpgradeExists";

	public static final String PLUMBING_UPGRADE_LBL_CSS = "label[for='PlumbingUpgradeExists'] span";

	public static final String PLUMBING_UPGRADE_YEAR_TXT_NAME = "PlumbingUpgradeYear";
	
	public static final String PLUMBING_SEC_XPATH = "div[validation-form='plumbingForm'] div[class='gw-panel-collapse gw-collapse gw-in'], [name='validationForms[plumbingForm]'] div[class*='gw-is-open']";

	// HEATING DETAILS FORM

	public static final String HEATING_SEC_CSS = "div[validation-form='heatingForm'] h3,div[validation-form='heatingForm'] h2,  [name='validationForms[heatingForm]'] > div";

	public static final String PRIMARY_HEATING_DROP_CSS = "div[label='Primary Heating'] select";

	public static final String SECONDARY_HEATING_LBL_NAME = "label[for='SecondaryHeatingExistsNo'] span";

	public static final String SECONDARY_HEATING_YES_RBTN_ID = "SecondaryHeatingExistsYes";

	public static final String SECONDARY_HEATING_NO_RBTN_ID = "SecondaryHeatingExistsYes";

	public static final String HEATING_UPGRADE_CHK_ID = "HeatingUpgradeExists";

	public static final String HEATING_UPGRADE_LBL_CSS = "label[for='HeatingUpgradeExists'] span";

	public static final String HEATING_UPGRADE_YEAR_TXT_NAME = "HeatingUpgradeYear";
	
	public static final String HEATING_SEC_XPATH = "div[validation-form='heatingForm'] div[class='gw-panel-collapse gw-collapse gw-in'], [name='validationForms[heatingForm]'] div[class*='gw-is-open']";

	// ELECTRICAL DETAILS FORM

	public static final String ELECTRICAL_SEC_CSS= "div[validation-form='electricalForm'] h3, div[validation-form='electricalForm'] h2, [name='validationForms[electricalForm]'] > div";

	public static final String ELECTRICAL_WIRING_DROP_CSS = "div[label='Wiring'] select";

	public static final String ELECTRICAL_WIRING_LBL_NAME = "div[label='Wiring'] span";

	public static final String ELECTRICAL_SYSTEM_LBL_CSS = "css=div[label='Electrical System'] span";

	public static final String ELECTRICAL_SYSTEM_DROP_CSS = "div[label='Electrical System'] select";

	public static final String ELECTRICAL_SYSTEM_CHK_ID = "WiringUpgradeExists";

	public static final String ELECTRICAL_SYSTEM_UPGRADE_LBL_CSS = "label[for='WiringUpgradeExists'] span";

	public static final String ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_NAME = "WiringUpgradeYear";
	
	public static final String ELECTRICAL_SEC_XPATH = "div[validation-form='electricalForm'] div[class='gw-panel-collapse gw-collapse gw-in'], [name='validationForms[electricalForm]'] div[class*='gw-is-open']";

}
