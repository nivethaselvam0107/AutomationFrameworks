package com.guidewire.portals.qnb.locators;

public class YourHomePageLocators {

	public YourHomePageLocators() {
		// Do nothing
	}

	public static final String YOURHOME_PAGE_HEADER_CSS = "h2";

	public static final String HOMEVALUE_LBL_CSS = "label.control-label > span.ng-binding";

	public static final String HOMEVALUE_TXT_CSS = "div[label='Estimated value of Your Home'] input";

	public static final String LOCTYPE_LBL_CSS = "label[for='DwellingLocation'] span";

	public static final String LOCTYPE_DROP_CSS = "[label='Location Type'] select";

	public static final String RESIDENCETYPE_LBL_CSS = "label[for='ResidenceType'] span";

	public static final String RESIDENCETYPE_DROP_CSS = "[label='Residence Type'] select";

	public static final String DIST_TO_FIREHYD_LBL_CSS = "label[for='DistanceToFireHydrantOpt2'] span";

	public static final String WITHIN1000FT_RBTN_CSS = "div[title1='Within 1000ft'] input:nth-of-type(1)";

	public static final String OVER1000FT_RBTN_CSS = "div[title1='Within 1000ft'] input:nth-of-type(2)";

	public static final String DIST_TO_FIRESTN_LBL_CSS = "label[for='DistanceToFireStationOpt2'] span";

	public static final String WITHIN5MILES_RBTN_CSS = "label[title='Within 5 miles']";

	public static final String OVER5MILES_RBTN_CSS = "label[title='Over 5 Miles']";

	public static final String NEAR_COMMRPROP_LBL_CSS = "label[for='NearCommercialNo'] span";

	public static final String NEAR_COMMRPROP_RBTN_YES_CSS = "div[label='Within 300ft of commercial property'] label.gw-first";

	public static final String NEAR_COMMRPROP_RBTN_NO_CSS = "div[label='Within 300ft of commercial property'] label.gw-second";

	public static final String FLOODORFIRE_LBL_CSS = "label[for='FloodingOrFireHazardNo'] span";

	public static final String FLOODORFIRE_RBTN_YES_CSS = "div[label='Flooding or Fire Hazard'] label.gw-first";

	public static final String FLOODORFIRE_RBTN_NO_CSS = "div[label='Flooding or Fire Hazard'] label.gw-second";

	public static final String HOME_USAGE_LBL_CSS = "label[for='DwellingUsage'] span";

	public static final String HOME_USAGE_DROP_CSS = "[label='Home Used As '] select";

	public static final String HOME_OCCUPANCY_LBL_CSS = "label[for='Home is'] span";

	public static final String HOME_OCCUPANCY_DROP_CSS = "[label='Home is'] select";

}
