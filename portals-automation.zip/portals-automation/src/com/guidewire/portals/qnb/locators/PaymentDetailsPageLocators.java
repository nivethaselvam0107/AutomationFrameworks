package com.guidewire.portals.qnb.locators;

public class PaymentDetailsPageLocators {
	
	public PaymentDetailsPageLocators() {
		// DO nothing
	}

	public static final String POLICY_INFO_PAGE_CSS = "div[class='pa-policy-info ng-scope']";
	
	public static final String MONTHLY_PREMIUM_VALUE_CSS = "h3";
	
	public static final String SIX_MONTH_PREMIUM_VALUE_CSS = "h3";
	
	public static final String PAYMENT_METHOD_CSS = "label[for='OPTION']";
	
	public static final String ACCOUNT_TYPED_CHECKING_CSS = "label[for='checking']";
	
	public static final String ACCOUNT_TYPE_SAVING_CSS = "label[for='savings']";
	
	public static final String ACCOUNT_NUMBER_CSS = "[label='Account Number'] input";
	public static final String ACCOUNT_HOLDER_NAME_CSS = "[label='Account Holder Name'] input";
	
	public static final String ABA_NUMBER_CSS = "[label='Routing (ABA) Number'] input";
	
	public static final String BANK_NAME_CSS = "[label='Bank Name'] input";
	
	public static final String CREDIT_CARD_ISSUER_NAME = "CreditCardIssuer";
	
	public static final String CREDIT_CARD_NUMBER_NAME = "CreditCardNumber";
	
	public static final String EXPIRY_MONTH_NAME = "dateFieldsMonth";
	
	public static final String EXPIRY_YEAR_NAME = "dateFieldsYear";
	
	public static final String PAYMENT_PLAN_CSS = "[class='gw-payment-selection'], gw-payment [on-click*='displayPayInFull()']";
	
	//public static final String PAYMENT_PLAN_NAME_XPATH = "//table[@list='quoteandbind.submission.bindData.paymentPlans']/tbody/tr/td/label[@title='Name']";
	
	public static final String PAYMENT_PLAN_NAME_CSS = "label[for='OPTION']";
	
	public static final String PAYMENT_DOWN_PAY_XPATH = "//table[@list='quoteandbind.submission.bindData.paymentPlans']/tbody/tr/td[@title='Down Payment']";
	
	public static final String PAYMENT_INSTALLMENT_XPATH = "//table[@list='quoteandbind.submission.bindData.paymentPlans']/tbody/tr/td[@title='Installment']";
	
	public static final String PAYMENT_TOTAL_XPATH = "//table[@list='quoteandbind.submission.bindData.paymentPlans']/tbody/tr/td[@title='Total']";
	
	public static final String PURCHASE_BTN_CSS = "[ng-click='goToNext()']";

}
