package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.PaymentDetailsPageLocators;
import com.guidewire.portals.qnb.locators.PolicyConfirmationPageLocators;
import com.guidewire.widgetcomponents.form.BinaryToggler;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class PaymentDetailsPage extends CommonPage{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();
	Logger logger = Logger.getLogger(this.getClass().getName());

	String DEFAULT_ACCOUNT_TYPE_VALUE = "Checking";
	String DEFAULT_PAYMENT_METHOD = "Bank Account";

	@FindBy(css = "[class='gw-quote-message ng-scope'] p:nth-of-type(2) span:nth-of-type(2)")
	WebElement TOTAL_PREMIUM_VALUE_CSS;
	
	@FindBy(css = "[class='gw-quote-message ng-scope'] p:nth-of-type(1) span:nth-of-type(2)")
	WebElement MONTHLY_PREMIUM_VALUE_CSS;
	
	@FindBy(xpath = "//*[contains(@class,'gw-fade')]//*[@ng-class='iconClass()']")
	WebElement PAYMENT_PLAN_CONFIRMATION_POP_UP_CSS;

	@FindBy(css = "tbody>tr>td:nth-of-type(2)")
	WebElement FULL_PAYMENT_PLAN_NAME_CSS;

	@FindBy(css = "[ng-click='$close()']")
	WebElement CONFIRMATION_POP_UP_CLOSE_CSS;

	By ACCOUNT_NUMBER_TXT_CSS = By.cssSelector("[model='bankAccountDetails.bankaccountNumber'] input, [model='bankAccountDetails.bankAccountNumber'] input");

	@FindBy(css = "[model='bankAccountDetails.bankaccountNumber'] span")
	WebElement ACCOUNT_NUMBER_LBL_CSS;

	@FindBy(css = "[model*='bankABANumber'] input")
	WebElement ABA_NUMBER_TXT_CSS;

	@FindBy(css = "[model='bankAccountDetails.bankAccountNumber'] span")
	WebElement ABA_NUMBER_LBL_CSS;

	@FindBy(css = "[model='bankAccountDetails.bankName'] input")
	WebElement BANK_NAME_TXT_CSS;

	@FindBy(css = "[model='bankAccountDetails.bankName'] input")
	WebElement BANK_NAME_LBL_CSS;

	@FindBy(css = "[model='creditCardDetails.creditCardExpDate'] .gw-error-inline")
	WebElement EXPIR_DATE_ERROR_CSS;

	@FindBy(css = "div[class='gw-controls-radios'] label.gw-first")
	WebElement CHECKINGS_LBL_CSS;
	
	@FindBy(css = "div[class='gw-controls-radios'] [data-ng-value='valueLeft']")
	WebElement CHECKINGS_INPUT_CSS;
	
	@FindBy(css = "div[class='gw-controls-radios'] [data-ng-value='valueRight']")
	WebElement SAVINGS_INPUT_CSS;

	@FindBy(css = "div[class='gw-controls-radios'] label.gw-second")
	WebElement SAVINGS_LBL_CSS;

	@FindBy(css = "div[model='creditCardDetails.creditCardIssuer'] select")
	WebElement CREDIT_CARD_ISSUER_DROP_CSS;

	@FindBy(css = "div[model='creditCardDetails.creditCardNumber'] input")
	WebElement CREDIT_CARD_NUMBER_TXT_CSS;

	@FindBy(css = "#cardNum")
	WebElement INOW_CREDIT_CARD_NUMBER_TXT_CSS;

	@FindBy(css = "#expiryDate")
	WebElement INOW_CREDIT_CARD_EXPIRY_DATE_CSS;

	@FindBy(css = "#cvv")
	WebElement INOW_CREDIT_CARD_CVV_CSS;

	@FindBy(css = "#firstNameID")
	WebElement INOW_CREDIT_CARD_FIRSTNAME_CSS;

	@FindBy(css = "#lastNameID")
	WebElement INOW_CREDIT_CARD_LASTNAME_CSS;

	@FindBy(css = "#zipID")
	WebElement INOW_CREDIT_ZIP_CSS;

	@FindBy(css = "#cityID")
	WebElement INOW_CREDIT_CITY_CSS;

	@FindBy(css = "#billingAddressID")
	WebElement INOW_CREDIT_BILLING_ADDRESS_CSS;

	@FindBy(css = "#stateID")
	WebElement INOW_CREDIT_STATE_CSS;

	@FindBy(css = "#phonenumberID")
	WebElement INOW_CREDIT_PHONE_CSS;

	@FindBy(css = "#countryID")
	WebElement INOW_CREDIT_COUNTRY_CSS;

	@FindBy(css = "#saveBtn")
	WebElement INOW_CREDIT_SAVE_BUTTON_CSS;



	@FindBy(xpath = "//*[@ng-model='creditCardDetails.creditCardNumber.value']/../following-sibling::div")
	WebElement CREDIT_CARD_NUMBER_ERROR_CSS;
	
	@FindBy(css = "[name='dateFieldsMonth']")
	WebElement CREDIT_CARD_MONTH_DROP_NAME;

	@FindBy(css = "[name='dateFieldsYear']")
	WebElement CREDIT_CARD_YEAR_DROP_NAME;
	
	@FindBy(xpath = "//*[@name='dateFieldsMonth']/ancestor::div[@class='gw-controls']/div")
	WebElement CREDIT_CARD_YEAR_DROP_ERROR_XPATH;

	@FindBy(css = "[ng-model*='paymentMethod'], [ng-model*='PaymentMethod']")
	WebElement PAYMENT_METHOD_DROP_CSS;
	
	@FindBy(css = "[class='gw-modal gw-fade  in']")
	WebElement POP_UP_CSS;

	@FindBy(css = "[on-click*='redistribute()']")
	WebElement SPREAD_PAYMENTS_BTN_CSS;

	@FindBy(css = "[on-click*='displayPayInFull()']")
	WebElement PAY_IN_FULL_BTN_CSS;

	@FindBy(css = "[on-click*='payInFull()'], [on-click='goToNext()']")
	WebElement PAY_AND_FINISH_BTN_CSS;

	@FindBy(css = "gw-action-message .gw-titles-heading")
	WebElement RENEWAL_MSG_AGENT_PAYMENT_LINE1_CSS;

	@FindBy(css = "gw-action-message p")
	WebElement RENEWAL_MSG_AGENT_PAYMENT_LINE2_CSS;

	@FindBy(css = "[on-click*='openReferToUnderwriterForm']")
	WebElement RENEWAL_REFER_TO_UW_BTN_CSS;

	@FindBy(css = "[ng-click*='referToUnderwriter']")
	WebElement RENEWAL_CONFIRM_REFER_TO_UW_BTN_CSS;

	@FindBy(css = "[ng-if*='referingToUnderwriter'] textarea")
	WebElement RENEWAL_REFER_TO_UW_NOTE_TXTAREA_CSS;
	
	String HEADER =  "//*[contains(@class,'gw-fade')]//*[contains(@class,'gw-heading')]";

	String POPUP_BODY = "//*[contains(@class,'gw-fade')]//*[contains(@class,'gw-message')]";
	
	String PAYMENT_METHOD_INPUT_CSS = "input[id='OPTION']";


	@FindBy(css = "button[ng-click='$ctrl.loadAuthorizeNetIframe()']")
	WebElement BUTTON_ENTER_CREDIT_INFO;

	@FindBy(css = "iframe[name='iframeAuthNetTarget']")
	WebElement INOW_PAYMENT_IFRAME;

	public PaymentDetailsPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public PaymentDetailsPage(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	// Set Methods

	public PaymentDetailsPage selectPaymentPlan(String planName) {
		return null;
	}

	public PolicyConfirmationPage goToConfirmationPage() {
		if (this.data.size() > 0) {
			seleniumCommands
					.waitForElementToBeVisible(By.cssSelector(PolicyConfirmationPageLocators.CONFIRMATION_PAGE_CSS));
			return new PolicyConfirmationPage(this.data);
		} else {
			return new Pagefactory().getConfirmationPage();
		}
	}

	public void clickSpreadPayments(){
		seleniumCommands.clickbyJS(SPREAD_PAYMENTS_BTN_CSS);
	}

	public PaymentDetailsPage clickPay(){
		seleniumCommands.clickbyJS(PAY_IN_FULL_BTN_CSS);
		return new PaymentDetailsPage();
	}

	public CPBOPTransactionConfirmationPage clickPayAndFinish(){
		seleniumCommands.clickbyJS(PAY_AND_FINISH_BTN_CSS);
		return new CPBOPTransactionConfirmationPage();
	}

	public PaymentDetailsPage setPaymentPlan() {
		String paymentMethod = data.get("PaymentPlan");
		seleniumCommands.waitForElementToExistAndScrollTO(
				By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentMethod)));
		seleniumCommands
				.clickbyJS(By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentMethod)));
		return this;
	}

	public PaymentDetailsPage setInowPaymentPlan() {
		String paymentPlan = data.get("INOW_PaymentPlan");
		seleniumCommands.waitForElementToExistAndScrollTO(
				By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentPlan)));
		seleniumCommands
				.clickbyJS(By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentPlan)));
		return this;
	}

	public PaymentDetailsPage setInowPaymentPlan(String paymentPlan) {
		seleniumCommands.waitForElementToExistAndScrollTO(
				By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentPlan)));
		seleniumCommands
				.clickbyJS(By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentPlan)));
		return this;
	}

	public PaymentDetailsPage setPaymentPlan(String paymentMethod) {
		seleniumCommands.waitForElementToExistAndScrollTO(
				By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentMethod)));
		seleniumCommands
				.click(By.cssSelector(PaymentDetailsPageLocators.PAYMENT_METHOD_CSS.replace("OPTION", paymentMethod)));
		return this;
	}

	public PaymentDetailsPage setAccountType() {
		if(data.get("AccountType").equalsIgnoreCase("Savings")) {
			seleniumCommands.clickbyJS(SAVINGS_LBL_CSS);
			isSavingBankAccountSelected().shouldBeTrue("Saving bank account type is not selected");
			return this;
		}else if(data.get("AccountType").equalsIgnoreCase("Checking")){
			seleniumCommands.clickbyJS(CHECKINGS_LBL_CSS);
			isCheckingBankAccountSelected().shouldBeTrue("Checking bank account type is not selected");
		}
		return this;
	}

	public PaymentDetailsPage setBankPaymentMethod() {
		seleniumCommands.selectDropDownValueByText(PAYMENT_METHOD_DROP_CSS, "Bank Account");
		return this;
	}
	
	public PaymentDetailsPage setCreditCardPaymentMethod() {
		seleniumCommands.selectDropDownValueByText(PAYMENT_METHOD_DROP_CSS, "Credit Card");
		return this;
	}

	public PaymentDetailsPage setPaymentMethod(String paymentMethod) {
		seleniumCommands.selectDropDownValueByText(PAYMENT_METHOD_DROP_CSS, paymentMethod);
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector("div[model='creditCardDetails.creditCardIssuer']
		// select"));
		return this;
	}

	public PaymentDetailsPage setAccountNumber(String accountNumber) {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_NUMBER_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_NUMBER_CSS), accountNumber);
		return this;
	}

	public PaymentDetailsPage setAccountNumber() {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_NUMBER_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_NUMBER_CSS), data.get("AccountNumber"));
		return this;
	}

	public PaymentDetailsPage setAccountHolderName() {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_HOLDER_NAME_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.ACCOUNT_HOLDER_NAME_CSS), "John Snow");
		return this;
	}

	public PaymentDetailsPage setABARoutingNumber() {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.ABA_NUMBER_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.ABA_NUMBER_CSS), data.get("RoutingNumber"));
		return this;
	}

	public PaymentDetailsPage setABARoutingNumber(String routingNumber) {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.ABA_NUMBER_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.ABA_NUMBER_CSS), routingNumber);
		return this;
	}

	public PaymentDetailsPage setBankName() {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.BANK_NAME_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.BANK_NAME_CSS), data.get("BankName"));
		return this;
	}

	public PaymentDetailsPage setBankName(String bankName) {
		seleniumCommands.click(By.cssSelector(PaymentDetailsPageLocators.BANK_NAME_CSS));
		seleniumCommands.type(By.cssSelector(PaymentDetailsPageLocators.BANK_NAME_CSS), bankName);
		return this;
	}

	public PaymentDetailsPage setCardIssuer(String issuer) {
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_ISSUER_DROP_CSS, issuer);
		return this;
	}

	public PaymentDetailsPage setCardIssuer() {
		ThreadLocalObject.getData().put("CardIssuer", "Visa");
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_ISSUER_DROP_CSS, data.get("CardIssuer"));
		return this;
	}

	public PaymentDetailsPage setCardNumber() {
		ThreadLocalObject.getData().put("CreditCardNumber", "4564565465765786");
		seleniumCommands.type(CREDIT_CARD_NUMBER_TXT_CSS, data.get("CreditCardNumber"));
		return this;
	}

	public PaymentDetailsPage setCardNumber(String cardNumber) {
		seleniumCommands.type(CREDIT_CARD_NUMBER_TXT_CSS, cardNumber);
		return this;
	}

	public PaymentDetailsPage setExpirationDate() {
		ThreadLocalObject.getData().put("ExpMonth", "July");
		ThreadLocalObject.getData().put("ExpYear", "2025");
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_MONTH_DROP_NAME, data.get("ExpMonth"));
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_YEAR_DROP_NAME, data.get("ExpYear"));
		return this;
	}

	public PaymentDetailsPage setExpirationDate(String expirationMonth, String expirationYear) {
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_MONTH_DROP_NAME, expirationMonth);
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_YEAR_DROP_NAME, expirationYear);
		return this;
	}

	public PaymentDetailsPage goNext() {
		seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public PolicyConfirmationPage purchasePolicy() {

		this.goNext();
		return checkIfQuoteCanNotCompletePopUpDisplayed();
	}
	
	private PolicyConfirmationPage checkIfQuoteCanNotCompletePopUpDisplayed() {
//		String POP_UP =  "//*[@class='gw-modal gw-fade  in']";
//		seleniumCommands.waitForElementToBeVisible(By.xpath(POP_UP));
//		new Validation(getAlertHeader(), DataConstant.PROCESSING_PAYMENT_HEADER).shouldBeEqual();
		seleniumCommands
					.waitForElementToBeVisible(By.cssSelector(PolicyConfirmationPageLocators.CONFIRMATION_PAGE_CSS));
			return new Pagefactory().getConfirmationPage();
	}

	public PaymentDetailsPage closePopUp() {
		new AlertHandler().closeAlert();
		return this;
	}

	// Get Method

	private String getMonthlyPremium() {
		return seleniumCommands.getTextAtLocator(MONTHLY_PREMIUM_VALUE_CSS).replaceAll(",", "").replace("$", "");
	}

	private String getAnnualPremium() {
		return seleniumCommands.getTextAtLocator(TOTAL_PREMIUM_VALUE_CSS).replaceAll(",", "").replace("$", "");
	}

	private HashMap<String, HashMap<String, String>> getAllPaymentPlans() {
		return null;
	}

	private Map<String, String> getSelectedPlan() {
		return null;
	}

	private String getAnnualPlanName() {
		return seleniumCommands.getTextAtLocator(FULL_PAYMENT_PLAN_NAME_CSS);
	}

	public String getPaymentMethod() {
		return seleniumCommands.getSelectedOptionFromDropDown(PAYMENT_METHOD_DROP_CSS);
	}

	public BinaryToggler getAccountTypeToggler() {
		return new BinaryToggler(seleniumCommands.findByContainedElement(SAVINGS_LBL_CSS, By.cssSelector("[gw-pl-radios-binary]")));
	}
	
	public String getBankAccountType() {
		if(SAVINGS_INPUT_CSS.isSelected()) {
			return "Savings";
		}
		return "Checking";
	}

	public ViewModelInput getAccountNumberInput() {
		return new ViewModelInput(seleniumCommands.findByContainedElement(seleniumCommands.findElement(ACCOUNT_NUMBER_TXT_CSS), By.cssSelector("[gw-pl-input-ctrl]")));
	}

	public String getAccountNumber() {
		return seleniumCommands.getValueAttributeFromLocator(seleniumCommands.findElement(ACCOUNT_NUMBER_TXT_CSS));
	}

	public ViewModelInput getRoutingNumberInput() {
		return new ViewModelInput(seleniumCommands.findByContainedElement(ABA_NUMBER_TXT_CSS, By.cssSelector("[gw-pl-input-ctrl]")));
	}

	public String getRoutingNumber() {
		return seleniumCommands.getValueAttributeFromLocator(ABA_NUMBER_TXT_CSS);
	}

	public ViewModelInput getBankNameInput() {
		return new ViewModelInput(seleniumCommands.findByContainedElement(BANK_NAME_TXT_CSS, By.cssSelector("[gw-pl-input-ctrl]")));
	}

	public String getBankName() {
		return seleniumCommands.getValueAttributeFromLocator(BANK_NAME_TXT_CSS);
	}
	
	public String getCardIssuerName() {
		return seleniumCommands.getSelectedOptionFromDropDown(CREDIT_CARD_ISSUER_DROP_CSS);
	}
	
	public String getCreditCardNumber() {
		return seleniumCommands.getValueAttributeFromLocator(CREDIT_CARD_NUMBER_TXT_CSS);
	}
	
	public String getCreditCardExpMonth() {
		return seleniumCommands.getSelectedOptionFromDropDown(CREDIT_CARD_MONTH_DROP_NAME);
	}
	
	public String getCreditCardExpYear() {
		return seleniumCommands.getSelectedOptionFromDropDown(CREDIT_CARD_YEAR_DROP_NAME);
	}
	
	public String getAlertHeader() {
		logger.info("Getting Header Text");
		return POP_UP_CSS.findElement(By.xpath(HEADER)).getText();
	}

	// Validation method

	public Validation validateProcessingPaymentPopUp(String jsonData) throws Exception {
		return new AlertHandler().validateProcessingPaymentPopUpContent();
	}
	
	public Validation isMonthlyPermiumEqualsTo(String jsonData) throws Exception {
		return new Validation(getMonthlyPremium(), ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonData).get("MONTHLY_AMOUNT_AFTER_TAX_VALUE"));
	}

	public Validation isAnnualPremiumEqualsTo(String jsonData) throws Exception {
		return new Validation(new Double(getAnnualPremium()), new Double(ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonData).get("ANNUAL_AMOUNT_AFTER_TAX_VALUE")));
	}
	
	public Validation isSelectedPlanEquals(String planName) {
		return new Validation(getSelectedPlan(), planName);
	}

	public Validation isSelectedPlanEquals(HashMap<String, HashMap<String, String>> planDataMap) {
		return new Validation(getAllPaymentPlans(), planDataMap);

	}
	
	public Validation validateCardIssuerName() {
		logger.info( "Validating card issuer field value");
		return new Validation(getCardIssuerName(), data.get("CardIssuer"));
	}

	public PaymentDetailsPage payAnnualPremiumWithSavingsBankAccount() {
		seleniumCommands.clickbyJS(SAVINGS_LBL_CSS);
		this.setAccountNumber().setABARoutingNumber().setBankName();
		return this;
	}

	public PaymentDetailsPage payAnnualPremiumWithCheckingBankAccount() {
		this.setAccountNumber().setBankPaymentMethod().setABARoutingNumber().setBankName();
		return this;
	}

	public PaymentDetailsPage iNowPayAnnualPremiumWithCheckingBankAccount() {
		this.setBankPaymentMethod().setAccountHolderName().setAccountNumber("123456789").setABARoutingNumber("123456789").setBankName();
		return this;
	}

	public PaymentDetailsPage payMonthlyPremiumWithCheckingBankAccount() {
		this.setPaymentPlan().setBankPaymentMethod().setAccountNumber().setABARoutingNumber().setBankName();
		isCheckingBankAccountSelected().shouldBeTrue("Checking bank account is not selected");
		return this;
	}

	public PaymentDetailsPage iNowPayMonthlyPremiumWithCheckingBankAccount(String paymentPlan) {
		this.setInowPaymentPlan(paymentPlan).setBankPaymentMethod().setAccountHolderName().setAccountNumber("123456789").setABARoutingNumber("123456789").setBankName();
		isCheckingBankAccountSelected().shouldBeTrue("Checking bank account is not selected");
		return this;
	}

	public PaymentDetailsPage payMonthlyPremiumWithSavingsBankAccount() {
		seleniumCommands.clickbyJS(SAVINGS_LBL_CSS);
		this.setPaymentPlan().setAccountNumber().setABARoutingNumber().setBankName();
		isSavingBankAccountSelected().shouldBeTrue("Saving bank account is not selected.");
		return this;
	}

	public PaymentDetailsPage iNowPayMonthlyPremiumWithSavingsBankAccount() {
		this.setInowPaymentPlan().setBankPaymentMethod();
		seleniumCommands.clickbyJS(SAVINGS_LBL_CSS);
		this.setAccountHolderName().setAccountNumber().setABARoutingNumber().setBankName();
		isSavingBankAccountSelected().shouldBeTrue("Saving bank account is not selected.");
		return this;
	}

	public PaymentDetailsPage payAnnualPremiumWithCreditCard() {
		this.setPaymentMethod("Credit Card");
		this.setCardIssuer().setCardNumber().setExpirationDate();
		return this;
	}

	public PaymentDetailsPage clickEnterCreditCardInfoButton(){
		seleniumCommands.waitForElementToBeVisible(BUTTON_ENTER_CREDIT_INFO);
		seleniumCommands.clickbyJS(BUTTON_ENTER_CREDIT_INFO);
		return this;
	}

	public PaymentDetailsPage setInowCreditCardDetailsAndSave(){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		//switch to iframe
		ThreadLocalObject.getDriver().switchTo().frame(INOW_PAYMENT_IFRAME);

		seleniumCommands.waitForElementToBeVisible(INOW_CREDIT_CARD_NUMBER_TXT_CSS);
		seleniumCommands.type(INOW_CREDIT_CARD_NUMBER_TXT_CSS, data.get("INOW_CreditCardNumber"));
		seleniumCommands.type(INOW_CREDIT_CARD_CVV_CSS, data.get("INOW_CreditCardCVV"));

		seleniumCommands.waitForLoaderToDisappearFromPage();
		INOW_CREDIT_CARD_EXPIRY_DATE_CSS.click();
		INOW_CREDIT_CARD_EXPIRY_DATE_CSS.sendKeys(data.get("INOW_CreditCardExpiry"));
		seleniumCommands.typeByJS(INOW_CREDIT_CARD_EXPIRY_DATE_CSS, data.get("INOW_CreditCardExpiry"));
		seleniumCommands.typeByJS(INOW_CREDIT_CARD_FIRSTNAME_CSS, data.get("INOW_Billing_FirstName"));
		seleniumCommands.typeByJS(INOW_CREDIT_CARD_LASTNAME_CSS, data.get("INOW_Billing_LastName"));
		seleniumCommands.selectDropDownValueByText(INOW_CREDIT_COUNTRY_CSS, data.get("INOW_Billing_Country"));

		seleniumCommands.type(INOW_CREDIT_ZIP_CSS, data.get("INOW_Billing_ZIP"));
		seleniumCommands.type(INOW_CREDIT_CITY_CSS, data.get("INOW_Billing_City"));
		seleniumCommands.type(INOW_CREDIT_BILLING_ADDRESS_CSS, data.get("INOW_Billing_Address"));
		seleniumCommands.type(INOW_CREDIT_STATE_CSS, data.get("INOW_Billing_State"));
		seleniumCommands.type(INOW_CREDIT_PHONE_CSS, data.get("INOW_Billing_Phone"));

		clickSaveInowCreditCardDetails();

		// return to defalult
		ThreadLocalObject.getDriver().switchTo().defaultContent();
		return this;
	}

	public PaymentDetailsPage clickSaveInowCreditCardDetails(){
		seleniumCommands.waitForElementToBeVisible(INOW_CREDIT_SAVE_BUTTON_CSS);
		seleniumCommands.clickbyJS(INOW_CREDIT_SAVE_BUTTON_CSS);
		return this;
	}

	public PaymentDetailsPage payMonthlyPremiumWithCreditCard() {
		this.setPaymentMethod("Credit Card");
		this.setPaymentPlan().setCardIssuer().setCardNumber().setExpirationDate();
		return this;
	}

	public PaymentDetailsPage iNowPayMonthlyPremiumWithCreditCard() {
		this.setInowPaymentPlan().setPaymentMethod("Credit Card");
		this.setInowCreditCardDetailsAndSave();
		return this;
	}

	public Validation isChoosePaymentPlanConfirmationPresent() {
		logger.info("Validating the ChoosePaymentPlan Confirmation pop up on Payment page");
		seleniumCommands.waitForElementToBeVisible(PAYMENT_PLAN_CONFIRMATION_POP_UP_CSS);
		return new Validation(PAYMENT_PLAN_CONFIRMATION_POP_UP_CSS.isDisplayed());
	}

	public Validation validateChoosePaymentPlanConfirmationText() {
		logger.info("Validating the ChoosePaymentPlan Confirmation pop text  up on Payment page");
		seleniumCommands.waitForElementToBeVisible(PAYMENT_PLAN_CONFIRMATION_POP_UP_CSS);
		new Validation(DataConstant.PAYMENT_PLAN_CONF_HEADER, seleniumCommands.getTextAtLocator(By.xpath(HEADER))).shouldBeEqual("Header text is not matched");
		new Validation(DataConstant.PAYMENT_PLAN_CONF_BODY, seleniumCommands.getTextAtLocator(By.xpath(POPUP_BODY))).shouldBeEqual("Pop Up body is not matched");
		return new Validation(true);
	}

	public Validation areBankPaymentFieldsMarkedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the Bank payment fields on policy payment page");
		return new Validation(isAccountNumberFieldMakedWithError() && isABANumberFieldMakedWithError()
				&& isBankNameFieldMakedWithError());
	}
	
	public Validation areCreditCardPaymentFieldsMarkedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the Credit card payment fields on policy payment page");
		this.setPaymentMethod("Credit Card");
		return new Validation(isCreditCardNumberFieldMakedWithError() && isCreditCardExpiFieldMakedWithError());
	}

	public boolean isAccountNumberFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for AccountNumber Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(ACCOUNT_NUMBER_TXT_CSS))
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Account Number is marked with Error " + value);
		return value;
	}

	public boolean isAccountNumberFieldMakedWithAsterisk() {
		logger.info("Validating the Asterick for Phone Number Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(ACCOUNT_NUMBER_LBL_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Account Number is marked with Asterisk " + value);
		return value;
	}

	public boolean isABANumberFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for ABA Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(ABA_NUMBER_TXT_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("ABA Number is marked with Error " + value);
		return value;
	}
	
	public Validation isCheckingBankAccountSelected() {
		logger.info("Validating the checking bank account type selection");
		return new Validation(CHECKINGS_INPUT_CSS.isSelected());
	}
	
	public Validation isSavingBankAccountSelected() {
		logger.info("Validating the saving bank account type selection");
		return new Validation(SAVINGS_INPUT_CSS.isSelected());
	}

	public boolean isABANumberFieldMakedWithAsterisk() {
		logger.info("Validating the Asterick for ABA Number Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(ABA_NUMBER_LBL_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info(" Number is marked with Asterisk " + value);
		return value;
	}

	public boolean isBankNameFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for Bank Name Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(BANK_NAME_TXT_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Bank Name is marked with Error " + value);
		return value; 
	}

	public boolean isBankNameFieldMakedWithAsterisk() {
		logger.info("Validating the Asterick for Bank Name Field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(BANK_NAME_LBL_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Bank Name is marked with Asterisk " + value);
		return value;
	}
	
	public boolean isCreditCardNumberFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for Credit Card Number Field");
		boolean value = seleniumCommands.getTextAtLocator(CREDIT_CARD_NUMBER_ERROR_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Credit Card Number is marked with Error " + value);
		return value;
	}
	
	public boolean isCreditCardExpiFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for Credit Card Expiration date Field");
		boolean value = seleniumCommands.getTextAtLocator(CREDIT_CARD_YEAR_DROP_ERROR_XPATH)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Credit Card Expiration date is marked with Error " + value);
		return value;
	}

	public Validation isPaymentDetailsPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(TOTAL_PREMIUM_VALUE_CSS);
		return new Validation(seleniumCommands.isElementPresent(TOTAL_PREMIUM_VALUE_CSS));
	}
	
	public Validation isPaymentPlanSelected() {
		logger.info("Validating if payment plan is selected");
		String paymentPlan = PAYMENT_METHOD_INPUT_CSS.replace("OPTION", data.get("PaymentPlan"));
		seleniumCommands.waitForElementToExistAndScrollTO(By.cssSelector(paymentPlan));
		return new Validation(seleniumCommands.findElement(By.cssSelector(paymentPlan)).isSelected());
	}

	public Validation isPolicyPlanNameEqualTo() {
		return new Validation(getAnnualPlanName(), DataConstant.FULL_PAY_ANNUAL_PLAN);
	}

	public Validation isINowPolicyPlanNameEqualTo() {
		return new Validation(getAnnualPlanName(), DataConstant.INOW_FULL_PAY_ANNUAL_PLAN);
	}
	
	public Validation arePaymentFieldsInInitialState() {
		new Validation(this.getPaymentMethod(), DEFAULT_PAYMENT_METHOD)
				.shouldBeEqual("Payment method is not set to default");

//		new Validation(this.getAccountTypeToggler().getSelectedValue(), DEFAULT_ACCOUNT_TYPE_VALUE)
//				.shouldBeEqual("Account type toggler is not in a default position"); //TODO: for some reason there's [object Object] instead of a proper value on an input

		new Validation(this.getAccountNumber(), "").shouldBeEqual("Account number is not empty");
		new Validation(this.getRoutingNumber(), "").shouldBeEqual("Routing number is not empty");
		new Validation(this.getBankName(), "").shouldBeEqual("Bank name is not empty");

		return new Validation(true);
	}

	//Individual validations for all fields

	public Validation isAccountNumberMarkedWithError() {
		logger.info( "Validating the Mandatory Error for Account number field");
		return new Validation(seleniumCommands.getErrorMessageForDropdown(seleniumCommands.findElement(ACCOUNT_NUMBER_TXT_CSS)),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isRoutingNumberMarkedWithError() {
		logger.info( "Validating the Mandatory Error for Routing number field");
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ABA_NUMBER_TXT_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isBankNameMarkedWithError() {
		logger.info( "Validating the Mandatory Error for Bank Name field");
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(BANK_NAME_TXT_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isCreditCardNumberMarkedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for Credit Card number field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(CREDIT_CARD_NUMBER_TXT_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}
	public Validation isCreditCardNumberMarkedWithInvalidError() {
		logger.info( "Validating the Invalid Error for Credit Card number field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(CREDIT_CARD_NUMBER_TXT_CSS),DataConstant.INVALID_CREDIT_CARD_ERROR);
	}

	public Validation isExpirationDateMarkedWithInvalidError() {
		logger.info( "Validating the Invalid Error for Expiration date field");
		return new Validation(seleniumCommands.getTextAtLocator(EXPIR_DATE_ERROR_CSS),DataConstant.DATE_FUTURE_ERROR);
	}

	public Validation isExpirationDateMarkedWithError() {
		logger.info( "Validating the Mandatory Error for Expiration date field");
		return new Validation(seleniumCommands.getTextAtLocator(EXPIR_DATE_ERROR_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isPaymentInformationPageSaved(){
		new Validation(seleniumCommands.getValueAttributeFromLocator(seleniumCommands.findElement(ACCOUNT_NUMBER_TXT_CSS)), "").shouldBeEqual("Account number isn't blank");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ABA_NUMBER_TXT_CSS), "").shouldBeEqual("Routing Number isn't blank");
		new Validation(seleniumCommands.getValueAttributeFromLocator(BANK_NAME_TXT_CSS), "").shouldBeEqual("Bank Name isn't blank");
		return new Validation(false);
	}

	public void validateMessageOnRenewalPaymentForAgent(){
		new Validation(seleniumCommands.getTextAtLocator(RENEWAL_MSG_AGENT_PAYMENT_LINE1_CSS), DataConstant.RENEWAL_PAYMENT_MSG_AGENT[0]).shouldBeEqual("The first line of the message didn't match");
		new Validation(seleniumCommands.getTextAtLocator(RENEWAL_MSG_AGENT_PAYMENT_LINE2_CSS),DataConstant.RENEWAL_PAYMENT_MSG_AGENT[1]).shouldBeEqual("The second line of the message didn't match");
	}

	public PaymentDetailsPage selectSavingAccountType() {
		seleniumCommands.clickbyJS(SAVINGS_INPUT_CSS);
		return this;
	}

	public PaymentDetailsPage selectCheckingAccountType() {
		seleniumCommands.clickbyJS(CHECKINGS_INPUT_CSS);
		return this;
	}

	public PaymentDetailsPage clickReferRenewalToUW(){
		seleniumCommands.click(RENEWAL_REFER_TO_UW_BTN_CSS);
		return this;
	}

	public PaymentDetailsPage confirmReferRenewalToUW(){
		seleniumCommands.waitForElementToBeVisible(RENEWAL_CONFIRM_REFER_TO_UW_BTN_CSS);
		seleniumCommands.type(RENEWAL_REFER_TO_UW_NOTE_TXTAREA_CSS, data.get("UWNote"));
		seleniumCommands.click(RENEWAL_CONFIRM_REFER_TO_UW_BTN_CSS);
		return this;
	}
}
