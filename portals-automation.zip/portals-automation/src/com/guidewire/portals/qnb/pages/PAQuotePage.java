package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.common.selenium.FrameWorkConstants;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

import io.restassured.path.json.JsonPath;



public class PAQuotePage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();
	PACoverageDetailsPage paCovPage = new PACoverageDetailsPage();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "span[class='fa fa-print']")
	WebElement PRINT_POLICY_BTN_CSS;

	@FindBy(css = "gw-qnb-multiple-offering-view")
	WebElement QUOTE_OPTION_TILE_CSS;
	
	@FindBy(css = "[ng-repeat*='offering in']:nth-of-type(1) p")
	WebElement QUOTE_OPTION_BASIC_LBL_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li div[class='offeringCost ng-binding']")
	WebElement QUOTE_OPTION_BASE_COST_CSS;

	@FindBy(css = "[ng-repeat*='offering in']:nth-of-type(3) p")
	WebElement QUOTE_OPTION_STANDARD_LBL_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(2) div[class='offeringCost ng-binding']")
	WebElement QUOTE_OPTION_STANDARD_COST_CSS;

	@FindBy(css = "[ng-repeat*='offering in']:nth-of-type(2) p")
	WebElement QUOTE_OPTION_PREMIUM_LBL_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(3) div[class='offeringCost ng-binding']")
	WebElement QUOTE_OPTION_PREMIUM_COST_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(4) div[class='gw-offeringName ng-binding']")
	WebElement QUOTE_OPTION_CUSTOM_LBL_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(4) div[class='offeringCost ng-binding']")
	WebElement QUOTE_OPTION_CUSTOM_COST_CSS;

	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [class='gw-price ng-binding']")
	WebElement BASIC_MONTHLY_PREMIUM_COST_LBL_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [class='gw-term ng-binding']")
	WebElement BASIC_FULL_PREMIUM_COST_LBL_CSS;

	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] button[ng-click='buyQuote()']")
	WebElement BUY_POLICY_BTN_CSS;
	
	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(1) button")
	WebElement BUY_BASIC_POLICY_BTN_CSS;

	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(1) button:disabled")
	WebElement BUY_BASIC_POLICY_BTN_DISABLED_CSS;
	
	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(3) button")
	WebElement BUY_STANDARD_POLICY_BTN_CSS;

	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(3) button:disabled")
	WebElement BUY_STANDARD_POLICY_BTN_DISABLED_CSS;
	
	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(2) button")
	WebElement BUY_PREMIUM_POLICY_BTN_CSS;

	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(2) button:disabled")
	WebElement BUY_PREMIUM_POLICY_BTN_DISABLED_CSS;

	@FindBy(css = "[class='gw-alert__content'] div")
	WebElement INFO_MESSAGE;

	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] input[value='monthly'] + label")
	WebElement FULL_PREMIUM_COST_RBTN_CSS;

	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] input[value='fullTerm'] + label")
	WebElement MONTHLY_PREMIUM_COST_RBTN_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(1) a")
	WebElement BASE_POLICY_TILE_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(2) a")
	WebElement STANDARD_POLICY_TILE_CSS;

	@FindBy(css = "ul[class*='gw-nav'] li:nth-of-type(3) a")
	WebElement PREMIUM_POLICY_TILE_CSS;

	@FindBy(css = "button[ng-click='emailQuote()']")
	WebElement EMAIL_QUOTE_BUTTON;

	@FindBy(css = "[class='gw-modal gw-fade gw-modal_animation_ in']")
	WebElement EMAIL_QUOTE_MODAL;

	@FindBy(css = "[class*='gwUnderwritingIssuesTitle']")
	WebElement UNDERWRITING_MESSAGE_TITLE;

  @FindBy(css = "h2[class='gw-titles-heading ng-scope ng-isolate-scope'] span[class='ng-binding ng-scope']")
	WebElement QUOTE_WITHDRAWN_MESSAGE_TITLE;
	
  @FindBy(css = "[class*='gwUnderwritingIssuesWarningText'] p[class]")
	WebElement UNDERWRITING_MESSAGE_TEXT;
	
  @FindBy(css = "[class*='gwUnderwritingIssuesResolutionOptions'] li:nth-of-type(1)")
	WebElement UNDERWRITING_MESSAGE_LIST_LINE1;
	
  @FindBy(css = "[class*='gwUnderwritingIssuesResolutionOptions'] li:nth-of-type(2)")
	WebElement UNDERWRITING_MESSAGE_LIST_LINE2;
	
	@FindBy(css = "[class*='gwUnderwritingIssuesResolutionOptions'] li:nth-of-type(3)")
	WebElement UNDERWRITING_MESSAGE_LIST_LINE3;

	@FindBy(css = "[class*='gwUnderwritingIssuesResolutionOptions'] li:nth-of-type(4)")
	WebElement UNDERWRITING_MESSAGE_LIST_LINE4;
	
	@FindBy(css = "button[on-click='$ctrl.withdrawSubmission()']")
	WebElement WITHDRAW_QUOTE_BUTTON;

	@FindBy(css = "button[on-click='withdraw()']")
	WebElement WITHDRAW_QUOTE_BUTTON_QUOTESUMMARYPAGE;
	
  @FindBy(css = "button[on-click='$ctrl.openReferToUWForm()']")
	WebElement REFER_TO_UNDERWRITER_BUTTON;

	@FindBy(css = "button[ng-click='$ctrl.closeReferToUWForm()']")
	WebElement CANCEL_REFER_TO_UNDERWRITER_BUTTON;

	@FindBy(css = "[ng-click*='referToUnderwriter()']")
	WebElement REFER_TO_UNDERWRITER_BUTTON_CONFIRM;

	By ACCOUNT_SUMMARY_LINK = By.cssSelector("a[ui-sref*='accounts.detail.summary']");
	
  private static String MEXICO_COVARAGE_CHECKBOX = "input[id='default_base5_coverage_";

	private static String UNINSURED_MOTORIST_BODILY_INJURY_CHECKBOX = "label[for='default_base1_coverage_";

	private static String UNINSURED_MOTORIST_PROPERTY_DAMAGE_CHECKBOX = "//label[@for='default_base3_coverage_";

	By UNINSURED_MOTORIST_PROPERTY_DAMAGE_DROPDOWN = By.cssSelector("select[id='PAUMPDLimit']");

	By UNINSURED_MOTORIST_BODILY_INJURY_DROPDOWN = By.cssSelector("select[id='PAUMBI']");

	By UNINSURED_MOTORIST_PROPERTY_DAMAGE_ERROR_MESSAGE = By.xpath("//select[@id='PAUMPDLimit']/../../following-sibling::div/div[@aria-hidden='false']/span");

	By UNINSURED_MOTORIST_BODILY_INJURY_ERROR_MESSAGE = By.xpath("//select[@id='PAUMBI']/../../following-sibling::div/div[@aria-hidden='false']/span");

	By LIABILITY_BODILY_INJURY_AND_PROPERTY_DAMAGE_DROPDOWN = By.cssSelector("select[id='PALiability'][aria-disabled='false'], select[id='PALiability']");

	By RESET_COVERAGES_BUTTON = By.cssSelector("a[ng-click*='revertCustomQuote(offering']");

	By OFFERING_PRICE = By.cssSelector("[class*='quote_offering_price'] span[class='ng-binding ng-scope']");

	By PAY_IN_FULL_TAB = By.cssSelector("label[title='Pay In Full']");

  By RECALCULATE_BUTTON = By.xpath("//button[ contains(@ng-click,'recalculate')]");

	By BUY_NOW = By.xpath("//button[ contains(@ng-disabled,'shouldDisableBuyOrRecalculateButton') and contains(@class,'gw-btn-primary') and not(contains(@class,'MobileQuoteOfferings'))]");

	String QUOTE_TILE_COUNT = "[ng-repeat*='offering in']";
	
	String MONTHLY_RDBTN_ID = "quoteTermFull0";

	String QUOTE_NUMBER = "p[class='gw-highlight ng-binding']";
	
	By RECALCULATE_BTN_CSS = By.cssSelector("[ng-click*='recalculate'][aria-disabled]");

	public PAQuotePage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT),
				PAQuotePage.class);
		if(!ThreadLocalObject.getSuitenName().equals(FrameWorkConstants.GPA_SUITE)) {
			ThreadLocalObject.setQuoteNum(new QuoteInfoBar().getSubmissionNumber());
		}
	}

	public String getQuoteNumber(){
		return new QuoteInfoBar().getSubmissionNumber();
	}
	public PAQuotePage(Object obj) {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		if(!ThreadLocalObject.getSuitenName().equals(FrameWorkConstants.GPA_SUITE)) {
			ThreadLocalObject.setQuoteNum(new QuoteInfoBar().getSubmissionNumber());
		}
	}
	public PAPolicyInfoPage goToPAPolicyInfoPage() {
		return new Pagefactory().getPAPolicyInfoPage();
	}

	private void goNext() {
	}

	public PolicyConfirmationPage buyQuotedPolicy()
	{
		new PAQuotePage().buyBasePolicyWithMonthlyPayment()
				.goToPAPolicyInfoPage()
				.setPolicyInfoPageDetails()
				.goToPaymentDetailsPage();
		new PaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
				.purchasePolicy();
		return new PolicyConfirmationPage();
	}

	public PAQuotePage openBaseQuoteView() {
		logger.info("Open Base policy View");
		seleniumCommands.clickbyJS(BASE_POLICY_TILE_CSS);
		return this;
	}

	public PAQuotePage openStandardQuoteView() {
		logger.info("Open Standard policy View");
		seleniumCommands.clickbyJS(STANDARD_POLICY_TILE_CSS);
		return this;
	}

	public PAQuotePage clickPayInFullTab() {
		logger.info("Clicking Pay in Full tab");
		seleniumCommands.clickbyJS(PAY_IN_FULL_TAB);
		return this;
	}

	public PAQuotePage clickMexicoCoverageCheckbox() {
		logger.info("Clicking Mexico coverage checkbox");
        switch (ThreadLocalObject.getData().get("Program")){
            case "Standard":
                seleniumCommands.clickbyJS(seleniumCommands.findElement(By.cssSelector(MEXICO_COVARAGE_CHECKBOX+"2']")));
                break;
            case "Premium":
                seleniumCommands.clickbyJS(seleniumCommands.findElement(By.cssSelector(MEXICO_COVARAGE_CHECKBOX+"1']")));
                break;
            case "Basic":
                seleniumCommands.clickbyJS(seleniumCommands.findElement(By.cssSelector(MEXICO_COVARAGE_CHECKBOX+"0']")));
                break;
        }
		return this;
	}

	public PAQuotePage clickUninsuredMotoristPropertyDamageCheckbox() {
		logger.info("Clicking Uninsured Motorist Property Damage checkbox");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		switch (ThreadLocalObject.getData().get("Program")){
			case "Standard":
				seleniumCommands.clickbyJS(seleniumCommands.findElement(By.xpath(UNINSURED_MOTORIST_PROPERTY_DAMAGE_CHECKBOX+"2']")));
				break;
			case "Premium":
				seleniumCommands.clickbyJS(By.xpath(UNINSURED_MOTORIST_PROPERTY_DAMAGE_CHECKBOX +"1']"));
				break;
			case "Basic":
				seleniumCommands.clickbyJS(seleniumCommands.findElement(By.xpath(UNINSURED_MOTORIST_PROPERTY_DAMAGE_CHECKBOX+"0']")));
				break;
		}
		seleniumCommands.waitForElementToBeVisible(UNINSURED_MOTORIST_PROPERTY_DAMAGE_DROPDOWN);
		return this;
	}

	public PAQuotePage validateUninsuredMotoristPropertyDamageDropdownValues (List<String> list){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(2);
		new Validation(seleniumCommands.getAllOptionsFromDropDown(seleniumCommands.findElement(UNINSURED_MOTORIST_PROPERTY_DAMAGE_DROPDOWN)), list).shouldBeEqual("Values in Uninsured Motorist Property Damage dropdownlist are not correct");
		return this;
	}
	
	private WebElement getEnabledRecalculateButton() {
		List<WebElement> recalculateBtn = seleniumCommands.findElements(RECALCULATE_BTN_CSS);
		
		return recalculateBtn.stream().filter(subjectElement -> subjectElement.isDisplayed()).findAny().get();
	}

	public PAQuotePage validateUninsuredMotoristBodilyInjuryDropdownValues (List<String> list){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(2);
		int index=0;
		switch (ThreadLocalObject.getData().get("Program")){
			case "Standard":
				index=1;
				break;
			case "Premium":
				index=0;
				break;
			case "Basic":
				index=0;
				break;
		}
		new Validation(seleniumCommands.getAllOptionsFromDropDown(seleniumCommands.findElements(UNINSURED_MOTORIST_BODILY_INJURY_DROPDOWN).get(index)), list).shouldBeEqual("Values in Uninsured Motorist Property Damage dropdownlist are not correct");
		return this;
	}

	public PAQuotePage validateErrorMessageForUninsuredMotoristPropertyDamageDropdown(){
		new Validation(seleniumCommands.getTextAtLocator(UNINSURED_MOTORIST_PROPERTY_DAMAGE_ERROR_MESSAGE).equals(DataConstant.MANDATORY_ERROR_MSG)).shouldBeTrue("No Mandatory field error message is presented");
		return this;
	}

	public PAQuotePage validateErrorMessageForUninsuredMotoristBodilyInjuryDropdown(){
		new Validation(seleniumCommands.getTextAtLocator(UNINSURED_MOTORIST_BODILY_INJURY_ERROR_MESSAGE).equals(DataConstant.MANDATORY_ERROR_MSG)).shouldBeTrue("No Mandatory field error message is presented");
		return this;
	}

	public PAQuotePage setUninsuredMotoristPropertyDamageDropdown(String value){
		seleniumCommands.selectDropDownValueByTextWithOutScroll(UNINSURED_MOTORIST_PROPERTY_DAMAGE_DROPDOWN,value);
		return this;
	}

	public PAQuotePage setUninsuredMotoristBodilyInjuryDropdown(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(2);
		int index=0;
		switch (ThreadLocalObject.getData().get("Program")){
			case "Standard":
				index=1;
				break;
			case "Premium":
				index=0;
				break;
			case "Basic":
				seleniumCommands.clickbyJS(By.cssSelector(UNINSURED_MOTORIST_BODILY_INJURY_CHECKBOX+"0']"));
				seleniumCommands.waitForLoaderToDisappearFromPage();
				index=0;
				break;
		}
		seleniumCommands.staticWait(3);
		seleniumCommands.selectDropDownValueByTextWithOutScroll(seleniumCommands.findElements(UNINSURED_MOTORIST_BODILY_INJURY_DROPDOWN).get(index),value);
		return this;
	}

	public PAQuotePage setValueToLiabilityBodilyInjuryAndPropertyDamage(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		((JavascriptExecutor)ThreadLocalObject.getDriver()).executeScript("scroll(0,-800)");
		seleniumCommands.staticWait(5);
		List<WebElement> liabBDInjury = seleniumCommands.findElements(LIABILITY_BODILY_INJURY_AND_PROPERTY_DAMAGE_DROPDOWN);
		seleniumCommands.selectDropDownValueByTextWithOutScroll(liabBDInjury.get(this.getProgramIndex()),value);
		seleniumCommands.waitForElementToBePresent(By.cssSelector("select[id='PALiability'][aria-disabled='true'], select[id='PALiability']"));
		seleniumCommands.waitForElementToBePresent(LIABILITY_BODILY_INJURY_AND_PROPERTY_DAMAGE_DROPDOWN);
		return this;
	}

	public PAQuotePage clickResetCoverages() {
		logger.info("Clicking Reset coverage button");
		seleniumCommands.waitForElementToBeClickable(RESET_COVERAGES_BUTTON);
		seleniumCommands.clickbyJS(RESET_COVERAGES_BUTTON);
		return this;
	}

    public PAQuotePage clickRecalculateButton() {
        logger.info("Clicking recalculate button");
        int index = this.getProgramIndex();
		seleniumCommands.waitForElementToBeClickable(seleniumCommands.findElements(RECALCULATE_BUTTON).get(index));
		seleniumCommands.findElements(RECALCULATE_BUTTON).get(index).click();
		seleniumCommands.staticWait(3);
		seleniumCommands.waitForElementToBeClickable(BUY_NOW);
        return this;
    }

    public PAQuotePage clickBuyNowButton() {
        logger.info("Clicking Buy Now button");
		seleniumCommands.waitForElementToBeClickable(BUY_NOW);
        seleniumCommands.clickbyJS(seleniumCommands.findElement(BUY_NOW));
        return this;
    }

    private int getProgramIndex(){
		logger.info("Returning Program index");
		switch (ThreadLocalObject.getData().get("Program")){
            case "Basic":
                return 0;
            case "Premium":
                return 1;
            case "Standard":
                return 2;
        }
        logger.info("Program value is not set");
        return 7;
    }

	public PAQuotePage getOfferingPrice() {
		logger.info("Saving Offering price");
		seleniumCommands.waitForLoaderToDisappearFromPage();
        int index = this.getProgramIndex();
        ThreadLocalObject.getData().put("OfferingPrice", seleniumCommands.findElements(OFFERING_PRICE).get(index).getText());
		return this;
	}

	public PAQuotePage isStandardMexicoCoverageChecked() {
		logger.info("Checking if Mexico Coverage is checked");
		seleniumCommands.waitForLoaderToDisappearFromPage();
        int index = this.getProgramIndex();
        ThreadLocalObject.getData().put("MexicoCoverageChecked", seleniumCommands.findElement(By.cssSelector(MEXICO_COVARAGE_CHECKBOX+ index +"']")).getAttribute("aria-checked"));
		return this;
	}

	public PAQuotePage openPremiumQuoteView() {
		logger.info("Open Premium policy View");
		seleniumCommands.clickbyJS(PREMIUM_POLICY_TILE_CSS);
		return this;
	}

	public PAQuotePage openCustomQuoteView() {
		logger.info("Open Custom policy View");
		paCovPage.openCustomPolicyView();
		return this;
	}

	public QuoteSummary clickReferToUnderwriterAndConfirm() {
		logger.info("Clicking on refer to Underwriting button");
		seleniumCommands.click(REFER_TO_UNDERWRITER_BUTTON);
		seleniumCommands.click(REFER_TO_UNDERWRITER_BUTTON_CONFIRM);
		new AlertHandler().closeAlertOnly();
		new AlertHandler().closeAlert();
		seleniumCommands.waitForElementToBePresent(WITHDRAW_QUOTE_BUTTON_QUOTESUMMARYPAGE);
		return new QuoteSummary();
	}

	public PAQuotePage clickReferToUnderwriterAndCancel() {
		logger.info("Clicking on refer to Underwriting button");
		seleniumCommands.click(REFER_TO_UNDERWRITER_BUTTON);
		seleniumCommands.click(CANCEL_REFER_TO_UNDERWRITER_BUTTON);
		return new PAQuotePage();
	}

	public PAQuotePage buyBasePolicyWithMonthlyPayment() {
		logger.info("Buy Base policy with Monthly Payment");
		seleniumCommands.clickbyJS(BUY_BASIC_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage buyStandardPolicyWithMonthlyPayment() {
		logger.info("Buy standard policy with Monthly Payment");
		seleniumCommands.clickbyJS(BUY_STANDARD_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage buyPremiumPolicyWithMonthlyPayment() {
		seleniumCommands.clickbyJS(BUY_PREMIUM_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage buyPremiumPolicyWithAnnualPayment() {
		this.selectAnnualPaymentOption();
		seleniumCommands.clickbyJS(BUY_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage buyBasePolicyWithAnnualPayment() {
		logger.info("Buy Base policy with Monthly Payment");
		this.openBaseQuoteView();
		this.selectAnnualPaymentOption();
		seleniumCommands.clickbyJS(BUY_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage buyStandardPolicyWithAnnualPayment() {
		this.openStandardQuoteView();
		this.selectAnnualPaymentOption();
		seleniumCommands.clickbyJS(BUY_POLICY_BTN_CSS);
		return this;
	}

	public PAQuotePage emailPolicyQuote() {
		EMAIL_QUOTE_BUTTON.click();
		return this;
	}

	private PAQuotePage selectMonthlyPaymentOption() {
		logger.info("Select Monthly Payment option");
		seleniumCommands.clickbyJS(MONTHLY_PREMIUM_COST_RBTN_CSS);
		return this;
	}

	private PAQuotePage selectAnnualPaymentOption() {
		seleniumCommands.clickbyJS(FULL_PREMIUM_COST_RBTN_CSS);
		return this;
	}

	public PAQuotePage configureCustomQuote() {
		paCovPage.configureCustomQuote();
		return this;
	}

	// Get Methods

	public HashMap<String, String> getBaseCoverageDetails() {
		return paCovPage.getBasicCoverageDataFromUI();
	}

	public HashMap<String, String> getStandardCoverageDetails() {
		this.openStandardQuoteView();
		return paCovPage.getStandardOrPremiumCoverageDataFromUI();
	}

	public HashMap<String, String> getPremiumCoverageDetails() {
		this.openPremiumQuoteView();
		return paCovPage.getStandardOrPremiumCoverageDataFromUI();
	}

	// Validations method

	public Validation isQuotePageLoaded() {
		return new Validation(seleniumCommands.isElementPresent(QUOTE_OPTION_TILE_CSS));
	}

	public Validation validateOfferingPrice(String expectedPrice) {
		logger.info("Comparing expected Offering Price to actual UI value");
		seleniumCommands.waitForLoaderToDisappearFromPage();
        int index = this.getProgramIndex();
        return new Validation(expectedPrice, seleniumCommands.findElements(OFFERING_PRICE).get(index).getText());
	}

	public void validateStandardMexicoCoverageStatus(String expectedStatus) {
		logger.info("Comparing expected Mexico Coverage status to actual UI status");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        int index = this.getProgramIndex();
        new Validation(seleniumCommands.findElement(By.cssSelector(MEXICO_COVARAGE_CHECKBOX+index + "']")).getAttribute("aria-checked"),expectedStatus).shouldBeEqual("Standard Mexico Coverage status is incorrect");
	}

	public Validation validatePAQuotePageBanner() throws Exception {

		QuoteInfoBar infoBar = new QuoteInfoBar();
		String jsondata = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				new QuoteInfoBar().getSubmissionNumber());
		System.out.println(ParseQuoteData.getVehicelDetailsFromBackEnd(jsondata));
		System.out.println(ParseQuoteData.getDriverDetailsFromBackEnd(jsondata));
		System.out.println(infoBar.getAddress());
		System.out.println(infoBar.getDriverList());
		System.out.println(infoBar.getVehicleList());
		return new Validation(true);
	}

	public Validation validatePAQuotePageLayout() throws Exception {
		this.validateQuoteOptionsLayout();
		new Validation(seleniumCommands.isElementPresent(MONTHLY_PREMIUM_COST_RBTN_CSS))
				.shouldBeTrue("Monthly payment radio btn is not available");
		new Validation(seleniumCommands.isElementPresent(FULL_PREMIUM_COST_RBTN_CSS))
				.shouldBeTrue("Full payment radio btn is not available");
		new Validation(seleniumCommands.findElement(By.id(MONTHLY_RDBTN_ID)).isSelected())
				.shouldBeTrue("Monthly payment radio btn is not selected");
		new Validation(seleniumCommands.isElementPresent(BASIC_FULL_PREMIUM_COST_LBL_CSS))
				.shouldBeTrue("Full payment radio btn is not available");
		new Validation(seleniumCommands.getTextAtLocator(BUY_POLICY_BTN_CSS), DataConstant.BUY_NOW_BUTTON_TXT)
		.shouldBeEqual("Buy Now buttton text is not matched");
		new Validation(seleniumCommands
				.getAttributeValueAtLocator(By.xpath(QUOTE_TILE_COUNT + "[1]"), "class")
				.contains("active")).shouldBeTrue("Base quote tile is not selected by default");
		return new Validation(true);
	}

	public Validation validatePAQuotePageBanner(String jsondata) throws Exception {
		// TODO for multiple Vehicle, Driver 
		String browser = ThreadLocalObject.getBrowserName();
			QuoteInfoBar infoBar = new QuoteInfoBar();
			String vehicleList = ParseQuoteData.getVehicelDetailsFromBackEnd(jsondata).get("VehicleDisplayName") + " ("
					+ data.get("LicensePlate") + "/" + data.get("VehicleStateValue") + ")";
			String drivername = data.get("DriverFirstName") + " " + data.get("DriverLastName");
			String address = data.get("AddressLine1") + "," + data.get("City") + ", " + data.get("StateValue") + " "
					+ data.get("ZipCode");
			new Validation(infoBar.getVehicleList().get(0), vehicleList)
					.shouldBeEqual("Vehicle details are not matched");
			new Validation(infoBar.getDriverList().get(0), drivername).shouldBeEqual("Driver name is not matched");
			new Validation(infoBar.getAddress(), address).shouldBeEqual("Driver name is not matched");
		return new Validation(true);
	}

	public Validation areBaseCoverageDetailsMatchingBackEnd() throws Exception {
		return MapCompare.compareMap(paCovPage.getBasicCoverageDataFromUI(),
				ParseQuoteData.getPABaseCoverageDataFromBackEnd(DataFetch.getQuoteData(
						ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));

	}

	public Validation areStandardCoverageDetailsMatchingBackEnd() throws Exception {
		this.openStandardQuoteView();
		return MapCompare.compareMap(paCovPage.getStandardOrPremiumCoverageDataFromUI(),
				ParseQuoteData.getPAStandardCoverageDataFromBackEnd(DataFetch.getQuoteData(
						ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));

	}

	public Validation arePremiumCoverageDetailsMatchingBackEnd() throws Exception {
		this.openPremiumQuoteView();
		return MapCompare.compareMap(paCovPage.getPremiumCoverageDataFromUI(),
				ParseQuoteData.getPAPremiumCoverageDataFromBackEnd(DataFetch.getQuoteData(
						ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
	}

	public Validation areBaseCoverageDetailsMatchingBackEnd(String jsonData) throws Exception {
		return MapCompare.compareMap(paCovPage.getBasicCoverageDataFromUI(),
				ParseQuoteData.getPABaseCoverageDataFromBackEnd(jsonData));

	}

	public Validation areStandardCoverageDetailsMatchingBackEnd(String jsonData) throws Exception {
		this.openStandardQuoteView();
		return MapCompare.compareMap(paCovPage.getStandardOrPremiumCoverageDataFromUI(),
				ParseQuoteData.getPAStandardCoverageDataFromBackEnd(jsonData));

	}

	public Validation arePremiumCoverageDetailsMatchingBackEnd(String jsonData) throws Exception {
		this.openPremiumQuoteView();
		return MapCompare.compareMap(paCovPage.getPremiumCoverageDataFromUI(),
				ParseQuoteData.getPAPremiumCoverageDataFromBackEnd(jsonData));
	}

	public Validation isEmailQuoteModalDisplayed() throws Exception {
		seleniumCommands.waitForElementToBeVisible(EMAIL_QUOTE_MODAL);
		new Validation(EMAIL_QUOTE_MODAL.isDisplayed());
		String headerText = EMAIL_QUOTE_MODAL.findElement(By.cssSelector(".gw-modal-header")).getText();
		new Validation(headerText, data.get("headerText")).shouldBeEqual();
		return new Validation(true);
	}

	public Validation isButtonBuyNowDisabled(){
		seleniumCommands.waitForElementToBeVisible(BUY_BASIC_POLICY_BTN_CSS);
		new Validation(seleniumCommands.isElementPresent(BUY_BASIC_POLICY_BTN_DISABLED_CSS), true)
			.shouldBeEqual("Buy Now button is not disabled for base policy.");
		new Validation(seleniumCommands.isElementPresent(BUY_STANDARD_POLICY_BTN_DISABLED_CSS), true)
			.shouldBeEqual("Buy Now button is not disabled for standard policy.");
		new Validation(seleniumCommands.isElementPresent(BUY_PREMIUM_POLICY_BTN_DISABLED_CSS), true)
			.shouldBeEqual("Buy Now button is not disabled for premium policy.");
		return new Validation(true);
	}

	public Validation isInformationMessageCorrectlyPresented(){
		seleniumCommands.waitForElementToBeVisible(INFO_MESSAGE);
		new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TITLE), DataConstant.UNDERWRITING_MESSAGE_TITLE_TEXT_2)
				.shouldBeEqual("Information message doesn't match to expected.");
		return new Validation(true);
	}

	public Validation validateQuoteOptionsLayout() {
		new Validation(seleniumCommands.findElements(By.cssSelector(QUOTE_TILE_COUNT)).size() == 3)
				.shouldBeTrue("Quote tiles are not correct in number");
		new Validation(seleniumCommands.getTextAtLocator(QUOTE_OPTION_BASIC_LBL_CSS), DataConstant.BASIC_QUOTE_LABEL).shouldBeEqual("Base quote label is incorrect");
		new Validation(seleniumCommands.getTextAtLocator(QUOTE_OPTION_STANDARD_LBL_CSS), DataConstant.STANDARD_QUOTE_LABEL).shouldBeEqual("Standard quote label is incorrect");
		new Validation(seleniumCommands.getTextAtLocator(QUOTE_OPTION_PREMIUM_LBL_CSS), DataConstant.PREMIUM_QUOTE_LABEL).shouldBeEqual("Premium quote label is incorrect");
		return new Validation(true);
	}

	public Validation validateQuoteOptionsAndBuyNowBtnAndInfoMessage(){
		this.validateQuoteOptionsLayout();
		this.isInformationMessageCorrectlyPresented();
		this.isButtonBuyNowDisabled();
		return new Validation(true);
	}

	public AccountSummaryPage goToAccountPage(){
		seleniumCommands.logInfo("Clicking Account link to cancel quote and to get to Account page");
		seleniumCommands.waitForElementToBeClickable(ACCOUNT_SUMMARY_LINK);
		seleniumCommands.clickbyJS(ACCOUNT_SUMMARY_LINK);
		new AlertHandler().closeAlert();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new AccountSummaryPage();
	}

    public String getStatusFromBackend(String jsonData) {
		seleniumCommands.logInfo("Getting Program price from backend");
		JsonPath jsonpath = new JsonPath(jsonData);
        String branchCode= "";
        int index = getProgramIndex();
        switch (index){
            case 0:
                branchCode = "PABasic";
                break;
            case 1:
                branchCode = "PAPremium";
                break;
            case 2:
                branchCode = "StandardProgram";
                break;
        }
        for (int i=0; i<3; i++){
            if (jsonpath.getString("quoteData.offeredQuotes"+"["+ i + "]" + ".branchCode" ).equals(branchCode) ){
                return jsonpath.getString("quoteData.offeredQuotes"+"["+ i + "]" + ".status" );
            }
        }
        return null;
    }

    public void validateBuyNowAndResetButtons(){
		seleniumCommands.logInfo("Validating Reset and Buy Now buttons");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        for (int i=0; i<3; i++){
            if (i==this.getProgramIndex())
                new Validation(seleniumCommands.isElementPresent(BUY_STANDARD_POLICY_BTN_CSS)).shouldBeTrue("Recalculate button is not present.");
            else
                new Validation(seleniumCommands.isElementPresent(BUY_NOW)).shouldBeTrue("Buy Now button is not present");
        }
    }

    public String getProgramPriceFromBackend(String jsonData, Boolean payFull) {
		seleniumCommands.logInfo("Getting Program price from backend");
        JsonPath jsonpath = new JsonPath(jsonData);
        String branchCode= "";
        int index = getProgramIndex();
        switch (index){
            case 0:
                branchCode = "PABasic";
                break;
            case 1:
                branchCode = "PAPremium";
                break;
            case 2:
                branchCode = "StandardProgram";
                break;
        }
        for (int i=0; i<3; i++){
            if (jsonpath.getString("quoteData.offeredQuotes"+"["+ i + "]" + ".branchCode" ).equals(branchCode) ){
				if (payFull) {
                	return jsonpath.getString("quoteData.offeredQuotes"+"["+ i + "]" + ".premium.total.amount" );
				}
					return jsonpath.getString("quoteData.offeredQuotes"+"["+ i + "]" + ".premium.monthlyPremium.amount" );}
        }
        return null;
		}
		
		public Validation validationUnderwritingMessage() {
			seleniumCommands.waitForLoaderToDisappearFromPage();
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TITLE), DataConstant.UNDERWRITING_MESSAGE_TITLE_TEXT_2).shouldBeEqual("Underwriting message is incorrect");
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TEXT), DataConstant.UNDERWRITING_MESSAGE_LINE1_TEXT).shouldBeEqual("Underwriting message is incorrect");
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LIST_LINE1), DataConstant.UNDERWRITING_MESSAGE_LIST_LINE1).shouldBeEqual("Underwriting message line 1 is incorrect");
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LIST_LINE1), DataConstant.UNDERWRITING_MESSAGE_LIST_LINE1).shouldBeEqual("Underwriting message line 2 is incorrect");
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LIST_LINE1), DataConstant.UNDERWRITING_MESSAGE_LIST_LINE1).shouldBeEqual("Underwriting message line 3 is incorrect");
			new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LIST_LINE1), DataConstant.UNDERWRITING_MESSAGE_LIST_LINE1).shouldBeEqual("Underwriting message line 4 is incorrect");

			new Validation(seleniumCommands.isElementPresent(WITHDRAW_QUOTE_BUTTON)).shouldBeTrue("Edit quote button is not presented");
			new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_BUTTON)).shouldBeTrue("Refer to Underwriter button is not presented");

			return new Validation(true);
	}
}
