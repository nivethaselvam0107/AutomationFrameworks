package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.PoliciesLanding;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.data.PolicyData;
import com.guidewire.data.QuoteScheduledPropertyItem;

public class PolicyConfirmationPage {

	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HOCoverageDetailsPage covDetails = new HOCoverageDetailsPage();

	@FindBy(css = "[class='gw-page gw-box gw-quote-confirmation ng-binding ng-scope']")
	WebElement POLICY_CONF_PAGE_CSS;

	@FindBy(xpath = "//h1")
	WebElement POLICY_CONF_MSG_CSS;

	@FindBy(xpath = "(//*[@class='gw-control-group'][1]/div[2])[1]")
	WebElement ACCOUNT_NUMBER_XPATH;

	@FindBy(xpath = "//*[@class='gw-control-group'][1]/div[2]/a")
	WebElement ACCOUNT_LINK_XPATH;

	@FindBy(css = "h1[class='gw-titles-title ng-isolate-scope gw-titles-title_offset']")
	WebElement ACCOUNT_NUMBER_DETAIL_PAGE_CSS;

	@FindBy(css = "[class='gw-policy-summaries gw-table ng-scope']")
	WebElement POLICY_TABLE_CSS;

	@FindBy(css = ".gw-policy-detail")
	WebElement POLICY_NUMBER_DETAIL_PAGE_CSS;

	@FindBy(css = ".gw-policy-detail button")
	WebElement POLICY_ACTIONS_DETAIL_CSS;

	@FindBy(xpath = "(//*[@class='gw-control-group'][2]/div[2])[1]")
	WebElement POLICY_NUMBER_XPATH;

	@FindBy(xpath = "//*[@class='gw-control-group'][2]/div[2]/a")
	WebElement POLICY_LINK_XPATH;

	@FindBy(xpath = "(//*[@class='gw-control-group'][3]/div[2])[1]")
	WebElement POLICY_START_DATE_XPATH;

	@FindBy(xpath = "(//*[@class='gw-control-group'][4]/div[2])[1]")
	WebElement POLICY_PERIOD_XPATH;

	@FindBy(xpath = "//*[@class='gw-control-group'][5]/div[2]")
	WebElement POLICY_TOTAL_AMT_XPATH;

	@FindBy(xpath = "//*[@class='gw-control-group'][6]/div[2]")
	WebElement POLICY_PLAN_NAME_XPATH;

	@FindBy(xpath = "//*[@class='gw-control-group'][7]/div[2]")
	WebElement POLICY_CURR_PAYMENT_XPATH;

	@FindBy(css = "span[is-open='status.vehicleOpen']")
	WebElement VEHICLE_SEC_EXPAND_BTN_CSS;

	@FindBy(css = "span[is-open='status.driverOpen']")
	WebElement DRIVER_SEC_EXPAND_BTN_CSS;

	@FindBy(css = "span[is-open='status.premiumOpen']")
	WebElement COV_DETAILS_EXPAND_BTN_CSS;

	@FindBy(css = "span[is-open='status.infoOpen']")
	WebElement CONTACT_INFO_EXPAND_BTN_CSS;

	@FindBy(css = "[is-open='status.vehicleOpen'] div[class='panel-body'] table")
	WebElement VEHICLE_TABLE_CSS;

	@FindBy(css = "[is-open='status.premiumOpen'] div[class='gw-panel-body gw-panel-body_'] table ")
	WebElement COVERAGE_TABLE_CSS;

	@FindBy(css = "[is-open='status.driverOpen']")
	WebElement DRIVER_SEC_CSS;

	@FindBy(xpath = "(//*[@is-open='status.infoOpen']//*[@class='gw-control-group']/div[2])[1]")
	WebElement FIRST_NAME_XPATH;

	@FindBy(xpath = "(//*[@is-open='status.infoOpen']//*[@class='gw-control-group']/div[2])[2]")
	WebElement LAST_NAME_XPATH;

	@FindBy(xpath = "(//*[@is-open='status.infoOpen']//*[@class='gw-control-group']/div[2])[3]")
	WebElement EMAIL_XPATH;

	@FindBy(xpath = "(//*[@is-open='status.infoOpen']//*[@class='gw-control-group']/div[2])[4]")
	WebElement ADDRESS_XPATH;

	// HO Your Info Locators
	@FindBy(xpath = "(//div[@gw-qnb-confirmation]//div[@gw-ho-confirmation]//div[@class='gw-control-group'][1]//div[2])[1]")
	WebElement HO_FIRST_NAME_XPATH;

	@FindBy(xpath = "(//*[@gw-ho-confirmation]//div[@class='gw-control-group'][2]//div[2])[1]")
	WebElement HO_LAST_NAME_XPATH;

	@FindBy(xpath = "(//*[@gw-ho-confirmation]//div[@class='gw-control-group'][3]//div[2])[1]")
	WebElement HO_EMAIL_XPATH;

	@FindBy(xpath = "(//*[@gw-ho-confirmation]//div[@class='gw-controls ng-binding'])[4]")
	WebElement HO_ADDRESS_XPATH;
	
	@FindBy(css = "[is-open='status.vehicleOpen'] div[class*=gw-in]")
	WebElement EXPANDED_VEHICLE_SEC_CSS;
	
	@FindBy(css = "[is-open='status.driverOpen'] div[class*=gw-in]")
	WebElement EXPANDED_DRIVER_SEC_CSS;
	
	@FindBy(css = "[is-open='status.vehicleOpen']")
	WebElement VEHICLE_SEC_CSS;
	
	@FindBy(css = "[is-open='status.premiumOpen']")
	WebElement COVERAGE_SEC_CSS;
	
	@FindBy(css = "[is-open='status.infoOpen']")
	WebElement CONTACT_DETAILS_SEC_CSS;
	
	String UNEXPANDED_CLASS_VALUE = "gw-panel ng-scope ng-isolate-scope  gw-panel_";
	
	@FindBy(xpath = "//div[@class[contains(.,'gw-facebook-sharing')]][@role='button']")
	WebElement FB_SHARE_XPATH;

	@FindBy(css = "[class='gw-panel-title gw-accordion-toggle gw-panel-title_default']")
	WebElement EXPAND_COVERAGE_CSS;

	@FindBy(css = ".gw-comprop-icon_pin-icon-primary")
	WebElement EXPAND_LOCATION_CVG_CSS;

	@FindBy(css = "[class='gw-comprop-icon gw-comprop-building-header__building-icon']")
	WebElement EXPAND_BUILDING_CVG_CSS;

	@FindBy(xpath = "//*[@ng-repeat='coverage in _coverages track by coverage.id'][1]//div[@ng-repeat='term in coverage.terms'][3]/div[2]")
	WebElement LIMIT_CVG_CSS;

	String PRIVATE_PROPERTY_DESCRIPTION = "//div[@ng-if='item()']";

	String SCHEDULED_BLOCKS = "//div[@ng-repeat='schedule in schedules track by schedule.getPattern()']";
	
	//Scheduled Item
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(1) td:nth-of-type(1), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(1)")
	WebElement SCH_PROPERTY_TYPE_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(1) td:nth-of-type(2), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(2)")
	WebElement SCH_PROPERTY_DESC_OR_LIMIT_VALUE_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(1) td:nth-of-type(3), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(3)")
	WebElement SCH_PROPERTY_VALUE_OR_DEDUCT_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(1) td:nth-of-type(4), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(4)")
	WebElement SCH_PROPERTY_VAL_METHOD_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(1)")
	WebElement SPECIAL_SCH_PROPERTY_TYPE_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(2)")
	WebElement SPECIAL_SCH_PROPERTY_DESC_OR_LIMIT_VALUE_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(2) td:nth-of-type(3)")
	WebElement SPECIAL_SCH_PROPERTY_VALUE_OR_DEDUCT_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) table[class*='actual'] tr:nth-of-type(3) td:nth-of-type(1), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) tr:nth-of-type(2)  td:nth-of-type(1), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) td:nth-of-type(1)")
	WebElement OTH_STRUC_ON_RESIDENCE_PREMISE_PROPERTY_DESC_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) table[class*='actual'] tr:nth-of-type(3) td:nth-of-type(2), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) tr:nth-of-type(2)  td:nth-of-type(2), [ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(3) td:nth-of-type(2)")
	WebElement OTH_STRUC_ON_RESIDENCE_PREMISE_PROPERTY_LIMIT_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(4) td:nth-of-type(1)")
	WebElement PERSONAL_PROPERTY_AT_OTHER_RESIDENCE_LOCATION_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(4) td:nth-of-type(2)")
	WebElement PERSONAL_PROPERTY_AT_OTHER_RESIDENCE_LIMIT_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(5) td:nth-of-type(1)")
	WebElement SPECIFIC_STRUCTURE_AWAY_RESIDENCE_LOCATION_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(5) td:nth-of-type(2)")
	WebElement SPECIFIC_STRUCTURE_AWAY_RESIDENCE_DESC_CSS;
	
	@FindBy(css = "[ng-repeat*='schedule in schedules track by schedule.getPattern()']:nth-of-type(5) td:nth-of-type(3)")
	WebElement SPECIFIC_STRUCTURE_AWAY_RESIDENCE_LIMIT_CSS;
	
	private static final By CONTACT_INFO_CSS = By.cssSelector("div[gw-qnb-confirmation] div[class='gw-control-group'] div:nth-of-type(2)");

	// HO Coverage Locators

	public PolicyConfirmationPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public PolicyConfirmationPage(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public FbPage shareOnFacebook() {

		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeClickable(FB_SHARE_XPATH);
		String mainWindowHwnd = seleniumCommands.getAllWindowOpened().get(0);
		seleniumCommands.clickbyJS(FB_SHARE_XPATH);

		return new FbPage(mainWindowHwnd);
	}

	private String getCoverageStartDate() {
		return seleniumCommands.getTextAtLocator(POLICY_START_DATE_XPATH);
	}

	private String getConfirmationMessage() {
		return POLICY_CONF_MSG_CSS.getText();
	}

	private String getAccountNumber() {
		return seleniumCommands.getTextAtLocator(ACCOUNT_NUMBER_XPATH);
	}

	public String getPolicyNumber() {
		return seleniumCommands.getTextAtLocator(POLICY_NUMBER_XPATH);
	}

	private String getPolicyEffectiveDate() {
		return seleniumCommands.getTextAtLocator(POLICY_START_DATE_XPATH);
	}

	private String getPolicyPeriod() {
		return seleniumCommands.getTextAtLocator(POLICY_PERIOD_XPATH);
	}

	private String getPolicyTotalAmount() {
		return seleniumCommands.getTextAtLocator(POLICY_TOTAL_AMT_XPATH);
	}

	private String getPolicyPlanName() {
		return seleniumCommands.getTextAtLocator(POLICY_PLAN_NAME_XPATH);
	}

	private String getCurrentPayment() {
		return seleniumCommands.getTextAtLocator(POLICY_CURR_PAYMENT_XPATH);
	}

	private String getFirstName() {
		if(data.get("PolicyType").equals("HomeOwner"))
		{

			return seleniumCommands.findElements(CONTACT_INFO_CSS).get(0).getText();
		}
		else
		{
			return FIRST_NAME_XPATH.getText();
		}

	}

	private String getLastName() {
		if(data.get("PolicyType").equals("HomeOwner"))
		{
			return  seleniumCommands.findElements(CONTACT_INFO_CSS).get(1).getText();
		}
		else
		{
			return LAST_NAME_XPATH.getText();
		}
	}

	public PoliciesLanding goToPolicies() {
		return new NavBar().goToPoliciesLanding();
	}

	private String getEmail() {
		if(data.get("PolicyType").equals("HomeOwner"))
		{
			return  seleniumCommands.findElements(CONTACT_INFO_CSS).get(2).getText();
		}
		else
		{
			return EMAIL_XPATH.getText();
		}
	}

	private String getAddress() {
		if(data.get("PolicyType").equals("HomeOwner"))
		{
			return  seleniumCommands.findElements(CONTACT_INFO_CSS).get(3).getText().replaceAll("[\\t\\n\\r]"," ");
		}
		else
		{
			return ADDRESS_XPATH.getText();
		}
	}

	public HashMap<String, String> getPolicySummary() {
		seleniumCommands.logInfo("Getting UI policy smmary data");
		HashMap<String, String> contactMap = new HashMap<>();
		contactMap.put("ACCOUNT_NUMBER", getAccountNumber());
		contactMap.put("POLICY_NUMBER", getPolicyNumber());
		contactMap.put("POLICY_PERIOD", getPolicyPeriod().replace(" -","").replace(" ", ""));
		contactMap.put("POLICY_TOTAL_AMOUNT", getPolicyTotalAmount());
		contactMap.put("PAYMENT_PLAN_NAME", getPolicyPlanName());
		contactMap.put("POLICY_CURRENT_PAYMENT", getCurrentPayment());
		contactMap.put("COV_START_DATE", getPolicyEffectiveDate());
		return contactMap;
	}

	public PolicyConfirmationPage savePolicyNumber(){
		data.put("POLICY_NUMBER", getPolicyNumber());
		return this;
	}

	public HashMap<String, String> getPAContactDetails() {
		CONTACT_INFO_EXPAND_BTN_CSS.click();
		seleniumCommands.waitForElementToBeVisible(FIRST_NAME_XPATH);
		HashMap<String, String> contactMap = new HashMap<>();
		contactMap.put("FirstName", getFirstName());
		contactMap.put("LastName", getLastName());
		contactMap.put("Email", getEmail());
		contactMap.put("AddressDisplayName", getAddress());
		return contactMap;
	}

	public HashMap<String, String> getHOContactDetails() {
		HashMap<String, String> contactMap = new HashMap<>();
		contactMap.put("FirstName", getFirstName());
		contactMap.put("LastName", getLastName());
		contactMap.put("Email", getEmail());
		contactMap.put("AddressDisplayName", getAddress());
		return contactMap;
	}

	public HashMap<String, String> getCoverageData() {
		COV_DETAILS_EXPAND_BTN_CSS.click();
		seleniumCommands.waitForElementToBeVisible(COVERAGE_TABLE_CSS);
		HashMap<String, String> covData = new HashMap<>();
		int iteration = COVERAGE_TABLE_CSS.findElements(By.xpath("./tbody/tr")).size();
		HashMap<String, String> hm = new HashMap<>();
		for (int i = 1; i <= iteration; i++) {
			String covName = COVERAGE_TABLE_CSS.findElement(By.xpath("./tbody/tr[" + i + "]/td[1]")).getText();
			String covPaymentData = COVERAGE_TABLE_CSS.findElement(By.xpath("./tbody/tr[" + i + "]/td[2]")).getText();
				switch(covName)
				{
				case "Mexico Coverage - Limited":
					covData.put("Mexico_Cov_Ltd_LBL", covName);
					break;
					
				case "Uninsured Motorist - Bodily Injury":
					covData.put("UninsuredMotoristBI_LBL", covName);
					if(covPaymentData!=null && !covPaymentData.isEmpty())
					{
						covData.put("UninsuredMotoristBILimit", covPaymentData);
					}
					break;
				
				case "Liability - Bodily Injury and Property Damage":
					covData.put("LiabilityBodilyPropDamage_LBL", covName);
					if(covPaymentData!=null && !covPaymentData.isEmpty())
					{
						covData.put("LiabilityBodilyPropDamage", covPaymentData);
					}
					break;
					
				case "Medical Payments":
					covData.put("MedicalPayment_LBL", covName);
					if(covPaymentData!=null && !covPaymentData.isEmpty())
					{
						covData.put("MedicalPayment", covPaymentData);
					}
					break;
			}
		}
		return covData;
	}

	public HashMap<String, String> getVehiclesTableData() {
		logger.info("Validating Vehicle data from confirmation page");
		seleniumCommands.clickbyJS(VEHICLE_SEC_EXPAND_BTN_CSS);
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeVisible(EXPANDED_VEHICLE_SEC_CSS);
		HashMap<String, String> vehicleData = new HashMap<>();
		List<WebElement> vehicleRow = seleniumCommands.findElements(By.cssSelector("[is-open='status.vehicleOpen'] td"));
		vehicleData.put("Make", vehicleRow.get(0).getText());
		vehicleData.put("Model", vehicleRow.get(1).getText());
		vehicleData.put("LicensePlate", vehicleRow.get(2).getText());
		return vehicleData;
	}

	public HashMap<String, String> getDriverTableData() {
		logger.info("Validating driver data from confirmation page");
		seleniumCommands.clickbyJS(DRIVER_SEC_EXPAND_BTN_CSS);
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeVisible(EXPANDED_DRIVER_SEC_CSS);
		HashMap<String, String> driverDetails = new HashMap<>();
		List<WebElement> driver = seleniumCommands.findElements(By.cssSelector("div[is-open='status.driverOpen'] div[class='gw-control-group'] [class='gw-controls ng-binding']"));
		driverDetails.put("DriverLicenseNum", driver.get(0).getText());
		driverDetails.put("DriverLicenseStateValue", driver.get(1).getText());
		driverDetails.put("FirstYearLicensed", driver.get(2).getText());
		return driverDetails;
	}
	
	public HashMap<String, String> getScheduledPersonalPropertyData() {
		logger.info("Validating scheduled personal property data from confirmation page");
		HashMap<String, String> schPropData = new HashMap<>();
		if(ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.QNB.toString())) {
			schPropData.put("SchedulePropertyType", seleniumCommands.getTextAtLocator(SCH_PROPERTY_TYPE_CSS));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(SCH_PROPERTY_DESC_OR_LIMIT_VALUE_CSS));
			schPropData.put("SchedulePropertyDeductible", seleniumCommands.getTextAtLocator(SCH_PROPERTY_VALUE_OR_DEDUCT_CSS));
			schPropData.put("SchedulePropertyValuationMethod", seleniumCommands.getTextAtLocator(SCH_PROPERTY_VAL_METHOD_CSS));
		} else {
			schPropData.put("SchedulePropertyType", seleniumCommands.getTextAtLocator(SCH_PROPERTY_TYPE_CSS));
			schPropData.put("SchedulePropertyDesc", seleniumCommands.getTextAtLocator(SCH_PROPERTY_DESC_OR_LIMIT_VALUE_CSS));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(SCH_PROPERTY_VALUE_OR_DEDUCT_CSS));
		}
		return schPropData;
	}
	
	public HashMap<String, String> getSpecialScheduledPersonalPropertyData() {
		logger.info("Validating scheduled personal property data from confirmation page");
		HashMap<String, String> schPropData = new HashMap<>();
			schPropData.put("SchedulePropertyType", seleniumCommands.getTextAtLocator(SPECIAL_SCH_PROPERTY_TYPE_CSS));
			schPropData.put("SchedulePropertyDesc", seleniumCommands.getTextAtLocator(SPECIAL_SCH_PROPERTY_DESC_OR_LIMIT_VALUE_CSS));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(SPECIAL_SCH_PROPERTY_VALUE_OR_DEDUCT_CSS));
		return schPropData;
	}
	
	public HashMap<String, String> getOtherStructureOnResidencePremisePropertyData() {
		logger.info("Validating Other Structures On The Residence Premises property data from confirmation page");
		HashMap<String, String> schPropData = new HashMap<>();
			schPropData.put("SchedulePropertyDesc", seleniumCommands.getTextAtLocator(OTH_STRUC_ON_RESIDENCE_PREMISE_PROPERTY_DESC_CSS));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(OTH_STRUC_ON_RESIDENCE_PREMISE_PROPERTY_LIMIT_CSS));
		return schPropData;
	}
	
	public HashMap<String, String> getPersonalPropertyOnOtherResidenceData() {
		logger.info("Validating Personal Property At Other Residences property data from confirmation page");
		HashMap<String, String> schPropData = new HashMap<>();
			schPropData.put("SchedulePropertyLocation", seleniumCommands.getTextAtLocator(PERSONAL_PROPERTY_AT_OTHER_RESIDENCE_LOCATION_CSS).replace("\n", " "));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(PERSONAL_PROPERTY_AT_OTHER_RESIDENCE_LIMIT_CSS));
			schPropData.put("SchedulePropertyLocationNonSpecific", data.get("SchedulePropertyLocationNonSpecific"));
		return schPropData;
	}
	
	public HashMap<String, String> getSpecificStructuresAwayFromTheResidencePremisesData() {
		logger.info("Validating Specific Structures Away From The Residence Premises property data from confirmation page");
		HashMap<String, String> schPropData = new HashMap<>();
			schPropData.put("SchedulePropertyLocation", seleniumCommands.getTextAtLocator(SPECIFIC_STRUCTURE_AWAY_RESIDENCE_LOCATION_CSS).replace("\n", " "));
			schPropData.put("SchedulePropertyLimit", seleniumCommands.getTextAtLocator(SPECIFIC_STRUCTURE_AWAY_RESIDENCE_LIMIT_CSS));
			schPropData.put("SchedulePropertyLocationNonSpecific", data.get("SchedulePropertyLocationNonSpecific"));
			schPropData.put("SchedulePropertyLocationDescription", seleniumCommands.getTextAtLocator(SPECIFIC_STRUCTURE_AWAY_RESIDENCE_DESC_CSS));
		return schPropData;
	}

	public HashMap<String,String> getPolicyCoverageDetails()
	{
		if(System.getProperty("platform").equalsIgnoreCase("granite")) {
			return covDetails.getCoverageDataFromUI_Granite();
		}else
		return covDetails.getCoverageDataFromUI();
	}

	public AccountSummary goToAccountDetailPage(){
		logger.info("Navigating to Account Details page from Confirmation page");
		seleniumCommands.clickbyJS(ACCOUNT_LINK_XPATH);
		return new AccountSummary();
	}

	public AccountSummary goToPolicyPage(){
		logger.info("Navigating to Policy Details page from Confirmation page");
		seleniumCommands.clickbyJS(ACCOUNT_LINK_XPATH);
		return new AccountSummary();
	}

	public PolicyConfirmationPage goToPolicyDetailPage(){
		logger.info("Navigating to Policy Details page from Confirmation page");
		seleniumCommands.clickbyJS(POLICY_LINK_XPATH);
		return this;
	}

	public PolicyConfirmationPage expandCoverages() {
		seleniumCommands.clickbyJS(EXPAND_COVERAGE_CSS);
		seleniumCommands.waitForElementToBePresent(EXPAND_LOCATION_CVG_CSS);
		return this;
	}

	public PolicyConfirmationPage expandLocation() {
		seleniumCommands.clickbyJS(EXPAND_LOCATION_CVG_CSS);
		seleniumCommands.waitForElementToBePresent(EXPAND_BUILDING_CVG_CSS);
		return this;
	}

	public PolicyConfirmationPage expandBuilding() {
		seleniumCommands.clickbyJS(EXPAND_BUILDING_CVG_CSS);
		seleniumCommands.waitForElementToBePresent(LIMIT_CVG_CSS);
		return this;
	}

	
	// Validation

	public Validation isCoverageDateEqualTo(String date) {
		return new Validation(getCoverageStartDate(), date);
	}

	public Validation isAccountDetailPageDisplayed(){
		seleniumCommands.waitForElementToBeVisible(POLICY_TABLE_CSS);
		logger.info("Validating account detail page");
		return new Validation(ACCOUNT_NUMBER_DETAIL_PAGE_CSS.getText().contains(data.get(PolicyData.ACCOUNT_NUMBER.toString())));
	}

	public Validation isPolicyDetailPageDisplayed(String policyNumber){
		seleniumCommands.waitForElementToBeVisible(POLICY_ACTIONS_DETAIL_CSS);
		logger.info("Validating policy detail page");
		return new Validation(POLICY_NUMBER_DETAIL_PAGE_CSS.getText().contains(policyNumber));
	}

	public Validation isCoverageUpdatedOnConfirmationPage(String limitCoverageValue){
		seleniumCommands.waitForElementToBeVisible(LIMIT_CVG_CSS);
		logger.info("Validating coverage change");
		return new Validation(LIMIT_CVG_CSS.getText().contains(limitCoverageValue));
	}

	public Validation isPolicyConfirmationPageDisplayed() {
		logger.info("Validating if confirmation page is opened");
		return new Validation(ACCOUNT_NUMBER_XPATH.isDisplayed());
	}

	public Validation isPolicyPlanNameEqualTo() {
		logger.info("Validating Policy Plan Name");
		return new Validation(getPolicyPlanName(), data.get("PaymentPlan"));
	}

	public Validation isINowPolicyPlanNameEqualTo() {
		logger.info("Validating Policy Plan Name");
		return new Validation(getPolicyPlanName(), data.get("INOW_PaymentPlan"));
	}

	public Validation isINowPolicyPlanNameEqualTo(String paymentPlan) {
		logger.info("Validating Policy Plan Name");
		return new Validation(getPolicyPlanName(), paymentPlan);
	}

	public Validation isPolicyNumberEqualTo(String jsondata) {
		seleniumCommands.logInfo("Validating Policy Number");
		seleniumCommands.logInfo("JSON DATA -" + jsondata);
		return new Validation(getPolicyNumber(), ParseQuoteData.getPolicyNumber(jsondata));
	}

	public Validation isPolicyNumberEqualTo() {
		return new Validation(getPolicyNumber(), ParseQuoteData.getPolicyNumber(DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
	}

	public Validation isPolicyOfferingNameEqualTo(String offeringName, String offeringFromBackEnd) {
		return new Validation(offeringFromBackEnd, offeringName);
	}
	
	public Validation isPolicyPaymentPlanNameEqualTo(String jsonData) throws Exception {
		return new Validation(getPolicySummary().get("PAYMENT_PLAN_NAME"), ParseQuoteData.getPolicySummaryDataFromBackEnd(jsonData).get("PAYMENT_PLAN_NAME"));
	}

	public Validation validatePAPolicySummaryDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating Policy Summary Details");
		return MapCompare.compareMap(this.getPolicySummary(),	ParseQuoteData.getPABaseCoverageDataFromBackEnd(jsonQuotedata));
	}
	
	public Validation validateHOPolicySummaryDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating Policy Summary Details");
		return MapCompare.compareMap(this.getPolicySummary(),	ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonQuotedata));
	}
	
	
	public Validation arePolicyDetailsSectionsCollapsedByDefault() throws Exception {
		logger.info("Validating policy confirmation page sections are collapsed ");
		new Validation(seleniumCommands.getAttributeValueAtLocator(VEHICLE_SEC_CSS, "class"), UNEXPANDED_CLASS_VALUE).shouldBeEqual("Vehicle section is not collapsed by default");
		new Validation(seleniumCommands.getAttributeValueAtLocator(DRIVER_SEC_CSS, "class"), UNEXPANDED_CLASS_VALUE).shouldBeEqual("Driver section is not collapsed by default");
		new Validation(seleniumCommands.getAttributeValueAtLocator(CONTACT_DETAILS_SEC_CSS, "class"), UNEXPANDED_CLASS_VALUE).shouldBeEqual("Contact details section is not collapsed by default");
		new Validation(seleniumCommands.getAttributeValueAtLocator(COVERAGE_SEC_CSS, "class"), UNEXPANDED_CLASS_VALUE).shouldBeEqual("Coverage details section is not collapsed by default");
		return new Validation(true);
	}
	
	public Validation validatePolicyConfPageDetailsWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Policy Confirmation page details");
		MapCompare.compareMap(this.getVehiclesTableData(), data);
		MapCompare.compareMap(this.getDriverTableData(), data);
		MapCompare.compareMap(this.getCoverageData(), ParseQuoteData.getPABaseCoverageDataFromBackEnd(jsonQuotedata));
		return new Validation(true);
	}

	public Validation validateHOPolicyDetailsWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Policy Summary Details");
		MapCompare.compareMap(data,
					ParseQuoteData.getDiscountDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Diiscount details are not correct");
		MapCompare.compareMap(data,
				ParseQuoteData.getConstructionDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Construction details are not correct");
		MapCompare.compareMap(data,
				ParseQuoteData.getYourHomeDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Home details are not correct");
		validatePAPolicyContactDetails(jsonQuotedata).shouldBeTrue("Policy Contact details are not correct");
		return new Validation(true);
	}

	public Validation validateHOPolicyQuoteDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy Details with backend");
		MapCompare.compareMap(data,
					ParseQuoteData.getDiscountDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Diiscount details are not correct");
		MapCompare.compareMap(data,
				ParseQuoteData.getConstructionDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Construction details are not correct");
		MapCompare.compareMap(data,
				ParseQuoteData.getYourHomeDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Home details are not correct");
		MapCompare.compareMap(data,
				ParseQuoteData.getPersonalInfoFromBackEnd(jsonQuotedata)).shouldBeTrue("Policy Home details are not correct");
		return new Validation(true);
	}
	
	public Validation validateHOScheduledPersonalPropertyDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Scheduled Property Data ");
		MapCompare.compareMap(getScheduledPersonalPropertyData(),
					ParseQuoteData.getScheduledPropertyDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Scheduled item details are not correct");
		return new Validation(true);
	}
	
	public Validation validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Scheduled Property Data ");
		MapCompare.compareMap(getSpecialScheduledPersonalPropertyData(),
					ParseQuoteData.getSpecialScheduledPropertyDataFromBackEnd(jsonQuotedata)).shouldBeTrue("Special Scheduled item details are not correct");
		return new Validation(true);
	}
	
	public Validation validateHOOtherStructuresOnTheResidencePremisesPropertyDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Scheduled Property Data ");
		MapCompare.compareMap(getOtherStructureOnResidencePremisePropertyData(),
					ParseQuoteData.getOtherStructuresOnTheResidencePremisesPropertyDataFromBackEnd(jsonQuotedata)).shouldBeTrue("OtherStructuresOnTheResidencePremises Scheduled item details are not correct");
		return new Validation(true);
	}
	
	public Validation validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Scheduled Property Data ");
		MapCompare.compareMap(getPersonalPropertyOnOtherResidenceData(),
					ParseQuoteData.getPersonalPropertyAtOtherResidencesDataFromBackEnd(jsonQuotedata)).shouldBeTrue("PersonalPropertyAtOtherResidencesData Scheduled item details are not correct");
		return new Validation(true);
	}
	
	public Validation validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(String jsonQuotedata) throws Exception {
		logger.info("Validating Scheduled Property Data ");
		MapCompare.compareMap(getSpecificStructuresAwayFromTheResidencePremisesData(),
					ParseQuoteData.getSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEnd(jsonQuotedata)).shouldBeTrue("SpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEnd Scheduled item details are not correct");
		return new Validation(true);
	}


	public void validatePersonalProperty(QuoteScheduledPropertyItem scheduledType) throws Exception {
		logger.info("Validating Personal Property Description");
		if(System.getProperty("platform").equalsIgnoreCase("granite")){
				String description_xpath = "("+ PRIVATE_PROPERTY_DESCRIPTION + ")[" + 1 + "]";
				String descrition = seleniumCommands.findElement(By.xpath(description_xpath)).getText();
				new Validation(descrition.equals("Guns")).shouldBeTrue("Scheduled Personal Property Description doesn't match one that was added");
			}else{
				String description_xpath = "("+ PRIVATE_PROPERTY_DESCRIPTION + ")[" + (scheduledType.getNumberOfMandatoryFileds()%2 +1) + "]";
				String descrition = seleniumCommands.findElement(By.xpath(description_xpath)).getText();
				new Validation(descrition.equals(data.get(scheduledType.getDescriptionIdentifier()) )).shouldBeTrue("Scheduled Personal Property Description doesn't match one that was added");
			}
	}

	public void validateHOPersonalProperty() throws Exception {
		logger.info("Validating Homeowner Personal Property Description");
		String description_xpath = "("+ PRIVATE_PROPERTY_DESCRIPTION + ")[" + 2 + "]";
		String descrition = seleniumCommands.findElement(By.xpath(description_xpath)).getText();
		new Validation(descrition.equals("$900.00")).shouldBeTrue("Scheduled Personal Property Description doesn't match one that was added");
	}

	public void validateTreeKindsOfPersonalProperty() throws Exception {
		this.validatePersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
		this.validatePersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY);
		this.validatePersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES);
	}

	public Validation validateHOBasePolicyCoverageDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy coverage with backend");
		return MapCompare.compareMap(this.getPolicyCoverageDetails(),
				ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonQuotedata));
	}

	public Validation validateHOPolicyCoverageDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy Contact Details");
		return MapCompare.compareMap(this.getPolicyCoverageDetails(),
				ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonQuotedata));
	}

	public Validation validateHOPolicyContactDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy Contact Details");
		return MapCompare.compareMap(this.getHOContactDetails(),
				ParseQuoteData.getPersonalInfoFromBackEnd(jsonQuotedata));
	}

	public Validation validatePAPolicyContactDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy Contact Details");
		return MapCompare.compareMap(this.getPAContactDetails(),
				ParseQuoteData.getPersonalInfoFromBackEnd(jsonQuotedata));
	}

	public Validation validateHOPolicyConfirmationPageDetailsWithBackEnd() throws Exception {
		logger.info("Validating HO Policy confirmation page Details");
		String jsonQuotedata = DataFetch.getQuoteAsJsonData(ThreadLocalObject.getQuoteNum().replace("(", "").replace(")", ""));
		this.isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page is not loaded");
		this.validateHOBasePolicyCoverageDetails(jsonQuotedata)
				.shouldBeTrue("Policy Base Coverage details are not matched");
		this.validateHOPolicySummaryDetails(jsonQuotedata).shouldBeTrue("Policy Summary details are not matched");
		this.validateHOPolicyContactDetails(jsonQuotedata).shouldBeTrue("Policy Contact details are not matched");
		return new Validation(true);
	}

	public Validation validateINowHOPolicyConfirmationPageDetailsWithBackEnd() throws Exception {
		logger.info("Validating HO Policy confirmation page data & quote data with backend");
		isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		isINowPolicyPlanNameEqualTo().shouldBeEqual("Payment Plan is not correct");
		String jsonPolicydata = DataFetch.getINowPolicyInfoAsJsonData(getPolicyNumber());
		this.validateHOBasePolicyCoverageDetails(jsonPolicydata)
				.shouldBeTrue("Policy Base Coverage details are not matched");
		this.validateHOPolicySummaryDetails(jsonPolicydata).shouldBeTrue("Policy Summary details are not matched");
		this.validateHOPolicyContactDetails(jsonPolicydata).shouldBeTrue("Policy Contact details are not matched");
		seleniumCommands.staticWait(15);
		return new Validation(true);
	}

	public Validation validatePAPolicyDataWithBackEnd(String jsonQuotedata) throws Exception {
		new QualificationPage().arePAQualificationAnswersMatchingBackEnd(jsonQuotedata)
				.shouldBeTrue("Qualification answers are not matching with Back End");
		DriverDetailsPage.areDriverDetailsMatchingBackEnd(jsonQuotedata)
				.shouldBeTrue("Driver Details are not matching with Back End");
		VehicleDetailsPage.areVehicleDetailsMatchingBackEnd(jsonQuotedata)
				.shouldBeTrue("Vehicle Details are not matching with Back End");
		new YourInfoPage().areYourInfoPageDataMatchingWithBackEnd(jsonQuotedata)
		.shouldBeTrue("Your Info page details are not matching with Back End");
		return new Validation(true);
	}
	
	public Validation validateHOConfirmationPageAndQuoteDataWithBackEnd(String refereNumber) throws Exception {
		logger.info("Validating HO Policy confirmation page data & quote data with backend");
		isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		isPolicyPlanNameEqualTo().shouldBeEqual("Payment Plan is not correct");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		validateHOPolicyQuoteDataWithBackEnd(jsonData).shouldBeTrue("Policy data is not matched with backend");
		validateHOPolicySummaryDetails(jsonData).shouldBeTrue("Policy details are not matched with backend");
		return new Validation(true);
	}

	public Validation iNowValidateHOConfirmationPageAndQuoteDataWithBackEnd(String refereNumber) throws Exception {
		logger.info("Validating HO Policy confirmation page data & quote data with backend");
		isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		isINowPolicyPlanNameEqualTo().shouldBeEqual("Payment Plan is not correct");
		return new Validation(true);
	}

	public Validation iNowValidateHOConfirmationPageAndQuoteDataWithBackEnd(String refereNumber, String paymentPlan) throws Exception {
		logger.info("Validating HO Policy confirmation page data & quote data with backend");
		isPolicyConfirmationPageDisplayed().shouldBeTrue("Policy Confirmation page not displayed");
		isINowPolicyPlanNameEqualTo(paymentPlan).shouldBeEqual("Payment Plan is not correct");
		return new Validation(true);
	}

	public Validation validatePAConfirmationPageDetails() throws Exception {
		logger.info("Validating PA Policy details(Summary, Contact, Coverages) with backend");
		this.isPolicyConfirmationPageDisplayed()
		.shouldBeTrue("Policy Confirmation page is not displayed");
		this.arePolicyDetailsSectionsCollapsedByDefault().shouldBeTrue();
		String quoteData = DataFetch.getQuoteAsJsonData(ThreadLocalObject.getQuoteNum());
		this.validatePAPolicySummaryDetails(quoteData)
				.shouldBeTrue("Policy Summary details are not matched");
		this.validatePolicyConfPageDetailsWithBackEnd(quoteData).shouldBeTrue();
		return new Validation(true);
	}
	
	public Validation validatePAStandardCoverageDetails(String jsonQuotedata) throws Exception {
		logger.info("Validating HO Policy coverage with backend");
		return MapCompare.compareMap(this.getPolicyCoverageDetails(),
				ParseQuoteData.getPAStandardCoverageDataFromBackEnd(jsonQuotedata));
	}
	
	

}