package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class CPBOPPolicyDetailsPage extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[model*='periodStartDate.value'] input")
    WebElement COVERAGE_START_DATE_CSS;

    @FindBy(css = "[model*='accountOrgType'] select")
    WebElement ORGANIZATION_TYPE_CSS;

    @FindBy(css = "[model*='smallBusinessType'] select")
    WebElement SMALL_BUS_TYPE_CSS;

    @FindBy(css = "[model*='effectiveDate'] input")
    WebElement EFFECTIVE_DATE_CSS;

    @FindBy(css = "[model*='description'] input")
    WebElement DESCRIPTION_CSS;

    @FindBy(css = "[model*='accountOrgType'] span[class='gw-error-inline ng-binding']")
    WebElement ORGANIZATION_TYPE_ERRMSG_CSS;

    @FindBy(css = "[model*='smallBusinessType'] span[class='gw-error-inline ng-binding']")
    WebElement SMALL_BUS_TYPE_ERRMSG_CSS;

    @FindBy(css = "[model*='periodStartDate'] span[class='gw-required-asterisk']")
    WebElement COVERAGE_DATE_ASTERISK_CSS;

    @FindBy(css = "[model*='accountOrgType'] span[class='gw-required-asterisk']")
    WebElement ORG_TYPE_ASTERISK_CSS;

    @FindBy(css = ".gw-page-title")
    WebElement PAGE_TITLE_CSS;

    @FindBy(css = "gw-transaction-wizard-title a[ui-sref*='accountNumber']")
    WebElement PAGE_TITLE_ACCOUNT_LINK_CSS;

    @FindBy(css = "gw-transaction-wizard-title span:nth-of-type(3)")
    WebElement JOB_NUMBER_CSS;

    public CPBOPPolicyDetailsPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public CPBOPPolicyDetailsPage(Object dataObj)
    {
        this.data = (HashMap<String, String>) dataObj;
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public String getJobNumber(){
        return seleniumCommands.getTextAtLocator(JOB_NUMBER_CSS);
    }

    public CPBOPPolicyDetailsPage setCPPolicyDetails() {

        this.setOrgType(false);
        return this;
    }

    public CPBOPPolicyDetailsPage setBOPPolicyDetails() {
        this.setOrgType(false);
        this.setSmallBusinessType(false);
        return this;
    }

    public CPBOPPolicyDetailsPage setOrgType(boolean newData) {
        String n = "";
        if(newData)
            n = "New";
        seleniumCommands.waitForElementToBeEnabled(ORGANIZATION_TYPE_CSS);
        seleniumCommands.selectDropDownValueByText(ORGANIZATION_TYPE_CSS, data.get(n+"OrganizationType"));
        return this;
    }

    public CPBOPPolicyDetailsPage setCoverageDate(String date) {
        seleniumCommands.waitForElementToBeEnabled(COVERAGE_START_DATE_CSS);
        seleniumCommands.type(COVERAGE_START_DATE_CSS, date);
        seleniumCommands.focusOff();
        return this;
    }

    public CPBOPPolicyDetailsPage setSmallBusinessType(boolean newData) {
        String n = "";
        if(newData)
            n = "New";
        seleniumCommands.waitForElementToBeEnabled(SMALL_BUS_TYPE_CSS);
        seleniumCommands.selectDropDownValueByText(SMALL_BUS_TYPE_CSS, data.get(n+"SmallBusinessType"));
        return this;
    }

    //Validation

    public Validation isOrgTypeFieldMarkedWithError() {
        logger.info( "Validating the Mandatory Error for Organization Type");
        return new Validation(seleniumCommands.getTextAtLocator(ORGANIZATION_TYPE_ERRMSG_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isSmallBusinessTypeFieldMarkedWithError() {
        logger.info( "Validating the Mandatory Error for Small Business Type");
        return new Validation(seleniumCommands.getTextAtLocator(SMALL_BUS_TYPE_ERRMSG_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isCoverageStartFieldMarkedWithMandatoryError() {
        logger.info( "Validating the Mandatory Error for Coverage Start field");
        return new Validation(seleniumCommands.getErrorMessageForDatePicker(COVERAGE_START_DATE_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isCoverageStartFieldMarkedWithInvalidError() {
        logger.info( "Validating the Invalid date Error for Coverage Start field");
        return new Validation(seleniumCommands.getErrorMessageForDatePicker(COVERAGE_START_DATE_CSS),DataConstant.DATE_FUTURE_ERROR);
    }

    public Validation isOrgTypeFieldMarkedWithAsterisk() {
        logger.info( "Validating the Asterisk for Organization Type Field");
        return new Validation(seleniumCommands.isElementPresent(ORG_TYPE_ASTERISK_CSS));
    }

    public Validation isCoverageStartDateFieldMarkedWithAsterisk() {
        logger.info( "Validating the Asterisk for Coverage Start Field");
        return new Validation(seleniumCommands.isElementPresent(COVERAGE_DATE_ASTERISK_CSS));
    }

    public Validation arePolicyDetailsSaved(String policyType){
        new Validation(seleniumCommands.getValueAttributeFromLocator(COVERAGE_START_DATE_CSS), DateUtil.getFutureDate()).shouldBeEqual("Coverage Date didn't save");
        new Validation(seleniumCommands.getSelectedOptionFromDropDown(ORGANIZATION_TYPE_CSS), data.get("OrganizationType")).shouldBeEqual("Organization type didn't save");
        if(policyType.equals("BOP"))
           new Validation(seleniumCommands.getSelectedOptionFromDropDown(SMALL_BUS_TYPE_CSS), data.get("SmallBusinessType")).shouldBeEqual("Small Business Type didn't save");
        return new Validation(true);
    }

    public void validatePageHeaderForPolicyChange(String policyType, String policyNum){
        String policyName = "";
        if(policyType.equals("BO"))
            policyName = "Businessowners ";
        else
            policyName = "Commercial Property ";
        new Validation(seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).contains(policyName+policyNum) && seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).contains("Policy Change ")).shouldBeTrue("LOB and job name header missing");
        new Validation(seleniumCommands.isElementPresent(PAGE_TITLE_ACCOUNT_LINK_CSS)).shouldBeTrue("Account link not present");
    }

    public void validatePageHeaderForPolicyRenewal(String policyType, String policyNum){
        String policyName = "";
        if(policyType.equals("BO"))
            policyName = "Businessowners ";
        else
            policyName = "Commercial Property ";
        new Validation(seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).contains(policyName+policyNum) && seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).contains("Renewal ")).shouldBeTrue("LOB and job name header missing");
        new Validation(seleniumCommands.isElementPresent(PAGE_TITLE_ACCOUNT_LINK_CSS)).shouldBeTrue("Account link not present");
    }

    public void validatePresenceOfAllFields(String policyType){
        new Validation(seleniumCommands.isElementPresent(ORGANIZATION_TYPE_CSS)).shouldBeTrue("Organisation type field is missing");
        new Validation(seleniumCommands.isElementPresent(DESCRIPTION_CSS)).shouldBeTrue("Description field is missing");
        new Validation(seleniumCommands.isElementPresent(EFFECTIVE_DATE_CSS)).shouldBeTrue("Effective date field is missing");
        if(policyType.equals("BO"))
            new Validation(seleniumCommands.isElementPresent(SMALL_BUS_TYPE_CSS)).shouldBeTrue("Small Business type field is missing");
    }

    public void validatePolicyDetailsWithBackend(String policyType){
        String jsonData = fetchDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages;
        if(policyType.equals("BO")) {
            lineCoverages = ParseEndorsementData.getBOPLinePolicyDetailsForPolicyChange(jsonData);
            new Validation(lineCoverages.get("Small_Bus_Type"), (data.get("NewSmallBusinessType")).toLowerCase()).shouldBeEqual("Small Business Type didn't match");
        }
        else
            lineCoverages = ParseEndorsementData.getCPLinePolicyDetailsForPolicyChange(jsonData);
        new Validation(lineCoverages.get("Org_Type"),(data.get("NewOrganizationType")).toLowerCase()).shouldBeEqual("Organization Type didn't match");
    }

    public String fetchDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

}
