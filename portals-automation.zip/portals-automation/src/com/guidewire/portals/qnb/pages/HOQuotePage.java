package com.guidewire.portals.qnb.pages;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.apache.xpath.operations.Bool;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.common.selenium.FrameWorkConstants;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.QuoteScheduledPropertyItem;
import com.guidewire.portals.qnb.pages.scheduleditemComponant.PropertyLocationModel;

import io.restassured.path.json.JsonPath;

public class HOQuotePage extends HOCoverageDetailsPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	@FindBy(xpath = "//gw-qnb-multiple-offering-view//*[@ng-repeat]/p[contains(@class,'Multiple')][2]")
	 WebElement BASE_MONTHLY_PREMIUM_COST_LBL_XPATH;
	
	@FindBy(xpath = "//gw-qnb-multiple-offering-view//*[@ng-repeat]/p[contains(@class,'Multiple')][2]")
	 WebElement BASE_FULL_PREMIUM_COST_LBL_XPATH;
	
	@FindBy(css = "gw-qnb-multiple-offering-view div[ng-repeat*='offering']:nth-of-type(1) button")
	 WebElement BUY_POLICY_BTN_CSS;
	
	@FindBy(css = "span[class='fa fa-print']")
	 WebElement PRINT_POLICY_BTN_CSS;

	@FindBy(css = "ul[class*='gw-nav'] ")
	 WebElement QUOTE_OPTION_TILE_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li[class*='active'] div[class*='offeringName']")
	 WebElement QUOTE_OPTION_BASE_LBL_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li[ng-repeat='quote in page.standardQuotes']")
	 WebElement QUOTE_OPTION_BASE_TILE_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li div[class='offeringCost ng-binding']")
	 WebElement QUOTE_OPTION_BASE_COST_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li:nth-of-type(2) div[class*='offeringName']")
	 WebElement QUOTE_OPTION_CUSTOM_LBL_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li:nth-of-type(2) div[class='offeringCost ng-binding']")
	 WebElement QUOTE_OPTION_CUSTOM_COST_CSS;
	
	@FindBy(css = "form[name='CustomQuoteForm']")
	 WebElement CUSTOM_QUOTE_FORM_CSS;
	
	@FindBy(css = "h4[class='coverage-header']:first-of-type span:nth-of-type(2)")
	 WebElement MAIN_COVERAGE_PREMIUM_COST_CSS;
	
	@FindBy(css = "//gw-qnb-multiple-offering-view//*[@gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_left_label]")
	 WebElement BASE_FULL_PREMIUM_COST_RBTN_CSS;
	
	@FindBy(css = "//gw-qnb-multiple-offering-view//*[@gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_right_label]")
	 WebElement BASE_MONTHLY_PREMIUM_COST_RBTN_CSS;
	
	@FindBy(css = "input[value='monthly']")
	 WebElement ANNUAL_COST_RBTN_CSS;
	
	@FindBy(css = "input[value='fullTerm']")
	 WebElement MONTHLY_COST_RBTN_CSS;
	
	@FindBy(css = "li[ng-repeat='quote in page.standardQuotes']")
	 WebElement BASE_POLICY_TILE_CSS;
	
	@FindBy(css = "[class*='gw-nav']  li a div")
	 WebElement BASE_TILE_NAME_CSS;

	@FindBy(css = "li[ng-repeat='quote in page.customQuotes']")
	WebElement CUSTOM_POLICY_TILE_CSS;

	@FindBy(css = "ul[class*='gw-nav']  li:nth-of-type(2) div[class='gw-offeringName ng-binding']")
	WebElement QUOTE_OPTION_STANDARD_LBL_CSS;

	@FindBy(css = "ul[class*='gw-nav']  li:nth-of-type(3) div[class='gw-offeringName ng-binding']")
	WebElement QUOTE_OPTION_PREMIUM_LBL_CSS;

	@FindBy(css = "tr[class*='gw-schedule-table__row'] input[ng-model='fakeVM.value']")
	WebElement PERSONAL_PROPERTY_DESCRIPTION;

	@FindBy(css = "tr[class*='gw-schedule-table__row gw-schedule-table__new-row'] select, tr[class*='gw-schedule-table__row'] select")
	WebElement PERSONAL_PROPERTY_TYPE;

	@FindBy(css = "tr[class*='gw-schedule-table__row gw-schedule-table__new-row'] button[on-click='add()']")
	WebElement PERSONAL_PROPERTY_ADD_BUTTON;
	
	@FindBy(css = "tr[class='gw-schedule-table__row gw-schedule-table__new-row ng-scope'] button[on-click='resetAdd()']")
	WebElement PERSONAL_PROPERTY_CANCEL_BUTTON;

	@FindBy(css = "button[ng-click*='recalculate']")
	WebElement CALCULATOR_BUTTON;
	
	@FindBy(css = "td[class*='scope'] [on-click='edit(scheduledItem)'] [ng-click='handleClick()']")
	WebElement EDIT;

	@FindBy(css = "td[class*='scope'] [on-click='edit(scheduledItem)'] [ng-click='handleClick()']")
	List<WebElement>	EDIT_BUTTON;
	
	@FindBy(css = "td[class*='scope'] [on-click='initRemove(scheduledItem)'] [ng-click='handleClick()']")
	WebElement DELETE;

	@FindBy(css = "td[class*='scope'] [on-click='initRemove(scheduledItem)'] [ng-click='handleClick()']")
	List<WebElement>	DELETE_ICON;
	
	@FindBy(css = "tr[ng-if='newItem'][class*='gw-schedule-table'] select, [class*='edit'] select")
	List<WebElement> SCHEDULED_PROPERTY_DROP_LIST;

	By ADD_PERSONAL_PROPERTY	= By.cssSelector("[on-Click='createNew()']");

	By CONFIRM_DELETE_PERSONAL_PROPERTY = By.cssSelector("td[ng-if] button[on-click='remove(scheduledItem)']");

	By PERSONAL_PROPERTY_VALUE = By.cssSelector("tr[class='gw-schedule-table__row gw-schedule-table__new-row ng-scope'] input[class*='gw-currency-input__input'], [class*='edit'] input");

	String QUOTE_TILE_COUNT = "//ul[@class='gw-nav gw-nav-tabs']/li";
	
	By MONTHLY_RDBTN_ID = By.xpath("//*[@gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_left_label]/ancestor::gw-qnb-multiple-offering-view//div[@title-left='Monthly']//input[1]");
	
	By ANNUAL_RDBTN_ID = By.xpath("//*[@gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_left_label]/ancestor::gw-qnb-multiple-offering-view//div[@title-left='Monthly']//input[2]");

	String SCHEDULE_IN_SCHEDULES = "//div[@ng-repeat='schedule in schedules track by schedule.getPattern()']";

	String MANDATORY_FIELD_ERROR_MESSAGE = "//div[@class='gw-schedule-table__error ng-binding ng-scope']";
	
	By NEW_ITEM_ROW	= By.cssSelector("[ng-if='newItem'][class*='schedule-table']");
	
	By RECALCULATE_MSG	= By.cssSelector("[class*='gw-message-overlay'] [aria-hidden='false'] .gw-overlay-banner");
	
	By DELETE_BUTTON	= By.xpath("(//table[contains(@class,'gw-schedule-table')])[2]//tr[3]//td[3]/button");

	By ACCOUNT_SUMMARY_LINK = By.cssSelector("a[ui-sref*='accounts.detail.summary']");

	By PERSONAL_INJURY_CHECKBOX = By.cssSelector("input[id='default_additional_coverages1_coverage_0']");

	By LIMITED_FUNGI_WET_DRY_ROT_BACTERIA_CHECKBOX = By.cssSelector("input[id='default_additional_coverages5_coverage_0']");

	By OFFERING_PRICE = By.cssSelector("[class*='quote_offering_price'] span[class='ng-binding ng-scope']");

	By RECALCULATE_BUTTON = By.xpath("//button[ contains(@ng-click,'recalculate')]");

	By HOMEOWNERS_OTHER_STRUCTURE_DROPDOWN = By.cssSelector("gw-qnb-multiple-offering-view select[id='HODW_OtherStructures_Limit_HOE']");

	By  LOSS_OF_USE_PROHIBITED_USE_DROPDOWN = By.cssSelector("gw-qnb-multiple-offering-view select[id='zdbiq4n6t22tqdq906jh6k5sbb9']");

    By  DWELLING_VALUATION_METHOD_DROPDOWN = By.cssSelector("gw-qnb-multiple-offering-view select[id='z8ugc5n3dv8bu7pbhkkbeiv23s9']");

	By  OTHER_STRUCTURES_CAUSE_OF_LOSS_DROPDOWN = By.cssSelector("gw-qnb-multiple-offering-view select[id='zc2j8chomjs3adiai3m74vl50ra']");

	By COVERAGE_E_PERSONAL_LIABILITY_LIMIT_DROPDOWN = By.cssSelector("[class*='MultipleOfferingViewInternal'] [id='zjihof5u6p0ob195orrdcmauhpa']");

	By ADDITIONAL_COVERAGES_LOSS_ASSESSMENT_DROPDOWN = By.cssSelector("[class*='MultipleOfferingViewInternal'] [id='zhlge07d7quku5kk35hk3ksuum9']");

	By ADD_PERSONAL_PROPERTY_BUTTON_HOP = By.cssSelector("[gw-pc-scheduled-coverages='offeringSchedule.model.schedules'] table[class*='gw-schedule-table'] button[on-click='createNew()']");

	By SCHEDULED_PERSONAL_PROPERTY_DROPDOWNLISTS = By.cssSelector("[class*='gw-schedule-table__data'] [gw-pl-select='fakeVM.value']");

	By SCHEDULED_PERSONAL_PROPERTY_COST = By.cssSelector("[class*='gw-schedule-table__data'] input[class*='gw-currency-input']");

	By SCHEDULED_PERSONAL_PROPERTY_ADD_BUTTON = By.cssSelector("[tabindex='-1'] button[on-click='add()']");

	By HOMEOWNERS_PERSONAL_LIABILITY = By.cssSelector("gw-qnb-multiple-offering-view select[id='HOLI_Liability_Limit_HOE']");

	By HOMEOWNERS_LOSS_OF_USE = By.cssSelector("gw-qnb-multiple-offering-view select[id='HODW_LossOfUseDwelLimit_HOE']");

	By BUY_NOW = By.xpath("//button[ contains(@ng-disabled,'shouldDisableBuyOrRecalculateButton') and contains(@class,'gw-btn-primary') and not(contains(@class,'MobileQuoteOfferings'))]");

	By PERSONAL_INJURY_NO_BUTTON = By.cssSelector("[class*='MultipleOfferingViewInternal'] [gw-test-policycommon-editablecoverages-editablecoverages='Personal Injury'] label[class='gw-second']");

	By RESET_COVERAGES_BUTTON = By.cssSelector("a[ng-click*='revertCustomQuote(offering']");

	By PAY_IN_FULL_TAB = By.cssSelector("label[title='Pay In Full']");

	String SAVE_BUTTON	="tr[class*='scope'] button[on-click='doneEditing(scheduledItem)']";
	
	public HOQuotePage() {
		seleniumCommands.waitForLoaderToDisappearFromPage(5);
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		if(!ThreadLocalObject.getSuitenName().equals(FrameWorkConstants.GPA_SUITE)) {
			ThreadLocalObject.setQuoteNum(new QuoteInfoBar().getSubmissionNumber());
		}
	}

	public HOQuotePage(Object obj) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public HOPolicyInfoPage goToPolicyInfoPage() {
			return new Pagefactory().getHOPolicyInfoPage();
	}
	
	private void goNext()
	{
	}

	public HOQuotePage openCustomPolicyView() {
		seleniumCommands.click(CUSTOM_POLICY_TILE_CSS);
		return this;
	}

	public HOQuotePage openBasePolicyView() {
		seleniumCommands.clickbyJS(BASE_POLICY_TILE_CSS);
		return this;
	}

	public HOQuotePage clickAddScheduleredPersonalProperty(QuoteScheduledPropertyItem blockIndex) {
		seleniumCommands.clickbyJS( seleniumCommands.findElements(ADD_PERSONAL_PROPERTY).get(blockIndex.getBlockIndex()));
		return this;
	}
	
	public HOQuotePage clickAddScheduleredPersonalProperty(int index) {
		seleniumCommands.clickbyJS( seleniumCommands.findElements(ADD_PERSONAL_PROPERTY).get(index));
		return this;
	}

	public HOQuotePage submitScheduledPersonalProperty() {
		seleniumCommands.logInfo("Saving scheduled property");
		new Validation(seleniumCommands.isElementPresent(PERSONAL_PROPERTY_ADD_BUTTON)).shouldBeTrue("Cancel scheduled property button is not available");
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_ADD_BUTTON);
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		return this;
	}
	
	private HOQuotePage saveScheduledProperty() {
		seleniumCommands.staticWait(3);
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.clickbyJS(By.cssSelector(SAVE_BUTTON));
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		return this;
	}
	
	private HOQuotePage deleteScheduledPersonalProperty() {
		seleniumCommands.waitForElementToBePresent(CONFIRM_DELETE_PERSONAL_PROPERTY);
		seleniumCommands.clickbyJS(CONFIRM_DELETE_PERSONAL_PROPERTY);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public HOQuotePage clickPersonalInjuryCheckbox() {
		logger.info("Clicking Personal Injury checkbox");
		seleniumCommands.clickbyJS(PERSONAL_INJURY_CHECKBOX);
		return this;
	}

	public HOQuotePage clickPersonalInjuryNoTabForHOP() {
		logger.info("Clicking Personal Injury No tab");
		seleniumCommands.clickbyJS(PERSONAL_INJURY_NO_BUTTON);
		seleniumCommands.waitForElementToBeClickable(RECALCULATE_BUTTON);
		return this;
	}

	public HOQuotePage clickLimitedFungiWetDryRotBacteriaCheckbox() {
		logger.info("Clicking Personal Injury checkbox");
		seleniumCommands.clickbyJS(LIMITED_FUNGI_WET_DRY_ROT_BACTERIA_CHECKBOX);
		seleniumCommands.staticWait(3);
		return this;
	}

	public HOQuotePage getOfferingPrice() {
		logger.info("Saving Offering price");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		ThreadLocalObject.getData().put("OfferingPrice", seleniumCommands.getTextAtLocator(OFFERING_PRICE));
		return this;
	}

	public HOQuotePage isPersonalInjuryChecked() {
		logger.info("Checking if Personal Injury is checked");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		ThreadLocalObject.getData().put("PersonalInjury", Boolean.toString(seleniumCommands.getAttributeValueAtLocator(PERSONAL_INJURY_CHECKBOX, "class").contains("not")));
		return this;
	}

	public HOQuotePage isLimitedFungiWetDryRotBacteriaChecked() {
		logger.info("Checking if Limited Fungi Wet Dry Rot Bacteria is checked");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		ThreadLocalObject.getData().put("LimitedFungiWetDryRotBacteria", Boolean.toString(seleniumCommands.getAttributeValueAtLocator(PERSONAL_INJURY_CHECKBOX, "class").contains("not")));
		return this;
	}

	public HOQuotePage setValueToHomeownersOtherStructures(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(3);
		seleniumCommands.selectDropDownValueByText(HOMEOWNERS_OTHER_STRUCTURE_DROPDOWN, value);
		return this;
	}

    public HOQuotePage setValueToDwellingValuationMethod(String value){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(DWELLING_VALUATION_METHOD_DROPDOWN, value);
        seleniumCommands.staticWait(5);
        return this;
    }

    public HOQuotePage setValueToHomeownersDwellingHomeownersPersonalLiability(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(1);
		seleniumCommands.selectDropDownValueByText(HOMEOWNERS_PERSONAL_LIABILITY, value);
		seleniumCommands.staticWait(2);
		return this;
	}

	public HOQuotePage setValueToCoverageEPersonalLiabilityLimit(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(1);
		seleniumCommands.selectDropDownValueByText(COVERAGE_E_PERSONAL_LIABILITY_LIMIT_DROPDOWN, value);
		seleniumCommands.waitForElementToBeClickable(RECALCULATE_BUTTON);
		return this;
	}

	public HOQuotePage setValueToAdditionalCoveragesLossAssessment(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(ADDITIONAL_COVERAGES_LOSS_ASSESSMENT_DROPDOWN, value);
		seleniumCommands.waitForElementToBeClickable(RECALCULATE_BUTTON);
		return this;
	}

	public HOQuotePage setValueToHomeownersHomeownersLossOfUse(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(1);
		seleniumCommands.selectDropDownValueByText(HOMEOWNERS_LOSS_OF_USE, value);
		return this;
	}

	public HOQuotePage setValueToLossOfUseProhibitedUse(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(LOSS_OF_USE_PROHIBITED_USE_DROPDOWN, value);
		return this;
	}

	public HOQuotePage setValueToOtherStructuresCauseOfLoss(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(OTHER_STRUCTURES_CAUSE_OF_LOSS_DROPDOWN, value);
		return this;
	}

	public HOQuotePage validateCoverageEPersonalLiabilityLimit(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(COVERAGE_E_PERSONAL_LIABILITY_LIMIT_DROPDOWN), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

	public HOQuotePage validateActualValueOfHomeownersOtherStructures(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(2);
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(HOMEOWNERS_OTHER_STRUCTURE_DROPDOWN), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

	public HOQuotePage validateActualValueOfHomeownersPersonalLiability(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(HOMEOWNERS_PERSONAL_LIABILITY), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

	public HOQuotePage validateActualValueOfHomeownersLossOfUse(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(HOMEOWNERS_LOSS_OF_USE), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

	public HOQuotePage validateLossOfUseProhibitedUse(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(3);
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(LOSS_OF_USE_PROHIBITED_USE_DROPDOWN), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

	public HOQuotePage validateOtherStructuresCauseOfLoss(String value){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation( seleniumCommands.getSelectedOptionFromDropDown(OTHER_STRUCTURES_CAUSE_OF_LOSS_DROPDOWN), value).shouldBeEqual("Selected value for Homeowners Other Structures is not correct");
		return this;
	}

    public HOQuotePage validateDwellingValuationMethod(String value){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation( seleniumCommands.getSelectedOptionFromDropDown(DWELLING_VALUATION_METHOD_DROPDOWN), value).shouldBeEqual("Selected value for Homeowners Dwelling is not correct");
        return this;
    }

	public HOQuotePage clickRecalculateButton() {
		logger.info("Clicking recalculate button");
		seleniumCommands.waitForElementToBeClickable(seleniumCommands.findElement(RECALCULATE_BUTTON));
		seleniumCommands.findElement(RECALCULATE_BUTTON).click();
		seleniumCommands.waitForElementToBeClickable(BUY_NOW);
		return this;
	}

	public Validation isRecalculateButtonAppears() {
		logger.info("checking recalculate button appears or not");
		seleniumCommands.waitForElementToBeClickable(seleniumCommands.findElement(RECALCULATE_BUTTON));
		return new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(RECALCULATE_BUTTON)));
	}
	public HOQuotePage clickResetCoverages() {
		logger.info("Clicking Reset coverage button");
		seleniumCommands.waitForElementToBeClickable(RESET_COVERAGES_BUTTON);
		seleniumCommands.clickbyJS(RESET_COVERAGES_BUTTON);
		seleniumCommands.staticWait(1);
		return this;
	}

	public HOQuotePage clickPayInFullTab() {
		logger.info("Clicking Pay in Full tab");
		seleniumCommands.clickbyJS(PAY_IN_FULL_TAB);
		return this;
	}

	public String getStatusFromBackend(String refereNumber) {
		seleniumCommands.logInfo("Getting Program price from backend");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		JsonPath jsonpath = new JsonPath(jsonData);
		return jsonpath.getString("quoteData.offeredQuotes"+"["+ 0 + "]" + ".status" );

	}

	public String getPriceFromBackend(String refereNumber) {
		seleniumCommands.logInfo("Getting Program price from backend");
		String jsonData = DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), refereNumber);
		JsonPath jsonpath = new JsonPath(jsonData);
		return jsonpath.getString("quoteData.offeredQuotes"+"["+ 0 + "]" + ".premium.total.amount" );
	}

	public HOQuotePage addPersonalProperty(QuoteScheduledPropertyItem scheduledType) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBePresent(ADD_PERSONAL_PROPERTY);
		this.clickAddScheduleredPersonalProperty(scheduledType);
		String description=UUID.randomUUID().toString();
	
		data.put(scheduledType.getDescriptionIdentifier(), description);
		if (scheduledType != QuoteScheduledPropertyItem.OTHER_STRUCTURES) {
			seleniumCommands.type(seleniumCommands.findElements(PERSONAL_PROPERTY_VALUE).get(1), "10000");
		}
		data.put("SchedulePropertyLimit", "10000");
		seleniumCommands.type(PERSONAL_PROPERTY_DESCRIPTION, description);
		data.put("SchedulePropertyDesc", description);
		seleniumCommands.selectDropDownValueByText( PERSONAL_PROPERTY_TYPE ,scheduledType.getDropdowlistValue());
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_TYPE);
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_TYPE);
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_DESCRIPTION);
		return submitScheduledPersonalProperty();
	}

	public HOQuotePage addPersonalPropertyGranite(){
		seleniumCommands.logInfo("Adding Personal Property");
		seleniumCommands.clickbyJS(ADD_PERSONAL_PROPERTY_BUTTON_HOP);

		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(SCHEDULED_PERSONAL_PROPERTY_DROPDOWNLISTS).get(0),"Guns");
		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(SCHEDULED_PERSONAL_PROPERTY_DROPDOWNLISTS).get(1),"$1,000");
		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(SCHEDULED_PERSONAL_PROPERTY_DROPDOWNLISTS).get(2),"Replacement cost");

		seleniumCommands.type(SCHEDULED_PERSONAL_PROPERTY_COST,"900");
		seleniumCommands.click(SCHEDULED_PERSONAL_PROPERTY_ADD_BUTTON);
		return this;
	}

	public HOQuotePage addOtherStructureOnPremisesProperty() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		QuoteScheduledPropertyItem item = QuoteScheduledPropertyItem.OTHER_STRUCTURES;
		this.clickAddScheduleredPersonalProperty(item);
		setOtherStructureOnPremisesProperty(item);
		return submitScheduledPersonalProperty();
	}
	
	public HOQuotePage addPersonalPropertyAOtherResidence() throws ParseException {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.clickAddScheduleredPersonalProperty(3);
		PropertyLocationModel locationModel = new PropertyLocationModel();
		locationModel.validateNewLocationPopUp();
		locationModel.setIncreasedLimit().fillNewLocationFrom();
		MapCompare.compareMap(new PolicyConfirmationPage().getPersonalPropertyOnOtherResidenceData(), ThreadLocalObject.getData());
		return this;
	}

	public HOPolicyInfoPage clickBuyNowButton() {
		logger.info("Clicking Buy Now button");
		seleniumCommands.waitForElementToBeClickable(BUY_NOW);
		seleniumCommands.clickbyJS(seleniumCommands.findElement(BUY_NOW));
		return new HOPolicyInfoPage();
	}
	
	public HOQuotePage addSpecificStructuresAwayFromTheOtherResidencePremisesProperty() throws ParseException {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.clickAddScheduleredPersonalProperty(4);
		PropertyLocationModel locationModel = new PropertyLocationModel();
		locationModel.validateNewLocationPopUp();
		locationModel.setIncreasedLimit().setDescription().fillNewLocationFrom();
		return this;
	}
	
	private HOQuotePage setOtherStructureOnPremisesProperty(QuoteScheduledPropertyItem item) {
		String description=UUID.randomUUID().toString();
		seleniumCommands.type(PERSONAL_PROPERTY_DESCRIPTION, description);
		seleniumCommands.selectDropDownValueByText( PERSONAL_PROPERTY_TYPE ,item.getDropdowlistValue());
		data.put("SchedulePropertyLimit", item.getDropdowlistValue());
		data.put("SchedulePropertyDesc", description);
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_DESCRIPTION);
		return this;
	}
	
	private HOQuotePage setPropertyLocation() {
		String description=UUID.randomUUID().toString();
		data.put("SchedulePropertyLimit", "10%");
		data.put("SchedulePropertyDesc", description);
		seleniumCommands.type(PERSONAL_PROPERTY_DESCRIPTION, description);
		seleniumCommands.selectDropDownValueByText( PERSONAL_PROPERTY_TYPE, data.get("SchedulePropertyLimit"));
		seleniumCommands.clickbyJS(PERSONAL_PROPERTY_DESCRIPTION);
		return this;
	}
	
	
	public HOQuotePage addScheduledPersonalProperty() {
		seleniumCommands.clickbyJS(ADD_PERSONAL_PROPERTY);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.setScheduledItemDataFields();
		return submitScheduledPersonalProperty();
	}
	
	public HOQuotePage editFirstScheduledPersonalProperty() {
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(EDIT);
		this.setScheduledItemDataFields();
		this.saveScheduledProperty();
		reCalculatePolicyPremium();
		return this;
	}
	
	public HOQuotePage editFirstPersonalPropertyOnOtherPremises() {
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.waitForElementToBeVisible(EDIT_BUTTON.get(0));
		seleniumCommands.clickbyJS(EDIT_BUTTON.get(0));
		PropertyLocationModel locationModel = new PropertyLocationModel();
		data.put("SchedulePropertyLimit", "5%");
		locationModel.setIncreasedLimit().addLocation();
		reCalculatePolicyPremium();
		return this;
	}
	
	public HOQuotePage editFirstSpecificStructuresAwayFromTheOtherResidencePremisesProperty() {
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(EDIT);
		PropertyLocationModel locationModel = new PropertyLocationModel();
		data.put("SchedulePropertyLimit", "10%");
		locationModel.setIncreasedLimit().setDescription().addLocation();
		reCalculatePolicyPremium();
		return this;
	}
	
	public HOQuotePage editFirstOtherStructureOnPremisesProperty() {
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(EDIT);
		QuoteScheduledPropertyItem item = QuoteScheduledPropertyItem.OTHER_STRUCTURES;
		item.setDropdowlistValue("20%");
		this.setOtherStructureOnPremisesProperty(item);
		this.saveScheduledProperty();
		reCalculatePolicyPremium();
		return this;
	}
	
	public HOQuotePage deleteFirstProperty() {
		seleniumCommands.waitForElementToBePresent(CALCULATOR_BUTTON);
		seleniumCommands.waitForElementListHaveLessValuesThan(RECALCULATE_MSG, 1);
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(DELETE);
		deleteScheduledPersonalProperty();
		reCalculatePolicyPremium();
		return this;
	}
	
	
	private void setScheduledItemDataFields() {
		if(SCHEDULED_PROPERTY_DROP_LIST.size() == 3) {
			//This set Personal property for QnB
			seleniumCommands.waitForElementToBeVisible(PERSONAL_PROPERTY_VALUE);
			seleniumCommands.selectDropDownValueByText(SCHEDULED_PROPERTY_DROP_LIST.get(0), data.get("SchedulePropertyType"));
			seleniumCommands.type(PERSONAL_PROPERTY_VALUE, data.get("SchedulePropertyLimit"));
			seleniumCommands.selectDropDownValueByText(SCHEDULED_PROPERTY_DROP_LIST.get(1), data.get("SchedulePropertyDeductible"));
			seleniumCommands.selectDropDownValueByText(SCHEDULED_PROPERTY_DROP_LIST.get(2), data.get("SchedulePropertyValuationMethod"));
			seleniumCommands.click(SCHEDULED_PROPERTY_DROP_LIST.get(1));
			seleniumCommands.click(SCHEDULED_PROPERTY_DROP_LIST.get(1));
		}
		else {
			//This set Personal property for GPA
			String description=UUID.randomUUID().toString();
			data.put("SchedulePropertyDesc", description);
			seleniumCommands.type(PERSONAL_PROPERTY_DESCRIPTION, description);
			seleniumCommands.selectDropDownValueByText( PERSONAL_PROPERTY_TYPE , data.get("SchedulePropertyType"));
		}
	}

	public HOQuotePage buyBasePolicyWithMonthlyPremium() {
		selectBasePolicyMonthlyOption();
		seleniumCommands.click(BUY_POLICY_BTN_CSS);
		return this;
	}
	
	public HOQuotePage buyBasePolicyWithAnnualPremium() {
		selectBasePolicyAnnualOption();
		seleniumCommands.click(BUY_POLICY_BTN_CSS);
		return this;
	}

	public HOQuotePage buyCustomPolicy() {
		return null;
	}

	public HOQuotePage reCalculatePolicyPremium() {
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(CALCULATOR_BUTTON);
		seleniumCommands.waitForElementListHaveLessValuesThan(RECALCULATE_MSG, 1);
		return this;
	}

	public HOQuotePage emailPolicyQuote() {
		return null;
	}

	public HOQuotePage addArticle() {
		return null;
	}

	public HOQuotePage deleteArticle() {
		return null;
	}

	public HOQuotePage selectBasePolicyMonthlyOption() {
		seleniumCommands.clickbyJS(seleniumCommands.selectLeftRadioButtonByRowIndex(0));
		return this;
	}

	public HOQuotePage selectBasePolicyAnnualOption() {
		seleniumCommands.clickbyJS(seleniumCommands.selectRightRadioButtonByRowIndex(0));
		return this;
	}

	public HOQuotePage selectCustomPolicyAnnualOption() {
		return null;
	}

	public HOQuotePage selectCustomPolicyMonthlyOption() {
		return null;
	}

	// Set Methods

	public HOQuotePage setAllOtherPeril_DEDUCT_Value() {
		return null;
	}

	public HOQuotePage setHurricanePercentage_DEDUCT_Value() {
		return null;
	}

	public HOQuotePage setWindOrHailPercentage_DEDUCT_Value() {
		return null;
	}

	public HOQuotePage setLimit_HO_DWEL_Value() {
		return null;
	}

	public HOQuotePage setValuationMethod_HOME_DWEL_Value() {
		return null;
	}

	public HOQuotePage setLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value() {
		return null;
	}

	public HOQuotePage setLimitPercentageOFDwellingCoverage_HO_PER_STRU_Value() {
		return null;
	}

	public HOQuotePage setValuationMethod_HO_PER_STRU_Value() {
		return null;
	}

	public HOQuotePage setLimitPercentageOFDwellingCoverage_HO_LOU_Value() {
		return null;
	}

	public HOQuotePage setLiabilityLimit_HO_PER_LIAB_Value() {
		return null;
	}

	public HOQuotePage setLimit_HO_MED_PAY_Value() {
		return null;
	}

	public HOQuotePage setPersonalInjury(boolean selection) {
		return null;
	}

	public HOQuotePage setLimit_HO_ORD_LAW_Value() {
		return null;
	}

	public HOQuotePage setLimitedFungiBact(boolean selection) {
		return null;
	}

	public HOQuotePage setLimit_Fungi_Bact_Value() {
		return null;
	}

	public HOQuotePage setAggregateLimit_Fungi_Bact_Value() {
		return null;
	}

	public HOQuotePage setArticleTypeValue() {
		return null;
	}

	public HOQuotePage setArticleDescValue() {
		return null;
	}

	public HOQuotePage setArticleValue() {
		return null;
	}

	// Get Methods

	private String getArticleTypeValue() {
		return null;
	}

	private String gettArticleDescValue() {
		return null;
	}

	private String getArticleValue() {
		return null;
	}
	
	private String getSelectedPolicyPaymentOption() {
		if(Boolean.parseBoolean(seleniumCommands.getAttributeValueAtLocator(ANNUAL_COST_RBTN_CSS, "aria-checked")))
		{
			return "Annual";
		}
		else if(Boolean.parseBoolean(seleniumCommands.getAttributeValueAtLocator(MONTHLY_COST_RBTN_CSS, "aria-checked")))
		{
			return "Monthly";
		}
		return null;
	}
	
	// Validations method

	public Validation isPaymentOptionSelectedEqualsTo(String paymentSelection)
	{
		return new Validation(getSelectedPolicyPaymentOption(), paymentSelection);
	}
	
	public Validation isArticleTypeValue_EqualsTo(String getArticleType) {
		return new Validation(getArticleTypeValue(), getArticleType);
	}

	public Validation isArticleDescValue_EqualsTo(String descValue) {
		return new Validation(gettArticleDescValue(), descValue);
	}
 
	public Validation isArticleValue_EqualsTo(String value) {
		return new Validation(getArticleValue(), value);
	}

	public Validation isQuoteisSaved(String quotenumber) {
		return new Validation(getArticleValue(), quotenumber);
	}

	public Validation isHOQuotePageLoaded() {
		logger.info("Validating HO quote page loading");
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeVisible(BUY_POLICY_BTN_CSS);
		new Validation(seleniumCommands.isElementPresent(BASE_MONTHLY_PREMIUM_COST_LBL_XPATH)).shouldBeTrue("Monthly quote value is displayed");
		selectBasePolicyAnnualOption();
		new Validation(seleniumCommands.isElementPresent(BASE_FULL_PREMIUM_COST_LBL_XPATH)).shouldBeTrue("Annual quote value is displayed");
		return new Validation(true);
	}

	public Validation validateQuotePageDefaultUI() throws Exception
	{
		isPaymentOptionSelectedEqualsTo("Monthly").shouldBeEqual("Payment option is not selected as default");
		
		return new Validation(true);
	}

	public void validateMandatoryFieldsOfScheduledPersonalProperty(QuoteScheduledPropertyItem scheduledType){
		for (int i=1; i<=scheduledType.getNumberOfMandatoryFileds(); i++){
			String errorMessage = seleniumCommands.findElement(By.xpath("(" + MANDATORY_FIELD_ERROR_MESSAGE+")["+i+"]")).getText();
			new Validation(errorMessage.equals(DataConstant.MANDATORY_ERROR_MSG )).shouldBeTrue("One of the mandatory field is has no missing error message");
		}
	}

	public void validateBuyNowButtonIsPresented(){
		new Validation(seleniumCommands.isElementVisible(BUY_NOW)).shouldBeTrue("Buy Now button is not clickable.");
	}

	public void validateRecalculateButtonIsPresented(){
		new Validation(seleniumCommands.isElementClickable(RECALCULATE_BUTTON)).shouldBeTrue("Recalculate Button is not clickable.");
	}

	public Validation validateHOQuotePageLayout() throws Exception {
		new Validation(seleniumCommands.isElementPresent(BASE_MONTHLY_PREMIUM_COST_LBL_XPATH))
				.shouldBeTrue("Monthly payment radio btn is not available");
		new Validation(seleniumCommands.isElementPresent(BASE_FULL_PREMIUM_COST_LBL_XPATH))
				.shouldBeTrue("Full payment radio btn is not available");
		new Validation(seleniumCommands.isElementPresent(MONTHLY_RDBTN_ID))
				.shouldBeTrue("Monthly payment radio btn is not selected");
		new Validation(seleniumCommands.getTextAtLocator(BUY_POLICY_BTN_CSS), DataConstant.BUY_NOW_BUTTON_TXT)
		.shouldBeEqual("Buy Now button text is not matched");
		return new Validation(true);
	}
	
	public HashMap<String, String> getCoverageDataFromUI() {
		policydata.put("ALL_OTHER_PERILS", getAllOtherPeril_Deduct_Value());
		policydata.put("HURRICANE_PERCENTAGE", getHurricanePercentage_DEDUCT_Value());
		policydata.put("WIND_HAIL_PERCENTAGE", getWindOrHailPercentage_DEDUCT_Value());
		policydata.put("HO_DWEL_LIMIT", getLimit_HO_DWEL_Value());
		policydata.put("HO_DWEL_DWEL_VALUATION_METHOD",getValuationMethod_HOME_DWEL_Value() );
		policydata.put("HO_OTR_STR_LIMIT%_DWEL_COVG",getLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value() );
		policydata.put("HO_PER_PROP_LIMIT%_DWEL_COVG",getLimitPercentageOFDwellingCoverage_HO_PER_PROP_Value() );
		policydata.put("HO_PER_PROP_VALUATION_METHOD",getValuationMethod_HO_PER_PROP_Value() );
		policydata.put("HO_PER_LIABILITY_LIMIT", getLiabilityLimit_HO_PER_LIAB_Value());
		policydata.put("HO_MED_PAY_LIMIT",getLimit_HO_MED_PAY_Value() );
		policydata.put("HO_ORD_LAW_LIMIT", getLimit_HO_ORD_LAW_Value());
		policydata.put("HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getLimitPercentageOFDwellingCoverage_HO_LOU_Value());
		policydata.put("ANNUAL_AMOUNT_AFTER_TAX_VALUE", seleniumCommands.getTextAtLocator(OFFERING_PRICE));
		selectBasePolicyMonthlyOption();
		policydata.put("MONTHLY_AMOUNT_AFTER_TAX_VALUE", seleniumCommands.getTextAtLocator(OFFERING_PRICE));
		
		return policydata;
	}

	public AccountSummaryPage goToAccountPage(){
		seleniumCommands.logInfo("Clicking Account link to cancel quote and to get to Account page");
		seleniumCommands.waitForElementToBeClickable(ACCOUNT_SUMMARY_LINK);
		seleniumCommands.clickbyJS(ACCOUNT_SUMMARY_LINK);
		new AlertHandler().closeAlert();
		return new AccountSummaryPage();
	}
	
}
