package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

public class HOCoverageDetailsPage extends CommonPage {
	HashMap<String, String> data = new HashMap<>();
	
	HashMap<String, String> policydata = new HashMap<>();
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();

	String PLATFORM = System.getProperty("platform");
	
	@FindBy(css = "td[title='All Other Perils']")
	 WebElement ALL_OTHER_PERIL_VALUE_CSS;
	
	@FindBy(css = "td[title='Hurricane Percentage']")
	 WebElement HURR_PERCENT_VALUE_CSS;
	
	@FindBy(css = "td[title='Wind or Hail Percentage']")
	 WebElement WIND_OR_HAIL_PERCENT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Homeowners Dwelling']/../following-sibling::tr/td[@title='Limit']")
	 WebElement HO_DWEL_LIMIT_VALUE_XPATH;
	
	@FindBy(xpath = "//*[@title='Homeowners Dwelling']/../following-sibling::tr/td[@title='Valuation Method']")
	 WebElement HO_DWELNG_VALUATION_METHOD_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Homeowners Other Structures']/../following-sibling::tr/td[@title='Limit - % of Dwelling Coverage']")
	 WebElement HO_OTH_STRUC_LIMIT_PERCENT_DWLNG_COVRG_VALUE_XPATH;
	
	@FindBy(css = "td[title='Limit - % of Dwelling Coverage']")
	 WebElement HO_PERS_PROP_LIMIT_PERCENT_DWLNG_COVRG_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Homeowners Personal Property']/../following-sibling::tr/td[@title='Valuation Method']")
	 WebElement HO_PERS_PROP_VALUATION_METHOD_VALUE_XPATH;
	
	@FindBy(xpath = "//tbody[@ng-repeat][5]/tr[@ng-repeat]/td[@title] | //tbody[@ng-repeat][6]/tr[@ng-repeat]/td[@title]")
	 WebElement HO_LOSS_OF_USE_LIMIT_DWEL_VALUE_XPATH;
	
	@FindBy(css = "[title='Liability Limit']")
	 WebElement HO_PERS_LIBILITY_LIMIT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Homeowners Medical Payments']/../following-sibling::tr/td[@title='Limit']")
	 WebElement HO_MED_PAYMENT_LIMIT_VALUE_XPATH;
	
	@FindBy(css = "td[title='Homeowners Ordinance Or Law']")
	 WebElement HO_ORDIDENCE_OR_LAW_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Homeowners Ordinance Or Law']/../following-sibling::tr/td[@title='Limit']")
	 WebElement HO_ORDIDENCE_OR_LAW_LIMIT_VALUE_XPATH;
	
	@FindBy(css = "td[title='Section I Limit']")
	 WebElement FUNGIWET_BACT_SECTION_1_LIMIT_VALUE_CSS;
	
	@FindBy(css = "td[title='Section II Aggregate Limit']")
	 WebElement FUNGIWET_BACT_SECTION_2_AGG_LIMIT_VALUE_CSS;
	
	@FindBy(css = "[value='fullTerm'] + label span")
	 WebElement MONTHLY_QUOTE_VALUE_AFTER_TAX_CSS;
	
	@FindBy(css = "[value='monthly'] + label span")
	 WebElement ANNUAL_QUOTE_VALUE_AFTER_TAX_CSS;
	
	@FindBy(css = "[class='gw-coverage-header'] span:nth-of-type(2)")
	 WebElement ANNUAL_QUOTE_VALUE_BEFORE_TAX_CSS;
	
	@FindBy(css = "div[ng-repeat*='cell in row'], [ng-repeat='term in coverage.terms'], [ng-repeat*='cell in row track by $index']")
	 List<WebElement> COV_ELEMENT_LIST;
	
	@FindBy(css = "[ng-repeat*='cov in additionalCoverages']")
	 List<WebElement> ADD_COV_ELEMENT_LIST;
	
	By QUOTE_BTN =  By.cssSelector("[ng-click*='ctrl.recalculate']");
	
	By QUOTE_CONFIRMATION_CSS =  By.cssSelector("[class*='confirmation']");
	
	
	private static final String COV_NAME_XPATH = "./div[contains(@class,'termName')]";
	
	private static final String COV_AMOUNT_XPATH = "./div[contains(@class,'Amount')]";


	@FindBy(css = "[coverages*='baseCoverages']>div")
	List<WebElement> READONLY_COV_ELEMENT_LIST;

	
	public HOCoverageDetailsPage()
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public HOCoverageDetailsPage(HashMap<String, String> data)
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}
	
	public String getAnnualBeforeTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(ANNUAL_QUOTE_VALUE_BEFORE_TAX_CSS);
	}
	
	public String getAnnualAfterTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(ANNUAL_QUOTE_VALUE_AFTER_TAX_CSS);
	}
	
	public String getMonthlyAfterTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(MONTHLY_QUOTE_VALUE_AFTER_TAX_CSS);
	}
	
	private String getCoverageValue(String covName, WebElement covElement) {
		if(seleniumCommands.isElementPresent(QUOTE_CONFIRMATION_CSS))
		{
				return seleniumCommands.getTextAtLocator(covElement .findElement(By.cssSelector("td[title*='"+covName+"']")));
		}
		String covTxt = covElement .findElement(By.xpath(COV_NAME_XPATH)).getText();
		if(covTxt.equals(covName))
		{
			return seleniumCommands.getTextAtLocator(covElement .findElement(By.xpath(COV_AMOUNT_XPATH)));
		}
		return null;
	}
	
	public String getAllOtherPeril_Deduct_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			if(PLATFORM.equalsIgnoreCase("granite")) {
				return getSelectedCoverage(COV_ELEMENT_LIST.get(1), 0);
			} else {
				return getSelectedCoverage(COV_ELEMENT_LIST.get(2), 0);
			}
		}
		if(PLATFORM.equalsIgnoreCase("granite")) {
			return getCoverageValue("All Perils", COV_ELEMENT_LIST.get(4));
		} else {
			return getCoverageValue("All Other Perils", COV_ELEMENT_LIST.get(3));
		}
	}

	public String getAllOtherPeril_Deduct_Value_Granite() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(1), 0);
		} else {
			return getCoverageValue("All Perils", COV_ELEMENT_LIST.get(4));
		}
	}

	public String getHurricanePercentage_DEDUCT_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(2), 1);
		}
		return getCoverageValue("Hurricane Percentage", COV_ELEMENT_LIST.get(4));
	}

	public String getWindOrHailPercentage_DEDUCT_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(2), 2);
		}
		return getCoverageValue("Wind or Hail Percentage", COV_ELEMENT_LIST.get(5));
	}

	public String getLimit_HO_DWEL_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return seleniumCommands.getValueAttributeFromLocator( COV_ELEMENT_LIST.get(3).findElement(By.xpath(".//input[@type='number']")));
		}
		return getCoverageValue("Limit", COV_ELEMENT_LIST.get(6));
	}

	public HOCoverageDetailsPage setInowLimit_HO_DWEL_Value(String value) {

		seleniumCommands.type(COV_ELEMENT_LIST.get(0).findElement(By.xpath(".//input[@type='number']")), value);
		seleniumCommands.selectFromDropdownByIndex(COV_ELEMENT_LIST.get(4).findElement(By.xpath(".//select")), 2);
		return this;
	}

	public String getInowLimit_HO_DWEL_Value() {

		return seleniumCommands.getValueAttributeFromLocator( COV_ELEMENT_LIST.get(0).findElement(By.xpath(".//input[@type='number']")));
	}

	public String getInowLimit_HO_OTHER_STRUCTURES_Value() {

		return seleniumCommands.getValueAttributeFromLocator( COV_ELEMENT_LIST.get(1).findElement(By.xpath(".//input[@type='number']")));
	}

	public String getInowLimit_HO_PERSONAL_PROPERTY_Value() {

		return seleniumCommands.getValueAttributeFromLocator( COV_ELEMENT_LIST.get(2).findElement(By.xpath(".//input[@type='number']")));
	}

	public String getInowLimit_HO_LOSS_OF_USE_Value() {

		return seleniumCommands.getValueAttributeFromLocator( COV_ELEMENT_LIST.get(3).findElement(By.xpath(".//input[@type='number']")));
	}

	public String getInowLimit_HO_LIABILITY_Value() {

		return seleniumCommands.getSelectedOptionFromDropDown(COV_ELEMENT_LIST.get(4).findElement(By.xpath(".//select")));
	}

	public String getInowLimit_HO_MEDICAL_PAYMENTS_Value() {

		return seleniumCommands.getSelectedOptionFromDropDown( COV_ELEMENT_LIST.get(5).findElement(By.xpath(".//select")));
	}

	public String getInow_HO_PACKAGE_COVERAGE_Value() {

		return seleniumCommands.getSelectedOptionFromDropDown( COV_ELEMENT_LIST.get(6).findElement(By.xpath(".//select")));
	}

	public String getInowReadOnlyLimit_HO_DWEL_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(0).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnlyLimit_HO_OTHER_STRUCTURES_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(1).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnlyLimit_HO_PERSONAL_PROPERTY_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(2).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnlyLimit_HO_LOSS_OF_USE_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(3).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnlyLimit_HO_LIABILITY_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(4).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnlyLimit_HO_MEDICAL_PAYMENTS_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(5).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getInowReadOnly_HO_PACKAGE_COVERAGE_Value() {

		return seleniumCommands.getTextAtLocator( READONLY_COV_ELEMENT_LIST.get(6).findElement(By.xpath(".//div[contains(@class, '__termAmount__')]")));
	}

	public String getValuationMethod_HOME_DWEL_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(3) , 0);
		}
		return getCoverageValue("Valuation Method", COV_ELEMENT_LIST.get(7));
	}

	public String getLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(1), 0);
		}
			return getCoverageValue("Limit - % of Dwelling Coverage", COV_ELEMENT_LIST.get(2));
	}

	public String getLimitPercentageOFDwellingCoverage_HO_PER_PROP_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(0) , 0);
		}
		return getCoverageValue("Limit - % of Dwelling Coverage", COV_ELEMENT_LIST.get(0));
	}

	public String getValuationMethod_HO_PER_PROP_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(0), 1);
		}
		return getCoverageValue("Valuation Method", COV_ELEMENT_LIST.get(1));
	}

	public String getLimitPercentageOFDwellingCoverage_HO_LOU_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(4), 0);
		}
		if(PLATFORM.equalsIgnoreCase("granite")) {
			return getCoverageValue("Limit - % of Dwelling Coverage", COV_ELEMENT_LIST.get(11));
		} else {
			return getCoverageValue("Limit - % of Dwelling Coverage", COV_ELEMENT_LIST.get(8));
		}
	}

	public String getLiabilityLimit_HO_PER_LIAB_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(5), 0);
		}
		return getCoverageValue("Liability Limit", COV_ELEMENT_LIST.get(9));
	}

	public String getLimit_HO_MED_PAY_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(6), 0);
		}
		if(PLATFORM.equalsIgnoreCase("granite")) {
			return getCoverageValue("Limit", COV_ELEMENT_LIST.get(19));
		} else {
			return getCoverageValue("Limit", COV_ELEMENT_LIST.get(10));
		}
		
	}

	public String getPersonalInjury() {
		return null;
	}

	public String getLimit_HO_ORD_LAW_Value() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(COV_ELEMENT_LIST.get(8), 0);
		} else if(seleniumCommands.isElementPresent(QUOTE_CONFIRMATION_CSS)) {
			
			return getCoverageValue("Limit", ADD_COV_ELEMENT_LIST.get(0));
		}
		else
		{
			return getCoverageValue("Limit", COV_ELEMENT_LIST.get(11));
		}
	}

	public String get_HO_ORD_LAW_Value() {
			return seleniumCommands.getTextAtLocator(HO_ORDIDENCE_OR_LAW_VALUE_CSS);
	}

	public String getLimitedFungiBact() {
		return null;
	}

	public String getLimit_Fungi_Bact_SEC1_Value() {
		return getCoverageValue("Section I Limit", COV_ELEMENT_LIST.get(13));
	}

	public String getAggregateLimit_Fungi_Bact_SEC2_Value() {
		return getCoverageValue("Section II Aggregate Limit", COV_ELEMENT_LIST.get(14));
	}
	
	public HashMap<String, String> getCoverageDataFromUI() {
		policydata.put("ALL_OTHER_PERILS", getAllOtherPeril_Deduct_Value());
		policydata.put("HURRICANE_PERCENTAGE", getHurricanePercentage_DEDUCT_Value());
		policydata.put("WIND_HAIL_PERCENTAGE", getWindOrHailPercentage_DEDUCT_Value());
		policydata.put("HO_DWEL_LIMIT", getLimit_HO_DWEL_Value());
		policydata.put("HO_DWEL_DWEL_VALUATION_METHOD",getValuationMethod_HOME_DWEL_Value() );
		policydata.put("HO_OTR_STR_LIMIT%_DWEL_COVG",getLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value() );
		policydata.put("HO_PER_PROP_LIMIT%_DWEL_COVG",getLimitPercentageOFDwellingCoverage_HO_PER_PROP_Value() );
		policydata.put("HO_PER_PROP_VALUATION_METHOD",getValuationMethod_HO_PER_PROP_Value() );
		policydata.put("HO_PER_LIABILITY_LIMIT", getLiabilityLimit_HO_PER_LIAB_Value());
		policydata.put("HO_MED_PAY_LIMIT",getLimit_HO_MED_PAY_Value() );
		policydata.put("HO_ORD_LAW_LIMIT", getLimit_HO_ORD_LAW_Value());
		policydata.put("HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getLimitPercentageOFDwellingCoverage_HO_LOU_Value());
		return policydata;
	}

	public HashMap<String, String> getCoverageDataFromUI_Granite() {
		policydata.put("ALL_OTHER_PERILS", getAllOtherPeril_Deduct_Value_Granite());
		policydata.put("HO_DWEL_LIMIT", getLimit_HO_DWEL_Value());
		policydata.put("HO_MED_PAY_LIMIT",getLimit_HO_MED_PAY_Value() );
		return policydata;
	}

	public HashMap<String, String> getInowCoverageDataFromUI() {
		policydata.put("HO_DWEL_LIMIT", getInowLimit_HO_DWEL_Value());
		policydata.put("HO_OTR_STR_LIMIT%_DWEL_COVG", getInowLimit_HO_OTHER_STRUCTURES_Value());
		policydata.put("HO_PER_PROP_LIMIT%_DWEL_COVG", getInowLimit_HO_PERSONAL_PROPERTY_Value());
		policydata.put("HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getInowLimit_HO_LOSS_OF_USE_Value());
		policydata.put("HO_LIABILITY_LIMIT", getInowLimit_HO_LIABILITY_Value());
		policydata.put("HO_MED_PAY_LIMIT",getInowLimit_HO_MEDICAL_PAYMENTS_Value());
		policydata.put("HO_PACKAGE_COVERAGE_VALUE",getInow_HO_PACKAGE_COVERAGE_Value());
		return policydata;
	}

	public HashMap<String, String> getInowReadOnlyCoverageDataFromUI() {
		policydata.put("HO_DWEL_LIMIT", getInowReadOnlyLimit_HO_DWEL_Value());
		policydata.put("HO_OTR_STR_LIMIT%_DWEL_COVG", getInowReadOnlyLimit_HO_OTHER_STRUCTURES_Value());
		policydata.put("HO_PER_PROP_LIMIT%_DWEL_COVG", getInowReadOnlyLimit_HO_PERSONAL_PROPERTY_Value());
		policydata.put("HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getInowReadOnlyLimit_HO_LOSS_OF_USE_Value());
		policydata.put("HO_LIABILITY_LIMIT", getInowReadOnlyLimit_HO_LIABILITY_Value());
		policydata.put("HO_MED_PAY_LIMIT",getInowReadOnlyLimit_HO_MEDICAL_PAYMENTS_Value());
		policydata.put("HO_PACKAGE_COVERAGE_VALUE",getInowReadOnly_HO_PACKAGE_COVERAGE_Value());
		return policydata;
	}
	
	private String getSelectedCoverage(WebElement element)
	{
		try{
			return seleniumCommands.getSelectedOptionFromDropDown(element.findElement(By.xpath(".//select")));
		}
		catch(NoSuchElementException e)
		{
			return null;
		}
	}
	
	private String getSelectedCoverage(WebElement element, int selectIndex)
	{
		try{
			return seleniumCommands.getSelectedOptionFromDropDown(element.findElements(By.xpath(".//select")).get(selectIndex));
		}
		catch(NoSuchElementException e)
		{
			return null;
		}
	}
	
	private String getCoverageTextValue(WebElement element)
	{
		try{
			return seleniumCommands.getValueAttributeFromLocator(element.findElement(By.xpath(".//input")));
		}
		catch(NoSuchElementException e)
		{
			return null;
		}
	}

	// Validation

	public Validation isAllOtherPerilValueEqualsTO(String parilvalue) {
		return new Validation(getAllOtherPeril_Deduct_Value(), parilvalue);
	}

	public Validation isHurricanePercentageValueEqualsTo(String hurricanePercentage) {
		return new Validation(getHurricanePercentage_DEDUCT_Value(), hurricanePercentage);
	}

	public Validation isWindOrHailPercentageValueEqualsTo(String windOrHailPercentage) {
		return new Validation(getWindOrHailPercentage_DEDUCT_Value(), windOrHailPercentage);
	}

	public Validation isLimitValue_EqualsTo(String getLimit) {
		return new Validation(getLimit_HO_DWEL_Value(), getLimit);
	}

	public Validation isValuationMethodValue_EqualsTo(String valuationMethod) {
		return new Validation(getValuationMethod_HOME_DWEL_Value(), valuationMethod);
	}

	public Validation isLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value(String limitePerecntageValue) {
		return new Validation(getLimitPercentageOFDwellingCoverage_HO_OTR_STRU_Value(), limitePerecntageValue);
	}

	public Validation isLimitPercentageOFDwellingCoverage_HO_PER_PROP_Value_EqualsTo(String limitPercentage) {
		return new Validation(getLimitPercentageOFDwellingCoverage_HO_PER_PROP_Value(), limitPercentage);
	}

	public Validation isValuationMethod_HO_PER_PROP_Value_EqualsTo(String valuationMethod) {
		return new Validation(getValuationMethod_HO_PER_PROP_Value(), valuationMethod);
	}

	public Validation isLimitPercentageOFDwellingCoverage_HO_LOU_ValueEqualsTo(String limitPercentage) {
		return new Validation(getLimitPercentageOFDwellingCoverage_HO_LOU_Value(), limitPercentage);
	}

	public Validation isLiabilityLimit_HO_PER_LIAB_Value_EqualsTo(String liabilityLimit) {
		return new Validation(getLiabilityLimit_HO_PER_LIAB_Value(), liabilityLimit);
	}

	public Validation isLimit_HO_MED_PAY_Value_EqualsTo(String getLimit) {
		return new Validation(getLimit_HO_MED_PAY_Value(), getLimit);
	}

	public Validation isPersonalInjury_Selected(boolean selection) {
		return new Validation(getPersonalInjury(), selection);
	}

	public Validation isLimit_HO_ORD_LAW_Value_EqualsTo(String limit) {
		return new Validation(getLimit_HO_ORD_LAW_Value(), limit);
	}

	public Validation isLimitedFungiBact_Selected(boolean selection) {
		return new Validation(getLimitedFungiBact(), selection);
	}

	public Validation isLimit_Fungi_Bact_Value_EqualsTo(String limit) {
		return new Validation(getLimit_Fungi_Bact_SEC1_Value(), limit);
	}

	public Validation isAggregateLimit_Fungi_Bact_Value_EqualsTo(String aggregateLimit) {
		return new Validation(getAggregateLimit_Fungi_Bact_SEC2_Value(), aggregateLimit);
	}

	public Validation areHOQuoteBaseCoverageDataMatchingWithBackEnd() throws Exception
	{
		if(!PLATFORM.equalsIgnoreCase("Granite")) {
			return MapCompare.compareMap(getCoverageDataFromUI(), ParseQuoteData.getHOBaseCoverageDataFromBackEnd(DataFetch.getQuoteAsJsonData()));
		} else {
			return MapCompare.compareMap(getCoverageDataFromUI_Granite(), ParseQuoteData.getHOBaseCoverageDataFromBackEnd(DataFetch.getQuoteAsJsonData()));
		}
	}

	public Validation areInowHOQuoteBaseCoverageDataMatchingWithBackEnd() throws Exception
	{
		return MapCompare.compareMap(getInowCoverageDataFromUI(), ParseQuoteData.getInowHOBaseCoverageDataFromBackEnd(DataFetch.getINowQuoteAsJsonData()));
	}

	public Validation areInowReadOnlyHOQuoteBaseCoverageDataMatchingWithBackEnd() throws Exception
	{
		return MapCompare.compareMap(getInowReadOnlyCoverageDataFromUI(), ParseQuoteData.getInowHOBaseCoverageDataFromBackEnd(DataFetch.getINowQuoteAsJsonData()));
	}
	
	public Validation areHOQuoteBaseCoverageDataMatchingWithBackEnd(String jsonData) throws Exception
	{
		return MapCompare.compareMap(getCoverageDataFromUI(), ParseQuoteData.getHOBaseCoverageDataFromBackEnd(jsonData));
	}
}
