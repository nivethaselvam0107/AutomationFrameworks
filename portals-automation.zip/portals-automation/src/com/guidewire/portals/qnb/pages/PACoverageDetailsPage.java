package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;

public class PACoverageDetailsPage {
	HashMap<String, String> data = new HashMap<>();
	
	HashMap<String, String> policydata = new HashMap<>();
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	//BASE Policy Only
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Liability - Bodily Injury and Property Damage']")
	 WebElement LIABILITY_BODILY_INJURY_PROP_DAMAGE_VALUE_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Auto Liability Package']")
	 WebElement AUTO_LIABILITY_PACKAGE_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Auto Liability Package']/..//select")
	 WebElement AUTO_LIABILITY_PACKAGE_DROP_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Medical Payments']")
	 WebElement MEDICAL_PAYMENT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Medical Payments']/..//input")
	 WebElement MEDICAL_PAYMENT_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Medical Limit']")
	 WebElement MEDICAL_LIMIT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Medical Limit']/..//select")
	 WebElement MEDICAL_LIMIT_DROP_XPATH;
	
	//To find multiple Vehicle
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [ng-repeat='vehicle in model.vehicleCoverages']")
	 WebElement VEHICLE_COV_HEADER_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Mexico Coverage - Limited']/..//input")
	 WebElement MEXICO_COV_LIMIT_CKB_XPATH;
	
	// Standard & Premium only
	@FindBy(xpath = "//*[@title='Underinsured Motorist - Property Damage']/..//input")
	 WebElement UNINSURED_MOTORIST_PROP_DAMAGE_CKB_XPATH;
	
	@FindBy(xpath = "//*[@title='Uninsured Motorist - Bodily Injury']/..//input")
	 WebElement UNINSURED_MOTORIST_BODILY_INJURY_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Uninsured Motorist - Bodily Injury']")
	 WebElement UNINSURED_MOTORIST_BODILY_INJURY_VALUE_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Uninsured Motorist - BI Limits']")
	 WebElement UNINSURED_MOTORIST_BI_LIMIT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Uninsured Motorist - BI Limits']/..//select")
	 WebElement UNINSURED_MOTORIST_BI_LIMIT_DROP_XPATH;
	
	//Custom Coverage
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Rental Reimbursement']")
	 WebElement RENTAL_REIMBURSMENT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Rental Reimbursement']/..//input")
	 WebElement RENTAL_REIMBURSMENT_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Rental Package']")
	 WebElement RENTAL_PACKAGE_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Rental Package']/..//select")
	 WebElement RENTAL_PACKAGE_DROP_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Collision']")
	 WebElement COLLISION_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Collision']/..//input")
	 WebElement COLLISION_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Collision Deductible']")
	 WebElement COLLISION__DEDUCT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Collision Deductible']/..//select")
	 WebElement COLLISION__DEDUCT_DROP_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Towing and Labor']")
	 WebElement TOWING_LABOUR_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Towing and Labor']/..//input")
	 WebElement TOWING_LABOUR_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Towing and Labor Limit']")
	 WebElement TOWING_LABOUR_LIMIT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Towing and Labor Limit']/..//select")
	 WebElement TOWING_LABOUR_LIMIT_DROP_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Comprehensive']")
	 WebElement COMPREHENSIVE_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Comprehensive']/..//input")
	 WebElement COMPREHENSIVE_CKB_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [title='Comprehensive Deductible']")
	 WebElement COMPREHENSIVE_DEDUCT_VALUE_CSS;
	
	@FindBy(xpath = "//*[@title='Towing and Labor Limit']/..//select")
	 WebElement COMPREHENSIVE_DEDUCT_DROP_XPATH;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [class='panel-item custom-quote'] [value='monthly']")
	 WebElement CUSTOM_MONTHLY_PREMIUM_COST_RBTN_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [class='panel-item custom-quote'] [value='fullTerm']")
	 WebElement CUSTOM_FULL_PREMIUM_COST_RBTN_CSS;
	
	@FindBy(css = "[class='fa fa-3x fa-calculator']")
	 WebElement CUSTOM_POLICY_CALCULATOR_CSS;
	
	@FindBy(css = "[class='panel-item custom-quote'] button[ng-click='buyQuote()'])")
	 WebElement BUY_CUSTOM_POLICY_BTN_CSS;
	
	@FindBy(css = "ul[class*='gw-nav']  li:nth-of-type(4)")
	 WebElement CUSTOM_POLICY_TILE_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [value='fullTerm'] + label span")
	 WebElement MONTHLY_QUOTE_VALUE_CSS;
	
	@FindBy(css = "[class='gw-tab-pane ng-scope gw-active'] [value='monthly'] + label span")
	 WebElement ANNUAL_QUOTE_VALUE_CSS;
	
	@FindBy(css = "[class*='gw-tab-pane ng-scope gw-active'] [ng-repeat*='_coverage'] [class*='name']")
	 List<WebElement> COV_AMT_ELEMENT_LIST;
	
	@FindBy(css = "[class*='gw-tab-pane ng-scope gw-active'] [ng-repeat*='_coverage'] [class*='termName']")
	 List<WebElement> COV_TERM_ELEMENT_LIST;
			
	String RECALCULATING_MESSAGE_CSS = "[ng-show='quoteStatus.calculatingQuote']";
	
		
	public PACoverageDetailsPage()
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public PACoverageDetailsPage(HashMap<String, String> data)
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}

	//Set Methods
	
	public PACoverageDetailsPage configureCustomQuote()
	{
		setUnderInsuredMotoristBodilyInjuryLimit();
		this.waitForCustomQuoteChangesToBeApplied();
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristPropertyDamage()
	{
		seleniumCommands.selectCheckBoxOrRadioBtn(UNINSURED_MOTORIST_PROP_DAMAGE_CKB_XPATH, Boolean.valueOf(data.get("UNI_MOT_PROP_DAMAGE")));
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristPropertyDamage(boolean value)
	{
		seleniumCommands.selectCheckBoxOrRadioBtn(UNINSURED_MOTORIST_PROP_DAMAGE_CKB_XPATH, value);
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristBodilyInjury()
	{
		seleniumCommands.selectCheckBoxOrRadioBtn(UNINSURED_MOTORIST_BODILY_INJURY_CKB_XPATH, Boolean.valueOf(data.get("UNI_MOT_BOD_INJURY")));
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristBodilyInjury(boolean value)
	{
		seleniumCommands.selectCheckBoxOrRadioBtn(UNINSURED_MOTORIST_BODILY_INJURY_CKB_XPATH, value);
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristBodilyInjuryLimit()
	{
		seleniumCommands.selectDropDownValueByText(UNINSURED_MOTORIST_BI_LIMIT_DROP_XPATH, data.get("UNI_MOT_BOD_INJURY_LIMIT"));
		return this;
	}
	
	public PACoverageDetailsPage setUnderInsuredMotoristBodilyInjuryLimit(String value)
	{
		seleniumCommands.selectDropDownValueByText(UNINSURED_MOTORIST_BI_LIMIT_DROP_XPATH, value);
		return this;
	}
	
	public PACoverageDetailsPage setMexicoCoverage(boolean value)
	{
		seleniumCommands.selectCheckBoxOrRadioBtn(MEXICO_COV_LIMIT_CKB_XPATH, value);
		return this;
	}
	
	public PACoverageDetailsPage setMexicoCoverage()
	{
		seleniumCommands.selectDropDownValueByText(MEXICO_COV_LIMIT_CKB_XPATH, data.get("MEXICO_COV"));
		return this;
	}
	
	private PACoverageDetailsPage selectCustomPolicyAnnualPaymentOption() {
		CUSTOM_FULL_PREMIUM_COST_RBTN_CSS.click();
		return this;
	}

	private PACoverageDetailsPage selectCustomPolicyMonthlyOption() {
		CUSTOM_MONTHLY_PREMIUM_COST_RBTN_CSS.click();
		return this;
	}
	

	public PACoverageDetailsPage buyCustomPolicyWithAnnualPayment() {
		this.openCustomPolicyView();
		this.selectCustomPolicyAnnualPaymentOption();
		BUY_CUSTOM_POLICY_BTN_CSS.click();
		return this;
	}
	
	public PACoverageDetailsPage buyCustomPolicyWithMonthlyPayment() {
		this.openCustomPolicyView();
		this.selectCustomPolicyMonthlyOption();
		BUY_CUSTOM_POLICY_BTN_CSS.click();
		return this;
	}
	
	public PACoverageDetailsPage openCustomPolicyView() {
		CUSTOM_POLICY_TILE_CSS.click();
		return this;
	}
	
	public PACoverageDetailsPage reCalculatePolicyPremium() {
		CUSTOM_POLICY_CALCULATOR_CSS.click();
		return this;
	}
	
	private PACoverageDetailsPage waitForCustomQuoteChangesToBeApplied()
	{
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("RECALCULATING_MESSAGE_CSS"));
		seleniumCommands.waitForElementToBeHidden(By.cssSelector("RECALCULATING_MESSAGE_CSS"));
		return this;
	}
	
	
	// Get Methods
	
	private String getCoverageAmount(String covName) {
		WebElement element = COV_AMT_ELEMENT_LIST.stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).contains(covName)).findAny().get();
		String amt = element.findElement(By.xpath(".//span")).getText();
		seleniumCommands.logInfo("Amount for covarege '"+ covName + "' is -> " + amt);
		return amt;
	}
	
	private boolean getCoverageName(String covName) {
		return COV_AMT_ELEMENT_LIST.stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).equals(covName)).findAny().isPresent();
	}
	
	private String getCoverageTermValue(String covName) {
		WebElement element = COV_TERM_ELEMENT_LIST.stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).contains(covName)).findAny().get();
		String termValue = element.findElement(By.xpath("./following-sibling::div[contains(@class,'termAmount')]")).getText();
		seleniumCommands.logInfo("Term value for covarege '"+ covName + "' is -> " + termValue);
		return termValue;
	}
	
	public String getMonthlyQuoteValue() {
		return seleniumCommands.getTextAtLocator(MONTHLY_QUOTE_VALUE_CSS);
	}
	
	public String getAnnualQuoteValue() {
		return seleniumCommands.getTextAtLocator(ANNUAL_QUOTE_VALUE_CSS);
	}
	
	public String getLIabilityBodilyINPropDamage_Value() {
		return getCoverageAmount("Liability - Bodily Injury and Property Damage");
	}

	public String getAutoLiabilityPackage_Value() {
		return getCoverageTermValue("Auto Liability Package");
	}

	public String getMedicalPayments_Value() {
		return getCoverageAmount("Medical Payments");
	}
	
	public String getMedicalLimits_Value() {
		return getCoverageTermValue("Medical Limit");
	}

	public String getUninsuredMotoristBI_Value() {
		return getCoverageAmount("Uninsured Motorist - Bodily Injury");
	}

	public String getUninsuredMotoristBI_Limits_Value() {
		return getCoverageTermValue("Uninsured Motorist - BI Limits");
	}
	
	public String getRentalReimbursment_Value() {
		return getCoverageAmount("Rental Reimbursement");
	}
	
	public String getRentalPackage_Value() {
		return getCoverageTermValue("Rental Package");
	}
	
	public String getCollision_Value() {
		return getCoverageAmount("Collision");
	}
	
	public String getCollisionDeductLimit_Value() {
		return getCoverageTermValue("Collision Deductible");
	}
	
	public String getTowingAndLabor_Value() {
		return getCoverageAmount("Towing and Labor");
	}
	
	public String getTowingAndLaborLimit_Value() {
		return getCoverageTermValue("Towing and Labor Limit");
	}
	
	public String getComprehensive_Value() {
		return getCoverageAmount("Comprehensive");
	}
	
	public String getComprehensiveDeduct_Value() {
		return getCoverageTermValue("Comprehensive Deductible");
	}
	
	
	public HashMap<String, String> getBasicCoverageDataFromUI() {
		policydata.clear();
		policydata.put("LiabilityBodilyPropDamage", getLIabilityBodilyINPropDamage_Value());
		policydata.put("AutoLiabilityPackage", getAutoLiabilityPackage_Value());
		policydata.put("MedicalPayment", getMedicalPayments_Value());
		policydata.put("MedicalLimit", getMedicalLimits_Value());
		policydata.put("QUOTE_ANNUAL_VALUE", getAnnualQuoteValue());
		policydata.put("QUOTE_MONTHLY_VALUE", getMonthlyQuoteValue());
		return policydata;
	}
	
	public HashMap<String, String> getStandardOrPremiumCoverageDataFromUI() {

		policydata.clear();
		policydata.putAll(this.getBasicCoverageDataFromUI());
		policydata.put("UninsuredMotoristBI", getUninsuredMotoristBI_Value());
		policydata.put("UninsuredMotoristBILimit", getUninsuredMotoristBI_Limits_Value());
		policydata.put("RentalReimbursement", getRentalReimbursment_Value());
		policydata.put("RentalPackage", getRentalPackage_Value());
		policydata.put("CollisionDeductible", getCollisionDeductLimit_Value());
		policydata.put("Collision", getCollision_Value());
		policydata.put("TowingAndLabor", getTowingAndLabor_Value());
		policydata.put("TowingAndLaborLimit", getTowingAndLaborLimit_Value());
		policydata.put("Comprehensive", getComprehensive_Value());
		policydata.put("ComprehensiveDeductible", getComprehensiveDeduct_Value());
		return policydata;
	}
	
	public HashMap<String, String> getPremiumCoverageDataFromUI() {

		policydata.clear();
		policydata.putAll(this.getBasicCoverageDataFromUI());
		policydata.put("UninsuredMotoristBI", getUninsuredMotoristBI_Value());
		policydata.put("UninsuredMotoristBILimit", getUninsuredMotoristBI_Limits_Value());
		policydata.put("RentalReimbursement", getRentalReimbursment_Value());
		policydata.put("RentalPackage", getRentalPackage_Value());
		policydata.put("Collision", getCollision_Value());
		policydata.put("CollisionDeductible", getCollisionDeductLimit_Value());
		policydata.put("Collision", getCollision_Value());
		policydata.put("CollisionDeductible", getCollisionDeductLimit_Value());
		policydata.put("TowingAndLabor", getTowingAndLabor_Value());
		policydata.put("TowingAndLaborLimit", getTowingAndLaborLimit_Value());
		policydata.put("Comprehensive", getComprehensive_Value());
		policydata.put("ComprehensiveDeductible", getComprehensiveDeduct_Value());
		return policydata;
	}

	// Validation - Not Defined yet


}
