package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import com.guidewire.widgetcomponents.Button;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.locators.YourHomePageLocators;

public class ZipCodePage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	 @FindBy(id = "PostalCodeNew")
	 WebElement ZIPCODE_TXT_ID;
	 
	 @FindBy(xpath = "//*[contains(@src,'personalauto.svg')]/ancestor::gw-available-products-and-features//input")
	 WebElement PA_ZIPCODE_TXT_ID;
	 
	 @FindBy(xpath = "//*[contains(@src,'homeowners.svg')]/ancestor::gw-available-products-and-features//input")
	 WebElement HO_ZIPCODE_TXT_ID;
	
	 By BOP_ZIPCODE_TXT_ID = By.cssSelector("[gw-test-quoteandbind-common-directives-ProductZipCodeContainer] input");

	 @FindBy(xpath = "//*[contains(@src,'homeowners.svg')]/ancestor::gw-available-products-and-features//a[contains(@ng-click, 'startQuote')]")

	 WebElement HO_START_QUOTE_BTN_XPATH;

	By START_QUOTE_BTNS = By.cssSelector("[gw-test-quoteandbind-common-directives-productzipcodecontainer-start_quote_button]");

	@FindBy(xpath = "//*[contains(@src,'personalauto.svg')]/ancestor::gw-available-products-and-features//a[contains(@ng-click, 'startQuote')]")
	WebElement PA_START_QUOTE_BTN_XPATH;
	
	By BOP_START_QUOTE_BTN = By.cssSelector("[gw-test-quoteandbind-common-directives-ProductZipCodeContainer-start_quote_button]");
	 
	 @FindBy(xpath = "//*[contains(@src,'personalauto.svg')]/ancestor::gw-available-products-and-features//div[contains(@class, 'gw-error')]")
	 WebElement PA_ZIPCODE_ERROR_XPATH;
	 
	 @FindBy(xpath = "//*[contains(@src,'homeowners.svg')]/ancestor::gw-available-products-and-features//div[contains(@class, 'gw-error')]")
	 WebElement HO_ZIPCODE_ERROR_XPATH;

	By BOP_ZIPCODE_ERROR_CSS = By.cssSelector("[gw-test-quoteandbind-common-directives-ProductZipCodeContainer] .gw-error");
	 
	 @FindBy(className = "gw-lob-type")
	 WebElement LOB_CLASSNAME ;
	 
	 @FindBy(xpath = "//*[@class='gw-lob-type']/div[1]")
	 WebElement VEHICLE_POLICY_BTN_XPATH ;
	   
	 @FindBy(xpath = "//*[@class='gw-lob-type']/div[2]")
	 WebElement HOME_POLICY_BTN_XPATH ;
	   
	 @FindBy(xpath = "//button[contains(@ng-click, 'goToNewQuote(form)')]")
	 WebElement GO_BTN_XPATH ;
	 
	 @FindBy(css = "[ng-click='activateItemRetrieval()']")
	 WebElement RETRIVE_LINK_CSS ;
	 
	 @FindBy(id = "PostalCodeRetrieve")
	 WebElement ZIPCODE_RETRIVE_TXT_ID;
	 
	 @FindBy(id = "QuoteIDRetrieve")
	 WebElement QUOTEID_RETRIVE_TXT_ID;
	 
	 @FindBy(xpath = "//button[contains(@ng-click, 'goToRetrieveQuote(form)')]")
	 WebElement GO_RETRIVE_BTN_XPATH ;

	@FindBy(css = "[href='#paquickQuote']")
	WebElement QUICK_QUOTE_LINK_CSS;

	@FindBy(css = "[gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_right_label]")
	WebElement BUSINESS_CSS;

	By GO_TO_GUIDANCE_PAGE_BUTTON = By.cssSelector("a[href='#guidanceproduct']");

	public ZipCodePage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public ZipCodePage(Object obj) {
		
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public ZipCodePage goNext() {
		if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.HO))
		{
			if (ThreadLocalObject.getBrowserName().equalsIgnoreCase("MicrosoftEdge")) {
				seleniumCommands.findElements(START_QUOTE_BTNS).get(1).click();
			}else
				seleniumCommands.clickbyJS(HO_START_QUOTE_BTN_XPATH);

		}
		else if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.PA))
		{
			seleniumCommands.clickbyJS(PA_START_QUOTE_BTN_XPATH);
		}
		else if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.BOP))
		{
			seleniumCommands.clickbyJS(BOP_START_QUOTE_BTN);
		}

		return this;
	}

	public ZipCodePage setZipCode() {
		System.out.println(data.toString());
		logger.info( "Starting the Quote for Zip : "+ data.get("ZipCode"));
		seleniumCommands.type(ZIPCODE_TXT_ID, String.valueOf(data.get("ZipCode")));
		return this;
	}
	
	public ZipCodePage setPAZipCode() {
		logger.info( "Starting the PA Quote for Zip : "+ data.get("ZipCode"));
		seleniumCommands.type(PA_ZIPCODE_TXT_ID, String.valueOf(data.get("ZipCode")));
		return this;
	}
	
	public ZipCodePage setHOZipCode() {
		logger.info( "Starting the HO Quote for Zip : "+ data.get("ZipCode"));
		seleniumCommands.waitForElementToBeVisible(HO_ZIPCODE_TXT_ID);
		seleniumCommands.type(HO_ZIPCODE_TXT_ID, String.valueOf(data.get("ZipCode")));
		return this;
	}

	public ZipCodePage setBOPZipCode() {
		logger.info( "Starting the BOP Quote for Zip : "+ data.get("ZipCode"));
		seleniumCommands.type(BOP_ZIPCODE_TXT_ID, String.valueOf(data.get("ZipCode")));
		return this;
	}

	public ZipCodePage setZipCode(String zipcode) {
		logger.info( "Starting the Quote for Zip : "+ zipcode);
		seleniumCommands.type(ZIPCODE_TXT_ID, zipcode);
		return this;
	}

	public ZipCodePage selectVehiclePolicyType() {
		logger.info( "Selecting PA Policy Type");
		VEHICLE_POLICY_BTN_XPATH.click();
		return this;
	}

	public ZipCodePage selectHomePolicyType() {
		logger.info( "Selecting HO Policy Type");
		HOME_POLICY_BTN_XPATH.click();
		return this;
	}

	public QuickQuotePage goToQuickQuotePage() {
		logger.info( "Selecting Quick Quote Policy Type");
		seleniumCommands.clickbyJS(QUICK_QUOTE_LINK_CSS);
		return new QuickQuotePage();
	}

	public YourInfoPage goToYourInfoPage() {
		logger.info( "Go to Your Info page");
		this.goNext();
		if (this.data.size() > 0) {
			seleniumCommands.waitForLoaderToDisappearFromPage();
			return new YourInfoPage(this.data);
		} else {
			return new Pagefactory().getYourInfoPage();
		}
	}
	
	//Retrieve
	public ZipCodePage setZipCodeRetrive(String zip) {
		logger.info("Retriving the Quote for Zip : " + zip);
		seleniumCommands.type(ZIPCODE_RETRIVE_TXT_ID, zip);
		return this;
	}

	public ZipCodePage setZipCodeRetrive() {
		logger.info("Retriving the Quote for Zip : " + data.get("ZipCode"));
		seleniumCommands.type(ZIPCODE_RETRIVE_TXT_ID, data.get("ZipCode"));
		return this;
	}

	public ZipCodePage setQuoteReference(String referenceNumber) {
		logger.info("Retriving the Quote for Ref Number  : " + referenceNumber);
		seleniumCommands.type(QUOTEID_RETRIVE_TXT_ID, referenceNumber);
		return this;
	}

	public ZipCodePage setQuoteReference() {
		logger.info("Retriving the Quote for Ref Number  : " + data.get("QuoteReferenceNumber"));
		seleniumCommands.type(QUOTEID_RETRIVE_TXT_ID, data.get("QuoteReferenceNumber"));
		return this;
	}

	public ZipCodePage setQuoteRetrivalDetails() {
		logger.info("Setting Quote retrival details");
		RETRIVE_LINK_CSS.click();
		this.setZipCodeRetrive().setQuoteReference();
		return this;
	}
	
	public ZipCodePage setQuoteRetrivalDetails(String refNum) {
		logger.info("Setting Quote retrival details");
		RETRIVE_LINK_CSS.click();
		this.setZipCodeRetrive().setQuoteReference(refNum);
		return this;
	}

	public ZipCodePage goToBusinessTab() {
		logger.info("Going to Business Tab");
		seleniumCommands.isElementPresent(By.cssSelector("[gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_right_label]"));
		seleniumCommands.clickbyJS(By.cssSelector("[gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_right_label]"));
		return this;
	}

	public QuoteRetrivalPage openRetriveQuotePage() {
		logger.info("Going to Retrive quote page");
		seleniumCommands.clickbyJS(RETRIVE_LINK_CSS);
		return new QuoteRetrivalPage();
	}

	public PAQuotePage getQuotePage() {
		logger.info("Going to the Quote Page");
			seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class*='gw-nav'] "));
			return new PAQuotePage();
	}

	public GuidanceProductPage goToGuidanceProductPage() {
		logger.info("Going to Guidance Product Page");
		seleniumCommands.waitForElementToBeClickable(GO_TO_GUIDANCE_PAGE_BUTTON);
		new Button(seleniumCommands.findElement(GO_TO_GUIDANCE_PAGE_BUTTON)).click();
		return new GuidanceProductPage();
	}

	public ZipCodePage setZipCodePageDetails() {
		logger.info( "Starting the Quote");
		if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.HO))
		{
			this.setHOZipCode();
		}
		else if (data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.PA))
		{
			this.setPAZipCode();
		}

		else if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.BOP))
		{
			this.setBOPZipCode();
		}

		return this;
	}
	
	//Validation
	
	public Validation areZipPageFieldsMakedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields the Quote");
		return new Validation(isZipCodeFieldMakedWithError());
	}
	
	public Validation isZipCodeFieldMakedWithError() {
		logger.info( "Validating the Mandatory Error for zip code field");
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(PA_ZIPCODE_TXT_ID), DataConstant.ZIP_CODE_MISSING_ERROR_MSG);
	}

	public Validation isZipCodeFieldMakedWithInvalidZipError() {
		logger.info( "Validating the Invalid Zip Code Error for zip code field");
		if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.HO))
		{
			return new Validation(seleniumCommands.isElementPresent(HO_ZIPCODE_ERROR_XPATH));
		}
		else if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.PA))
		{
			return new Validation(seleniumCommands.isElementPresent(PA_ZIPCODE_ERROR_XPATH));
		}

		else if(data.get(DataConstant.POLICYTYPE_DATA_COL).equals(DataConstant.BOP))
		{
			return new Validation(seleniumCommands.isElementPresent(BOP_ZIPCODE_ERROR_CSS));
		}

		return null;
	}
	public boolean isPolicyTypeFieldMakedWithError() {
		logger.info( "Checking the Mandatory Error LOB fields the Quote");
		return seleniumCommands.getErrorMessageForTxtBox(LOB_CLASSNAME).equals(DataConstant.POLICY_SELECTION_ERROR_MSG);
	}
	
	public Validation isPolicyTypeHomeOwnerSelected() {
		logger.info( "Checking If HO Policy Selected");
		return null;
	}
	
	public Validation isZipCodePageOpened() {
		logger.info( "Checking If HO Policy Selected");
		seleniumCommands.waitForElementToBeEnabled(PA_ZIPCODE_TXT_ID);
		return new Validation(seleniumCommands.isElementPresent(PA_ZIPCODE_TXT_ID));
	}
	public Validation isHOOnlyZipCodePageOpened() {
		logger.info( "Checking If HO Policy Selected");
		seleniumCommands.waitForElementToBeEnabled(HO_ZIPCODE_TXT_ID);
		return new Validation(seleniumCommands.isElementPresent(HO_ZIPCODE_TXT_ID));
	}
	
}
