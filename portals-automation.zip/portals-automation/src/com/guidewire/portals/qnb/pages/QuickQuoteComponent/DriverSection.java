package com.guidewire.portals.qnb.pages.QuickQuoteComponent;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author jkrawczyk-koca
 */
public class DriverSection extends CommonPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(xpath = "//*[@model='model.dto.email']//input")
    WebElement EMAIL_TXT_XPATH;

    @FindBy(xpath = "//*[@model='model.dto.email']//*[@ng-repeat='errorMessage in model.aspects.validationMessages track by $index']")
    WebElement EMAIL_FORMAT_ERR_CSS ;

    By  EMAIL_FORMAT_ERR_LOCATOR  = By.xpath("//*[@model='model.dto.email']//*[@ng-repeat='errorMessage in model.aspects.validationMessages track by $index']");
    By  EMAIL_TXT_XPATH_LOCATOR = By.xpath("//*[@model='model.dto.email']//input");

    @FindBy(css = "[model='driverAge'] input")
    WebElement AGE_TXT_CSS;

    By AGE_TXT_CSS_LOCATOR = By.cssSelector("[model='model.dto.age'] input");

    @FindBy(css = "label[for = 'Agree']")
    WebElement TERMSCONDITIONS_CHECKBOX_CSS;

    @FindBy(xpath = "//*[@model='model.dto.email']//div/span")
    WebElement EMAIL_VALUE_XPATH;

    @FindBy(xpath = "//*[@model='model.dto.age']//div/span")
    WebElement AGE_VALUE_XPATH;

    @FindBy(xpath = "//label[@for='Agree']")
    WebElement TERMSCONDITIONS_VALUE_XPATH;

    @FindBy(css = "button[ng-click='markComplete()']")
    WebElement SAVE_DRIVER_BTN_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state='2'] [class*='complete']")
    WebElement DRIVERS_COMPLETE_CSS;

    @FindBy(css = "button[ng-click='model.edit()']")
    WebElement EDIT_DRIVER_BTN_CSS;
    
    @FindBy(css = "[ng-click='selectPrevValue()'][class*='Disabled']")
    WebElement DISABLED_DRIVER_AGE_DECREMENT_BTN_CSS;
    
    @FindBy(css = "[ng-click='selectNextValue()'][class*='Disabled']")
    WebElement DISABLED_DRIVER_AGE_INCREMENT_BTN_CSS;

    @FindBy(css = "[ng-click='quote()']")
    WebElement QUOTE_BTN;

      By SAVE_DRIVER_BTN_LOCATOR = By.cssSelector("button[ng-click='markComplete()']");

   /** @FindBy(css = "//*[@model='model.dto.email']//input/following-sibling::div//span")
    WebElement EMAIL_ERR_CSS; */


    final By EMAIL_ERR_CSS = By.xpath("//*[@model='model.dto.email']//input/following-sibling::div//span");

   /** @FindBy(css = "[model*='.age'] div[class*='error']")
    WebElement AGE_ERR_CSS; */

    final By AGE_ERR_CSS = By.cssSelector("[model*='.age'] div[class*='error']");

    /**@FindBy(css = "[model*='.termsChecked'] div[class*='error']")
    WebElement TERMSCONDITIONS_ERR_CSS; */

    final By TERMSCONDITIONS_ERR_CSS = By.cssSelector("[model*='.termsChecked'] div[class*='error']");

    public DriverSection()
    {
        seleniumCommands.pageWebElementLoader(this);
    }

// Set Methods

    public DriverSection withEmail() {
        seleniumCommands.logInfo( "Setting Email ");
        seleniumCommands.type(EMAIL_TXT_XPATH, data.get("Email"));
        return this;
    }

    public DriverSection withAge() {
        seleniumCommands.logInfo( "Setting Age ");
        seleniumCommands.type(AGE_TXT_CSS, data.get("Age"));
        return this;
    }

    public DriverSection withTermsConditions() {
        seleniumCommands.logInfo( "Setting Terms & Conditions ");
        seleniumCommands.clickbyJS(TERMSCONDITIONS_CHECKBOX_CSS);
        return this;
    }

    public DriverSection setDriverDetails() {
        seleniumCommands.logInfo( "Setting Driver Details ");
        //this.withEmail()
        this.withAge().withTermsConditions();
        return this;
    }

    public DriverSection setDriverWithoutTermsConditionsDetails() {
        seleniumCommands.logInfo( "Setting Driver Details ");
        this.withEmail().withAge().submitDriverData();
        return this;
    }

    // Methods

    public DriverSection submitDriverData() {
        seleniumCommands.logInfo( "Submitting driver data ");
        seleniumCommands.click(SAVE_DRIVER_BTN_CSS);
        return this;
    }

    public DriverSection editDriverData() {
        seleniumCommands.logInfo( "Submitting driver data ");
        seleniumCommands.click(EDIT_DRIVER_BTN_CSS);
        return this;
    }

    public DriverSection clickQuote() {
        seleniumCommands.logInfo("Setting Address Details");
        seleniumCommands.click(QUOTE_BTN);
        return this;
    }

    // Get Methods

    private String getEmail()
    {
        seleniumCommands.logInfo( "Getting Email ");
        return seleniumCommands.getTextAtLocator(EMAIL_VALUE_XPATH);
    }

    private String getAge()
    {
        seleniumCommands.logInfo( "Getting Age ");
        return seleniumCommands.getValueAttributeFromLocator(AGE_TXT_CSS);
    }

    private String getTermsConditions()
    {
        seleniumCommands.logInfo( "Getting Terms & Condtions ");
        return seleniumCommands.getTextAtLocator(TERMSCONDITIONS_VALUE_XPATH);
    }

    // Validation Methods

    public Validation isEmailEqualsTo() {
        seleniumCommands.logInfo( "Validating if email equals to ");
        return new Validation(getEmail(), data.get("Email"));
    }
    
    public Validation isDriverAgeEqualsTo() {
        seleniumCommands.logInfo( "Validating if age equals to ");
        return new Validation(getAge(), data.get("Age"));
    }

    public Validation isDriverSectionLoaded() {
        seleniumCommands.logInfo( "Validating if Driver Section is loaded ");
        seleniumCommands.waitForElementToBeVisible(AGE_TXT_CSS);
        return new Validation(seleniumCommands.isElementPresent(AGE_TXT_CSS));
    }

    public void validateDriverDataRetrived() {
        seleniumCommands.logInfo( "Validating the driver data ");
        new Validation(this.getEmail(),data.get("Email")).shouldBeEqual("Email data was not matched");
        new Validation(this.getAge(),data.get("Age")).shouldBeEqual("Age data was not retrived");
        new Validation(this.getTermsConditions(),data.get("TermsConditions")).shouldBeEqual("Terms Conditions data was not retrived");
    }

    public Validation areDriverSectionFieldsMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory fields marked with error");
        isEmailFieldMarkedWithMandatoryError().shouldBeEqual("Email field is not marked with error");
        isAgeFieldMarkedWithMandatoryError().shouldBeTrue("Age field is not marked with error");
        isTermsConditionsMarkedWithMandatoryError().shouldBeTrue("Terms Conditions field is not marked with error");
       return new Validation(true);
    }

   public Validation isEmailFieldMarkedWithMandatoryError() {
       seleniumCommands.logInfo( "Validating the format error for Email Field");
       String actualError = seleniumCommands.findElement(EMAIL_ERR_CSS).getAttribute("innerHTML")  ;
        return new Validation(actualError, DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isEmailFieldMarkedWithFormatError() {
        seleniumCommands.logInfo( "Validating the format error for Email Field");
        String actualError = seleniumCommands.findElement(EMAIL_ERR_CSS).getAttribute("innerHTML")  ;
        return new Validation(actualError, DataConstant.EMAIL_FORMAT_ERROR);
    }

   public Validation isAgeFieldMarkedWithMandatoryError() {
       seleniumCommands.logInfo( "Validating the Error for Age Field");
        return new Validation(seleniumCommands.isElementPresent(AGE_ERR_CSS));
    }
   
   public Validation isAgeDecrementButtonDisabled() {
       seleniumCommands.logInfo( "Validating the age decrement button disability");
        return new Validation(seleniumCommands.isElementPresent(DISABLED_DRIVER_AGE_DECREMENT_BTN_CSS));
    }
   
   public Validation isAgeIncrementtButtonDisabled() {
       seleniumCommands.logInfo( "Validating the age increment button disability");
        return new Validation(seleniumCommands.isElementPresent(DISABLED_DRIVER_AGE_INCREMENT_BTN_CSS));
    }

    public Validation isTermsConditionsMarkedWithMandatoryError() {
        seleniumCommands.logInfo( "Validating the Error for Age Field");
        return new Validation(seleniumCommands.isElementPresent(TERMSCONDITIONS_ERR_CSS));
    }
    
    public void isDriverSectionComplete() {
        logger.info( "Validating if Driver Section is Complete ");
        seleniumCommands.waitForElementToBeVisible(DRIVERS_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(DRIVERS_COMPLETE_CSS)).shouldBeTrue("Driver's data was not retrived");
    }

}
