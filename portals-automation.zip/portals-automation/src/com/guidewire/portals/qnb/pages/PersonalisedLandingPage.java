package com.guidewire.portals.qnb.pages;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.PropertiesReader;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PersonalisedLandingPage extends CommonPage {

    Logger logger = Logger.getLogger(this.getClass().getName());


    private static final String LANDING_PAGE_TILE = "header h1";
    private static final String LANDING_PAGE_TILE_IMAGE = "header.gw-landing-page-1-bg-image";
    private static final String LANDING_PAGE_TILE_TEXT = "This is the Strapline";
    private static final String LANDING_PAGE_BlOCK_SECTION = "section.gw-landing-page-1-section--primary";
    private static final String LANDING_PAGE_GET_STARTED_BUTTON = ".gw-btn-primary";
    private static final String LANDING_PAGE_CAROUSEL = "gw-carousel-slides";
    private static final String DYNAMIC_BRANDING_GATEWAY_LOGO = ".gw-branding-gateway-cobranded .gw-image-versioning-logo";
    private static final String DYNAMIC_BRANDING_GATEWAY_BORDER_BAR = ".gw-branding-gateway-cobranded .gw-quote-wrapper";
    private static final String DYNAMIC_BRANDING_MILLENNIALS_LOGO = ".gw-branding-millennials .gw-image-versioning-logo";
    private static final String DYNAMIC_BRANDING_MILLENNIALS__BORDER_BAR = ".gw-branding-millennials .gw-quote-wrapper";


    private Validation verifyLandingPageHeaderIsDisplayed() {
        logger.info("verifying landing page header is displayed");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(LANDING_PAGE_TILE)));
    }

    private Validation verifyLandingPageHeaderText() {
        logger.info("verifying landing page header text");
        return new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(LANDING_PAGE_TILE)),LANDING_PAGE_TILE_TEXT);
    }

    private Validation verifyLandingPageHeaderImage() {
        logger.info("verifying landing page header image");
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(LANDING_PAGE_TILE_IMAGE)));
    }

    private Validation verifyLandingPageBlockSectionIsDisplayed() {
        logger.info("verifying landing page block section is displayed");
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(LANDING_PAGE_BlOCK_SECTION)));
    }

    private Validation verifyLandingPageCarouselIsDisplayed() {
        logger.info("verifying landing page Carousel is displayed");
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(LANDING_PAGE_CAROUSEL)));
    }

    private Validation verifyDynamicBrandingLogoIsDisplayed(String locator) {
        logger.info("verifying Dynamic Branding Logo is displayed");
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(locator)));
    }

    private Validation verifyDynamicBrandingBorderBarIsDisplayed(String locator) {
        logger.info("verifying dynamic branding Border bar is displayed");
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(locator)));
    }

    public PersonalisedLandingPage clickGetStartedButton() {
        logger.info("Clicking Get Started Button");
        seleniumCommands.click(By.cssSelector(LANDING_PAGE_GET_STARTED_BUTTON));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public PersonalisedLandingPage verifyLandingPageOneElements() {
        verifyLandingPageHeaderIsDisplayed().shouldBeTrue("Checking Landing Page Header is displayed");
        verifyLandingPageHeaderText().shouldBeEqual("Verifying landing page header text is correct");
        verifyLandingPageHeaderImage().shouldBeTrue("Checking Landing Page header image is displayed");
        verifyLandingPageBlockSectionIsDisplayed().shouldBeTrue("Checking Landing Page Bock Section is displayed");
        return this;
    }

    public PersonalisedLandingPage verifyLandingPageTwoElements() {
        verifyLandingPageCarouselIsDisplayed().shouldBeTrue("Checking Landing Page Carousel is displayed");
        verifyLandingPageBlockSectionIsDisplayed().shouldBeTrue("Checking Landing Page Bock Section is displayed");
        return this;
    }

    public PersonalisedLandingPage verifyDynamicBrandingGatewayElements() {
        verifyDynamicBrandingLogoIsDisplayed(DYNAMIC_BRANDING_GATEWAY_LOGO).shouldBeTrue("Checking Dynamic Branding Logo is displayed");
        verifyDynamicBrandingBorderBarIsDisplayed(DYNAMIC_BRANDING_GATEWAY_BORDER_BAR).shouldBeTrue("Checking Dynamic Branding Border bar is displayed");
        return this;
    }

    public PersonalisedLandingPage verifyDynamicBrandingMillennialsElements() {
        verifyDynamicBrandingLogoIsDisplayed(DYNAMIC_BRANDING_MILLENNIALS_LOGO).shouldBeTrue("Checking Dynamic Branding Logo is displayed");
        verifyDynamicBrandingBorderBarIsDisplayed(DYNAMIC_BRANDING_MILLENNIALS__BORDER_BAR).shouldBeTrue("Checking Dynamic Branding Border bar is displayed");
        return this;
    }

    public PersonalisedLandingPage promoRedirect(int promoNumber){
        WebDriver driver = ThreadLocalObject.getDriver();
        String urlWithLastCharacterRemoved = removeLastCharacterFromUrl();
        logger.info("Using Campaign Codes - Promotion"+ promoNumber + " to get redirected to Landing Page " + promoNumber);
        driver.get(urlWithLastCharacterRemoved + "?utm_source=email&utm_medium=social&utm_campaign=promotion" + promoNumber);
        return this;
    }

    public PersonalisedLandingPage dynamicBrandingRedirect(String brandOption){
        WebDriver driver = ThreadLocalObject.getDriver();
        String urlWithLastCharacterRemoved = removeLastCharacterFromUrl();
        logger.info("Opening Dynamic Branding pages using " + brandOption);
        driver.get(urlWithLastCharacterRemoved + "?branding=" + brandOption);
        return this;
    }

    private String removeLastCharacterFromUrl(){
        String url = PropertiesReader.getURL(ThreadLocalObject.getSuitenName());
        return url.substring(0 , url.length() -1);
    }
}
