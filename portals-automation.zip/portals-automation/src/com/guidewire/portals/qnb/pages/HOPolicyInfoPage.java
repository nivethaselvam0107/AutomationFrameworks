package com.guidewire.portals.qnb.pages;

import java.util.Arrays;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;

public class HOPolicyInfoPage extends HOCoverageDetailsPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> newBillData = new HashMap<>();
	HashMap<String, String> uiData = new HashMap<>();
	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	@FindBy(xpath = "//*[@class='gw-control-group']/div[2]")
	WebElement COV_START_DATE_XPATH;
	
	@FindBy(xpath = "//*[@class='gw-control-group'][2]/div[2]")
	WebElement PRIMARY_INSURED_NAME_CSS;
	
	@FindBy(xpath = "//*[@class='gw-control-group'][3]/div[2]")
	WebElement ADDRESS_XPATH;
	
	@FindBy(css = "[name='policyInfoForm']")
	WebElement POLICY_INFO_PAGE_CSS;
	
	@FindBy(css = "label[for='BillAndPolAddrsEqualNo']")
	WebElement BILLING_ADDRESS_YES_CSS;
	
	@FindBy(css = "label[for='BillAndPolAddrsEqualNo']")
	WebElement BILLING_ADDRESS_NO_CSS;
	
	@FindBy(name = "ContactEmail")
	WebElement EMAIL_NAME;
	
	@FindBy(css = "div[label='Phone'] input")
	WebElement CONTACTNO_CSS;
	
	@FindBy(css = "[ng-click='goToNext()']")
	WebElement GONEXT_BTN_CSS;
	
	@FindBy(css = "div[model='submissionVM.bindData.contactEmail'] input, [label='Email'] input")
	WebElement EMAIL_TXT_CSS;

	@FindBy(css = "[label='Email'] [ng-if='readonly']")
	WebElement BILLING_READ_ONLY_EMAIL_CSS;

	@FindBy(css = "div[model='submissionVM.bindData.contactEmail'] span")
	WebElement EMAIL_LBL_CSS;

	@FindBy(css = "div[model='submissionVM.bindData.contactPhone'] input, [label='Phone'] input")
	WebElement CONTACTNO_TXT_CSS;
	
	@FindBy(css = "div[model='submissionVM.bindData.contactPhone'] span")
	WebElement CONTACTNO_LBL__CSS;
	
	@FindBy(css = "[model='policyInfo.billAndPolAddrsEqual'] label[class='second']")
	WebElement BILLING_ADD_NO_LBL_CSS;
	
	@FindBy(css = "[model='policyInfo.billAndPolAddrsEqual'] input[data-ng-value='valueLeft'], [label*='billing address'] input[data-ng-value='valueLeft']")
	WebElement BILLING_ADD_YES_INPUT_CSS;
	
	@FindBy(css = "[model='policyInfo.billAndPolAddrsEqual'] input[data-ng-value='valueRight']")
	WebElement BILLING_ADD_NO_INPUT_CSS;

	By PERSONAL_INJURY = By.cssSelector("[coverages='model.additionalCoverages'] div[class*='name']");

	By COVERAGES_BLOCKS = By.cssSelector("[ng-repeat='coverage in _coverages track by coverage.id']");

	By COVERAGE_VALUES = By.cssSelector("[class*='termAmount']");

	By FIRST_NAME_CSS = By.cssSelector("[label='First Name'] input[class*='ng-empty']");

	By LAST_NAME_CSS = By.cssSelector("div[model='contact.lastName'] input, [label='Last Name'] input");

	public HOPolicyInfoPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public HOPolicyInfoPage(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}
	
	public HOPolicyInfoPage goNext()
	{
		seleniumCommands.staticWait(3);
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}
	
	public PaymentDetailsPage goToPaymentDetailsPage() {
		this.goNext();
			return new Pagefactory().getPaymentInfoPage();
	}
	
	//Set Metthod
	
	public HOPolicyInfoPage setEmailAddress(String email) {
		if (ThreadLocalObject.getBrowserName().equals("internet explorer") && (email.equals(""))) {
			EMAIL_TXT_CSS.clear();
		} else{
			seleniumCommands.type(EMAIL_TXT_CSS, email);
			seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		}
		return this;
	}
	
	public HOPolicyInfoPage setEmailAddress() {
		seleniumCommands.type(EMAIL_TXT_CSS, data.get("Email"));
		return this;
	}

	public HOPolicyInfoPage setPhoneNumber(String number) {
		this.setUserDetails();
		if(ThreadLocalObject.getBrowserName().equals("internet explorer") && (number.equals(""))) {
			CONTACTNO_CSS.clear();
		}else {
			seleniumCommands.type(CONTACTNO_CSS, number);
			seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		}
		return this;
	}
	
	public HOPolicyInfoPage setPhoneNumber() {
		//this.setUserDetails();
		seleniumCommands.type(CONTACTNO_CSS, String.valueOf(data.get("PhoneNumber")));
		return this;
	}

	private HOPolicyInfoPage setUserDetails() {
		if(seleniumCommands.isElementPresent(FIRST_NAME_CSS)){
			seleniumCommands.type(FIRST_NAME_CSS, data.get("FirstName"));
			seleniumCommands.type(LAST_NAME_CSS, data.get("LastName"));
		}
		return this;
	}
	
	public HOPolicyInfoPage selectAddressSelection(boolean selection) {
		return null;
	}
	
	public HOPolicyInfoPage setAddLine1(String addLine1) {
		return null;
	}
	
	public HOPolicyInfoPage setAddLine2(String addLine2) {
		return null;
	}
	
	public HOPolicyInfoPage setZipCode(String zipCode) {
		return null;
	}
	
	// Get Methods
	
	private String getCoverageStartDate() {
		return seleniumCommands.getTextAtLocator(COV_START_DATE_XPATH);
	}
	
	private String getPrimaryInssured() {
		return seleniumCommands.getTextAtLocator(PRIMARY_INSURED_NAME_CSS);
	}
	
	private String getAddressDetails() {
		return seleniumCommands.getTextAtLocator(ADDRESS_XPATH).replaceAll("[\\t\\n\\r]+", " ");
	}
	
	private String getCity() {
		return null;
	}
	
	private String getState() {
		return null;
	}

	public String getEmailAddress() {
		return seleniumCommands.getValueAttributeFromLocator(EMAIL_TXT_CSS);
	}

	public String getInowReadOnlyEmailAddress() {
		return seleniumCommands.getTextAtLocator(BILLING_READ_ONLY_EMAIL_CSS);
	}

	public String getPhoneNumber() {
		return seleniumCommands.getValueAttributeFromLocator(CONTACTNO_CSS);
	}
	
	public boolean getBillingAddressIsSameAsPolicyAddressValue() {
			boolean flag = false;
			if (new Boolean(
					seleniumCommands.getAttributeValueAtLocator(BILLING_ADD_YES_INPUT_CSS, "aria-checked"))) {
				flag = true;
			} else if (new Boolean(
					seleniumCommands.getAttributeValueAtLocator(BILLING_ADD_NO_INPUT_CSS, "aria-checked"))) {
				flag = false;
			}
			return flag;
	}
	
	public HOPolicyInfoPage setNewBillingAddress()
	{
		newBillData.put("AddressLine1", "MounJoy Square New");
		newBillData.put("AddressLine2", "City Center New");
		newBillData.put("AddressLine3", "Dublin 1 New");
		newBillData.put("City", "Dublin New");
		newBillData.put("State", "California");
		newBillData.put("StateValue", "CA");
		newBillData.put("Email", "New_dh@gmail.com");
		seleniumCommands.clickbyJS(BILLING_ADD_NO_LBL_CSS);
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[ng-show='!policyInfo.billAndPolAddrsEqual.value']"));
		YourInfoPage infoPage = new YourInfoPage();
		infoPage.withAddLine1(newBillData.get("AddressLine1")).withAddLine2(newBillData.get("AddressLine2")).
		withAddLine3(newBillData.get("AddressLine3")).withCity(newBillData.get("City")).
		withState(newBillData.get("State"));
		return this;
	}
	
	// Validation method
	
	public Validation isCoverageDateEqualTo(String date)
	{
		return new Validation(getCoverageStartDate(), date);
	}
	
	public Validation isBillingAddressSelected(String date)
	{
		return new Validation(getCoverageStartDate(), date);
	}
	
	public Validation isPrimaryInsuredNameEqualsTo(String name)
	{
		return new Validation(getPrimaryInssured(), name);
	}
	
	public Validation isAddressEqualTo(String address)
	{
		return new Validation(getAddressDetails(), address);
	}
	
	public Validation isCityEqualTo(String city)
	{
		return new Validation(getCity(), city);
	}
	
	public Validation isStateEqualTo(String state)
	{
		return new Validation(getState(), state);
	}

	public HOPolicyInfoPage setPolicyInfoPageDetails() {
		this.setEmailAddress().setPhoneNumber().setUserDetails();
		return this;
	}

	public HOPolicyInfoPage setInowPolicyInfoPageDetails() {
		this.setPhoneNumber();
		return this;
	}

	public Validation isPersonalInjuryCovarageSaved() {
		seleniumCommands.logInfo("Validating if Personal Injury coverage was saved.");
		return new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElements(PERSONAL_INJURY).get(0)),"Personal Injury");
	}

	public void validateOtherStructuresCauseOfLoss(String value) {
		seleniumCommands.logInfo("Validating if Other Structures cause of loss was saved.");
		new Validation(seleniumCommands.getTextAtLocator(  seleniumCommands.findElements(COVERAGES_BLOCKS).get(3).findElements(COVERAGE_VALUES).get(3)), value).shouldBeEqual("Coverage changes were not saved properly.");
	}

    public void validateDwellingValuationMethod(String value) {
        seleniumCommands.logInfo("Validating if Other Structures cause of loss was saved.");
        new Validation(seleniumCommands.getTextAtLocator(  seleniumCommands.findElements(COVERAGES_BLOCKS).get(3).findElements(COVERAGE_VALUES).get(2)), value).shouldBeEqual("Coverage changes were not saved properly.");
    }

	public Validation isPolicyBillingAddressOptionSelectedByDefault() {
		seleniumCommands.logInfo("Validating the billing address option");
		return new Validation(BILLING_ADD_YES_INPUT_CSS.isSelected());
	}
	
	public Validation isHOPolicyInfoPageLoaded() {
		seleniumCommands.logInfo( "Validating if HO Policy Info page is loaded");
		return new Validation(seleniumCommands.isElementPresent(POLICY_INFO_PAGE_CSS));
	}
	
	public Validation arePolicyInfoPageFieldsMarkedWithMandatoryError() {
		seleniumCommands.logInfo( "Validating the Mandatory Error for the fields of HO Policy Info page");
		isPhoneNumberFieldMakedWithError().shouldBeEqual("Phone number was not marked with error");
		isEmailFieldMakedWithError().shouldBeEqual("Email field was not marked with error");
		return new Validation(true);
	}
	
	public Validation isPhoneNumberFieldMakedWithError() {
		seleniumCommands.logInfo( "Validating the Mandatory Error for Phone Number Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(CONTACTNO_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isEmailFieldMakedWithError() {
		seleniumCommands.waitForLoaderToDisappearFromPage(2);
		seleniumCommands.logInfo( "Validating the Mandatory Error for Email Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(EMAIL_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isEmailFieldMarkedWithFormatError() {
		seleniumCommands.logInfo( "Validating the Format Error for Email Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(EMAIL_TXT_CSS), DataConstant.EMAIL_FORMAT_ERROR);
	}

	public boolean isEmailFieldMakedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Asterick for Email Field");
		boolean value = seleniumCommands.checkAstrickForFields(EMAIL_LBL_CSS);
		seleniumCommands.logInfo("Email is marked with Asterisk " + value);
		return value;
	}
	
	public Validation validatePolicyAddressWithBackEnd() {
		seleniumCommands.logInfo("Validating the new billing address for HO Policy");
		return new Validation(getAddressDetails(), ParseQuoteData.getHOPolicyAdressFromBackEnd(DataFetch.getQuoteAsJsonData()).get("AddressDisplayName"));
	}
	
	public Validation validateCoverageDateWithBackEnd() {
		seleniumCommands.logInfo("Validating the new billing address for HO Policy");
		return new Validation(getCoverageStartDate(), ParseQuoteData.getHOPolicyAdressFromBackEnd(DataFetch.getQuoteAsJsonData()).get("AddressDisplayName"));
	}
	
	public Validation validatePolicyAddressWithBackEnd(String jsonData) {
		seleniumCommands.logInfo("Validating the new billing address for HO Policy");
		new Validation(BILLING_ADD_YES_INPUT_CSS.isSelected()).shouldBeTrue("Billing addess option is is not selected Yes by default");
		return new Validation(getAddressDetails(), ParseQuoteData.getHOPolicyAdressFromBackEnd(jsonData).get("AddressDisplayName"));
	}
	
	public Validation validateCoverageDateWithBackEnd(String jsonData) {
		seleniumCommands.logInfo("Validating the policy Coverage date for HO Policy");
		return new Validation(getCoverageStartDate(), DateUtil.formatDateTo(data.get("Quote_Cov_Date"), "MMM d, YYYY"));
	}
	
	public Validation validatePrimaryInsuredPersonNameWithBackEnd(String jsonData) {
		if (!seleniumCommands.isElementPresent(FIRST_NAME_CSS)) {
			seleniumCommands.logInfo("Validating the policy Coverage date for HO Policy");
		String uiName = getPrimaryInssured();
		String apiName = ParseQuoteData.getPersonalInfoFromBackEnd(jsonData).get("PolicyHolderDisplayName");
		return new Validation(uiName, apiName);
		}
		else {
			return new Validation(true, true);
		}
	}
	
	public Validation isEmailSaved() {
		return new Validation(this.getEmailAddress(), (data.get("Email")));
	}

	public Validation isReadOnlyEmailExists() {
		return new Validation(this.getInowReadOnlyEmailAddress(), (data.get("Email")));
	}

	public Validation isPhoneSaved() {
		return new Validation(this.getPhoneNumber(), (data.get("PhoneNumber")));
	}
}
