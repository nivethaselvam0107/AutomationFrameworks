package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.ConstructionPageLocators;

public class ConstructionPage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());	

	@FindBy(css = "div[label='Estimated value of Your Home'] input")
	WebElement HOMEVALUE_TXT_CSS;

	@FindBy(css = "div[validation-form='detailsForm'] h3,div[validation-form='detailsForm'] h2, [name='validationForms[detailsForm]'] div[ng-click='toggleOpen()']")
	WebElement CONSTRUCTION_DETAILS_SEC_CSS;

	@FindBy(css = "[model='view.yearBuilt'] input, [label='Year Built'] input, [label='What year was your home built?'] input")
	WebElement BUILD_YEAR_TXT_CSS;

	@FindBy(css = "div[label='Year Build'] span")
	WebElement ESTIMATED_COST_LBL_CSS;

	@FindBy(css = "[model='view.storiesNumber'] select, [label='Number of Stories'] select")
	WebElement STORIES_DROP_CSS;
	
	@FindBy(css = "[model='view.storiesNumber'] input, [label='Number of Stories'] input")
	WebElement STORIES_TXT_CSS;

	@FindBy(css = "div[label='Number of Stories'] span")
	WebElement STORIES_LBL_CSS;

	@FindBy(css = "[label='Garage'] input:nth-of-type(2)")
	WebElement ATTACHED_GARAGE_RBTN_CSS;

	@FindBy(css = "[label='Garage'] input:nth-of-type(1)")
	WebElement NO_GARAGE_RBTN_CSS;

	@FindBy(css = "div[label='Garage'] span")
	WebElement GARAGE_LBL_CSS;

	@FindBy(css = "[model='view.constructionType'] select, [label='Construction Type'] select")
	WebElement CONSTRUCTION_DROP_CSS;

	@FindBy(id = "CONSTRUCTION_LBL_ID")
	WebElement CONSTRUCTION_LBL_ID;

	@FindBy(css = "[model='view.foundationType'] span")
	WebElement FOUNDATION_LBL_ID;

	@FindBy(css = "[model='view.foundationType'] select, [label='Foundation Type'] select")
	WebElement FOUNDATION_DROP_CSS;

	// ROOF DETAILS FORM

	@FindBy(css = "div[validation-form='roofsForm'] h3,div[validation-form='roofsForm'] h2, [name='validationForms[roofForm]'] div[ng-click='toggleOpen()']")
	WebElement ROOF_DETAILS_SEC_CSS;

	@FindBy(css = "[model='view.roofType'] [class='gw-inline-messages'] span, [custom-option-model*='roof'] [class='gw-inline-messages'] span[gw-test-platform-widgets-basicinputs-ctrl-group-error-message], [name='validationForms[roofForm]'] .gw-inline-messages")
	WebElement ROOF_SECTION_ERR_CSS;

	@FindBy(css = "[label='What type of roof do you have?']")
	WebElement INOW_ROOF_SECTION;

	@FindBy(css = "[label='What type of roof do you have?'] .gw-inline-messages")
	WebElement INOW_ROOF_SECTION_ERR_CSS;
	// Replace roofType with the type you want

	@FindBy(css = "input[name='RoofType'][value ='comp']")
	WebElement ROOF_TYPE_IMG_CSS;
	
	@FindBy(css = "[model='otherModel'] textarea, textarea[ng-model*='otherModel']")
	WebElement OTHER_ROOF_TYPE_DESC_CSS;

	@FindBy(css = "[upgrade-exists*='roofUpgradeExists'] input[type='checkbox']")
	WebElement ROOF_UPGRADE_CHK_CSS;

	@FindBy(css = "[]")
	WebElement ROOF_UPGRADE_LBL_CSS;

	@FindBy(css = "[upgrade-exists*='roofUpgradeExists'] input[type='number'], [label='Roofing Upgraded'] input[type='number']")
	WebElement ROOF_UPGRADE_YEAR_TXT_CSS;

	@FindBy(xpath = "//div[@validation-form='roofsForm']//div[@class='panel-collapse collapse in']")
	WebElement ROOFTYPES_SEC_XPATH;

	// PLUMBING DETAILS FORM

	@FindBy(css = "div[validation-form='plumbingForm'] h3, div[validation-form='plumbingForm'] h2, [name='validationForms[plumbingForm]'] div[ng-click='toggleOpen()']")
	WebElement PLUMBING_DETAILS_SEC_CSS;

	@FindBy(css = "[model='view.plumbingType'] [model='otherModel'] [class='gw-inline-messages'] span")
	WebElement PLUMBING_OTHER_TYPE_TXT_CSS;

	@FindBy(css = "div[label='Plumbing'] select")
	WebElement PLUMBING_TYPE_DROP_CSS;

	@FindBy(css = "[upgrade-exists*='plumbingUpgradeExists'] input[type='checkbox']")
	WebElement PLUMBING_UPGRADE_CHK_CSS;

	@FindBy(css = "label[for='PlumbingUpgradeExists'] span")
	WebElement PLUMBING_UPGRADE_LBL_CSS;

	@FindBy(css = "[upgrade-exists*='plumbingUpgradeExists'] input[type='number'], [label='Plumbing Upgraded'] input[type='number']")
	WebElement PLUMBING_UPGRADE_YEAR_TXT_CSS;

	@FindBy(xpath = "//div[@validation-form='plumbingForm']//div[@class='gw-panel-collapse gw-collapse gw-in']")
	WebElement PLUMBING_SEC_XPATH;

	// HEATING DETAILS FORM

	@FindBy(css = "div[validation-form='heatingForm'] h3,div[validation-form='heatingForm'] h2,  [name='validationForms[heatingForm]'] div[ng-click='toggleOpen()']")
	WebElement HEATING_SEC_CSS;

	@FindBy(css = "div[label='Primary Heating'] select")
	WebElement PRIMARY_HEATING_DROP_CSS;
	
	@FindBy(css = "[model='view.primaryHeatingType'] [model='otherModel'] input, [model*='primaryHeatingType'] input")
	WebElement OTHER_PRIMARY_HEATING_DESC_CSS;

	@FindBy(css = "[model='view.primaryHeatingType'] [model='otherModel'] [class='gw-inline-messages'] span")
	WebElement PRIMARY_OTHER_TYPE_TXT_CSS;
	
	@FindBy(css = "label[for='SecondaryHeatingExistsNo'] span")
	WebElement SECONDARY_HEATING_LBL_CSS;

	@FindBy(css = "[model='view.secondaryHeatingExists'] [class='gw-first'], [label='Secondary Heating'] [class='gw-first']")
	WebElement SECONDARY_HEATING_YES_RBTN_ID;

	@FindBy(css = "[model='view.secondaryHeatingExists'] [class='gw-second'], [label='Secondary Heating'] [class='gw-second']")
	WebElement SECONDARY_HEATING_NO_RBTN_ID;
	
	@FindBy(css = "[model='view.secondaryHeatingExists'] input:nth-of-type(1), [label='Secondary Heating'] input:nth-of-type(1)")
	WebElement SECONDARY_HEATING_YES_VALUE_RBTN_ID;

	@FindBy(css = "[model='view.secondaryHeatingExists'] input:nth-of-type(2), [label='Secondary Heating'] input:nth-of-type(2)")
	WebElement SECONDARY_HEATING_NO_VALUE_RBTN_ID;

	@FindBy(css = "[upgrade-exists*='heatingUpgradeExists'] input[type='checkbox']")
	WebElement HEATING_UPGRADE_CHK_CSS;

	@FindBy(css = "label[for='HeatingUpgradeExists'] span")
	WebElement HEATING_UPGRADE_LBL_CSS;

	@FindBy(css = "[upgrade-exists*='heatingUpgradeExists'] input[type='number'], [label='Heating Upgraded'] input[type='number']")
	WebElement HEATING_UPGRADE_YEAR_TXT_CSS;

	@FindBy(xpath = "//div[@validation-form='heatingForm']//div[@class='gw-panel-collapse gw-collapse gw-in']")
	WebElement HEATING_SEC_XPATH;

	// ELECTRICAL DETAILS FORM

	@FindBy(css = "div[validation-form='electricalForm'] h3,div[validation-form='electricalForm'] h2,   [name='validationForms[electricalForm]'] div[ng-click='toggleOpen()']")
	WebElement ELECTRICAL_SEC_CSS;

	@FindBy(css = "div[label='Wiring'] select")
	WebElement ELECTRICAL_WIRING_DROP_CSS;

	@FindBy(name = "div[label='Wiring'] span")
	WebElement ELECTRICAL_WIRING_LBL_NAME;

	@FindBy(css = "css=div[label='Electrical System'] span")
	WebElement ELECTRICAL_SYSTEM_LBL_CSS;

	@FindBy(css = "div[label='Electrical System'] select")
	WebElement ELECTRICAL_SYSTEM_DROP_CSS;

	@FindBy(css = "[model='view.wiringType'] [class='gw-inline-messages'] span")
	WebElement ELECTRICAL_WIRING_OTHER_TYPE_TXT_CSS;

	@FindBy(css = "[upgrade-exists*='wiringUpgradeExists'] input[type='checkbox']")
	WebElement ELECTRICAL_SYSTEM_CHK_CSS;

	@FindBy(css = "[model='view.electricalType'] [class='gw-inline-messages'] span")
	WebElement ELECTRICAL_SYSTEM_OTHER_TYPE_TXT_CSS;

	@FindBy(css = "label[for='WiringUpgradeExists'] span, [label='Wiring Upgraded'] input[type='number']")
	WebElement ELECTRICAL_SYSTEM_UPGRADE_LBL_CSS;

	@FindBy(css = "[upgrade-exists*='wiringUpgradeExists'] input[type='number'], [label='Wiring Upgraded'] input[type='number']")
	WebElement ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS;

	@FindBy(css = "//div[@validation-form='electricalForm']//div[@class='gw-panel-collapse gw-collapse gw-in']")
	WebElement ELECTRICAL_SEC_XPATH;
	
//	String BUILT_YEAR_VALUE_MODEL = "view.yearBuilt";
//	String STORIES_VALUE_MODEL = "view.storiesNumber";
//	String GARAGE_VALUE_MODEL = "view.hasGarage";
//	String CONSTRUCTION_TYPE_VALUE_MODEL = "view.constructionType";
//	String FOUNDATION_TYPE_VALUE_MODEL = "view.foundationType";
//	String ROOF_TYPE_MODEL = "view.roofType";
//	String PLUMBING_TYPE_VALUE_MODEL = "view.plumbingType";
//	String HEATING_TYPE_VALUE_MODEL = "view.plumbingType";
//	String PRIMARY_HEATING_TYPE_MODEL = "view.primaryHeatingType";
//	String SECONDARY_HEATING_TYPE_MODEL = "view.secondaryHeatingExists";
//	String WIRING_TYPE_MODEL = "view.wiringType";
//	String ELECTRICAL_SYSTEM_MODEL = "view.electricalType";
	String BUILT_YEAR_VALUE_MODEL = "Year Built";
	String STORIES_VALUE_MODEL = "Number of Stories";
	String GARAGE_VALUE_MODEL = "Garage";
	String CONSTRUCTION_TYPE_VALUE_MODEL = "Construction Type";
	String FOUNDATION_TYPE_VALUE_MODEL = "Foundation Type";
	String ROOF_TYPE_MODEL = "Roof";
	String PLUMBING_TYPE_VALUE_MODEL = "Plumbing";
	String HEATING_TYPE_VALUE_MODEL = "Primary Heating";
	String PRIMARY_HEATING_TYPE_MODEL = "Primary Heating";
	String SECONDARY_HEATING_TYPE_MODEL = "Secondary Heating";
	String WIRING_TYPE_MODEL = "Wiring";
	String ELECTRICAL_SYSTEM_MODEL = "Electrical System";

//	INOW Model
	String INOW_BUILT_YEAR_VALUE_MODEL = "What year was your home built?";
	String INOW_MATERIAL_MADEOF_VALUE_MODEL = "What material is your house made of?";
	String INOW_STORIES_VALUE_MODEL = "Stories";
	String INOW_UNITS_VALUE_MODEL = "Units";
	String INOW_ROOFTYPE_VALUE_MODEL ="What type of roof do you have?";

	By SELECTED_ROOF_TYPE =  By.cssSelector ("input:checked + div img");

	By STORY_DROP =  By.cssSelector("[model='view.storiesNumber'] select, [label='Number of Stories'] select");
	
	String CONS_DETAIL_SEC_XPATH = "//div[@validation-form='detailsForm'][@ng-init] | //*[contains(@name,'detailsForm')]/div";



	// iNow locators
	@FindBy(css = "[label='What material is your house made of?'] select")
	WebElement INOW_MATERIAL_HOUSE_MADE_DROPDOWN;

	@FindBy(css = "[label='Stories'] input")
	WebElement INOW_STORIES_INPUT;

	@FindBy(css = "[label='Units'] input")
	WebElement INOW_UNITS_INPUT;

	By ROOF_H2_XPATH = By.xpath("//*[@name='validationForms[roofForm]']");
	By ROOFTYPE_PARENT_XPATH = By.xpath("//*[@label='What type of roof do you have?']");
	By ROOFTYPE_CHILD_XPATH = By.xpath("//label/input[@type='radio']");


	public ConstructionPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public ConstructionPage(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public DiscountPage goToDiscountPage() {
		this.goNext();
		return new Pagefactory().getDiscountPage();
	}

	public ConstructionPage expandConstructionSection() {
		seleniumCommands
				.waitForElementToBeClickable(By.cssSelector(ConstructionPageLocators.CONSTRUCTION_DETAILS_SEC_CSS));
		if(!seleniumCommands.findElement(By.xpath(CONS_DETAIL_SEC_XPATH)).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.clickbyJS(CONSTRUCTION_DETAILS_SEC_CSS);
		}
		seleniumCommands.waitForElementToBeVisible(BUILD_YEAR_TXT_CSS);
		return this;
	}

	public ConstructionPage expandRoofSection() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(ConstructionPageLocators.ROOF_DETAILS_SEC_CSS));
		if(!ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[roofForm]'] > div, div[validation-form='roofsForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.clickbyJS(ROOF_DETAILS_SEC_CSS);
		}
		seleniumCommands.waitForElementToBePresent(By.cssSelector(ConstructionPageLocators.ROOFTYPES_SEC_XPATH));
		return this;
	}

	public ConstructionPage expandPlumbingSection() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(ConstructionPageLocators.PLUMBING_DETAILS_SEC_CSS));
		if(!ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[plumbingForm]'] > div, div[validation-form='plumbingForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.clickbyJS(PLUMBING_DETAILS_SEC_CSS);
		}
		seleniumCommands.waitForElementToBePresent(By.cssSelector(ConstructionPageLocators.PLUMBING_SEC_XPATH), 10000);
		seleniumCommands.waitForElementToBeVisible(PLUMBING_TYPE_DROP_CSS);
		return this;
	}

	public ConstructionPage expandHeatingSection() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(ConstructionPageLocators.HEATING_SEC_CSS));
		if(!ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[heatingForm]'] > div, div[validation-form='heatingForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.clickbyJS(HEATING_SEC_CSS);
		}
		seleniumCommands.waitForElementToBePresent(By.cssSelector(ConstructionPageLocators.HEATING_SEC_XPATH), 10000);
		return this;
	}

	public ConstructionPage expandElectricSection() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(ConstructionPageLocators.ELECTRICAL_SEC_CSS));
		if(!ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[electricalForm]'] > div, div[validation-form='electricalForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.click(ELECTRICAL_SEC_CSS);
		}
		seleniumCommands.waitForElementToBePresent(By.cssSelector(ConstructionPageLocators.ELECTRICAL_SEC_XPATH), 10000);
		return this;
	}

	public ConstructionPage hideConstructionSection() {
		return null;
	}

	public ConstructionPage hideRoofSection() {
		if(ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[roofForm]'] > div, div[validation-form='roofsForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.click(ROOF_DETAILS_SEC_CSS);
		}
		return this;
	}

	public ConstructionPage hidePlumbingSection() {
		if(ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[plumbingForm]'] > div, div[validation-form='plumbingForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.click(PLUMBING_DETAILS_SEC_CSS);
		}
		return this;
	}

	public ConstructionPage hideHeatingSection() {
		if(ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[heatingForm]'] > div, div[validation-form='heatingForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.click(HEATING_SEC_CSS);
		}
		return this;
	}

	public ConstructionPage hideElectricSection() {
		if(!ThreadLocalObject.getDriver().findElement(By.cssSelector("[name='validationForms[electricalForm]'] > div, div[validation-form='electricalForm']")).getAttribute("class").contains("is-open"))
		{
			seleniumCommands.click(ELECTRICAL_SEC_CSS);
		}
		return this;
	}

	// Set Methods

	public ConstructionPage withBuildYear(String buildYear) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.BUILD_YEAR_TXT_CSS));
		BUILD_YEAR_TXT_CSS.sendKeys(buildYear);
		return this;
	}

	public ConstructionPage withiNowBuildYear() {
		seleniumCommands.type(BUILD_YEAR_TXT_CSS, data.get("BuildYear"));
		return this;
	}
	public ConstructionPage withiNowStories() {
		seleniumCommands.type(INOW_STORIES_INPUT, data.get("Stories"));
		return this;
	}
	public ConstructionPage withiNowUnits() {
		seleniumCommands.type(INOW_UNITS_INPUT, data.get("NumUnits"));
		return this;
	}
	public ConstructionPage withConstructionMeterial() {
		seleniumCommands.selectDropDownValueByText(INOW_MATERIAL_HOUSE_MADE_DROPDOWN, data.get("MaterialHouseMade"));
		return this;
	}

	public ConstructionPage withiNowRoofType(String roofType) {

		// Expand Roof items
		seleniumCommands.click(ROOF_H2_XPATH);
		seleniumCommands.waitForElementToBeVisible(ROOFTYPE_PARENT_XPATH);
		WebElement roofParentElement  = seleniumCommands.getElement(ROOFTYPE_PARENT_XPATH);

		List <WebElement> roofItems = seleniumCommands.findElements(roofParentElement, ROOFTYPE_CHILD_XPATH);

		for ( WebElement item: roofItems ){
			WebElement roof = item.findElement(By.xpath(".."));
			if( roof.getText().equalsIgnoreCase(roofType)){
				roof.click();
			}
		}
		return this;
	}

	public String getiNowRoofType() {

		// Expand Roof items
		seleniumCommands.click(ROOF_H2_XPATH);
		seleniumCommands.waitForElementToBeVisible(ROOFTYPE_PARENT_XPATH);
		WebElement roofParentElement  = seleniumCommands.getElement(ROOFTYPE_PARENT_XPATH);

		List <WebElement> roofItems = seleniumCommands.findElements(roofParentElement, ROOFTYPE_CHILD_XPATH);

		for ( WebElement item: roofItems ){

			if( item.getAttribute("aria-checked").equalsIgnoreCase("true")){
				return item.findElement(By.xpath("..")).getText();
			}
		}
		return "";
	}


	public ConstructionPage withBuildYear() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.BUILD_YEAR_TXT_CSS));
		BUILD_YEAR_TXT_CSS.sendKeys(data.get("BuildYear"));
		return this;
	}

	public ConstructionPage withHouseStories(String stories) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.STORIES_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(STORIES_DROP_CSS, stories);
		return this;
	}

	public ConstructionPage withHouseStories() {
		if(seleniumCommands.isElementPresent(STORY_DROP))
		{
			seleniumCommands.selectDropDownValueByText(STORIES_DROP_CSS, data.get("Stories"));
		}
		else
		{
			seleniumCommands.type(STORIES_TXT_CSS, data.get("Stories"));
		}
		return this;
	}
	
	public ConstructionPage withGarage() {
		seleniumCommands.selectDropDownValueByText(STORIES_DROP_CSS, data.get("Stories"));
		if(data.get("Garage").equals("NoGarage"))
		{
			NO_GARAGE_RBTN_CSS.click();
		}
		else if(data.get("Garage").equals("AttachedGarage"))
		{
			ATTACHED_GARAGE_RBTN_CSS.click();
		}
		return this;
	}
	
	public ConstructionPage withGarage(String Value) {
		seleniumCommands.selectDropDownValueByText(STORIES_DROP_CSS, data.get("Stories"));
		if(Value.equals("NoGarage"))
		{
			//NO_GARAGE_RBTN_CSS.click();
		}
		else if(Value.equals("AttachedGarage"))
		{
			ATTACHED_GARAGE_RBTN_CSS.click();
		}
		return this;
	}

	private ConstructionPage selectNoGarage() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.NO_GARAGE_RBTN_CSS));
		NO_GARAGE_RBTN_CSS.click();
		return this;
	}

	private ConstructionPage selectAttachedGarage() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.ATTACHED_GARAGE_RBTN_CSS));
		ATTACHED_GARAGE_RBTN_CSS.click();
		return this;
	}

	public ConstructionPage withConstructionType(String type) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.CONSTRUCTION_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(CONSTRUCTION_DROP_CSS, type);
		return this;
	}

	public ConstructionPage withConstructionType() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.CONSTRUCTION_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(CONSTRUCTION_DROP_CSS, data.get("ConstructionType"));
		return this;
	}

	public ConstructionPage withFoundationType(String foundationType) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.FOUNDATION_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(FOUNDATION_DROP_CSS, foundationType);
		return this;
	}

	public ConstructionPage withFoundationType() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.FOUNDATION_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(FOUNDATION_DROP_CSS, data.get("FoundationType"));
		return this;
	}

	public ConstructionPage withRoofType(String roofType) {
		WebDriver driver = ThreadLocalObject.getDriver();
		By locator = By.xpath("[src='../styles/images/ho/roof/" + "RoofType" + ".jpg']");
		seleniumCommands.waitForElementToBeVisible(locator);
		WebElement element = driver.findElement(locator);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		element.click();
		if(roofType.equals("other"))
		{
			seleniumCommands.waitForElementToBeVisible(OTHER_ROOF_TYPE_DESC_CSS);
			seleniumCommands.type(OTHER_ROOF_TYPE_DESC_CSS, data.get("RoofOtherTypeDesc"));
			
		}
		return this;
	}

	public ConstructionPage withRoofType() {
		WebDriver driver = ThreadLocalObject.getDriver();
		By locator = By.xpath("//*[@src='../styles/images/common/roof/" + data.get("RoofType") + ".jpg']/../..");
		System.out.println("Browser in Roof" + data.get("Browser"));
		seleniumCommands.waitForElementToBeVisible(locator);
		WebElement element = driver.findElement(locator);
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		element.click();
		if(data.get("RoofType").equals("other"))
		{
			seleniumCommands.waitForElementToBeVisible(OTHER_ROOF_TYPE_DESC_CSS);
			seleniumCommands.type(OTHER_ROOF_TYPE_DESC_CSS, data.get("RoofOtherTypeDesc"));

		}
		return this;
	}


	private ConstructionPage withRoofUpgraded() {
		// seleniumCommands.waitForElementToBeVisible(By.name(ConstructionPageLocators.ROOF_UPGRADE_CHK_ID));
		this.expandRoofSection();
		seleniumCommands.clickbyJS(ROOF_UPGRADE_CHK_CSS);
		return this;
	}

	public ConstructionPage withRoofUpgradeYear() {
		withRoofUpgraded();
		seleniumCommands.type(ROOF_UPGRADE_YEAR_TXT_CSS, data.get("RoofUpgradeYear"));
		return this;
	}

	public ConstructionPage withRoofUpgradeYear(String year) {
		withRoofUpgraded();
		seleniumCommands.type(ROOF_UPGRADE_YEAR_TXT_CSS, year);
		return this;
	}

	public ConstructionPage withPlumbingType() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.PLUMBING_TYPE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(PLUMBING_TYPE_DROP_CSS, data.get("PlumbingType"));
		return this;
	}

	public ConstructionPage withPlumbingType(String type) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.PLUMBING_TYPE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(PLUMBING_TYPE_DROP_CSS, type);
		return this;
	}

	private ConstructionPage selectPlumbingUpgraded() {
		this.expandPlumbingSection();
		seleniumCommands.staticWait(2);
		seleniumCommands.clickbyJS(PLUMBING_UPGRADE_CHK_CSS);
		return this;
	}

	public ConstructionPage withPlumbingUpgradeYear(String year) {
		selectPlumbingUpgraded();
		seleniumCommands.type(PLUMBING_UPGRADE_YEAR_TXT_CSS, year);
		return this;
	}

	public ConstructionPage withPlumbingUpgradeYear() {
		selectPlumbingUpgraded();
		seleniumCommands.type(PLUMBING_UPGRADE_YEAR_TXT_CSS, data.get("PlumbingUpgradeYear"));
		return this;
	}

	public ConstructionPage withHeatingType(String type) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.PRIMARY_HEATING_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(PRIMARY_HEATING_DROP_CSS, type);
		if(type.equals("Other"))
		{
			seleniumCommands.waitForElementToBeVisible(OTHER_PRIMARY_HEATING_DESC_CSS);
			seleniumCommands.type(OTHER_PRIMARY_HEATING_DESC_CSS, data.get("PrimaryHeatingOtherTypeDesc"));
			
		}
		return this;
	}

	public ConstructionPage withHeatingType() {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.PRIMARY_HEATING_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(PRIMARY_HEATING_DROP_CSS, data.get("HeatingType"));
		if(data.get("HeatingType").equals("Other"))
		{
			seleniumCommands.waitForElementToBeVisible(OTHER_PRIMARY_HEATING_DESC_CSS);
			seleniumCommands.type(OTHER_PRIMARY_HEATING_DESC_CSS, data.get("PrimaryHeatingOtherTypeDesc"));

		}

		return this;
	}
	public ConstructionPage withSecondaryHeating(boolean selection) {
		if (selection) {
			SECONDARY_HEATING_YES_RBTN_ID.click();
		} else {
			SECONDARY_HEATING_NO_RBTN_ID.click();
		}
		return this;
	}

	public ConstructionPage withSecondaryHeating() {
		if (new Boolean(data.get("SecondaryHeating"))) {
			SECONDARY_HEATING_YES_RBTN_ID.click();
		} else {
			SECONDARY_HEATING_NO_RBTN_ID.click();
		}
		return this;
	}

	private ConstructionPage selectHeatingUpgraded() {
		this.expandHeatingSection();
		seleniumCommands.staticWait(2);
		seleniumCommands.clickbyJS(HEATING_UPGRADE_CHK_CSS);
		return this;

	}

	public ConstructionPage withHeatingUpgradeYear(String year) {
		this.selectHeatingUpgraded();
		seleniumCommands.type(HEATING_UPGRADE_YEAR_TXT_CSS, year);
		return this;
	}

	public ConstructionPage withHeatingUpgradeYear() {
		this.selectHeatingUpgraded();
		seleniumCommands.type(HEATING_UPGRADE_YEAR_TXT_CSS, data.get("HeatingUpgradeYear"));
		return this;
	}

	public ConstructionPage withElectricalWiringType() {
		seleniumCommands.selectDropDownValueByText(ELECTRICAL_WIRING_DROP_CSS, data.get("WiringType"));
		return this;
	}

	public ConstructionPage withElectricalWiringType(String wiringType) {
		seleniumCommands.selectDropDownValueByText(ELECTRICAL_WIRING_DROP_CSS, wiringType);
		return this;
	}

	public ConstructionPage withElectricalSystemType(String wiringType) {
		seleniumCommands.selectDropDownValueByText(ELECTRICAL_SYSTEM_DROP_CSS, wiringType);
		return this;
	}

	public ConstructionPage withElectricalSystemType() {
		seleniumCommands.selectDropDownValueByText(ELECTRICAL_SYSTEM_DROP_CSS, data.get("ElectricalSystemType"));
		return this;
	}

	private ConstructionPage selectWiringUpgraded() {
		this.expandElectricSection();
		seleniumCommands.staticWait(2);
		seleniumCommands.clickbyJS(ELECTRICAL_SYSTEM_CHK_CSS);
		return this;
	}

	public ConstructionPage withWiringUpgradeYear() {
		this.selectWiringUpgraded();
		seleniumCommands.type(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS, data.get("WiringUpgradeYear"));
		return this;
	}

	public ConstructionPage withWiringUpgradeYear(String heatingUpgradeYear) {
		this.selectWiringUpgraded();
		seleniumCommands.type(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS, heatingUpgradeYear);
		return this;
	}
	
	public ConstructionPage withConstructionUpgradeYear() {
		this.withRoofUpgradeYear().withPlumbingUpgradeYear().withHeatingUpgradeYear().withWiringUpgradeYear();
		return this;
	}
	

	// Get Methods

	private String getBuildYear() {
		return seleniumCommands.getAttributeValueAtLocator(BUILD_YEAR_TXT_CSS, "value");
	}

	private String getBuildingStories() {
		if(seleniumCommands.isElementPresent(STORY_DROP)) {
			return seleniumCommands.getSelectedOptionFromDropDown(STORIES_DROP_CSS);
		}

			return seleniumCommands.getValueAttributeFromLocator(STORIES_TXT_CSS);
	}

	private String getGarageInPropertyStatus() {
		if (ATTACHED_GARAGE_RBTN_CSS.isSelected()) {
			return "AttachedGarage";
		} else if (NO_GARAGE_RBTN_CSS.isSelected()) {
			return "NoGarage";
		}
		return null;
	}

	private String getConstructionType() {
		return seleniumCommands.getSelectedOptionFromDropDown(CONSTRUCTION_DROP_CSS);
	}

	private String getFoundationType() {
		return seleniumCommands.getSelectedOptionFromDropDown(FOUNDATION_DROP_CSS);
	}

	private String getRoofType() {
		seleniumCommands.pageWebElementLoader(this);
		 String imageSRC =  seleniumCommands.getAttributeValueAtLocator(SELECTED_ROOF_TYPE, "src");
		 return imageSRC.substring(imageSRC.lastIndexOf("/") +1).replace(".jpg", "");
	}

	private boolean getRoofUpgradeStatus() {
		return new Boolean(seleniumCommands.getAttributeValueAtLocator(ROOF_UPGRADE_CHK_CSS, "aria-checked"));
	}

	private String getRoofUpgradeYear() {
		return seleniumCommands.getAttributeValueAtLocator(ROOF_UPGRADE_YEAR_TXT_CSS, "value");
	}

	private String getPlumbingType() {
		return seleniumCommands.getSelectedOptionFromDropDown(PLUMBING_TYPE_DROP_CSS);
	}

	private boolean getPlumbingUpgradeStatus() {
		return new Boolean(seleniumCommands.getAttributeValueAtLocator(PLUMBING_UPGRADE_CHK_CSS, "aria-checked"));
	}

	private String getPlumbingUpgradeYear() {
		return seleniumCommands.getAttributeValueAtLocator(PLUMBING_UPGRADE_YEAR_TXT_CSS, "value");
	}

	private String getPrimaryHeatingType() {
		return seleniumCommands.getSelectedOptionFromDropDown(PRIMARY_HEATING_DROP_CSS);
	}

	private boolean getHeatUpgradeStatus() {
		return new Boolean(seleniumCommands.getAttributeValueAtLocator(HEATING_UPGRADE_CHK_CSS, "aria-checked"));
	}

	private String getHeatUpgradeYear() {
		return seleniumCommands.getAttributeValueAtLocator(HEATING_UPGRADE_YEAR_TXT_CSS, "value");
	}

	private boolean getSecondaryHeatingStatus() {
		if (SECONDARY_HEATING_YES_VALUE_RBTN_ID.isSelected()) {
			return true;
		} else if (SECONDARY_HEATING_NO_VALUE_RBTN_ID.isSelected()) {
			return false;
		}
		return false;
	}

	private String getElectricalWiringType() {
		return seleniumCommands.getSelectedOptionFromDropDown(ELECTRICAL_WIRING_DROP_CSS);
	}

	private String getElectricalSystemType() {
		return seleniumCommands.getSelectedOptionFromDropDown(ELECTRICAL_SYSTEM_DROP_CSS);
	}

	private boolean getWiringUpgradeStatus() {
		return new Boolean(seleniumCommands.getAttributeValueAtLocator(ELECTRICAL_SYSTEM_CHK_CSS, "aria-checked"));
	}

	private String getWiringUpgradeYear() {
		return seleniumCommands.getAttributeValueAtLocator(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS, "value");
	}

	// Validation Methods

	public Validation isBuildYearEqualsTo() {
		return new Validation(getBuildYear(), data.get("BuildYear"));
	}
	
	public Validation isBuildYearFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(BUILD_YEAR_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowMaterialMadeOfFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDropdown(INOW_MATERIAL_HOUSE_MADE_DROPDOWN), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation areInowStoriesFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(INOW_STORIES_INPUT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation areInowUnitsFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(INOW_UNITS_INPUT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowBuildingMaterialMadeOf() {
		return new Validation(seleniumCommands.getSelectedOptionFromDropDown(INOW_MATERIAL_HOUSE_MADE_DROPDOWN), data.get("MaterialHouseMade"));
	}
	public Validation areInowStoriesEqualsTo() {
		return new Validation(seleniumCommands.getAttributeValueAtLocator(INOW_STORIES_INPUT, "value"), data.get("Stories"));
	}
	public Validation areInowUnitsEqualsTo() {
		return new Validation(seleniumCommands.getAttributeValueAtLocator(INOW_UNITS_INPUT, "value"), data.get("NumUnits"));
	}
	public Validation isInowRoofTypeEqualsTo() {
		return new Validation(getiNowRoofType(), data.get("INOW_RoofType"));
	}

	public Validation areBuildlingStoriesEqualsTo() {
		return new Validation(getBuildingStories(), data.get("Stories"));
	}
	
	public Validation isBuildlingStoriesFieldmarkedWithError() {
		if(seleniumCommands.isElementPresent(STORY_DROP)) {
			return new Validation(seleniumCommands.getErrorMessageForTxtBox(STORIES_DROP_CSS), DataConstant.MANDATORY_ERROR_MSG);
		}
			return new Validation(seleniumCommands.getErrorMessageForTxtBox(STORIES_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isGarageAvailable() {
		return new Validation(getGarageInPropertyStatus(),  data.get("Garage"));
	}

	public Validation isConstructionTypeEqualsTo() {
		return new Validation(getConstructionType(), data.get("ConstructionType"));
	}
	
	public Validation isConstructionTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ThreadLocalObject.getDriver().findElement(By.xpath("//*[contains(@model,'constructionType')]//select/.."))), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isFoundationTypeEqualsTo() {
		return new Validation(getFoundationType(), data.get("FoundationType"));
	}
	
	public Validation isFoundationTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(FOUNDATION_DROP_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isRoofTypeEqualsTo(String roofType) {
		return new Validation(getRoofType(), roofType);
	}
	
	public Validation isRoofTypeEqualsTo() {
		return new Validation(getRoofType(), data.get("RoofType"));
	}
	
	public Validation isRoofMarkedWithError() {
		seleniumCommands.staticWait(2);
		return new Validation(seleniumCommands.getTextAtLocator(ROOF_SECTION_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowRoofMarkedWithError() {
		seleniumCommands.staticWait(2);
		// Expand Roof items
		seleniumCommands.click(ROOF_H2_XPATH);
		seleniumCommands.waitForElementToBeVisible(INOW_ROOF_SECTION_ERR_CSS);
		return new Validation(seleniumCommands.getTextAtLocator(INOW_ROOF_SECTION_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isRoofUpgraded() {
		return new Validation(getRoofUpgradeStatus());
	}
	
	public Validation isRoofUpGradeMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ROOF_UPGRADE_YEAR_TXT_CSS), DataConstant.UPGRADE_YEAR_SHOULD_BE_LATER_THAN_2010_ERROR);
	}

	public Validation isRoofUpgradedMarkedWithMandatoryError() {
		seleniumCommands.staticWait(2);
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ROOF_UPGRADE_YEAR_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isRoofUpgradedMarkedWithNumericError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ROOF_UPGRADE_YEAR_TXT_CSS), DataConstant.NUMBER_FORMAT_ERROR_MSG);
	}

	public Validation isRoofUpgradeYearEqualsTo() {
		return new Validation(getRoofUpgradeYear(), data.get("RoofUpgradeYear"));
	}

	public Validation isPlumbingTypeEqualsTo() {
		return new Validation(getPlumbingType(), data.get("PlumbingType"));
	}

	public Validation isPlumbingUpgraded() {
		return new Validation(getPlumbingUpgradeStatus());
	}
	
	public Validation isPlumbingUpGradeMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(PLUMBING_UPGRADE_YEAR_TXT_CSS), DataConstant.UPGRADE_YEAR_SHOULD_BE_LATER_THAN_2010_ERROR);
	}

	public Validation isPlumbingUpgradedMarkedWithMandatoryError() {
		seleniumCommands.staticWait(2);
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(PLUMBING_UPGRADE_YEAR_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isPlumbingUpgradedMarkedWithNumericError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(PLUMBING_UPGRADE_YEAR_TXT_CSS), DataConstant.NUMBER_FORMAT_ERROR_MSG);
	}

	public Validation isPlumbingUpgradeYearEqualsTo() {
		return new Validation(getPlumbingUpgradeYear(), data.get("PlumbingUpgradeYear"));
	}
	public Validation isPlumbingTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ThreadLocalObject.getDriver().findElement(By.xpath("//*[contains(@model,'plumbing')]//select/.."))), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isPlumbingOtherTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(PLUMBING_OTHER_TYPE_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isHeatingTypeEqualsTo() {
		return new Validation(getPrimaryHeatingType(), data.get("HeatingType"));
	}

	public Validation isSecondaryHeatingAvailable() {
		return new Validation(getSecondaryHeatingStatus());
	}

	public Validation isHeatingUpgraded() {
		return new Validation(getHeatUpgradeStatus());
	}
	
	public Validation isHeatingTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ThreadLocalObject.getDriver().findElement(By.xpath("//*[contains(@model,'primaryHeatingType')]//select/.."))), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isHeatingTypeOtherFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(PRIMARY_OTHER_TYPE_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	public Validation isHeatingUpGradeMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(HEATING_UPGRADE_YEAR_TXT_CSS), DataConstant.UPGRADE_YEAR_SHOULD_BE_LATER_THAN_2010_ERROR);
	}

	public Validation isHeatingUpgradedMarkedWithMandatoryError() {
		seleniumCommands.staticWait(2);
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(HEATING_UPGRADE_YEAR_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isHeatingUpgradedMarkedWithNumericError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(HEATING_UPGRADE_YEAR_TXT_CSS), DataConstant.NUMBER_FORMAT_ERROR_MSG);
	}

	public Validation isHeatingUpgradeYearEqualsTo() {
		return new Validation(getHeatUpgradeYear(), data.get("HeatingUpgradeYear"));
	}

	public Validation isWiringTypeEqualsTo() {
		return new Validation(getElectricalWiringType(), data.get("WiringType"));
	}

	public Validation isElectricalSystemEqualsTo() {
		return new Validation(getElectricalSystemType(), data.get("ElectricalSystemType"));
	}
	
	public Validation isWiringTypeFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ThreadLocalObject.getDriver().findElement(By.xpath("//*[contains(@model,'wiringType')]//select/.."))), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isElectricalWiringTypeOtherFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(ELECTRICAL_WIRING_OTHER_TYPE_TXT_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isElectricalWiringUpgradeMarkedWithNumericError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS), DataConstant.NUMBER_FORMAT_ERROR_MSG);
	}

	public Validation isElectricalSystemTypeOtherFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(ELECTRICAL_SYSTEM_OTHER_TYPE_TXT_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isElectricalWiringUpGradeMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS), DataConstant.UPGRADE_YEAR_SHOULD_BE_LATER_THAN_2010_ERROR);
	}

	public Validation isElectricalWiringUpgradeMarkedWithMandatoryError() {
		seleniumCommands.staticWait(2);
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ELECTRICAL_SYSTEM_UPGRADE_YEAR_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isWiringUpgraded() {
		return new Validation(getWiringUpgradeStatus());
	}

	public Validation isWiringUpgradeYearEqualsTo() {
		return new Validation(getWiringUpgradeYear(), data.get("WiringUpgradeYear"));
	}

	public ConstructionPage goNext() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public ConstructionPage setConstructionPageDetails() {
		this.withBuildYear().withHouseStories().withConstructionType().withFoundationType().expandRoofSection()
				.withRoofType().expandPlumbingSection().withPlumbingType().expandHeatingSection().withHeatingType()
				.expandElectricSection().withElectricalWiringType().withElectricalSystemType();
		return this;
	}

	public ConstructionPage setiNowConstructionPageDetails() {
		this.withiNowBuildYear().withConstructionMeterial().withiNowStories().withiNowUnits().withiNowRoofType(data.get("INOW_RoofType"));
		return this;
	}

	public ConstructionPage setConstructionPageDetailsWithUpgradedYear() {
		this.withBuildYear().withHouseStories().withConstructionType().withFoundationType().expandRoofSection()
				.withRoofType().withRoofUpgradeYear().expandPlumbingSection().withPlumbingType().withPlumbingUpgradeYear().expandHeatingSection()
				.withHeatingType().withHeatingUpgradeYear().expandElectricSection().withElectricalWiringType().withElectricalSystemType().withWiringUpgradeYear();
		return this;
	}

	public ConstructionPage withUpgradeYear() {
		this.expandRoofSection()
				.withRoofType().expandPlumbingSection().withPlumbingType().expandHeatingSection().withHeatingType()
				.expandElectricSection().withElectricalWiringType().withElectricalSystemType().withConstructionUpgradeYear();
		return this;
	}

	
	public Validation areConstructionPageFieldsMakedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields on Construction page");
		isBuildYearFieldmarkedWithError().shouldBeEqual("Build year  Field is not marked with Error");
		isBuildlingStoriesFieldmarkedWithError().shouldBeEqual("No of Stories Field is not marked with Error");
		isConstructionTypeFieldmarkedWithError().shouldBeEqual("Construction type Field is not marked with Error");
		isFoundationTypeFieldmarkedWithError().shouldBeEqual("Foundation type Field is not marked with Error");
		expandRoofSection();
		isRoofMarkedWithError().shouldBeEqual("Roof Section Field is not marked with Error");
		hideRoofSection();
		expandPlumbingSection();
		isPlumbingTypeFieldmarkedWithError().shouldBeEqual("Plumbing type Field is not marked with Error");
		hidePlumbingSection();
		expandHeatingSection();
		isHeatingTypeFieldmarkedWithError().shouldBeEqual("Heating type Field is not marked with Error");
		hideHeatingSection();
		expandElectricSection();
		isWiringTypeFieldmarkedWithError().shouldBeEqual("Wiring type Field is not marked with Error");
		hideElectricSection();
		return new Validation(true);
    }

	public Validation areInowConstructionPageFieldsMakedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields on Construction page");
		isBuildYearFieldmarkedWithError().shouldBeEqual("Build year  Field is not marked with Error");
		isInowMaterialMadeOfFieldmarkedWithError().shouldBeEqual("Material Made of Field is not marked with Error");
		areInowStoriesFieldmarkedWithError().shouldBeEqual("Number of Stories Field is not marked with Error");
		areInowUnitsFieldmarkedWithError().shouldBeEqual("Number of Units Field is not marked with Error");

		isInowRoofMarkedWithError().shouldBeEqual("Roof Section Field is not marked with Error");
		return new Validation(true);
	}
	
	public Validation areConstructionPageMandatoryFieldsMakedWithAsterisk() {
		logger.info( "Validating the Asterisk for mandatory field on Your Home page");
		isAsteriskPresentForMandatoryField(BUILT_YEAR_VALUE_MODEL).shouldBeEqual("Build year value Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(STORIES_VALUE_MODEL).shouldBeEqual("Stories Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(GARAGE_VALUE_MODEL).shouldBeEqual("Garage type Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(CONSTRUCTION_TYPE_VALUE_MODEL).shouldBeEqual("Construction type value Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(FOUNDATION_TYPE_VALUE_MODEL).shouldBeEqual("Foundation type value Field is not marked with Asterisk");
		expandRoofSection();
		isAsteriskPresentForMandatoryField(ROOF_TYPE_MODEL).shouldBeEqual("Roof type Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(PLUMBING_TYPE_VALUE_MODEL).shouldBeEqual("Plumbing type Field is not marked with Asterisk");
		expandHeatingSection();
		isAsteriskPresentForMandatoryField(PRIMARY_HEATING_TYPE_MODEL).shouldBeEqual("Primary heating is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(SECONDARY_HEATING_TYPE_MODEL).shouldBeEqual("Secondary heating Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(WIRING_TYPE_MODEL).shouldBeEqual("Wiring type is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(ELECTRICAL_SYSTEM_MODEL).shouldBeEqual("Electrical system Field is not marked with Asterisk");
		return new Validation(true);
	}

	public Validation areInowConstructionPageMandatoryFieldsMakedWithAsterisk() {
		logger.info( "Validating the Asterisk for mandatory field on Your Home page");
		isAsteriskPresentForMandatoryField(INOW_BUILT_YEAR_VALUE_MODEL).shouldBeEqual("Build year value Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_MATERIAL_MADEOF_VALUE_MODEL).shouldBeEqual("Material made of is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_STORIES_VALUE_MODEL).shouldBeEqual("Number of Stories Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_UNITS_VALUE_MODEL).shouldBeEqual("Number of Units type value Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_ROOFTYPE_VALUE_MODEL).shouldBeEqual("ROOF type value Field is not marked with Asterisk");
		return new Validation(true);
	}
	
	public Validation areConstructionPageDetailsSaved() {
		logger.info( "Validating the data saved for the Construction page");
		expandConstructionSection();
		isBuildYearEqualsTo().shouldBeEqual("Build year value is not matched");
		areBuildlingStoriesEqualsTo().shouldBeEqual("No of buildings value is not matched");
		isGarageAvailable().shouldBeEqual("Garage availability value is not matched");
		isConstructionTypeEqualsTo().shouldBeEqual("Construction value is not matched");
		isFoundationTypeEqualsTo().shouldBeEqual("Foundation value is not matched");

		expandRoofSection();
		isRoofTypeEqualsTo().shouldBeEqual("Roof type value is not matched" );
		
		expandPlumbingSection();
		isPlumbingTypeEqualsTo().shouldBeEqual("Plumbing value is not matched");
		
		expandHeatingSection();
		isHeatingTypeEqualsTo().shouldBeEqual("Heating type value is not matched");
		isSecondaryHeatingAvailable().shouldBeTrue("Secondary heating value is not matched");
				
		expandElectricSection();
		isWiringTypeEqualsTo().shouldBeEqual("Wiring type value is not matched");
		isElectricalSystemEqualsTo().shouldBeEqual("Electrical system value is not matched");
		
		return new Validation(true);
	}


	public Validation areInowConstructionPageDetailsSaved() {
		logger.info( "Validating the data saved for the Construction page");
		expandConstructionSection();
		isBuildYearEqualsTo().shouldBeEqual("Build year value is not matched");
		isInowBuildingMaterialMadeOf().shouldBeEqual("House Material made of is not matched");
		areInowStoriesEqualsTo().shouldBeEqual("No of Stories value is not matched");
		areInowUnitsEqualsTo().shouldBeEqual("No of Units value is not matched");
		isInowRoofTypeEqualsTo().shouldBeEqual("Roof type value is not matched" );

		return new Validation(true);
	}
	public Validation areConstructionUpgradeDetailsSaved() {
		logger.info( "Validating the data saved for the Construction page");
		
		expandRoofSection();
		isRoofUpgraded().shouldBeTrue("Roof upgrade check box value is not matched");
		isRoofUpgradeYearEqualsTo().shouldBeEqual("Roof upgrade value is not matched");
		
		expandPlumbingSection();
		isPlumbingUpgraded().shouldBeTrue("Plumbing checkbox value is not matched");
		isPlumbingUpgradeYearEqualsTo().shouldBeEqual("Plumbing upgrade value is not matched");
		
		expandHeatingSection();
		isHeatingUpgradeYearEqualsTo().shouldBeEqual("Heating upgrade value is not matched");
		isHeatingUpgraded().shouldBeTrue("HEating upgrade checkbox value is not matched");
				
		expandElectricSection();
		isWiringUpgraded().shouldBeTrue("Wiring upgrade checkbox value is not matched");
		isWiringUpgradeYearEqualsTo().shouldBeEqual("Wiring Upgrade year value is not matched");
		
		return new Validation(true);
	}

	public Validation areConstructionPageDetailsNotSaved() {
		logger.info( "Validating the data saved for the Construction page");
		isBuildYearEqualsTo().shouldNotBeEqual("Build year value is matched");
		areBuildlingStoriesEqualsTo().shouldNotBeEqual("No of buildings value is matched");
		isConstructionTypeEqualsTo().shouldNotBeEqual("Construction value is matched");
		isFoundationTypeEqualsTo().shouldNotBeEqual("Foundation value is matched");

		expandRoofSection();
		//TODO  roof type valiodation
		//isRoofTypeEqualsTo().shouldNotBeEqual("Roof type value is matched" );
		isRoofUpgraded().shouldBeFalse("Roof upgrade check box value is matched");

		expandPlumbingSection();
		isPlumbingTypeEqualsTo().shouldNotBeEqual("Plumbing value is matched");
		isPlumbingUpgraded().shouldBeFalse("Plumbing checkbox value is matched");

		expandHeatingSection();
		isHeatingTypeEqualsTo().shouldNotBeEqual("Heating type value is matched");
		isHeatingUpgraded().shouldBeFalse("HEating upgrade checkbox value is matched");

		expandElectricSection();
		isWiringTypeEqualsTo().shouldNotBeEqual("Wiring type value is matched");
		isElectricalSystemEqualsTo().shouldNotBeEqual("Electrical system value is matched");
		isWiringUpgraded().shouldBeFalse("Wiring upgrade checkbox value is matched");

		return new Validation(true);
	}

	public Validation isConstructionPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(BUILD_YEAR_TXT_CSS);
		return new Validation(seleniumCommands.isElementPresent(BUILD_YEAR_TXT_CSS));
	}

	public Validation areConstructionPageDetailsMatchingBackEnd(String jsonData) throws Exception {
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getConstructionDataFromBackEnd(jsonData));
	}
}
