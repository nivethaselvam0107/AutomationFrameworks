package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class AlertHandler {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();

	@FindBy(css = "[class*='gw-fade']")
	WebElement POP_UP_CSS;

	private final By POP_UP_CLOSE_BTN = By.cssSelector("[class*='gw-fade'] [ng-click*='$close']");

	String DESC =  "//div[@class='gw-message']";
	
	@FindBy(css = "[class*='gw-fade'] p[class='ng-binding']")
	WebElement CANCEL_SUB_MESSAGE ;
	
	@FindBy(css = "a[href='#/home']")
	WebElement HEADER_IMAGE_CSS;
	
	String POP_UP_ERROR_MESSAGE =  "//*[contains(@class,'gw-fade')]//div[@class='gw-message']/p";

	By POP_UP =  By.xpath("//*[contains(@class,'gw-fade')]//*[@ng-class='iconClass()']");

	String POPUP_CLOSE_BTN_CSS = "[class*='gw-fade'] [ng-click*='close']";

	String POPUP_HEADER = "[class*='gw-fade'] div[class*='heading']";
	
	@FindBy(css = "[name='noteform']")
    WebElement NOTES_FORM_CSS;
	
	@FindBy(css = "[model='note.subject'] input")
    WebElement NOTES_SUB;
	
	@FindBy(css = "[model='note.body'] input")
    WebElement NOTES_BODY;
	
	@FindBy(css = "[ng-click='saveNote(note)']")
    WebElement SAVE_NOTES;
	
	public AlertHandler() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public AlertHandler(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}
	
	 public ViewModelForm getForm() {
		 return new ViewModelForm(NOTES_FORM_CSS);
	 }
	
	public void closeAlertIfPresent() {
		if (seleniumCommands.isElementPresent(POP_UP_CLOSE_BTN)) {
			this.closeSubmissionAlert();
		}
	}

	 public ContactUsPage closeAlert() {
		seleniumCommands.logInfo("Closing alert");
		seleniumCommands.waitForElementToBeClickable(POP_UP_CLOSE_BTN);
		seleniumCommands.clickbyJS(POP_UP_CLOSE_BTN);
		seleniumCommands.waitForElementToDisappear(POP_UP_CLOSE_BTN, 2);

		return new ContactUsPage();
	}

	/* please use closeSubmissionAlert instead */
	@Deprecated
	public ClaimListPage closeClaimSubmissionAlert() {
		seleniumCommands.logInfo("Closing alert");
		seleniumCommands.waitForElementToBeClickable(POP_UP_CLOSE_BTN);
		seleniumCommands.clickbyJS(POP_UP_CLOSE_BTN);
		seleniumCommands.waitForElementToDisappear(POP_UP_CLOSE_BTN, 2);

		return new ClaimListPage();
	}

	public void closeSubmissionAlert() {
		seleniumCommands.logInfo("Closing alert");
		seleniumCommands.waitForElementToBeClickable(POP_UP_CLOSE_BTN);
		seleniumCommands.clickbyJS(POP_UP_CLOSE_BTN);
		seleniumCommands.waitForElementToDisappear(POP_UP_CLOSE_BTN, 2);
	}
	
	public ZipCodePage closeAlertOnly() {
		seleniumCommands.logInfo("Closing alert only");
		seleniumCommands.waitForElementToBeClickable(POP_UP_CLOSE_BTN);
		seleniumCommands.clickbyJS(POP_UP_CLOSE_BTN);
		seleniumCommands.waitForElementToDisappear(POP_UP_CLOSE_BTN, 2);
		return new ZipCodePage();
	}
	
	public AlertHandler goToLandingPage() {
		seleniumCommands.logInfo("Go To Zipcode Page");
		seleniumCommands.clickbyJS(HEADER_IMAGE_CSS);
		seleniumCommands.waitForElementToBeClickable(POP_UP_CLOSE_BTN);
		return this;
	}
	
	public AlertHandler withNotesSubject() {
		seleniumCommands.logInfo("Setting notes subject Text");
		 seleniumCommands.type(NOTES_SUB, data.get("NoteSubject"));
		 return this;
	}
	
	public AlertHandler withNotesBody() {
		seleniumCommands.logInfo("Setting notes body Text");
		seleniumCommands.type(NOTES_BODY, data.get("NoteBody"));
		 return this;
	}
	
	public NewClaimSummaryPage withNotesContent() {
		seleniumCommands.waitForElementToBeVisible(NOTES_FORM_CSS);
		this.withNotesBody().withNotesSubject();
		seleniumCommands.click(SAVE_NOTES);
		 return new NewClaimSummaryPage();
	}

	// Get Methods

	public String getAlertHeader() {
		seleniumCommands.logInfo("Getting Header Text");
		return seleniumCommands.findElement(By.cssSelector(POPUP_HEADER)).getText();
	}
	
	public String getAlertText() {
		seleniumCommands.logInfo("Getting Alert Text");
		return POP_UP_CSS.findElement(By.xpath(DESC)).getText();
	}

	// Validation method
	
	public Validation isAlertDisplayed() {
		seleniumCommands.logInfo("Checking alert's presence");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeVisible(POP_UP);
		new Validation(seleniumCommands.isElementPresent(POP_UP)).shouldBeEqual("Alert is not present");
		return new Validation(true);
	}
	
	public Validation isCanNotProcessAlertDisplayed() {
		seleniumCommands.logInfo("Checking Can not proceed alert's presence");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeVisible(POP_UP);
		new Validation(getAlertHeader(), DataConstant.CAN_NOT_PROCEED_HEADER).shouldBeEqual("Can not proceed Alert's Header is not matched");
		return new Validation(true);
	}
	
	public Validation isCanNotPurchaseQuoteAlertDisplayed() {
		seleniumCommands.logInfo("Checking Can not purchase quote alert's presence");
		seleniumCommands.waitForElementToBeVisible(POP_UP);
		new Validation(getAlertHeader(), DataConstant.UNABLE_TO_PURCHASE_QUOTE_HEADER).shouldBeEqual("Unable to purchase quote Alert's Header is not matched");
		return new Validation(true);
	}
	
	public Validation isCancelSubmissionPopUpDisplayed() {
		seleniumCommands.logInfo("Validating If Cancel Submission Pop Up Displayed");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(POPUP_CLOSE_BTN_CSS));
		return new Validation(seleniumCommands.findElement(By.cssSelector(POPUP_HEADER)).getText(), DataConstant.CANCEL_SUBMISSION_HEADER);
	}

	public Validation isNoBuildingPopUpDisplayed() {
		seleniumCommands.logInfo("Validating If No Building Pop Up Displayed");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(POPUP_CLOSE_BTN_CSS));
		return new Validation(seleniumCommands.findElement(By.cssSelector(POPUP_HEADER)).getText(), DataConstant.NO_BUILDING_HEADER);
	}

	public Validation isNoPaymentPlanPopUpDisplayed() {
		seleniumCommands.logInfo("Validating If No Payment plan selected Pop Up is displayed");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(POPUP_CLOSE_BTN_CSS));
		return new Validation(seleniumCommands.findElement(By.cssSelector(POPUP_HEADER)).getText(), DataConstant.NO_PAYMENT_PLAN_HEADER);
	}

	public Validation validateCanNotProcessPopUpContent() {
		seleniumCommands.logInfo("Validating Can Not Proces pop up Content");
		return new Validation(getAlertText() , DataConstant.CAN_NOT_PROCEED_DESC);
	}
	
	public Validation validateCanNotPurchaseQuotePopUpContent() {
		seleniumCommands.logInfo("Validating pop up Content");
		return new Validation(getAlertText() , DataConstant.CAN_NOT_BIND_DESC);
	}
	
	public Validation validateProcessingPaymentPopUpContent() {
		seleniumCommands.logInfo("Validating Processing payment pop up Content");
		seleniumCommands.waitForElementToBeVisible(POP_UP_CSS);
		return new Validation(seleniumCommands.findElement(By.cssSelector(POPUP_HEADER)).getText() , DataConstant.PROCESSING_PAYMENT_HEADER);
	}
	
	public Validation validateEnrollmentDataErrorPopUpContent() {
		seleniumCommands.logInfo("Validating Enrollment Data PopUp Content");
		String alertText = getAlertText();
		closeAlert();
		return new Validation( alertText, DataConstant.DATA_ENTRY_ENROLLMENT_ERROR);
	}
	
	public Validation validateCancelQuoteSubmissionPopUpContent() {
		seleniumCommands.logInfo("Validating Cancel Quote Submission pop up Content");
		String alertContent = seleniumCommands.getTextAtLocator(CANCEL_SUB_MESSAGE);
		System.out.println(alertContent);
		return new Validation(alertContent , DataConstant.CANCEL_QUOTE_SUBMISSION_DESC);
	}

	public Validation isZipCodeRetrivalErrorPopUpDisplayed() {
		seleniumCommands.logInfo("Validating If Quote Retrival Pop Up Displayed");
		seleniumCommands.waitForElementToBeVisible(POP_UP);
		return new Validation(getAlertHeader(), DataConstant.QUOTE_RETRIVAL_ERROR_HEADER);
	}

	public Validation isFailedToUploadPopUpDisplayed() {
		seleniumCommands.logInfo("Validating if failed to upload document pop up is displayed");
		seleniumCommands.waitForElementToBeVisible(POP_UP);
		return new Validation(getAlertHeader(), DataConstant.UPLOAD_FAILED_HEADER_MSG);
	}

	public Validation isFailedToUploadPopUpContentEqualsTo() {
		seleniumCommands.logInfo("Validating failed to upload pop up Content");
		return new Validation(ThreadLocalObject.getDriver().findElement(By.xpath(POP_UP_ERROR_MESSAGE)).getText(), DataConstant.UPLOAD_FAILED_ERR_DESC);
	}
	
	public Validation isZipCodeRetrivalErrorPopUpContentEqualsTo() {
		seleniumCommands.logInfo("Validating Cancel Submission pop up Content");
		return new Validation(ThreadLocalObject.getDriver().findElement(By.xpath(POP_UP_ERROR_MESSAGE)).getText(), DataConstant.QUOTE_RETRIVAL_ERROR_DESC);
	}

	public Validation isNoBuildingAddedErrorEqualsTo() {
		seleniumCommands.logInfo("Validating All locations should have a building pop up Content");
		return new Validation(ThreadLocalObject.getDriver().findElement(By.xpath(POP_UP_ERROR_MESSAGE)).getText(), DataConstant.NO_BUILDING_ERROR_MSG);
	}

	public Validation isNoPaymentPlanSelectedErrorEqualsTo() {
		seleniumCommands.logInfo("Validating no payment plan selected pop up Content");
		return new Validation(ThreadLocalObject.getDriver().findElement(By.xpath(POP_UP_ERROR_MESSAGE)).getText(), DataConstant.NO_PAYMENT_PLAN_ERROR_MSG);
	}

}
