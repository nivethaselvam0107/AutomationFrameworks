package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.AddressSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.DriverSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.QuickQuoteSection;
import com.guidewire.portals.qnb.pages.QuickQuoteComponent.VehicleSection;

/**
 * @author jkrawczyk-koca
 */
public class QuickQuotePage {

    public HashMap<String, String> data = ThreadLocalObject.getData();
    SeleniumCommands seleniumCommands = new SeleniumCommands();


    public VehicleSection getVehicleSection() {
        seleniumCommands.logInfo("Go to Vehicle Section");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new VehicleSection();
    }

    public DriverSection getDriverSection() {
        seleniumCommands.logInfo("Go to Vehicle Section");
           return new DriverSection();
    }

    public AddressSection getAddressSection() {
        seleniumCommands.logInfo("Go to Address Section");
        return new AddressSection();
    }

    public QuickQuoteSection getQuickQuoteSection() {
        seleniumCommands.logInfo("Go to Quick Quote Section");
        return new QuickQuoteSection();

    }
    
    public QuickQuotePage generateQuickQuote()
    {
        seleniumCommands.logInfo("Generate Quick Quote");
        this.getVehicleSection().setVIN().clickNext();
        this.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        this.getDriverSection().setDriverDetails().clickNext();
        QuickQuoteSection quickQuoteSection = this.getQuickQuoteSection();
        quickQuoteSection.setEmail().clickNext();
        return this;
    }

    public QuickQuotePage generateQuickQuoteWithoutVIN()
    {
        seleniumCommands.logInfo("Generate Quick Quote without VIN");
        this.getVehicleSection().withMake().withModel().withYear().clickNext();
        this.getAddressSection().setAddress().searchAddress1().selectFirstAddress().clickNext();
        this.getDriverSection().setDriverDetails().clickNext();
        QuickQuoteSection quickQuoteSection = this.getQuickQuoteSection();
        quickQuoteSection.setEmail().clickNext();
        return this;
    }

}
