package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.quote.data.HOPQuoteData;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.ParseQuoteData;

public class HOPCoverageDetailsPage extends CommonPage {
	HashMap<String, String> data = new HashMap<>();
	
	HashMap<String, String> policydata = new HashMap<>();
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	@FindBy(css = "[class='gw-coverage-header'] span:nth-of-type(2)")
	 WebElement ANNUAL_QUOTE_VALUE_BEFORE_TAX_CSS;
	
	@FindBy(css = "[value='fullTerm'] + label span")
	 WebElement MONTHLY_QUOTE_VALUE_AFTER_TAX_CSS;
	
	@FindBy(css = "[value='monthly'] + label span")
	 WebElement ANNUAL_QUOTE_VALUE_AFTER_TAX_CSS;
	
	//@FindBy(css = "[ng-repeat*='term in coverage.terms'] div[class*='Amount'], [ng-repeat*='term in coverage.terms']")
	@FindBy(css = "[ng-repeat*='term in coverage.terms']")
	 List<WebElement> COV_ELEMENT_LIST;
	
	@FindBy(css = "[class*='Checkbox'] input")
	 List<WebElement> COV_CKBOX_ELEMENT_LIST;
	
	@FindBy(xpath = "//*[contains(@ng-repeat,'coverage in')]//div[contains(@class,'name')]")
	 List<WebElement> COV_LABEL_TXT;
	
	By QUOTE_BTN =  By.cssSelector("[ng-click='buyQuote()']");
	
	By GLASS_COV_LABEL_CSS = By.cssSelector("[ng-repeat*='coverage in _coverages track by coverage.id']");
	
	public HOPCoverageDetailsPage()
	{
		seleniumCommands.pageWebElementLoader(this);
	}
	
	public String getAnnualBeforeTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(ANNUAL_QUOTE_VALUE_BEFORE_TAX_CSS);
	}
	
	public String getAnnualAfterTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(ANNUAL_QUOTE_VALUE_AFTER_TAX_CSS);
	}
	
	public String getMonthlyAfterTaxQuoteValue() {
		return seleniumCommands.getTextAtLocator(MONTHLY_QUOTE_VALUE_AFTER_TAX_CSS);
	}
	
	private String getCoverageValue( WebElement covElement) {
			return covElement .findElement(By.xpath(".//div[contains(@class,'termAmount')]")).getText();
	}
	
	private String getSelectedCoverage(WebElement element)
	{
		try{
			return seleniumCommands.getSelectedOptionFromDropDown(element.findElement(By.xpath(".//select")));
		}
		catch(NoSuchElementException e)
		{
			return null;
		}
	}
	
	private String getSelectedCheckBox(int index)
	{
		if(seleniumCommands.getLeftRadioButtonValueByRowIndex(index).isSelected())
		{
			return "Yes";
		}
		else
		{
			return "No";
		}
	}
	
	private String getCoverageTextBoxValue(WebElement element)
	{
		try{
			return seleniumCommands.getValueAttributeFromLocator(element.findElement(By.xpath(".//input")));
		}
		catch(NoSuchElementException e)
		{
			return null;
		}
	}
	
	private boolean getRadioButtonDropDataFromUI(String covTitle, int index)
	{
		seleniumCommands.logInfo("Getting value for coverage  -> "+ covTitle);
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return false;
		}
		return covTitle.equals(seleniumCommands.getTextAtLocator(COV_LABEL_TXT.get(index)));
	}
	
	private String getCoverageDropDataFromUI(String covTitle, WebElement element)
	{
		seleniumCommands.logInfo("Getting value for coverage  -> "+ covTitle);
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCoverage(element);
		}
			return getCoverageValue(element);
	}
	
	private boolean getCoverageCheckBoxDataFromUI(String covTitle, int index)
	{
		seleniumCommands.logInfo("Getting value for coverage  -> "+ covTitle);
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return covTitle.equals(seleniumCommands.getTextAtLocator(COV_CKBOX_ELEMENT_LIST.get(index).findElement(By.xpath("./ancestor::div[@ng-repeat]//span"))));
		}
		return covTitle.equals(seleniumCommands.getTextAtLocator(COV_LABEL_TXT.get(index)));
	}
	
	private String getCoverageTextDataFromUI(String covTitle, WebElement element)
	{
		seleniumCommands.logInfo("Getting value for coverage  -> "+ covTitle);
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getCoverageTextBoxValue(element);
		}
			return getCoverageValue(element);
	}
	
	public String getLOU_LIMIT_PERCENT() {
			return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(0));
	}
	
	public String getLOU_LIMIT_VALUE() {
			return getCoverageTextDataFromUI("Limit", COV_ELEMENT_LIST.get(1));
	}
	
	public String getLOU_LOSS_RENTAL_INCOME_CHECK() {
		if(seleniumCommands.isElementPresent(QUOTE_BTN))
		{
			return getSelectedCheckBox(0);
		}
			return getCoverageValue(COV_ELEMENT_LIST.get(2));
	}
	
	public String getLOU_PROBIHITED_USE_CIVIL_AUTH() {
			return getCoverageDropDataFromUI("Prohibited Use - Civil Authority", COV_ELEMENT_LIST.get(3));
	}
	
	public String getSEC1_DEDUCT_ALL_PTHER_PERIL() {
			return getCoverageDropDataFromUI("All Perils", COV_ELEMENT_LIST.get(4));
	}
	
	public String getPER_PROP_LIMIT_PERCENT() {
			return getCoverageDropDataFromUI("Limit Percentage", COV_ELEMENT_LIST.get(5));
	}
	
	public String getPER_PROP_LIMIT_VALUE() {
			return getCoverageTextDataFromUI("Limit Value", COV_ELEMENT_LIST.get(6));
	}
	
	public String getPER_PROP_AT_OTHER_RESIDENCE() {
			return getCoverageDropDataFromUI("Property at Other Residence", COV_ELEMENT_LIST.get(7));
	}
	
	public String getPER_PROP_SELF_STORAGE() {
			return getCoverageDropDataFromUI("Self Storage Units", COV_ELEMENT_LIST.get(8));
	}
	
	public String getPER_PROP_CAUSE_OF_LOSS() {
			return getCoverageDropDataFromUI("Cause of Loss ", COV_ELEMENT_LIST.get(9));
	}
	
	public String getPER_PROP_VALUATION_METHOD() {
			return getCoverageDropDataFromUI("Valuation Method", COV_ELEMENT_LIST.get(10));
	}
	
	public String getDWEL_LIMIT_VALUE() {
			return getCoverageTextDataFromUI("Limit", COV_ELEMENT_LIST.get(11));
	}
	
	public String getDWEL_COINSURANCE_PERCENT() {
			return getCoverageDropDataFromUI("Coinsurance", COV_ELEMENT_LIST.get(12));
	}
	
	public String getDWEL_VALUATION_METHOD() {
			return getCoverageDropDataFromUI("Valuation Method", COV_ELEMENT_LIST.get(13));
	}
	
	public String getDWEL_CAUSE_OF_LOSS() {
			return getCoverageDropDataFromUI("Cause of Loss", COV_ELEMENT_LIST.get(14));
	}
	
	public String getOTR_STRUC_LIMIT_PERCENT() {
		return getCoverageDropDataFromUI("Limit Percentage", COV_ELEMENT_LIST.get(15));
	}
	
	public String getOTR_STRUC_LIMIT_VALUE() {
			return getCoverageTextDataFromUI("Limit Value", COV_ELEMENT_LIST.get(16));
	}
	
	
	public String getOTR_STRUC_VALUATION_METHOD() {
			return getCoverageDropDataFromUI("Valuation Method", COV_ELEMENT_LIST.get(17));
	}
	
	public String getOTR_STRUC_COINSURANCE_PERCENT() {
			return getCoverageDropDataFromUI("Coinsurance", COV_ELEMENT_LIST.get(18));
	}
	
	public String getOTR_STRUC_CAUSE_OF_LOSS() {
			return getCoverageDropDataFromUI("Cause of Loss", COV_ELEMENT_LIST.get(19));
	}
	
	public String getPER_LIABILITY_LIMIT_VALUE() {
			return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(20));
	}
	
	public String getPER_LIABILITY_PER_INJURY() {
			return getCoverageDropDataFromUI("Personal Injury", COV_ELEMENT_LIST.get(21));
	}
	
	public String getMEDICAL_LIMIT_VALUE() {
			return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(22));
	}
	
	//Aditional Coverages
	
	public String getREWARD_RECOVERED_PROP_LIMIT_PERCENT() {
		return getCoverageDropDataFromUI("Limit for Arson or Recovered Property", COV_ELEMENT_LIST.get(23));
	}
	
	public String getREWARD_THEFT_CONVECTION_LIMIT_PERCENT() {
		return getCoverageDropDataFromUI("Limit for Theft Conviction ", COV_ELEMENT_LIST.get(24));
	}
	
	public String getDAMAGE_OTHERS_PROPERTY_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(25));
	}
	
	public String getLOSS_ASSESSMENT_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(26));
	}
	
	public String getFORGERY_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(27));
	}
	
	public String getTHEFT_PROTECTION_EXPENSE_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Expense Limit", COV_ELEMENT_LIST.get(28));
	}
	
	public String getTHEFT_PROTECTION_DEDUCT_VALUE() {
		return getCoverageDropDataFromUI("Deductible", COV_ELEMENT_LIST.get(29));
	}
	
	public boolean getFIRST_AID() {
		return getCoverageCheckBoxDataFromUI("First Aid", 12);
	}
	
	public boolean getREASONABLE_REPAIRS() {
		return getCoverageCheckBoxDataFromUI("Reasonable Repairs", 13);
	}
	
	public String getVOLCANIC_ACTION_DEDUCT_VALUE() {
		return getCoverageDropDataFromUI("Deductible", COV_ELEMENT_LIST.get(30));
	}
	
	public String getCONSTRUCTION_PERMIT_INCREASE_COST_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(31));
	}

	public String getREFRIGIRATED_CONTENTS_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(32));
	}
	
	public String getREFRIGIRATED_CONTENTS_LIMIT_VALUE_DEDUCT_VALUE() {
		return getCoverageDropDataFromUI("Deductible", COV_ELEMENT_LIST.get(33));
	}
	
	public String getFUNGUS_MOLD_REMED_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(34));
	}
		
	public boolean getCOLAPSE() {
		return getCoverageCheckBoxDataFromUI("Collapse", 18);
	}
	
	public String getDWEL_COV_EXTENSION_DEDUCT_VALUE() {
		return getCoverageDropDataFromUI("Deductible", COV_ELEMENT_LIST.get(35));
	}
	
	public String getTREE_LAWN_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(36));
	}
	
	public String getEARTHQUAKE_FOOD_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(37));
	}
	
	public String getMORTAGEE_CLOSE_COST_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(38));
	}
	
	public boolean getEMERGENCY_REMOVAL_PROP() {
		return getCoverageCheckBoxDataFromUI("Emergency Removal of Property", 23);
	}
	
	public String getDEBRIS_REMOVAL_TREE_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(39));
	}
	
	public String getEMERGENCY_LIVING_EXPENSE_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(40));
	}
	
	public boolean getDEBRIS_REMOVAL() {
		return getCoverageCheckBoxDataFromUI("Debris Removal", 26);
	}
	
	public String getLANDLORD_FURNISHING_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(41));
	}
	
	public String getLAND_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(42));
	}
	
	public String getGRAVE_MAKER_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(43));
	}
	
	public String getFIRE_DEPT_SERVICE_CHARGE_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(44));
	}
	
	public boolean getLOCK_REPLACEMENT() {
		return getCoverageCheckBoxDataFromUI("Lock Replacement", 31);
	}
	
	public String getPROP_REMOVED_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(45));
	}
	
	public String getINFLATION_PROTECTION_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(46));
	}
	
	public String getORDINANCE_LAW_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(47));
	}
	
	public String getFIRE_EXT_RECHARGE_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(48));
	}
	
	public String getDATA_RECORD_LIMIT_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(49));
	}
	
	public String getDATA_RECORD_PERSONAL_ONLY_CHECK() {
		return getCoverageDropDataFromUI("Personal Only", COV_ELEMENT_LIST.get(50));
	}
	
	public boolean getGLASS() {
		return getCoverageCheckBoxDataFromUI("Glass", 37);
	}
	
	//Get Permium data
	
	public String getANNUAL_AMOUNT_AFTER_TAX_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(49));
	}
	
	public String getANNUAL_BASE_PREMIUM_VALUE() {
		return getCoverageDropDataFromUI("Limit", COV_ELEMENT_LIST.get(50));
	}
	
	public String getMONTHLY_AMOUNT_AFTER_TAX_VALUE() {
		return getCoverageTextDataFromUI("Glass", COV_ELEMENT_LIST.get(37));
	}
	
	public HashMap<String, String> getCoverageDataFromUI() {
		DataFormatUtil.putData(policydata, HOPQuoteData.LOU_LIMIT_PERCENT.toString(), getLOU_LIMIT_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.LOU_LIMIT_VALUE.toString(), getLOU_LIMIT_VALUE());
		//TODO for correct locator DataFormatUtil.putData(policydata, HOPQuoteData.LOU_LOSS_RENTAL_INCOME_CHECK.toString(), getLOU_LOSS_RENTAL_INCOME_CHECK());
		DataFormatUtil.putData(policydata, HOPQuoteData.LOU_PROBIHITED_USE_CIVIL_AUTH.toString(), getLOU_PROBIHITED_USE_CIVIL_AUTH());
		DataFormatUtil.putData(policydata, HOPQuoteData.SEC1_DEDUCT_ALL_OTHER_PERIL.toString(), getSEC1_DEDUCT_ALL_PTHER_PERIL());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_LIMIT_PERCENT.toString(), getPER_PROP_LIMIT_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_LIMIT_VALUE.toString(), getPER_PROP_LIMIT_VALUE());
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_AT_OTHER_RESIDENCE.toString(), getPER_PROP_AT_OTHER_RESIDENCE());
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_SELF_STORAGE.toString(), getPER_PROP_SELF_STORAGE());
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_CAUSE_OF_LOSS.toString(), getPER_PROP_CAUSE_OF_LOSS());
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_PROP_VALUATION_METHOD.toString(), getPER_PROP_VALUATION_METHOD());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DWEL_LIMIT_VALUE.toString(), getDWEL_LIMIT_VALUE());
		DataFormatUtil.putData(policydata, HOPQuoteData.DWEL_COINSURANCE_PERCENT.toString(), getDWEL_COINSURANCE_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.DWEL_VALUATION_METHOD.toString(), getDWEL_VALUATION_METHOD());
		DataFormatUtil.putData(policydata, HOPQuoteData.DWEL_CAUSE_OF_LOSS.toString(), getDWEL_CAUSE_OF_LOSS());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.OTR_STRUC_LIMIT_VALUE.toString(), getOTR_STRUC_LIMIT_VALUE());
		DataFormatUtil.putData(policydata, HOPQuoteData.OTR_STRUC_LIMIT_PERCENT.toString(), getOTR_STRUC_LIMIT_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.OTR_STRUC_VALUATION_METHOD.toString(), getOTR_STRUC_VALUATION_METHOD());
		DataFormatUtil.putData(policydata, HOPQuoteData.OTR_STRUC_COINSURANCE_PERCENT.toString(), getOTR_STRUC_COINSURANCE_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.OTR_STRUC_CAUSE_OF_LOSS.toString(), getOTR_STRUC_CAUSE_OF_LOSS());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.PER_LIABILITY_LIMIT_VALUE.toString(), getPER_LIABILITY_LIMIT_VALUE());
		//TODO for correct locator DataFormatUtil.putData(policydata, HOPQuoteData.PER_LIABILITY_PER_INJURY.toString(), getPER_LIABILITY_PER_INJURY());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.MEDICAL_LIMIT_VALUE.toString(), getMEDICAL_LIMIT_VALUE());
		
		//Additional Coverages
		DataFormatUtil.putData(policydata, HOPQuoteData.REWARD_RECOVERED_PROP_LIMIT_PERCENT.toString(), getREWARD_RECOVERED_PROP_LIMIT_PERCENT());
		DataFormatUtil.putData(policydata, HOPQuoteData.REWARD_THEFT_CONVECTION_LIMIT_PERCENT.toString(), getREWARD_THEFT_CONVECTION_LIMIT_PERCENT());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DAMAGE_OTHERS_PROPERTY_LIMIT_VALUE.toString(), getDAMAGE_OTHERS_PROPERTY_LIMIT_VALUE());

		DataFormatUtil.putData(policydata, HOPQuoteData.LOSS_ASSESSMENT_LIMIT_VALUE.toString(), getLOSS_ASSESSMENT_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.FORGERY_LIMIT_VALUE.toString(), getFORGERY_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.THEFT_PROTECTION_EXPENSE_LIMIT_VALUE.toString(), getTHEFT_PROTECTION_EXPENSE_LIMIT_VALUE());
		DataFormatUtil.putData(policydata, HOPQuoteData.THEFT_PROTECTION_DEDUCT_VALUE.toString(), getTHEFT_PROTECTION_DEDUCT_VALUE());
		seleniumCommands.logInfo(policydata.toString());
		DataFormatUtil.putData(policydata, HOPQuoteData.FIRST_AID.toString(), getFIRST_AID()+"");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.REASONABLE_REPAIRS.toString(), getREASONABLE_REPAIRS()+"");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.VOLCANIC_ACTION_DEDUCT_VALUE.toString(), getVOLCANIC_ACTION_DEDUCT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.CONSTRUCTION_PERMIT_INCREASE_COST_LIMIT_VALUE.toString(), getCONSTRUCTION_PERMIT_INCREASE_COST_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.REFRIGIRATED_CONTENTS_LIMIT_VALUE.toString(), getREFRIGIRATED_CONTENTS_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.REFRIGIRATED_CONTENTS_LIMIT_VALUE_DEDUCT_VALUE.toString(), getREFRIGIRATED_CONTENTS_LIMIT_VALUE_DEDUCT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.FUNGUS_MOLD_REMED_LIMIT_VALUE.toString(), getFUNGUS_MOLD_REMED_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.COLAPSE.toString(), getCOLAPSE()+"");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DWEL_COV_EXTENSION_DEDUCT_VALUE.toString(), getDWEL_COV_EXTENSION_DEDUCT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.TREE_LAWN_LIMIT_VALUE.toString(), getTREE_LAWN_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.EARTHQUAKE_FOOD_LIMIT_VALUE.toString(), getEARTHQUAKE_FOOD_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.MORTAGEE_CLOSE_COST_LIMIT_VALUE.toString(), getMORTAGEE_CLOSE_COST_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.EMERGENCY_REMOVAL_PROP.toString(), getEMERGENCY_REMOVAL_PROP()+"");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DEBRIS_REMOVAL_TREE_LIMIT_VALUE.toString(), getDEBRIS_REMOVAL_TREE_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.EMERGENCY_LIVING_EXPENSE_LIMIT_VALUE.toString(), getEMERGENCY_LIVING_EXPENSE_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DEBRIS_REMOVAL.toString(), getDEBRIS_REMOVAL()+"");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.LANDLORD_FURNISHING_LIMIT_VALUE.toString(), getLANDLORD_FURNISHING_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.LAND_LIMIT_VALUE.toString(), getLAND_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.GRAVE_MAKER_LIMIT_VALUE.toString(), getGRAVE_MAKER_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.FIRE_DEPT_SERVICE_CHARGE_LIMIT_VALUE.toString(), getFIRE_DEPT_SERVICE_CHARGE_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.LOCK_REPLACEMENT.toString(), getLOCK_REPLACEMENT() + "");
		
		DataFormatUtil.putData(policydata, HOPQuoteData.PROP_REMOVED_LIMIT_VALUE.toString(), getPROP_REMOVED_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.INFLATION_PROTECTION_LIMIT_VALUE.toString(), getINFLATION_PROTECTION_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.ORDINANCE_LAW_LIMIT_VALUE.toString(), getORDINANCE_LAW_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.FIRE_EXT_RECHARGE_LIMIT_VALUE.toString(), getFIRE_EXT_RECHARGE_LIMIT_VALUE());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.DATA_RECORD_LIMIT_VALUE.toString(), getDATA_RECORD_LIMIT_VALUE());
		
		//TODO for correct locator DataFormatUtil.putData(policydata, HOPQuoteData.DATA_RECORD_PERSONAL_ONLY_CHECK.toString(), getDATA_RECORD_PERSONAL_ONLY_CHECK());
		
		DataFormatUtil.putData(policydata, HOPQuoteData.GLASS.toString(), getGLASS() + "");
		
		return policydata;
	}

	// Validation
	
	public Validation areHOPQuoteBaseCoverageDataMatchingWithBackEnd(String jsonData) throws Exception
	{
		return MapCompare.compareMap(getCoverageDataFromUI(), ParseQuoteData.getHOPBaseCoverageDataFromBackEnd(jsonData));
	}
}
