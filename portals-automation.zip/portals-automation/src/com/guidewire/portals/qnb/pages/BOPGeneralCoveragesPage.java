package com.guidewire.portals.qnb.pages;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import java.util.HashMap;

public class BOPGeneralCoveragesPage extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(xpath = "//div[@ng-if='coverage.selected']//select")
    WebElement LIAB_LIMITS_XPATH;

    @FindBy(css = ".gw-schedule-table [on-click='createNew()']")
    WebElement ADD_CONTRACTOR_TOOLS_BTN_CSS;

    @FindBy(xpath = "(((//table)[2]//tr)[3]//input)[1]")
    WebElement ADD_SI_SERIAL_NO_INPUT_CSS;

    @FindBy(xpath = "(((//table)[2]//tr)[3]//input)[2]")
    WebElement ADD_SI_DESC_INPUT_CSS;

    @FindBy(xpath = "(//*[@ng-if='newItem']/td)[3]//div[@ng-if]")
    WebElement ADD_SI_DESC_INPUT_ERR_CSS;

    @FindBy(xpath = "(((//table)[2]//tr)[3]//input)[3]")
    WebElement ADD_SI_INSURED_VALUE_INPUT_CSS;

    @FindBy(xpath = "(//*[@ng-if='newItem']/td)[4]//div[@ng-if]")
    WebElement ADD_SI_INSURED_VALUE_INPUT_ERR_CSS;

    @FindBy(xpath = "(((//table)[2]//tr)[3]//td)[4]//div[@ng-if]")
    WebElement ADD_SI_INSURED_VALUE_VIEW_XPATH;

    @FindBy(xpath = "(//*[@ng-if='newItem']/td)[5]//button[@on-click='resetAdd()']")
    WebElement CANCEL_SI_BTN_CSS;

    By ADD_BTN = By.cssSelector("td button[gw-test-policycommon-common-table-submit-new-valuable-button]");

    @FindBy(xpath = "((//table)[2]//tr)[3]//button[@on-click='doneEditing(scheduledItem)']")
    WebElement SAVE_SI_BTN_CSS;

    @FindBy(xpath = "(//button[@on-click='remove(scheduledItem)'])[2]")
    WebElement CONFIRM_DELETE_SI_BTN_CSS;

    @FindBy(css = "[gw-test-policycommon-editablecoverages-editablecoverages='Employee Dishonesty Limit'] select")
    WebElement EMP_DISHONESTY_LIMIT_SELECT_CSS;

    @FindBy(css = "[gw-test-policycommon-editablecoverages-editablecoverages='Number of Covered Employees'] input")
    WebElement NO_COVERED_EMP_INPUT_CSS;

    @FindBy(css = "[gw-test-policycommon-editablecoverages-editablecoverages='Number of Covered Locations'] input")
    WebElement NO_COVERED_LOC_INPUT_CSS;

    private static final String REMOVE_SI_BTN_XPATH = "(((//table)[2]//tr)[3]//div[@ng-click])[1]/i";

    private static final String EDIT_SI_BTN_XPATH = "(((//table)[2]//tr)[3]//div[@ng-click])[2]/i";

    private static final String GEN_CVG_HEADER_XPATH = "//gw-bop-general-coverages";

    @FindBy(xpath = "//select[@id='BOPLiabPDDeductible']")
    WebElement LIAB_PD_DEDUCATIBLE;

    @FindBy(xpath = "//div[@id='BOPPersAdvertInj']/div/input")
    WebElement PERS_ADVERT_INJURY_CHK_BOX;

    @FindBy(xpath = "//select[@id='SBSpecialPacks']")
    WebElement SPL_COV_PACKAGES_SELECT;

    @FindBy(xpath = "//div[@id='BOPNonOwnedAutoCov']/div/label")
    WebElement OTHER_INCLUDED_NON_OWNED_AUTO_LIABILITY;

    @FindBy(xpath = "//div[@id='BOPHiredAuto']/div/label")
    WebElement  OTHER_INCLUDED_HIRED_AUTO;

    @FindBy(xpath = "//select[@id='BOPOptCovDed']")
    WebElement  PROPERTY_REQUIRED_OPTIONAL_COV_DEDUCTIBLE;

    @FindBy(xpath = "//select[@id='BOPPropertyCovCauseOfLoss']")
    WebElement  PROPERTY_REQUIRED_CAUSE_OF_LOSS;

    By ADD_SI_DESC_VIEW_XPATH  = By.xpath("(((//table)[2]//tr)[3]//td)[3]//div[@ng-if]");

    public BOPGeneralCoveragesPage()    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public BOPGeneralCoveragesPage setLimitsOccurenceCoverage(){
        seleniumCommands.waitForElementToBeVisible(LIAB_LIMITS_XPATH);
        seleniumCommands.selectDropDownValueByText(LIAB_LIMITS_XPATH, data.get("LimitsOccurence"));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BOPGeneralCoveragesPage setGevCoverageForTest(){
        seleniumCommands.waitForElementToBeVisible(LIAB_PD_DEDUCATIBLE);
        seleniumCommands.selectDropDownValueByText(LIAB_PD_DEDUCATIBLE, "250");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(PERS_ADVERT_INJURY_CHK_BOX);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(SPL_COV_PACKAGES_SELECT, "Merchant's Risk Pack");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(OTHER_INCLUDED_NON_OWNED_AUTO_LIABILITY);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(OTHER_INCLUDED_HIRED_AUTO);
        seleniumCommands.selectDropDownValueByText(PROPERTY_REQUIRED_OPTIONAL_COV_DEDUCTIBLE, "2,500");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(PROPERTY_REQUIRED_CAUSE_OF_LOSS, "Named Perils");
        seleniumCommands.waitForLoaderToDisappearFromPage();

        return this;
    }

    public BOPGeneralCoveragesPage clickOnAddContractorTools(){
        seleniumCommands.waitForElementToBeVisible(ADD_CONTRACTOR_TOOLS_BTN_CSS);
        seleniumCommands.click(ADD_CONTRACTOR_TOOLS_BTN_CSS);
        return this;
    }

    public BOPGeneralCoveragesPage setDataOnContractorTools(){
        seleniumCommands.waitForElementToBeVisible(ADD_SI_DESC_INPUT_CSS);
        seleniumCommands.type(ADD_SI_DESC_INPUT_CSS, data.get("ContractorToolsDesc"));
        seleniumCommands.type(ADD_SI_INSURED_VALUE_INPUT_CSS, data.get("InsuredValue"));
        ADD_SI_DESC_INPUT_CSS.click();
        return this;
    }


    public BOPGeneralCoveragesPage setNewDataOnContractorTools(){
        seleniumCommands.waitForElementToBeVisible(ADD_SI_DESC_INPUT_CSS);
        seleniumCommands.type(ADD_SI_DESC_INPUT_CSS, data.get("ContractorToolsDescNew"));
        seleniumCommands.type(ADD_SI_INSURED_VALUE_INPUT_CSS, data.get("InsuredValueNew"));
        ADD_SI_DESC_INPUT_CSS.click();
        return this;
    }

    public BOPGeneralCoveragesPage setEmployeeDishonestyCoverageTerms(){
        seleniumCommands.waitForElementToBeVisible(EMP_DISHONESTY_LIMIT_SELECT_CSS);
        seleniumCommands.type(NO_COVERED_LOC_INPUT_CSS, data.get("NumberOfCoveredLocations"));
        seleniumCommands.type(NO_COVERED_EMP_INPUT_CSS, data.get("NumberOfCoveredEmployees"));
        seleniumCommands.click(EMP_DISHONESTY_LIMIT_SELECT_CSS);
        seleniumCommands.click(EMP_DISHONESTY_LIMIT_SELECT_CSS);
        seleniumCommands.selectDropDownValueByText(EMP_DISHONESTY_LIMIT_SELECT_CSS, data.get("EmployeeDishonestyLimit"));
        return this;
    }

    public BOPGeneralCoveragesPage clickOnAdd(){
        seleniumCommands.staticWait(2);
        seleniumCommands.waitForElementToBeClickable(ADD_BTN);
        seleniumCommands.clickbyJS(ADD_BTN);
        return this;
    }

    public BOPGeneralCoveragesPage clickOnCancelForSI(){
        seleniumCommands.waitForElementToBeVisible(CANCEL_SI_BTN_CSS);
        seleniumCommands.click(CANCEL_SI_BTN_CSS);
        return this;
    }

    public BOPGeneralCoveragesPage clickOnEdit(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(By.xpath(EDIT_SI_BTN_XPATH));
        seleniumCommands.click(By.xpath(EDIT_SI_BTN_XPATH));
        return this;
    }

    public BOPGeneralCoveragesPage clickOnSave(){
        seleniumCommands.waitForElementToBeVisible(SAVE_SI_BTN_CSS);
        seleniumCommands.click(SAVE_SI_BTN_CSS);
        return this;
    }

    public BOPGeneralCoveragesPage removeContractorToolsSI(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(By.xpath(REMOVE_SI_BTN_XPATH));
        seleniumCommands.clickbyJS(By.xpath(REMOVE_SI_BTN_XPATH));
        seleniumCommands.waitForElementToBeVisible(CONFIRM_DELETE_SI_BTN_CSS);
        seleniumCommands.click(CONFIRM_DELETE_SI_BTN_CSS);
        return this;
    }

    //Validation Methods

    public Validation isLimitsOccurenceCoverageSaved(){
        logger.info("Verifying Liability Limits coverage value");
        seleniumCommands.waitForElementToBeVisible(LIAB_LIMITS_XPATH);
        return new Validation(seleniumCommands.getSelectedOptionFromDropDown(LIAB_LIMITS_XPATH), data.get("LimitsOccurence"));
    }

    public Validation isDescriptionMarkedWithError(){
        logger.info("Validation if Description is marked with mandatory field error");
        return new Validation(seleniumCommands.getTextAtLocator(ADD_SI_DESC_INPUT_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isInsuredValueMarkedWithError(){
        logger.info("Validation if Insured Value is marked with mandatory field error");
        return new Validation(seleniumCommands.getTextAtLocator(ADD_SI_INSURED_VALUE_INPUT_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isContractorToolAdded(){
        logger.info("Validation if Contractor Tools SI was added");
        if(seleniumCommands.isElementPresent(By.xpath(REMOVE_SI_BTN_XPATH))){
            seleniumCommands.staticWait(2);
            new Validation(seleniumCommands.getTextAtLocator(ADD_SI_DESC_VIEW_XPATH), data.get("ContractorToolsDesc")).shouldBeEqual();
            new Validation(seleniumCommands.getTextAtLocator(ADD_SI_INSURED_VALUE_VIEW_XPATH).replace("$",""), data.get("InsuredValue").toString()).shouldBeEqual();
            return new Validation(true);
        }
        else {
            return new Validation(false);
        }
    }

    public Validation isContractorToolEdited(){
        logger.info("Validation if Contractor Tools SI was updated");
        seleniumCommands.staticWait(2);
        new Validation(seleniumCommands.getTextAtLocator(ADD_SI_DESC_VIEW_XPATH), data.get("ContractorToolsDescNew")).shouldBeEqual();
        new Validation(seleniumCommands.getTextAtLocator(ADD_SI_INSURED_VALUE_VIEW_XPATH).replace("$",""), data.get("InsuredValueNew").toString()).shouldBeEqual();
        return new Validation(true);
    }

    public Validation isGeneralCoveragesPageLoaded(){
        logger.info("Verifying if General Coverages page was loaded");
        return new Validation(seleniumCommands.isElementPresent(By.xpath(GEN_CVG_HEADER_XPATH)));
    }

    public void isEmployeeDishonestySelectedInBackend() {
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParseEndorsementData.getBOPLineGeneralCoveragesForPolicyChange(jsonData);
        new Validation(lineCoverages.get("Employee_Dishonesty_Selected"), "true").shouldBeEqual("Employee Dishonesty isn't selected in backend");
    }

    public void validateEmployeeDishonestyTermsInBackend() {
            String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
            HashMap<String, String> lineCoverages = ParseEndorsementData.getBOPLineGeneralCoveragesForPolicyChange(jsonData);
            new Validation(lineCoverages.get("Employee_Dishonesty_Limit"),(data.get("EmployeeDishonestyLimit").replace(",",""))).shouldBeEqual("Employee Dishonesty Limit didn't match");
            new Validation(lineCoverages.get("No_Covered_Employees"),(data.get("NumberOfCoveredEmployees"))).shouldBeEqual("Number of covered employees didn't match");
            new Validation(lineCoverages.get("No_Covered_Locations"),(data.get("NumberOfCoveredLocations"))).shouldBeEqual("Number of covered locations didn't match");
    }

    public String getPolicyChangeDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

    public void validateEmployeeDishonestyFieldsAreEmpty(){
        new Validation(seleniumCommands.isElementPresent(NO_COVERED_EMP_INPUT_CSS)).shouldBeTrue("Employee Dishonesty isn't selected");
        new Validation(seleniumCommands.getTextAtLocator(NO_COVERED_EMP_INPUT_CSS), "").shouldBeEqual("Number of Covered Employees not empty");
    }
}
