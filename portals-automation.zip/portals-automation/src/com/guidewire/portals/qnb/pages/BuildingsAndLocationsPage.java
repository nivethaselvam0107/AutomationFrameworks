package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import com.guidewire.widgetcomponents.Modal;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class BuildingsAndLocationsPage extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = ".gw-comprop-btn__icon.fa-building-o, .gw-bop-btn__icon.fa-building-o")
    WebElement ADD_BUILDING_BTN_CSS;

    @FindBy(xpath = "//div[2]/div[2]//div/div/div[2]/gw-pl-accordion//div/div" )
    WebElement ADD_BUILDING_FOR_NEW_LOCATION_BTN_CSS;

    @FindBy(xpath = "//div[2]/gw-pl-accordion//div//div//div" )
    WebElement ADD_SECOND_BUILDING_BTN_CSS;

    @FindBy(css = "[model='buildingView.description'] input")
    WebElement ADD_BUILDING_DESC_CSS;

    @FindBy(xpath = "//input[@ng-model='term.newValue'][2]")
    WebElement PRSNL_PPTY_LIMIT_XPATH;

    @FindBy(css = "[model='buildingView.classCode'] textarea")
    WebElement ADD_CLASS_CODE_CSS;

    @FindBy(css = "[model='buildingView.classCode'] [ng-click='wipe()']")
    WebElement CLEAR_CLASS_CODE_CSS;

    @FindBy(css = "[model='buildingView.basisAmount'] input")
    WebElement ADD_BASIS_AMOUNT_CSS;

    @FindBy(css = "[model='buildingView.yearBuilt'] input")
    WebElement ADD_YEAR_BUILT_CSS;

    @FindBy(css = "[model='buildingView.constructionType'] select")
    WebElement ADD_CONS_TYPE_CSS;

    @FindBy(css = "[model='buildingView.numberOfStories'] input")
    WebElement ADD_STORIES_CSS;

    @FindBy(css = "[model='buildingView.totalAreaExcludingBasement'] input")
    WebElement ADD_TOTAL_AREA_CSS;

    @FindBy(css = "[model='buildingView.percentageSprinklered'] select")
    WebElement ADD_SPRINKLERED_CSS;

    @FindBy(css = "[model='buildingView.exposure'] input")
    WebElement ADD_EXPOSURE_CSS;

    @FindBy(css = "[model='hasAlarm'] [class='gw-first']")
    WebElement ADD_ALARM_YES_BTN_CSS;

    @FindBy(css = "[model='hasAlarm'] [class='gw-second']")
    WebElement ADD_ALARM_NO_BTN_CSS;

    @FindBy(css = "[model='buildingView.alarmType'] select")
    WebElement ADD_ALARM_TYPE_CSS;

    @FindBy(css = "[on-click*='save(locationForm)'], [ng-click*='save(newLocationForm)'], [on-click='saveBuilding(newBuildingForm)']")
    WebElement ADD_LOCATION_SAVE_BTN_BOP_CSS;

    @FindBy(css = "[on-click*='save(coverageForm)']")
    WebElement EDIT_CVG_SAVE_BTN_BOP_CSS;

    @FindBy(css = "button[primary][on-click*='saveBuilding'], button[on-click*='updateBuilding()']")
    WebElement ADD_BUILDING_SAVE_BTN_BOP_CSS;

    @FindBy(css = "button[on-click='back()']")
    WebElement ADD_BUILDING_BACK_BTN_BOP_CSS;

    @FindBy(css = "button[ng-click='back()']")
    WebElement ADD_LOCATION_BACK_BTN_BOP_CSS;

    @FindBy(css = ".gw-building-year-built div")
    WebElement YEAR_BUILT_CSS;

    @FindBy(css = ".gw-building-no-of-stories div")
    WebElement STORIES_CSS;

    @FindBy(css = ".gw-building-construction-type div")
    WebElement CONS_TYPE_CSS;

    @FindBy(css = ".gw-building-total-area div")
    WebElement TOT_AREA_CSS;

    @FindBy(css = ".gw-building-exposure div")
    WebElement EXPOSURE_CSS;

    @FindBy(css = ".gw-building-alarm div")
    WebElement ALARM_TYPE_CSS;

    @FindBy(css = ".gw-building-property-class div")
    WebElement PROP_CLASS_CODE_CSS;

    @FindBy(css = ".gw-building-basis-amount div")
    WebElement BASIS_AMOUNT_CSS;

    @FindBy(css = ".gw-bop-building-header [class*='name']")
    WebElement BLDNG_DESC_CSS;

    @FindBy(css = ".gw-building-sprinkler div")
    WebElement SPRINKLERED_CSS;

    @FindBy(css = "[ng-if='hasNumBuildingsInfo()']")
    WebElement NO_OF_BUILDING_ADDED_CSS;

    @FindBy(css = "[model='buildingView.classCode'] span[class='gw-required-asterisk']")
    WebElement CLASS_CODE_ASTERISK_CSS;

    @FindBy(css = "[ng-click='removeBuilding()']")
    WebElement REMOVE_BLDNG_BTN_CSS;

    @FindBy(css = ".gw-bop-location-header__delete:not(.gw-bop-location-header__action_hidden)")
    WebElement REMOVE_LOCATION_BTN_CSS;

    @FindBy(css = ".gw-modal [ng-click*='close'].gw-btn-primary")
    WebElement POP_UP_CONFIRM_BTN_CSS;

    @FindBy(css = "div[class='gw-comprop-add-location ng-scope'], div[class='gw-bop-add-location ng-scope']")
    WebElement ADD_LOCATION_BAR_CSS;

    @FindBy(css = "[model*='address.addressLine1'] input")
    WebElement ADD_ADDRESS_LINE1_CSS;

    @FindBy(css = "[model*='address.addressLine2'] input")
    WebElement ADD_ADDRESS_LINE2_CSS;

    @FindBy(css = "[model*='address.addressLine3'] input")
    WebElement ADD_ADDRESS_LINE3_CSS;

    @FindBy(css = "[model*='address.city'] input")
    WebElement ADD_CITY_CSS;

    @FindBy(css = "[ng-if='coverage.selected'] label")
    WebElement CVG_LBL_CSS;

    @FindBy(css = "[model*='address.postalCode'] input")
    WebElement ADD_ZIP_CODE_CSS;

    @FindBy(css = "[model*='address.state'] select")
    WebElement ADD_STATE_CSS;

    @FindBy(css = "[model*='locationView.locationCode'] input")
    WebElement ADD_LOCATION_CODE_CSS;

    @FindBy(xpath = "(//*[@class='gw-location-code'])[2]")
    WebElement LOCATION_CODE_DETAIL_XPATH;

    @FindBy(css = "[ng-click='editBuilding()']")
    WebElement BUILDING_EDIT_BTN_CSS;

    @FindBy(xpath = "((//*[@coverages='building.baseCoverages']/div)[1]//div[@ng-repeat='term in coverage.terms']/div)[2]")
    WebElement BUILDING_LMT_VIEW_XPATH;

    @FindBy(xpath = "((//*[@coverages='building.additionalCoverages']/div)[1]//div[@ng-repeat='term in coverage.terms']/div)[2]")
    WebElement TENANTS_LBLTY_LMT_VIEW_XPATH;

    @FindBy(css = ".noCoverage")
    WebElement NO_ADD_COVERAGE_MSG_CSS;

    @FindBy(css = ".gw-bop-building-additional-coverages-header")
    WebElement ADD_CVG_HEADER_CSS;

    @FindBy(xpath = "((//gw-pc-editable-coverages)[2]//ng-form)[4]//label")
    WebElement SELECT_TENANTS_LBLTY_XPATH;

    @FindBy(css = "[model*='locationView.phone'] input")
    WebElement ADD_PHONE_CSS;

    @FindBy(css = "[model*='locationView.fireProtection'] select")
    WebElement ADD_FIRE_PROTECTION_CSS;

    @FindBy(css = ".gw-comprop-icon_pin-icon-primary, .gw-bop-icon_pin-icon-primary")
    WebElement PRIMARY_LOCATION_ICON_CSS;

    @FindBy(xpath = "//*[@class='gw-bop-icon gw-bop-icon_pin-icon-primary']/../following-sibling::div/*[@ng-click='removeLocation()']")
    WebElement REMOVE_PRIMARY_LOCATION_BTN_XPATH;

    @FindBy(css = ".gw-no-coverage-displayed")
    WebElement ADD_BLDNG_MSG_CSS;

    private final static String BLDNG_HEADER_DESC = "[class*='gw-bop-building-header'] [class*='name']";

    private final static String LOC_HEADER_DESC = "[class*='gw-bop-location-header'] [class*='name']";

    private static final By RMV_BLD = By.cssSelector("ng-click='removeBuilding()");

    private static final By BUILDING_ITEM = By.cssSelector("[class='gw-location-buildings'] [class='gw-bop-building-header__name ng-binding'], [class='gw-location-buildings'] [class='gw-comprop-building-header__name ng-binding']");

    private static final By CLASS_CODES_VALUES = By.cssSelector("[ng-bind-html*='match.model.code']");

    private final static String POP_UP_CONFIRM_MSG = "//*[@class='gw-modal gw-fade  in']//*[@class='gw-modal-header ng-scope'] | //*[@class='gw-modal__inner']//*[@class='gw-modal-header ng-scope'] ";

    private final static String DELETE_CONFIRM_MSG = "//*[@class='gw-btn gw-modal-btn gw-btn-primary']";

    String LOCATION_DETAILS_HEADER = "//*[contains(text(), '"+data.get("AddressHeader")+"')]";

    private static final String BUILDING_TAB_SELECT = "(//*[@class='gw-building-body']//li)[$]/a";

    private final static String SELECTABLE_COVERAGES_XPATH = "//gw-pc-editable-coverages//*[@ng-click='select($event, coverage)']";

    private final static String BASE_CVGS_VIEW_SUB_XPATH = "//*[@ng-repeat='coverage in _coverages track by coverage.id']";

    private final static String BASE_CVGS_VIEW_CHANGE_XPATH = "//gw-pc-coverages-list";

    private final static String ADD_CVGS_VIEW_XPATH = "//gw-pc-readonly-coverages[@coverages='building.additionalCoverages']//*[@ng-repeat='coverage in _coverages track by coverage.id']";

    private final static String CVG_INPUT_XPATH_PERSONAL = "//input[@id='BOPBPPBldgLim']";

    private final static String CVG_INPUT_XPATH = ".//*[contains(@gw-test-policycommon-editablecoverages-editablecoverages, 'Limit')]//input";

    private final static String CVG_SELECT_XPATH = ".//*[contains(@gw-test-policycommon-editablecoverages-editablecoverages, 'Valuation Method')]//select";

    private final static String BLDNG_LMT_INPUT_XPATH = "//input[@ng-model='term.newValue'][1]";

    private final static String CLASS_CODE_RESULT_CSS = "//*[@model='buildingView.classCode']//li";

    private final static String CLEAR_CLASS_CODE_BTN_CSS = "i[ng-click='wipe()']";

    By BUILDING_COVERAGES_BLOCK = By.cssSelector("gw-pc-coverages-list[coverages='building.coverages'], gw-pc-coverages-list[coverages='building.baseCoverages'], gw-pc-coverages-list gw-pc-editable-coverages");

    By BLDNG_LMT_INPUT = By.cssSelector("input[id='BOPBldgLim'], input[id='CPBldgCovLimit']");

    By BLDNG_PROPERTY_LMT_INPUT = By.cssSelector("input[id='BOPBPPBldgLim'], [id='CPBPPCovLimit']");

    By SUBMIT_BUILDING_BUTTON = By.cssSelector("input[id='BOPBldgLim']");


    public BuildingsAndLocationsPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public BuildingsAndLocationsPage(Object dataObj)
    {
        this.data = (HashMap<String, String>) dataObj;

        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }


    public BuildingsAndLocationsPage saveAddedBuilding()
    {
        seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_SAVE_BTN_BOP_CSS);
        seleniumCommands.clickbyJS(ADD_BUILDING_SAVE_BTN_BOP_CSS);
        return this;
    }

    public BuildingsAndLocationsPage clickBackAndConfirmOnBuilding(){
        seleniumCommands.click(ADD_BUILDING_BACK_BTN_BOP_CSS);
        new Modal().confirm();
        return this;
    }

    public BuildingsAndLocationsPage clickBackAndConfirmOnLocation(){
        seleniumCommands.click(ADD_LOCATION_BACK_BTN_BOP_CSS);
        new Modal().confirm();
        return this;
    }

    public BuildingsAndLocationsPage saveBOPBuilding()
    {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_SAVE_BTN_BOP_CSS);
        seleniumCommands.clickbyJS(ADD_BUILDING_SAVE_BTN_BOP_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage saveBOPLocation()
    {
        seleniumCommands.waitForElementToBeClickable(ADD_LOCATION_SAVE_BTN_BOP_CSS);
        seleniumCommands.clickbyJS(ADD_LOCATION_SAVE_BTN_BOP_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage removeBuilding()
    {

        seleniumCommands.clickbyJS(REMOVE_BLDNG_BTN_CSS);
        seleniumCommands.waitForElementToBePresent(POP_UP_CONFIRM_BTN_CSS);
        seleniumCommands.clickbyJS(POP_UP_CONFIRM_BTN_CSS);
        return this;
    }

    public BuildingsAndLocationsPage removeBuilding(String buildingDesc)
    {
        for (WebElement element:seleniumCommands.findElements(By.cssSelector(BLDNG_HEADER_DESC))
             ) {
            if(seleniumCommands.getTextAtLocator(element).equals(buildingDesc)){
                seleniumCommands.clickbyJS(element);
                seleniumCommands.clickbyJS(element.findElement(By.xpath("./..//div[@ng-click='removeBuilding()']")));
                seleniumCommands.waitForElementToBePresent(POP_UP_CONFIRM_BTN_CSS);
                seleniumCommands.clickbyJS(POP_UP_CONFIRM_BTN_CSS);
                return this;
            }
        }
        return this;
    }

    public BuildingsAndLocationsPage getNewBuildingForm()
    {

        seleniumCommands.logInfo("Clicking Add Building button");
        seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_BUILDING_BTN_CSS);
      //  ADD_BUILDING_BTN_CSS.click();
        seleniumCommands.waitForElementToBeEnabled(ADD_CLASS_CODE_CSS);
        return this;
    }

    public BuildingsAndLocationsPage getNewBuildingForm(String locHeader)
    {
        for (WebElement element:seleniumCommands.findElements(By.cssSelector(LOC_HEADER_DESC))
                ) {
            if (seleniumCommands.getTextAtLocator(element).equals(locHeader)) {
                seleniumCommands.clickbyJS(element);
                seleniumCommands.logInfo("Clicking Add Building button");
                seleniumCommands.clickbyJS(element.findElement(By.xpath("./ancestor::*[contains(@class, 'gw-is-open')]//i[@class='gw-bop-btn__icon fa fa fa-building-o']")));
                seleniumCommands.waitForElementToBeEnabled(ADD_CLASS_CODE_CSS);
                return this;
            }
        }
        return this;
    }

    public BuildingsAndLocationsPage getSecondBuildingForm()
    {

        seleniumCommands.logInfo("Clicking Second Add Building button");
        seleniumCommands.waitForElementToBeClickable(ADD_SECOND_BUILDING_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_SECOND_BUILDING_BTN_CSS);
        seleniumCommands.waitForElementToBeEnabled(ADD_CLASS_CODE_CSS);
        return this;
    }

    public BuildingsAndLocationsPage getBuildingForNewLocationForm()
    {

        seleniumCommands.logInfo("Clicking Second Add Building button");
        seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_FOR_NEW_LOCATION_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_BUILDING_FOR_NEW_LOCATION_BTN_CSS);
        //  ADD_BUILDING_BTN_CSS.click();
        seleniumCommands.waitForElementToBeEnabled(ADD_CLASS_CODE_CSS);
        return this;
    }


    public BuildingsAndLocationsPage changeLimitOnCPBuilding(String buildingLimit){
        WebElement INPUT_CVG_XPATH = new Pagefactory().getCoverageEntry("Building Coverage").findElement(By.xpath(CVG_INPUT_XPATH));
        seleniumCommands.waitForElementToBeVisible(INPUT_CVG_XPATH);
        seleniumCommands.type(INPUT_CVG_XPATH, buildingLimit);
        seleniumCommands.click(CVG_LBL_CSS);
        return this;
    }

    public BuildingsAndLocationsPage removeLocation()
    {
        seleniumCommands.waitForElementToBeVisible(REMOVE_LOCATION_BTN_CSS);
        seleniumCommands.clickbyJS(REMOVE_LOCATION_BTN_CSS);


        seleniumCommands.waitForElementToBePresent(By.xpath(DELETE_CONFIRM_MSG));
        seleniumCommands.clickbyJS(By.xpath(DELETE_CONFIRM_MSG));

        seleniumCommands.waitForElementToDisappear(By.xpath(LOCATION_DETAILS_HEADER));

        return this;
    }

    public BuildingsAndLocationsPage saveAddedLocation()
    {
        seleniumCommands.waitForElementToBeClickable(ADD_LOCATION_SAVE_BTN_BOP_CSS);
        ADD_LOCATION_SAVE_BTN_BOP_CSS.sendKeys("");
        seleniumCommands.clickbyJS(ADD_LOCATION_SAVE_BTN_BOP_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage saveCoveragesOnBuilding()
    {
        seleniumCommands.waitForElementToBeClickable(EDIT_CVG_SAVE_BTN_BOP_CSS);
        seleniumCommands.clickbyJS(EDIT_CVG_SAVE_BTN_BOP_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage getNewLocationForm()
    {
        seleniumCommands.waitForElementToBeClickable(ADD_LOCATION_BAR_CSS);
        ADD_LOCATION_BAR_CSS.click();
        return this;
    }

    public BuildingsAndLocationsPage expandAddCoveragesOnNewBldng()
    {
        seleniumCommands.waitForElementToBeVisible(ADD_CVG_HEADER_CSS);
        seleniumCommands.clickbyJS(ADD_CVG_HEADER_CSS);
        return this;
    }

    public BuildingsAndLocationsPage clickOnEditBldng()
    {
        seleniumCommands.waitForElementToBeVisible(BUILDING_EDIT_BTN_CSS);
        seleniumCommands.clickbyJS(BUILDING_EDIT_BTN_CSS);
        return this;
    }


    public WebElement getCoverageEntryOnBuildingCoveragesView(String cvgName){
        logger.info("Searching "+cvgName+" on Coverages tab");
        List<WebElement> allCoverages;
        if(seleniumCommands.isElementPresent(By.xpath(BASE_CVGS_VIEW_SUB_XPATH)))
            allCoverages = seleniumCommands.findElements(By.xpath(BASE_CVGS_VIEW_SUB_XPATH));
        else
            allCoverages = seleniumCommands.findElements(By.xpath(BASE_CVGS_VIEW_CHANGE_XPATH));

        for (WebElement element:allCoverages) {
            if(seleniumCommands.getTextAtLocator(element.findElement(By.xpath(".//div"))).contains(cvgName))
                return element;
        }
        return null;
    }

    public WebElement getCoverageEntryOnBuildingAddCoveragesView(String cvgName){
        logger.info("Searching "+cvgName+" on Additional Coverages tab");
        List<WebElement> allCoverages = seleniumCommands.findElements(By.xpath(ADD_CVGS_VIEW_XPATH));
        for (WebElement element:allCoverages) {
            if(seleniumCommands.getTextAtLocator(element.findElement(By.xpath("./div"))).contains(cvgName))
                return element;
        }
        return null;
    }

    public BuildingsAndLocationsPage setClassCodeEmpty(){
        logger.info("Clearing class code field");
        seleniumCommands.waitForElementToBeVisible(CLEAR_CLASS_CODE_CSS);
        seleniumCommands.click(CLEAR_CLASS_CODE_CSS);
        seleniumCommands.waitForElementToBeVisible(ADD_BLDNG_MSG_CSS);
        return this;
    }

    //set methods

    //set new building

    //This method takes a boolean parameter to identify if new/old set of data has to be used, this is mostly needed for test cases requiring editing values on a form.
    public BuildingsAndLocationsPage setBuildingData(String policyType, boolean newData) {
        String n = "";
        if(newData) n = "New";
       seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_DESC_CSS);
        if(policyType.equals(PolicyType.BO.toString())){
            this.setPropClassCode(data.get(n+"BOPPropertyClassCode"));
            this.setBasisAmount(data.get(n+"BasisAmount"));
        }
        else if(policyType.equals(PolicyType.CP.toString()))
            this.setPropClassCode(data.get(n+"CPPropertyClassCode"));
        this.setBuildingDesc(data.get(n+"BuildingDescription")).setYearBuilt(data.get(n+"YearBuilt")).setConstructionType(data.get(n+"ConstructionType")).setNoOfStories(data.get(n+"NoOfStories"))
                .setTotalArea(data.get(n+"TotalArea")).setSprinklered(data.get(n+"Sprinklered")).setExposure(data.get(n+"Exposure")).setHasAlarm(data.get(n+"HasAlarm"));
       return this;
    }

    public BuildingsAndLocationsPage setBuildingDesc(String buildingDesc) {
        seleniumCommands.waitForElementToBeClickable(ADD_BUILDING_DESC_CSS);
        seleniumCommands.type(ADD_BUILDING_DESC_CSS, buildingDesc);
        return this;
    }

    public BuildingsAndLocationsPage setBuildingLimit(String buildingLimit) {
        seleniumCommands.waitForElementToBePresent(BUILDING_COVERAGES_BLOCK);
        seleniumCommands.type(BLDNG_LMT_INPUT,buildingLimit);

        String productCode;
        if ((ThreadLocalObject.getData().get("PRODUCT_CODE")!=null) && (ThreadLocalObject.getData().get("PRODUCT_CODE").equals("CommercialProperty")))
            productCode = "Building Coverage";
        else
            productCode = "Building";
        seleniumCommands.click(CVG_LBL_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectFromDropdownByIndex(new Pagefactory().getCoverageEntry(productCode).findElement(By.xpath(CVG_SELECT_XPATH)), 2);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage setPersonalPropertyLimit() {
        seleniumCommands.type(BLDNG_PROPERTY_LMT_INPUT,data.get("PersonalPropertyLimit"));
        seleniumCommands.click(CVG_LBL_CSS);
        return this;
    }

    public BuildingsAndLocationsPage setTenantsLiabilityCvg(){
        Pagefactory pagefactory = new Pagefactory();
        this.expandAddCoveragesOnNewBldng();
        pagefactory.clickOnCoverageCheckbox("Tenants Liability", false);
        seleniumCommands.waitForElementToBeVisible(pagefactory.getCoverageEntry("Tenants Liability").findElement(By.xpath(CVG_INPUT_XPATH)));
        seleniumCommands.click(pagefactory.getCoverageEntry("Tenants Liability").findElement(By.xpath(CVG_INPUT_XPATH)));
        seleniumCommands.type(pagefactory.getCoverageEntry("Tenants Liability").findElement(By.xpath(CVG_INPUT_XPATH)), data.get("TenantsLiability"));
        seleniumCommands.click(CVG_LBL_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage setPropClassCode(String classCode) {
        seleniumCommands.waitForElementToBePresent(ADD_CLASS_CODE_CSS);
        if(seleniumCommands.isElementPresent(By.cssSelector(CLEAR_CLASS_CODE_BTN_CSS)))
            this.clearPropClassCodeField();
        seleniumCommands.typeByJS(ADD_CLASS_CODE_CSS, classCode);
        seleniumCommands.click(ADD_CLASS_CODE_CSS);
        seleniumCommands.waitForElementToBeVisible(CLASS_CODES_VALUES);
        List<WebElement> classCodes = seleniumCommands.findElements(CLASS_CODES_VALUES);
        ThreadLocalObject.getData().put("PropCodeCount", classCodes.size()+"");
        WebElement filtered=  classCodes.stream()
                .filter(prod -> prod.getText().equals(classCode.split(" ")[0]))
                .findFirst().orElse(null);
        if (filtered!=null) {
            filtered.click();
        }
        else    {
            seleniumCommands.focusOff();
        }
        return this;
    }

    public BuildingsAndLocationsPage setBasisAmount(String basisAmount) {
        seleniumCommands.waitForElementToBeVisible(ADD_BASIS_AMOUNT_CSS);
        seleniumCommands.type(ADD_BASIS_AMOUNT_CSS, basisAmount);
        return this;
    }


    public BuildingsAndLocationsPage setYearBuilt(String yearBuilt) {
        seleniumCommands.waitForElementToBeClickable(ADD_YEAR_BUILT_CSS);
        seleniumCommands.type(ADD_YEAR_BUILT_CSS, yearBuilt);
        return this;
    }

    public BuildingsAndLocationsPage setConstructionType(String constructionType) {
        seleniumCommands.waitForElementToBeClickable(ADD_CONS_TYPE_CSS);
        seleniumCommands.selectDropDownValueByText(ADD_CONS_TYPE_CSS, constructionType);
        return this;
    }

    public BuildingsAndLocationsPage setNoOfStories(String noOfStories) {
        seleniumCommands.waitForElementToBeClickable(ADD_STORIES_CSS);
        seleniumCommands.type(ADD_STORIES_CSS, noOfStories);
        return this;
    }

    public BuildingsAndLocationsPage setTotalArea(String totalArea) {
        seleniumCommands.waitForElementToBeClickable(ADD_TOTAL_AREA_CSS);
        seleniumCommands.type(ADD_TOTAL_AREA_CSS, totalArea);
        return this;
    }

    public BuildingsAndLocationsPage setSprinklered(String sprinklered) {
        seleniumCommands.waitForElementToBeClickable(ADD_SPRINKLERED_CSS);
        seleniumCommands.selectDropDownValueByText(ADD_SPRINKLERED_CSS, sprinklered);
        return this;
    }

    public BuildingsAndLocationsPage setExposure(String exposure) {
        seleniumCommands.waitForElementToBeClickable(ADD_EXPOSURE_CSS);
        seleniumCommands.type(ADD_EXPOSURE_CSS, exposure);
        return this;
    }

    public BuildingsAndLocationsPage setHasAlarm(String hasAlarm) {
        if (hasAlarm.equals("Yes")) {
            seleniumCommands.clickbyJS(ADD_ALARM_YES_BTN_CSS);
            seleniumCommands.waitForElementToBeClickable(ADD_ALARM_TYPE_CSS);
            seleniumCommands.selectDropDownValueByText(ADD_ALARM_TYPE_CSS, data.get("AlarmType"));
        } else {
            seleniumCommands.clickbyJS(ADD_ALARM_NO_BTN_CSS);
        }
        return this;
    }

    public BuildingsAndLocationsPage clickSubmitOnBuildingLimit(WebElement element){
        logger.info("Clicking on Submit to sync coverages.");
        seleniumCommands.clickbyJS(element.findElement(By.xpath(".//button[@ng-show='showNestedButton'][@aria-hidden='false']")));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public BuildingsAndLocationsPage clearPropClassCodeField(){
        seleniumCommands.click(By.cssSelector(CLEAR_CLASS_CODE_BTN_CSS));
        return this;
    }

    public String getLocationHeader(boolean newData){
        String n = "";
        if(newData) n="New";
        return data.get(n+"LocAddressLine1")+", "+data.get(n+"LocationCity")+", "+data.get(n+"LocationState").substring(0,2).toUpperCase();
    }

    //set new location

    //This method takes a boolean parameter to identify if new/old set of data has to be used, this is mostly needed for test cases requiring editing values on a form.
    public BuildingsAndLocationsPage setLocationData(boolean newData) {
        String n = "";
        if(newData) n = "New";
        seleniumCommands.waitForElementToBeClickable(ADD_ADDRESS_LINE1_CSS);
        this.setAddressLine1(data.get(n+"LocAddressLine1")).setAddressLine2(data.get(n+"LocAddressLine2")).setAddressLine3(data.get(n+"LocAddressLine3")).setCity(data.get(n+"LocationCity")).setZIPCode(data.get(n+"LocationZipcode")).setState(data.get(n+"LocationState"))
                .setLocationCode(data.get(n+"LocationCode")).setPhone(data.get(n+"LocationPhone")).setFireProtection(data.get(n+"FireProtection"));
        return this;
    }

    public BuildingsAndLocationsPage setAddressLine1(String addressLine1) {
        seleniumCommands.waitForElementToBeClickable(ADD_ADDRESS_LINE1_CSS);
        seleniumCommands.type(ADD_ADDRESS_LINE1_CSS, addressLine1);
        return this;
    }

    public BuildingsAndLocationsPage setAddressLine2(String addressLine2) {
        seleniumCommands.waitForElementToBeClickable(ADD_ADDRESS_LINE2_CSS);
        seleniumCommands.type(ADD_ADDRESS_LINE2_CSS, addressLine2);
        return this;
    }

    public BuildingsAndLocationsPage setAddressLine3(String addressLine3) {
        seleniumCommands.waitForElementToBeClickable(ADD_ADDRESS_LINE3_CSS);
        seleniumCommands.type(ADD_ADDRESS_LINE3_CSS, addressLine3);
        return this;
    }

    public BuildingsAndLocationsPage setCity(String city) {
        seleniumCommands.waitForElementToBeClickable(ADD_CITY_CSS);
        seleniumCommands.type(ADD_CITY_CSS, city);
        return this;
    }

    public BuildingsAndLocationsPage setZIPCode(String zipCode) {
        seleniumCommands.waitForElementToBeClickable(ADD_ZIP_CODE_CSS);
        seleniumCommands.type(ADD_ZIP_CODE_CSS, zipCode);
        return this;
    }

    public BuildingsAndLocationsPage setState(String state) {
        seleniumCommands.waitForElementToBeClickable(ADD_STATE_CSS);
        seleniumCommands.selectDropDownValueByText(ADD_STATE_CSS, state);
        return this;
    }

    public BuildingsAndLocationsPage setLocationCode(String locationCode) {
        seleniumCommands.waitForElementToBeClickable(ADD_LOCATION_CODE_CSS);
        seleniumCommands.type(ADD_LOCATION_CODE_CSS, locationCode);
        return this;
    }

    public BuildingsAndLocationsPage setPhone(String phone) {
        seleniumCommands.waitForElementToBeClickable(ADD_PHONE_CSS);
        seleniumCommands.type(ADD_PHONE_CSS, phone);
        return this;
    }

    public BuildingsAndLocationsPage setFireProtection(String fireProtection) {
        seleniumCommands.waitForElementToBeClickable(ADD_FIRE_PROTECTION_CSS);
        seleniumCommands.selectDropDownValueByText(ADD_FIRE_PROTECTION_CSS, fireProtection);
        return this;
    }

    public BuildingsAndLocationsPage selectBuildingTab(String tab){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(By.xpath(BUILDING_TAB_SELECT.replace("$", tab)));
        return this;
    }


    //Validation

    public Validation isBasisAmountCorrectOnDetails(){
        seleniumCommands.logInfo("Verifying Building limit on Details tab");
        this.selectBuildingTab("1");
        seleniumCommands.waitForElementToBeVisible(BASIS_AMOUNT_CSS);
        return new Validation(seleniumCommands.getTextAtLocator(BASIS_AMOUNT_CSS), data.get("NewBasisAmount"));
    }

    public void isBuildingDescCorrectOnDetails(){
        seleniumCommands.logInfo("Verifying Building Description on Details tab");
        this.selectBuildingTab("1");
        seleniumCommands.waitForElementToBeVisible(BLDNG_DESC_CSS);
        new Validation(seleniumCommands.getTextAtLocator(BLDNG_DESC_CSS), data.get("NewBuildingDescription")).shouldBeEqual("Building description isn't correct in wizard");
    }

    public Validation isBuildingLimitDataCorrectOnCoverages(){
        seleniumCommands.logInfo("Verifying Building data on Coverages tab");
        seleniumCommands.waitForElementToBeVisible(ADD_BUILDING_BTN_CSS);
        this.selectBuildingTab("2");
        WebElement COVERAGE_SECTION = this.getCoverageEntryOnBuildingCoveragesView("Building");
        new Validation(seleniumCommands.getTextAtLocator(COVERAGE_SECTION.findElement(By.xpath("./div[2]/div[2]/div[2]"))), data.get("NewBuildingLimit")).shouldBeEqual();
        new Validation(seleniumCommands.getTextAtLocator(COVERAGE_SECTION.findElement(By.xpath("./div[2]/div[1]/div[2]"))), data.get("BuildingIncrease")).shouldBeEqual();
        new Validation(seleniumCommands.getTextAtLocator(COVERAGE_SECTION.findElement(By.xpath("./div[2]/div[3]/div[2]"))), data.get("ValuationMethod")).shouldBeEqual();
        new Validation(seleniumCommands.getTextAtLocator(COVERAGE_SECTION.findElement(By.xpath("./div[2]/div[4]/div[2]"))), data.get("Coinsurance")).shouldBeEqual();
        return new Validation(true);
    }

    public Validation isTenantsLiabilityAmountCorrectOnAddCoverages(){
        seleniumCommands.waitForElementToBeVisible(ADD_BUILDING_BTN_CSS);
        seleniumCommands.logInfo("Verifying Building limit on Additional Coverages tab");
        this.selectBuildingTab("3");
        seleniumCommands.waitForElementToBeVisible(TENANTS_LBLTY_LMT_VIEW_XPATH);
        return new Validation(seleniumCommands.getTextAtLocator(this.getCoverageEntryOnBuildingAddCoveragesView("Tenants Liability").findElement(By.xpath("./div[2]/div[1]/div[2]"))).replace(",",""), data.get("TenantsLiability"));
    }

    public Validation isNoAddCoveragesMessageDisplayed(){
        seleniumCommands.waitForElementToBeVisible(ADD_BUILDING_BTN_CSS);
        seleniumCommands.logInfo("Verifying No Additional Coverages message on Additional Coverages tab");
        this.selectBuildingTab("3");
        seleniumCommands.waitForElementToBeVisible(NO_ADD_COVERAGE_MSG_CSS);
        return new Validation(seleniumCommands.getTextAtLocator(NO_ADD_COVERAGE_MSG_CSS), DataConstant.NO_ADD_CVG_MSG_TEXT);
    }

    public Validation isAddBuildingDetailsMessageDisplayed(){
        seleniumCommands.logInfo("Verifying if add building details to view coverages message is displayed and that the coverage section isn't displayed");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(seleniumCommands.isElementPresent(By.xpath(BLDNG_LMT_INPUT_XPATH)))
            return new Validation(false);
        else{
            new Validation(seleniumCommands.getTextAtLocator(ADD_BLDNG_MSG_CSS), DataConstant.ADD_BLDNG_FOR_CVG_MSG_TEXT).shouldBeEqual();
            return new Validation(true);
        }

    }

    public Validation isNumberOfBuildingsCorrect(String noOfBuildingAdded) {
        seleniumCommands.logInfo( "Validating number of buildings");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(NO_OF_BUILDING_ADDED_CSS.getText(), noOfBuildingAdded );
    }

    public Validation isBuildingAdded() {
        seleniumCommands.waitForElementToBeClickable(REMOVE_BLDNG_BTN_CSS);
        List<WebElement> building = seleniumCommands.findElements(BUILDING_ITEM);
        boolean isBuildingAdded = false;
        for(WebElement element : building)
        {
            if(element.getText().equals(data.get("BuildingDescription")))
            {
                isBuildingAdded = true;
                break;
            }

        }
        return new Validation(isBuildingAdded);
    }

    public Validation isBOPBuildingSaved() {
        seleniumCommands.logInfo( "Validating the Building fields");
        seleniumCommands.waitForElementToBeVisible(YEAR_BUILT_CSS);
        new Validation(seleniumCommands.getTextAtLocator(YEAR_BUILT_CSS),data.get("YearBuilt")).shouldBeEqual("Year Built didn't save");
        new Validation(seleniumCommands.getTextAtLocator(STORIES_CSS),data.get("NoOfStories")).shouldBeEqual("No. of stories didn't save");
        new Validation(seleniumCommands.getTextAtLocator(EXPOSURE_CSS),data.get("Exposure")).shouldBeEqual("Exposure didn't save");
        new Validation(seleniumCommands.getTextAtLocator(CONS_TYPE_CSS),data.get("ConstructionType").substring(0,1)).shouldBeEqual("Construction Type didn't save");
        new Validation(seleniumCommands.getTextAtLocator(TOT_AREA_CSS),data.get("TotalArea")).shouldBeEqual("Total Area didn't save");
        new Validation(seleniumCommands.getTextAtLocator(ALARM_TYPE_CSS),data.get("AlarmType").toLowerCase()).shouldBeEqual("Alarm Type didn't save");
        new Validation(seleniumCommands.getTextAtLocator(SPRINKLERED_CSS),data.get("Sprinklered")).shouldBeEqual("% Sprinklered didn't save");
        new Validation(seleniumCommands.getTextAtLocator(PROP_CLASS_CODE_CSS),data.get("BOPPropertyClassCode")).shouldBeEqual("Property Class Code didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BASIS_AMOUNT_CSS), data.get("BasisAmount")).shouldBeEqual("Basis Amount didn't save");
        return new Validation(true);
    }

    public Validation isPropClassCodeFieldMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory Error for Property Class Code field");
        return new Validation(seleniumCommands.getErrorMessageForDatePicker(ADD_CLASS_CODE_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isAddressLine1MarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory Error for Address Line 1 field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(ADD_ADDRESS_LINE1_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isZipcodeMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory Error for ZIP Code field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(ADD_ZIP_CODE_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isCityMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory Error for City field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(ADD_CITY_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isStateMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory Error for State field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(ADD_STATE_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isPropClassCodeFieldMarkedWithAsterisk() {
        seleniumCommands.logInfo( "Validating the Asterisk for Property Class Code Field");
        return new Validation(seleniumCommands.isElementPresent(CLASS_CODE_ASTERISK_CSS));
    }

    public Validation isLocationPresent() {
        seleniumCommands.logInfo( "Validating if location is present");
        return new Validation(seleniumCommands.isElementPresent(By.xpath(LOCATION_DETAILS_HEADER)));
    }

    public Validation isRemoveIconAvailableForPrimaryLocation() {
        seleniumCommands.logInfo( "Validating if remove icon for primary location is present");
        seleniumCommands.clickbyJS(PRIMARY_LOCATION_ICON_CSS);
        return new Validation(REMOVE_PRIMARY_LOCATION_BTN_XPATH.isDisplayed());

    }

    public Validation areTenResultsDisplayedForClassCode(){
        seleniumCommands.logInfo("Verifying if exactly 10 results are displayed for Property Class Codes");
        return new Validation(ThreadLocalObject.getData().get("PropCodeCount").equals("10"));
    }

    public Validation areResultsDisplayedForClassCode(){
        seleniumCommands.logInfo("Verifying if no results are displayed for incorrect Property Class Codes");
        return new Validation(seleniumCommands.isElementPresent(By.xpath(CLASS_CODE_RESULT_CSS)));
    }

    public void validateBOPBuildingDetailsInBackend(){
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParseEndorsementData.getBOPBuildingDetailsForPolicyChange(jsonData);
        new Validation(lineCoverages.get("Building_Desc").trim(),data.get("NewBuildingDescription")).shouldBeEqual("Building Description didn't match with backend");
        new Validation(lineCoverages.get("Basis_Amount"),data.get("NewBasisAmount")).shouldBeEqual("Basis Amount didn't match with backend");
        new Validation(lineCoverages.get("Building_Limit"), data.get("NewBuildingLimit")).shouldBeEqual("Building Limit didn't match with backend");
    }

    public String getPolicyChangeDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }
}
