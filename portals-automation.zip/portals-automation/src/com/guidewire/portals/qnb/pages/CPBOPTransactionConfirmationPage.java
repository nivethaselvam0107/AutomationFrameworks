package com.guidewire.portals.qnb.pages;


import com.guidewire.capabilities.agent.model.page.PolicyChangeSummaryPage;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.HashMap;

public class CPBOPTransactionConfirmationPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "a[ui-sref*='policies.detail.billing']")
    WebElement POLICY_BILLING_LINK_CSS;

    @FindBy(css = "[on-click*='goToTransaction()']")
    WebElement VIEW_CHANGE_BTN_CSS;

    @FindBy(css = "[on-click*='goToPolicy()']")
    WebElement VIEW_POLICY_BTN_CSS;

    @FindBy(css = "[class*='TransactionConfirmation'] i")
    WebElement TRANSACTION_DONE_ICON_CSS;

    @FindBy(css = "div[class*='gw-box TransactionConfirmation']")
    WebElement TRANSACTION_CONFIRMATION_SECTION_CSS;

    public CPBOPTransactionConfirmationPage() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public PolicySummary clickPolicyBillingPageLink(){
        seleniumCommands.waitForElementToBeVisible(POLICY_BILLING_LINK_CSS);
        seleniumCommands.clickbyJS(POLICY_BILLING_LINK_CSS);
        return new PolicySummary();
    }

    public PolicyChangeSummaryPage clickViewPolicyChangeBtn(){
        seleniumCommands.waitForElementToBeVisible(VIEW_CHANGE_BTN_CSS);
        seleniumCommands.clickbyJS(VIEW_CHANGE_BTN_CSS);
        return new PolicyChangeSummaryPage();
    }

    public PolicySummary clickViewPolicyBtn(){
        seleniumCommands.waitForElementToBeVisible(VIEW_POLICY_BTN_CSS);
        seleniumCommands.clickbyJS(VIEW_POLICY_BTN_CSS);
        return new PolicySummary();
    }



    //Validation

    public void validateTransactionConfirmationPage(String jobNum, String policyNum){
        if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
            new Validation(seleniumCommands.getTextAtLocator(TRANSACTION_CONFIRMATION_SECTION_CSS).replaceAll("\n"," "), DataConstant.TRANSACTION_CONFIRMATION_MSG.replace("jobNum", jobNum).replace("policyNum", policyNum).replaceAll("\n"," ")).shouldBeEqual("The transaction confirmation message wasn't correct");
        }else
            new Validation(seleniumCommands.getTextAtLocator(TRANSACTION_CONFIRMATION_SECTION_CSS), DataConstant.TRANSACTION_CONFIRMATION_MSG.replace("jobNum", jobNum).replace("policyNum", policyNum)).shouldBeEqual("The transaction confirmation message wasn't correct");
        new Validation(seleniumCommands.isElementPresent(TRANSACTION_DONE_ICON_CSS)).shouldBeTrue("Transaction Confirmation page not displayed");
    }

}
