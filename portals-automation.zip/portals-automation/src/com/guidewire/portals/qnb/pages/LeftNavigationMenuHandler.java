package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.Modal;

public class LeftNavigationMenuHandler {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();

	@FindBy(xpath = "//*[contains(@class,'wizard-sidebar-steps-wrapper')]")
	WebElement LEFT_NAV_SECTION_CSS;

	@FindBy(xpath = "//li[contains(text(),'Your Info')]")
	WebElement YOUR_INFO_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Qualification')]")
	WebElement QUALIFICATION_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Home')]")
	WebElement YOUR_HOME_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Construction')]")
	WebElement CONSTRUCTION_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Discount')]")
	WebElement DISCOUNT_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Policy Info')]")
	WebElement POLICY_INFO_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Payment Details')]")
	WebElement PAYMENT_DETAILS_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Drivers')]")
	WebElement DRIVER_DETAILS_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Vehicles')]")
	WebElement VEHICEL_DETAILS_PAGE_LINK;

	@FindBy(xpath = "//li[contains(text(),'Quote')]")
	WebElement QUOTE_PAGE_LINK;

	@FindBy(xpath = "(//div[contains(@class, 'gw-wizard-sidebar-steps')]//li)[1]")
	WebElement POLICY_DETAILS_PAGE_LINK;

	@FindBy(css = "[class*='gw-modal'] button[ng-click*='$close']")
	static WebElement MODAL_CONFIRM_BTN;

	public LeftNavigationMenuHandler() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public LeftNavigationMenuHandler(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}

	// Get Methods

	public YourInfoPage gotoYourInfoPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(YOUR_INFO_PAGE_LINK);
		new Modal().confirm();
		return new Pagefactory().getYourInfoPage();
	}

	public QualificationPage gotoQualificationPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(QUALIFICATION_PAGE_LINK);
		new Modal().confirm();
		return new Pagefactory().getQualificationPage();
	}
	
	public QualificationPage gotoQualificationPage_GPA() {
		clickToggelBar();
		QUALIFICATION_PAGE_LINK.click();
		new Modal().confirm();
		return new Pagefactory().getQualificationPage();
	}

	public DriverDetailsPage gotoDriverPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(DRIVER_DETAILS_PAGE_LINK);
		return new Pagefactory().getDriverDetailsPage();
	}
	
	public DriverDetailsPage gotoDriverPage_GPA() {
		clickToggelBar();
		DRIVER_DETAILS_PAGE_LINK.click();
		new Modal().confirm();
		return new Pagefactory().getDriverDetailsPage();
	}

	public VehicleDetailsPage gotoVehiclePage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(VEHICEL_DETAILS_PAGE_LINK);
		return new Pagefactory().getVehicelDetailsPage();
	}

	public Object gotoQuotePage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(QUOTE_PAGE_LINK);
		new Modal().confirm();
		if (data.get("PolicyType").equals("PersonalAuto")) {
			return new PAQuotePage();
		} else {
			return new HOQuotePage();
		}
	}

	public YourHomePage gotoYourHomePage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(YOUR_HOME_PAGE_LINK);
		new Modal().confirm();
		return new Pagefactory().getYourHomePage();
	}
	
	public YourHomePage gotoYourHomePage_GPA() {
		clickToggelBar();
		YOUR_HOME_PAGE_LINK.click();
		new Modal().confirm();
		return new Pagefactory().getYourHomePage();
	}
	
	public DiscountPage gotoDiscountPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(DISCOUNT_PAGE_LINK);
		new Modal().confirm();
		return new Pagefactory().getDiscountPage();
	}

	public LeftNavigationMenuHandler gotoConstructionPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(CONSTRUCTION_PAGE_LINK);
		new Modal().confirm();
		return this;
	}
	
	public ConstructionPage gotoConstructionPage_GPA() {
		clickToggelBar();
		CONSTRUCTION_PAGE_LINK.click();
		new Modal().confirm();
		return new Pagefactory().getConstructionPage();
	}
	
	public Object gotoPolicyInfo() {
		clickToggelBar();
		seleniumCommands.clickbyJS(POLICY_INFO_PAGE_LINK);
		new AlertHandler().closeAlert();
		if (data.get("PolicyType").equals("PersonalAuto")) {
			return new Pagefactory().getPAPolicyInfoPage();
		} else {
			return new Pagefactory().getHOPolicyInfoPage();
		}
	}
	
	public PaymentDetailsPage gotoPaymentDetailsPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(PAYMENT_DETAILS_PAGE_LINK);
		return new Pagefactory().getPaymentInfoPage();
	}

	public CPBOPPolicyDetailsPage goToPolicyDetailsPage() {
		clickToggelBar();
		seleniumCommands.clickbyJS(POLICY_DETAILS_PAGE_LINK);
		if(seleniumCommands.isElementPresent(MODAL_CONFIRM_BTN))
			new Modal().confirm();
		return new Pagefactory().getCPBOPPolicyDetailPage();
	}
	
	private void clickToggelBar()
	{
		String browser = ThreadLocalObject.getBrowserName();
		if (browser.equalsIgnoreCase("NEXUS5") || browser.equalsIgnoreCase("IPHONE6")) 
		{
			seleniumCommands.clickbyJS(By.cssSelector("[ng-click='toggleWizardStepDisplay()']"));
			seleniumCommands.waitForElementToBeVisible(LEFT_NAV_SECTION_CSS);
		}
	}
	
	//Validation
	
	public Validation isPaymentDetailsPageLoaded() {
		return new Validation(Pagefactory.getPageUrl().contains(DataConstant.PA_PAYMENT_PAGE));
	}

	public Validation isQuotePageDisabled() {
		{
			return new Validation(seleniumCommands.getAttributeValueAtLocator(QUOTE_PAGE_LINK,"class").contains("gw-not-visited"));
		}
	}
}
