package com.guidewire.portals.qnb.pages;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class CPBOPPolicyInfoPage extends CommonPage {

    @FindBy(css = "[model='submissionVM.bindData.contactEmail'] input")
    WebElement ADD_EMAIL_CSS;

    @FindBy(css = "[model='submissionVM.bindData.contactPhone'] input")
    WebElement ADD_PHONE_CSS;
    
    @FindBy(css = "[model='policyInfo.billAndPolAddrsEqual'] label[class*='second']")
	WebElement BILLING_ADD_NO_LBL_CSS;
    
    @FindBy(css = "[model='address.addressLine1'] input")
	WebElement ADDLINE1_TXT_CSS;

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    public CPBOPPolicyInfoPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public CPBOPPolicyInfoPage(Object dataObj)
    {
        this.data = (HashMap<String, String>) dataObj;
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }


    //set methods

    public CPBOPPolicyInfoPage setEmailField() {
        seleniumCommands.waitForElementToBeClickable(ADD_EMAIL_CSS);
        seleniumCommands.type(ADD_EMAIL_CSS, data.get("Email"));
        return this;
    }
    public CPBOPPolicyInfoPage setEmailField(String emailText) {
        seleniumCommands.waitForElementToBeClickable(ADD_EMAIL_CSS);
        seleniumCommands.type(ADD_EMAIL_CSS, emailText);
        return this;
    }
    
    public CPBOPPolicyInfoPage setBillingAddress() {
        seleniumCommands.clickbyJS(BILLING_ADD_NO_LBL_CSS);
        seleniumCommands.click(ADDLINE1_TXT_CSS);
        return this;
    }

    public CPBOPPolicyInfoPage setPhoneField() {
        seleniumCommands.waitForElementToBeClickable(ADD_PHONE_CSS);
        seleniumCommands.type(ADD_PHONE_CSS, data.get("Phone"));
        return this;
    }
    
    public CPBOPPolicyInfoPage setPhoneField(String number) {
        seleniumCommands.waitForElementToBeClickable(ADD_PHONE_CSS);
        seleniumCommands.type(ADD_PHONE_CSS, number);
        return this;
    }

    //Validation methods

    public Validation isEmailFieldMarkedWithError() {
        logger.info( "Validating the Mandatory Error for Email field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(ADD_EMAIL_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isPhoneFieldMarkedWithError() {
        logger.info( "Validating the Mandatory Error for Phone field");
        return new Validation(seleniumCommands.getErrorMessageForDatePicker(ADD_PHONE_CSS),DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isPolicyInfoPageSaved(){
        new Validation(seleniumCommands.getValueAttributeFromLocator(ADD_EMAIL_CSS), data.get("Email")).shouldBeEqual("Email didn't save");
        new Validation(seleniumCommands.getValueAttributeFromLocator(ADD_PHONE_CSS), data.get("Phone")).shouldBeEqual("Phone didn't save");
        return new Validation(true);
    }


}
