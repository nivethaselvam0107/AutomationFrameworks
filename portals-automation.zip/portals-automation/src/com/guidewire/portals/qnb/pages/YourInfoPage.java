package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.YourInfoPageLocators;

public class YourInfoPage extends CommonPage{
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	
	@FindBy(css = "h2")
	 WebElement YOURQUOTE_PAGE_HEADER_CSS;
	
	@FindBy(css = "[model='contact.firstName'] span[class='gw-required-asterisk'], [label='First Name'] span[class='gw-required-asterisk']")
	 WebElement FIRSTNAME_ASTERISK_CSS;
	 
	@FindBy(css = "[label='First Name'] input")
	 WebElement FIRSTNAME_TXT_CSS;
	 
	@FindBy(css = "[model='contact.lastName'] span[class='gw-required-asterisk'], [label='Last Name'] span[class='gw-required-asterisk']")
	 WebElement LASTNAME_ASTERISK_CSS;
	 
	@FindBy(css = "div[model='contact.lastName'] input, [label='Last Name'] input")
	 WebElement LASTNAME_TXT_CSS;

	@FindBy(css = "[gw-test-quoteandbind-bop-views-bop-contact-details-company_name] input")
	WebElement COMPANYNAME_TXT_CSS;

	@FindBy(css = "[gw-test-quoteandbind-bop-views-bop-contact-details-company_name] span[gw-test-platform-widgets-basicinputs-templates-input-ctrl-asterisk]")
	WebElement COMPANYNAME_ASTERISK_CSS;
	
	@FindBy(css = "label[for='Date of Birth'] span")
	 WebElement DOB_LBL_CSS;
	
	@FindBy(xpath = "(//*[@id='localDateChooser'])[1]")
	 WebElement DOB_TXT_CSS;

	@FindBy(id = "localDateChooser")
	WebElement DOB_TXT_ID;
	 
	@FindBy(css = "[model='address.addressLine1'] input, [label='Address Line 1'] input")
	 WebElement ADDLINE1_TXT_CSS;
	
	@FindBy(css = "[model='address.addressLine1'] span[class='gw-required-asterisk']")
	 WebElement ADDLINE1_ASTERISK_CSS;
	
	@FindBy(css = "label[for='AddressLine2'] span")
	 WebElement ADDLINE2_LBL_CSS;

	@FindBy(css = "[model='address.addressLine2'] input, [label='Address Line 2'] input")
	 WebElement ADDLINE2_TXT_CSS;

	@FindBy(css = "[model='address.addressLine3'] input, [label='Address Line 3'] input")
	 WebElement ADDLINE3_TXT_CSS;
	 
	@FindBy(css = "label[for='City'] span")
	 WebElement CITY_LBL_CSS;
	
	@FindBy(css = "[class*='gw-page-section-title']")
	 WebElement YOUR_INFO_HEADER_CSS;
	
	@FindBy(css = "[model='address.city'] span[class='gw-required-asterisk']")
	 WebElement CITY_ASTERISK_CSS;
	 
	String CITY_TXT_CSS= "[model='address.city'] input, [label='City'] input";

	@FindBy(css = "input.address_search_input")
	WebElement HOME_ADDRESS_INPUT;
	
	String ZIP_TXT_CSS= "[model='address.postalCode'] input";

	String STATE_TXT_CSS= "[model='address.state'] select";
	 
	@FindBy(css = "label[for='AddressLine1'] span")
	 WebElement ADDLINE1_LBL_CSS;
	 
	@FindBy(css = "label[for='PostalCode'] span")
	WebElement ZIP_LBL_CSS;

	@FindBy(css = "[model='address.postalCode'] div[ng-if] span")
	 WebElement ZIP_VALUE_XPATH;
	 
	@FindBy(css = "div[label='State'] span")
	 WebElement STATE_LBL_CSS;

	String STATE_VALUE_CSS = "div[model='address.state'] div[ng-if] span:not([class*='error'])";

	By ENTER_ADD_MANUALLY = By.cssSelector("[ng-click='$ctrl.toggleAddressMode()'], [ng-click='$ctrl.toggleAddressEntry()'], [ng-click='ctrl.toggleAddressEntry()']");
	By EXPANDED_ADD_SEARCH = By.cssSelector("gw-pl-find-address [disable-state='true']");

	@FindBy(css = "div[label='State'] select")
	 WebElement STATE_DROP_CSS;
	
	@FindBy(css = "[name='localDateChooser'] i")
	 WebElement DOB_BTN_CSS;

	By DBO_BUTTON_LEFT = By.cssSelector("[data-datetimepicker-config*='datepicker2'] [class='left']");

	By DBO_YEAR = By.className("year");

	By DBO_MONTH = By.className("month");

	By DBO_DAY = By.cssSelector("[data-datetimepicker-config*='datepicker2'] [class*='day']");

	By FIRST_NAME_LOCATOR = By.cssSelector("[label='First Name'] input");

	@FindBy(css = "[model*='.accountHolder.dateOfBirth'] span[class='gw-required-asterisk'], [label='Date of Birth'] span[class='gw-required-asterisk']")
	 WebElement DOB_ASTERISK_CSS;
	 
	@FindBy(css = "[model*='emailAddress1'] span[class='gw-required-asterisk'], [label*='Email Address'] span[class='gw-required-asterisk']")
	WebElement EMAIL_ASTERISK_CSS;
	
	@FindBy(css = "[model*='emailAddress1'] input, [label='Email Address'] input")
	WebElement  EMAIL_TXT_CSS;

	@FindBy(css = "[label='Email Address 2 (Extended)'] input")
	WebElement EMAIL_ADDRESS2_TXT_CSS;

	@FindBy(css = "[label='Email Address 2 Type (Extended)'] select")
	WebElement EMAIL_ADDRESS2_TYPE_DROPDOWN_CSS;

	@FindBy(css = "[label*='Coverage Start Date'] input[gw-test-platform-widgets-datetimepicker-date-dropdown-picker]")
	WebElement COVR_STARTDATE_TXT_CSS;
	
	@FindBy(css = "[model*='periodStartDate'] span[class='gw-required-asterisk'], [label*='Coverage Start Date'] span[class='gw-required-asterisk']")
	WebElement COV_ASTERISK_CSS;

	@FindBy(css = "[gw-test-quoteandbind-bop-views-bop-contact-details-orgtype] select")
	WebElement ORGANIZATIONTYPE_CSS;

	@FindBy(css = "[gw-test-quoteandbind-bop-views-bop-contact-details-orgtype] span[gw-test-platform-widgets-basicinputs-templates-input-ctrl-asterisk]")
	WebElement ORGTYPE_ASTERISK_CSS;

	String ORGANIZATIONTYPE_VALUE_CSS = "[gw-test-quoteandbind-bop-views-bop-contact-details-orgtype] span";

	By SMALLBUSINESSTYPE_CSS = By.cssSelector("[gw-test-quoteandbind-bop-view-bop-contact-details-small_business_type] select");

	@FindBy(css = "[model='submissionVM.baseData.periodStartDate']")
	WebElement GTP_REDIRECTION_START_DATE;

	@FindBy(css = "[model='submissionVM.lobData.businessOwners.smallBusinessType']")
	WebElement GTP_REDIRECTION_SMALL_BUSINESS_TYPE;

	@FindBy(css = "[model='submissionVM.lobData.businessOwners.accountOrgType']")
	WebElement GTP_REDIRECTION_ACCOUNT_ORGANIZATION_TYPE;

	@FindBy(css = "[gw-test-quoteandbind-bop-view-bop-contact-details-small_business_type] span[gw-test-platform-widgets-basicinputs-templates-input-ctrl-asterisk]")
	WebElement SMALLBUSINESS_ASTERISK_CSS;

	String SMALLBUSINESS_VALUE_CSS = "[gw-test-quoteandbind-bop-view-bop-contact-details-small_business_type] span";

	@FindBy(xpath = "//a[contains(text(),'Enter your address manually')]")
	WebElement ADDRESS_LINK;

	public YourInfoPage()
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public YourInfoPage(Object dataObj)
	{
		this.data = (HashMap<String, String>) dataObj;
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public QualificationPage goToQualificationPage() {
			this.goNext();
			return new Pagefactory().getQualificationPage();
	}
	
	public YourInfoPage goNext() {
		seleniumCommands.clickbyJS(EMAIL_ASTERISK_CSS);
		seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}
	
	// Set Methods

	public YourInfoPage withFirstName() {
		seleniumCommands.type(FIRSTNAME_TXT_CSS, data.get("FirstName"));
		return this;
	}
	
	public YourInfoPage withFirstName(String firstName) {
		seleniumCommands.type(FIRSTNAME_TXT_CSS, firstName);
		return this;
	}

	public YourInfoPage withLastName(String lastName) {
		seleniumCommands.type(LASTNAME_TXT_CSS, lastName);
		return this;
	}
	
	public YourInfoPage withLastName() {
		seleniumCommands.type(LASTNAME_TXT_CSS, data.get("LastName"));
		return this;
	}

	public YourInfoPage withCompanyName() {
		seleniumCommands.type(COMPANYNAME_TXT_CSS, data.get("CompanyName"));
		return this;
	}
	
	public YourInfoPage withDOB() {
		if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
			seleniumCommands.click(DOB_BTN_CSS);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.getElements(DBO_YEAR).get(1).click();
			seleniumCommands.getElements(DBO_MONTH).get(11).click();
			seleniumCommands.getElements(DBO_DAY).get(12).click();
		}
		else{
			seleniumCommands.type(DOB_TXT_ID, data.get("DOB"));
			seleniumCommands.click(DOB_BTN_CSS);
			data.put("DriverDOB", (data.get("DOB").startsWith("0")? data.get("DOB").substring(1) : data.get("DOB")));
			data.put("DOB", data.get("DriverDOB"));
		}
		return this;
	}
	
	public YourInfoPage withDOB(String dob) {
		DOB_TXT_CSS.clear();
		String browser = data.get("Browser");
		if(!(browser.equals("NEXUS5") || browser.equals("IPHONE6")))
		{
			YOURQUOTE_PAGE_HEADER_CSS.click();
		}
		if(ThreadLocalObject.getBrowserName().equalsIgnoreCase("IE")){
			seleniumCommands.typeByJS(DOB_TXT_CSS, dob);
		} else{
			seleniumCommands.type(DOB_TXT_CSS, dob);
		}
		return this;
	}
	

	public YourInfoPage withAddLine1() {
		seleniumCommands.type(ADDLINE1_TXT_CSS, data.get("AddressLine1"));
		return this;
	}

	public YourInfoPage withiNowAddLine1() {
		seleniumCommands.type(ADDLINE1_TXT_CSS, data.get("AddressLine1"));
		return this;
	}

	public YourInfoPage withAddLine1(String addressLine1) {
		seleniumCommands.type(ADDLINE1_TXT_CSS,addressLine1);
		return this;
	}

	public YourInfoPage withAddLine2() {
		if(ADDLINE2_TXT_CSS.getText().equals("")) {
			seleniumCommands.type(ADDLINE2_TXT_CSS, data.get("AddressLine2"));
		}
		return this;
	}

	public YourInfoPage withiNowAddLine2() {
		if(ADDLINE2_TXT_CSS.getText().equals("")) {
			seleniumCommands.type(ADDLINE2_TXT_CSS, data.get("AddressLine2"));
		}
		return this;
	}
	
	public YourInfoPage withAddLine2(String addressLine) {
		seleniumCommands.type(ADDLINE2_TXT_CSS,addressLine);
		return this;
	}
	
	public YourInfoPage withAddLine3() {
		if(ADDLINE3_TXT_CSS.getText().equals("")) {
			seleniumCommands.type(ADDLINE3_TXT_CSS, data.get("AddressLine3"));
		}
		return this;
	}

	public YourInfoPage withiNowAddLine3() {
		if(ADDLINE3_TXT_CSS.getText().equals("")) {
			seleniumCommands.type(ADDLINE3_TXT_CSS, data.get("AddressLine3"));
		}
		return this;
	}
	
	public YourInfoPage withAddLine3(String addressLine3) {
		seleniumCommands.type(ADDLINE3_TXT_CSS,addressLine3);
		return this;
	}

	public YourInfoPage withCity() {
		seleniumCommands.type(By.cssSelector(CITY_TXT_CSS),data.get("City"));
		return this;
	}

	public YourInfoPage removeCity() {
		if(seleniumCommands.isElementPresent(ENTER_ADD_MANUALLY)) {
			seleniumCommands.clickbyJS(ENTER_ADD_MANUALLY);
			seleniumCommands.type(By.cssSelector(CITY_TXT_CSS), "");
			seleniumCommands.staticWait(3);
		}
		return this;
	}

	public YourInfoPage withCity(String city) {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CITY_TXT_CSS));
		seleniumCommands.type(By.cssSelector(CITY_TXT_CSS), city);
		return this;
	}

	public YourInfoPage withState() {
		if(!seleniumCommands.isElementPresent(By.cssSelector(STATE_VALUE_CSS)))
			seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("State"));
		return this;
	}
	
	public YourInfoPage withState(String state) {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourInfoPageLocators.STATE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, state);
		return this;
	}

	public YourInfoPage withEmail() {
			seleniumCommands.type(EMAIL_TXT_CSS, data.get("Email"));
		return this;
	}

	public YourInfoPage withEmailAddress2AndType() {
		if (seleniumCommands.isElementPresent(EMAIL_ADDRESS2_TXT_CSS)) {
			seleniumCommands.type(EMAIL_ADDRESS2_TXT_CSS, data.get("Email_Address2"));
			seleniumCommands.selectDropDownValueByText(EMAIL_ADDRESS2_TYPE_DROPDOWN_CSS, data.get("Email_Address2_Type"));
		}
		return this;
	}


	public YourInfoPage withEmail(String email) {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourInfoPageLocators.EMAIL_TXT_CSS));
		seleniumCommands.type(By.cssSelector(YourInfoPageLocators.EMAIL_TXT_CSS), email);
		return this;
	}

	public YourInfoPage withCoverage() {

		seleniumCommands.type(COVR_STARTDATE_TXT_CSS, data.get("Quote_Cov_Date"));
		seleniumCommands.clickbyJS(YOUR_INFO_HEADER_CSS);

		if(!seleniumCommands.isElementPresent(COVR_STARTDATE_TXT_CSS)) {
			seleniumCommands.type(COVR_STARTDATE_TXT_CSS, data.get("Quote_Cov_Date"));
			seleniumCommands.clickbyJS(YOUR_INFO_HEADER_CSS);
		}
		return this;
	}

	public YourInfoPage withOrganizationType() {
		seleniumCommands.selectDropDownValueByText(ORGANIZATIONTYPE_CSS, data.get("OrganizationTypeQB"));
		return this;
	}

	public YourInfoPage withSmallBusinessType() {
		seleniumCommands.selectDropDownValueByText(SMALLBUSINESSTYPE_CSS, data.get("SmallBusinessTypeQB"));
		return this;
	}
	
	/**
	 * @param data as a Sting in the format of DD-MONTH-YYYY (12-August-2015)
	 * @return current page
	 */
	public YourInfoPage withCoverage(String data) {
		seleniumCommands.type(COVR_STARTDATE_TXT_CSS, data);
		seleniumCommands.clickbyJS(YOUR_INFO_HEADER_CSS);
		return this;
	}
	
	
	/**
	 * Set only Mandatory Details
	 * @return
	 */
	public YourInfoPage setYourInfoPageDetails() {
		seleniumCommands.staticWait(3);
		if(data.get("PolicyType").equals("PersonalAuto"))
		{

			this.withFirstName().withLastName();
			this.withDOB();
			this.setAddressManually();

		}

		if(data.get("PolicyType").equals("HomeOwner"))
		{
			if(!seleniumCommands.isElementPresent(FIRST_NAME_LOCATOR)){
				ThreadLocalObject.getData().put("FirstName", "0dummyname0");
				ThreadLocalObject.getData().put("LastName", "0dummyname0");
				this.setAddressManually();
			} else {
				this.withFirstName().withLastName();
				this.setAddressManually();
			}

		}

		if(data.get("PolicyType").equals("BusinessOwner"))
		{
			this.withCompanyName()
					.withOrganizationType()
					.withSmallBusinessType();
		}

		this.withEmail();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(CITY_TXT_CSS));
				this.withAddLine1()
				.withAddLine2()
				.withAddLine3()
				.withCity()
				.withState()
				.withCoverage();
		return this;
	}
	
	public YourInfoPage setAddressManually() {
		if(!seleniumCommands.isElementPresent(EXPANDED_ADD_SEARCH)){
			if(seleniumCommands.isElementPresent(ENTER_ADD_MANUALLY) &&
					seleniumCommands.getTextAtLocator(ENTER_ADD_MANUALLY).equalsIgnoreCase("Enter your address manually")) {
				seleniumCommands.clickbyJS(ENTER_ADD_MANUALLY);
			}
		}
		return this;
	}

	/**
	 * Set only Mandatory Details
	 * @return
	 */
	public YourInfoPage setYourInfoPageWithGoogleAddressSearchDetails() {
		if(data.get("PolicyType").equals("PersonalAuto"))
		{

			this.withFirstName().withLastName();
			this.withDOB();

		}

		if(data.get("PolicyType").equals("HomeOwner"))
		{
			this.withFirstName().withLastName();

		}

		if(data.get("PolicyType").equals("BusinessOwner"))
		{
			this.withCompanyName()
					.withOrganizationType()
					.withSmallBusinessType();
		}

		this.withEmail();
		this.withEmailAddress2AndType();

		seleniumCommands.waitForElementToBeVisible(HOME_ADDRESS_INPUT);
		seleniumCommands.type(HOME_ADDRESS_INPUT, "1060 Shoreline drive san mateo");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("div.pac-container>div.pac-item"));
		seleniumCommands.click(By.cssSelector("div.pac-container>div.pac-item"));
		seleniumCommands.waitForElementToDisappear(By.cssSelector("div.pac-container>div.pac-item"));
		seleniumCommands.click(HOME_ADDRESS_INPUT);
		data.replace("AddressLine1", "1060 Shoreline Drive");
		data.replace("AddressLine2", "East San Mateo");
		data.remove("AddressLine3");
		data.replace("City", "San Mateo");
		return this;
	}

	public Validation isAddressFieldsArePopulated(){
		//Click Enter address manually to expand address fields
		if(seleniumCommands.isElementPresent(ENTER_ADD_MANUALLY)) {
			seleniumCommands.clickbyJS(ENTER_ADD_MANUALLY);
		}
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CITY_TXT_CSS));
		int counter=0;
		while(counter < 5){
			if (getAddLine1().isEmpty()) {
				seleniumCommands.staticWait(2);
				counter++;
				seleniumCommands.logInfo("Waiting for form load: loop count :- " + counter);
			}else{
				break;
			}
		}

		isAddLine1EqualsTo().shouldBeEqual("Address Line1 didn't match with Google Address selected");
		isAddLine2EqualsTo().shouldBeEqual("Address Line2 didn't match with Google Address selected");
		isCityEqualsTo().shouldBeEqual("City didn't match with Google Address selected");
		isStateEqualsTo().shouldBeEqual("State didn't match with Google Address selected");
		isZipCodeEqualsTo().shouldBeEqual("Zip code didn't match with Google Address selected");
		return new Validation(true);
	}
	// Get Methods

	private String getFirstName() {
		return seleniumCommands.getValueAttributeFromLocator(FIRSTNAME_TXT_CSS);
	}

	private String getLastName() {
		return seleniumCommands.getValueAttributeFromLocator(LASTNAME_TXT_CSS);
	}

	private String getCompanyName() {
		return seleniumCommands.getValueAttributeFromLocator(COMPANYNAME_TXT_CSS);
	}
	
	private String getDOB() {
		return seleniumCommands.getValueAttributeFromLocator(DOB_TXT_CSS);
	}

	private String getAddLine1() {
		return seleniumCommands.getValueAttributeFromLocator(ADDLINE1_TXT_CSS);
	}

	private String getAddLine2() {
		return seleniumCommands.getValueAttributeFromLocator(ADDLINE2_TXT_CSS);
	}
	
	private String getAddLine3() {
		return seleniumCommands.getValueAttributeFromLocator(ADDLINE3_TXT_CSS);
	}


	private String getCity() {
		return seleniumCommands.getAttributeValueAtLocator(By.cssSelector(CITY_TXT_CSS), "value");
	}

	private String getState() {
		return seleniumCommands.getTextAtLocator(By.cssSelector(STATE_VALUE_CSS));
		//return seleniumCommands.getSelectedOptionFromDropDown(By.cssSelector(STATE_TXT_CSS));
	}

	private String getEmail() {
			return seleniumCommands.getValueAttributeFromLocator(EMAIL_TXT_CSS);
	}
	
	private String getZipCode() {
		return seleniumCommands.getTextAtLocator(ZIP_VALUE_XPATH);
	}

	private String getOrganizationType() {
		return seleniumCommands.getTextAtLocator(By.cssSelector(ORGANIZATIONTYPE_VALUE_CSS));
	}

	private String getSmallBusinessType() {
		return seleniumCommands.getTextAtLocator(By.cssSelector(SMALLBUSINESS_VALUE_CSS));
	}

	/**
	 * @return Date in the format of DD-MONTH-YYYY
	 */
	private String getCoverageStartDate() {
		return seleniumCommands.getValueAttributeFromLocator(COVR_STARTDATE_TXT_CSS);			
	}
	
	// Validation Methods
	
	public Validation isFirstNameEqualsTo(String firstName) {
		return new Validation(getFirstName(), firstName);
	}
	
	public Validation isFirstNameEqualsTo() {
		return new Validation(getFirstName(), data.get("FirstName"));
	}

	public Validation isLastNameEqualsTo(String lastName) {
		return new Validation(getLastName(), lastName);
	}
	
	public Validation isLastNameEqualsTo() {
		return new Validation(getLastName(), data.get("LastName"));
	}

	public Validation isCompanyNameEqualsTo(String companyName) {
		return new Validation(getCompanyName(), companyName);
	}

	public Validation isCompanyNameEqualsTo() {
		return new Validation(getCompanyName(), data.get("CompanyName"));
	}
	
	public Validation isDOBEqualsTo(String DOB) {
		return new Validation(getDOB(), DOB);
	}
	
	public Validation isDOBEqualsTo() {
		return new Validation(getDOB(), data.get("DOB"));
	}

	public Validation isAddLine1EqualsTo(String addLine1) {
		return new Validation(getAddLine1(), addLine1);
	}
	
	public Validation isAddLine1EqualsTo() {
		return new Validation(getAddLine1(), data.get("AddressLine1"));
	}

	public Validation isAddLine2EqualsTo(String addLine2) {
		return new Validation(getAddLine2(), addLine2);
	}
	
	public Validation isAddLine2EqualsTo() {
		return new Validation(getAddLine2(), data.get("AddressLine2"));
	}
	
	public Validation isAddLine3EqualsTo(String addLine3) {
		return new Validation(getAddLine3(), addLine3);
	}
	
	public Validation isAddLine3EqualsTo() {
		return new Validation(getAddLine3(), data.get("AddressLine3"));
	}

	public Validation isCityEqualsTo(String city) {
		return new Validation(getCity(), city);
	}
	
	public Validation isCityEqualsTo() {
		return new Validation(getCity(), data.get("City"));
	}

	public Validation isStateEqualsTo(String state) {
		return new Validation(getState(), state);
	}

	public Validation isStateEqualsTo() {
		return new Validation(getState(), data.get("State"));
	}
	public Validation isOrganizationTypeEqualsTo() {
		return new Validation(getOrganizationType(), data.get("OrganizationType"));
	}

	public Validation isSmallBusinessTypeTypeEqualsTo() {
		return new Validation(getOrganizationType(), data.get("SmallBusinessType"));
	}

	public Validation isEmailEqualsTo(String email) {
		return new Validation(getEmail(), email);
	}
	
	public Validation isEmailEqualsTo() {
		return new Validation(getEmail(), data.get("Email"));
	}
	
	public Validation isZipCodeEqualsTo() {
		return new Validation(getZipCode(), data.get("ZipCode"));
	}
	
	public Validation isZipCodeEqualsTo(String zipCode) {
		return new Validation(getZipCode(), zipCode);
	}

	/**
	 * @param coverageDate should be in the format of DD-MONTH-YYYY
	 * @return Validation object
	 */
	public Validation isCoverageEqualsTo(String coverageDate) {
		return new Validation(getCoverageStartDate(), coverageDate);
	}
	
	public Validation isCoverageEqualsTo() {
		return new Validation(getCoverageStartDate(), data.get("Quote_Cov_Date"));
	}
	
	public void isFirstNameFieldMandatory() {
		new Validation(seleniumCommands.getErrorMessageForTxtBox(FIRSTNAME_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG)).shouldBeTrue("FirstName is not marked with Mandatory error.");
	}
	
	public Validation isCoverageDateFutureErrorPresent() {
		System.out.println(seleniumCommands.getErrorMessageForDatePicker(COVR_STARTDATE_TXT_CSS));
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(COVR_STARTDATE_TXT_CSS), DataConstant.DATE_FUTURE_ERROR);
	}
	
	public Validation isYourInfoPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(COVR_STARTDATE_TXT_CSS);
		return new Validation(seleniumCommands.isElementPresent(COVR_STARTDATE_TXT_CSS));
	}

		public Validation areYourPageFieldsMakedWithMandatoryError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error foe the fields the Quote");
			 if(data.get("PolicyType").equalsIgnoreCase("PersonalAuto"))
			 {
				 new Validation(isDOBFieldMakedWithError()).shouldBeTrue("DOB is not marked with Error");
				 new Validation(isFirstNameFieldMakedWithError()).shouldBeTrue("FirstName is not marked with Error");
				 new Validation(isLastNameFieldMakedWithError()).shouldBeTrue("LastName is not marked with Error");
			 }
			if(data.get("PolicyType").equalsIgnoreCase("HomeOwner"))
			{ if(seleniumCommands.isElementPresent(FIRST_NAME_LOCATOR)) {
					new Validation(isFirstNameFieldMakedWithError()).shouldBeTrue("FirstName is not marked with Error");
					new Validation(isLastNameFieldMakedWithError()).shouldBeTrue("LastName is not marked with Error");
				}
			}

			if(data.get("PolicyType").equalsIgnoreCase("BusinessOwner"))
			{
				new Validation(isCompanyNameFieldMarkedWithError()).shouldBeTrue("FirstName is not marked with Error");
			}
		
			 new Validation(isAddressLine1FieldMakedWithError()).shouldBeTrue("Address 1 is not marked with Error");
			 new Validation(isCityFieldMakedWithError()).shouldBeTrue("City is not marked with Error");
			 //new Validation(isStateFieldMakedWithError()).shouldBeTrue("State is not marked with Error");
			 new Validation(isEmailFieldMakedWithError()).shouldBeTrue("Email is not marked with Error");
			 
			return new Validation(true);
		}

	public Validation areiNowDefaultYourPageFieldsMakedWithMandatoryError() {
		seleniumCommands.logInfo( "Validating the Mandatory Error foe the fields the Quote");
		if(seleniumCommands.isElementPresent(ENTER_ADD_MANUALLY)) {
			seleniumCommands.clickbyJS(ENTER_ADD_MANUALLY);
		}
		if(data.get("PolicyType").equalsIgnoreCase("PersonalAuto"))
		{
			new Validation(isDOBFieldMakedWithError()).shouldBeTrue("DOB is not marked with Error");
			new Validation(isFirstNameFieldMakedWithError()).shouldBeTrue("FirstName is not marked with Error");
			new Validation(isLastNameFieldMakedWithError()).shouldBeTrue("LastName is not marked with Error");
		}
		if(data.get("PolicyType").equalsIgnoreCase("HomeOwner"))
		{
			new Validation(isFirstNameFieldMakedWithError()).shouldBeTrue("FirstName is not marked with Error");
			new Validation(isLastNameFieldMakedWithError()).shouldBeTrue("LastName is not marked with Error");
		}

		if(data.get("PolicyType").equalsIgnoreCase("BusinessOwner"))
		{
			new Validation(isCompanyNameFieldMarkedWithError()).shouldBeTrue("FirstName is not marked with Error");
		}
		new Validation(isAddressLine1FieldMakedWithError()).shouldBeTrue("Address 1 is not marked with Error");
		new Validation(isEmailFieldMakedWithError()).shouldBeTrue("Email is not marked with Error");

		return new Validation(true);
	}

	public Validation areYourPageFieldsMakedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Mandatory Error foe the fields the Quote");

			 if(data.get("PolicyType").equalsIgnoreCase("PersonalAuto"))
			 {
				 new Validation(isDOBFieldMakedWithAsterisk()).shouldBeTrue("DOB is not marked with Asterisk");
				 new Validation(isFirstNameFieldMakedWithAsterisk()).shouldBeTrue("FirstName is not marked with Asterisk");
				 new Validation(isLastNameFieldMakedWithAsterisk()).shouldBeTrue("LastName is not marked with Asterisk");
			 }

			if(data.get("PolicyType").equalsIgnoreCase("HomeOwner"))
			{
			    if(seleniumCommands.isElementPresent(FIRST_NAME_LOCATOR)) {
					new Validation(isFirstNameFieldMakedWithAsterisk()).shouldBeTrue("FirstName is not marked with Asterisk");
					new Validation(isLastNameFieldMakedWithAsterisk()).shouldBeTrue("LastName is not marked with Asterisk");
				}
			}

			if(data.get("PolicyType").equals("BusinessOwner"))
			{
				this.withCompanyName()
						.withOrganizationType()
						.withSmallBusinessType();

			}
			 new Validation(isAddressLine1FieldMakedWithAsterisk()).shouldBeTrue("Address 1 is not marked with Asterisk");
			 new Validation(isCityFieldMakedWithAsterisk()).shouldBeTrue("City is not marked with Asterisk");
			 //new Validation(isStateFieldMakedWithError()).shouldBeTrue("State is not marked with Asterisk");
			 new Validation(isEmailFieldMakedWithAsterisk()).shouldBeTrue("Email is not marked with Asterisk");
			 new Validation(isCoverageDateFieldMakedWithAsterisk()).shouldBeTrue("Cov date is not marked with Asterisk");
			return new Validation(true);
		}

	public Validation areINowDefaultYourPageFieldsMakedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Mandatory Error foe the fields the Quote");

		if(data.get("PolicyType").equalsIgnoreCase("PersonalAuto"))
		{
			new Validation(isDOBFieldMakedWithAsterisk()).shouldBeTrue("DOB is not marked with Asterisk");
			new Validation(isFirstNameFieldMakedWithAsterisk()).shouldBeTrue("FirstName is not marked with Asterisk");
			new Validation(isLastNameFieldMakedWithAsterisk()).shouldBeTrue("LastName is not marked with Asterisk");
		}

		if(data.get("PolicyType").equalsIgnoreCase("HomeOwner"))
		{
			new Validation(isFirstNameFieldMakedWithAsterisk()).shouldBeTrue("FirstName is not marked with Asterisk");
			new Validation(isLastNameFieldMakedWithAsterisk()).shouldBeTrue("LastName is not marked with Asterisk");
		}

		if(data.get("PolicyType").equals("BusinessOwner"))
		{
			this.withCompanyName()
					.withOrganizationType()
					.withSmallBusinessType();

		}
		new Validation(isAddressLine1FieldMakedWithAsterisk()).shouldBeTrue("Address 1 is not marked with Asterisk");
		new Validation(isEmailFieldMakedWithAsterisk()).shouldBeTrue("Email is not marked with Asterisk");
		new Validation(isCoverageDateFieldMakedWithAsterisk()).shouldBeTrue("Cov date is not marked with Asterisk");
		return new Validation(true);
	}

	public boolean isFirstNameFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for First Name Field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(FIRSTNAME_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("FirstName is marked with Error " + value);
			return value;
		}
		
		public boolean isFirstNameFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for First Name Field");
			return seleniumCommands.isElementPresent(FIRSTNAME_ASTERISK_CSS);
		}
		
		public boolean isLastNameFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error Last Name field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(LASTNAME_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("LastName is marked with Error " + value);
			return value;
		}
		
		public boolean isLastNameFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for Last Name field");
			return seleniumCommands.isElementPresent(LASTNAME_ASTERISK_CSS);
		}

	public boolean isCompanyNameFieldMarkedWithError() {
		seleniumCommands.logInfo( "Validating the Mandatory Error Company Name field");
		boolean value = seleniumCommands.getErrorMessageForTxtBox(COMPANYNAME_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
		seleniumCommands.logInfo("CompanyName is marked with Error " + value);
		return value;
	}

	public boolean isCompanyNameFieldMarkedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Asterix for Copmany Name field");
		return seleniumCommands.isElementPresent(COMPANYNAME_ASTERISK_CSS);
	}


		public boolean isDOBFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for DOB field");
			boolean value = seleniumCommands.getErrorMessageForDatePicker(DOB_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("DOB is marked with Error " + value);
			return value;
		}
		
		public boolean isDOBFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for DOB field");
			return seleniumCommands.isElementPresent(DOB_ASTERISK_CSS);
		}
		
		public boolean isAddressLine1FieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for Address Line 1 field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(ADDLINE1_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("Error for Address Line 1 is marked with Error " + value);
			return value;
		}
		
		public boolean isAddressLine1FieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for  Address Line 1 field");
			return seleniumCommands.isElementPresent(ADDLINE1_ASTERISK_CSS);
		}
		
		public boolean isCityFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for City field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(ThreadLocalObject.getDriver().findElement(By.cssSelector(CITY_TXT_CSS))).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("City is marked with Error " + value);
			return value;
		}
		
		public boolean isCityFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for City field");
			return seleniumCommands.isElementPresent(CITY_ASTERISK_CSS);
		}
		
		public boolean isStateFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for State field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(STATE_DROP_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("State is marked with Error " + value);
			return value;
		}
		
		public boolean isStateFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for State field");
			boolean value = seleniumCommands.checkAstrickForFields(STATE_LBL_CSS);
			seleniumCommands.logInfo(" State is marked with Asterisk " + value);
			return value;
		}
		
		public boolean isEmailFieldMakedWithError() {
			seleniumCommands.logInfo( "Validating the Mandatory Error for Email field");
			boolean value = seleniumCommands.getErrorMessageForTxtBox(EMAIL_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
			seleniumCommands.logInfo("Email is marked with Error " + value);
			return value;
		}

		public Validation isEmailFieldMarkedWithFormatError() {
			seleniumCommands.logInfo( "Validating the Format Error for Email Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(EMAIL_TXT_CSS), DataConstant.EMAIL_FORMAT_ERROR);
	    }

		public boolean isEmailFieldMakedWithAsterisk() {
			seleniumCommands.logInfo( "Validating the Asterick for Email field");
			return seleniumCommands.isElementPresent(EMAIL_ASTERISK_CSS);
		}
		
		public boolean isCoverageDateFieldMakedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Asterick for Coverage field");
		return seleniumCommands.isElementPresent(COV_ASTERISK_CSS);
	}
	public boolean isOrganizationTypeFieldMarkedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Asteriks for Organization Type field");
		return seleniumCommands.isElementPresent(ORGTYPE_ASTERISK_CSS);
	}

	public boolean isSmallBusinessTypeFieldMarkedWithAsterisk() {
		seleniumCommands.logInfo( "Validating the Asteriks for Small Business Type field");
		return seleniumCommands.isElementPresent(SMALLBUSINESS_ASTERISK_CSS);
	}
		
	    public Validation areYourInfoPageDetailsSaved() {
			if(seleniumCommands.isElementPresent(FIRST_NAME_LOCATOR)) {
				this.isFirstNameEqualsTo().shouldBeEqual("First Name is not correct");
				this.isLastNameEqualsTo().shouldBeEqual("Last Name is not correct");
				if (data.get("PolicyType").equals("PersonalAuto")) {
					this.isDOBEqualsTo().shouldBeEqual("DOB is not correct");
				}
			}
			this.isAddLine1EqualsTo().shouldBeEqual("Add line1 is not correct");
			this.isCityEqualsTo().shouldBeEqual("City is not correct");
			this.isZipCodeEqualsTo().shouldBeEqual("Zip Code is not correct");
			this.isStateEqualsTo().shouldBeEqual("State is not correct");
			this.isEmailEqualsTo().shouldBeEqual("Email is not correct");
			this.isCoverageEqualsTo().shouldBeEqual("Coverage Date is not correct");
			return new Validation(true);
		}
	    
	    public void validateQuickQuoteDataPreFilledOnYourInfoPage() {
			this.isAddLine1EqualsTo().shouldBeEqual("Add line1 is not correct");
			this.isCityEqualsTo().shouldBeEqual("City is not correct");
			this.isZipCodeEqualsTo().shouldBeEqual("Zip Code is not correct");
			this.isStateEqualsTo().shouldBeEqual("State is not correct");
			this.isEmailEqualsTo().shouldBeEqual("Email is not correct");
		}


	public void validateGTPRedirectionComponents() {
		new Validation(seleniumCommands.isElementPresent(GTP_REDIRECTION_START_DATE)).shouldBeTrue("Start date field is not present");
		new Validation(seleniumCommands.isElementPresent(GTP_REDIRECTION_ACCOUNT_ORGANIZATION_TYPE)).shouldBeTrue("Account organization type field is not present");
		new Validation(seleniumCommands.isElementPresent(GTP_REDIRECTION_SMALL_BUSINESS_TYPE)).shouldBeTrue("Small Busines Type field is not present");

	}

	public void validatePrefilledDataFrom() {
		String addressLine1 = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(",")[0];
		String city = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[1];
		String zip = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[3];

		isAddLine1EqualsTo(addressLine1).shouldBeEqual("Address line 1 is not prefilled or value is incorrect");
		isZipCodeEqualsTo(zip).shouldBeEqual("Zip is not prefilled or value is incorrect");
		isStateEqualsTo().shouldBeEqual("State is not prefilled or value is incorrect");
		isCityEqualsTo(city).shouldBeEqual("City is not prefilled or value is incorrect");
	}

	public void validatePrefilledDataFrom(String addressLine1,String addressLine2,String addressLine3, String city, String zip) {

		isAddLine1EqualsTo(addressLine1).shouldBeEqual("Address line 1 is not prefilled or value is incorrect");
		isAddLine2EqualsTo(addressLine2).shouldBeEqual("Address line 2 is not prefilled or value is incorrect");
		isAddLine3EqualsTo(addressLine3).shouldBeEqual("Address line 3 is not prefilled or value is incorrect");
		isZipCodeEqualsTo(zip).shouldBeEqual("Zip is not prefilled or value is incorrect");
		isStateEqualsTo().shouldBeEqual("State is not prefilled or value is incorrect");
		isCityEqualsTo(city).shouldBeEqual("City is not prefilled or value is incorrect");
	}

		public Validation areYourInfoPageDataMatchingWithBackEnd() throws Exception
		{
			return MapCompare.compareMap
					(data, ParseQuoteData.getPersonalInfoFromBackEnd
								(DataFetch.getQuoteData
										(ThreadLocalObject.getData().get("ZipCode"),
												new QuoteInfoBar().getSubmissionNumber())));
		}
		
		public Validation areYourInfoPageDataMatchingWithBackEnd(String jsonData) throws Exception
		{
			return MapCompare.compareMap(data, ParseQuoteData.getPersonalInfoFromBackEnd(jsonData));
		}
}
