package com.guidewire.portals.qnb.pages.QuickQuoteComponent;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.portals.qnb.pages.CommonPage;
import com.guidewire.portals.qnb.pages.YourInfoPage;

/**
 * @author  jkrawczyk-koca
 */
public class QuickQuoteSection extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    HashMap<String, String> uiData = new HashMap<>();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[ng-click='quote()']")
    WebElement QUOTE_CSS;

    @FindBy(css = "[gw-pa-quick-quote-quote-error-state]")
    WebElement QUOTE_ERR_MSG;

    @FindBy(css = "button[ng-click='model.onNext()']")
    WebElement SAVE_QUOTE_BTN_CSS;

    @FindBy(css = "button[ng-click='model.onRevise()']")
    WebElement EDIT_QUOTE_BTN_CSS;

    @FindBy(css = "button[ng-click='emailQuote()']")
    WebElement EMAIL_QUOTE_BTN_CSS;
    
    @FindBy(css = "button[ng-click='emailQuote()'][disabled='disabled']")
    WebElement DISABLED_EMAIL_QUOTE_BTN_CSS;
    
    @FindBy(css = "[ng-model='quoteEmailVM.emailAddress1.value']")
    WebElement EMAIL_TXT_CSS;

    @FindBy(css = "[class*='gwPaQuickQuoteEstimatedCost'] strong[class*='ng-binding']")
    WebElement PREMIUM_12MONTHS_LABEL_CSS;

    @FindBy(css = "[class*='gwPaQuickQuoteEstimateMonthlyCost']")
    WebElement PREMIUM_1MONTH_LABEL_CSS;

    @FindBy(css = "[gw-displaykey-format-replaces*='estimateNumber']")
    WebElement REFERENCE_LABEL_CSS;

    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state='0'] [class*='complete']")
    WebElement VEHICLES_COMPLETE_CSS;

    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state='1'] [class*='complete']")
    WebElement ADDRESS_COMPLETE_CSS;

    @FindBy(css = "[ng-repeat*='complete']:nth-of-type(3) p[class*='complete']")
    WebElement DRIVERS_COMPLETE_CSS;
    
    By QUOTE_BTN_CSS = By.cssSelector("[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state-quote-button][class*='complete']");
    
    public QuickQuoteSection()
    {
        seleniumCommands.pageWebElementLoader(this);
    }
    //Set Methods

    public QuickQuoteSection quote() {
        seleniumCommands.logInfo( "Quoting ");
        seleniumCommands.click(QUOTE_CSS);
        return this;
    }


    public String getQuoteErrorMSG(){
        seleniumCommands.logInfo( "Get Quote Error Message ");
        return seleniumCommands.getTextAtLocator(QUOTE_ERR_MSG);
    }

    public YourInfoPage submitQuote() {
        seleniumCommands.logInfo( "Submitting Quote ");
        seleniumCommands.clickbyJS(SAVE_QUOTE_BTN_CSS);
        return new YourInfoPage();
    }

    public QuickQuoteSection editQuote() {
        seleniumCommands.logInfo( "Editing Quote ");
        seleniumCommands.clickbyJS(EDIT_QUOTE_BTN_CSS);
        return this;
    }

    public QuickQuoteSection emailQuote() {
        seleniumCommands.logInfo( "Emailing Quote ");
        seleniumCommands.staticWait(2);
        seleniumCommands.clickbyJS(EMAIL_QUOTE_BTN_CSS);
        new AlertHandler().closeAlert();
        return this;
    }
    
    public QuickQuoteSection setEmail(String email) {
        seleniumCommands.logInfo( "Setting email ");
        seleniumCommands.type(EMAIL_TXT_CSS, email);
        return this;
    }
    
    public QuickQuoteSection setEmail() {
        seleniumCommands.logInfo( "Setting email ");
        seleniumCommands.type(EMAIL_TXT_CSS, data.get("Email"));
        return this;
    }

    //Get Methods

    private String getPremiumFor12Months()
    {
        seleniumCommands.logInfo( "Getting Premium for 12 Months ");
        return seleniumCommands.getTextAtLocator(PREMIUM_12MONTHS_LABEL_CSS).split(" ")[0].substring(1);
    }

    private String getPremiumFor1Month()
    {
        seleniumCommands.logInfo( "Getting Premium for 1 Month ");
        return seleniumCommands.getTextAtLocator(PREMIUM_1MONTH_LABEL_CSS).split(" ")[0].substring(1);
    }

    private String getReference()
    {
        seleniumCommands.logInfo( "Getting Reference ");
        return seleniumCommands.getTextAtLocator(REFERENCE_LABEL_CSS);
    }

    // Validation

    public void validateQuoteDataRetrived() throws Exception {
        seleniumCommands.logInfo( "Validating the quote data ");
        HashMap<String, String> quoteData = ParseQuoteData.getQuickQuoteDataFromBackEnd(DataFetch.getQuoteData(data.get("ZipCode"), getReference()));
        data.put("ANNUAL_AMOUNT_AFTER_TAX_VALUE", getPremiumFor12Months());
        data.put("MONTHLY_AMOUNT_AFTER_TAX_VALUE", getPremiumFor1Month());
        MapCompare.compareMap(data, quoteData);
    }

    public void isVehicleSectionComplete() {
        seleniumCommands.logInfo( "Validating if Vehicle Section is complete ");
        seleniumCommands.waitForElementToBeVisible(VEHICLES_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(VEHICLES_COMPLETE_CSS)).shouldBeTrue("Vehicle data was not completed");
    }

    public void isAddressSectionComplete() {
        seleniumCommands.logInfo( "Validating if Address Section is Complete ");
        seleniumCommands.waitForElementToBeVisible(ADDRESS_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(ADDRESS_COMPLETE_CSS)).shouldBeTrue("Address data was not completed");
    }

    public void isDriverSectionComplete() {
        logger.info( "Validating if Driver Section is Complete ");
        seleniumCommands.waitForElementToBeVisible(DRIVERS_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(DRIVERS_COMPLETE_CSS)).shouldBeTrue("Driver's data was not retrived");
    }
    
    public Validation isQuoteButtonEnabled() {
        logger.info( "Validating if Quote button is enabled ");
        return new Validation(seleniumCommands.isElementPresent(EMAIL_QUOTE_BTN_CSS));
    }
    
    public void validateIncorrectEmailFormat(String email) {
        logger.info( "Validating if email value is correct ");
        seleniumCommands.type(EMAIL_TXT_CSS, email);
        new Validation(seleniumCommands.isElementPresent(DISABLED_EMAIL_QUOTE_BTN_CSS)).shouldBeTrue("Email quote button is disabled");
    }
    
    public void validateCorrectEmailFormat(String email) {
        logger.info( "Validating if email value is correct ");
        seleniumCommands.type(EMAIL_TXT_CSS, email);
        new Validation(seleniumCommands.isElementPresent(EMAIL_QUOTE_BTN_CSS)).shouldBeTrue("Email quote button is disabled");
    }
    
    public void validateUWIssue(String uwIssue) {
        logger.info( "Validating UW issues for quote");
        Map<String, String> uwIssues = ParseQuoteData.getQuoteUWIssuesDataFromBackEnd(DataFetch.getQuoteUWIssues(getReference()));
		new Validation(uwIssues.containsKey(uwIssue)).shouldBeTrue("Primary Driver under 25 UW issue is not present in the list");
    }
}
