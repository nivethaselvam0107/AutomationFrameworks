package com.guidewire.portals.qnb.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class QuoteRetrivalPage extends CommonPage {

	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	 @FindBy(css = "[ng-click='activateItemRetrieval()']")
	 WebElement RETRIVE_LINK_CSS ;
	 
	 @FindBy(css = "[model='postalCode'] input")
	 WebElement ZIPCODE_RETRIVE_TXT_CSS;
	 
	 @FindBy(css = "[model='quoteId'] input")
	 WebElement QUOTEID_RETRIVE_TXT_CSS;
	 
	 @FindBy(css = "[on-click*='startRetrieveQuote']")
	 WebElement CONTINUE_BTN_CSS ;
	 
	 @FindBy(css = "[on-click='deActivateRetrieveState()'][aria-disabled='false']")
	 WebElement CANCEL_BTN_CSS ;

	@FindBy(css = "[href='#paquickQuote']")
	WebElement QUICK_QUOTE_LINK_CSS;

	//Retrieve
	public QuoteRetrivalPage setZipCodeRetrive(String zip) {
		logger.info("Retriving the Quote for Zip : " + zip);
		seleniumCommands.type(ZIPCODE_RETRIVE_TXT_CSS, zip);
		return this;
	}

	public QuoteRetrivalPage setZipCodeRetrive() {
		logger.info("Retriving the Quote for Zip : " + data.get("ZipCode"));
		seleniumCommands.type(ZIPCODE_RETRIVE_TXT_CSS, data.get("ZipCode"));
		return this;
	}

	public QuoteRetrivalPage setQuoteReference(String referenceNumber) {
		logger.info("Retriving the Quote for Ref Number  : " + referenceNumber);
		seleniumCommands.type(QUOTEID_RETRIVE_TXT_CSS, referenceNumber);
		return this;
	}

	public QuoteRetrivalPage setQuoteReference() {
		logger.info("Retriving the Quote for Ref Number  : " + data.get("QuoteReferenceNumber"));
		seleniumCommands.type(QUOTEID_RETRIVE_TXT_CSS, data.get("QuoteReferenceNumber"));
		return this;
	}

	public QuoteRetrivalPage setQuoteRetrivalDetails() {
		logger.info("Setting Quote retrival details");
		this.setZipCodeRetrive().setQuoteReference();
		return this;
	}
	
	public QuoteRetrivalPage setQuoteRetrivalDetails(String refNum) {
		logger.info("Setting Quote retrival details");
		this.setZipCodeRetrive().setQuoteReference(refNum);
		return this;
	}
	
	public QuoteRetrivalPage retriveQuote() {
		logger.info("Clicking on continue button");
		seleniumCommands.clickbyJS(CONTINUE_BTN_CSS);
		return this;
	}

	public PAQuotePage getQuotePage() {
		logger.info("Going to the Quote Page");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("gw-qnb-multiple-offering-view[quote-data]"));
		return new PAQuotePage();
	}
	
	//Validation
	
	
}
