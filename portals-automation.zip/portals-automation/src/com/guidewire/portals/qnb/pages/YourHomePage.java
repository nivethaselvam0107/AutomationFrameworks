package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.ConstructionPageLocators;
import com.guidewire.portals.qnb.locators.YourHomePageLocators;
import com.guidewire.widgetcomponents.form.BinaryToggler;

public class YourHomePage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	@FindBy(css = "h2")
	WebElement YOURHOME_PAGE_HEADER_CSS;

	@FindBy(css = "div[validation-form='detailsForm'] h3")
	WebElement HOMEVALUE_LBL_CSS;

	@FindBy(css = "[model='view.replacementCost'] input, [label='Estimated Value of Home'] input")
	WebElement HOMEVALUE_TXT_CSS;
	
	@FindBy(css = "label[for='DwellingLocation'] span")
	WebElement LOCTYPE_LBL_CSS;

	@FindBy(css = "[model='view.dwellingLocation'] select, [label='Location Type'] select")
	WebElement LOCTYPE_DROP_CSS;
	
	@FindBy(css = "label[for='ResidenceType'] span")
	WebElement RESIDENCETYPE_LBL_CSS;

	@FindBy(css = "[model='view.residenceType'] select, [label='Residence Type'] select")
	WebElement RESIDENCETYPE_DROP_CSS;

	@FindBy(css = "[model='view.distanceToFireHydrant'] span")
	WebElement DIST_TO_FIREHYD_LBL_CSS;
	
	@FindBy(css = "label[title='Within 500ft']")
	WebElement WITHIN500FT_RBTN_CSS;

	@FindBy(css = "label[title='Over 500ft']")
	WebElement OVER500FT_RBTN_CSS;
	
	@FindBy(css = "div[title1='Within 500ft'] input:nth-of-type(1)")
	WebElement WITHIN500FT_BTN_VALUE_CSS;
	
	@FindBy(css = "div[title1='Within 500ft'] input:nth-of-type(2)")
	WebElement OVER500FT_BTN_VALUE_CSS;

	@FindBy(css = "[model='view.distanceToFireStation'] span")
	WebElement DIST_TO_FIRESTN_LBL_CSS;
	
	@FindBy(css = "label[title='Within 5 miles']")
	WebElement WITHIN5MILES_RBTN_CSS;

	@FindBy(css = "label[title='Over 5 Miles']")
	WebElement OVER5MILES_RBTN_CSS;
	
	@FindBy(css = "div[title1='Within 5 miles'] input:nth-of-type(1)")
	WebElement WITHIN5MILES_BTN_VALUE_CSS;
	
	@FindBy(css = "div[title1='Within 5 miles'] input:nth-of-type(2)")
	WebElement OVER5MILES_BTN_VALUE_CSS;

	@FindBy(css = "[model='view.nearCommercial'] span")
	WebElement NEAR_COMMRPROP_LBL_CSS;
	
	@FindBy(css = "[model='view.nearCommercial'] label.gw-first, [label='Within 300ft of Commercial Property'] label.gw-first")
	WebElement NEAR_COMMRPROP_RBTN_YES_CSS;

	@FindBy(css = "[model='view.nearCommercial'] label.gw-second, [label='Within 300ft of Commercial Property'] label.gw-second")
	WebElement NEAR_COMMRPROP_RBTN_NO_CSS;
	
	@FindBy(css = "div[model='view.nearCommercial'] input:nth-of-type(1), [label='Within 300ft of Commercial Property'] input:nth-of-type(1)")
	WebElement  NEAR_COMMRPROP_BTN__YES_VALUE_CSS;
	
	@FindBy(css = "div[model='view.nearCommercial'] input:nth-of-type(2), [label='Within 300ft of Commercial Property'] input:nth-of-type(2)")
	WebElement NEAR_COMMRPROP_BTN__NO_VALUE_CSS;
	
	@FindBy(css = "[model='view.floodingOrFireHazard'] span")
	WebElement FLOODORFIRE_LBL_CSS;
	
	@FindBy(css = "[model='view.floodingOrFireHazard'] label.gw-first, [label='Flooding or Fire Hazard'] label.gw-first")
	WebElement FLOODORFIRE_RBTN_YES_CSS;
	
	@FindBy(css = "[model='view.floodingOrFireHazard'] label.gw-second, [label='Flooding or Fire Hazard'] label.gw-second")
	WebElement FLOODORFIRE_RBTN_NO_CSS;
	
	@FindBy(css = "[model='view.floodingOrFireHazard'] input:nth-of-type(1), [label='Flooding or Fire Hazard'] input:nth-of-type(1)")
	WebElement FLOODORFIRE_RBTN_VALUE_YES_CSS;
	
	@FindBy(css = "[model='view.floodingOrFireHazard'] input:nth-of-type(2), [label='Flooding or Fire Hazard'], input:nth-of-type(2)")
	WebElement FLOODORFIRE_RBTN_VALUE_NO_CSS;

	@FindBy(css = "[model='view.dwellingUsage'] span")
	WebElement HOME_USAGE_LBL_CSS;

	@FindBy(css = "[model='view.dwellingUsage'] select, [label='Home Type'] select")
	WebElement HOME_USAGE_DROP_CSS;
	
	@FindBy(css = "[model='view.occupancy'] span")
	WebElement HOME_OCCUPANCY_LBL_CSS;

	@FindBy(css = "[model='view.occupancy'] select, [label='Specify who occupies the home'] select")
	WebElement HOME_OCCUPANCY_DROP_CSS;
	
//	String HOME_VALUE_MODEL = "view.replacementCost";
//	String LOC_TYPE_VALUE_MODEL = "view.dwellingLocation";
//	String RES_TYPE_VALUE_MODEL = "view.residenceType";
//	String DIST_TO_FIREHYDRANT_VALUE_MODEL = "view.distanceToFireHydrant";
//	String DIST_TO_FIRESTATION_VALUE_MODEL = "view.distanceToFireStation";
//	String WITHN_COM_PROP_VALUE_MODEL = "view.nearCommercial";
//	String FLOOD_HAZARD_VALUE_MODEL = "view.floodingOrFireHazard";
//	String HOME_USAGE_MODEL = "view.dwellingUsage";
//	String HOME_OCUPANCY_MODEL = "view.occupancy";
	
	String HOME_VALUE_MODEL = "Estimated Value of Home";
	String LOC_TYPE_VALUE_MODEL = "Location Type";
	String RES_TYPE_VALUE_MODEL = "Residence Type";
	String DIST_TO_FIREHYDRANT_VALUE_MODEL = "Distance to Fire Hydrant";
	String DIST_TO_FIRESTATION_VALUE_MODEL = "Distance to Fire Station";
	String WITHN_COM_PROP_VALUE_MODEL = "Within 300ft of Commercial Property";
	String FLOOD_HAZARD_VALUE_MODEL = "Flooding or Fire Hazard";
	String HOME_USAGE_MODEL = "Home Type";
	String HOME_OCUPANCY_MODEL = "Specify who occupies the home";
	String INOW_SQUARE_FOOTAGE_MODEL = "What is square footage? (#)";
	String INOW_OCCUPANCY_CODE_MODEL = "Occupancy Code";
	String INOW_PROTECTION_CLASS_MODEL = "Protection Class";
	String INOW_TERRITORY_CODE_MODEL = "Territory Code";

	// iNow locators
	@FindBy(css = "[label='What is square footage? (#)'] input")
	WebElement INOW_SQUARE_FOOTAGE_INPUT;

	@FindBy(css = "[label='Occupancy Code'] select")
	WebElement INOW_OCCUPANCY_CODE_SELECT;

	@FindBy(css = "[label='Protection Class'] input")
	WebElement INOW_PROTECTION_CLASS_INPUT;

	@FindBy(css = "[label='Territory Code'] input")
	WebElement INOW_TERRITORY_CODE_INPUT;

	By TERRITORY_CODE_INPUT_XPATH = By.xpath("//*[@label='Territory Code']//input");
	
	public YourHomePage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public YourHomePage(Object obj) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}


	public ConstructionPage goToConstructionPage() {
		this.goNext();
		if (this.data.size() > 0) {
			seleniumCommands
					.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.CONSTRUCTION_DETAILS_SEC_CSS));
			return new ConstructionPage(this.data);
		} else {
			return new Pagefactory().getConstructionPage();
		}
	}

	// Set Methods

	public YourHomePage withHomeEstimationValue(String value) {
		// seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.HOMEVALUE_TXT_CSS));
		seleniumCommands.type(HOMEVALUE_TXT_CSS, value);
		return this;
	}

	public YourHomePage withHomeEstimationValue() {
		//seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.HOMEVALUE_TXT_CSS));
		seleniumCommands.type(HOMEVALUE_TXT_CSS, data.get("HomeValue"));
		return this;
	}

	public YourHomePage withHomeSquareFootage() {
		seleniumCommands.type(INOW_SQUARE_FOOTAGE_INPUT, data.get("SquareFootage"));
		return this;
	}

	public YourHomePage withHomeOccupancyCode() {
		seleniumCommands.selectDropDownValueByText(INOW_OCCUPANCY_CODE_SELECT, data.get("Inow_OccupancyCode"));
		return this;
	}

	public YourHomePage withHomeProtectionClass() {
		seleniumCommands.type(INOW_PROTECTION_CLASS_INPUT, data.get("ProcetctionClass"));
		return this;
	}

	public YourHomePage withHomeTerritoryCode() {
		seleniumCommands.type(INOW_TERRITORY_CODE_INPUT, data.get("TerritoryCode"));
		return this;
	}

	public YourHomePage withLocationType() {
		seleniumCommands.staticWait(2);
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.LOCTYPE_DROP_CSS));
		String locType = data.get("LocType");
		if(System.getProperty("platform").equalsIgnoreCase("granite")){
			locType = "In Protected Suburb";
		}
		seleniumCommands.selectDropDownValueByText(LOCTYPE_DROP_CSS, locType);
		return this;
	}

	public YourHomePage withLocationType(String locType) {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.LOCTYPE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(LOCTYPE_DROP_CSS, locType);
		return this;
	}

	public YourHomePage withResidenceType(String resType) {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.RESIDENCETYPE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(RESIDENCETYPE_DROP_CSS, resType);
		return this;
	}

	public YourHomePage withResidenceType() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(YourHomePageLocators.RESIDENCETYPE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(RESIDENCETYPE_DROP_CSS,	data.get("ResType"));
		return this;
	}

	private YourHomePage selectDistanceToFireHydrant_WithIn500ft() {
//		seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.WITHIN1000FT_RBTN_CSS));
		seleniumCommands.clickbyJS(WITHIN500FT_RBTN_CSS);
		return this;
	}

	private YourHomePage selectDistanceToFireHydrant_Over500ft() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.DIST_TO_FIREHYD_LBL_CSS));
		seleniumCommands.clickbyJS(OVER500FT_RBTN_CSS);
		return this;
	}

	public YourHomePage selectDistanceToFireHydrant() {
		if (data.get("DistanceToFireHydrant").equals("WithIn500Ft")) {
			selectDistanceToFireHydrant_WithIn500ft();
		} else {
			selectDistanceToFireHydrant_Over500ft();
		}
		return this;
	}
	
	public YourHomePage selectDistanceToFireHydrant(String value) {
		if (value.equals("WithIn1000Ft")) {
			selectDistanceToFireHydrant_WithIn500ft();
		} else {
			selectDistanceToFireHydrant_Over500ft();
		}
		return this;
	}

	private YourHomePage selectDistanceToFireStn_WithIn5Miles() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.WITHIN5MILES_RBTN_CSS));
		seleniumCommands.clickbyJS(WITHIN5MILES_RBTN_CSS);
		return this;
	}

	private YourHomePage selectDistanceToFireStn_Over5Miles() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.OVER5MILES_RBTN_CSS));
		seleniumCommands.clickbyJS(OVER5MILES_RBTN_CSS);
		return this;
	}

	public YourHomePage selectDistanceToFireStn() {
		if (data.get("DistanceToFireStation").equals("WithIn5Miles")) {
			selectDistanceToFireStn_WithIn5Miles();
		} else {
			selectDistanceToFireStn_Over5Miles();
		}
		return this;
	}
	
	public YourHomePage selectDistanceToFireStn(String Value) {
		if (Value.equals("WithIn5Miles")) {
			selectDistanceToFireStn_WithIn5Miles();
		} else {
			selectDistanceToFireStn_Over5Miles();
		}
		return this;
	}

	private YourHomePage withDistanceToCommercialPropertyTrue() {
		seleniumCommands.waitForElementToBeVisible(NEAR_COMMRPROP_RBTN_YES_CSS);
		seleniumCommands.click(NEAR_COMMRPROP_RBTN_YES_CSS);
		return this;
	}

	private YourHomePage withDistanceToCommercialPropertyFalse() {
		seleniumCommands.waitForElementToBeVisible(NEAR_COMMRPROP_RBTN_YES_CSS);
		seleniumCommands.clickbyJS((NEAR_COMMRPROP_RBTN_NO_CSS));
		return this;
	}

	public YourHomePage withDistanceToCommercialProperty() {
		if (Boolean.getBoolean(data.get("NearCommerProp"))) {
			withDistanceToCommercialPropertyTrue();
		} else {
			withDistanceToCommercialPropertyFalse();
		}
		return this;
	}
	
	public YourHomePage withDistanceToCommercialProperty(String value) {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.NEAR_COMMRPROP_LBL_CSS));
		if (value.equals("Yes")) {
			withDistanceToCommercialPropertyTrue();
		} else {
			withDistanceToCommercialPropertyFalse();
		}
		return this;
	}

	public YourHomePage withFireORFloodHazardTrue() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.FLOODORFIRE_RBTN_YES_CSS));
		seleniumCommands.clickbyJS(FLOODORFIRE_RBTN_YES_CSS);
		return this;
	}

	public YourHomePage withFireORFloodHazardFalse() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.FLOODORFIRE_RBTN_NO_CSS));
		seleniumCommands.clickbyJS(FLOODORFIRE_RBTN_NO_CSS);
		return this;
	}

	public YourHomePage withFireORFloodHazard() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.FLOODORFIRE_LBL_CSS));
		if (Boolean.getBoolean(data.get("FloodFireHazard"))) {
			withFireORFloodHazardTrue();
		} else {
			withFireORFloodHazardFalse();
		}
		return this;
	}

	public YourHomePage withHomeUsageAs(String homeUsage) {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.HOME_USAGE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(HOME_USAGE_DROP_CSS, homeUsage);
		return this;
	}

	public YourHomePage withHomeUsageAs() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.HOME_USAGE_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(HOME_USAGE_DROP_CSS,	data.get("HomeUsage"));
		return this;
	}

	public YourHomePage withHomeOccupancy(String occupencyType) {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.HOME_OCCUPANCY_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(HOME_OCCUPANCY_DROP_CSS, occupencyType);
		return this;
	}

	public YourHomePage withHomeOccupancy() {
		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(YourHomePageLocators.HOME_OCCUPANCY_DROP_CSS));
		seleniumCommands.selectDropDownValueByText(HOME_OCCUPANCY_DROP_CSS, data.get("OccupencyType"));
		return this;
	}
	

	public YourHomePage goNext() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public YourHomePage setYourHomePageDetails() {
		this.withHomeEstimationValue().withLocationType().withResidenceType().selectDistanceToFireHydrant().selectDistanceToFireStn()
				.withDistanceToCommercialProperty().withFireORFloodHazard().withHomeUsageAs().withHomeOccupancy();
		return this;
	}

	public YourHomePage setiNowYourHomePageDetails() {
		this.withHomeSquareFootage().withHomeOccupancyCode().withHomeProtectionClass().withHomeTerritoryCode();
		return this;
	}

	public YourHomePage cleariNowYourHomePageDetails() {
		seleniumCommands.type(INOW_SQUARE_FOOTAGE_INPUT, "");
		seleniumCommands.type(INOW_PROTECTION_CLASS_INPUT, "");
		seleniumCommands.type(INOW_TERRITORY_CODE_INPUT, "");
		seleniumCommands.selectFromDropdownByIndex(INOW_OCCUPANCY_CODE_SELECT,0);
		return this;
	}
	// Get Methods

	private String getHomeEstimationValue() {
		return seleniumCommands.getAttributeValueAtLocator(HOMEVALUE_TXT_CSS, "value");
	}

	private String getLocationType() {
		return seleniumCommands.getSelectedOptionFromDropDown(LOCTYPE_DROP_CSS);
	}

	private String getResidenceType() {
		return seleniumCommands
				.getSelectedOptionFromDropDown(RESIDENCETYPE_DROP_CSS);
	}

	private String getDistanceToFireHydrant() {
		
		if (WITHIN500FT_BTN_VALUE_CSS.isSelected()) {
			return "WithIn500Ft";
		} else if (OVER500FT_BTN_VALUE_CSS.isSelected()) {
			return "Over500Ft";
		}
		return null;
	}

	private String getDistanceToFireStn() {
		if (new Boolean(WITHIN5MILES_BTN_VALUE_CSS.isSelected())) {
			return "WithIn5Miles";
		} else if (new Boolean(OVER5MILES_BTN_VALUE_CSS.isSelected())) {
			return "Over5Miles";
		}
		return null;
	}

	private boolean getDistanceToCommercialProperty() {
		if (NEAR_COMMRPROP_BTN__YES_VALUE_CSS.isSelected()) {
			return true;
		} else if (NEAR_COMMRPROP_BTN__NO_VALUE_CSS.isSelected()) {
			return false;
		}
		return false;
	}

	private boolean getFireORFloodHazardStatus() {
		if (FLOODORFIRE_RBTN_VALUE_YES_CSS.isSelected()) {
			return true;
		} else if (FLOODORFIRE_RBTN_VALUE_NO_CSS.isSelected()) {
			return false;
		}
		return false;
	}

	private String getHomeUsageAs() {
		return seleniumCommands.getSelectedOptionFromDropDown(HOME_USAGE_DROP_CSS);
	}

	private String getHomeOccupancyStatus() {
		return seleniumCommands
				.getSelectedOptionFromDropDown(HOME_OCCUPANCY_DROP_CSS);
	}

	private BinaryToggler findBinaryTogglerByContainedElement(WebElement element) {
		return new BinaryToggler(seleniumCommands.findByContainedElement(element, By.cssSelector("[gw-pl-radios-binary]")));
	}

	public BinaryToggler getDistanceToFireHydrantToggler() {
		return findBinaryTogglerByContainedElement(WITHIN500FT_BTN_VALUE_CSS);
	}

	public BinaryToggler getDistanceToFireStationToggler() {
		return findBinaryTogglerByContainedElement(WITHIN5MILES_BTN_VALUE_CSS);
	}

	public BinaryToggler getDistanceToCommercialPropertyToggler() {
		return findBinaryTogglerByContainedElement(NEAR_COMMRPROP_BTN__YES_VALUE_CSS);
	}

	public BinaryToggler getFloodOrFireHazardToggler() {
		return findBinaryTogglerByContainedElement(FLOODORFIRE_RBTN_VALUE_YES_CSS);
	}


	// Validation Methods

	public Validation isHomeEstimationValueEqualsTo(String estimationValue) {
		return new Validation(getHomeEstimationValue(), estimationValue);
	}
	
	public Validation isHomeEstimationFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(HOMEVALUE_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isHomeEstimationFieldMarkedWithMAXValueError() {
		seleniumCommands.click(RESIDENCETYPE_DROP_CSS);
		seleniumCommands.click(RESIDENCETYPE_DROP_CSS);
		return new Validation(ThreadLocalObject.getDriver().findElement(By.xpath("//*[@model='view.replacementCost']//*[@gw-test-platform-widgets-basicinputs-ctrl-group-error-message] | //*[@label='Estimated Value of Home']//*[contains(@class,'error-inline')]")).getText(), DataConstant.MAX_HOUSE_VALUE_ERROR);
	}

	public Validation isHomeEstimationValueEqualsTo() {
		return new Validation(getHomeEstimationValue(), data.get("HomeValue"));
	}

	public Validation isLocationTypeEqualsTo(String locationType) {
		return new Validation(getLocationType(), locationType);
	}

	public Validation isLocationTypeEqualsTo() {
		return new Validation(getLocationType(), data.get("LocType"));
	}

	public Validation isResidenceTypeEqualsTo(String residenceType) {
		return new Validation(getResidenceType(), residenceType);
	}

	public Validation isResidenceTypeEqualsTo() {
		return new Validation(getResidenceType(), data.get("ResType"));
	}
	
	public Validation isDistanceToFireHydrantEqualsTo(String distance) {
		return new Validation(getDistanceToFireHydrant(), distance);
	}

	public Validation isDistanceToFireHydrantEqualsTo() {
		return new Validation(getDistanceToFireHydrant(), data.get("DistanceToFireHydrant"));
	}
	
	public Validation isDistanceToFireHydrantFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(WITHIN500FT_RBTN_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isDistanceToFireHydrantOver1000Miles(String distance) {
		return new Validation(getDistanceToFireHydrant(), distance);
	}

	public Validation isDistanceToFireStationEqualsTo() {
		return new Validation(getDistanceToFireStn(), data.get("DistanceToFireStation"));
	}
	
	public Validation isDistanceToFireStationFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(WITHIN5MILES_RBTN_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isYourHomePageLoaded() {
		seleniumCommands.waitForElementToBeVisible(HOMEVALUE_TXT_CSS);
		return new Validation(seleniumCommands.isElementPresent(HOMEVALUE_TXT_CSS));
	}

	public Validation isInowYourHomePageLoaded() {
		seleniumCommands.waitForElementToBeVisible(INOW_SQUARE_FOOTAGE_INPUT);
		return new Validation(seleniumCommands.isElementPresent(INOW_SQUARE_FOOTAGE_INPUT));
	}

	public Validation isWithInCommercialPropertyMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(NEAR_COMMRPROP_RBTN_YES_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isWithInCommercialPropertyFieldValueEqualsTo() {
		return new Validation(getDistanceToCommercialProperty());
	}
	
	public Validation isFloddingHazardFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(FLOODORFIRE_RBTN_YES_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isFloddingHazardFieldValueEqualsTo() {
		return new Validation(getFireORFloodHazardStatus());
	}
	
	public Validation isHomeOccupancyFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(HOME_OCCUPANCY_DROP_CSS),DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isHomeUsageFieldValueEqualsTo() {
		return new Validation(getHomeUsageAs(),data.get("HomeUsage"));
	}
	
	public Validation isHomeOccupancyFieldValueEqualsTo() {
		return new Validation(getHomeOccupancyStatus(),data.get("OccupencyType"));
	}

	public Validation isInowSquareFootageFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(INOW_SQUARE_FOOTAGE_INPUT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowHomeOccupancyFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDropdown(INOW_OCCUPANCY_CODE_SELECT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowProtectionClassFireStationFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(INOW_PROTECTION_CLASS_INPUT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowTerritoryCodeFieldMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(INOW_TERRITORY_CODE_INPUT), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isHomeEstimationValueFieldMarkedWithNumericError() {
		logger.info("Validating if Estimated Value of Home is numeric only");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(HOMEVALUE_TXT_CSS), DataConstant.NUMBER_FORMAT_ERROR_MSG);
	}

	public Validation areYourHomePageFieldsMakedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields on Your home page");
		isHomeEstimationFieldMarkedWithError().shouldBeEqual("Home value Field is not marked with Error");
		isDistanceToFireHydrantFieldMarkedWithError().shouldBeEqual("Fire Hydrant Distance Field is not marked with Error");
		isDistanceToFireStationFieldMarkedWithError().shouldBeEqual("Fire Station Distance Field is not marked with Error");
		isWithInCommercialPropertyMarkedWithError().shouldBeEqual("With Commeritial property limit Field is not marked with Error");
		isFloddingHazardFieldMarkedWithError().shouldBeEqual("Fire Hazard Field is not marked with Error");
		isHomeOccupancyFieldMarkedWithError().shouldBeEqual("Home Occupancy Field is not marked with Error");
		return new Validation(true);
	}

	public Validation areINowYourHomePageFieldsMakedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields on Your home page");
		isInowSquareFootageFieldMarkedWithError().shouldBeEqual("Square Footage Field is not marked with Error");
		isInowProtectionClassFireStationFieldMarkedWithError().shouldBeEqual("Protection Class Field is not marked with Error");
		isInowTerritoryCodeFieldMarkedWithError().shouldBeEqual("Territory Code Field is not marked with Error");
		return new Validation(true);
	}

	public Validation areYourHomePageMandatoryFieldsMakedWithAsterisk() {
		logger.info( "Validating the Asterisk for mandatory field on Your Home page");
		isAsteriskPresentForMandatoryField(HOME_VALUE_MODEL).shouldBeEqual("Home value Field is not marked with Error");
		isAsteriskPresentForMandatoryField(LOC_TYPE_VALUE_MODEL).shouldBeEqual("Location type Field is not marked with Error");
		isAsteriskPresentForMandatoryField(RES_TYPE_VALUE_MODEL).shouldBeEqual("Residence type Field is not marked with Error");
		isAsteriskPresentForMandatoryField(DIST_TO_FIREHYDRANT_VALUE_MODEL).shouldBeEqual("Dist to fire hydrant value Field is not marked with Error");
		isAsteriskPresentForMandatoryField(DIST_TO_FIRESTATION_VALUE_MODEL).shouldBeEqual("Dist to fire station  value Field is not marked with Error");
		isAsteriskPresentForMandatoryField(WITHN_COM_PROP_VALUE_MODEL).shouldBeEqual("Within commercial property Field is not marked with Error");
		isAsteriskPresentForMandatoryField(FLOOD_HAZARD_VALUE_MODEL).shouldBeEqual("Flood / hazard value Field is not marked with Error");
		isAsteriskPresentForMandatoryField(HOME_USAGE_MODEL).shouldBeEqual("Home usage Field is not marked with Error");
		isAsteriskPresentForMandatoryField(HOME_OCUPANCY_MODEL).shouldBeEqual("Home occupancy Field is not marked with Error");
		return new Validation(true);
	}

	public Validation areINowYourHomePageMandatoryFieldsMakedWithAsterisk() {
		logger.info( "Validating the Asterisk for mandatory field on Your Home page");
		isAsteriskPresentForMandatoryField(INOW_SQUARE_FOOTAGE_MODEL).shouldBeEqual("Square footage Field is not marked with Error");
		isAsteriskPresentForMandatoryField(INOW_OCCUPANCY_CODE_MODEL).shouldBeEqual("Occupancy code Field is not marked with Error");
		isAsteriskPresentForMandatoryField(INOW_PROTECTION_CLASS_MODEL).shouldBeEqual("Protection Class Field is not marked with Error");
		isAsteriskPresentForMandatoryField(INOW_TERRITORY_CODE_MODEL).shouldBeEqual("Territory Code Field is not marked with Error");
		return new Validation(true);
	}
	
	public Validation areYourHomePageFieldsValuesAreSaved() {
		logger.info( "Validating the field values on Your Info page");
		isHomeEstimationValueEqualsTo().shouldBeEqual("Home Field value is not matched");
		isLocationTypeEqualsTo().shouldBeEqual("Location type Field value is not matched");
		isResidenceTypeEqualsTo().shouldBeEqual("Residence type Field value is not matched");
		isDistanceToFireHydrantEqualsTo().shouldBeEqual("Fire Hydrant Distance Field value is not matched");
		isDistanceToFireStationEqualsTo().shouldBeEqual("Fire station Distance Field value is not matched");
		isWithInCommercialPropertyFieldValueEqualsTo().shouldBeFalse("With in commercial property field value not matched");
		isFloddingHazardFieldValueEqualsTo().shouldBeFalse("Flood and Hazard property value not matched");
		isHomeUsageFieldValueEqualsTo().shouldBeEqual("Home usage value is not matched");
		isHomeOccupancyFieldValueEqualsTo().shouldBeEqual("Home occupancy value is not matched");
		return new Validation(true);
	}


	public Validation areINowYourHomePageFieldsValuesAreSaved() {
		logger.info( "Validating the field values on Your Info page");
		this.withHomeSquareFootage().withHomeOccupancyCode().withHomeProtectionClass().withHomeTerritoryCode();
		new Validation(seleniumCommands.getAttributeValueAtLocator(INOW_SQUARE_FOOTAGE_INPUT, "value"), data.get("SquareFootage")).shouldBeEqual("Home Square footage Field value is not matched");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(INOW_OCCUPANCY_CODE_SELECT), data.get("Inow_OccupancyCode")).shouldBeEqual("Home Field Occupancy Code value is not matched");
		new Validation(seleniumCommands.getAttributeValueAtLocator(INOW_PROTECTION_CLASS_INPUT, "value"), data.get("ProcetctionClass")).shouldBeEqual("Home Protection class Field value is not matched");
		new Validation(seleniumCommands.getAttributeValueAtLocator(INOW_TERRITORY_CODE_INPUT, "value"), data.get("TerritoryCode")).shouldBeEqual("Home Territory Field value is not matched");
		return new Validation(true);
	}

	public Validation areYourHomePageFieldsValuesNotSaved() {
		logger.info( "Validating the field values on Your Info page");
		isHomeEstimationValueEqualsTo().shouldNotBeEqual("Home Field value is matched");
		isLocationTypeEqualsTo().shouldNotBeEqual("Location type Field value is matched");
		isResidenceTypeEqualsTo().shouldNotBeEqual("Residence type Field value is matched");
		isHomeUsageFieldValueEqualsTo().shouldNotBeEqual("Home usage value is matched");
		isHomeOccupancyFieldValueEqualsTo().shouldNotBeEqual("Home occupancy value is matched");

		return new Validation(
				!this.getDistanceToCommercialPropertyToggler().isValueSelected() &&
						!this.getDistanceToFireHydrantToggler().isValueSelected() &&
						!this.getDistanceToFireStationToggler().isValueSelected() &&
						!this.getFloodOrFireHazardToggler().isValueSelected()
		);
	}
	
	public Validation areYourHomePageFieldsValuesMatchingBackEnd() throws Exception {
	return MapCompare.compareMap(ThreadLocalObject.getData(),
			ParseQuoteData.getYourHomeDataFromBackEnd(DataFetch.getQuoteData(
					ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
	}
	
	public Validation areYourHomePageFieldsValuesMatchingBackEnd(String jsonData) throws Exception {
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getYourHomeDataFromBackEnd(jsonData));
		}
}
