package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import com.guidewire.capabilities.agent.model.page.AccountSearchResults;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.Modal;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.locators.ConstructionPageLocators;
import com.guidewire.portals.qnb.locators.DiscountPageLocators;
import com.guidewire.portals.qnb.locators.HOQuotePageLocators;
import com.guidewire.portals.qnb.locators.PaymentDetailsPageLocators;
import com.guidewire.portals.qnb.locators.PolicyConfirmationPageLocators;
import com.guidewire.portals.qnb.locators.PolicyInfoPageLocators;
import com.guidewire.portals.qnb.locators.YourHomePageLocators;
import com.guidewire.portals.qnb.locators.ZipCodePageLocators;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;


public class Pagefactory {

	public HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());
	SeleniumCommands seleniumCommands = new SeleniumCommands();

	@FindBy(id = "PostalCodeNew")
	WebElement ZIPCODE_TXT_ID;

	@FindBy(css = "h2")
	WebElement YOURHOME_PAGE_HEADER_CSS;

	@FindBy(css = "[class='show-for-tablet-portrait-up']")
	WebElement QnB_HEADER_IMAGE_CSS;

	@FindBy(css = "[icon='print'][role='button'] i, gw-quote .gw-quote-grid")
	WebElement PRINT_QUOTE_BTN_CSS;

	@FindBy(css = ".gw-comprop-icon_pin-icon-primary, .gw-bop-icon_pin-icon-primary")
	WebElement PRIMARY_LOCATION_ICON_CSS;

	@FindBy(css = "[model*='contactEmail'] input")
	WebElement CP_BOP_POLICY_INFO_PAGE_CSS;

	@FindBy(css = "[model*='accountOrgType'] select")
	WebElement ORGANIZATION_TYPE_CSS;

	@FindBy(css = "[data-ng-repeat='qs in questionSets'], [ng-class*='preQualClassName']")
	WebElement BOP_QUAL_PAGE_CSS;

	@FindBy(css = "gw-pc-editable-coverages[coverages='coverages']")
	WebElement BOP_GEN_CVG_PAGE_CSS;

	@FindBy(css = "gw-pc-coverages-list[coverages*='filteredCoverages()']")
	WebElement BOP_ADD_CVG_PAGE_CSS;

	@FindBy(css = "[ng-model*='paymentMethod.value']")
	WebElement PAYMENT_DETAILS_PAGE_CSS;

	@FindBy(css = "[ng-click='removeBuilding()']")
	WebElement REMOVE_BLD_BTN;

	@FindBy(css = "[ng-click='removeBuilding()']")
	WebElement REMOVE_CONFIRM_BTM;

	@FindBy(css = "div[class*='gw-hamburger']")
	WebElement NAV_BAR_HAMBURGER_CSS;
	
	@FindBy(css = "[href*='#paquickQuote']")
	WebElement START_QUOTE_BTN_CSS;

	@FindBy(css = ".fa-building-o")
	WebElement ADD_BLDG_ICON_CSS;

	@FindBy(css = "a[ui-sref*='accountNumber'], a[ui-sref*='accounts.detail.summary']")
	WebElement ACC_LINK_WIZARD_CSS;

	@FindBy(css = "[class*='TransactionConfirmation'] i")
	WebElement TRANSACTION_DONE_ICON_CSS;
	
	By CP_BOP_POLICY_START_DATE_TXT_CSS = By.cssSelector("[model*='periodStartDate.value'] input");

	By HO_RETRIEVE_QUOTE_LINK = By.xpath("//*[contains(@src,'homeowners.svg')]/ancestor::gw-available-products-and-features//a[@ng-click='activateItemRetrieval()']");

	By PA_RETRIEVE_QUOTE_LINK = By.xpath("//*[contains(@src,'personalauto.svg')]/ancestor::gw-available-products-and-features//a[@ng-click='activateItemRetrieval()']");

	private final static String SELECTABLE_COVERAGES_XPATH = "//gw-pc-editable-coverages//*[@ng-click='select($event, coverage)']";

	public Pagefactory() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public Pagefactory(Object obj) {
		seleniumCommands.pageWebElementLoader(this);
	}

	public ZipCodePage getZipCodePage() {
		logger.info("Go to ZipCode Page");
		seleniumCommands.waitForElementToBeVisible(By.xpath(ZipCodePageLocators.PA_ZIPCODE_TXT_ID));
		logger.info("Going to ZipCode Page");
		return new ZipCodePage();
	}

	public ZipCodePage getHoOnlyZipCodePage() {
		logger.info("Go to ZipCode Page");
		seleniumCommands.waitForElementToBeVisible(By.xpath(ZipCodePageLocators.HO_ZIPCODE_TXT_ID));
		logger.info("Going to ZipCode Page");
		return new ZipCodePage();
	}
	public YourInfoPage getYourInfoPage() {
		logger.info("Go to YourInfo Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new YourInfoPage();
	}

	public YourInfoPage retrieveQuote(String referenceNumber) {
		logger.info("Retrieving Quote");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		if(ThreadLocalObject.getData().get("PolicyType").equals("HomeOwner")){
			seleniumCommands.clickbyJS(HO_RETRIEVE_QUOTE_LINK);
		}else
			seleniumCommands.clickbyJS(PA_RETRIEVE_QUOTE_LINK);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new QuoteRetrivalPage().setZipCodeRetrive().setQuoteReference(referenceNumber).retriveQuote();
		return new YourInfoPage();
	}

	public QualificationPage getQualificationPage() {
		logger.info("Go to Qualificaton Page");
		seleniumCommands.waitForElement(By.xpath("//*[text()='Qualification']"));
		return new QualificationPage();
	}
	
	public YourHomePage getYourHomePage() {
		logger.info("Go to  Your Home Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new YourHomePage();
	}

	public DriverDetailsPage getDriverDetailsPage() {
		logger.info("Go to Driver Details Page");
		ThreadLocalObject.getDriver().findElement(By.cssSelector("[gw-qnb-pa-edit-driver]"));
		return new DriverDetailsPage();
	}

	public VehicleDetailsPage getVehicelDetailsPage() {
		logger.info("Go to Vehicle Details Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToExist(By.cssSelector("[vehicle='vehicle']"));
		return new VehicleDetailsPage(data);
	}

	public ConstructionPage getConstructionPage() {
		logger.info("Go to Construction Page");
		seleniumCommands
				.waitForElementToBeVisible(By.cssSelector(ConstructionPageLocators.CONSTRUCTION_DETAILS_SEC_CSS));
		return new ConstructionPage();
	}

	public DiscountPage getDiscountPage() {
		logger.info("Go to Discount Page");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(DiscountPageLocators.MANDATORY_FIELD_CLASS));
		return new DiscountPage();
	}

	public HOQuotePage getHOQuotePage() {
		logger.info("Go to HO Quote Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(HOQuotePageLocators.QUOTE_OPTION_TILE_CSS));
		return new HOQuotePage();
	}

	public PAQuotePage getPAQuotePage() {
		logger.info("Go to PA Quote Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(HOQuotePageLocators.QUOTE_OPTION_TILE_CSS));
		return new PAQuotePage();
	}

	public HOPolicyInfoPage getHOPolicyInfoPage() {
		logger.info("Go to HO Policy Info Page");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(PolicyInfoPageLocators.POLICY_INFO_PAGE_CSS));
		return new HOPolicyInfoPage(data);
	}

	public PAPolicyInfoPage getPAPolicyInfoPage() {
		logger.info("Go to PA Policy Info Page");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[name='policyInfoForm']"));
		return new PAPolicyInfoPage(data);
	}

	public PaymentDetailsPage getPaymentInfoPage() {
		logger.info("Go to Payment Page");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(PaymentDetailsPageLocators.PAYMENT_PLAN_CSS));
		return new PaymentDetailsPage();
	}

	public PolicyConfirmationPage getConfirmationPage() {
		logger.info("Go to Confirmation Page");
		seleniumCommands
				.waitForElementToBeVisible(By.cssSelector(PolicyConfirmationPageLocators.CONFIRMATION_PAGE_CSS));
		return new PolicyConfirmationPage(data);
	}

	public CPBOPTransactionConfirmationPage getTransactionConfirmationPage(){
		logger.info("Go to transaction confirmation page");
		seleniumCommands.waitForElementToBeVisible(TRANSACTION_DONE_ICON_CSS);
		return new CPBOPTransactionConfirmationPage();
	}

	//Quick quote pages

	public QuickQuotePage getQuickQuotePage() {
		logger.info("Go to QuickQuote Page");
		return this.getZipCodePage().goToQuickQuotePage();

	}

	public static String getPageUrl() {
		return ThreadLocalObject.getDriver().getCurrentUrl();
	}

	public ZipCodePage gotoZipCodePage() {
		logger.info("Go to Zipcode page by clicking on header image");
		logger.info("Clicking QnB header image");
		this.getZipCodePage();
		return new ZipCodePage();
	}

	public CPBOPPolicyDetailsPage getCPBOPPolicyDetailPage() {
		logger.info("Go to Policy Detail Page");
		seleniumCommands.waitForElementToBeVisible(ORGANIZATION_TYPE_CSS);
		return new CPBOPPolicyDetailsPage();
	}

	public BuildingsAndLocationsPage getBuildingsAndLocationsPage() {
		logger.info("Go to Buildings and Locations Page");
		seleniumCommands.waitForElementToBeVisible(PRIMARY_LOCATION_ICON_CSS);
		return new BuildingsAndLocationsPage();
	}

	public CPBuildingsAndLocations getCPBuildingsAndLocationsPage() {
		logger.info("Go to Buildings and Locations Page of CP");
		seleniumCommands.waitForElementToBeVisible(ADD_BLDG_ICON_CSS);
		return new CPBuildingsAndLocations();
	}

	public BOPQualificationsPage getBOPQualificationPage() {
		logger.info("Go to BOP Qualification Page");
		seleniumCommands.waitForElementToBeVisible(BOP_QUAL_PAGE_CSS);
		seleniumCommands.staticWait(3);
		return new BOPQualificationsPage();
	}

	public BOPGeneralCoveragesPage getBOPGenCoveragePage() {
		logger.info("Go to BOP General Coverages Page");
		seleniumCommands.waitForElementToBeVisible(BOP_GEN_CVG_PAGE_CSS);
		return new BOPGeneralCoveragesPage();
	}

	public BOPAdditionalCoveragesPage getBOPAddCoveragePage() {
		logger.info("Go to BOP Additional Coverages Page");
		seleniumCommands.waitForElementToBeVisible(BOP_ADD_CVG_PAGE_CSS);
		return new BOPAdditionalCoveragesPage();
	}

	public CPBOPQuotePage getCPBOPQuotePage() {
		logger.info("Go to CP/BOP Quote Page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		if (ThreadLocalObject.getSuitenName().equals(SuiteName.GPA.toString())){
			seleniumCommands.waitForElementToBeVisible(PRINT_QUOTE_BTN_CSS);
		}
		return new CPBOPQuotePage();
	}

	public CPBOPPolicyInfoPage getCPBOPPolicyInfoPage() {
		logger.info("Go to Policy Info Page");
		seleniumCommands.waitForElementToBeVisible(CP_BOP_POLICY_INFO_PAGE_CSS);
		return new CPBOPPolicyInfoPage();
	}

	public PaymentDetailsPage getPaymentDetails() {
		logger.info("Go to Payment Details Page");
		seleniumCommands.waitForElementToBeVisible(PAYMENT_DETAILS_PAGE_CSS);
		return new PaymentDetailsPage();
	}

	public AccountSummary clickOnAccountLinkFromWizard(){
		seleniumCommands.click(ACC_LINK_WIZARD_CSS);
		new Modal().confirm();
		return new AccountSummary();
	}

	public CPBOPPolicyDetailsPage setPolicyDetailsPage() {
		logger.info("Setting quote data on Policy details page");
		return this.getCPBOPPolicyDetailPage().setCPPolicyDetails();
	}

	public YourInfoPage setPolicyDataUpToYourInfoPage() {
		logger.info("Setting quote data till Your Info Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails();
	}

	public QualificationPage setPAPolicyDataUpToQualificationPage() {
		logger.info("Setting quote data till Qualification Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails();
	}

	public DriverDetailsPage setPAPolicyDataUpToDriverPage() {
		logger.info("Setting quote data till Driver Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails().goToDriverDetailsPage().setPrimaryDriverDetails();
	}

	public DriverDetailsPage setPAPolicyDataUpToDriverPageWithExtraDriver() {
		logger.info("Setting quote data till Driver Page with Extra Driver");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails().goToDriverDetailsPage().setPrimaryDriverDetails()
				.withNewDriver();
	}

	public VehicleDetailsPage setPAPolicyDataUpToVehiclePage() {
		logger.info("Setting quote data till Vehicle Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails().goToDriverDetailsPage().setPrimaryDriverDetails()
				.goToVehicleDetailsPage().setVehicleDetails();
	}
	
	public PolicyConfirmationPage quoteAndBuyPABasePolicyWithMonthlySavingAccountPayment() {
		logger.info("Quoting and buying a PA policy");
		return this.setPAPolicyDataUpToVehiclePage().goToPAQuotePage().buyBasePolicyWithMonthlyPayment().goToPAPolicyInfoPage().setPolicyInfoPageDetails()
				.goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount().purchasePolicy();
	}

	public VehicleDetailsPage setPAPolicyDataUpToVehiclePageWithExtraVehicle() {
		logger.info("Setting quote data till Vehicle Page with Extra Vehicle");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails().goToDriverDetailsPage().setPrimaryDriverDetails()
				.withNewDriver().goToVehicleDetailsPage().setVehicleDetails().withNewVehicle();
	}
	
	
	//HO data setter
	public DiscountPage setHOPolicyDataUpToAdditionalDiscountPage() {
		logger.info("Setting quote data for Additional Discount Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setYourHomePageDetails()
				.goToConstructionPage().setConstructionPageDetails().goToDiscountPage().setDiscountPageDetails().withAdditionalDiscountDetails();
	}
	
	public DiscountPage setHOPolicyDataUpToDiscountPage() {
		logger.info("Setting quote data till Discount Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setYourHomePageDetails()
				.goToConstructionPage().setConstructionPageDetails().goToDiscountPage().setDiscountPageDetails();
	}

	public DiscountPage setiNowHOPolicyDataUpToDiscountPage() {
		logger.info("Setting quote data till Discount Page");
		return this.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setiNowYourHomePageDetails()
				.goToConstructionPage().setiNowConstructionPageDetails().goToDiscountPage().setiNowDiscountPageDetails();
	}


	public Validation setiNowHOPolicyDataUpToDiscountPageWithNoDiscounts() {
		logger.info("Setting quote data till Discount Page");
		return this.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setiNowYourHomePageDetails()
				.goToConstructionPage().setiNowConstructionPageDetails().goToDiscountPage().setiNowDiscountPageDetailsWithNoDiscounts().goToHOQuotePage().isHOQuotePageLoaded();
	}

	public Validation setHOPolicyDataAndValidateQuoteGenerated() {
		logger.info("Setting quote data till Discount Page and validating is quote is generated");
		return setHOPolicyDataUpToDiscountPage().goToHOQuotePage().isHOQuotePageLoaded();
	}
	
	public QualificationPage setHOPolicyDataUpToQualificationPage() {
		logger.info("Setting quote data till Qualification Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails()
				.goToQualificationPage().setQualificationPageDetails();
	}

	public QualificationPage setINowHOPolicyDataUpToQualificationPage() {
		logger.info("Setting quote data till Discount Page");
		return this.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails();
	}

	public YourInfoPage setHOPolicyDataUpToYourInfoPage() {
		logger.info("Setting quote data till Your Info Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails();
	}
	
	public YourHomePage setHOPolicyDataUpToYourHomePage() {
		logger.info("Setting quote data till Your Home Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setYourHomePageDetails();
	}

	public YourHomePage setiNowHOPolicyDataUpToYourHomePage() {
		logger.info("Setting quote data till Construction Page");
		return this.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setiNowYourHomePageDetails();
	}
	
	public ConstructionPage setHOPolicyDataUpToConstructionPage() {
		logger.info("Setting quote data till Construction Page");
		return this.getZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setYourHomePageDetails()
				.goToConstructionPage().setConstructionPageDetails();
	}

	public ConstructionPage setiNowHOPolicyDataUpToConstructionPage() {
		logger.info("Setting quote data till Construction Page");
		return this.getHoOnlyZipCodePage().setZipCodePageDetails().goToYourInfoPage().setYourInfoPageDetails().goToQualificationPage().setQualificationPageDetails().goToYourHomePage().setiNowYourHomePageDetails()
				.goToConstructionPage().setiNowConstructionPageDetails();
	}
	
	public ConstructionPage setHOPolicyDataUpToConstructionPageWithUpgradeYear() {
		logger.info("Setting quote data till Construction Page with upgrade year");
		return this.setHOPolicyDataUpToConstructionPage().withHeatingUpgradeYear();
	}

	public HOPolicyInfoPage setHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment() {
		logger.info("Setting quote data till policy info page");
		return this.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails();
	}

	public HOPolicyInfoPage setiNowHOBasePolicyDataUpToPolicyInfoPageWithMonthlyPayment() {
		logger.info("Setting quote data till policy info page");
		return this.setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setInowPolicyInfoPageDetails();
	}
	
	public HOPolicyInfoPage setHOBasePolicyDataUpToPolicyInfoPageWithAnnualPayment() {
		logger.info("Setting quote data till policy info page");
		return this.setHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithAnnualPremium().goToPolicyInfoPage().setPolicyInfoPageDetails();
	}
	
			
	public PolicyConfirmationPage quoteAndBuyHOBasePolicyWithMonthlySavingAccountPayment() {
				logger.info("Quoting and buying a PA policy");
				return setHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage()
						.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount().purchasePolicy();
	}

	public PolicyConfirmationPage quoteAndBuyInowHOBasePolicyWithMonthlySavingAccountPayment() {
		logger.info("Quoting and buying a PA policy");
		return setiNowHOPolicyDataUpToDiscountPage().goToHOQuotePage().buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage()
				.setPolicyInfoPageDetails().goToPaymentDetailsPage().iNowPayMonthlyPremiumWithCreditCard().purchasePolicy();
	}
	//Businessowners set data on pages

	public Pagefactory setDataOnBOPPolicyDetailsAndGoNext(){
		this.getCPBOPPolicyDetailPage()
				.setOrgType(false)
				.setSmallBusinessType(false)
				.clickNext();
		return this;
	}

	public Pagefactory setBOPEntryPoint(){
		String suite = ThreadLocalObject.getSuitenName();
		if (suite.equals(SuiteName.GPA.toString())) {
			this.startBOPQuoteWithExistingAccount(data);


		} else {
			seleniumCommands.waitForElementToBeVisible(By.xpath(ZipCodePageLocators.PA_ZIPCODE_TXT_ID));
			this.getZipCodePage().goToBusinessTab().setZipCodePageDetails().goToYourInfoPage();

		}

		return this;
	}



	public Pagefactory setDataTillBOPQualAndGoNext(){
		String suite = ThreadLocalObject.getSuitenName();
		if (suite.equals(SuiteName.GPA.toString())) {

			this.setDataOnBOPPolicyDetailsAndGoNext();

		} else {

			this.setDataOnYourInfoAndGoNext();
		}

		this.getBOPQualificationPage()
				.setPolicyDeclinedQuestion()
				.clickNext();
		return this;
	}

	public Pagefactory setDataTillBOPGenCvgAndGoNext(){
		this.setDataTillBOPQualAndGoNext();
		this.getBOPGenCoveragePage()
				.setLimitsOccurenceCoverage()
				.clickNext();
		return this;
	}

	public Pagefactory setDataToTestGenCvgAndGoNext(){
		this.setDataTillBOPQualAndGoNext();
		this.getBOPGenCoveragePage()
				.setGevCoverageForTest()
				.clickNext();
		return this;
	}

	public Pagefactory setDataTillBOPAddCvgAndGoNext(){
		this.setDataTillBOPGenCvgAndGoNext();
		this.getBOPAddCoveragePage()
				.setGuestPropertyInSafeDepositCoverage()
				.clickNext();
		return this;
	}

	public Pagefactory setDataTillBOPBuildingPageAndGoNext(){
		this.setDataTillBOPAddCvgAndGoNext();
		this.getBuildingsAndLocationsPage()
				.getNewBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding()
				.clickNext();
		return this;
	}

	public Pagefactory setDataToAddLocation(){
		this.setDataTillBOPAddCvgAndGoNext();

		this.getBuildingsAndLocationsPage()
				.getNewBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding();

		this.getBuildingsAndLocationsPage()
				.getNewLocationForm()
				.setAddressLine1(data.get("NewLocation_AddressLine1"))
				.setAddressLine2(data.get("NewLocation_AddressLine2"))
				.setAddressLine3(data.get("NewLocation_AddressLine3"))
				.setCity(data.get("NewLocation_City"))
				.setZIPCode(data.get("NewLocation_ZipCode"))
				.setState(data.get("NewLocation_State"))
				.setLocationCode(data.get("NewLocation_LocationCode"))
				.setPhone(data.get("NewLocation_Phone"))
				.setFireProtection(data.get("NewLocation_FireProtection"))
				.saveAddedLocation();

		// Code to Add Building to New Location

			this.getBuildingsAndLocationsPage()
					.getBuildingForNewLocationForm()
					.setBuildingData(PolicyType.BO.toString(), false)
					.setBuildingLimit(data.get("BuildingLimit"))
					.setPersonalPropertyLimit()
					.saveBOPBuilding();

		this.getBuildingsAndLocationsPage().clickNext();
		return this;

	}

	public Pagefactory setDataToAddRemoveLocation(){
		this.setDataTillBOPAddCvgAndGoNext();

		this.getBuildingsAndLocationsPage()
				.getNewBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding();

		this.getBuildingsAndLocationsPage()
				.getNewLocationForm()
				.setAddressLine1(data.get("NewLocation_AddressLine1"))
				.setAddressLine2(data.get("NewLocation_AddressLine2"))
				.setAddressLine3(data.get("NewLocation_AddressLine3"))
				.setCity(data.get("NewLocation_City"))
				.setZIPCode(data.get("NewLocation_ZipCode"))
				.setState(data.get("NewLocation_State"))
				.setLocationCode(data.get("NewLocation_LocationCode"))
				.setPhone(data.get("NewLocation_Phone"))
				.setFireProtection(data.get("NewLocation_FireProtection"))
				.saveAddedLocation();

		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.getBuildingsAndLocationsPage().removeLocation();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;

	}

	public Pagefactory setDataTillBOPAddBld() {

		this.setDataTillBOPAddCvgAndGoNext();
		this.getBuildingsAndLocationsPage()
				.getNewBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding();

		this.getBuildingsAndLocationsPage()
				.getSecondBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding();

		return this;
	}



	public Pagefactory setDataTillBOPBuildingRmvBld() {
		this.setDataTillBOPAddCvgAndGoNext();

		this.getBuildingsAndLocationsPage()
				.getNewBuildingForm()
				.setBuildingData(PolicyType.BO.toString(), false)
				.setBuildingLimit(data.get("BuildingLimit"))
				.setPersonalPropertyLimit()
				.saveBOPBuilding();

		this.getBuildingsAndLocationsPage().removeBuilding();
		this.getBuildingsAndLocationsPage().clickNext();


	return this;
	}


	public Pagefactory removeBuilding(){
		this.getBuildingsAndLocationsPage().removeBuilding();
		this.getBuildingsAndLocationsPage().clickNext();
		return this;
	}

	public Pagefactory setDataTillYourInfoPage() {
			this.setDataOnYourInfoAndGoNext();
		return this;
	}

	public Pagefactory setDataTillQualificationPageSavingPoint() {
		this.setDataOnYourInfoAndGoNext();
		this.getBOPQualificationPage()
				.setQualificationQuestion()
				.clickNext();
		return this;
	}


	public Pagefactory setDataTillBOPQuotePageAndGoNext(){
		this.setDataTillBOPBuildingPageAndGoNext();
		this.getCPBOPQuotePage();
		ThreadLocalObject.getData().put("REFER_NUMBER", new QuoteInfoBar().getSubmissionNumber());
		ThreadLocalObject.getData().put("QUOTE_TOTAL_PREMIUM", new QuoteInfoBar().getQuotePremium());
		ThreadLocalObject.getData().put("QUOTE_TAXES", new QuoteInfoBar().getQuoteTaxes());
		ThreadLocalObject.getData().put("QUOTE_TOTAL_COST", new QuoteInfoBar().getQuoteTotalCost());
		new CPBOPQuotePage().clickNext();
		return this;
	}

	public Pagefactory setDataForAdditionalCoveragesSavingPoint(){
		this.setDataTillBOPGenCvgAndGoNext();
		this.getBOPAddCoveragePage()
				.setAdditionalCoveragesSavingPoint()
				.clickNext();
		return this;
	}

	public Pagefactory setDataForGeneralCoveragesSavingPoint(){
		this.setDataToTestGenCvgAndGoNext();
		return this;
	}

	public Pagefactory setDataTillBOPPolicyInfoPageAndGoNext(){
		this.setDataTillBOPQuotePageAndGoNext();
		this.getCPBOPPolicyInfoPage()
				.setPhoneField()
				.setEmailField()
				.clickNext();
		return this;
	}

	public PolicyConfirmationPage setDataTillBOPPaymentDetailPageAndGoNext(){
		this.setDataTillBOPPolicyInfoPageAndGoNext()
				.getPaymentDetails()
				.setPaymentPlan()
				.setAccountNumber()
				.setABARoutingNumber()
				.setBankName()
				.clickNext();

		return this.getConfirmationPage();
	}

	public PolicyConfirmationPage dasha(){
		this.setDataTillBOPPolicyInfoPageAndGoNext()
				.getPaymentDetails()
				.setPaymentPlan()
				.setAccountNumber()
				.setABARoutingNumber()
				.setBankName()
				.clickNext();

		return this.getConfirmationPage();
	}
	//Commercial Property set data on pages

	public Pagefactory setDataOnCPPolicyDetailsAndGoNext(){
		this.getCPBOPPolicyDetailPage()
				.setOrgType(false)
				.clickNext();
		return this;
	}
	
	public Pagefactory setDataTillCPBuildingPageAndGoNext(){
		seleniumCommands.waitForLoaderToDisappearFromPage();
		if(seleniumCommands.isElementPresent(CP_BOP_POLICY_START_DATE_TXT_CSS))
				this.setDataOnCPPolicyDetailsAndGoNext();
		this.getCPBuildingsAndLocationsPage()
			.addBuildingOnNewLocation().clickNext();
		CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
		cpBuildingsAndLocations.validateFirstBuilding();
		cpBuildingsAndLocations.clickNext();
		return this;
	}

	public Pagefactory setDataTillCPQuoteAndGoNext(){
		this.setDataTillCPBuildingPageAndGoNext()
			.getCPBOPQuotePage()
			.clickNext();

		return this;
	}

	public Pagefactory setDataTillCPPolicyInfoAndGoNext(){
		this.setDataTillCPQuoteAndGoNext()
			.getCPBOPPolicyInfoPage()
			.setEmailField()
			.setPhoneField()
			.clickNext();

		return this;
	}

	public PolicyConfirmationPage setDataTillCPPaymentAndGoNext(){
		this.setDataTillCPPolicyInfoAndGoNext()
			.getPaymentDetails()
			.setPaymentPlan()
			.setAccountNumber()
			.setABARoutingNumber()
			.setBankName()
			.clickNext();

		return this.getConfirmationPage();
	}

	public void startBOPQuoteWithExistingAccount(HashMap<String, String> data){
		PolicyGenerator.createBasicBoundPAPolicy();
		login();
		searchForPersonalAccount(data)
				.useExistingAccountWithAccountNumber(data.get(PolicyData.ACCOUNT_NUMBER.toString()))
				.withState(data.get("State"))
				.withProducerByIndex(1)
				.withProductCode(PolicyType.BO.getPolicyType())
				.submit();
	}

	public AccountSearchResults searchForPersonalAccount(HashMap<String, String> data){
		return new AgentDashboard()
				.searchQuote()
				.forPersonalAccount()
				.withFirstName(data.get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
				.withLastName(data.get(PolicyData.ACCOUNT_LAST_NAME.toString()))
				.search();

	}
	private void login(){
		new LoginPage().login();
	}
//Businessowners set data pages for Quote & Buy

	public Pagefactory setDataOnYourInfoAndGoNext(){
		this.getYourInfoPage()
				.setYourInfoPageDetails()
				.clickNext();
		return this;
	}

	public WebElement getCoverageEntry(String cvgName) {
		logger.info("Searching " + cvgName + " on Add Building page");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		List<WebElement> allCoverages = seleniumCommands.findElements(By.xpath(SELECTABLE_COVERAGES_XPATH));
		for (WebElement element : allCoverages) {
			if (seleniumCommands.getTextAtLocator(element.findElement(By.cssSelector("span"))).equals(cvgName)) {
				return element;
			}
		}
		return null;
	}


	public Pagefactory clickOnCoverageCheckbox(String cvgName, boolean cvgSelected){
		seleniumCommands.waitForElementToBeVisible(this.getCoverageEntry(cvgName).findElement(By.xpath("./div")));
		if(cvgSelected)
			seleniumCommands.click(this.getCoverageEntry(cvgName).findElement(By.xpath("./div/label")));
		else
			seleniumCommands.click(this.getCoverageEntry(cvgName).findElement(By.xpath("./div")));
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}
}
