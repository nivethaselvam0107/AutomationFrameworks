package com.guidewire.portals.qnb.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;

public class PAPolicyInfoPage extends CommonPage{

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "form[name='policyDetailsForm'] div[class='gw-controls ng-binding']")
	WebElement COV_START_DATE_CSS;

	@FindBy(css = "[ng-if='isAccountHolder(driver)'] div:nth-of-type(1) div:nth-of-type(2)")
	WebElement PRIMARY_DRIVER_NAME_CSS;

	@FindBy(css = "(//*[@class='control-group']/div[2])[11]")
	WebElement ADDRESS_XPATH;

	@FindBy(css = "[name='policyInfoForm']")
	WebElement POLICY_INFO_PAGE_CSS;

	@FindBy(css = "[model='bindData.contactEmail'] input")
	WebElement EMAIL_TXT_CSS;

	@FindBy(css = "[model='view.contactEmail'] span")
	WebElement EMAIL_LBL_CSS;

	@FindBy(css = "[model='bindData.contactPhone'] input")
	WebElement CONTACTNO_TXT_CSS;

	@FindBy(css = "[model='view.contactPhone'] span")
	WebElement CONTACTNO_LBL__CSS;

	@FindBy(css = "button[ng-click='goToNext()']")
	WebElement GONEXT_BTN_CSS;

	@FindBy(css = "[name='policyInfoForm'] table:nth-of-type(2)")
	WebElement DRIVER_TABLE_CSS;

	@FindBy(css = "[name='policyInfoForm'] table:nth-of-type(1)")
	WebElement VEHICLE_TABLE_CSS;
	
	static String VEHICLE_TABLE_XPATH = "//*[@name='policyInfoForm']/table[1]";
	
	static String DRIVER_TABLE_XPATH = "//*[@name='policyInfoForm']/table[2]";
	
	static HashMap<String, String> driverMap = new HashMap<>();
	
	static HashMap<String, String> vehicleMap = new HashMap<>();

	public PAPolicyInfoPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public PAPolicyInfoPage(HashMap<String, String> data) {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}

	public PAPolicyInfoPage goNext() {
		seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public PaymentDetailsPage goToPaymentDetailsPage() {
		this.goNext();
		return new Pagefactory().getPaymentInfoPage();
	}

	// Set Method

	public PAPolicyInfoPage setEmailAddress(String email) {
		//seleniumCommands.type(EMAIL_TXT_CSS, email);
		EMAIL_TXT_CSS.click();
		EMAIL_TXT_CSS.clear();
		if(email.equals(""))
		{
			System.out.println("Null email Number");
			seleniumCommands.click(PRIMARY_DRIVER_NAME_CSS);
			return this;
		}
		seleniumCommands.type(EMAIL_TXT_CSS, email);
		return this;
	}

	public PAPolicyInfoPage setEmailAddress() {
		seleniumCommands.type(EMAIL_TXT_CSS, data.get("Email"));
		return this;
	}

	public PAPolicyInfoPage setPhoneNumber(String number) {
		seleniumCommands.type(CONTACTNO_TXT_CSS, number);
		if(number.equals(""))
		{
			System.out.println("Null Phone Number");
			seleniumCommands.click(PRIMARY_DRIVER_NAME_CSS);
		}
		seleniumCommands.click(VEHICLE_TABLE_CSS);
		return this;
	}

	public PAPolicyInfoPage setPhoneNumber() {
		// seleniumCommands.getTableDataRowWise(DRIVER_TABLE_CSS);
		// seleniumCommands.getTableDataRowWise(VEHICLE_TABLE_CSS);
		seleniumCommands.type(CONTACTNO_TXT_CSS, String.valueOf(data.get("PhoneNumber")));
		return this;
	}

	public PAPolicyInfoPage setPolicyInfoPageDetails() {
		this.setPhoneNumber().setEmailAddress();
		return this;
	}

	// Get Methods

	private String getCoverageStartDate() {
		return COV_START_DATE_CSS.getText();
	}

	private String getPrimaryInssured() {
		return PRIMARY_DRIVER_NAME_CSS.getText();
	}

	private String getEmail() {
		System.out.println(EMAIL_TXT_CSS.getAttribute("value"));
		return EMAIL_TXT_CSS.getAttribute("value");
	}

	public static HashMap<String, String> getVehicleList(int num) {
		// TODO for multiple vehicle
		List<String> vehicleHeader = Arrays.asList("Make", "Model", "VehicleYear", "LicensePlate", "VehicleState");
		return getTableDataRowWise(VEHICLE_TABLE_XPATH, num, vehicleHeader);
	}

	 public static HashMap<String, String> getDriverDetails(int num) {
	 //TODO for multiple driver
	 List<String> driverHeader = Arrays.asList("DriverFullName",
	 "DriverLicenseNum", "DriverLicenseState");
	 return getTableDataRowWise(DRIVER_TABLE_XPATH, num, driverHeader);
	 }

	// Validations method

	public Validation isPAPolicyInfoPageLoaded() {
		logger.info("Validating the Policy Info page loading");
		seleniumCommands.waitForElementToBeVisible(POLICY_INFO_PAGE_CSS);
		return new Validation(seleniumCommands.isElementPresent(POLICY_INFO_PAGE_CSS));
	}

	public Validation isCoverageDateEqualTo(String date) {
		logger.info("Validating the Coverage Date on Policy Info page.");
		return new Validation(getCoverageStartDate(), date);
	}

	public Validation isPrimaryDriverNameEqualsTo(String name) {
		logger.info("Validating the Primary Insured person name on Policy Info page.");
		return new Validation(getPrimaryInssured(), name);
	}
	
	public Validation isPrimaryDriverNameEqualsTo() {
		logger.info("Validating the Primary Driver Name on Policy Info page.");
		return new Validation(getPrimaryInssured(), data.get("DriverFirstName") + " " + data.get("DriverLastName"));
	}
	
	public Validation isEmailEqualsTo() {
		logger.info("Validating the Email value on Policy Info page.");
		return new Validation(getEmail(), data.get("Email"));
	}
	

	private static HashMap<String, String> getTableDataRowWise(String tablePath, int rowNum, List<String> header) {
		HashMap<String, String> topHM = new HashMap<>();
		List<WebElement> elements = new ArrayList<>();
		elements = ThreadLocalObject.getDriver().findElements(By.xpath(tablePath + "/tbody/tr[" + rowNum + "]/td"));
		int i = 0;
		for (WebElement element : elements) {
			topHM.put(header.get(i), element.getText());
			i++;
		}
		return topHM;
	}

	// Validation

	public Validation arePolicyInfoPageFieldsMarkedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for Policy Info page fields");
		isPhoneNumberFieldMakedWithError().shouldBeEqual("Phone Number is not marked with Error");
		new Validation(isEmailFieldMakedWithError()).shouldBeTrue("Email Field is not marked with Error");
		return new Validation(true);
	}

	public Validation isPhoneNumberFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for Phone Number Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(CONTACTNO_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public boolean isGenderrFieldMakedWithAsterisk() {
		logger.info("Validating the Asterick for Phone Number Field");
		boolean value = seleniumCommands.checkAstrickForFields(CONTACTNO_LBL__CSS);
		logger.info("Phone Number is marked with Asterisk " + value);
		return value;
	}

	public boolean isEmailFieldMakedWithError() {
		logger.info("Validating the Mandatory Error for Email Field");
		boolean value = seleniumCommands.getErrorMessageForDatePicker(EMAIL_TXT_CSS)
				.equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Email is marked with Error " + value);
		return value;
	}

	public boolean isEmailFieldMakedWithAsterisk() {
		logger.info("Validating the Asterick for Email Field");
		boolean value = seleniumCommands.checkAstrickForFields(EMAIL_LBL_CSS);
		logger.info("Email is marked with Asterisk " + value);
		return value;
	}

	public Validation validatePolicyInfoPageDetails() throws Exception {
		logger.info("Validating the Policy Info page details");
		String jsonData = DataFetch.getQuoteAsJsonData();
		isCoverageDateEqualTo(DateUtil.getCurrentDateMMMDYYYY()).shouldBeEqual("Coverage date is not matched");
		isPrimaryDriverNameEqualsTo().shouldBeEqual("Primary Person Name is not Correct");
		isEmailEqualsTo().shouldBeEqual("Email value is not correct");
		areDriverDetailsMatchingBackEnd(jsonData).shouldBeTrue("Driver details are not matched");
		areVehicleDetailsMatchingBackEnd(jsonData).shouldBeTrue("Vehicle details are not matched");
		return new Validation(true);
	}
	
	public static Validation areVehicleDetailsMatchingBackEnd(String jsonData) throws Exception
	{
		MapCompare.compareMap(getVehicleList(1),ParseQuoteData.getVehicelDetailsFromBackEnd(jsonData));
		return new Validation(true);
	}
	
	public static Validation areDriverDetailsMatchingBackEnd(String jsonData) throws Exception
	{
		MapCompare.compareMap(getDriverDetails(1),ParseQuoteData.getDriverDetailsFromBackEnd(jsonData));
		return new Validation(true);
	}

}
