package com.guidewire.portals.qnb.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

public class QuoteInfoBar {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();

//	@FindBy(css = "[class='gw-infobar-item']:nth-of-type(1) [class='gw-infobar-content ng-binding'], [class*='page-title'] [class*='ng-binding']")
//	WebElement SUBMISSION_NUMBER_CSS;
    By SUBMISSION_NUMBER_CSS = By.cssSelector( "[class='gw-infobar-content ng-binding'], gw-transaction-wizard-title [class*='title'] div:nth-of-type(2)");


	static String ADDRESS_CSS = "[class='gw-infobar-item']:nth-of-type(2) div:nth-of-type(2) li";
	
	static String VEHICLE_LIST_CSS = "[class='gw-infobar-item']:nth-of-type(3) div:nth-of-type(2) li";
	
	static String DRIVER_LIST_CSS = "[class='gw-infobar-item']:nth-of-type(4) div:nth-of-type(2)";
	
	String MOBILE_QUOTE_INFO_SECTION = "[ng-click='toggleContextPageMenu()']";
	
	String NAV_BAR_SECTION_XPATH = "//*[@gw-qnb-info-bar='submission']/..";

	@FindBy(xpath = "(//div[@class='gw-total-row'])/div[2]")
	WebElement QUOTE_TOTAL_PREMIUM;

	@FindBy(xpath = "(//div[2][@class='gw-total-row'])/div[2]")
	WebElement QUOTE_TAXES;

	@FindBy(xpath = "(//div[4][@class='gw-total-row'])/div[2]")
	WebElement QUOTE_TOTAL_COST;


	public QuoteInfoBar() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		expandQuoteRefSection();
	}

	// Get Methods

	public String getQuotePremium() {
		 String premium = seleniumCommands.getTextAtLocator(QUOTE_TOTAL_PREMIUM);
		 return premium.replace("$", "").substring(0, premium.length()-2);
	}

	public String getQuoteTaxes() {
		String taxes = seleniumCommands.getTextAtLocator(QUOTE_TAXES);
		return taxes.replace("$", "").substring(0, taxes.length()-2);
	}

	public String getQuoteTotalCost() {
		String total_cost =  seleniumCommands.getTextAtLocator(QUOTE_TOTAL_COST);
		return total_cost.replace("$", "").substring(0, total_cost.length()-2);
	}

	public String getSubmissionNumber() {
		seleniumCommands.waitForElementToBeVisible(seleniumCommands.findElements(SUBMISSION_NUMBER_CSS).get(0));
		expandQuoteRefSection();
		String quoteNo;
		if (seleniumCommands.findElements(SUBMISSION_NUMBER_CSS).size()>1) {
			quoteNo = seleniumCommands.findElements(SUBMISSION_NUMBER_CSS).get(2).getText();
		}else
			quoteNo = seleniumCommands.findElements(SUBMISSION_NUMBER_CSS).get(0).getText();
		ThreadLocalObject.setQuoteNum(quoteNo);
		quoteNo = quoteNo.replaceAll("\\D+","");
		return quoteNo;
	}

	public String getAddress() {
		expandQuoteRefSection();
		List<String> address = getListData(By.cssSelector(ADDRESS_CSS));
		return address.get(0) + "," + address.get(1) ;
	}

	public List< String> getVehicleList() {
		expandQuoteRefSection();
		List<String> veh =  getListData(By.cssSelector(VEHICLE_LIST_CSS));
		return veh;
	}

	public List< String> getDriverList() {
		expandQuoteRefSection();
		List<String> Driver=  getListData(By.cssSelector(DRIVER_LIST_CSS));
		return Driver;
	}
	
	private void expandQuoteRefSection()
	{
		if(!ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.GPA.toString()))
		{
			String browser = ThreadLocalObject.getBrowserName();
			boolean flagExpanded =!seleniumCommands.getAttributeValueAtLocator(By.xpath(NAV_BAR_SECTION_XPATH), "class").contains("gw-slide-appearance");
			if ((browser.equalsIgnoreCase("NEXUS5") || browser.equalsIgnoreCase("IPHONE6")) && flagExpanded) 
			{
				seleniumCommands.clickbyJS(By.cssSelector(MOBILE_QUOTE_INFO_SECTION));
			}
		}
	}
	
	public void hideQuoteRefSection()
	{
		String browser = ThreadLocalObject.getBrowserName();
		boolean flagExpanded =seleniumCommands.getAttributeValueAtLocator(By.xpath(NAV_BAR_SECTION_XPATH), "class").contains("gw-slide-appearance");
		if ((browser.equalsIgnoreCase("NEXUS5") || browser.equalsIgnoreCase("IPHONE6")) && flagExpanded) 
		{
			seleniumCommands.clickbyJS(By.cssSelector(MOBILE_QUOTE_INFO_SECTION));
		}
	}

	// Validation method


	private static List< String> getListData(By locator) {
		
		List<String> add = new ArrayList<>();
		List<WebElement> elements = new ArrayList<>();
		elements = ThreadLocalObject.getDriver().findElements(locator);
		for (WebElement element: elements) {
		     add.add(element.getText());
		}
		return add;
	}
	
	public static Validation isSubmissionInDraftStatus() throws Exception
	{
		return new Validation(ParseQuoteData.getSubmisionStatusEqualsTo(DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())), "Draft");
	}
	
	public static Validation isSubmissionInDraftStatus(String quoteDataBackEnd) throws Exception
	{
		return new Validation(ParseQuoteData.getSubmisionStatusEqualsTo(quoteDataBackEnd), "Draft");
	}
	
	public static Validation isSubmissionInQuotedStatus() throws Exception
	{
		return new Validation(ParseQuoteData.getSubmisionStatusEqualsTo(DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())), "Quoted");
	}

	public static Validation isiNowSubmissionInQuotedStatus() throws Exception
	{
		return new Validation(ParseQuoteData.getSubmisionStatusEqualsTo(DataFetch.getiNowQuoteData(ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())), "Quoted");
	}
	
	public static Validation isSubmissionInQuotedStatus(String jsonData) throws Exception
	{
		return new Validation(ParseQuoteData.getSubmisionStatusEqualsTo(jsonData), "Quoted");
	}
	
	public Validation validateHOPolicyAddress() throws Exception
	{
		HashMap<String, String> policyAddress = ParseQuoteData.getHOPolicyAdressFromBackEnd(DataFetch.getQuoteAsJsonData());
		String addressString = policyAddress.get("AddressLine1") +","+ policyAddress.get("City") +", "+ policyAddress.get("StateValue") +" "+ policyAddress.get("ZipCode");
		return new Validation(getAddress(), addressString);
	}

}
