package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class ContactUsPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	HashMap<String, String> uiData = new HashMap<>();

	@FindBy(css = "[class='gw-error-contact']")
	WebElement CONTACT_US_PAGE_CSS;
	
	@FindBy(css = "[class='gw-main-content'] div[ng-if]")
	WebElement CONTACT_US_ERROR_MSG_CSS;
	
	@FindBy(css = "h4")
	WebElement UNABLE_TO_QUOTE_ERROR_MSG_CSS;
	
	@FindBy(css = "[class='gw-control-group gw-reference-number']>div")
	WebElement QUOTE_REF_LBL_CSS;
	
	@FindBy(css = "[class='gw-control-group gw-reference-number']>div + div")
	WebElement QUOTE_REF_NUM_CSS;
	
	
	public ContactUsPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public ContactUsPage(HashMap<String, String> data) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		this.data = data;
	}

	// Get Methods

	
	public String getQuoteReferenceNumber() {
		return QUOTE_REF_NUM_CSS.getText();
	}
	
	public String getContactUsErrorMessage() {
		return CONTACT_US_ERROR_MSG_CSS.getText();
	}
	
	public String getUnableToQuoteMessage() {
		return UNABLE_TO_QUOTE_ERROR_MSG_CSS.getText();
	}

	// Validation method
	
	
	public Validation validateContactPageError()
	{
		new Validation(getContactUsErrorMessage(), DataConstant.CONTACT_US_PAGE_ERROR).shouldBeEqual("Contact Us message is not correct");
		new Validation(getUnableToQuoteMessage(), DataConstant.UNABLE_TO_QUOTE_ERROR).shouldBeEqual("Unable to quote message is not correct");
		return new Validation(true);
	}
	
	public Validation isContactPageDisplayed()
	{
		seleniumCommands.waitForElementToBeVisible(CONTACT_US_PAGE_CSS);
		return new Validation(CONTACT_US_PAGE_CSS.isDisplayed());
	}

	
	
	
	

}
