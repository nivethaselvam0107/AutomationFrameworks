package com.guidewire.portals.qnb.pages.QuickQuoteComponent;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author jkrawczyk-koca
 */
public class VehicleSection extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());
    
    @FindBy(css = "[model='vehicle.vin'] input")
    WebElement VIN_TXT_CSS;

    @FindBy(css = "[model='model.dto.vin'][readonly='true'] label>span[class*='binding']")
    WebElement VIN_LBL_CSS;

    @FindBy(css =  "[model='model.dto.vin'][readonly='true'] span[class*='readonly']")
    WebElement VIN_VALUE_CSS;

    @FindBy(css = "[gw-pa-quick-vehicle-vin-lookup-state] button[ng-click='model.lookup()']")
    WebElement SEARCH_VIN_BTN_CSS;

    @FindBy(css = "button[ng-click='model.cancel()']")
    WebElement CAR_ICON_BTN_CSS;

    By MAKE_DROP_CSS = By.cssSelector("[model*='make'] select");

    @FindBy(css = "[model*='make'][readonly='true'] ng-transclude span[class*='binding']")
    WebElement MAKE_VALUE_CSS;

    By MAKE_LABEL_CSS = By.cssSelector("[gw-pl-select='model.make.value']");

    @FindBy(css = "[model*='make'] div[class*='error']")
    WebElement MAKE_ERR_CSS;

    By MODEL_DROP_CSS = By.cssSelector("[model*='.model'] select");

    @FindBy(css = "[model*='.model'] div[class*='error']")
    WebElement MODEL_ERR_CSS;

    @FindBy(css = "[model*='.model'] ng-transclude span[class*='binding")
    WebElement MODEL_VALUE_CSS;

    @FindBy(css = "[model*='.model'] label span[class*='binding']")
    WebElement MODEL_LABEL_CSS;

    By YEAR_DROP_CSS = By.cssSelector("[model*='.year'] select");

    @FindBy(css = "[model*='.year'] div[class*='error']")
    WebElement YEAR_ERR_CSS;
    
    @FindBy(css = "[model*='.year'] ng-transclude span[class*='binding']")
    WebElement YEAR_VALUE_CSS;

    @FindBy(css = "[model*='.year'] label span[class*='binding']")
    WebElement YEAR_LABEL_CSS;

    @FindBy(css = "[gw-pa-quick-vehicle-edit-state] button[ng-click='submit()']")
    WebElement SAVE_CAR_BTN_CSS;

    @FindBy(css = "[gw-pa-quick-vehicle-edit-state] button[ng-click='model.cancel()']")
    WebElement CANCEL_CAR_BTN_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state='2'] [class*='complete']")
    WebElement VEHICLES_COMPLETE_CSS;

    @FindBy(css = "button[ng-click='model.edit()']")
    WebElement EDIT_CAR_BTN_CSS;
    
    By VIN_RBTN_CSS = By.cssSelector("[class*='Desktop'] [gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_right_label]");

    By VEHICLE_DETAILS_RBTN_CSS = By.cssSelector("[class*='Desktop'] [gw-test-platform-atomic_design-molecules-directives-templates-radio-binary-binary_choice_left_label]");
    
    By VIN_DETAILS_PAGE = By.cssSelector("section[class*='gw-active'] h1[class*='gw-pa-quick-quote-tile-text']");
    
    public VehicleSection()
    {
        seleniumCommands.pageWebElementLoader(this);
    }

    //Set Methods

    public VehicleSection setVIN() {
        seleniumCommands.logInfo( "Setting VIN ");
        seleniumCommands.waitForElementToBeVisible(VIN_RBTN_CSS);
        seleniumCommands.clickbyJS(VIN_RBTN_CSS);
        seleniumCommands.type(VIN_TXT_CSS,data.get("VIN"));
        seleniumCommands.click(new By.ByCssSelector("[class='gw-container gw-content ng-scope']"));
        return this;
    }

    public VehicleSection searchVIN() {
        seleniumCommands.logInfo( "Searching VIN" );
        seleniumCommands.click(VIN_DETAILS_PAGE);
        seleniumCommands.click(VIN_RBTN_CSS);
        //seleniumCommands.waitForElementToBeVisible(MODEL_LABEL_CSS);
        return this;
    }

      public VehicleSection withMake() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.logInfo( "Setting Make ");
        seleniumCommands.staticWait(2);
        seleniumCommands.selectDropDownValueByText(MAKE_DROP_CSS, data.get("Make"));
        return this;
    }

    public VehicleSection withModel() {
        seleniumCommands.logInfo( "Setting Model ");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(2);
        seleniumCommands.selectDropDownValueByText(MODEL_DROP_CSS, data.get("Model"));
        return this;
    }

    public VehicleSection withYear() {
        seleniumCommands.logInfo( "Setting Year ");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(2);
         seleniumCommands.selectDropDownValueByText(YEAR_DROP_CSS, data.get("VehicleYear"));
         return this;
        }


    public VehicleSection openVehicleDetailsForm() {
        seleniumCommands.logInfo( "Opening Vehicle Details ");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(CAR_ICON_BTN_CSS);
        seleniumCommands.waitForElementToBeVisible(MAKE_LABEL_CSS);
        return this;
    }

    public VehicleSection setVehicleFormDetails() {
        seleniumCommands.logInfo( "Setting Vehicle Details ");
        this.openVehicleDetailsForm().withMake().withModel().withYear().submitVehicleData();
        return this;
	}

    public VehicleSection searchVehicleDetailsByVin() {
        seleniumCommands.logInfo( "Searching for Vehicle Details by VIN ");
        this.setVIN().searchVIN();
        return this;
	}

    public VehicleSection submitVehicleData() {
        seleniumCommands.logInfo( "Submitting Vehicle Details ");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SAVE_CAR_BTN_CSS);
        seleniumCommands.waitForElementToBeVisible(MAKE_VALUE_CSS);
        return this;
    }

    public VehicleSection clickSubmit() {
        seleniumCommands.logInfo( "Clicking Submit Icon ");
        seleniumCommands.clickbyJS(SAVE_CAR_BTN_CSS);
        return this;
    }

    public VehicleSection cancelVehicleData() {
        seleniumCommands.logInfo( "Cancelling the Vehicle Data ");
        seleniumCommands.clickbyJS(CANCEL_CAR_BTN_CSS);
        seleniumCommands.waitForElementToBeVisible(VIN_TXT_CSS);
        return this;
    }

    public VehicleSection clickEdit() {
        seleniumCommands.logInfo( "Clicking Edit Icon ");
        seleniumCommands.clickbyJS(EDIT_CAR_BTN_CSS);
        return this;
    }

    // Get Methods

    private String getVIN()
        {
            seleniumCommands.logInfo( "Getting VIN ");
            return seleniumCommands.getTextAtLocator(VIN_VALUE_CSS);
        }

    private String getMake()
        {
            seleniumCommands.logInfo( "Getting Make ");
        return seleniumCommands.getSelectedOptionFromDropDown(MAKE_DROP_CSS);
        }


    private String getModel()
    {
        seleniumCommands.logInfo( "Getting Model ");
        return seleniumCommands.getSelectedOptionFromDropDown(MODEL_DROP_CSS);
    }

    private String getYear()
    {
        seleniumCommands.logInfo( "Getting Year ");
        return seleniumCommands.getSelectedOptionFromDropDown(YEAR_DROP_CSS);
    }

    // Validation

    public Validation isVINSectionLoaded() {
        seleniumCommands.logInfo( "Validating if VIN Section is loaded ");
        seleniumCommands.waitForElementToBeVisible(VIN_TXT_CSS);
        return new Validation(seleniumCommands.isElementPresent(VIN_TXT_CSS));
    }

    public void isVINDataRetrived() {
        seleniumCommands.logInfo( "Validating if VIN Data is retrieved ");
        seleniumCommands.waitForElementToBeVisible(VIN_VALUE_CSS);
        new Validation(seleniumCommands.isElementPresent(VIN_VALUE_CSS)).shouldBeTrue("VIN data was not retrived");
    }

    public void validateVehicleDataRetrived(boolean manualEntry) {
        seleniumCommands.logInfo( "Validating the vehicle data is retrieved ");
        if(manualEntry)
        	new Validation(this.getVIN(),data.get("VIN")).shouldBeEqual("VIN data was not matched");
        new Validation(this.getMake(),data.get("Make")).shouldBeEqual("Make data was not retrived");
        new Validation(this.getModel(),data.get("Model")).shouldBeEqual("Model data was not retrived");
        new Validation(this.getYear(),data.get("VehicleYear")).shouldBeEqual("Year data was not retrived");
    }

    public void validateVehicleFormIsOpened() {
        seleniumCommands.logInfo( "Validating Details form is opened ");
        new Validation(seleniumCommands.isElementPresent(MAKE_DROP_CSS)).shouldBeTrue("Make data was not retrived");
        new Validation(seleniumCommands.isElementPresent(MODEL_DROP_CSS)).shouldBeTrue("Model data was not retrived");
        new Validation(seleniumCommands.isElementPresent(YEAR_DROP_CSS)).shouldBeTrue("Year data was not retrived");
    }

    public void  areVehicleSectionFieldsMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Mandatory fields marked with error");
        isMakeFieldMarkedWithError().shouldBeTrue("Make field is not marked with error");
        isModelFieldMakedWithError().shouldBeTrue("Model field is not marked with error");
        isYearFieldMarkedWithError().shouldBeTrue("Year field is not marked with error");
    }

    public Validation isMakeFieldMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Asterisk for make field");
        return new Validation(seleniumCommands.isElementPresent(MAKE_ERR_CSS));
    }

    public Validation isModelFieldMakedWithError() {
        seleniumCommands.logInfo( "Validating the Asterisk for VIN Field");
        return new Validation(seleniumCommands.isElementPresent(MODEL_ERR_CSS));
    }

    public Validation isYearFieldMarkedWithError() {
        seleniumCommands.logInfo( "Validating the Asterisk for Year Field");
        return new Validation(seleniumCommands.isElementPresent(YEAR_ERR_CSS));
    }
    
    public void isVehicleSectionComplete() {
        seleniumCommands.logInfo( "Validating if Vehicle Section is complete ");
        seleniumCommands.waitForElementToBeVisible(VEHICLES_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(VEHICLES_COMPLETE_CSS)).shouldBeTrue("Vehicle data was not completed");
    }
}
