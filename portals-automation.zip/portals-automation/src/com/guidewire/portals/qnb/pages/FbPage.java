package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;


public class FbPage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(id = "email")
 	WebElement FB_USER_ID;

	@FindBy(id = "pass")
	WebElement FB_PASSWORD_ID;

	@FindBy(name = "login")
	WebElement FB_LOGIN_NAME;

	@FindBy(name = "__CONFIRM__")
	WebElement FB_POST_ON_NAME;

	@FindBy(xpath = "//textarea")
	WebElement FB_SHARE_TEXT_XPATH;

	@FindBy(xpath = "//form//a//img")
	WebElement FB_SHARE_PICTURE_XPATH;

	@FindBy(xpath = "//form//a[text()]")
	WebElement FB_SHARE_TITLE_XPATH;

	@FindBy(xpath = "//meta[@property='og:description']")
	WebElement FB_SHARE_META_TAG_DESCRIPTION_XPATH;

	@FindBy(xpath = "//meta[@property='og:title']")
	WebElement FB_SHARE_META_TAG_TITLE_XPATH;

	private String SELECTOR_XPATH = "//*[text()[contains(.,'%')]]";

	private String MAIN_WINDOW_HWND;
	private String FB_WINDOW_HWND;
	private String FB_SHARE_TEXT;

	public FbPage(String mainWindowHwnd) {

		MAIN_WINDOW_HWND = mainWindowHwnd;
		FB_WINDOW_HWND = this.getFbWindowHwnd();
		seleniumCommands.switchToWindowByHwnd(FB_WINDOW_HWND);
		seleniumCommands.pageWebElementLoader(this);
		this.setFbUserInfo();
	}

	private String getFbWindowHwnd() {
		return seleniumCommands.getPopupHwnd(MAIN_WINDOW_HWND);
	}

	private void setFbUserInfo() {
		logger.info("Setting FB credentials");
		if(seleniumCommands.isElementPresent(FB_USER_ID)) {
			seleniumCommands.type(FB_USER_ID, data.get("FB_USER"));
			seleniumCommands.type(FB_PASSWORD_ID, data.get("FB_PASSWORD"));
			seleniumCommands.click(FB_LOGIN_NAME);
		}
		seleniumCommands.waitForElementToBeVisible(FB_POST_ON_NAME);
		seleniumCommands.pageWebElementLoader(this);
	}

	public void typePostText(String text) {
		logger.info("Typing FB shared text");
		seleniumCommands.type(FB_SHARE_TEXT_XPATH, text);
		FB_SHARE_TEXT = text;
	}

	public Validation verifyElementsVisibleOnFbSharePopup() {
		logger.info("Verify FB elements visibility on popup.");
		seleniumCommands.switchToWindowByHwnd(FB_WINDOW_HWND);
		new Validation(seleniumCommands.getValueAttributeFromLocator(FB_SHARE_TEXT_XPATH), FB_SHARE_TEXT).shouldBeEqual("FB share text is NOT as typed.");
		new Validation(seleniumCommands.isElementPresent(FB_SHARE_TITLE_XPATH)).shouldBeTrue("FB share title is NOT present.");
		new Validation(seleniumCommands.isElementPresent(FB_SHARE_PICTURE_XPATH)).shouldBeTrue("FB share picture is NOT present.");
		return new Validation(true);
	}

	public Validation verifyFbTagsValuesOnFbSharePopup(){
		logger.info("Verify FB elements content on popup based on FB OG tags.");
		seleniumCommands.switchToWindowByHwnd(MAIN_WINDOW_HWND);
		String contentExpected = seleniumCommands.getAttributeValueAtLocator(FB_SHARE_META_TAG_DESCRIPTION_XPATH, "content");
		String titleExpected = seleniumCommands.getAttributeValueAtLocator(FB_SHARE_META_TAG_TITLE_XPATH, "content");

		seleniumCommands.switchToWindowByHwnd(FB_WINDOW_HWND);
		String contentActual = seleniumCommands.findElement(By.xpath(SELECTOR_XPATH.replace("%", contentExpected))).getText();
		String titleActual = seleniumCommands.findElement(By.xpath(SELECTOR_XPATH.replace("%", titleExpected))).getText();

		new Validation(contentActual, contentExpected).shouldBeEqual("FB share tag[cotent] is NOT the same on popup.");
		new Validation(titleActual, titleExpected).shouldBeEqual("FB share tag[title] is NOT the same on popup.");

		return new Validation(true);
	}

	public PolicyConfirmationPage postOnFacebook() {
		logger.info("Post FB content.");
		seleniumCommands.clickbyJS(FB_POST_ON_NAME);
		seleniumCommands.switchToMainWindow(MAIN_WINDOW_HWND);
		seleniumCommands.pageWebElementLoader(this);
		return new PolicyConfirmationPage();
	}
}
