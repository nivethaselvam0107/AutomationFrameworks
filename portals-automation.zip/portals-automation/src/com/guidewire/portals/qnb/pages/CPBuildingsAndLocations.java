package com.guidewire.portals.qnb.pages;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.Modal;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CPBuildingsAndLocations extends BuildingsAndLocationsPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = ".gw-labels .gw-second")
    WebElement NEW_LOC_RADIO_CSS;

    @FindBy(css = ".gw-alert__content")
    WebElement BLDNG_ALERT_MSG_CSS;

    @FindBy(css = "[on-open='$ctrl.ellipsisOpen(item)'] i")
    WebElement FIRST_BLDNG_ELLIPSIS_ICON_CSS;

    @FindBy(css = "li[ng-click*='deleteBuilding'], [ng-click*='removeBuilding'] i")
    WebElement ELLIPSIS_DELETE_BLDNG_CSS;

    @FindBy(css = "li[ng-click*='addBuilding']")
    WebElement ELLIPSIS_ADD_BLDNG_TO_THIS_LOC_CSS;

    @FindBy(css = "td[attribute='address'] a")
    WebElement LOC_FIRST_BLDNG_LINK_CSS;

    @FindBy(css = "[class*='CPLocationSummary'][class*='code'] div")
    WebElement LOC_LOCATION_CODE_CSS;

    @FindBy(css = "[class*='CPLocationSummary'][class*='phone'] div")
    WebElement LOC_PHONE_NUM_CSS;

    @FindBy(css = "[class*='CPLocationSummary'][class*='fireProtection'] div")
    WebElement LOC_FIRE_PROTECTION_CSS;

    @FindBy(css = "td[title='Building Description'] > a.ng-binding")
    WebElement BLDNG_DESC_LINK_ON_LISTING_CSS;

    @FindBy(css = "[title='Building Class Code']")
    WebElement FIRST_CLASS_CODE_ON_LISTING_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='yearBuilt'] div")
    WebElement BLDG_YEAR_BUILT_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='noOfStories'] div")
    WebElement BLDG_NO_STORIES_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='exposure'] div")
    WebElement BLDG_EXPOSURE_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='constructionType'] div")
    WebElement BLDG_CONS_TYPE_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='totalArea'] div")
    WebElement BLDG_TOT_AREA_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='alarm'] div")
    WebElement BLDG_ALARM_TYPE_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='sprinkler'] div")
    WebElement BLDG_SPRINKLERED_CSS;

    @FindBy(css = "[class*='CPBuildingSummary'][class*='propertyClass'] div")
    WebElement BLDG_CLASS_CODE_CSS;

    @FindBy(css = "[type='building'] [class*='header'][class*='subheading'], div[heading*='Building'] [ng-click='toggleOpen()'] [class*='subheading']")
    WebElement BLDG_DETAILS_VIEW_MODE_ACC_CSS;

    @FindBy(css = "[heading*='Location'] span")
    WebElement LOC_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS;


    @FindBy(css = "[heading*='Coverage']")
    WebElement CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS;

    @FindBy(css = "a[ui-sref='cpBuildingWizardBuildingsList']")
    WebElement BACK_VIEW_BTN_CSS;

    @FindBy(css = "[class*='BuildingSummary'] [ng-click='edit()']")
    WebElement EDIT_LINK_BLDNG_CSS;

    @FindBy(css = "[class*='CoveragesSummary'] button[ng-click='edit()']")
    WebElement EDIT_LINK_CVG_CSS;

    @FindBy(css = "[class*='LocationSummary'] [ng-click='edit()']")
    WebElement EDIT_LINK_LOC_CSS;

    @FindBy(css = "[on-click='goToCancel()']")
    WebElement ADD_ANOTHER_BUILDING_BTN_CSS;

    @FindBy(css = ".gw-alert div[class*='content']")
    WebElement EDIT_LOC_MULT_BLDNG_MSG_CSS;

    @FindBy(css = "[on-click*='cancel(locationForm)'], [on-click*='cancel()']")
    WebElement CANCEL_EDIT_FORM_BTN_CSS;

    @FindBy(css = "input[ng-change*='makeQuery()']")
    WebElement SEARCH_BLDNG_LOC_INPUT_CSS;

    @FindBy(css = "td span[class*='highlight']")
    WebElement SEARCH_HIGHLIGHTED_LBL_CSS;

    By BLDNG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS = By.cssSelector("[heading*='Building'] span");

    private final static String VIEW_BUILDINGS_LINK_EDIT_LOC_CSS = "[ng-click*='navigateToLocationView(locationForm)']";

    private final static String NEXT_EMPTY_STATE_BTN_CSS = "[on-click='goToNext()'][disabled='disabled']";

    private final static String NEXT_EMPTY_STATE_BTN_TOOLTIP_CSS = ".tooltipster-content div";

    private final static String NEW_BADGE_CSS = "[type='cpbuildinglistview-new-building']";

    private final static String ADD_BUILDING_BTN_CSS = "button[on-click='$ctrl.manualAddBuilding()'], [ng-click*='addBuilding()'], button[on-click='$ctrl.addBuilding()']";

    private final static String LOC_ADDRESS_VIEW_MODE_CSS = "[class*='CPLocationSummary'][class*='address'] div:nth-of-Type(NUM)";

    private final static String EXISTING_LOCATIONS_DROP_DOWN_CSS = "[model='chosenExistingLocation'] select option";

    private final static String BLDNG_LINK_LOC_VIEW_CSS = "[list='buildingList'] a";

    private final static String LOC_FORM_ADD_BLDNG_CSS = "[name='locationForm']";

    private final static String BLDNG_LISTING_PAGE_TBL_CSS = "table[list='$ctrl.shownBuildings']";

    private final static String LOC_LINKS_LISTING_CSS = "[title='Location'] a";

    private final static String EXCLUDE_THEFT_CVG_CSS = "[gw-test-policycommon-editablecoverages-editablecoverages='Exclude Theft'] select";

    public CPBuildingsAndLocations selectNewLocation(){
        seleniumCommands.clickbyJS(NEW_LOC_RADIO_CSS);
        return this;
    }

    public CPBuildingsAndLocations addNewLocationDetails(){
        this.selectNewLocation();
        new BuildingsAndLocationsPage().setLocationData(false);
        return this;
    }

    public CPBuildingsAndLocations clickOnAddBuilding(){
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_BUILDING_BTN_CSS));
        seleniumCommands.clickbyJS(By.cssSelector(ADD_BUILDING_BTN_CSS));
        return this;
    }

    public CPBuildingsAndLocations selectFromExistingLocations(String location){
        seleniumCommands.selectDropDownValueByText(By.cssSelector(EXISTING_LOCATIONS_DROP_DOWN_CSS.replace(" option", "")), location);
        return this;
    }

    public CPBuildingsAndLocations addBuildingToDefaultLocation(boolean newData){
        String n = "";
        this.clickOnAddBuilding();
        BuildingsAndLocationsPage buildingsAndLocationsPage = new BuildingsAndLocationsPage();
        buildingsAndLocationsPage.clickNext();
        buildingsAndLocationsPage.setBuildingData(PolicyType.CP.toString(), newData).clickNext();
        buildingsAndLocationsPage.setBuildingLimit(data.get("BuildingLimit"));
        buildingsAndLocationsPage.setPersonalPropertyLimit().clickNext();
        return this;
    }

    public CPBuildingsAndLocations addBuildingOnExistingLocation(String location, boolean newData){
        this.clickOnAddBuilding();
        this.selectFromExistingLocations(location);
        BuildingsAndLocationsPage buildingsAndLocationsPage = new BuildingsAndLocationsPage();
        buildingsAndLocationsPage.clickNext();
        buildingsAndLocationsPage.setBuildingData(PolicyType.CP.toString(), newData).clickNext();
        buildingsAndLocationsPage.setBuildingLimit(data.get("BuildingLimit")).clickNext();
        return this;
    }

    public CPBuildingsAndLocations addBuildingOnNewLocation(){
        this.clickOnAddBuilding();
        this.addNewLocationDetails();
        BuildingsAndLocationsPage buildingsAndLocationsPage = new BuildingsAndLocationsPage();
        buildingsAndLocationsPage.clickNext();
        buildingsAndLocationsPage.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        buildingsAndLocationsPage.setBuildingLimit(data.get("BuildingLimit"));
        buildingsAndLocationsPage.setPersonalPropertyLimit().clickNext();
        seleniumCommands.waitForElementToBeClickable(BLDNG_ALERT_MSG_CSS);
        return this;
    }

    public CPBuildingsAndLocations clickAddAnotherBuilding(){
        seleniumCommands.waitForElementToBeClickable(ADD_ANOTHER_BUILDING_BTN_CSS);
        seleniumCommands.click(ADD_ANOTHER_BUILDING_BTN_CSS);
        return this;
    }

    public CPBuildingsAndLocations clickOnEllipsisIcon(){
        //seleniumCommands.focus(FIRST_BLDNG_ELLIPSIS_ICON_CSS);
        seleniumCommands.clickbyJS(FIRST_BLDNG_ELLIPSIS_ICON_CSS);
        return this;
    }

    public CPBuildingsAndLocations removeBuildingFromListing(){
        this.clickOnEllipsisIcon();
        this.clickDeleteAndConfirm();
        return this;
    }

    public String getFirstBuildingDesc(){
        return seleniumCommands.getTextAtLocator(BLDNG_DESC_LINK_ON_LISTING_CSS);
    }

    public CPBuildingsAndLocations clickOnAddBuildingToThisLocation(){
        this.clickOnEllipsisIcon();
        seleniumCommands.click( ELLIPSIS_ADD_BLDNG_TO_THIS_LOC_CSS);
        return this;
    }

    public CPBuildingsAndLocations removeBuildingFromViewMode(){
        this.clickDeleteAndConfirm();
        return this;
    }

    public CPBuildingsAndLocations removeBuildingForLocation(String location){
        for (WebElement element:seleniumCommands.findElements(By.cssSelector(LOC_LINKS_LISTING_CSS))
                ) {
            if (seleniumCommands.getTextAtLocator(element).equals(location)){
               // seleniumCommands.focus(element.findElement(By.xpath("./ancestor::td[@title='Location']//i")));
                seleniumCommands.clickbyJS(element.findElement(By.xpath("./ancestor::td[@title='Location']//i")));
                this.clickDeleteAndConfirm();
                seleniumCommands.waitForLoaderToDisappearFromPage();
                return this;
            }
        }
        return this;
    }

    public CPBuildingsAndLocations openLocationOfFirstBuilding(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(LOC_FIRST_BLDNG_LINK_CSS);
        return this;
    }

    public CPBuildingsAndLocations clickOnViewBuildingsLinkOnEditLocation(){
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(VIEW_BUILDINGS_LINK_EDIT_LOC_CSS));
        seleniumCommands.click(By.cssSelector(VIEW_BUILDINGS_LINK_EDIT_LOC_CSS));
        return this;
    }

    public CPBuildingsAndLocations clickDeleteAndConfirm(){
        seleniumCommands.waitForElementToBeVisible(ELLIPSIS_DELETE_BLDNG_CSS);
        seleniumCommands.clickbyJS(ELLIPSIS_DELETE_BLDNG_CSS);
        new Modal().confirm();
        return this;
    }

    public CPBuildingsAndLocations clickEditOnLocationSummary(){
        seleniumCommands.waitForElementToBeVisible(EDIT_LINK_LOC_CSS);
        seleniumCommands.click(EDIT_LINK_LOC_CSS);
        return this;
    }

    public CPBuildingsAndLocations clickCancelAndConfirmOnForm(){
        seleniumCommands.waitForElementToBeVisible(CANCEL_EDIT_FORM_BTN_CSS);
        seleniumCommands.click(CANCEL_EDIT_FORM_BTN_CSS);
        new Modal().confirm();
        return this;
    }

    public CPBuildingsAndLocations clickEditOnBuildingSummary(){
        seleniumCommands.waitForElementToBeVisible(EDIT_LINK_BLDNG_CSS);
        seleniumCommands.click(EDIT_LINK_BLDNG_CSS);
        return this;
    }

    public CPBuildingsAndLocations selectCauseOfLossForBuildingCoverage(String cause){
        WebElement element = this.getCoverageEntryOnBuildingCoveragesView("Building Coverage").findElement(By.xpath(".//*[@gw-test-policycommon-editablecoverages-editablecoverages='Cause Of Loss']/select"));
        seleniumCommands.selectDropDownValueByText(element, cause);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public CPBuildingsAndLocations selectCauseOfLossForBusinessPersonalPropertyCoverage(String cause){
        WebElement element = this.getCoverageEntryOnBuildingCoveragesView("Business Personal Property Coverage").findElement(By.xpath(".//*[@gw-test-policycommon-editablecoverages-editablecoverages='Cause Of Loss']/select"));
        seleniumCommands.selectDropDownValueByText(element, cause);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public CPBuildingsAndLocations searchForString(String query){
        seleniumCommands.waitForElementToBeVisible(SEARCH_BLDNG_LOC_INPUT_CSS);
        seleniumCommands.type(SEARCH_BLDNG_LOC_INPUT_CSS, query);
        return this;
    }

    public CPBuildingsAndLocations clickEditOnCoveragesSummary(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeClickable(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.click(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.staticWait(2);
        if (!seleniumCommands.isElementPresent(EDIT_LINK_CVG_CSS)){
            seleniumCommands.click(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        }
        seleniumCommands.waitForElementToBeClickable(EDIT_LINK_CVG_CSS);
        seleniumCommands.click(EDIT_LINK_CVG_CSS);
        return this;
    }

    public CPBuildingsAndLocations openFirstBuildingFromListing(){
        seleniumCommands.click(BLDNG_DESC_LINK_ON_LISTING_CSS);
        return this;
    }

    public CPBuildingsAndLocations openFirstBuildingFromLocationView(){
        seleniumCommands.click(By.cssSelector(BLDNG_LINK_LOC_VIEW_CSS));
        return this;
    }

    public CPBuildingsAndLocations expandBuildingSummary(){
        seleniumCommands.click(BLDG_DETAILS_VIEW_MODE_ACC_CSS);
        return this;
    }

    public CPBuildingsAndLocations expandLocationSummaryInAddBuildingFlow(){
    	seleniumCommands.staticWait(3);
        seleniumCommands.waitForElementToBeVisible(LOC_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.click(LOC_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        return this;
    }

    public CPBuildingsAndLocations expandBuildingSummaryInAddBuildingFlow(){
    	seleniumCommands.staticWait(2);
        seleniumCommands.waitForElementToBeVisible(BLDNG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.clickbyJS(BLDNG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("[heading*='Building'] span[class*='open']"));
        return this;
    }

    public CPBuildingsAndLocations expandCoveragesSummaryInAddBuildingFlow_ExcludesFirefox(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        if(!ThreadLocalObject.getBrowserName().equalsIgnoreCase(BrowserType.FIREFOX.toString()))
        		seleniumCommands.click(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        return this;
    }
    
    public CPBuildingsAndLocations expandCoveragesSummaryInAddBuildingFlow(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        seleniumCommands.click(CVG_SUMMARY_ADD_BLDNG_FLOW_ACC_CSS);
        return this;
    }

    public ArrayList<String> getExistingLocations(){
        ArrayList<String> locations = new ArrayList<>();
        for (WebElement element:seleniumCommands.findElements(By.cssSelector(EXISTING_LOCATIONS_DROP_DOWN_CSS))
             ) {
            locations.add(seleniumCommands.getTextAtLocator(element));
        }
        return locations;
    }

    public ArrayList<String> getBuildingsDescriptionOnLocation(){
        ArrayList<String> buildings = new ArrayList<String>();
        for (WebElement element:seleniumCommands.findElements(By.cssSelector(BLDNG_LISTING_PAGE_TBL_CSS))
             ) {
                buildings.add(seleniumCommands.getTextAtLocator(element));
        }
        return buildings;
    }

    public CPBuildingsAndLocations clickBackOnViewModes(){
        seleniumCommands.click(BACK_VIEW_BTN_CSS);
        return this;
    }

    public List<String> getAllLocationsFromListing(){
        ArrayList<String> locations = new ArrayList<String>();
        for (WebElement element : seleniumCommands.findElements(By.cssSelector(LOC_LINKS_LISTING_CSS))
             ) {
            locations.add(seleniumCommands.getTextAtLocator(element));
        }
        return locations;
    }


    //Validation

    public Validation isCoverageTermExcludeTheftAvailable(){
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(EXCLUDE_THEFT_CVG_CSS)));
    }

    public Validation isLocationAvailableInExistingLocations(String location){
        ArrayList<String> existingLocations = this.getExistingLocations();
        return new Validation(existingLocations.contains(location));
    }

    public Validation isBuildingAvailableOnLocation(String desc){
        boolean isBuildingAdded=false;
        for(String s:this.getBuildingsDescriptionOnLocation() ){
            if(s.contains(desc)){
                isBuildingAdded=true;
            }
        }
        return new Validation(isBuildingAdded);
    }

    public Validation isNextButtonDisabled(){
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(NEXT_EMPTY_STATE_BTN_CSS)));
    }

    public Validation isLocationPageDisplayedOnAddBuilding(){
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(LOC_FORM_ADD_BLDNG_CSS)));
    }

    public Validation isBuildingListingPageDisplayed(){
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(BLDNG_LISTING_PAGE_TBL_CSS)));
    }

    public void validateLocationsOnListing(String expectedlocHeader){
        for (String locationFromListing:this.getAllLocationsFromListing()
             ) {
            new Validation(locationFromListing, expectedlocHeader).shouldBeEqual("Location Header didn't match on Listing page");
        }
    }

    public void validateMessageOnEditLocForMultipleBuildings(){
        new Validation(seleniumCommands.getTextAtLocator(EDIT_LOC_MULT_BLDNG_MSG_CSS).equalsIgnoreCase(DataConstant.EDIT_LOC_MULT_BUILDINGS_ALERT_MSG)).shouldBeTrue("The alert message is incorrect for editing location having multiple buildings.");
    }

    public void validateTooltipDisplayedForNoBuildings(){
        seleniumCommands.focus(seleniumCommands.findElement(By.cssSelector(NEXT_EMPTY_STATE_BTN_CSS)));
        new Validation(seleniumCommands.isElementVisible(By.cssSelector(NEXT_EMPTY_STATE_BTN_TOOLTIP_CSS))).shouldBeTrue("Tooltip for no buildings not visible");
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(NEXT_EMPTY_STATE_BTN_TOOLTIP_CSS)).equals(DataConstant.NO_BUILDING_TOOLTIP_TXT)).shouldBeTrue("Tooltip text for no buildings doesn't match");
    }


    public void validateBuildingWithoutChangesSavedMessage(){
        new Validation(seleniumCommands.getTextAtLocator(BLDNG_ALERT_MSG_CSS).equals(DataConstant.BUILDING_SAVED_ALERT_MSG)).shouldBeTrue("Building saved message not displayed");
    }

    public void validateBuildingSavedMessage(){
         new Validation(seleniumCommands.getTextAtLocator(BLDNG_ALERT_MSG_CSS).equals(DataConstant.BUILDING_CHANGES_SAVED_ALERT_MSG)).shouldBeTrue("Building saved message not displayed");
    }

    public void validateBuildingonLocationSavedMessage(){
        new Validation(seleniumCommands.getTextAtLocator(BLDNG_ALERT_MSG_CSS).equals(DataConstant.BUILDING_SAVED_ALERT_MSG)).shouldBeTrue("Building saved message not displayed");
    }

    public void validateNewBadgeOnBuilding(){
        new Validation(seleniumCommands.isElementVisible(By.cssSelector(NEW_BADGE_CSS))).shouldBeTrue("New Badge not displayed for added building ");
    }

    public void isEmptyStateViewDisplayed(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(2);
        new Validation(seleniumCommands.isElementVisible(By.cssSelector(NEXT_EMPTY_STATE_BTN_CSS))).shouldBeTrue("Building is present");
    }

    public void validateNumberOfBuildingsOnLocationViewMode(int numberOfBuildings){
        new Validation(seleniumCommands.findElements(By.cssSelector(BLDNG_LINK_LOC_VIEW_CSS)).size(), numberOfBuildings).shouldBeEqual("The number of buildings is incorrect on location view mode");
    }

    public void validateSelectedLocation(String location){
        new Validation(seleniumCommands.getSelectedOptionFromDropDown(By.cssSelector(EXISTING_LOCATIONS_DROP_DOWN_CSS.replace(" option",""))), location).shouldBeEqual("Selected location didn't match");
    }

    public void validateIfTextHighlighted(String query){
        new Validation(seleniumCommands.isElementPresent(SEARCH_HIGHLIGHTED_LBL_CSS)).shouldBeTrue("No search result highlighted in black");
        if(seleniumCommands.isElementPresent(SEARCH_HIGHLIGHTED_LBL_CSS)){
            new Validation(seleniumCommands.getTextAtLocator(SEARCH_HIGHLIGHTED_LBL_CSS), query).shouldBeEqual("Highlighted string and query didn't match");
        }
    }

    //This method takes a boolean parameter to identify if new/old set of data has to be used, this is mostly needed for test cases requiring editing values on a form.
    public void validateLocationDetailsInViewMode(boolean newData){
        String n = "";
        if(newData) n="New";
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(LOC_ADDRESS_VIEW_MODE_CSS.replace("NUM","1"))), data.get(n+"LocAddressLine1")).shouldBeEqual("Address Line 1 didn't match");
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(LOC_ADDRESS_VIEW_MODE_CSS.replace("NUM","2"))), data.get(n+"LocationCity")).shouldBeEqual("City didn't match");
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(LOC_ADDRESS_VIEW_MODE_CSS.replace("NUM","3"))), data.get(n+"LocationState").substring(0,2).toUpperCase()).shouldBeEqual("State didn't match");
        new Validation(seleniumCommands.getTextAtLocator(LOC_LOCATION_CODE_CSS), data.get(n+"LocationCode")).shouldBeEqual("Location Code didn't match");
        new Validation(seleniumCommands.getTextAtLocator(LOC_PHONE_NUM_CSS).replaceAll("-",""), data.get(n+"LocationPhone")).shouldBeEqual("Phone Number didn't match");
        new Validation(seleniumCommands.getTextAtLocator(LOC_FIRE_PROTECTION_CSS), data.get(n+"FireProtection")).shouldBeEqual("Fire Protection didn't match");
    }

    public void validateFirstBuilding(){
        new Validation(seleniumCommands.getTextAtLocator(BLDNG_DESC_LINK_ON_LISTING_CSS), data.get("BuildingDescription")).shouldBeEqual("Building Description didn't match");
    }

    public void validateClassCodeOnFirstBuilding(){
        new Validation(seleniumCommands.getTextAtLocator(FIRST_CLASS_CODE_ON_LISTING_CSS), data.get("CPPropertyClassCode").split(": ")[0]).shouldBeEqual("Property Class Code didn't match");
    }

    public void validateLocationOnFirstBuilding(){
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(LOC_LINKS_LISTING_CSS)), data.get("AddressHeader")).shouldBeEqual("Location Header didn't match");
    }

    //This method takes a boolean parameter to identify if new/old set of data has to be used, this is mostly needed for test cases requiring editing values on a form.
    public void validateCPBuildingData(boolean newData){
        String n = "";
        if(newData) n="New";
        new Validation(seleniumCommands.getTextAtLocator(BLDG_YEAR_BUILT_CSS),data.get(n+"YearBuilt")).shouldBeEqual("Year Built didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BLDG_NO_STORIES_CSS),data.get(n+"NoOfStories")).shouldBeEqual("No. of stories didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BLDG_EXPOSURE_CSS),data.get(n+"Exposure")).shouldBeEqual("Exposure didn't save");
        String constructionTypeInitials = "";
        for (String initial : data.get(n+"ConstructionType").split(" ")
             ) {
            constructionTypeInitials = constructionTypeInitials+initial.substring(0,1);
        }
        new Validation(seleniumCommands.getTextAtLocator(BLDG_CONS_TYPE_CSS),constructionTypeInitials.toUpperCase()).shouldBeEqual("Construction Type didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BLDG_TOT_AREA_CSS),data.get(n+"TotalArea")).shouldBeEqual("Total Area didn't save");
        if(data.get(n+"HasAlarm").equals("Yes"))
        new Validation(seleniumCommands.getTextAtLocator(BLDG_ALARM_TYPE_CSS),data.get(n+"AlarmType").toLowerCase()).shouldBeEqual("Alarm Type didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BLDG_SPRINKLERED_CSS),data.get(n+"Sprinklered")).shouldBeEqual("% Sprinklered didn't save");
        new Validation(seleniumCommands.getTextAtLocator(BLDG_CLASS_CODE_CSS).contains(data.get(n+"CPPropertyClassCode"))).shouldBeTrue("Property Class Code didn't save");
    }

    public void validateCoverageChange(String buildingLimit){
        WebElement COVERAGE_SECTION = this.getCoverageEntryOnBuildingCoveragesView("Building Coverage");
        new Validation(seleniumCommands.getTextAtLocator(COVERAGE_SECTION.findElement(By.xpath("./div[2]/div[3]/div[2]"))), buildingLimit).shouldBeEqual("Building Limit didn't match");
    }
}
