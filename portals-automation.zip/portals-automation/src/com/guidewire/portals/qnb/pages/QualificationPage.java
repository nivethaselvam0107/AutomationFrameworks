package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.QualificationPageLocators;
import com.guidewire.portals.qnb.locators.YourHomePageLocators;
import com.guidewire.widgetcomponents.form.BinaryToggler;

public class QualificationPage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	// HO Locators
	@FindBy(css = "[label='Any coverage declined, cancelled or non-renewed in past 5 years?']")
	WebElement QUALIFICATION_PAGE_CSS;

	@FindBy(xpath = "//label[@for='binaryinputctrlx4Right'][@class='gw-second']")
	WebElement COV_DECLINED_RBTN_NO_CSS;

	@FindBy(xpath = "//label[@for='binaryinputctrlx0Left'][@class='gw-first']")
	WebElement COV_DECLINED_RBTN_YES_CSS;

	@FindBy(css = "label.control-label > span.ng-binding")
	WebElement COV_DECLINED_LBL_CSS;

	@FindBy(xpath = "//input[@id='binaryinputctrlx4Left']")
	WebElement COV_DECLINED_INPUT_YES_VAL_CSS;

	@FindBy(xpath = "//input[@id='binaryinputctrlx4Right']")
	WebElement COV_DECLINED_INPUT_NO_VAL_CSS;

	@FindBy(xpath = "//label[@for='binaryinputctrlx5Right'][@class='gw-second']")
	WebElement BUSI_ON_PREM_RBTN_NO_CSS;

	@FindBy(xpath = "//label[@for='binaryinputctrlx5Left][@class='gw-first']")
	WebElement BUSI_ON_PREM_RBTN_YES_CSS;

	@FindBy(id = "binaryinputctrlx5Left")
	WebElement BUSI_ON_PREM__INPUT_YES_VAL_ID;

	@FindBy(id = "binaryinputctrlx5Right")
	WebElement BUSI_ON_PREM__INPUT_NO_VAL_ID;

	@FindBy(css = "[class=gw-control-label][for=NoAnswer1]  span")
	WebElement BUSI_ON_PREM_LBL_CSS;

	@FindBy(css = "select")
	WebElement BUSI_TYPE_DROP_NAME;

	@FindBy(css = "[ng-if='q.questionType === 'String''] span")
	WebElement OTHR_REASON_LBL_CSS;

	@FindBy(css = "[name='Answer3']")
	WebElement OTHR_REASON_TXT_CSS;

	@FindBy(css = "[name='Answer3']")
	WebElement COV_DECLINED_SELECTED_OPTION_CSS;

	@FindBy(css = "[name='Answer3']")
	WebElement BUSINESS_ON_PREMISE_SELECTED_OPTION_CSS;

	// PA Locators

	@FindBy(css = "select, [name='Answer0']")
	WebElement ARE_YOU_INSURED_DROP_CSS;

	@FindBy(css = "label[class=gw-second][for=binaryinputctrlx0Right]")
	WebElement LICENSE_CURR_SUS_NO_CSS;

	@FindBy(css = "label[class=gw-first][for=binaryinputctrlx0Left]")
	WebElement LICENSE_CURR_SUS_YES_CSS;

	@FindBy(css = "label[class=gw-second][for=binaryinputctrlx1Right]")
	WebElement LICENSE_ANYTIME_CAN_NO_CSS;

	@FindBy(css = "label[class=gw-first][for=binaryinputctrlx1Left]")
	WebElement LICENSE_ANYTIME_CAN_YES_CSS;

	@FindBy(css = "label[class=gw-second][for=binaryinputctrlx2Right]")
	WebElement TRAFFIC_VIOL_NO_CSS;

	@FindBy(css = "label[class=gw-first][for=binaryinputctrlx2Left]")
	WebElement TRAFFIC_VIOL_YES_CSS;

	@FindBy(css = "input[type='text']")
	WebElement TRAFFIC_VIOL_DETAILS_TXT_CS;

	@FindBy(css = "label[class=gw-second][for=binaryinputctrlx3Right]")
	WebElement POLICY_DECLINE_NO_CSS;

	@FindBy(css = "label[class=gw-first][for=binaryinputctrlx3Left]")
	WebElement POLICY_DECLINE_YES_CSS;

	@FindBy(css = "[on-click='goToNext()']")
	WebElement GO_NEXT_BTN_CSS;

	By DRIVER_PROFILE_TITLE = By.xpath("//div[@class='gw-driver-profile-title']");
	
	//HOP 
	@FindBy(css = "[label='Who occupies this dwelling?'] select")
	WebElement WHO_OCCUPY_DROP_XPATH;
	
	@FindBy(css = "[label='What breed of dog is it?'] select")
	WebElement DOG_BREED_DROP_XPATH;

	private final String RBTN_ID = "binaryinputctrlxNUMLeft";
	
	private final String LEFT_RDBTN_LABLE = "label[for*='Left'][class='gw-first']";
	
	private final String RIGHT_RDBTN_LABLE = "label[for*='Right'][class='gw-second']";
	
	private final String LEFT_RDBTN_XPATH ="input[id*='Left']";
	
	private final String RIGHT_RDBTN_XPATH = "input[id*='Right']";
	
	By OCCUPIER_XPATH = By.cssSelector("[label='Who occupies this dwelling?'] select");

	//iNow locators

	By INOW_NUMBER_OF_CLAIMS_INPUT = By.cssSelector("[label='Number of Claims in last 3 years?'] input");

	@FindBy(css = "[label='Number of aggressive dogs'] input")
	WebElement INOW_NUMBER_OF_DOGS_INPUT;

	@FindBy(css = "[label='Describe'] textarea")
	WebElement INOW_DESCRIBE_DOGS_TEXTAREA;

	@FindBy(css = "[label='Is there a pool on the property?'] select")
	WebElement INOW_HAS_SWIMMING_POOL_SELECT;

	@FindBy(css = "[label='Is the pool fenced?'] select")
	WebElement INOW_IS_POOL_FENCED_SELECT;

	@FindBy(css = "[label='Send for eSignature automatically'] select")
	WebElement INOW_SEND_ESIGNATURE_SELECT;

	@FindBy(css = "[name='localDateChooser'] i")
	WebElement DOB_BTN_CSS;

	By DBO_BUTTON_LEFT = By.cssSelector("[data-datetimepicker-config*='datepicker2'] [class='left']");

	By DBO_YEAR = By.className("year");

	By DBO_MONTH = By.className("month");

	By DBO_DAY = By.cssSelector("[data-datetimepicker-config*='datepicker2'] [class*='day']");

	By FIRST_NAME_LOCATOR = By.cssSelector("[label='First Name'] input");

	public QualificationPage() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public YourHomePage goToYourHomePage() {
		this.goNext();
		if (this.data.size() > 0) {
			seleniumCommands.waitForLoaderToDisappearFromPage();;
			return new YourHomePage(this.data);
		} else {
			return new Pagefactory().getYourHomePage();
		}
	}

	public DriverDetailsPage goToDriverDetailsPage() {
		this.goNext();
		if (this.data.size() > 0) {
			return new DriverDetailsPage(this.data);
		} else {
			return new Pagefactory().getDriverDetailsPage();
		}
	}

	public QualificationPage goNext() {
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public QualificationPage setQualificationPageDetails() {
		if ((data.get("PolicyType").equals("HomeOwner"))||(data.get("PolicyType").equals("Homeowners")) ||(data.get("PolicyType").equals("HOPHomeowners"))) {

			if(seleniumCommands.isElementPresent(OCCUPIER_XPATH))
			{
				this.hasDog().hasSwimmingPool().isPropertyVacant().propertyOccupiedBy();
			} else if (seleniumCommands.isElementPresent(INOW_NUMBER_OF_CLAIMS_INPUT)){
				// iNow Question Sets
				this.setInowHONumberOfClaims().hasSwimmingPool_DropDown().setInowHONumberOfDogs();
				this.setDescribeDogs();
				this.hasEsignatureAutomatically_DropDown();
			}
			else
			{
				this.setHOCoverageDeclinedStatus().setHOPremisesUsedForBusiness();
			}
		} else if (data.get("PolicyType").equals("PersonalAuto")) {
			this.setCurrentInsuranceStatus().setLicenseStatusCancelled().setLicenseCancelledAnyTime()
					.setTrafficeViolationHistory().setPolicyDeclinedHistory();
		}
		return this;
	}

	// Set Methods
	public QualificationPage setCoverageDeclinedStatus(String selection) {
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(COV_DECLINED_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(COV_DECLINED_RBTN_NO_CSS);
		}
		return this;
	}
	private WebElement getLeftRadioButtonByRowIndex(String selector , int num)
	{
		return seleniumCommands.findElements(By.cssSelector(selector)).get(num);
	}
	
	private WebElement getRightRadioButtonByRowIndex(String selector, int num)
	{
		return seleniumCommands.findElements(By.cssSelector(selector)).get(num);
	}
	
	public QualificationPage setHOCoverageDeclinedStatus() {
		if (new Boolean(data.get("CoverageDeclineStatus"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 0));
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 0));
		}
		return this;
	}

	public QualificationPage setInowHONumberOfClaims() {
		return setInowHONumberOfClaims(data.get("NumberOfClaims"));
	}

	public QualificationPage setInowHONumberOfClaims(String number) {
		seleniumCommands.type(INOW_NUMBER_OF_CLAIMS_INPUT, number);
		return this;
	}

	public QualificationPage setDescribeDogs() {
		seleniumCommands.type(INOW_DESCRIBE_DOGS_TEXTAREA, data.get("DescribeDogs"));
		return this;
	}

	public QualificationPage setInowHONumberOfDogs() {
		seleniumCommands.type(INOW_NUMBER_OF_DOGS_INPUT, data.get("NumberOfAggressiveDogs"));
		return this;
	}



	public QualificationPage setHOPremisesUsedForBusiness() {
		if (new Boolean(data.get("BusinessOnPremiseStatus"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 1));
			setTypeOfBusiness();
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE,1));
		}
		return this;
	}

	public QualificationPage setHOPremisesUsedForBusiness(String selection) {
		seleniumCommands
				.waitForElementToBeClickable(By.cssSelector(QualificationPageLocators.BUSI_ON_PREM_RBTN_YES_CSS));
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(BUSI_ON_PREM_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(BUSI_ON_PREM_RBTN_NO_CSS);
		}
		seleniumCommands.selectDropDownValueByText(BUSI_TYPE_DROP_NAME, "Farming");
		return this;
	}

	public QualificationPage setTypeOfBusiness() {
		seleniumCommands.waitForElementToBeEnabled(BUSI_TYPE_DROP_NAME);
		seleniumCommands.selectDropDownValueByText(BUSI_TYPE_DROP_NAME, data.get("TypeOfBusiness"));
		return this;
	}

	public QualificationPage setTypeOfBusiness(String typeOfBusiness) {
		seleniumCommands.selectDropDownValueByText(BUSI_TYPE_DROP_NAME, typeOfBusiness);
		return this;
	}

	public QualificationPage setOtherBusinessDescription(String typeOfBusinessDesc) {
		OTHR_REASON_TXT_CSS.sendKeys(typeOfBusinessDesc);
		return this;
	}

	public QualificationPage setOtherBusinessDescription() {
		OTHR_REASON_TXT_CSS.sendKeys(data.get("OtherBusinessDesc"));
		return this;
	}

	//HOP set Method
	public QualificationPage hasDog() {
		if (new Boolean(data.get("HasDog"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 0));
			seleniumCommands.selectDropDownValueByText(DOG_BREED_DROP_XPATH, data.get("DogBreed"));
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 0));
		}
		return this;
	}
	
	public QualificationPage isPropertyVacant() {
		if (new Boolean(data.get("PropertyVacant"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 1));
		} else { 
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 1));
			propertyOccupiedBy();
		}
		return this;
	}
	
	public QualificationPage hasSwimmingPool() {
		return hasSwimmingPool(2,3);
	}

	public QualificationPage hasSwimmingPool(int index, int subIndex) {
		if (new Boolean(data.get("HasPool"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, index));
			if (new Boolean(data.get("FenceAvailability"))) {
				seleniumCommands.logInfo("Fence setting");
				seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, subIndex));
			} else {
				seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, subIndex));
			}
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, index));
		}
		return this;
	}

	public QualificationPage hasSwimmingPool_DropDown() {
		String hasPool = data.get("InowHasPool");

		seleniumCommands.selectDropDownValueByText(INOW_HAS_SWIMMING_POOL_SELECT, hasPool);
		if (hasPool.equals("Yes")) {
				this.hasPoolFenced_DropDown();
		}
		return this;
	}
	public QualificationPage hasPoolFenced_DropDown() {
		seleniumCommands.selectDropDownValueByText(INOW_IS_POOL_FENCED_SELECT, data.get("InowHasPoolFenced"));
		return this;
	}

	public QualificationPage hasEsignatureAutomatically_DropDown() {
		seleniumCommands.selectDropDownValueByText(INOW_SEND_ESIGNATURE_SELECT, data.get("HasEsignature"));
		return this;
	}

	public QualificationPage hasEsignatureAutomatically(int index) {
		int rowIndex = index;
		if (! new Boolean(data.get("HasPool"))) {
			rowIndex = index - 1;
		}
		if (new Boolean(data.get("hasEsignature"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, rowIndex));
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, rowIndex));
		}
		return this;
	}

	private QualificationPage propertyOccupiedBy() {
		seleniumCommands.selectDropDownValueByText(WHO_OCCUPY_DROP_XPATH, data.get("PropertyOccupier"));
		if (data.get("PropertyOccupier").equals("Myself")) {
			this.propertyOccupiedFulltime();
		} 
		return this;
	}
	
	private QualificationPage propertyOccupiedFulltime() {
		if (new Boolean(data.get("FullTimeOccupier"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 2));
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 2));
			primaryPropertyInsured();
		}
		return this;
	}
	
	private QualificationPage primaryPropertyInsured() {
		if (new Boolean(data.get("InsurePrimary"))) {
			seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 3));
		} else {
			seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 3));
		}
		return this;
	}
	
	// HO Get Methods
	private boolean getCoverageStatus() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 0).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 0).isSelected()) {
			return false;
		}
		return false;
	}

	public boolean getPremisesUsageForBusinessStatus() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 1).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 1).isSelected()) {
			return false;
		}
		return false;
	}

	private String getOtherBusinessDesc() {
		return seleniumCommands.getAttributeValueAtLocator(OTHR_REASON_TXT_CSS, "value");

	}

	private String getTypeOfBusinessSelectedOptions() {
		return seleniumCommands.getSelectedOptionFromDropDown(OTHR_REASON_TXT_CSS);

	}

	// PA Set method

	public QualificationPage setCurrentInsuranceStatus(String selection) {
		seleniumCommands.selectDropDownValueByText(ARE_YOU_INSURED_DROP_CSS, selection);
		return this;
	}

	public QualificationPage setCurrentInsuranceStatus() {
		seleniumCommands.waitForLoaderToDisappearFromPage(2);
		seleniumCommands.selectDropDownValueByText(ARE_YOU_INSURED_DROP_CSS, data.get("InsuranceStatus"));
		return this;
	}

	public QualificationPage setLicenseStatusCancelled() {
		if (data.get("CurrentLicencseStatus").equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 0));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 0));
		}
		return this;
	}

	public QualificationPage setLicenseStatusCancelled(String selection) {
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 0));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 0));
		}
		return this;
	}

	public QualificationPage setLicenseCancelledAnyTime() {
		if (data.get("LicencseCancelledAnyTime").equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 1));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 1));
		}
		return this;
	}

	public QualificationPage setLicenseCancelledAnyTime(String selection) {
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 1));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 1));
		}
		return this;
	}

	public QualificationPage setTrafficeViolationHistory() {
		if (data.get("TrafficeViolationHistory").equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 2));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 2));
		}
		return this;
	}

	public QualificationPage setTrafficeViolationHistory(String selection) {
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 2));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 2));
		}
		return this;
	}

	public QualificationPage setTrafficeViolationHistoryDetails(String details) {
		TRAFFIC_VIOL_DETAILS_TXT_CS.sendKeys(details);
		return this;
	}

	public QualificationPage setTrafficeViolationHistoryDetails() {
		TRAFFIC_VIOL_DETAILS_TXT_CS.sendKeys(data.get("TrafficeViolationHistoryDetails"));
		return this;
	}

	public QualificationPage setPolicyDeclinedHistory() {
		if (data.get("PolicyDeclinedHistory").equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 3));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 3));
		}
		return this;
	}

	public QualificationPage setPolicyDeclinedHistory(String selection) {
		if (selection.equals("true")) {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABLE, 3));
		} else {
			seleniumCommands.clickbyJS(getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABLE, 3));
		}
		return this;
	}

	// PA Get Method

	private String getCurrentInsuranceStatus() {
		return seleniumCommands.getSelectedOptionFromDropDown(ARE_YOU_INSURED_DROP_CSS);
	}

	private boolean getLicenseStatusCancelled() {
		return getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 0).isSelected();
	}

	private boolean getLicenseCancelledAnyTime() {
		return  getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 1).isSelected();
	}

	private boolean getTrafficeViolationHistory() {
		return  getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 2).isSelected();
	}

	private String getTrafficeViolationHistoryDetails() {
		return seleniumCommands.getAttributeValueAtLocator(TRAFFIC_VIOL_YES_CSS, "value");
	}

	private boolean getPolicyDeclinedHistory() {
		return  getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 3).isSelected();
	}
	
	//HOP get method
	
	public boolean getHasDogValue() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 0).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 0).isSelected()) {
			return false;
		}
		return false;
	}
	
	public boolean getPropertyVacantStatusValue() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 1).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 1).isSelected()) {
			return false;
		}
		return false;
	}
	
	public boolean getSwimmingPoolAvailability() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 3).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 3).isSelected()) {
			return false;
		}
		return false;
	}
	
	private String getPropertyOccupier() {
		return seleniumCommands.getSelectedOptionFromDropDown(WHO_OCCUPY_DROP_XPATH);
	}
	
	private boolean getPropertyOccupyBySelf() {
		if (this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_XPATH, 2).isSelected()) {
			return true;
		} else if (this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 2).isSelected()) {
			return false;
		}
		return false;
	}

	// HO Validation Methods
	public Validation isCoverageStatusEqualsTo(boolean status) {
		return new Validation(getCoverageStatus(), status);
	}

	public Validation isCoverageStatusEqualsTo() {
		return new Validation(getCoverageStatus(), new Boolean(data.get("CoverageDeclineStatus")));
	}

	public Validation isCoverageStatusMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(seleniumCommands.findElements(By.cssSelector("input[id*='Left']")).get(0))
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}

	public Validation isPremisesUsedForBusiness(boolean status) {
		return new Validation(getPremisesUsageForBusinessStatus(), status);
	}

	public Validation isPremisesUsedForBusiness() {
		return new Validation(getPremisesUsageForBusinessStatus(), new Boolean(data.get("BusinessOnPremiseStatus")));
	}

	public Validation isPremisesUsedForBusinessMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(seleniumCommands.findElements(By.cssSelector("input[id*='Left']")).get(1))
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}
	
	public Validation isPropertyOccupiedByMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(seleniumCommands.findElement(OCCUPIER_XPATH))
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}

	public Validation isTypeOfBusinessSelectedAs(String typeOfBusiness) {
		return new Validation(getTypeOfBusinessSelectedOptions(), typeOfBusiness);
	}

	public Validation isTypeOfBusinessSelectedAs() {
		return new Validation(getTypeOfBusinessSelectedOptions(), data.get("TypeOfBusiness"));
	}

	public Validation isOtherBusinessDescEqualTo(String typeOfBusiness) {
		return new Validation(getOtherBusinessDesc(), typeOfBusiness);
	}

	public Validation isOtherBusinessDescEqualTo() {
		return new Validation(getOtherBusinessDesc(), data.get("OtherBusinessDesc"));
	}

	public Validation areHOQualificationPageFieldsMakedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the fields on Qualification page");
		if(seleniumCommands.isElementPresent(OCCUPIER_XPATH)) {
			isPropertyOccupiedByMarkedWithError().shouldBeTrue("Property occupier field is not marked with error");
		}
		else if (seleniumCommands.isElementPresent(INOW_NUMBER_OF_CLAIMS_INPUT)){
			// iNow Question Sets
			isINowNumberOfClaimsLast3YearsByMarkedWithError().shouldBeTrue("Number of Claims in last 3 years field is not marked with error");
			isINowNumberOfDogsByMarkedWithError().shouldBeTrue("Number of Dogs field is not marked with error");
			isINowNumberOfHasSwimmingPoolByMarkedWithError().shouldBeTrue("Has Swimming pool field is not marked with error");
		}
		else {
			isPremisesUsedForBusinessMarkedWithError().shouldBeTrue("Business on Premise field is not marked with Error");
			isCoverageStatusMarkedWithError().shouldBeTrue("Coverage declined status is not marked with Error");
		}
		return new Validation(true);
	}

	public Validation isINowNumberOfClaimsLast3YearsByMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForParentSiblingTxtBox(seleniumCommands.findElement(INOW_NUMBER_OF_CLAIMS_INPUT))
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}

	public Validation isINowNumberOfDogsByMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForParentSiblingTxtBox(INOW_NUMBER_OF_DOGS_INPUT)
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}

	public Validation isINowNumberOfHasSwimmingPoolByMarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForParentSiblingTxtBox(INOW_HAS_SWIMMING_POOL_SELECT)
				.equals(DataConstant.MANDATORY_ERROR_MSG));
	}

	// PA Validation

	private Validation isCurrentInsuranceStatusEqualsTo() {
		return new Validation(getCurrentInsuranceStatus(), data.get("InsuranceStatus"));
	}

	private Validation isCurrentInsuranceStatusEqualsTo(String value) {
		return new Validation(getCurrentInsuranceStatus(), value);
	}

	public Validation isLicenseStatusCancelledSetAs() {
		return new Validation(getLicenseStatusCancelled(), Boolean.valueOf(data.get("CurrentLicencseStatus")));
	}

	public Validation isLicenseStatusCancelledSetAs(boolean status) {
		return new Validation(getLicenseStatusCancelled(), status);
	}

	public Validation isLicenseCancelledAnyTimeSetAs() {
		return new Validation(getLicenseCancelledAnyTime(), Boolean.valueOf(data.get("LicencseCancelledAnyTime")));
	}

	public Validation isLicenseCancelledAnyTimeSetAs(boolean status) {
		return new Validation(getLicenseCancelledAnyTime(), status);
	}

	public Validation isTrafficeViolationHistorySetAs() {
		return new Validation(getTrafficeViolationHistory(), Boolean.valueOf(data.get("TrafficeViolationHistory")));
	}

	public Validation isTrafficeViolationHistorySetAs(boolean status) {
		return new Validation(getTrafficeViolationHistory(), status);
	}

	public Validation isTrafficeViolationHistoryDetailsEqualTo() {
		return new Validation(getTrafficeViolationHistoryDetails(),
				Boolean.valueOf(data.get("TrafficeViolationHistoryDetails")));
	}

	public Validation isTrafficeViolationHistoryDetailsEqualTo(String details) {
		return new Validation(getTrafficeViolationHistoryDetails(), details);
	}
	
	public Validation isConvictionDetailsFieldMarkedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the Conviction details fields");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(TRAFFIC_VIOL_DETAILS_TXT_CS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isPolicyDeclinedHistorySetAs() {
		return new Validation(getPolicyDeclinedHistory(), Boolean.valueOf(data.get("PolicyDeclinedHistory")));
	}

	public Validation isPolicyDeclinedHistorySetAs(boolean status) {
		return new Validation(getPolicyDeclinedHistory(), status);
	}

	public Validation isQualificationPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[ng-class*='preQualClassName'], [class='gw-prequal-questions ng-scope']"));
		return new Validation(seleniumCommands.isElementPresent(By.cssSelector("[ng-class*='preQualClassName'], [class='gw-prequal-questions ng-scope']")));
	}

	public Validation isHOCoverageDeclinedValueEqualsTo() {
		return new Validation(getCoverageStatus(), Boolean.valueOf(data.get("CoverageDeclineStatus")));
	}

	public Validation isBusinessOnPremiseValueEqualsTo() {
		return new Validation(getPremisesUsageForBusinessStatus(),
				Boolean.valueOf(data.get("BusinessOnPremiseStatus")));
	}

	public Validation arePAQualificationAnswersSaved() {
		this.isCurrentInsuranceStatusEqualsTo().shouldBeEqual("Current insurance status is not matched");
		this.isLicenseStatusCancelledSetAs().shouldBeEqual("License status is not correct");
		this.isLicenseCancelledAnyTimeSetAs().shouldBeEqual("Any time license revoke status not matched");
		this.isTrafficeViolationHistorySetAs().shouldBeEqual("Traffic violation history not matched");
		this.isPolicyDeclinedHistorySetAs().shouldBeEqual("Policy declined status not matched");
		return new Validation(true);
	}

	public Validation arePAQualificationAnswersNotSaved() {
		this.isCurrentInsuranceStatusEqualsTo("-- Choose --");
		this.isLicenseStatusCancelledSetAs().shouldBeEqual("License status is not correct");
		this.isLicenseCancelledAnyTimeSetAs().shouldBeEqual("Any time license revoke status not matched");
		this.isTrafficeViolationHistorySetAs().shouldBeEqual("Traffic violation history not matched");
		this.isPolicyDeclinedHistorySetAs().shouldBeEqual("Policy declined status not matched");
		return new Validation(true);
	}

	public Validation areHOQualificationAnswersSaved() {
		if(seleniumCommands.isElementPresent(OCCUPIER_XPATH)) {
			this.hasDog().hasSwimmingPool().isPropertyVacant().propertyOccupiedBy();
			new Validation(getHasDogValue(), Boolean.valueOf(data.get("HasDog"))).shouldBeEqual("Dog availability is not matched");
			new Validation(getPropertyVacantStatusValue(), Boolean.valueOf(data.get("PropertyVacant"))).shouldBeEqual("PropertyVacant status is not matched");
			new Validation(getPropertyOccupier(), data.get("PropertyOccupier")).shouldBeEqual("PropertyOccupier value is not matched");
			new Validation(getPropertyOccupyBySelf(), Boolean.valueOf(data.get("FullTimeOccupier"))).shouldBeEqual("FullTimeOccupier value is not matched");
			new Validation(getSwimmingPoolAvailability(), Boolean.valueOf(data.get("HasPool"))).shouldBeEqual("HasPool is not matched matched");
		} else if (seleniumCommands.isElementPresent(INOW_NUMBER_OF_CLAIMS_INPUT)){
			// iNow Question Sets
			new Validation(getPropertyInowHONumberOfClaims(), data.get("NumberOfClaims")).shouldBeEqual("Number of claims in last 3 years is not matched");
			new Validation(getPropertyInowHONumberOfDogs(), data.get("NumberOfAggressiveDogs")).shouldBeEqual("Number of dogs is not matched");
			new Validation(getPropertyhasSwimmingPoolValue(), data.get("InowHasPool")).shouldBeEqual("Property has swimming Pool is not matched");
			new Validation(getPropertyhasEsignatureValue(), data.get("HasEsignature")).shouldBeEqual("Property has Esignature status is not matched");
			new Validation(getPropertyDescribeDogs(), data.get("DescribeDogs")).shouldBeEqual("Describe Dogs text is not matched");
			if(data.get("InowHasPool").equals("Yes")){
				new Validation(getPropertyhasPoolFencedValue(), data.get("InowHasPoolFenced")).shouldBeEqual("Property has swimming Pool Fenced is not matched");
			}
		}
		else {
			this.isCoverageStatusEqualsTo().shouldBeEqual("HO Coverage Declined status is not matched");
			this.isBusinessOnPremiseValueEqualsTo().shouldBeEqual("Business On Premise value is not matched");
		}

		return new Validation(true);
	}

	public String getPropertyInowHONumberOfClaims() {
		return seleniumCommands.getAttributeValueAtLocator(INOW_NUMBER_OF_CLAIMS_INPUT, "value");
	}
	public String getPropertyInowHONumberOfDogs() {

		return seleniumCommands.getAttributeValueAtLocator(INOW_NUMBER_OF_DOGS_INPUT, "value");
	}

	public String getPropertyhasSwimmingPoolValue() {
		return seleniumCommands.getSelectedOptionFromDropDown(INOW_HAS_SWIMMING_POOL_SELECT);
	}

	public String getPropertyhasPoolFencedValue() {
			return seleniumCommands.getSelectedOptionFromDropDown(INOW_IS_POOL_FENCED_SELECT);
	}

	public String getPropertyhasEsignatureValue() {

		return seleniumCommands.getSelectedOptionFromDropDown(INOW_SEND_ESIGNATURE_SELECT);
	}

	public String getPropertyDescribeDogs() {

		return seleniumCommands.getAttributeValueAtLocator(INOW_DESCRIBE_DOGS_TEXTAREA, "value");
	}

	private BinaryToggler findBinaryTogglerByContainedElement(WebElement element) {
		return new BinaryToggler(seleniumCommands.findByContainedElement(element, By.cssSelector("[gw-pl-radios-binary]")));
	}

	public BinaryToggler getCoverageDeclinedToggler() {
		return findBinaryTogglerByContainedElement(COV_DECLINED_INPUT_YES_VAL_CSS);
	}

	public BinaryToggler getBusinessOnPremisesToggler() {
		return findBinaryTogglerByContainedElement(BUSI_ON_PREM__INPUT_YES_VAL_ID);
	}

	public Validation areHOQualificationAnswersNotSaved() {
		 new Validation(this.getCoverageDeclinedToggler().isValueSelected()).shouldBeTrue("Coverage declined option value is not correct");
		 new Validation(this.getBusinessOnPremisesToggler().isValueSelected()).shouldBeTrue("Business on Premises option value is not correct");
		return new Validation(true);
	}

	public Validation arePAQualificationAnswersMatchingBackEnd() throws Exception{
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getPAPreQualificationAnswerFromBackEnd(DataFetch.getQuoteData(
						ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
	}

	public Validation arePAQualificationAnswersMatchingBackEnd(String jsonData) throws Exception{
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getPAPreQualificationAnswerFromBackEnd(jsonData));
	}
}
