package com.guidewire.portals.qnb.pages;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.HashMap;

public class BOPQualificationsPage extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    private final static String LEFT_RDBTN_LABEL = "label[for*='Left'][class='gw-first']";

    private final static String RIGHT_RDBTN_LABEL = "label[for*='Right'][class='gw-second']";

    private final static String LEFT_RDBTN_XPATH ="input[id*='Left']";

    private final static String RIGHT_RDBTN_XPATH = "input[id*='Right']";

    public BOPQualificationsPage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public BOPQualificationsPage setPolicyDeclinedQuestion(){
        if (data.get("PolicyDeclineStatus").equals("Yes")) {
            seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABEL, 0));
        } else {
            seleniumCommands.clickbyJS(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 0));
        }
        return this;
    }


    public BOPQualificationsPage setQualificationQuestion(){

        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 0));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 1));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 2));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 3));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 4));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 5));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 6));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 7));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 8));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 9));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 10));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 11));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABEL, 12));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(LEFT_RDBTN_LABEL, 13));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 14));
        seleniumCommands.clickbyJS(this.getLeftRadioButtonByRowIndex(RIGHT_RDBTN_LABEL, 15));
        return this;
    }

    private WebElement getLeftRadioButtonByRowIndex(String selector , int num)
    {
        return seleniumCommands.findElements(By.cssSelector(selector)).get(num);
    }

    private WebElement getRightRadioButtonByRowIndex(String selector, int num)
    {
        seleniumCommands.staticWait(3);
        return seleniumCommands.findElements(By.cssSelector(selector)).get(num);
    }

    //Validation method

    public Validation isPolicyDeclinedQuesMarkedNo(){
        logger.info("Verifying Policy/Coverage declined question's answer");
        return new Validation(this.getRightRadioButtonByRowIndex(RIGHT_RDBTN_XPATH, 0).isSelected());
    }
}
