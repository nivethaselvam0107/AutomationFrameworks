package com.guidewire.portals.qnb.pages.QuickQuoteComponent;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author jkrawczyk-koca
 */
public class AddressSection extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    HashMap<String, String> uiData = new HashMap<>();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[ng-model='model.address'], textarea")
    WebElement ADDRESS_TXT_CSS;

    @FindBy(css = "div.gw-slq-buttons > button.gw-icon-primary.gw-icon-button-search")
    WebElement SEARCH_BTN;

    @FindBy(css = "div.gw-slq-buttons > button.gw-icon-primary.gw-icon-button-edit")
    WebElement EDIT_BTN;


    By zipCode = By.id("PostalCode");

    @FindBy(css = "[ng-click='switchToManualEntryMode()']")
    WebElement ADDRESS_NOT_IN_LIST_BTN;
    
    @FindBy(css = "[ng-click='switchToSearch()']")
    WebElement BACK_TO_SEARCH_ADDRESS;

    @FindBy(css = "[ng-model='model.value']")
    WebElement SEARCH_STREET_TXT_BAR;

    @FindBy(css = "[ng-click='submit()']")
    WebElement ADDRESS_SUBMIT_BTN;

    @FindBy(xpath = "//gw-pl-input-ctrl[2]/div/div/div/input")
    WebElement CITY_FIELD_TXT_BTN;


    @FindBy(xpath = "[gw-pa-quick-address-tile] [ng-click='model.lookup()']")
    WebElement SEARCH_ADDRESS_BTN_CSS;

    @FindBy(css = "[result] [ng-repeat]:nth-of-type(1)")
    WebElement ADDRESS_FIRST_RESULT_CSS;

    @FindBy(css = "[ng-if='searchForLocation'] [map-name='paQuickQuoteLocationMap']")
    WebElement LOCATION_CSS;

    @FindBy(xpath = "//*[@model='model.dto.city']//div/span")
    WebElement CITY_VALUE_XPATH;

    @FindBy(xpath = "//*[@model='model.dto.state']//div/span")
    WebElement STATE_VALUE_XPATH;

    @FindBy(xpath = "//*[@model='model.dto.postalCode']//div/span")
    WebElement ZIPCODE_VALUE_XPATH;
    
    @FindBy(css = "[model='address.postalCode'] input")
    WebElement ZIPCODE_TXT_CSS;
    
    @FindBy(css = "[model='address.state'] select")
    WebElement STATE_DROP_CSS;
    
    @FindBy(css = "[model='address.city'] input")
    WebElement CITY_TXT_CSS;
    
    @FindBy(css = "[model='address.addressLine1'] input")
    WebElement STREET_TXT_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-quote-edit-state='1'] [class*='complete']")
    WebElement ADDRESS_COMPLETE_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-address-list-state-create-new-button]")
    WebElement ADD_NEW_ADD_BTN_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-address-address-input-state-addline1-input'] input")
    WebElement ADDLINE1_TXT_CSS;
    
    @FindBy(css = "[gw-test-quoteandbind-quickquote-pa-quick-address-address-input-state-address-save-button]")
    WebElement CHECK_ADDRESS_CSS;

    @FindBy(css = "div.gw-error-text.ng-binding")
    WebElement ERR_ZIP_CODE;


    private static final String Address = "Hillsdale";

    public AddressSection() {
        seleniumCommands.pageWebElementLoader(this);
    }

    //Set Methods

    public AddressSection setAddress() {
        seleniumCommands.logInfo("Setting Address Details");
        seleniumCommands.type(ADDRESS_TXT_CSS,Address);
        return this;
    }

    public AddressSection setAddress(String address) {
        seleniumCommands.logInfo("Setting Address Details");
        seleniumCommands.type(ADDRESS_TXT_CSS,address);
        return this;
    }

    public AddressSection setAddressDetails() {
        seleniumCommands.logInfo("Setting Address Details");
        this.setAddress().searchAddress1().selectFirstAddress();
        return this;
    }
    
    public AddressSection addNewAddress() {
        seleniumCommands.logInfo("Setting Address Details");
        this.setAddress().searchAddress().enterNewAddressData().saveAddress();
        return this;
    }
    
    public AddressSection setZipCode() {
        seleniumCommands.logInfo("Setting zip code");
        seleniumCommands.type(ZIPCODE_TXT_CSS, data.get("ZipCode"));
        return this;
    }
    
    public AddressSection setState() {
        seleniumCommands.logInfo("Setting zip code");
        seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("State"));
        return this;
    }
    
    public AddressSection setCity() {
        seleniumCommands.logInfo("Setting zip code");
        seleniumCommands.type(CITY_TXT_CSS, data.get("City"));
        return this;
    }
    
    public AddressSection setStreet() {
        seleniumCommands.logInfo("Setting zip code");
        seleniumCommands.type(STREET_TXT_CSS, data.get("Street"));
        seleniumCommands.click(CITY_TXT_CSS);
        return this;
    }

    // Get Methods
    private String getAddressFirstSearchResults()
    {
        seleniumCommands.logInfo("Getting the first result for Address");
        return seleniumCommands.getTextAtLocator(ADDRESS_FIRST_RESULT_CSS);
    }

    private String getStreet()
    {
        seleniumCommands.logInfo("Getting Street");
        return seleniumCommands.getValueAttributeFromLocator(STREET_TXT_CSS);
    }

    private String getCity()
    {
        seleniumCommands.logInfo("Getting City");
        return seleniumCommands.getValueAttributeFromLocator(CITY_TXT_CSS);
    }

    private String getState()
    {
        seleniumCommands.logInfo("Getting State");
        return seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS);
    }

    private String getZipCode()
    {
        seleniumCommands.logInfo("Getting Zip Code");
        return seleniumCommands.getValueAttributeFromLocator(ZIPCODE_TXT_CSS);
    }

    //Methods

    public AddressSection searchAddress1() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.logInfo("Searching for Address Btn");
        //seleniumCommands.clickbyJS(SEARCH_BTN);
        return this;
    }

    public String zipCodeErrorMsg(){
        return ERR_ZIP_CODE.getText();
    }


    public AddressSection clickAddressNotInList() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.logInfo("Click Address Not In List");
        seleniumCommands.clickbyJS(ADDRESS_NOT_IN_LIST_BTN);
        return this;
    }

    public AddressSection clickBackToAddressSearch() {
        seleniumCommands.logInfo("Going back to address search");
        seleniumCommands.clickbyJS(BACK_TO_SEARCH_ADDRESS);
        seleniumCommands.waitForElementToBeVisible(ADDRESS_TXT_CSS);
        return this;
    }
    
    public AddressSection searchZipCode() {
        seleniumCommands.logInfo("Click Address Not In List");
        seleniumCommands.type(zipCode, "94404");
        return this;
    }

    public AddressSection addStreet(String streetName){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(SEARCH_STREET_TXT_BAR, streetName);
        seleniumCommands.click(ADDRESS_SUBMIT_BTN);
        return this;
    }

    public AddressSection clickEditBtn() {
        seleniumCommands.logInfo("Click Edit Btn");
        seleniumCommands.clickbyJS(EDIT_BTN);
        return this;
    }

    public AddressSection editCityAddress() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.logInfo("Edit City Address");
        seleniumCommands.type(CITY_FIELD_TXT_BTN, "New Foster City");
        seleniumCommands.click(ADDRESS_SUBMIT_BTN);
        return this;
    }



    public AddressSection searchAddress() {
        seleniumCommands.logInfo("Searching for Address");
        seleniumCommands.clickbyJS(SEARCH_ADDRESS_BTN_CSS);
        seleniumCommands.waitForElementToBeVisible(ADDRESS_FIRST_RESULT_CSS);
        return this;
    }

    public AddressSection selectFirstAddress() {
        seleniumCommands.logInfo("Selecting first Address from the list");
        seleniumCommands.clickbyJS(ADDRESS_FIRST_RESULT_CSS);
        seleniumCommands.waitForElementToBeVisible(LOCATION_CSS);
        return this;
    }
    
    public AddressSection enterNewAddressData() {
        seleniumCommands.logInfo("Adding new Address");
        seleniumCommands.clickbyJS(ADD_NEW_ADD_BTN_CSS);
        seleniumCommands.type(ZIPCODE_TXT_CSS, data.get("ZipCode"));
        seleniumCommands.type(ADDLINE1_TXT_CSS, data.get("AddressLine1"));
        return this;
    }
    
    public AddressSection saveAddress() {
        seleniumCommands.logInfo("Selecting check button for saving new Address");
        seleniumCommands.clickbyJS(CHECK_ADDRESS_CSS);
        seleniumCommands.waitForElementToBeVisible(ZIPCODE_VALUE_XPATH);
        return this;
    }
    
    //Validation
    
    public void isAddressSectionComplete() {
        seleniumCommands.logInfo( "Validating if Address Section is Complete ");
        seleniumCommands.waitForElementToBeVisible(ADDRESS_COMPLETE_CSS);
        new Validation(seleniumCommands.isElementPresent(ADDRESS_COMPLETE_CSS)).shouldBeTrue("Address data was not completed");
    }
    
    public void validateAddressManualEntryFormDisplayed() {
        seleniumCommands.logInfo( "Validating if Address entry form is displayed");
        seleniumCommands.waitForElementToBeVisible(BACK_TO_SEARCH_ADDRESS);
        new Validation(seleniumCommands.isElementPresent(ZIPCODE_TXT_CSS)).shouldBeTrue("Zip code field is not displayed");
        new Validation(seleniumCommands.isElementPresent(STATE_DROP_CSS)).shouldBeTrue("State field is not displayed");
        new Validation(seleniumCommands.isElementPresent(CITY_TXT_CSS)).shouldBeTrue("City field is not displayed");
        new Validation(seleniumCommands.isElementPresent(STREET_TXT_CSS)).shouldBeTrue("Stree field is not displayed");
    }
    
    public void validateAddressManualEntryFormData() {
        seleniumCommands.logInfo( "Validating if Address entry form is displayed");
        seleniumCommands.waitForElementToBeVisible(BACK_TO_SEARCH_ADDRESS);
    }
    
    public void validateAddressData() {
        seleniumCommands.logInfo( "Validating address value");
        new Validation(this.getCity(), data.get("City")).shouldBeEqual("City is not correct");
        new Validation(this.getStreet(), data.get("Street")).shouldBeEqual("Street is not correct");
        new Validation(this.getState(), data.get("State")).shouldBeEqual("State is not correct");
        new Validation(this.getZipCode(), data.get("ZipCode")).shouldBeEqual("ZipCode is not correct");
    }
}
