package com.guidewire.portals.qnb.pages;


import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.HashMap;

public class BOPAdditionalCoveragesPage extends CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(xpath = "(//gw-pc-editable-coverages//label)[2]")
    WebElement CHECKBX_GUEST_PROP_CVG_XPATH;

    @FindBy(css = "[gw-test-policycommon-editablecoverages-editablecoverages='Guest Property - Safe Deposit Limit'] select")
    WebElement SELECT_GUEST_PROP_CVG_CSS;

    @FindBy(css = "[id='BOPCertTerrorCapLimit']")
    WebElement TERROR_ADDTNL_CVG_INPUT_CSS;

    @FindBy(xpath = "//div[@id='BOPDesigPremProj']/div/label")
    WebElement CONTRACTORS_DESIGNATED_PREMISES;

    @FindBy(xpath = "//div[@id='BOPY2KLimitedCov']/div/label")
    WebElement LIABILITY_OTHER_COMPUTER_LTD_LIA_COV;

    @FindBy(xpath = "//div[@id='BOPEmpBenefits']/div/label")
    WebElement LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY;

    @FindBy(xpath = "//input[@id='BOPEmpBenEachEmpLim']")
    WebElement LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY_EMP_TXT;

    @FindBy(xpath = "//input[@id='BOPEmpBenAggLim']")
    WebElement LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY_AGE_LMT_TXT;

    @FindBy(xpath = "//ng-datepicker[@id='BOPEmpBenRetroDate']/div/input")
    WebElement LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY_RETROACTIVE_DATE;

    @FindBy(xpath = "//div[@id='BOPY2KPremOnlyCov']/div/label")
    WebElement LIABILITY_OTHER_COMPUTER_LIA_PREMISES_ONLY;

    @FindBy(xpath = "//div[@id='BOPComputerFraudCov']/div/label")
    WebElement CRIME_COMPUTER_FUNDS;

    @FindBy(xpath = "//div[@id='BOPLiquorEvents']/div/label")
    WebElement LIQUOR_LIABILITY_EVENT_ONLY;

    @FindBy(xpath = "//ng-datepicker[@id='LiqLiabEventDate']/div/input")
    WebElement LIQUOR_LIABILITY_EVENT_DATE;

    @FindBy(xpath = "//textarea[@id='LiqLiabEventsDescription']")
    WebElement LIQUOR_LIABILITY_EVENT_DESC;

    @FindBy(xpath = "//div[@id='BOPLiquorCov']/div/label")
    WebElement LIQUOR_LIABILITY_COVERAGE;

    @FindBy(xpath = "//input[@id='BOPLiquorAggLim']")
    WebElement LIQUOR_LIABILITY_COVERAGE_AGE_LMT;

    @FindBy(xpath = "//div[@id='BOPFDService']/div/label")
    WebElement POLICY_WIDE_FD_SERVICE_CONTRACT;

    @FindBy(xpath = "//div[@id='BusIncChangeCov']/div/label")
    WebElement POLICY_WIDE_BUS_WAITING_PERIOD;

    @FindBy(xpath = "//div[@id='BOPBarberCov']/div/label")
    WebElement PROF_OCC_BARBER_BEAUTICIAN_LIA;

    @FindBy(xpath = "//input[@id='BOPBarberBeautNum']")
    WebElement PROF_OCC_BARBER_BEAUTICIAN_LIA_COUNT_TXT;

    @FindBy(xpath = "//div[@id='BOPFuneralDirCov']/div/label")
    WebElement PROF_OCC_FUNERAL_DIRECTOR_LIA;

    @FindBy(xpath = "//input[@id='BOPFuneralDirNum']")
    WebElement PROF_OCC_FUNERAL_DIRECTOR_LIA_COUNT_TXT;

    @FindBy(xpath = "//div[@id='BOPCertTerrorCap']/div/label")
    WebElement TERRORISM_TERROR_CAP;

    @FindBy(xpath = "//input[@id='BOPCertTerrorCapLimit']")
    WebElement TERRORISM_TERROR_CAP_AGE_LMT_TXT;

    @FindBy(xpath = "//button[@ng-show='showNestedButton']")
    WebElement NESTED_BTN;

    @FindBy(xpath = "//ng-datepicker//div")
    WebElement DATE_PICKER_RETRO;

    @FindBy(xpath = " //*[@id='LiqLiabEventDate']")
    WebElement DATE_PICKER_EVENT;

    @FindBy(xpath = "//ng-datepicker[@id='BOPEmpBenRetroDate']/div/div[3]/div/table/tbody/tr[2]/td[5]")
    WebElement SELECT_DATA_RETRO;

    @FindBy(xpath="//ng-datepicker[@id='BOPEmpBenRetroDate']/div/div[3]/div/table/tbody/tr/td/span[3]")
    WebElement SELECT_TIME_RETRO;

    @FindBy(xpath = "//ng-datepicker[@id='LiqLiabEventDate']/div/div[3]/div/table/tbody/tr[2]/td[5]")
    WebElement SELECT_DATA_EVENT;

    @FindBy(xpath="//ng-datepicker[@id='LiqLiabEventDate']/div/div[3]/div/table/tbody/tr/td/span[3]")
    WebElement SELECT_TIME_EVENT;

    public BOPAdditionalCoveragesPage()    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public BOPAdditionalCoveragesPage setGuestPropertyInSafeDepositCoverage(){
        seleniumCommands.waitForElementToBeVisible(CHECKBX_GUEST_PROP_CVG_XPATH);
        seleniumCommands.clickbyJS(CHECKBX_GUEST_PROP_CVG_XPATH);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(SELECT_GUEST_PROP_CVG_CSS);
        seleniumCommands.selectDropDownValueByText(SELECT_GUEST_PROP_CVG_CSS, data.get("GuestPropSafeDepositLimit"));
        return this;
    }

    public BOPAdditionalCoveragesPage setAdditionalCoveragesSavingPoint(){
        seleniumCommands.waitForElementToBeVisible(CHECKBX_GUEST_PROP_CVG_XPATH);
        seleniumCommands.clickbyJS(CONTRACTORS_DESIGNATED_PREMISES);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(LIABILITY_OTHER_COMPUTER_LTD_LIA_COV);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY_EMP_TXT, "50");
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.typeByJS(LIABILITY_OTHER_EMPLOYEE_BENENITS_LIABILITY_AGE_LMT_TXT, "25");
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.clickbyJS(DATE_PICKER_RETRO);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SELECT_DATA_RETRO);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SELECT_TIME_RETRO);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(LIABILITY_OTHER_COMPUTER_LIA_PREMISES_ONLY);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(CRIME_COMPUTER_FUNDS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(LIQUOR_LIABILITY_EVENT_ONLY);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(DATE_PICKER_EVENT);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SELECT_DATA_EVENT);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SELECT_TIME_EVENT);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.typeByJS(LIQUOR_LIABILITY_EVENT_DESC, "Event Description: For August");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.clickbyJS(LIQUOR_LIABILITY_COVERAGE);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.typeByJS(LIQUOR_LIABILITY_COVERAGE_AGE_LMT, "25");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.clickbyJS(POLICY_WIDE_FD_SERVICE_CONTRACT);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(POLICY_WIDE_BUS_WAITING_PERIOD);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(PROF_OCC_BARBER_BEAUTICIAN_LIA);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.typeByJS(PROF_OCC_BARBER_BEAUTICIAN_LIA_COUNT_TXT, "100");
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(PROF_OCC_FUNERAL_DIRECTOR_LIA);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.typeByJS(PROF_OCC_FUNERAL_DIRECTOR_LIA_COUNT_TXT, "100");
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(TERRORISM_TERROR_CAP);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.typeByJS(TERRORISM_TERROR_CAP_AGE_LMT_TXT, "30");
        seleniumCommands.clickbyJS(NESTED_BTN);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }



    //Validation Methods

    public void isGuestPropertySafeDepositSelected(){
        seleniumCommands.waitForElementToBeVisible(SELECT_GUEST_PROP_CVG_CSS);
        if(data.get("POLICY_NUM")!=null) {
            String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
            HashMap<String, String> lineCoverages = ParseEndorsementData.getBOPLineAdditionalCoveragesForPolicyChange(jsonData);
            new Validation(lineCoverages.get("Guest_Prop_Safe_deposit_Selected"), "true").shouldBeEqual("Guest Property In Safe Deposit wasn't selected in backend");
        }
        seleniumCommands.scrollTo(SELECT_GUEST_PROP_CVG_CSS);
        new Validation(seleniumCommands.isElementVisible(SELECT_GUEST_PROP_CVG_CSS)).shouldBeTrue("Guest Property In Safe Deposit wasn't selected");
    }

    public void validateGuestPropSafeDepositLimitInBackend() {
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParseEndorsementData.getBOPLineAdditionalCoveragesForPolicyChange(jsonData);
        new Validation(lineCoverages.get("Guest_Prop_Safe_deposit_Limit"), data.get("GuestPropSafeDepositLimit").replace(",","")).shouldBeEqual("Guests Property In Safe Deposit Limit didn't match");
    }

    public String getPolicyChangeDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

    public void validateTerrorSelectedAndEmpty(){
        new Validation(seleniumCommands.isElementPresent(TERROR_ADDTNL_CVG_INPUT_CSS)).shouldBeTrue("Terror - Cap On Cert. Acts is not selected");
        new Validation(seleniumCommands.getTextAtLocator(TERROR_ADDTNL_CVG_INPUT_CSS), "").shouldBeEqual("Aggregate Limit isn't empty for Terrorism");
    }
}
