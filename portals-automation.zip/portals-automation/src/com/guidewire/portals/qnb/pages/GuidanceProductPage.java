package com.guidewire.portals.qnb.pages;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.Button;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Created by dfedo on 07/06/2017.
 */
public class GuidanceProductPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();

    By WHAT_YOUR_BUSINESS_TEXT_FIELD = By.cssSelector("[result='industryCode.value'] textarea");
    By BUSINESS_DESCRIPTION_DROPDOWNLIST = By.cssSelector("[result='industryCode.value'] ul[class*='gw-dropdown-menu']");
    By BUSINESS_DESCRIPTION_DROPDOWNLIST_VALUES = By.cssSelector("[result='industryCode.value'] ul[class*='gw-dropdown-menu'] li span");
    By CONTINUE_BUTTON = By.cssSelector("button[ng-click='continueToNextPanel()']");
    By CONTINUE_BUTTON_DISABLED = By.cssSelector("button[ng-click='continueToNextPanel()']:disabled");

    By ADDRESS_TEXT_FIELD = By.cssSelector("[result='address.value'] textarea");
    By ADDRESS_DROPDOWNLIST = By.cssSelector("[result='address.value'] ul[class*='gw-dropdown-menu']");
    By ADDRESS_DROPDOWNLIST_VALUES = By.cssSelector("[result='address.value'] ul[class*='gw-dropdown-menu'] li div[title]");
    By GET_QUOTE_BUTTON = By.cssSelector("[class*='GuidanceRecommendations'] button");
    By MY_ADDRESS_ISNT_IN_LIST_LINK = By.cssSelector("a[ng-click='switchToManualEntryMode()']");
    String BUSINESS_MODEL = "//div[contains(text(),'%s')]/./preceding-sibling::label";
    By BUSINESS_MODEL_CHECKBOXES = By.cssSelector("gw-multi-select label");
    By BUSINESS_MODEL_LABEL = By.cssSelector("[id*='multiselect-item-text']");
    By BUSINESS_MODEL_LINE = By.cssSelector("[class*='row_container']");
    By ADDRESS_LINE1_TEXT_FIELD = By.cssSelector("[model='address.addressLine1'] input");
    By ADDRESS_LINE2_TEXT_FIELD = By.cssSelector("[model='address.addressLine2'] input");
    By ADDRESS_LINE3_TEXT_FIELD = By.cssSelector("[model='address.addressLine3'] input");
    By CITY_TEXT_FIELD = By.cssSelector("[model='address.city'] input");
    By ZIP_CODE_TEXT_FIELD = By.cssSelector("[model='address.postalCode'] input");
    By STATE_FIELD = By.cssSelector("[model='address.state'] select");
    By SUMMARY_FORM_ADDRESS_VALUES = By.cssSelector("gw-pl-address-summary div");

    String PRODUCT_OFFERING_ICON = "i[class*='fa-%s']";
    By PRODUCT_OFFERING_HEADER_TEXT = By.cssSelector("gw-guidance-recommendations-panel p");
    By PRODUCT_OFFERING_PLACEHOLDER_IMAGE = By.cssSelector("[class='gw-gtp-option-area'] img");
    By PRODUCT_OFFERING_INFO_HEADER = By.cssSelector("[class='gw-gtp-option-area'] div[class*='InfoHeader']");
    By PRODUCT_OFFERING_TALK_TO_AGENT_BUTTON = By.cssSelector("[class='gw-gtp-option-area'] button[class='gw-btn-primary']");
    By BACK_TO_SEARCH_LINK = By.cssSelector("a[ng-click='switchToSearch()']");

    By QUESTION_ICON = By.cssSelector("i[class='fa fa-question-circle']");
    
    By PRODUCT_OFFERING_ITEM = By.cssSelector("[model*='selectItem.model']");

    By EDIT_ADDRESS_BUTTON = By.cssSelector("[address='model.userAddress'] [on-click='onClick()']");

    private static String PRODUCT_OFFERING_INFO_HEADER_XPATH = "//div[@class='gw-gtp-option-area']//div[contains(@class,'InfoHeader')]";
    private static String placeHolderImageBusinessowner = "businessowner.svg";
    private static String placeHolderImageWorkerscompensation = "workerscomp.svg";
    private static String placeHolderImageCommercialAuto = "commauto.svg";

    public GuidanceProductPage typeWhatBusinessAreYouIn(){
        seleniumCommands.logInfo("Filling business description field and choosing from existing choices.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(WHAT_YOUR_BUSINESS_TEXT_FIELD,data.get("BUSINESS_DESCRIPTION"));
        seleniumCommands.waitForElementToBeVisible(BUSINESS_DESCRIPTION_DROPDOWNLIST);
        seleniumCommands.staticWait(3);
        for (WebElement element:seleniumCommands.findElements(BUSINESS_DESCRIPTION_DROPDOWNLIST_VALUES)) {
            if (element.getText().contains(data.get("BUSINESS_DESCRIPTION")))
                element.click();
        }
        return this;
    }

    public GuidanceProductPage clickContinueButton(){
        seleniumCommands.logInfo("Clicking Continue button");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Button(seleniumCommands.findElement(CONTINUE_BUTTON)).click();
        return this;
    }

    public GuidanceProductPage clickBackToSearchLink(){
        seleniumCommands.logInfo("Clicking back to search link");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Button(seleniumCommands.findElement(BACK_TO_SEARCH_LINK)).click();
        return this;
    }

    public GuidanceProductPage clickEditAddressButton(){
        seleniumCommands.logInfo("Clicking edit address button");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Button(seleniumCommands.findElement(EDIT_ADDRESS_BUTTON)).click();
        return this;
    }

    public YourInfoPage clickGetQuoteButton(){
        seleniumCommands.logInfo("Clicking Get Quote button");
        seleniumCommands.waitForElementToBeClickable(GET_QUOTE_BUTTON);
        new Button(seleniumCommands.findElement(GET_QUOTE_BUTTON)).click();
        return new YourInfoPage();
    }

    public GuidanceProductPage typeBusinessAddress(){
        seleniumCommands.logInfo("Typing Business addres and chosing it from list of suggestions .");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(ADDRESS_TEXT_FIELD,data.get("BUSINESS_ADDRESS"));
        seleniumCommands.waitForElementToBeVisible(ADDRESS_DROPDOWNLIST);
        for (WebElement element:seleniumCommands.findElements(ADDRESS_DROPDOWNLIST_VALUES))
        {
            if (element.getText().equals(data.get("BUSINESS_ADDRESS_EXPECTED"))){
                element.click();
                return this;
            }
        }
        return this;
    }

    public GuidanceProductPage clickMyAddressIsntInTheListLink(){
        seleniumCommands.logInfo("Clicking My Address Isnt In TheList Link.");
        new Button(seleniumCommands.findElement(MY_ADDRESS_ISNT_IN_LIST_LINK)).click();
        return this;
    }

    public GuidanceProductPage checkBusinessModelCheckbox(){
        seleniumCommands.logInfo("Checking business model checkbox.");
        String businessModel = ThreadLocalObject.getData().get("BUSINESS_MODEL");
        seleniumCommands.waitForElementToBeClickable(By.xpath(String.format(BUSINESS_MODEL,businessModel)));
        seleniumCommands.findElement(By.xpath(String.format(BUSINESS_MODEL,businessModel))).click();
        return this;
    }

    public GuidanceProductPage checkAllBusinessModelCheckboxes(){
        seleniumCommands.logInfo("Checking all business model checkboxes.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(BUSINESS_MODEL_CHECKBOXES);
        for (WebElement checkbox : seleniumCommands.findElements(BUSINESS_MODEL_CHECKBOXES)){
            checkbox.click();
        }
        return this;
    }

    public GuidanceProductPage validateAddressMandatoryFieldsAreFilled(){
        seleniumCommands.logInfo("Filling address field and choosing from existing choices.");
        String addressLine1 = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(",")[0];
        String city = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[1];
        String zip = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[3];
        String state = ThreadLocalObject.getData().get("State");

        new Validation(addressLine1, seleniumCommands.getValueAttributeFromLocator(seleniumCommands.findElement(ADDRESS_LINE1_TEXT_FIELD))).shouldBeEqual("Address Line1 doesn't match expected");
        new Validation(city, seleniumCommands.getValueAttributeFromLocator(seleniumCommands.findElement(CITY_TEXT_FIELD))).shouldBeEqual("City doesn't match expected");
        new Validation(zip, seleniumCommands.getValueAttributeFromLocator(seleniumCommands.findElement(ZIP_CODE_TEXT_FIELD))).shouldBeEqual("ZIP code doesn't match expected");
        new Validation(state, seleniumCommands.getSelectedOptionFromDropDown(seleniumCommands.findElement(STATE_FIELD))).shouldBeEqual("State code doesn't match expected");
        return this;
    }

    public GuidanceProductPage fillAddressMandatoryFieldsInAddressForm(){
        seleniumCommands.logInfo("Filling address fields in address form.");
        String addressLine1 = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(",")[0];
        String city = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[1];
        String zip = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[3];
        String state = ThreadLocalObject.getData().get("State");

        seleniumCommands.type(ADDRESS_LINE1_TEXT_FIELD,addressLine1);
        seleniumCommands.type(CITY_TEXT_FIELD,city);
        seleniumCommands.type(ZIP_CODE_TEXT_FIELD,zip);
        seleniumCommands.selectDropDownValueByText(STATE_FIELD,state);
        return this;
    }
    public GuidanceProductPage fillAddressMandatoryFieldsInAddressForm(String addressLine1, String addressLine2, String addressLine3, String city, String zip){
        seleniumCommands.logInfo("Filling address fields in address form.");
        seleniumCommands.type(ADDRESS_LINE1_TEXT_FIELD,addressLine1);
        seleniumCommands.type(ADDRESS_LINE2_TEXT_FIELD,addressLine2);
        seleniumCommands.type(ADDRESS_LINE3_TEXT_FIELD,addressLine3);
        seleniumCommands.type(CITY_TEXT_FIELD,city);
        seleniumCommands.type(ZIP_CODE_TEXT_FIELD,zip);
        seleniumCommands.selectDropDownValueByText(STATE_FIELD,data.get("State"));
        return this;
    }

    public GuidanceProductPage validateBusinessModelIcons(String typeOfModel) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<String> icons = null;
        switch (typeOfModel){
            case "Services":
                icons = Arrays.asList("plane", "compass", "phone", "building", "users", "money", "archive", "keyboard-o");
                break;
            case "Other":
                icons = Arrays.asList("truck", "building", "barcode", "plane", "users", "phone", "compass");
                break;
            case "Construction":
                icons = Arrays.asList("truck", "desktop", "barcode","building","plane","money", "users","hand-paper-o");
                break;
            case "Retail":
                icons = Arrays.asList("truck", "building", "barcode", "plane", "users", "desktop", "money", "archive");
                break;
        }
        for(String icon: icons){
            new Validation(seleniumCommands.isElementPresent(By.cssSelector(String.format(PRODUCT_OFFERING_ICON, icon)))).shouldBeTrue(icon + " icon is not present on the page");
        }
        return this;
    }


    public GuidanceProductPage validateAllBusinessModelSummaryBlocks(Boolean withCommercialAuto){
        seleniumCommands.logInfo("Validate all business model icons.");
        seleniumCommands.waitForElementToBeVisible(By.xpath(PRODUCT_OFFERING_INFO_HEADER_XPATH));
        new Validation(seleniumCommands.getTextAtLocator(PRODUCT_OFFERING_HEADER_TEXT).contains(DataConstant.GTP_PRODUCT_OFFERING_HEADER_TEXT)).shouldBeTrue("Header text doesn't match expected");
        validateProductSummaryBlock(placeHolderImageBusinessowner,DataConstant.PRODUCT_CODE_BUSINESSOWNER).shouldBeTrue("Businessowner summary block was not found");
        if (withCommercialAuto) {
            validateProductSummaryBlock(placeHolderImageCommercialAuto, DataConstant.PRODUCT_CODE_COMMERCIAL_AUTO).shouldBeTrue("Comercial Auto summary block was not found");
        }
        validateProductSummaryBlock(placeHolderImageWorkerscompensation,DataConstant.PRODUCT_CODE_WORKERS_COMPENSATION).shouldBeTrue("Worker's compensation summary block was not found");
        return this;
    }

    private Validation validateProductSummaryBlock(String placeHolderImage, String productCode){
        seleniumCommands.logInfo("Validate " + productCode+ " summary block.");
        seleniumCommands.waitForElementToBeVisible(By.xpath(PRODUCT_OFFERING_INFO_HEADER_XPATH));
        for(WebElement element : seleniumCommands.findElements(By.xpath(PRODUCT_OFFERING_INFO_HEADER_XPATH))){
            if(element.getText().equals(productCode)){
                new Validation(seleniumCommands.getAttributeValueAtLocator(element.findElement(By.xpath("../preceding-sibling::img")),"src").contains(placeHolderImage)).shouldBeTrue("Image placeholder is not correct");
                new Validation(seleniumCommands.isElementPresent(element.findElement(By.xpath("./following-sibling::div/button[@class='gw-btn-primary']")))).shouldBeTrue("Button is missing");
                return new Validation(true);
            }
        }
        return new Validation(false);
    }

    public GuidanceProductPage validateAddressOnSummaryForm(){
        seleniumCommands.logInfo("Validating Address in summary form.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String addressLine1 = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(",")[0];
        String city = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[1];
        String zip = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[3];
        String state = ThreadLocalObject.getData().get("BUSINESS_ADDRESS_EXPECTED").split(", ")[2];
        seleniumCommands.staticWait(4);
        List<WebElement> addressValues = seleniumCommands.findElements(SUMMARY_FORM_ADDRESS_VALUES);
        new Validation(addressLine1, addressValues.get(0).getText()).shouldBeEqual("Address Line1 doesn't match expected");
        new Validation(city, addressValues.get(3).getText()).shouldBeEqual("City doesn't match expected");
        new Validation(state, addressValues.get(4).getText()).shouldBeEqual("state doesn't match expected");
        new Validation(zip, addressValues.get(5).getText()).shouldBeEqual("Zip doesn't match expected");
        return this;
    }

    public GuidanceProductPage validateEditedAddressOnSummaryForm(String addressLine1, String addressLine2, String addressLine3, String city, String state, String zip){
        seleniumCommands.logInfo("Validating Address in summary form.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<WebElement> addressValues = seleniumCommands.findElements(SUMMARY_FORM_ADDRESS_VALUES);
        new Validation(addressLine1, addressValues.get(0).getText()).shouldBeEqual("Address Line1 doesn't match expected");
        new Validation(addressLine2, addressValues.get(1).getText()).shouldBeEqual("Address Line2 doesn't match expected");
        new Validation(addressLine3, addressValues.get(2).getText()).shouldBeEqual("Address Line3 doesn't match expected");
        new Validation(city, addressValues.get(3).getText()).shouldBeEqual("City doesn't match expected");
        new Validation(state, addressValues.get(4).getText()).shouldBeEqual("state doesn't match expected");
        new Validation(zip, addressValues.get(5).getText()).shouldBeEqual("Zip doesn't match expected");
        return this;
    }

    public GuidanceProductPage validateProductOfferingSection(){
        seleniumCommands.logInfo("Validating Product Offering section elements.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String businessModel = ThreadLocalObject.getData().get("BUSINESS_MODEL");
        String icon = "";
        switch (businessModel){
            case "Business Property" :
                icon = "building";
                validateProductSummaryBlock(placeHolderImageBusinessowner,DataConstant.PRODUCT_CODE_BUSINESSOWNER).shouldBeTrue("There is no Businessowner auto block");
                break;
            case "Van or Truck" :
                icon = "truck";
                validateProductSummaryBlock(placeHolderImageCommercialAuto,DataConstant.PRODUCT_CODE_COMMERCIAL_AUTO).shouldBeTrue("There is no Comercial auto block");
            break;
            case "Employees" :
                icon = "users";
                validateProductSummaryBlock(placeHolderImageWorkerscompensation,DataConstant.PRODUCT_CODE_WORKERS_COMPENSATION).shouldBeTrue("There is no Workers compensation block");
               break;
        }
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(String.format(PRODUCT_OFFERING_ICON,icon)))).shouldBeTrue("Icon is not present on the page");
        new Validation(seleniumCommands.getTextAtLocator(PRODUCT_OFFERING_HEADER_TEXT).contains(DataConstant.GTP_PRODUCT_OFFERING_HEADER_TEXT)).shouldBeTrue("Header text doesn't match expected");
        return this;
    }

    public Validation isContinueButtonDisabled(){
        seleniumCommands.logInfo("Checking if continue button is disabled");
        seleniumCommands.waitForElementToBePresent(CONTINUE_BUTTON_DISABLED);
        return new Validation(seleniumCommands.getAttributeValueAtLocator(CONTINUE_BUTTON_DISABLED, "disabled"),"true");
    }


    public Validation validateGuidanceBusinessDescriptionLine(String businessModelText){
        seleniumCommands.logInfo("Validating guidance business description line");
        for (WebElement element : seleniumCommands.findElements(BUSINESS_MODEL_LINE)){
            if(element.findElement(BUSINESS_MODEL_LABEL).getText().contains(businessModelText)){
                new Validation(seleniumCommands.isElementPresent(element.findElement(QUESTION_ICON))).shouldBeTrue("Question icon for " + businessModelText+ " is not presented");
                new Validation(seleniumCommands.isElementPresent(element.findElement(BUSINESS_MODEL_CHECKBOXES))).shouldBeTrue("Checkbox for "+ businessModelText+ " is not presented");
                return new Validation(true);
            }
        }
       return new Validation(false);
    }

    public void validateAllPlumbingBusinessLines(){
        validateAllBaseBusinessLines();
        validateGuidanceBusinessDescriptionLine("Business Contents").shouldBeTrue("Business Contents descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Van or Truck").shouldBeTrue("Van or Truck descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Manual Work").shouldBeTrue("Manual Work descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Stock").shouldBeTrue("Stock descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Regular Payments").shouldBeTrue("Regular Payments descriptions is missing");
    }

    public void validateAllFurnitureBusinessLines(){
        validateAllBaseBusinessLines();
        validateGuidanceBusinessDescriptionLine("Business Contents").shouldBeTrue("Business Contents descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Van or Truck").shouldBeTrue("Van or Truck descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Store Things").shouldBeTrue("Store Things descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Stock").shouldBeTrue("Stock descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Regular Payments").shouldBeTrue("Regular Payments descriptions is missing");
    }

    public void validateAllRecreationalServiceLines(){
        validateAllBaseBusinessLines();
        validateGuidanceBusinessDescriptionLine("Provide Advice").shouldBeTrue("Provide Advice descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Store Documents").shouldBeTrue("Store Documents descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Business Equipment").shouldBeTrue("Business Equipment descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Regular Payments").shouldBeTrue("Regular Payments descriptions is missing");
    }

    public void validateAllPoliceProtectionLines(){
        validateAllBaseBusinessLines();
        validateGuidanceBusinessDescriptionLine("Provide Advice").shouldBeTrue("Provide Advice descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Provide a Service").shouldBeTrue("Provide a Service descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Van or Truck").shouldBeTrue("Van or Truck descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Stock").shouldBeTrue("Stock descriptions is missing");

    }

    public void validateAllBaseBusinessLines(){

        validateGuidanceBusinessDescriptionLine("Employees").shouldBeTrue("Employees descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Business Property").shouldBeTrue("Business Property descriptions is missing");
        validateGuidanceBusinessDescriptionLine("Visitors or Visiting").shouldBeTrue("Visitors or Visiting descriptions is missing");
    }

}
