package com.guidewire.portals.qnb.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.locators.CommonPageLocators;

public abstract class CommonPage extends CommonScenario
{
	@FindBy(css = "[on-click='goToCancel()'], [ng-click='cancel()']")
	 WebElement CANCEL_QUOTE_BTN_CSS;

	@FindBy(css = "[class*='gw-fade'] [ng-click*='close'] ")
	WebElement CONFIRM_CANCEL_BUTTON;
	
	@FindBy(css = "button[ng-click='cancel()']")
	WebElement CANCEL_DRIVER_VEH_BUTTON;

	@FindBy(css = "div[class*='gw-header'] a[href*='home']")
	WebElement HOME_BTN_CSS;

	String ASTERISK_CSS = "[model*='MODEL'] [class*='asterisk'], [label='LABEL'] [class*='asterisk']";
	
	public Pagefactory getPageFactory()
	{
		return new Pagefactory();
	}
	

	public ZipCodePage pressCancel()
	{
		CANCEL_QUOTE_BTN_CSS.click();
		return new Pagefactory().getZipCodePage();
	}
	
	public CommonPage pressCancelOnVehicleDriverPage()
	{
		seleniumCommands.click(CANCEL_QUOTE_BTN_CSS);
		return this;
	}

	public CommonPage pressCancelGPA(){
		CANCEL_QUOTE_BTN_CSS.click();
		return this;
	}

	public QuoteSummary confirmCancel(){
		seleniumCommands.waitForElementToBeVisible(CONFIRM_CANCEL_BUTTON);
		CONFIRM_CANCEL_BUTTON.click();
		return new QuoteSummary();
	}
	
	public Object pressCancelAndConfirm(){
		seleniumCommands.clickbyJS(CANCEL_QUOTE_BTN_CSS);
		seleniumCommands.clickbyJS(CONFIRM_CANCEL_BUTTON);
		return new Object();
	}

	public CommonPage clickNext()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		clickButton(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}
	
	public Validation isNextButtonDisabled()
	{
		seleniumCommands.waitForElementToBePresent(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return new Validation(seleniumCommands.getAttributeValueAtLocator(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS), "disabled"), "true");
	}

	public void clickButton(By locator) {
		seleniumCommands.waitForElementToBeClickable(locator);
		seleniumCommands.waitForElementToBeEnabled(locator);
		if (browserType.equals(BrowserType.IPHONE6) || browserType.equals(BrowserType.IPHONE6S)) {
			seleniumCommands.click(locator);
		} else {
			seleniumCommands.clickbyJS(locator);
		}
	}

	public CommonPage clickCancel()
	{
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CommonPageLocators.CANCEL_QUOTE_BTN_CSS));
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.CANCEL_QUOTE_BTN_CSS));
		return this;
	}

	public CommonPage goPrev()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(CommonPageLocators.PREVIOUS_QUOTE_BTN_CSS));
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.PREVIOUS_QUOTE_BTN_CSS));
		return this;
	}

	public CommonPage goPrevWithAlert()
	{
		seleniumCommands.logInfo("Getting to previous page through alert popup");
		this.goPrev();
		new AlertHandler().closeAlert();
		return this;
	}
	
	public Validation isAsteriskPresentForMandatoryField(String modelVale){
		return new Validation(seleniumCommands.getAttributeValueAtLocator(By.cssSelector(ASTERISK_CSS.replace("MODEL", modelVale).replace("LABEL", modelVale)), "innerHTML"),DataConstant.ASTERISK);
	}

	public CommonPage clickOnHeaderGWAndConfirmCancel()
	{
		seleniumCommands.logInfo("Click on Header GW logo");
		seleniumCommands.click(HOME_BTN_CSS);
		seleniumCommands.clickbyJS(CONFIRM_CANCEL_BUTTON);
		return this;
	}

}