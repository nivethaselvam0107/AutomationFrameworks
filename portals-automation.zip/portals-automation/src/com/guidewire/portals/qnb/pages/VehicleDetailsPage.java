package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

public class VehicleDetailsPage extends CommonPage {
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	@FindBy(css = "[model*='vehicle.vin'] input")
	 List<WebElement> VIN_TXT_CSS;

	@FindBy(css = "[model='vehicle.vin'] span")
	 WebElement VIN_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.vin'] span[class='gw-required-asterisk'], [vin-loaded] span[class='gw-required-asterisk']")
	 WebElement VIN_ASTERISK_CSS;
	
	@FindBy(css = "[model='vehicle.make'] span")
	 WebElement MAKE_LBL_CSS;
	
	@FindBy(id = "Make")
	List<WebElement> MAKE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.make'] span[class='gw-required-asterisk']")
	List<WebElement> MAKE_ASTERISK_CSS;
	
	@FindBy(css = "[model='vehicle.make'] input")
	 WebElement MAKE_VALUE_CSS;

	@FindBy(css = "[model='vehicle.model'] input")
	 WebElement MODEL_VALUE_CSS;
	
	@FindBy(css = "[model='vehicle.model'] span")
	 WebElement MODEL_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.model'] span[class='gw-required-asterisk']")
	List<WebElement> MODEL_ASTERISK_CSS;
	
	@FindBy(id = "Model")
	List<WebElement> MODEL_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.year'] select")
	List<WebElement> YEAR_VALUE_CSS;
	
	@FindBy(css = "[model='vehicle.year'] span")
	 WebElement YEAR_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.year'] span[class='gw-required-asterisk']")
	List<WebElement> YEAR_ASTERISK_CSS;
	
	@FindBy(css = "[gw-pl-select='vehicle.year.value']")
	 WebElement YEAR_DROP_CSS;
	
	@FindBy(css = "[model='vehicle.year'] [ng-show='readonly']")
	List<WebElement> YEAR_VALUE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.license'] input, [label='License Plate'] input")
	List<WebElement> LICENSE_PLATE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.license'] span, [label='License Plate'] span")
	 WebElement LICENSE_PLATE_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.license'] span[class='gw-required-asterisk'], [label='License Plate'] span[class='gw-required-asterisk']")
	List<WebElement> LICENSE_PLATE_ASTERISK_CSS;

	@FindBy(css = "[model='vehicle.licenseState'] select, [label='State'] select")
	List<WebElement> STATE_DROP_CSS;

	@FindBy(css = "[model='vehicle.licenseState'] span, [label='State'] sapn")
	 WebElement STATE_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.licenseState'] span[class='gw-required-asterisk'], [label='State'] span[class='gw-required-asterisk']")
	List<WebElement> STATE_ASTERISK_CSS;
	
	@FindBy(css = "[model='vehicle.costNew.amount'] input, [label='Cost New'] input")
	List<WebElement> COST_TXT_CSS;

	@FindBy(css = "[model='vehicle.costNew.amount'] span")
	 WebElement COST_LBL_CSS;
	
	@FindBy(css = "[model*='costNew.amount'] span[class='gw-required-asterisk']")
	List<WebElement> COST_ASTERISK_CSS;
	
	@FindBy(css = "button[on-click='addVehicle(form)']")
	 WebElement ADD_VEHICLE_YES_BTN_CSS;
	
	@FindBy(css = "button[ng-click='next(form)']")
	 WebElement ADD_VEHICLE_NO_BTN_CSS;
	
	@FindBy(css = "button[ng-click='goToCancel()'], button[ng-click='cancel()'], button[on-click='goToCancel()']")
	 WebElement CANCEL_BTN_CSS;
	
	@FindBy(id = "vehiclesTable")
	 WebElement VEHICLE_TABLE_ID;


	@FindBy(css = "[class='gw-modal gw-fade  in']")
	WebElement QUOTE_MODAL;
	
	String tableID = "vehiclesTable";
	
	//Replace the ROW_NUM with the row you want to edit
	String EDIT_BTN_CSS = "[id='vehiclesTable'] tr:nth-child(ROW_NUM) span[class='fa fa-pencil']";
		
	//Replace the ROW_NUM with the row you want to edit
	String DELETE_BTN_CSS = "[id='vehiclesTable'] tr:nth-child(ROW_NUM) span[class='fa fa-trash']";

	public VehicleDetailsPage()
	{
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public VehicleDetailsPage(Object dataObj)
	{
		this.data = (HashMap<String, String>) dataObj;
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public VehicleDetailsPage goNext()
	{
		clickNext();
		return this;
	}
	
	public VehicleDetailsPage clickCancel()
	{
		seleniumCommands.waitForElementToBeClickable(CANCEL_BTN_CSS);
		seleniumCommands.clickbyJS(CANCEL_BTN_CSS);
		return this;
	}
	
	public PAQuotePage goToPAQuotePage() {
		this.clickNext();
		return new Pagefactory().getPAQuotePage();
}
	public void proceedToQuoteSummaryThroughtAllert() {
		goNext();
		new AlertHandler().closeAlert();
	}

	//Set Methods
	//TODO for refresh check
	public VehicleDetailsPage withVIN() {
		String browser = ThreadLocalObject.getBrowserName();
		if (browser.equalsIgnoreCase("NEXUS5") || browser.equalsIgnoreCase("IPHONE6")) {
			WebElement element = seleniumCommands.findElement(By.xpath("//h2"));
			((JavascriptExecutor) ThreadLocalObject.getDriver()).executeScript("window.scrollTo(0," + element.getLocation().y + ")");
		}
			seleniumCommands.type(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1),data.get("VIN"));
			seleniumCommands.click(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1));
		return this;
	}
	//TODO for refresh check
	public VehicleDetailsPage withVIN(String vin) {
			seleniumCommands.type(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1),vin);
			seleniumCommands.click(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1));
			seleniumCommands.click(VIN_LBL_CSS);
		return this;
	}

	public VehicleDetailsPage withLicensePlate(String firstName) {
		seleniumCommands.type(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1), firstName);
		return this;
	}
	
	public VehicleDetailsPage withLicensePlate() {
		seleniumCommands.type(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1), data.get("LicensePlate"));
		return this;
	}
	
	public VehicleDetailsPage withState() {
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS.get(STATE_DROP_CSS.size()-1), data.get("State"));
		return this;
	}
	
	public VehicleDetailsPage withState(String state) {
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS.get(STATE_DROP_CSS.size()-1), state);
		return this;
	}


	public VehicleDetailsPage withVehicleCost() {
		seleniumCommands.type(COST_TXT_CSS.get(COST_TXT_CSS.size()-1), data.get("VehicleCost"));
		return this;
	}
	
	public VehicleDetailsPage withVehicleCost(String cost) {
		seleniumCommands.type(COST_TXT_CSS.get(COST_TXT_CSS.size()-1), cost);
		seleniumCommands.click(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1));
		return this;
	}

	public VehicleDetailsPage withMake() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.type(MAKE_TXT_CSS.get(MAKE_TXT_CSS.size()-1), data.get("Make"));
		return this;
    }
    
    public VehicleDetailsPage withModel() {
    		seleniumCommands.type(MODEL_TXT_CSS.get(MODEL_TXT_CSS.size()-1), data.get("Model"));
		return this;
    }
    
    public VehicleDetailsPage withYear() {
    	seleniumCommands.selectDropDownValueByText(YEAR_VALUE_CSS.get(YEAR_VALUE_CSS.size()-1), data.get("VehicleYear"));
        return this;
    }
	
	public VehicleDetailsPage setVehicleDetails() {
		this.withVIN().withMake().withModel().withVehicleCost().withLicensePlate().withState().withYear();
		return this;
	}
	
	public VehicleDetailsPage setQuickQuoteVehicleDetails() {
		this.withVehicleCost().withLicensePlate();
		return this;
	}
	
	public VehicleDetailsPage setVehicleDetailsWithAdditionalVehicle() {
		this.withVIN().withVehicleCost().withLicensePlate().withState();
		this.withNewVehicle();
			return this;
		}
	
	public VehicleDetailsPage withNewVehicle() {
		
		HashMap<String, String> policyData =  ThreadLocalObject.getData();
		policyData.put("VIN", "SGSGSG");
		seleniumCommands.click(ADD_VEHICLE_YES_BTN_CSS);
		this.withVIN()
			.withLicensePlate()
			.withMake()
			.withModel()
			.withState()
			.withVehicleCost()
			.withYear();

			//	.withLicensePlate("wqwqw").withState("California").withVehicleCost("24500");
		return this;
	}

	public VehicleDetailsPage clickYes() {
		seleniumCommands.logInfo( "Clicking Yes Button ");
		seleniumCommands.clickbyJS(ADD_VEHICLE_YES_BTN_CSS);
		return this;
	}
	
	public VehicleDetailsPage editDriverDetails(String rownum) {
		ThreadLocalObject.getDriver().findElement(By.cssSelector(EDIT_BTN_CSS.replace("ROW_NUM",rownum))).click();
		seleniumCommands.waitForElementToBeClickable(By.id(tableID));
		return this;
	}
	
	public VehicleDetailsPage deleteDriver(String rownum) {
		ThreadLocalObject.getDriver().findElement(By.cssSelector(DELETE_BTN_CSS.replace("ROW_NUM",rownum)));
		return this;
	}
	
	// Get Methods
	
	
	private String getVIN() {
		return seleniumCommands.getValueAttributeFromLocator(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1));
	}
	
	private String getLIcensePlateValue() {
		return seleniumCommands.getValueAttributeFromLocator(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1));
	}
	
	private String getVehicleCost() {
		return seleniumCommands.getValueAttributeFromLocator(COST_TXT_CSS.get(COST_TXT_CSS.size()-1));
	}
	
	private String getMake() {
		return seleniumCommands.getValueAttributeFromLocator(MAKE_TXT_CSS.get(MAKE_TXT_CSS.size()-1));
	}
	
	private String getModel() {
		return seleniumCommands.getValueAttributeFromLocator(MODEL_TXT_CSS.get(MODEL_TXT_CSS.size()-1));
	}
	
	private String getYear() {
		if(!new Boolean(seleniumCommands.getAttributeValueAtLocator(YEAR_VALUE_TXT_CSS.get(YEAR_VALUE_TXT_CSS.size()-1), "aria-hidden")))
		{
			return seleniumCommands.getTextAtLocator(YEAR_VALUE_TXT_CSS.get(YEAR_VALUE_TXT_CSS.size()-1));
		}
		else 	if(!new Boolean(seleniumCommands.getAttributeValueAtLocator(YEAR_DROP_CSS, "aria-hidden")))
		{
			return seleniumCommands.getSelectedOptionFromDropDown(YEAR_DROP_CSS);
		}
		return null;
	}
	
	private String getState() {
		return seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS.get(STATE_DROP_CSS.size()-1));
	}
	
	
	
	// Validation 
	
		public Validation isVehiclePageLoaded() {
			seleniumCommands.waitForElementToBeVisible(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1));
			return new Validation(seleniumCommands.isElementPresent(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1)));
		}
		
		public Validation areVehiclePageFieldsMarkedWithMandatoryError() {
			logger.info( "Validating the Mandatory Error for the fields the Quote");
			isVINFieldMakedWithError().shouldBeEqual("VIN field is not marked with correct mandatory error");
			isMakeFieldMakedWithError().shouldBeEqual("Make field is not marked with correct mandatory error");
			isModelFieldMakedWithError().shouldBeEqual("Model field is not marked with correct mandatory error");
			isYearFieldMakedWithError().shouldBeEqual("Yeardxdycccc field is not marked with correct mandatory error");
			isCostNewFieldMakedWithError().shouldBeEqual("Cost field is not marked with correct mandatory error");
			return new Validation(true);
		}
		
		public Validation  areVehiclePageFieldsMarkedWithAsterisk() {
			logger.info( "Validating the Mandatory fields marked with asterisk");
			isVINFieldMakedWithAsterisk().shouldBeTrue("Vin field is not marked with asterisk");
			isMakeFieldMakedWithAsterisk().shouldBeTrue("Make field is not marked with asterisk");
			isModelFieldMakedWithAsterisk().shouldBeTrue("Model field is not marked with asterisk");
			isYearFieldMakedWithAsterisk().shouldBeTrue("Year field is not marked with asterisk");
			isStateFieldMakedWithAsterisk().shouldBeTrue("State field is not marked with asterisk");
			isCostNewFieldMakedWithAsterisk().shouldBeTrue("Vin field is not marked with asterisk");
			return new Validation(true);
		}
			
		public Validation isVINFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for VIN");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(VIN_TXT_CSS.get(VIN_TXT_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isVINFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for VIN Field");
			return new Validation(seleniumCommands.isElementPresent(VIN_ASTERISK_CSS));
		}
		
		public Validation isMakeFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for Make Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(MAKE_VALUE_CSS),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isMakeFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for make field");
			return new Validation(seleniumCommands.isElementPresent(MAKE_ASTERISK_CSS.get(MAKE_ASTERISK_CSS.size()-1)));
		}
		
		public Validation isModelFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for Model Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(MODEL_VALUE_CSS),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isModelFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for VIN Field");
			return new Validation(seleniumCommands.isElementPresent(MODEL_ASTERISK_CSS.get(MODEL_ASTERISK_CSS.size()-1)));
		}
		
		public Validation isYearFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for Year Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(YEAR_VALUE_CSS.get(YEAR_VALUE_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isYearFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for Year Field");
			return new Validation(seleniumCommands.isElementPresent(YEAR_ASTERISK_CSS.get(YEAR_ASTERISK_CSS.size()-1)));
		}
		
		public Validation isLicensePlateFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for License Plate Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(LICENSE_PLATE_TXT_CSS.get(LICENSE_PLATE_TXT_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isLicensePlateFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for License Plate Field");
			return new Validation(seleniumCommands.isElementPresent(LICENSE_PLATE_ASTERISK_CSS.get(LICENSE_PLATE_ASTERISK_CSS.size()-1)));
		}
		
		public Validation isStateFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for state Field");
			return new Validation(seleniumCommands.isElementPresent(STATE_ASTERISK_CSS.get(STATE_ASTERISK_CSS.size()-1)));
		}

	public Validation isStateFieldMarkedWithError() {
		logger.info( "Validating the Mandatory Error for State Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(STATE_DROP_CSS.get(STATE_DROP_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG);
	}
		
		public Validation isCostNewFieldMakedWithError() {
			logger.info( "Validating the Mandatory Error for CostNew Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(COST_TXT_CSS.get(COST_TXT_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG);
		}
		
		public Validation isCostNewFieldMakedWithNumberFormatError() {
			logger.info( "Validating the Number Format Error for CostNew Field");
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(COST_TXT_CSS.get(COST_TXT_CSS.size()-1)), DataConstant.NUMBER_FORMAT_ERROR_MSG);
		}
		
		public Validation isCostNewFieldMakedWithAsterisk() {
			logger.info( "Validating the Asterisk for CostNew Field");
			return new Validation(seleniumCommands.isElementPresent(COST_ASTERISK_CSS.get(COST_ASTERISK_CSS.size()-1)));
		}
		
		public Validation isVINEqualsTo() {
			return new Validation(getVIN(), data.get("VIN"));
		}
		
		public Validation isVINEqualsTo(String vin) {
			return new Validation(getVIN(), vin);
		}

		public Validation isMakeEqualsTo(String make) {
			return new Validation(getMake(), make);
		}
		
		public Validation isMakeEqualsTo() {
			return new Validation(getMake(), data.get("Make"));
		}
		
		public Validation isModelEqualsTo() {
			return new Validation(getModel(), data.get("Model"));
		}
		
		public Validation isModelEqualsTo(String model) {
			return new Validation(getModel(), model);
		}

		public Validation isYearEqualsTo(String year) {
			return new Validation(getYear(), year);
		}
		
		public Validation isYearEqualsTo() {
			return new Validation(getYear(),  data.get("VehicleYear"));
		}
		
		public Validation isLicensePlateEqualsTo() {
			return new Validation(getLIcensePlateValue(), data.get("LicensePlate"));
		}
		
		public Validation isLicensePlateEqualsTo(String plate) {
			return new Validation(getYear(),plate);
		}
		
		public Validation isStateEqualsTo() {
			return new Validation(getState(), data.get("State"));
		}
		
		public Validation isStateEqualsTo(String state) {
			return new Validation(getState(), state);
		}
		
		public Validation isCostEqualsTo() {
			return new Validation(getVehicleCost(), data.get("VehicleCost"));
		}
		
		public Validation isCostEqualsTo(String cost) {
			return new Validation(getVehicleCost(), cost);
		}
		
		public Validation areVehiclesDetailsSaved() {
			this.isVINEqualsTo().shouldBeEqual("Vin ");
			this.isMakeEqualsTo("Toyota").shouldBeEqual("Make is not correct");this.isModelEqualsTo("Avensis").shouldBeEqual("Model is not correct");
			this.isYearEqualsTo("2013").shouldBeEqual("Year is not correct");
			this.isLicensePlateEqualsTo().shouldBeEqual("License Plate is not correct");
			this.isStateEqualsTo().shouldBeEqual("State is not correct");
			this.isCostEqualsTo().shouldBeEqual("Cost is not correct");
			
			return new Validation(true);
		}
		
		public void validateQuickQuoteDataPreFilledOnVehiclesDetailsPage(boolean searchByVin) {
			if(searchByVin)
				this.isVINEqualsTo().shouldBeEqual("VIN value is not correct");
			this.isMakeEqualsTo().shouldBeEqual("Make value is not correct");
			this.isModelEqualsTo().shouldBeEqual("Model value is not correct");
			this.isYearEqualsTo().shouldBeEqual("Vehicle Year value is not correct");
			this.isStateEqualsTo().shouldBeEqual("State value is not correct");
		}

		public Validation areVehiclesDetailsNotSaved() {
			this.isVINEqualsTo().shouldNotBeEqual();
			this.isMakeEqualsTo().shouldNotBeEqual();
			this.isModelEqualsTo().shouldNotBeEqual();
			this.isYearEqualsTo().shouldNotBeEqual();
			this.isLicensePlateEqualsTo().shouldNotBeEqual();
			this.isStateEqualsTo().shouldNotBeEqual();
			this.isCostEqualsTo().shouldNotBeEqual();

			return new Validation(true);
		}

	    public static Validation areVehicleDetailsMatchingBackEnd() throws Exception{
			return MapCompare.compareMap(ThreadLocalObject.getData(),
					ParseQuoteData.getVehicelDetailsFromBackEnd(DataFetch.getQuoteData(
							ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
		}

	    public static Validation areVehicleDetailsMatchingBackEnd(String jsonData) throws Exception{
			return MapCompare.compareMap(ThreadLocalObject.getData(), ParseQuoteData.getVehicelDetailsFromBackEnd(jsonData));
		}
	    
	    public static Validation areVehicleDetailsMatchingBackEndFilterByVIN(String jsonData) throws Exception{
			return MapCompare.compareMap(ThreadLocalObject.getData(), 
					ParseQuoteData.getAllVehicleDetailsFromBackEnd(jsonData).get(ThreadLocalObject.getData().get("VIN")));
		}
		
}
