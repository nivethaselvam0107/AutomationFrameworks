package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;


public class CPBOPQuotePage extends  CommonPage{

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[ng-click=\"selectStep(step.name)\"]")
    WebElement CP_EDIT_COVERAGES_CSS;

    @FindBy(css = "[ng-click=\"selectStep('bopGeneralCoverages')\"]")
    WebElement BOP_EDIT_COVERAGES_CSS;

    @FindBy(css = "gw-qnb-cp-location-header")
    WebElement CP_BUILDINGS_PAGE_CSS;

    @FindBy(xpath = "//gw-bop-coverages-list[@coverages='lobCoverages']")
    WebElement BOP_GEN_CVG_HEADER_XPATH;

    @FindBy(css = "[icon='print'][role='button'] i, gw-quote .gw-quote-grid")
    WebElement PRINT_QUOTE_BTN_CSS;

    @FindBy(css = "[class*='gw-alert'] [class*='content']")
    WebElement ALERT_CONTENT_CSS;

    @FindBy(css = "[class*='gw-alert'] strong:nth-of-type(1)")
    WebElement NEW_PREMIUM_CSS;

    @FindBy(css = "[class*='gw-alert'] strong:nth-of-type(2)")
    WebElement CHANGE_IN_PREMIUM_CSS;

    public CPBOPQuotePage()
    {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public CPBOPQuotePage(Object dataObj)
    {
        this.data = (HashMap<String, String>) dataObj;
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public CPBOPQuotePage clickOnEditCoveragesForCP() {
        seleniumCommands.clickbyJS(CP_EDIT_COVERAGES_CSS);
        seleniumCommands.waitForElementToBePresent(CP_BUILDINGS_PAGE_CSS);
        return this;
    }

    public CPBOPQuotePage clickOnEditCoveragesForBOP() {
        seleniumCommands.clickbyJS(BOP_EDIT_COVERAGES_CSS);
        seleniumCommands.waitForElementToBePresent(BOP_GEN_CVG_HEADER_XPATH);
        return this;
    }


    //Validation Methods
    public Validation isBOPQuotePageLoaded(){
        return new Validation(seleniumCommands.isElementPresent(PRINT_QUOTE_BTN_CSS));
    }

    public Validation isCPQuotePageLoaded(){
        return new Validation(seleniumCommands.isElementPresent(PRINT_QUOTE_BTN_CSS));
    }

    public void validateTransactionQuotePageForNoChange(){
        new Validation(seleniumCommands.getTextAtLocator(ALERT_CONTENT_CSS), DataConstant.QUOTE_ALERT_NO_CHANGE_MSG).shouldBeEqual("The message for no change isn't correct");
    }

    public void validateTransactionQuotePageForDecrease(){
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> quoteDetails = ParseEndorsementData.getQuoteDetailsForPolicyChange(jsonData);
        new Validation(seleniumCommands.getTextAtLocator(ALERT_CONTENT_CSS).replace(",",""), DataConstant.QUOTE_ALERT_DECREASE_MSG.replace("newPremium", quoteDetails.get("Total_Premium")).replace("changePremium", quoteDetails.get("Premium_Change"))).shouldBeEqual("The message for decrease in premium isn't correct");
    }

    public void validateTransactionQuotePageForIncrease(){
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> quoteDetails = ParseEndorsementData.getQuoteDetailsForPolicyChange(jsonData);
        new Validation(seleniumCommands.getTextAtLocator(ALERT_CONTENT_CSS).replace(",",""), DataConstant.QUOTE_ALERT_INCREASE_MSG.replace("newPremium", quoteDetails.get("Total_Premium")).replace("changePremium", quoteDetails.get("Premium_Change"))).shouldBeEqual("The message for decrease in premium isn't correct");
    }

    public void validateBOPPolicyChangeQuoteDetailsInBackend(){
        String jsonData = getPolicyChangeDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> quoteDetails = ParseEndorsementData.getQuoteDetailsForPolicyChange(jsonData);
        new Validation(quoteDetails.get("Total_Premium"),seleniumCommands.getTextAtLocator(NEW_PREMIUM_CSS).replace("$","")).shouldBeEqual("New Premium didn't match with backend");
        new Validation(quoteDetails.get("Premium_Change"),seleniumCommands.getTextAtLocator(CHANGE_IN_PREMIUM_CSS).replace("$","")).shouldBeEqual("Change in Premium didn't match with backend");
    }

    public String getPolicyChangeDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

}
