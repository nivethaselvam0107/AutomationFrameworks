package com.guidewire.portals.qnb.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.locators.DiscountPageLocators;

public class DiscountPage extends CommonPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[class='gw-mandatory-group'], [view-model*='ratingViewModel']")
	WebElement MANDATORY_FIELD_CLASS;

	@FindBy(css = "[ng-click='goToNext()']")
	WebElement GO_NEXT_BTN_CSS;

	@FindBy(css = "[model*='fireExtinguishers'] label.gw-first, [label*='Fire Extinguishers'] label.gw-first, [label='Smoke detector?'] label.gw-first, [label*='Fire Extinguishers'] input")
	WebElement FIRE_EXT_YES_LBL_CSS;

	@FindBy(css = "[model*='fireExtinguishers'] label.gw-second, [label*='Fire Extinguishers'] label.gw-second")
	WebElement FIRE_EXT_NO_LBL_CSS;

	@FindBy(css = "[model*='fireExtinguishers'] input:nth-of-type(1), [label*='Fire Extinguishers'] input:nth-of-type(1)")
	WebElement FIRE_EXT_YES_VALUE_CSS;
	
	By FIRE_EXT_TXT_CSS = By.cssSelector("[model*='fireExtinguishers'] input, [label*='Fire Extinguishers'] input[type='number']");

	@FindBy(css = "[model*='fireExtinguishers'] input:nth-of-type(2), [label*='Fire Extinguishers'] input:nth-of-type(2)")
	WebElement FIRE_EXT_NO_VALUE_CSS;

	@FindBy(css = "[model*='burglarAlarm'] label.gw-first, [label='Burglar Alarm'] label.gw-first")
	WebElement BURG_ALARM_YES_LBL_CSS;

	@FindBy(css = "[model*='burglarAlarm'] label.gw-second, [label='Burglar Alarm'] label.gw-second")
	WebElement BURG_ALARM_NO_LBL_CSS;

	@FindBy(css = "[model*='burglarAlarm'] input:nth-of-type(1), [label='Burglar Alarm'] input:nth-of-type(1)")
	WebElement BURG_ALARM_YES_VALUE_CSS;

	@FindBy(css = "[model*='burglarAlarm'] input:nth-of-type(2), [label='Burglar Alarm'] input:nth-of-type(1)")
	WebElement BURG_ALARM_NO_VALUE_CSS;

	@FindBy(xpath = "(//*[@model='view.burglarAlarmType']//input/following-sibling::label)[2] | (//*[@label='Specify type:']//input/following-sibling::label)[1]")
	WebElement BURG_ALARM_LOCAL_LBL_CSS;

	@FindBy(xpath = "(//*[@model='view.burglarAlarmType']//input/following-sibling::label)[2] | (//*[@label='Specify type:']//input/following-sibling::label)[2]")
	WebElement BURG_ALARM_LOCAL_LBL_CSS_GRANITE;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(1) input, [label='Specify type:'] div:nth-of-type(1) input")
	WebElement BURG_ALARM_LOCAL_VALUE_CSS;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(1) input, [label='Specify type:'] div:nth-of-type(2) input")
	WebElement BURG_ALARM_LOCAL_VALUE_CSS_GRANITE;

	@FindBy(xpath = "(//*[@model='view.burglarAlarmType']//input/following-sibling::label)[2] | (//*[@label='Specify type:']//input/following-sibling::label)[2]")
	WebElement BURG_ALARM_CENTRAL_LBL_XPATH;

	@FindBy(xpath = "(//*[@model='view.burglarAlarmType']//input/following-sibling::label)[2] | (//*[@label='Specify type:']//input/following-sibling::label)[3]")
	WebElement BURG_ALARM_CENTRAL_LBL_XPATH_GRANITE;

	@FindBy(css = "label[for='BurglarAlarmType2']")
	WebElement BURG_ALARM_POLICE_LBL_CSS;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(2) input, [label='Specify type:'] div:nth-of-type(2) input")
	WebElement BURG_ALARM_CENTRAL_VALUE_CSS;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(2) input, [label='Specify type:'] div:nth-of-type(3) input")
	WebElement BURG_ALARM_CENTRAL_VALUE_CSS_GRANITE;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(3) input, [label='Specify type:'] div:nth-of-type(3) input")
	WebElement BURG_ALARM_POLICE_VALUE_CSS;

	@FindBy(css = "[model='view.burglarAlarmType'] div:nth-of-type(3) input, [label='Specify type:'] div:nth-of-type(4) input")
	WebElement BURG_ALARM_POLICE_VALUE_CSS_GRANITE;

	@FindBy(css = "[model='view.fireAlarm'] label.gw-second, [label='Fire Alarm Reporting to Monitoring Center'] label.gw-second")
	WebElement FIR_ALARM_REP_NO_LBL_CSS;

	@FindBy(css = "[model='view.fireAlarm'] label.gw-first, [label='Fire Alarm Reporting to Monitoring Center'] label.gw-first")
	WebElement FIR_ALARM_REP_YES_LBL_CSS;

	@FindBy(css = "[model='view.fireAlarm'] input:nth-of-type(1), [label='Fire Alarm Reporting to Monitoring Center'] input:nth-of-type(1)")
	WebElement FIRE_ALARM_YES_VALUE_CSS;

	@FindBy(css = "[model='view.fireAlarm'] input:nth-of-type(2), [label='Fire Alarm Reporting to Monitoring Center'] input:nth-of-type(2)")
	WebElement FIRE_ALARM_NO_VALUE_CSS;

	@FindBy(css = "[model='view.smokeAlarm'] label.gw-second, [label='Smoke Alarms'] label.gw-second")
	WebElement SMOKE_ALARM_NO_LBL_CSS;

	@FindBy(css = "[model='view.smokeAlarm'] label.gw-first, [label='Smoke Alarms'] label.gw-first")
	WebElement SMOKE_ALARM_YES_LBL_CSS;

	@FindBy(css = "[model='view.smokeAlarm'] input:nth-of-type(1), [label='Smoke Alarms'] input:nth-of-type(1)")
	WebElement SMOKE_ALARM_YES_VALUE_CSS;

	@FindBy(css = "[model='view.smokeAlarm'] input:nth-of-type(2), [label='Smoke Alarms'] input:nth-of-type(2)")
	WebElement SMOKE_ALARM_NO_VALUE_CSS;

	@FindBy(css = "[ng-if='view.smokeAlarm.value'] label.gw-first, [label='Are there alarms on all floors?'] label.gw-first")
	WebElement SMOKE_ALARM_ALLFLOOR_YES_LBL_CSS;

	@FindBy(css = "[ng-if='view.smokeAlarm.value'] label.gw-second, [label='Are there alarms on all floors?'] label.gw-second")
	WebElement SMOKE_ALARM_ALLFLOOR_NO_LBL_CSS;

	@FindBy(css = "[model='view.smokeAlarmOnAllFloors'] input:nth-of-type(1), [label='Are there alarms on all floors?'] input:nth-of-type(1)")
	WebElement SMOKE_ALARM_ALLFLOOR_YES_VALUE_CSS;

	@FindBy(css = "[model='view.view.smokeAlarmOnAllFloors'] input:nth-of-type(2), [label='Are there alarms on all floors?'] input:nth-of-type(2)")
	WebElement SMOKE_ALARM_ALLFLOOR_NO_VALUE_CSS;

	@FindBy(css = "[model='view.deadbolts'] label.gw-second, [label='Deadbolts'] label.gw-second")
	WebElement DEADBOLTS_NO_LBL_CSS;

	@FindBy(css = "[model='view.deadbolts'] label.gw-first,  [label='Deadbolts'] label.gw-first")
	WebElement DEADBOLTS_YES_LBL_CSS;

	@FindBy(css = "[model='view.deadbolts'] input:nth-of-type(1), [label='Deadbolts'] input:nth-of-type(1)")
	WebElement DEADBOLTS_YES_VALUE_CSS;

	@FindBy(css = "[model='view.deadbolts'] input:nth-of-type(2), [label='Deadbolts'] input:nth-of-type(1)")
	WebElement DEADBOLTS_NO_VALUE_CSS;
	
	@FindBy(css = "[ng-model='view.deadboltsNumber.value'], [label='Specify the number of deadbolts:'] input")
	WebElement DEADBOLTS_COUNT_CSS;

	@FindBy(css = "[model='view.visibleToNeighbors'] label.gw-second, [label='Residence Visible to Neighbours'] label.gw-second")
	WebElement VISIBLE_TO_NEIGH_NO_LBL_CSS;

	@FindBy(css = "[model='view.visibleToNeighbors'] label.gw-first, [label='Residence Visible to Neighbours'] label.gw-first")
	WebElement VISIBLE_TO_NEIGH_YES_LBL_CSS;

	@FindBy(css = "[model='view.visibleToNeighbors'] input:nth-of-type(1), [label='Residence Visible to Neighbours'] input:nth-of-type(1)")
	WebElement VISIBLE_TO_NEIGH_YES_VALUE_CSS;

	@FindBy(css = "[model='view.visibleToNeighbors'] input:nth-of-type(2), [label='Residence Visible to Neighbours'] input:nth-of-type(2)")
	WebElement VISIBLE_TO_NEIGH_NO_VALUE_CSS;

	@FindBy(css = "[model='view.sprinklerSystemType'] select, [label='Sprinkler System Type'] select")
	WebElement SPRINKLER_DROP_CSS;

	// Additional Details
	@FindBy(css = "span[is-open='isAdditionalOpen'], [is-open] [ng-click]")
	WebElement EXPAND_ADDITIONAL_DETAILS_BTN_CSS;

	@FindBy(css = "div[class='panel-group'] [class='panel-collapse collapse in']")
	WebElement ADDITIONAL_DETAILS_SEC_CSS;

	@FindBy(css = "//div[@validation-form='ratingAdditionalForm']//div[@class='panel-collapse collapse in']")
	WebElement ADDITIONAL_DETAILS_EXPANDED_SEC_CSS;

	@FindBy(css = "[model='view.roomerBoarders'] [class='gw-second'], [detailfield*='roomerBoardersNumber'] [class='gw-second']")
	WebElement ROOMR_OR_BORDR_NO_LBL_CSS;

	@FindBy(css = "[model*='roomerBoarders'] [class='gw-first'], [detailfield*='roomerBoardersNumber'] [class='gw-first']")
	WebElement ROOMR_OR_BORDR_YES_LBL_CSS;

	@FindBy(css = "[model*='roomerBoarders'] input:nth-of-type(1), [detailfield*='roomerBoardersNumber'] input:nth-of-type(1)")
	WebElement ROOMR_OR_BORDR_YES_VALUE_CSS;

	@FindBy(css = "[model*='roomerBoarders'] input:nth-of-type(2), [detailfield*='roomerBoardersNumber'] input:nth-of-type(2)")
	WebElement ROOMR_OR_BORDR_NO_VALUE_CSS;

	@FindBy(css = "[model*='roomerBoardersNumber'] input, [detailfield*='roomerBoardersNumber'] input[type='number']")
	WebElement ROOMR_OR_BORDR_NO_TXT_CSS;

	@FindBy(css = "[model*='fireplaceOrWoodStoveExists'] [class='gw-second'], [detailfield*='fireplaceOrWoodStovesNumber'] [class='gw-second']")
	WebElement FIREPLC_OR_WOODSTOV_NO_LBL_CSS;

	@FindBy(css = "[model*='fireplaceOrWoodStoveExists'] [class='gw-first'], [detailfield*='fireplaceOrWoodStovesNumber'] [class='gw-first']")
	WebElement FIREPLC_OR_WOODSTOV_YES_LBL_CSS;

	@FindBy(css = "[model*='fireplaceOrWoodStovesNumber'] input, [detailfield*='fireplaceOrWoodStovesNumber'] input[type='number']")
	WebElement FIREPLC_OR_WOODSTO_NO_TXT_CSS;

	@FindBy(css = "[model*='fireplaceOrWoodStoveExists'] input:nth-of-type(1), [detailfield*='fireplaceOrWoodStovesNumber'] input:nth-of-type(1)")
	WebElement FIREPLC_OR_WOODSTOV_YES_VALUE_CSS;

	@FindBy(css = "[model*='fireplaceOrWoodStoveExists'] input:nth-of-type(2), [detailfield*='fireplaceOrWoodStovesNumber'] input:nth-of-type(2)")
	WebElement FIREPLC_OR_WOODSTOV_NO_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolExists'] [class='gw-first'], [detailfield*='swimmingPool'] [class='gw-first']")
	WebElement POOL_YES_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolExists'] [class='gw-second'], [detailfield*='swimmingPool'], [class='gw-second']")
	WebElement POOL_NO_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolExists'] input:nth-of-type(1), [detailfield*='swimmingPool'] input:nth-of-type(1)")
	WebElement POOL_YES_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolExists'] input:nth-of-type(2), [detailfield*='swimmingPool'] input:nth-of-type(2)")
	WebElement POOL_NO_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolFencing'] [class='gw-second'], [label='Is the property fenced?'] [class='gw-second']")
	WebElement POOL_FENCE_NO_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolFencing'] [class='gw-first'], [label='Is the property fenced?'] [class='gw-first']")
	WebElement POOL_FENCE_YES_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] [class='gw-first'], [label='Is there a slide?'] [class='gw-first']")
	WebElement POOL_SLIDE_YES_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] [class='gw-second'], [label='Is there a slide?'] [class='gw-second']")
	WebElement POOL_SLIDE_NO_LBL_CSS;
	
	@FindBy(xpath = "//*[contains(@model,'swimmingPoolFencing')]//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span"
			+ "| //*[@label='Is the property fenced?']//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span")
	WebElement POOL_FENCE_ERROR_XPATH;

	@FindBy(css = "[model*='swimmingPoolFencing'] input:nth-of-type(1), [label='Is the property fenced?'] input:nth-of-type(1)")
	WebElement POOL_FENCE_YES_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolFencing'] input:nth-of-type(2), [label='Is the property fenced?'] input:nth-of-type(2)")
	WebElement POOL_FENCE_NO_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] [class='gw-second'], [label='Is there a diving board?'] [class='gw-second']")
	WebElement POOL_DIVEBOARD_NO_LBL_CSS;
	
	@FindBy(xpath = "//*[contains(@model,'swimmingPoolDivingBoard')]//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span"
			+ " | //*[@label='Is there a diving board?']//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span")
	WebElement POOL_DIVEBOARD_ERROR_XPATH;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] [class='gw-first'], [label='Is there a diving board?'] [class='gw-first']")
	WebElement POOL_DIVEBOARD_YES_LBL_CSS;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] input:nth-of-type(1), [label='Is there a diving board?'] input:nth-of-type(1)")
	WebElement POOL_DIVEBOARD_YES_VALUE_CSS;

	@FindBy(css = "[model*='swimmingPoolDivingBoard'] input:nth-of-type(2), [label='Is there a diving board?'] input:nth-of-type(2)")
	WebElement POOL_DIVEBOARD_NO_VALUE_CSS;

	@FindBy(css = "[model*='trampolineExists'] [class='gw-first'], [label='Trampoline'] [class='gw-first']")
	WebElement TREMPOLINE_YES_LBL_CSS;

	@FindBy(css = "[model*='trampolineExists'] [class='gw-second'], [label='Trampoline'] [class='gw-second']")
	WebElement TREMPOLINE_NO_LBL_CSS;
	
	@FindBy(xpath = "//*[contains(@model,'trampolineExists')]//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span"
			+ " | //*[@label='Does the trampoline have a safety net?']//*[@class='gw-first']/ancestor::div[@class='gw-inline-controls']//span")
	WebElement TREMPOLINE_ERROR_XPATH;

	@FindBy(css = "[model*='trampolineExists'] input:nth-of-type(1), [label='Trampoline'] input:nth-of-type(1)")
	WebElement TREMPOLINE_YES_VALUE_CSS;

	@FindBy(css = "[model*='trampolineExists'] input:nth-of-type(2), [label='Trampoline'] input:nth-of-type(2)")
	WebElement TREMPOLINE_NO_VALUE_CSS;

	@FindBy(css = "[model*='trampolineSafetyNet'] [class='gw-second'], [label='Does the trampoline have a safety net?'] [class='gw-second']")
	WebElement TREMPOLINE_SAFTYNET_NO_LBL_CSS;

	@FindBy(css = "[model*='trampolineSafetyNet'] [class='gw-first'], [label='Does the trampoline have a safety net?'] [class='gw-first']")
	WebElement TREMPOLINE_SAFTYNET_YES_LBL_CSS;

	@FindBy(css = "[model*='trampolineSafetyNet'] input:nth-of-type(1), [label='Does the trampoline have a safety net?'] input:nth-of-type(1)")
	WebElement TREMPOLINE_SAFTYNET_YES_VALUE_CSS;

	@FindBy(css = "[model*='trampolineSafetyNet'] input:nth-of-type(2), [label='Does the trampoline have a safety net?'] input:nth-of-type(2)")
	WebElement TREMPOLINE_SAFTYNET_NO_VALUE_CSS;

	@FindBy(css = "[model*='knownWaterLeakage'] [class='gw-second'], [label='Water leakage or flooding in the past 5 years?'] [class='gw-second']")
	WebElement WATER_LEAK_NO_LBL_CSS;

	@FindBy(css = "[model*='knownWaterLeakage'] [class='gw-first'], [label='Water leakage or flooding in the past 5 years?'] [class='gw-first']")
	WebElement WATER_LEAK_YES_LBL_CSS;

	@FindBy(css = "[model*='knownWaterLeakage'] input:nth-of-type(1), [label='Water leakage or flooding in the past 5 years?'] input:nth-of-type(1)")
	WebElement WATER_LEAK_YES_VALUE_CSS;

	@FindBy(css = "[model*='knownWaterLeakage'] input:nth-of-type(2), [label='Water leakage or flooding in the past 5 years?'] input:nth-of-type(2)")
	WebElement WATER_LEAK_NO_VALUE_CSS;

	@FindBy(css = "[model*='knownWaterLeakageDescription'] textarea, [label='Provide details:'] input")
	WebElement WATER_LEAK_DESC_TXT_CSS;
	
	@FindBy(xpath = "//*[contains(@model,'knownWaterLeakageDescription')]//span[@class='gw-error-inline ng-binding'] |"
			+ "//*[@label='Provide details:']//span[@class='gw-error-inline ng-binding']")
	WebElement WATER_LEAK_DESC_ERROR_XPATH;

	@FindBy(xpath = "(//*[contains(@model,'unitsNumber')]//label)[2] | (//*[@label='Number of Units']//label)[2]")
	WebElement UNIT_ONE_LBL_XPATH;

	@FindBy(xpath = "(//*[contains(@model,'unitsNumber')]//label)[3] | (//*[@label='Number of Units']//label)[3]")
	WebElement UNIT_TWO_LBL_XPATH;

	@FindBy(css = "[model*='unitsNumber'] div:nth-of-type(1) input, [label='Number of Units'] div:nth-of-type(1) input")
	WebElement UNIT_ONE_VALUE_CSS;

	@FindBy(css = "[model*='unitsNumber'] div:nth-of-type(2) input, [label='Number of Units'] div:nth-of-type(2) input")
	WebElement UNIT_TWO_VALUE_CSS;
	
	By FIRE_EXT_CSS =  By.cssSelector("[model*='fireExtinguishers'] input[type='number']");


	// iNow HO locators
	@FindBy(css = "[label='Smoke detector?'] label.gw-first")
	WebElement INOW_SMOKE_DETECTOR_YES;

	@FindBy(css = "[label='Smoke detector?'] label.gw-second")
	WebElement INOW_SMOKE_DETECTOR_NO;

	@FindBy(css = "[label='Smoke detector?'] .gw-inline-messages")
	WebElement INOW_SMOKE_DETECTOR_ERR_MSG;

	@FindBy(css = "[label='Smoke detector?'] input[data-ng-value='valueLeft']")
	WebElement INOW_SMOKE_DETECTOR_INPUT_YES;

	@FindBy(css = "[label='Smoke detector?'] input[data-ng-value='valueRight']")
	WebElement INOW_SMOKE_DETECTOR_INPUT_NO;

	@FindBy(css = "[label='Guarded gate'] label.gw-first")
	WebElement INOW_GUARDED_GATE_YES;

	@FindBy(css = "[label='Guarded gate'] label.gw-second")
	WebElement INOW_GUARDED_GATE_NO;

	@FindBy(css = "[label='Guarded gate'] input[data-ng-value='valueLeft']")
	WebElement INOW_GUARDED_GATE_INPUT_YES;

	@FindBy(css = "[label='Guarded gate'] input[data-ng-value='valueRight']")
	WebElement INOW_GUARDED_GATE_INPUT_NO;

	@FindBy(css = "[label='Burglar alarm type'] select")
	WebElement INOW_BURGLAR_ALARM_DROPDOWN;

	@FindBy(css = "[label='Fire alarm type'] select")
	WebElement INOW_FIRE_ALARM_DROPDOWN;

	@FindBy(css = "[label='Deductible'] select")
	WebElement INOW_DEDUCTIBLE_DROPDOWN;


	//	INOW Model
	String INOW_SMOKE_DETECTOR_VALUE_MODEL = "Smoke detector?";
	String INOW_BURGLAR_ALARM_VALUE_MODEL = "Burglar alarm type";
	String INOW_FIRE_ALARM_VALUE_MODEL = "Fire alarm type";
	String INOW_DEDUCTIBLE_VALUE_MODEL ="Deductible";

	public DiscountPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public DiscountPage(Object obj) {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public HOQuotePage goToHOQuotePage() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[label*='Fire Extinguishers']"));
		this.goNext();
		return new Pagefactory().getHOQuotePage();
	}

	public DiscountPage expandAdditionalPage() {
		if(!ThreadLocalObject.getDriver().findElement(By.xpath("//div[@is-open]")).getAttribute("class").contains("open"))
		{
			seleniumCommands.clickbyJS(EXPAND_ADDITIONAL_DETAILS_BTN_CSS);
		}
	
		// seleniumCommands.waitForElementToBeVisible(ROOMR_OR_BORDR_YES_LBL_CSS);
		return this;
	}

	// Set Methods

	public DiscountPage setFireExtinguishersAvailability(boolean selection) {
		if (selection) {
			FIRE_EXT_YES_LBL_CSS.click();
		} else {
			FIRE_EXT_NO_LBL_CSS.click();
		}
		return this;
	}

	public DiscountPage setFireExtinguishersDetails() {
		if(seleniumCommands.isElementPresent(FIRE_EXT_TXT_CSS))
		{
			seleniumCommands.type(FIRE_EXT_TXT_CSS, data.get("FireExtCount"));
			ThreadLocalObject.getData().put("FireExtinguishersAvailability",data.get("FireExtCount"));
		}
		else
		{
			if (new Boolean(data.get("FireExtinguishersAvailability"))) {
				seleniumCommands.clickbyJS(FIRE_EXT_YES_LBL_CSS);
			} else {
				seleniumCommands.clickbyJS(FIRE_EXT_NO_LBL_CSS);
			}
		}
		return this;
	}

	public DiscountPage withiNowSmokeDetector() {

			if (data.get("INOW_SmokeDetector").equalsIgnoreCase("Yes")) {
				seleniumCommands.clickbyJS(INOW_SMOKE_DETECTOR_YES);
			} else {
				seleniumCommands.clickbyJS(INOW_SMOKE_DETECTOR_NO);
			}
		return this;
	}

	public DiscountPage withiNowGuardedGate() {

		if (data.get("INOW_GuardedGate").equalsIgnoreCase("Yes")) {
			seleniumCommands.clickbyJS(INOW_GUARDED_GATE_YES);
		} else {
			seleniumCommands.clickbyJS(INOW_GUARDED_GATE_NO);
		}
		return this;
	}

	public DiscountPage withiNowBurglarAlarmType() {
		seleniumCommands.selectDropDownValueByText(INOW_BURGLAR_ALARM_DROPDOWN, data.get("INOW_BurglarAlarm"));
		return this;
	}

	public DiscountPage withiNowFireAlarmType() {
		seleniumCommands.selectDropDownValueByText(INOW_FIRE_ALARM_DROPDOWN, data.get("INOW_FireAlaram"));
		return this;
	}

	public DiscountPage withiNowDeductible() {
		seleniumCommands.selectDropDownValueByText(INOW_DEDUCTIBLE_DROPDOWN, data.get("INOW_Deductible"));
		return this;
	}

	public DiscountPage setFireExtinguishersAvailability(String avail) {
		if (new Boolean(avail)) {
			//FIRE_EXT_YES_LBL_CSS.click();
			seleniumCommands.clickbyJS(FIRE_EXT_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(FIRE_EXT_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setBurgularAlarmAvailability(String selection) {
		if (new Boolean(selection)) {
			BURG_ALARM_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(BURG_ALARM_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setBurgularAlarmAvailability() {
		if (new Boolean(data.get("BurgularAlarmAvailability"))) {
			BURG_ALARM_YES_LBL_CSS.click();
			seleniumCommands.staticWait(2);
			this.setBurgularAlarmType();
		} else {
			seleniumCommands.clickbyJS(BURG_ALARM_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setBurgularAlarmType(String type) {
		// seleniumCommands.waitForElementToBeVisible(By.cssSelector(DiscountPageLocators.BURG_ALARM_LOCAL_LBL_CSS));
		if (type.equals("Local")) {
			BURG_ALARM_LOCAL_LBL_CSS.click();
		} else if (type.equals("Central")) {
			BURG_ALARM_CENTRAL_LBL_XPATH.click();
		} else if (type.equals("Police")) {
			BURG_ALARM_POLICE_LBL_CSS.click();
		}
		return this;
	}

	public DiscountPage setBurgularAlarmType() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(DiscountPageLocators.BURG_ALARM_LOCAL_LBL_CSS));
		String platfrom = System.getProperty("platform");
		if (data.get("BurgAlarmType").equals("Local")) {
			if(platfrom.equalsIgnoreCase("granite")){
				BURG_ALARM_LOCAL_LBL_CSS_GRANITE.click();
			} else{
				BURG_ALARM_LOCAL_LBL_CSS.click();
			}
		} else if (data.get("BurgAlarmType").equals("Central")) {
			if(platfrom.equalsIgnoreCase("granite")){
				BURG_ALARM_CENTRAL_LBL_XPATH_GRANITE.click();
			} else{
				BURG_ALARM_CENTRAL_LBL_XPATH.click();
			}
		} else if (data.get("BurgAlarmType").equals("Police")) {
			BURG_ALARM_POLICE_LBL_CSS.click();
		}
		return this;
	}

	public DiscountPage setFireAlarmReportingAvailability(String selection) {
		if (new Boolean(selection)) {
			FIR_ALARM_REP_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(FIR_ALARM_REP_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setFireAlarmReportingAvailability() {
		if (new Boolean(data.get("FireAlarmReporting"))) {
			FIR_ALARM_REP_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(FIR_ALARM_REP_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSmokeAlarmAvailability(String smokeAlarmAvailability) {
		if (new Boolean(smokeAlarmAvailability)) {
			SMOKE_ALARM_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(SMOKE_ALARM_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSmokeAlarmAvailability() {
		if (new Boolean(data.get("SmokeAlarmAvailability"))) {
			SMOKE_ALARM_YES_LBL_CSS.click();
			this.setSmokeAlarmAllFloor();
		} else {
			seleniumCommands.clickbyJS(SMOKE_ALARM_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSmokeAlarmAllFloor(String allFloorAvailability) {
		if (new Boolean(allFloorAvailability)) {
			SMOKE_ALARM_ALLFLOOR_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(SMOKE_ALARM_ALLFLOOR_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSmokeAlarmAllFloor() {
		if (new Boolean(data.get("AllFloorAvailability"))) {
			SMOKE_ALARM_ALLFLOOR_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(SMOKE_ALARM_ALLFLOOR_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setDeadBoltsAvailability() {
		if (new Boolean(data.get("DeadBoltAvailability"))) {
			DEADBOLTS_YES_LBL_CSS.click();
			setDeadBoltsCount();
		} else {
			seleniumCommands.clickbyJS(DEADBOLTS_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setDeadBoltsAvailability(String deadBoltAvailability) {
		if (new Boolean(deadBoltAvailability)) {
			DEADBOLTS_YES_LBL_CSS.click();
			setDeadBoltsCount();
		} else {
			seleniumCommands.clickbyJS(DEADBOLTS_NO_LBL_CSS);
		}
		return this;
	}
	
	public DiscountPage setDeadBoltsCount() {
			seleniumCommands.type(DEADBOLTS_COUNT_CSS, data.get("DeadBoltCount"));
		return this;
	}

	public DiscountPage setVisibilityToNeighbours(String visibilityToNeighbour) {
		if (new Boolean(visibilityToNeighbour)) {
			VISIBLE_TO_NEIGH_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(VISIBLE_TO_NEIGH_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setVisibilityToNeighbours() {
		if (new Boolean(data.get("VisibilityToNeighbour"))) {
			VISIBLE_TO_NEIGH_YES_LBL_CSS.click();
		} else {
			seleniumCommands.clickbyJS(VISIBLE_TO_NEIGH_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSprinklerType(String value) {
		seleniumCommands.selectDropDownValueByText(SPRINKLER_DROP_CSS, value);
		return this;
	}

	public DiscountPage setSprinklerType() {
		seleniumCommands.selectDropDownValueByText(SPRINKLER_DROP_CSS, data.get("SprinklerType"));
		return this;
	}

	public DiscountPage setRoomersOrBoardersAvailability() {
		if (new Boolean(data.get("RoomersOrBoardersAvailability"))) {
			seleniumCommands.clickbyJS(ROOMR_OR_BORDR_YES_LBL_CSS);
			this.setRoomersOrBoardersNumber();
		} else {
			seleniumCommands.clickbyJS(ROOMR_OR_BORDR_NO_LBL_CSS);
		}
		return this;
	}
	
	public DiscountPage generateErrorMSgForAdditionalFields() {
			seleniumCommands.clickbyJS(ROOMR_OR_BORDR_YES_LBL_CSS);
			seleniumCommands.clickbyJS(FIREPLC_OR_WOODSTOV_YES_LBL_CSS);
			seleniumCommands.clickbyJS(POOL_YES_LBL_CSS);
			seleniumCommands.clickbyJS(TREMPOLINE_YES_LBL_CSS);
			seleniumCommands.clickbyJS(WATER_LEAK_YES_LBL_CSS);
		return this;
	}

	public DiscountPage setRoomersOrBoardersAvailability(boolean roomersOrBoardersAvailability) {
		if (roomersOrBoardersAvailability) {
			seleniumCommands.clickbyJS(ROOMR_OR_BORDR_YES_LBL_CSS);
			this.setRoomersOrBoardersNumber();
		} else {
			seleniumCommands.clickbyJS(ROOMR_OR_BORDR_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setRoomersOrBoardersNumber(String number) {
		seleniumCommands.type(ROOMR_OR_BORDR_NO_TXT_CSS, number);
		return this;
	}

	public DiscountPage setRoomersOrBoardersNumber() {
		seleniumCommands.type(ROOMR_OR_BORDR_NO_TXT_CSS, data.get("RoomersOrBoardersNumber"));
		return this;
	}

	public DiscountPage setNoOfUnits(String unit) {
		logger.info("Setting no of Unit value with " + unit);
		if (unit.equals("One")) {
			seleniumCommands.clickbyJS(UNIT_ONE_LBL_XPATH);
		} else if (data.get("NoOfUnits").equals("Two")) {
			seleniumCommands.clickbyJS(UNIT_TWO_LBL_XPATH);
		}
		return this;
	}

	public DiscountPage setNoOfUnits() {
		logger.info("Setting no of Unit value with " + data.get("NoOfUnits"));
		if (data.get("NoOfUnits").equals("One")) {
			seleniumCommands.clickbyJS(UNIT_ONE_LBL_XPATH);
		} else if (data.get("NoOfUnits").equals("Two")) {
			seleniumCommands.clickbyJS(UNIT_TWO_LBL_XPATH);
		}
		return this;
	}

	public DiscountPage setFirePlaceOrWoodStoveAvailability(boolean firePlaceOrWoodStoveAvailability) {
		logger.info("Setting firePlaceOrWoodStoveAvailability value with " + firePlaceOrWoodStoveAvailability);
		if (firePlaceOrWoodStoveAvailability) {
			seleniumCommands.clickbyJS(FIREPLC_OR_WOODSTOV_YES_LBL_CSS);
			setFirePlaceOrWoodStoveNumber();
		} else {
			seleniumCommands.clickbyJS(FIREPLC_OR_WOODSTOV_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setFirePlaceOrWoodStoveAvailability() {
		logger.info(
				"Setting firePlaceOrWoodStoveAvailability value with " + data.get("FirePlaceOrWoodStoveAvailability"));
		if (new Boolean(data.get("FirePlaceOrWoodStoveAvailability"))) {
			seleniumCommands.clickbyJS(FIREPLC_OR_WOODSTOV_YES_LBL_CSS);
			setFirePlaceOrWoodStoveNumber();
		} else {
			seleniumCommands.clickbyJS(FIREPLC_OR_WOODSTOV_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setFirePlaceOrWoodStoveNumber(String number) {
		seleniumCommands.type(FIREPLC_OR_WOODSTO_NO_TXT_CSS, number);
		return this;
	}

	public DiscountPage setFirePlaceOrWoodStoveNumber() {
		seleniumCommands.type(FIREPLC_OR_WOODSTO_NO_TXT_CSS, data.get("FirePlaceOrWoodStoveNumber"));
		return this;
	}

	public DiscountPage setPoolAvailability() {
		if (new Boolean(data.get("PoolAvailability"))) {
			seleniumCommands.clickbyJS(POOL_YES_LBL_CSS);
			this.setFenceAvailability();
			this.setDivingBoardAvailability();
			if(System.getProperty("platform").equalsIgnoreCase("granite")) {
				this.setSlideAvailability();
			}
		} else {
			seleniumCommands.clickbyJS(POOL_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setPoolAvailability(boolean poolAvailability) {
		if (poolAvailability) {
			seleniumCommands.clickbyJS(POOL_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(POOL_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setFenceAvailability(boolean fenceAvailability) {
		if (fenceAvailability) {
			seleniumCommands.clickbyJS(POOL_FENCE_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(POOL_FENCE_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setFenceAvailability() {
		if (new Boolean(data.get("FenceAvailability"))) {
			seleniumCommands.clickbyJS(POOL_FENCE_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(POOL_FENCE_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setDivingBoardAvailability() {
		if (new Boolean(data.get("DivingBoardAvailability"))) {
			seleniumCommands.clickbyJS(POOL_DIVEBOARD_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(POOL_DIVEBOARD_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSlideAvailability() {
		if (new Boolean(data.get("SlideAvailability"))) {
			seleniumCommands.clickbyJS(POOL_SLIDE_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(POOL_SLIDE_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setDivingBoardAvailability(boolean divingBoardAvailability) {
		if (divingBoardAvailability) {
			seleniumCommands.click(By.cssSelector(DiscountPageLocators.POOL_DIVEBOARD_YES_LBL_CSS));
		} else {
			seleniumCommands.click(By.cssSelector(DiscountPageLocators.POOL_DIVEBOARD_NO_LBL_CSS));
		}
		return this;
	}

	public DiscountPage setTrampolineAvailability(boolean trampolineAvailability) {
		if (trampolineAvailability) {
			seleniumCommands.clickbyJS(TREMPOLINE_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(TREMPOLINE_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setTrampolineAvailability() {
		if (new Boolean(data.get("TrampolineAvailability"))) {
			seleniumCommands.clickbyJS(TREMPOLINE_YES_LBL_CSS);
			this.setSafetyNetAvailability();
		} else {
			seleniumCommands.clickbyJS(TREMPOLINE_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSafetyNetAvailability() {
		if (new Boolean(data.get("SafetyNetAvailability"))) {
			seleniumCommands.clickbyJS(TREMPOLINE_SAFTYNET_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(TREMPOLINE_SAFTYNET_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setSafetyNetAvailability(boolean safetyNetAvailability) {
		if (safetyNetAvailability) {
			seleniumCommands.clickbyJS(TREMPOLINE_SAFTYNET_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(TREMPOLINE_SAFTYNET_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setLeakageOrFloodingHistory(boolean waterLeakage) {
		if (waterLeakage) {
			seleniumCommands.clickbyJS(WATER_LEAK_YES_LBL_CSS);
		} else {
			seleniumCommands.clickbyJS(WATER_LEAK_NO_LBL_CSS);
		}
		return this;
	}

	public DiscountPage setLeakageOrFloodingHistory() {
		if (new Boolean(data.get("WaterLeakage"))) {
			seleniumCommands.clickbyJS(WATER_LEAK_YES_LBL_CSS);
			this.setLeakageOrFloodingHistoryDetails();
		} else {
			seleniumCommands.clickbyJS(WATER_LEAK_NO_LBL_CSS);
		}
		setLeakageOrFloodingHistoryDetails();
		return this;
	}

	public DiscountPage setLeakageOrFloodingHistoryDetails(String details) {
		seleniumCommands.type(WATER_LEAK_DESC_TXT_CSS, details);
		return this;
	}

	public DiscountPage setLeakageOrFloodingHistoryDetails() {
		seleniumCommands.type(WATER_LEAK_DESC_TXT_CSS, data.get("WaterLeakageHistory"));
		return this;
	}

	public DiscountPage goNext() {
		seleniumCommands.clickbyJS(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
		return this;
	}

	public DiscountPage setDiscountPageDetails() {
		this.setFireExtinguishersDetails();
		this.setBurgularAlarmAvailability().setFireAlarmReportingAvailability()
				.setSmokeAlarmAvailability().setDeadBoltsAvailability().setVisibilityToNeighbours().setSprinklerType();
		return this;

	}

	public DiscountPage setiNowDiscountPageDetails() {
		this.withiNowSmokeDetector().withiNowBurglarAlarmType().withiNowFireAlarmType().withiNowGuardedGate().withiNowDeductible();
		return this;
	}

	public DiscountPage setiNowDiscountPageDetailsWithNoDiscounts() {
		seleniumCommands.clickbyJS(INOW_SMOKE_DETECTOR_NO);
		seleniumCommands.selectDropDownValueByText(INOW_BURGLAR_ALARM_DROPDOWN, "None");
		seleniumCommands.selectDropDownValueByText(INOW_FIRE_ALARM_DROPDOWN, "None");
		seleniumCommands.clickbyJS(INOW_GUARDED_GATE_NO);
		seleniumCommands.selectDropDownValueByText(INOW_DEDUCTIBLE_DROPDOWN, "$250");
		return this;
	}

	public DiscountPage withAdditionalDiscountDetails() {
		this.expandAdditionalPage();
		this.setRoomersOrBoardersAvailability().setFirePlaceOrWoodStoveAvailability()
				.setPoolAvailability().setTrampolineAvailability().setLeakageOrFloodingHistory();
		if(!System.getProperty("platform").equalsIgnoreCase("granite")){
			this.setNoOfUnits();
		}
		return this;

	}

	// Get Method

	private boolean getFireExtinguisStatus() {
		boolean flag = false;
		if (new Boolean(seleniumCommands.getAttributeValueAtLocator(FIRE_EXT_YES_VALUE_CSS, "checked"))) {
			flag = true;
		} else if (new Boolean(seleniumCommands.getAttributeValueAtLocator(FIRE_EXT_NO_VALUE_CSS, "checked"))) {
			flag = false;
		}
		return flag;
	}

	private boolean getBurglarAlarmStatus() {
		boolean flag = false;
		if (BURG_ALARM_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (BURG_ALARM_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private String getBurglarAlarmType() {
		if(System.getProperty("platform").equalsIgnoreCase("granite")) {
			if (BURG_ALARM_LOCAL_VALUE_CSS_GRANITE.isSelected()) {
				return "Local";
			} else if (BURG_ALARM_CENTRAL_VALUE_CSS_GRANITE.isSelected()) {
				return "Central";
			} else if (BURG_ALARM_POLICE_VALUE_CSS_GRANITE.isSelected()){
				return "Police";
			}
		}
		else {
			if (BURG_ALARM_LOCAL_VALUE_CSS.isSelected()) {
				return "Local";
			} else if (BURG_ALARM_CENTRAL_VALUE_CSS.isSelected()) {
				return "Central";
			} else if (BURG_ALARM_POLICE_VALUE_CSS.isSelected()) {
				return "Police";
			}
		}
		return null;
	}

	private boolean getFireAlarmReportingStatus() {
		boolean flag = false;
		if (FIRE_ALARM_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (FIRE_ALARM_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getSmokeAlarmStatus() {
		boolean flag = false;
		if (SMOKE_ALARM_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (SMOKE_ALARM_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getSmokeAlarmOnAllFloorStatus() {
		boolean flag = false;
		if (SMOKE_ALARM_ALLFLOOR_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (
				SMOKE_ALARM_ALLFLOOR_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getDeadBoltStatus() {
		boolean flag = false;
		if (DEADBOLTS_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (DEADBOLTS_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}
	
	private String getNoOfDeadBoltValue() {
		return seleniumCommands.getAttributeValueAtLocator(DEADBOLTS_COUNT_CSS, "value");
	}

	private boolean getVisibilityToNeighBourStatus() {
		boolean flag = false;
		if (VISIBLE_TO_NEIGH_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (
				VISIBLE_TO_NEIGH_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private String getSprinklerType() {
		return seleniumCommands.getSelectedOptionFromDropDown(SPRINKLER_DROP_CSS);
	}

	private boolean getRoomerOrBoarderStatus() {
		boolean flag = false;
		if (ROOMR_OR_BORDR_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else
			if (ROOMR_OR_BORDR_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private String getRoomerBoarderNumber() {
		return seleniumCommands.getAttributeValueAtLocator(ROOMR_OR_BORDR_NO_TXT_CSS, "value");
	}

	private String getNoOfUnitValue() {
		if (UNIT_ONE_VALUE_CSS.isSelected()) {
			return "One";
		} else if (UNIT_TWO_VALUE_CSS.isSelected()) {
			return "Two";
		}
		return null;
	}

	private boolean getFirePlaceOrWoodStoveStatus() {
		boolean flag = false;
		if (FIREPLC_OR_WOODSTOV_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (FIREPLC_OR_WOODSTOV_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private String getFirePlaceOrWoodStoveValue() {
		return seleniumCommands.getAttributeValueAtLocator(FIREPLC_OR_WOODSTO_NO_TXT_CSS, "value");
	}

	private boolean getPoolStatus() {
		boolean flag = false;
		if (POOL_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (POOL_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getPoolFenceStatus() {
		boolean flag = false;
		if (POOL_FENCE_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (POOL_FENCE_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getPoolDivingBoardStatus() {
		boolean flag = false;
		if (POOL_DIVEBOARD_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else
			if (POOL_DIVEBOARD_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getTrempolineStatus() {
		boolean flag = false;
		if (TREMPOLINE_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (TREMPOLINE_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getTrempolineSaftyNetStatus() {
		boolean flag = false;
		if (TREMPOLINE_SAFTYNET_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (TREMPOLINE_SAFTYNET_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private boolean getWaterLeakageStatus() {
		boolean flag = false;
		if (WATER_LEAK_YES_VALUE_CSS.isSelected()) {
			flag = true;
		} else if (WATER_LEAK_NO_VALUE_CSS.isSelected()) {
			flag = false;
		}
		return flag;
	}

	private String getWaterLeakageHistory() {
		return seleniumCommands.getAttributeValueAtLocator(WATER_LEAK_DESC_TXT_CSS, "value");
	}

	// Validation

	public Validation isFireExtinguisherFieldmarkedWithError() {
		if(seleniumCommands.isElementPresent(FIRE_EXT_TXT_CSS)) {
			return new Validation(seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(FIRE_EXT_TXT_CSS)),
					DataConstant.MANDATORY_ERROR_MSG);
		}
			return new Validation(seleniumCommands.getErrorMessageForDatePicker(FIRE_EXT_YES_LBL_CSS),
					DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowSmokeDetectorFieldmarkedWithError() {
			return new Validation(INOW_SMOKE_DETECTOR_ERR_MSG.getText(),
					DataConstant.MANDATORY_ERROR_MSG);
	}


	public Validation isInowBurglarAlarmFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDropdown(INOW_BURGLAR_ALARM_DROPDOWN),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowFireAlarmFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDropdown(INOW_FIRE_ALARM_DROPDOWN),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isInowDeductibleFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDropdown(INOW_DEDUCTIBLE_DROPDOWN),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isBurglarAlarmFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(BURG_ALARM_YES_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isBurglarAlarmOptionFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(BURG_ALARM_LOCAL_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isFireAlarmReportingFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(FIR_ALARM_REP_YES_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isSmokeAlarmFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(SMOKE_ALARM_YES_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isSmokeAlarmOptionFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(SMOKE_ALARM_ALLFLOOR_YES_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isDeadBoltFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(DEADBOLTS_YES_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation isResidenceVisibilityFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(VISIBLE_TO_NEIGH_NO_LBL_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	//Addition discount error fields
	
	public Validation isRoomerOrHeaterFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(ROOMR_OR_BORDR_NO_TXT_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isFireWoodStoveFieldmarkedWithError() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(FIREPLC_OR_WOODSTO_NO_TXT_CSS),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isFenceAvailabilityFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(POOL_FENCE_ERROR_XPATH),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isDivingBoardAvailabilityFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(POOL_DIVEBOARD_ERROR_XPATH),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isTrempolineSaftyNetAvailabilityFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(TREMPOLINE_ERROR_XPATH),
				DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation isWaterLeakHistoryFieldmarkedWithError() {
		return new Validation(seleniumCommands.getTextAtLocator(WATER_LEAK_DESC_ERROR_XPATH),
				DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation areInowHODiscountPageFieldsMakedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the fields on Discount page");
		isInowSmokeDetectorFieldmarkedWithError().shouldBeEqual("Smoke Detector field is not marked with Error");
		isInowBurglarAlarmFieldmarkedWithError().shouldBeEqual("Burglar alarm field is not marked with Error");
		isInowFireAlarmFieldmarkedWithError().shouldBeEqual("Fire alarm field is not marked with Error");
		isInowDeductibleFieldmarkedWithError().shouldBeEqual("Deductible field is not marked with Error");
		return new Validation(true);
	}

	public Validation areHODiscountPageFieldsMakedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the fields on Discount page");
		isFireExtinguisherFieldmarkedWithError().shouldBeEqual("Fire Extinu field is not marked with Error");
		isBurglarAlarmFieldmarkedWithError().shouldBeEqual("Burglar alarm field is not marked with Error");
		isFireAlarmReportingFieldmarkedWithError().shouldBeEqual("Fire alarm field is not marked with Error");
		isSmokeAlarmFieldmarkedWithError().shouldBeEqual("Smoke alarm field is not marked with Error");
		isDeadBoltFieldmarkedWithError().shouldBeEqual("Dead Bolt field is not marked with Error");
		isResidenceVisibilityFieldmarkedWithError()
				.shouldBeEqual("Residence visibility to neighbour field is not marked with Error");
		return new Validation(true);
	}
	
	public Validation areHOAdditionalDiscountPageFieldsMakedWithMandatoryError() {
		logger.info("Validating the Mandatory Error for the fields on Discount page");
		isRoomerOrHeaterFieldmarkedWithError().shouldBeEqual("Roomer or Heater fields are not marked with error");
		isFireWoodStoveFieldmarkedWithError().shouldBeEqual("Roomer or Heater fields are not marked with error");
		isFenceAvailabilityFieldmarkedWithError().shouldBeEqual("Pool Fence field is not marked with error");
		isDivingBoardAvailabilityFieldmarkedWithError().shouldBeEqual("Pool Diving board field is not marked with error");
		isTrempolineSaftyNetAvailabilityFieldmarkedWithError().shouldBeEqual("TrempolineSaftyNet field is not marked with error");
		isWaterLeakHistoryFieldmarkedWithError().shouldBeEqual("WaterLeakHistory field is not marked with error");
		return new Validation(true);
	}

	public Validation isDiscountPageLoaded() {
		seleniumCommands.waitForElementToBePresent(MANDATORY_FIELD_CLASS);
		return new Validation(seleniumCommands.isElementPresent(MANDATORY_FIELD_CLASS));
	}

	public Validation isInowDiscountPageLoaded() {
		seleniumCommands.waitForElementToBePresent(INOW_SMOKE_DETECTOR_YES);
		return new Validation(seleniumCommands.isElementPresent(INOW_SMOKE_DETECTOR_YES));
	}

	public void isFireExtinguisherAvailable() {
		System.out.println(seleniumCommands.isElementPresent(FIRE_EXT_TXT_CSS) + "==============================================>>>>>>>>>>");
		if(seleniumCommands.isElementPresent(FIRE_EXT_TXT_CSS)) {
			new Validation(seleniumCommands.getAttributeValueAtLocator(FIRE_EXT_TXT_CSS, "value"), data.get("FireExtCount"))
					.shouldBeEqual("Fire Ext value is not matched");
		} else {
			new Validation(getFireExtinguisStatus()).shouldBeTrue("Fire Ext value is not matched");
		}
	}

	public Validation isInowSmokeDetectorSelected() {
		String smokeDetectorValue = "";
			if(seleniumCommands.getAttributeValueAtLocator(INOW_SMOKE_DETECTOR_INPUT_YES, "aria-checked").equalsIgnoreCase("true"))
				smokeDetectorValue = "Yes";
			else if(seleniumCommands.getAttributeValueAtLocator(INOW_SMOKE_DETECTOR_INPUT_NO, "aria-checked").equalsIgnoreCase("true"))
				smokeDetectorValue = "NO";
			return new Validation(smokeDetectorValue.equalsIgnoreCase(data.get("INOW_SmokeDetector")));
	}

	public Validation isInowGuardedGateSelected() {
		String guardedGateValue = "";
		if(seleniumCommands.getAttributeValueAtLocator(INOW_GUARDED_GATE_INPUT_YES, "aria-checked").equalsIgnoreCase("true"))
			guardedGateValue = "Yes";
		else if(seleniumCommands.getAttributeValueAtLocator(INOW_GUARDED_GATE_INPUT_NO, "aria-checked").equalsIgnoreCase("true"))
			guardedGateValue = "NO";
		return new Validation(guardedGateValue.equalsIgnoreCase(data.get("INOW_GuardedGate")));
	}

	public Validation isInowBurglarAlarmAvailable() {
		return new Validation(seleniumCommands.getSelectedOptionFromDropDown(INOW_BURGLAR_ALARM_DROPDOWN).equalsIgnoreCase(data.get("INOW_BurglarAlarm")));
	}

	public Validation isInowFireAlarmAvailable() {
		return new Validation(seleniumCommands.getSelectedOptionFromDropDown(INOW_FIRE_ALARM_DROPDOWN).equalsIgnoreCase(data.get("INOW_FireAlaram")));
	}
	public Validation isInowDeductibleEqualTo() {
		return new Validation(seleniumCommands.getSelectedOptionFromDropDown(INOW_DEDUCTIBLE_DROPDOWN).equalsIgnoreCase(data.get("INOW_Deductible")));
	}

	public Validation isBurglarAlarmAvailable() {
		return new Validation(getBurglarAlarmStatus());
	}

	public Validation isBurglarAlarmTypeEqualsTo() {
		return new Validation(getBurglarAlarmType(), data.get("BurgAlarmType"));
	}

	public Validation isFireAlarmReportingAvailable() {
		return new Validation(getFireAlarmReportingStatus());
	}

	public Validation isSmokeAlarmAvailable() {
		return new Validation(getSmokeAlarmStatus());
	}

	public Validation isSmokeAlarmOnAllFloorAvailable() {
		return new Validation(getSmokeAlarmOnAllFloorStatus());
	}

	public Validation isDeadBoltAvailable() {
		return new Validation(getDeadBoltStatus());
	}
	
	public Validation isDeadBoltValueEqualsTo() {
		return new Validation(getNoOfDeadBoltValue(), data.get("DeadBoltCount"));
	}

	public Validation isResidenceVisibileToNeighbour() {
		return new Validation(getVisibilityToNeighBourStatus());
	}

	public Validation isSprinklerTypeEqualsTo() {
		return new Validation(getSprinklerType(), data.get("SprinklerType"));
	}

	public Validation isRoomerOrBoarderAvailable() {
		return new Validation(getRoomerOrBoarderStatus());
	}

	public Validation isRoomerOrBoarderValueEqualsTo() {
		return new Validation(getRoomerBoarderNumber(), data.get("RoomersOrBoardersNumber"));
	}

	public Validation isNoOfUnitValueEqualsTo() {
		return new Validation(getNoOfUnitValue(), data.get("NoOfUnits"));
	}

	public Validation isFirePlaceOrWoodStoveAvailable() {
		return new Validation(getFirePlaceOrWoodStoveStatus());
	}

	public Validation isFirePlaceOrWoodValueEqualsTo() {
		return new Validation(getFirePlaceOrWoodStoveValue(),  data.get("FirePlaceOrWoodStoveNumber"));
	}

	public Validation isPoolAvailable() {
		return new Validation(getPoolStatus());
	}

	public Validation isPoolFenceAvailable() {
		return new Validation(getPoolFenceStatus());
	}

	public Validation isPoolDivingBoardAvailable() {
		return new Validation(getPoolDivingBoardStatus());
	}

	public Validation isTrempolineAvailable() {
		return new Validation(getTrempolineStatus());
	}

	public Validation isTrempolineSaftyNetAvailable() {
		return new Validation(getTrempolineSaftyNetStatus());
	}

	public Validation isWaterHistoryInPastYEarsAvailable() {
		return new Validation(getWaterLeakageStatus());
	}

	public Validation isWaterHistoryIValueEqualsTo() {
		return new Validation(getWaterLeakageHistory(), data.get("WaterLeakageHistory"));
	}

	public Validation areDiscountPageValueSaved() {
		isFireExtinguisherAvailable();
		isBurglarAlarmAvailable().shouldBeTrue("Burglar Alarm value is not matched");
		isBurglarAlarmTypeEqualsTo().shouldBeEqual("Burglar Alarm Type value is not matched");
		isFireAlarmReportingAvailable().shouldBeTrue("Fire Alarm reporting value is not matched");
		isSmokeAlarmAvailable().shouldBeTrue("Smoke Alarm value is not matched");
		isSmokeAlarmOnAllFloorAvailable().shouldBeTrue("Smoke alarm on all floor value is not matched");
		isDeadBoltAvailable().shouldBeTrue("Dead bolt value is not matched");
		isResidenceVisibileToNeighbour().shouldBeTrue("Visibility to neighbour value is not matched");
		isSprinklerTypeEqualsTo().shouldBeEqual("Sprinkler type value is not matched");

		// Additional details

		return new Validation(true);
	}

	public Validation areInowDiscountPageValueSaved() {
		isInowSmokeDetectorSelected().shouldBeTrue("Smoke Detector value is not matched");
		isInowGuardedGateSelected().shouldBeTrue("Guarded Gate value is not matched");
		isInowBurglarAlarmAvailable().shouldBeTrue("Burglar Alarm value is not matched");
		isInowFireAlarmAvailable().shouldBeTrue("Fire Alarm value is not matched");
		isInowDeductibleEqualTo().shouldBeTrue("Deductible value is not matched");

		return new Validation(true);
	}

	public Validation areDiscountPageValuesNotSaved() {
		isFireExtinguisherAvailable();
		isBurglarAlarmAvailable().shouldBeFalse("Burglar Alarm value is not matched");
		isFireAlarmReportingAvailable().shouldBeFalse("Fire Alarm reporting value is not matched");
		isSmokeAlarmAvailable().shouldBeFalse("Smoke Alarm value is not matched");
		isDeadBoltAvailable().shouldBeFalse("Dead bolt value is not matched");
		isResidenceVisibileToNeighbour().shouldBeFalse("Visibility to neighbour value is not matched");
		isSprinklerTypeEqualsTo().shouldNotBeEqual("Sprinkler type value is not matched");

		return new Validation(true);
	}

	public Validation areAdditionalDiscountPageValueSaved() {

		// Additional details
		isRoomerOrBoarderAvailable().shouldBeTrue("Roomer or Boarders value is not matched");
		isRoomerOrBoarderValueEqualsTo().shouldBeEqual("Roomer or boarder value is not matched");
		if(!System.getProperty("platform").equalsIgnoreCase("granite"))
			isNoOfUnitValueEqualsTo().shouldBeEqual("No of Units value is not matched");
		isFirePlaceOrWoodStoveAvailable().shouldBeTrue("Fire Place or Wood Stove value is not matched");
		isFirePlaceOrWoodValueEqualsTo().shouldBeEqual("Fireplace value is not matched");
		isPoolAvailable().shouldBeTrue("Pool availability value is not matched");
		isPoolFenceAvailable().shouldBeTrue("Pool Fence is not available");
		isPoolDivingBoardAvailable().shouldBeTrue("Diving board availability value is not matched");
		isTrempolineAvailable().shouldBeTrue("Trempoline availability value is not matched");
		isTrempolineSaftyNetAvailable().shouldBeTrue("Trempoline safty net value is not matched");
		isWaterHistoryInPastYEarsAvailable().shouldBeTrue("Water Leakage history value is not matched");
		isWaterHistoryIValueEqualsTo().shouldBeEqual("Water LEakage History Desc value is not matched");

		return new Validation(true);
	}

	public Validation areDiscountPageDetailsWithAdditionalMatchingBackEnd(String jsonData) throws Exception {
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getDiscountDataWithAdditonalFromBackEnd(jsonData));
	}
	
	public Validation areDiscountPageDetailsMatchingBackEnd(String jsonData) throws Exception {
		return MapCompare.compareMap(data,
				ParseQuoteData.getDiscountDataFromBackEnd(jsonData));
	}

	public Validation areInowDiscountPageMandatoryFieldsMakedWithAsterisk() {
		logger.info( "Validating the Asterisk for mandatory field on Your Home page");
		isAsteriskPresentForMandatoryField(INOW_SMOKE_DETECTOR_VALUE_MODEL).shouldBeEqual("Smoke detector Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_BURGLAR_ALARM_VALUE_MODEL).shouldBeEqual("burglar alarm type is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_FIRE_ALARM_VALUE_MODEL).shouldBeEqual("Fire Alarm type Field is not marked with Asterisk");
		isAsteriskPresentForMandatoryField(INOW_DEDUCTIBLE_VALUE_MODEL).shouldBeEqual("Deductible value Field is not marked with Asterisk");
		return new Validation(true);
	}
	
	
	

}
