/**
 * 
 */
package com.guidewire.portals.qnb.pages.scheduleditemComponant;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class PropertyLocationModel {
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    HashMap<String, String> uiData = new HashMap<>();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[class*='fade'] select")
    WebElement LIMIT_DROP_CSS;
    
    @FindBy(css = "[model='dataItem.getVM()'] input")
    WebElement PROPERTY_DESCRIPTION_TXT_CSS;

    @FindBy(css = "[on-click='commit(locationForm)']")
    WebElement ADD_LOC_BTN_CSS;
    
    @FindBy(css = "[on-click='undo()']")
    WebElement CANCEL_ADD_LOC_BTN_CSS;
    
    @FindBy(css = "[model='address.addressLine1']")
    WebElement ADDLINE1_CSS;
    
    @FindBy(css = "[model='address.addressLine2']")
    WebElement ADDLINE2_CSS;
    
    @FindBy(css = "[model='address.addressLine3']")
    WebElement ADDLINE3_CSS;
    
    @FindBy(css = "[model='address.city']")
    WebElement CITY_CSS;
    
    @FindBy(css = "[model='address.postalCode']")
    WebElement ZIPCODE_CSS;
    
    @FindBy(css = "[model='address.state']")
    WebElement STATE_CSS;
    
    @FindBy(css = "[gw-pl-select='chosenExistingLocation.value']")
    WebElement EXISTING_LOC_DROP_CSS;
    
    @FindBy(css = "[class*='fade'] label[for*='Right'][class='gw-second']")
    WebElement NEW_LOC_RBTN_CSS;

    @FindBy(css = "[gw-pc-scheduled-coverages='offeringSchedule.model.schedules'] table[class*='gw-schedule-table'] button[on-click='add()'][class*='Table']")
    WebElement ADD_PERSONAL_PROPERTY_BUTTON_HOP;
    
    By SCHEDULE_PERSONAL_PROPERTY_SELECTORS = By.cssSelector("[class*='gw-schedule-table__row gw-schedule-table__new-row Table-hashed__gwTableRow'] td[class*='ng-scope'] div[class*='gw-schedule-table__error']");
    By ADDLINE1 = By.cssSelector("[model='address.addressLine1'] input");
    By ADDLINE2 = By.cssSelector("[model='address.addressLine2'] input");
    By ADDLINE3 = By.cssSelector("[model='address.addressLine3'] input");
    By CITY = By.cssSelector("[model='address.city'] input");
    By ZIPCODE = By.cssSelector("[model='address.postalCode'] input");
    By STATE = By.cssSelector("[model='address.state'] select");
    By PROPERTY_INPUT_BOX = By.cssSelector("[class*='gw-schedule-table__data-cell gw-schedule-table__data-cell_edit']");

    int INDEX = -1;
    
    public PropertyLocationModel() {
        seleniumCommands.pageWebElementLoader(this);
    }
    
    public PropertyLocationModel(int index) {
    	this.INDEX = index;
        seleniumCommands.pageWebElementLoader(this);
    }

    //Set Methods
    public PropertyLocationModel setIncreasedLimit() {
    	seleniumCommands.selectDropDownValueByText(LIMIT_DROP_CSS, data.get("SchedulePropertyLimit"));
    	return this;
    }
    
    public PropertyLocationModel setDescription() {
    	String description=UUID.randomUUID().toString();
    	data.put("SchedulePropertyLocationDescription", description);
    	seleniumCommands.type(PROPERTY_DESCRIPTION_TXT_CSS, description);
    	return this;
    }
    
    public PropertyLocationModel addLocation() {
    	seleniumCommands.click(ADD_LOC_BTN_CSS);
    	return this;
    }
    
    public PropertyLocationModel fillNewLocationFrom() {
    	seleniumCommands.waitForElementToBeVisible(EXISTING_LOC_DROP_CSS);
    	seleniumCommands.clickbyJS(NEW_LOC_RBTN_CSS);
    	seleniumCommands.waitForElementToBeVisible(ADDLINE1);
    	seleniumCommands.type(ADDLINE1, data.get("AddressLine1"));
    	seleniumCommands.type(ADDLINE2, data.get("AddressLine2"));
    	seleniumCommands.type(ADDLINE3, data.get("AddressLine3"));
    	seleniumCommands.type(CITY, data.get("City"));
    	seleniumCommands.type(ZIPCODE, data.get("ZipCode"));
    	seleniumCommands.selectDropDownValueByText(STATE, data.get("State"));
    	this.addLocation();
    	data.put("SchedulePropertyLocation", data.get("AddressLine1") + " " + data.get("AddressLine2") + " " + data.get("AddressLine3") + " " + data.get("City") + " " + data.get("StateValue") + " " +data.get("ZipCode"));
    	return this;
    }
    
    //Validation
    
    public void validateNewLocationPopUp() {
    	seleniumCommands.waitForElementToBeVisible(ADDLINE1_CSS);
    	new Validation(seleniumCommands.isElementPresent(ADDLINE1_CSS)).shouldBeTrue("Addline 1 field is not present");
    	new Validation(seleniumCommands.isElementPresent(CITY_CSS)).shouldBeTrue("City field is not present");
    	new Validation(seleniumCommands.isElementPresent(ZIPCODE_CSS)).shouldBeTrue("Zipcode field is not present");
    	new Validation(seleniumCommands.isElementPresent(STATE_CSS)).shouldBeTrue("State field is not present");
    	new Validation(seleniumCommands.isElementPresent(EXISTING_LOC_DROP_CSS)).shouldBeTrue("Existing loc drop field is not present");
    	new Validation(seleniumCommands.isElementPresent(ADD_LOC_BTN_CSS)).shouldBeTrue("Add loc button field is not present");
    	new Validation(seleniumCommands.isElementPresent(CANCEL_ADD_LOC_BTN_CSS)).shouldBeTrue("Cancel Add loc button field is not present");
    	if(INDEX == 4){
    		new Validation(seleniumCommands.isElementPresent(PROPERTY_DESCRIPTION_TXT_CSS)).shouldBeTrue("Cancel Add loc button field is not present");
    	}
    }
    
    public void validateNewLocationPopUpMandatoryFields() {
    	seleniumCommands.clickbyJS(NEW_LOC_RBTN_CSS);
    	seleniumCommands.waitForElementToBeVisible(ADDLINE1_CSS);
    	this.addLocation();
    	new Validation(seleniumCommands.getTextAtLocator(LIMIT_DROP_CSS.findElement(By.xpath("./../../following-sibling::div"))), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Increased Limit error message is not correct");
    	new Validation(seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(ADDLINE1)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Addline1 error message is not correct");
    	new Validation(seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(ZIPCODE)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Zipcode error message is not correct");
    	new Validation(seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(STATE)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("State error message is not correct");
    	new Validation(seleniumCommands.getErrorMessageForTxtBox(seleniumCommands.findElement(CITY)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("City error message is not correct");
    	if(INDEX == 4){
    		new Validation(seleniumCommands.getTextAtLocator(PROPERTY_DESCRIPTION_TXT_CSS.findElement(By.xpath("./../../following-sibling::div"))), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Increased Limit error message is not correct");
    	}
    }

    public void validateNewScheduledPersonalPropertyPopUpMandatoryFields() {
        seleniumCommands.click(ADD_PERSONAL_PROPERTY_BUTTON_HOP);
        List<WebElement> selectors = seleniumCommands.getElements(SCHEDULE_PERSONAL_PROPERTY_SELECTORS);
        new Validation(seleniumCommands.getTextAtLocator(selectors.get(0)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Property Type error message is not present.");
        new Validation(seleniumCommands.getTextAtLocator(selectors.get(1)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Property Amount error message is not present.");
        new Validation(seleniumCommands.getTextAtLocator(selectors.get(2)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Property Deductible error message is not present.");
        new Validation(seleniumCommands.getTextAtLocator(selectors.get(3)), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Property Valuation method error message is not present.");
    }
    
    

    

}
