package com.guidewire.portals.qnb.pages;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;

public class DriverDetailsPage extends CommonPage
{

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());	
	
	//HO Locators
	@FindBy(css = "[label='First Name'] div>span")
	 WebElement FIRST_NAME_VALUE_CSS;
	
	@FindBy(css = "[label='First Name'] div>input")
	 List<WebElement> FIRST_NAME_TXT_CSS;

	@FindBy(css = "[label='First Name'] [class='gw-required-asterisk']")
	WebElement FIRSTNAME_ASTERISK_CSS;
	
	@FindBy(css = "[model*='lastName'] div>span")
	 WebElement LAST_NAME_VALUE_CSS;
	
	@FindBy(css = "div[model='contact.lastName'] div>input, [label='Last Name'] div>input")
	 List<WebElement> LAST_NAME_TXT_CSS;

	@FindBy(css = "[model*='lastName'] [class='gw-required-asterisk']")
	WebElement LASTNAME_ASTERISK_CSS;
	
	@FindBy(id = "localDateChooser")
	 List<WebElement> DOB_TXT_ID;

	@FindBy(id = "localDateChooser")
	 WebElement GPA_DOB_TXT_ID;
	
	@FindBy(css = "span[ng-show='driver.person.value.accountHolder && !editableDriverDOB'][aria-hidden='false'], [model*='dateOfBirth'] ng-transclude span[ng-show], [label='Date of Birth'] span[ng-show='readonly']")
	 WebElement DOB_VALUE_CSS;
	
	@FindBy(css = "div[model='driver.gender'] select, [label='Gender'] select")
	 List<WebElement> GENDER_DROP_CSS;

	@FindBy(css = "div[model='driver.dateOfBirth'] [class='gw-required-asterisk'], [label='Date of Birth'] [class='gw-required-asterisk']")
	 WebElement DOB_ASTERISK_CSS;
	
	@FindBy(css = "div[model='driver.licenseState'] span")
	 WebElement LICENSE_NUM_LBL_CSS;

	 @FindBy(css = "[model='driver.licenseNumber'] div input, [label*='License Number'] input")
	 List<WebElement> LICENSE_NUM_TXT_CSS;

	@FindBy(css = "[model='driver.dateOfBirth'] ng-transclude")
	WebElement DOB_TXT_CSS;
	
	@FindBy(css = "[model='driver.licenseNumber'] [class='gw-required-asterisk'], [label*='License Number'] [class='gw-required-asterisk']")
	 WebElement LICENSE_NUM_ASTERISK_CSS;
	
	@FindBy(css = "div[model='driver.licenseState'] select, [label*='License State'] select")
	 List<WebElement> LICENSE_STATE_DROP_CSS;

	@FindBy(css = "div[model='driver.licenseState'] span")
	 WebElement LICENSE_STATE_LABEl_CSS;
	
	@FindBy(css = "[model='driver.licenseState'] [class='gw-required-asterisk'], [label*='License State'] [class='gw-required-asterisk']")
	 WebElement LICENSE_STATE_ASTERISK_CSS;
	
	@FindBy(css = "div[label='Year First Licensed'] select")
	 List<WebElement> LICENSE_FIRST_YEAR_DROP_CSS;

	@FindBy(css = "div[model='driver.yearLicensed'] select")
	 WebElement LICENSE_FIRST_YEAR_LABEL_CSS;
	
	@FindBy(css = "[model*='yearLicensed'] [class='gw-required-asterisk']")
	 WebElement LICENSE_YEAR_ASTERISK_CSS;
	
	@FindBy(css = "[model*='accidents'] [gw-pl-stepper-select] .ng-binding")
	 WebElement NO_OF_ACCIDENT_LBL_CSS;

	@FindBy(css = "div[ng-click='selectNextValue()']")

	 WebElement NO_OF_ACCIDENT_INCREMENT_BTN_CSS;
	
	@FindBy(css = "div[ng-click='selectPrevValue()']")
	 WebElement NO_OF_ACCIDENT_DECREMENT_BTN_CSS;
	
	@FindBy(css = "[model*='accidents'] [class='gw-required-asterisk']")
	 WebElement NO_OF_ACCIDENT_ASTERISK_CSS;

	@FindBy(css = "[model*='violations'] [gw-pl-stepper-select] .ng-binding")
	 WebElement NO_OF_VIOLATION_LBL_CSS;
	
	@FindBy(css = "[model*='violations'] div[ng-click='selectNextValue()']")
	 WebElement NO_OF_VIOLATION_INCREMENT_BTN_CSS;
	
	@FindBy(css = "[model*='violations'] div[ng-click='selectPrevValue()']")
	 WebElement NO_OF_VIOLATION_DECREMENT_BTN_CSS;
	
	@FindBy(css = "[model*='violations'] [class='gw-required-asterisk']")
	 WebElement NO_OF_VIOLATION_ASTERISK_CSS;
	
	@FindBy(css = "button[ng-click='goToCancel()']")
	 WebElement CANCEL_BTN_CSS;
	
	@FindBy(css = "button[on-click='addDriver(form)']")
	 WebElement ADD_DRIVER_YES_BTN_CSS;
	
	@FindBy(css = "[on-click='goToNext()']")
	WebElement ADD_DRIVER_NO_BTN_CSS;
	
	@FindBy(id = "driversTable")
	 WebElement DRIVER_TABLE_ID;

	@FindBy(css = "[name='localDateChooser'] i")
	WebElement DOB_BTN_CSS;

	By DBO_BUTTON_LEFT = By.cssSelector("[data-datetimepicker-config*='datepicker4'] [class='left']");

	By DBO_YEAR = By.className("year");

	By DBO_MONTH = By.className("month");

	By DBO_DAY = By.cssSelector("[data-datetimepicker-config*='datepicker4'] [class*='day']");


	By VEHICLE_SECTION_HEADER = By.xpath("//div[@class='gw-vehicle-section-header-content']");

	By NEXT_BUTTON = By.cssSelector("button[on-click='goToNext()'][aria-hidden='false']");

	String tableID = "driversTable";
	
	//Replace the ROW_NUM with the row you want to edit
	String EDIT_BTN_CSS = "[id='driversTable'] tr:nth-child(ROW_NUM) span[class='fa fa-pencil']";
	
	//Replace the ROW_NUM with the row you want to edit
	String DELETE_BTN_CSS = "[id='driversTable'] tr:nth-child(ROW_NUM) span[class='fa fa-trash']";
	
	public DriverDetailsPage() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public DriverDetailsPage(Object obj) {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		
	}
	
	public DriverDetailsPage goNext()
	{
		ADD_DRIVER_NO_BTN_CSS.click();
		return this;
	}
	
	public VehicleDetailsPage goToVehicleDetailsPage()
	{
		this.clickNext();
		if(this.data.size() > 0)
		{
			return new VehicleDetailsPage(this.data);
		}
		else
		{
			return new Pagefactory().getVehicelDetailsPage();
		}
	}
	
	//Set Methods
	
	public DriverDetailsPage setFirstName() {
		seleniumCommands.type(FIRST_NAME_TXT_CSS.get(FIRST_NAME_TXT_CSS.size()-1), data.get("DriverFirstName"));
		return this;
	}
	
	public DriverDetailsPage setFirstName(String firstName) {
		seleniumCommands.type(FIRST_NAME_TXT_CSS.get(FIRST_NAME_TXT_CSS.size()-1), firstName);
		return this;
	}

	public DriverDetailsPage setLastName(String lastName) {
		seleniumCommands.type(LAST_NAME_TXT_CSS.get(LAST_NAME_TXT_CSS.size()-1), lastName);
		return this;
	}
	
	public DriverDetailsPage setLastName() {
		seleniumCommands.type(LAST_NAME_TXT_CSS.get(LAST_NAME_TXT_CSS.size()-1), data.get("DriverLastName"));
		return this;
	}
	
	public DriverDetailsPage setDOB(String dob) {
		seleniumCommands.type(DOB_TXT_ID.get(DOB_TXT_ID.size()-1), dob);
		return this;
	}
	
	public DriverDetailsPage setDOB() {
		seleniumCommands.type(DOB_TXT_ID.get(DOB_TXT_ID.size()-1), data.get("DOB"));
		return this;
	}

	public DriverDetailsPage setDOBGPA(String dob) {
		GPA_DOB_TXT_ID.clear();
		if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
			seleniumCommands.click(DOB_BTN_CSS);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.getElements(DBO_YEAR).get(1).click();
			seleniumCommands.getElements(DBO_MONTH).get(11).click();
			seleniumCommands.getElements(DBO_DAY).get(12).click();
		}
		else {
			GPA_DOB_TXT_ID.sendKeys(dob);
		}
		return this;
	}

	public DriverDetailsPage setDOBGPA() {
		if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
			seleniumCommands.click(DOB_BTN_CSS);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.click(DBO_BUTTON_LEFT);
			seleniumCommands.getElements(DBO_YEAR).get(1).click();
			seleniumCommands.getElements(DBO_MONTH).get(11).click();
			seleniumCommands.getElements(DBO_DAY).get(12).click();
		}
		else{
			GPA_DOB_TXT_ID.clear();
			GPA_DOB_TXT_ID.sendKeys(data.get("DriverDOB"));
		}
		return this;
	}

	public DriverDetailsPage setDOBUnder25() {
		GPA_DOB_TXT_ID.clear();
		GPA_DOB_TXT_ID.sendKeys(data.get("DriverDOBUnder25"));
		return this;
	}

	public DriverDetailsPage setGender() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(GENDER_DROP_CSS.get(GENDER_DROP_CSS.size()-1), data.get("DriverGendor"));

		return this;
	}
	
	public DriverDetailsPage setGender(String gendor) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(GENDER_DROP_CSS.get(GENDER_DROP_CSS.size()-1), gendor);
		return this;
	}
	
	public DriverDetailsPage setDriverLicenseNumber() {
		seleniumCommands.type(LICENSE_NUM_TXT_CSS.get(LICENSE_NUM_TXT_CSS.size()-1), data.get("DriverLicenseNum"));
		return this;
	}
	
	public DriverDetailsPage setDriverLicenseNumber(String licenseNum) {
		seleniumCommands.type(LICENSE_NUM_TXT_CSS.get(LICENSE_NUM_TXT_CSS.size()-1), licenseNum);
		return this;
	}

	public DriverDetailsPage setLIcenseState() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(LICENSE_STATE_DROP_CSS.get(LICENSE_STATE_DROP_CSS.size()-1), data.get("DriverLicenseState"));
		return this;

	}
	
	public DriverDetailsPage setLIcenseState(String lIcenseState) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(LICENSE_STATE_DROP_CSS.get(LICENSE_STATE_DROP_CSS.size()-1), lIcenseState);
		return this;
	}

	public DriverDetailsPage setYearFirstLicensed() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(LICENSE_FIRST_YEAR_DROP_CSS.get(LICENSE_FIRST_YEAR_DROP_CSS.size()-1), data.get("FirstYearLicensed"));
		return this;
	}
	
	public DriverDetailsPage setYearFirstLicensed(String firstYear) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.selectDropDownValueByText(LICENSE_FIRST_YEAR_DROP_CSS.get(LICENSE_FIRST_YEAR_DROP_CSS.size()-1), firstYear);
		return this;
	}
	
	public DriverDetailsPage setNoOfAccident() {
		int no = Integer.parseInt(data.get("AccidentNum"));
		while(no!=0)
		{
			NO_OF_ACCIDENT_INCREMENT_BTN_CSS.click();
			no--;
		}
		return this;
	}
	
	public DriverDetailsPage setNoOfAccident(String noOfAcc) {
		int no = Integer.parseInt(noOfAcc);
		while(no!=0)
		{
			NO_OF_ACCIDENT_INCREMENT_BTN_CSS.click();
			no--;
		}
		return this;
	}
	
	public DriverDetailsPage setNoOfViolation() {
		int no = Integer.parseInt(data.get("ViolationNum"));
		while(no!=0)
		{
			NO_OF_VIOLATION_INCREMENT_BTN_CSS.click();
			no--;
		}
		return this;
	}
	
	public DriverDetailsPage setNoOfViolation(String noOfVio) {
		int no = Integer.parseInt(noOfVio);
		while(no!=0)
		{
			NO_OF_VIOLATION_INCREMENT_BTN_CSS.click();
			no--;
		}
		return this;
	}
	
	public DriverDetailsPage setPrimaryDriverDetails() {
		this.setGender().setDriverLicenseNumber().setYearFirstLicensed().setLIcenseState().setNoOfAccident().setNoOfViolation();
		return this;
	}
	
	public DriverDetailsPage withNewDriver() {
		seleniumCommands.click(ADD_DRIVER_YES_BTN_CSS);
		List<WebElement> allElements =seleniumCommands.findElements(By.id("localDateChooser"));
		this.setFirstName(data.get("NewDriverFirstName"))
			.setLastName(data.get("NewDriverLastName"))
			.setDOB(data.get("NewDriverDOB"))
			.setGender(data.get("NewDriverGendor"))
			.setDriverLicenseNumber(data.get("NewDriverLicenseNum"))
			.setYearFirstLicensed(data.get("NewDriverFirstYearLicensed"))
			.setLIcenseState(data.get("NewDriverLicenseState"));
		return this;
	}

	public DriverDetailsPage clickYes() {
		seleniumCommands.click(ADD_DRIVER_YES_BTN_CSS);
		return this;
	}

	public DriverDetailsPage editDriverDetails(String rownum) {
		ThreadLocalObject.getDriver().findElement(By.cssSelector(EDIT_BTN_CSS.replace("ROW_NUM",rownum))).click();
		seleniumCommands.waitForElementToBeClickable(By.id(tableID));
		return this;
	}
	
	public DriverDetailsPage deleteDriver(String rownum) {
		ThreadLocalObject.getDriver().findElement(By.cssSelector(DELETE_BTN_CSS.replace("ROW_NUM",rownum)));
		return this;
	}
	
	private String getGender() {
		return seleniumCommands.getSelectedOptionFromDropDown(GENDER_DROP_CSS.get(GENDER_DROP_CSS.size()-1));
	}
	
	private String getDriverLicenseNumber() {
		return seleniumCommands.getValueAttributeFromLocator(LICENSE_NUM_TXT_CSS.get(LICENSE_NUM_TXT_CSS.size()-1));
	}
	
	private String getDriverLicenseState() {
		return seleniumCommands.getSelectedOptionFromDropDown(LICENSE_STATE_DROP_CSS.get(LICENSE_STATE_DROP_CSS.size()-1));
	}
	
	private String getDriverLicenseFirstYear() {
		return seleniumCommands.getSelectedOptionFromDropDown(LICENSE_FIRST_YEAR_DROP_CSS.get(LICENSE_FIRST_YEAR_DROP_CSS.size()-1));
	}
	
	public String getNoOfAccident() {
		return seleniumCommands.getTextAtLocator(NO_OF_ACCIDENT_LBL_CSS);
	}
	
	private String getNoOfViolation() {
		return seleniumCommands.getTextAtLocator(NO_OF_VIOLATION_LBL_CSS);
	}
	
	
	
	// Validation 
	public Validation isDriverPageLoaded() {
		logger.info( "Validating the driver page loading");
		seleniumCommands.waitForElementToBeVisible(NO_OF_ACCIDENT_INCREMENT_BTN_CSS);
		return new Validation(seleniumCommands.isElementPresent(NO_OF_ACCIDENT_INCREMENT_BTN_CSS));
	}
	
	public Validation arePrimaryDriverDetailsNonEditable() {
		logger.info( "Validating if primary driver's firstname, lastname & dob details are non editable");
		new Validation(seleniumCommands.isElementVisible(FIRST_NAME_VALUE_CSS)).shouldBeTrue("Primary driver's First Name is editable");
		new Validation(seleniumCommands.isElementVisible(LAST_NAME_VALUE_CSS)).shouldBeTrue("Primary driver's Last Name is editable");
		new Validation(seleniumCommands.isElementVisible(DOB_VALUE_CSS)).shouldBeTrue("Primary driver's DOB is editable");
		return new Validation(true);
	}

	public Validation areDriverPageFieldsMarkedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the fields the Quote");
		new Validation(isLicenseYearFieldMakedWithError()).shouldBeTrue("First year license year field is not marked with error");
		new Validation(isLicenseNumberFieldMakedWithError()).shouldBeTrue("License number field is not marked with error");
		return new Validation(true);
	}

	public Validation areAdditionalDriverPageFieldsMarkedWithMandatoryError() {
		logger.info( "Validating the Mandatory Error for the Additional Driver fields the Quote");
		new Validation(isLicenseYearFieldMakedWithError()).shouldBeTrue("First year license year field is not marked with mandatory error");
		new Validation(isLicenseNumberFieldMakedWithError()).shouldBeTrue("License number field is not marked with mandatory error");
		new Validation(isDayOfBirthFieldMarkedWithError()).shouldBeTrue("DOB field is not marked with mandatory error");
		new Validation(isLicenseStateFieldMakedWithError()).shouldBeTrue("License field is not marked with mandatory error");
		isFirstNameFieldMarkedWithError().shouldBeEqual("First Name field is not marked with mandatory error");
		isLastNameFieldMarkedWithError().shouldBeEqual("License field is not marked with mandatory error");
		return new Validation(true);
	}

	public Validation isDriverPageNextButtonDisabled() {
		return new Validation(seleniumCommands.isElementPresent(NEXT_BUTTON));
	}

	public Validation areDriverPageFieldsMarkedWithAsterisk() {
		logger.info( "Validating the Mandatory fields marked with asterisk");
		isDobFieldMakedWithAsterisk().shouldBeEqual("DOB field is not marked with asterisk");
		isLicenseNumberFieldMakedWithAsterisk().shouldBeEqual("License num field is not marked with asterisk");
		isLicenseStateFieldMakedWithAsterisk().shouldBeEqual("License state field is not marked with asterisk");
		isLicenseYearFieldMakedWithAsterisk().shouldBeEqual("License year field is not marked with asterisk");
		isNoOfAccidentsFieldMakedWithAsterisk().shouldBeEqual("No of Accident field is not marked with asterisk");
		isNoOfViolationsFieldMakedWithAsterisk().shouldBeEqual("No of violation field is not marked with asterisk");
		return new Validation(true);
	}

	public Validation areAdditionalDriverPageFieldsMarkedWithAsterisk() {
		logger.info( "Validating the Mandatory fields marked with asterisk");
		areDriverPageFieldsMarkedWithAsterisk();
		isFirstNameMarkedWithAsterisk().shouldBeEqual("First Name field is not marked with asterisk");
		isLastNameMarkedWithAsterisk().shouldBeEqual("Last Name field is not marked with asterisk");
		return new Validation(true);
	}

	public Validation isDobFieldMakedWithAsterisk() {
		logger.info( "Validating the Mandatory Error for Gender Field");
		return  new Validation(seleniumCommands.getTextAtLocator(DOB_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	
	public boolean isLicenseNumberFieldMakedWithError() {
		logger.info( "Validating the Mandatory Error LICENSE_NUM field");
		boolean value = seleniumCommands.getErrorMessageForDatePicker(LICENSE_NUM_TXT_CSS.get(LICENSE_NUM_TXT_CSS.size()-1)).equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("LICENSE_NUM is marked with Error " + value);
		return value;
    }

	public Validation isFirstNameFieldMarkedWithError() {
	seleniumCommands.logInfo( "Validating the Mandatory Error for First Name Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(FIRST_NAME_TXT_CSS.get(FIRST_NAME_TXT_CSS.size()-1)).equals(DataConstant.MANDATORY_ERROR_MSG) );
	}

	public Validation  isFirstNameMarkedWithAsterisk() {
		logger.info( "Validating the Asterisk for First Name field");
		return  new Validation(seleniumCommands.getTextAtLocator(FIRSTNAME_ASTERISK_CSS), DataConstant.ASTERISK);
	}

	public Validation isLastNameFieldMarkedWithError() {
		seleniumCommands.logInfo( "Validating the Mandatory Error for Last Name Field");
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(LAST_NAME_TXT_CSS.get(LAST_NAME_TXT_CSS.size()-1)),DataConstant.MANDATORY_ERROR_MSG );
	}

	public Validation  isLastNameMarkedWithAsterisk() {
		logger.info( "Validating the Asterisk for Last Name field");
		return  new Validation(seleniumCommands.getTextAtLocator(LASTNAME_ASTERISK_CSS), DataConstant.ASTERISK);
	}

	public boolean isDayOfBirthFieldMarkedWithError() {
		logger.info( "Validating the Mandatory Error for Day Of Birth field");
		boolean value = seleniumCommands.getErrorMessageForDatePicker(DOB_TXT_CSS).equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("Day Of Birth is marked with Error " + value);
		return value;
	}
	
	public Validation  isLicenseNumberFieldMakedWithAsterisk() {
		logger.info( "Validating the Asteriks for LICENSE_NUM field");
		return  new Validation(seleniumCommands.getTextAtLocator(LICENSE_NUM_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	
	public boolean isLicenseYearFieldMakedWithError() {
		logger.info( "Validating the Mandatory Error LICENSE_Year field");
		boolean value = seleniumCommands.getErrorMessageForDatePicker(LICENSE_FIRST_YEAR_DROP_CSS.get(LICENSE_FIRST_YEAR_DROP_CSS.size()-1)).equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("LICENSE_Year is marked with Error " + value);
		return value;
	}
	
	public Validation  isLicenseYearFieldMakedWithAsterisk() {
		logger.info( "Validating the Asterick for LICENSE_Year field");
		return  new Validation(seleniumCommands.getTextAtLocator(LICENSE_YEAR_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	
	public boolean isLicenseStateFieldMakedWithError() {
		logger.info( "Validating the Mandatory Error LICENSE_State field");
		boolean value = seleniumCommands.getErrorMessageForDatePicker(LICENSE_STATE_DROP_CSS.get(LICENSE_STATE_DROP_CSS.size()-1)).equals(DataConstant.MANDATORY_ERROR_MSG);
		logger.info("LICENSE_ State is marked with Error " + value);
		return value;
	}
	
	public Validation  isLicenseStateFieldMakedWithAsterisk() {
		logger.info( "Validating the Asterick for LICENSE State field");
		return  new Validation(seleniumCommands.getTextAtLocator(LICENSE_STATE_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	
	public Validation  isNoOfAccidentsFieldMakedWithAsterisk() {
		logger.info( "Validating the Asterick for no of accidents field");
		return  new Validation(seleniumCommands.getTextAtLocator(NO_OF_ACCIDENT_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	
	public Validation  isNoOfViolationsFieldMakedWithAsterisk() {
		logger.info( "Validating the Asterick for no of violation field");
		return  new Validation(seleniumCommands.getTextAtLocator(NO_OF_VIOLATION_ASTERISK_CSS), DataConstant.ASTERISK);
	}
	

	public Validation isGenderEqualsTo() {
		return new Validation(getGender(), data.get("DriverGendor"));
	}
	
	public Validation isGenderEqualsTo(String gendor) {
		return new Validation(getGender(), gendor);
	}
	
	public Validation isDriverLicenseNumEqualsTo() {
		return new Validation(getDriverLicenseNumber(), data.get("DriverLicenseNum"));
	}
	
	public Validation isDriverLicenseNumEqualsTo(String num) {
		return new Validation(getDriverLicenseNumber(), num);
	}
	
	public Validation isDriverLicenseStateEqualsTo(String State) {
		return new Validation(getDriverLicenseState(), State);
	}
	
	public Validation isDriverLicenseStateEqualsTo() {
		return new Validation(getDriverLicenseState(), data.get("DriverLicenseState"));
	}
	
	public Validation isDriverLicenseFirstYearEqualsTo() {
		return new Validation(getDriverLicenseFirstYear(), data.get("FirstYearLicensed"));
	}

	public Validation isDriverLicenseFirstYearEqualsTo(String yearFirstLicenced) {
		return new Validation(getDriverLicenseFirstYear(), yearFirstLicenced);
	}
	
	public Validation isNoOfViolationsEqualsTo(String violation) {
		return new Validation(getNoOfViolation(), violation);
	}
	
	public Validation isNoOfViolationsEqualsTo() {
		return new Validation(getNoOfViolation(), data.get("ViolationNum"));
	}
	
	public Validation isNoOfAccidentEqualsTo(String accident) {
		return new Validation(getNoOfAccident(), accident);
	}
	
	public Validation isNoOfAccidentEqualsTo() {
		return new Validation(getNoOfAccident(), data.get("AccidentNum"));
	}
	
	
	public Validation areDriverDetailsSaved()
	{
		this.isGenderEqualsTo().shouldBeEqual("Gender is not correct");
		this.isDriverLicenseNumEqualsTo().shouldBeEqual("License Number is not correct");
		this.isDriverLicenseStateEqualsTo().shouldBeEqual("License state is not correct");
		this.isDriverLicenseFirstYearEqualsTo().shouldBeEqual("Driver First License year is not correct");
		this.isNoOfAccidentEqualsTo().shouldBeEqual("No of Accident is not correct");
		this.isNoOfViolationsEqualsTo().shouldBeEqual("No of Violation i snot correct");
		return new Validation(true);
	}

	public Validation areGPADriverDetailsNotSaved()
	{
		this.isGenderEqualsTo("-- Choose Driver Gender --");
		this.isDriverLicenseNumEqualsTo("");
		this.isDriverLicenseStateEqualsTo("-- Choose License State --");
		this.isDriverLicenseFirstYearEqualsTo("-- Choose License Year --");
		this.isNoOfAccidentEqualsTo("0");
		this.isNoOfViolationsEqualsTo("0");
		return new Validation(true);
	}

	public static Validation areDriverDetailsMatchingBackEnd() throws Exception{
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getDriverDetailsFromBackEnd(DataFetch.getQuoteData(
						ThreadLocalObject.getData().get("ZipCode"), new QuoteInfoBar().getSubmissionNumber())));
	}
	
	public static Validation areNewDriverDetailsMatchingBackEnd(String jsondata) throws Exception{
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getNewAdditionalDriverDetailsFromBackEnd(jsondata));
	}
	
	public static Validation areDriverDetailsMatchingBackEnd(String jsonData) throws Exception{
		return MapCompare.compareMap(ThreadLocalObject.getData(),
				ParseQuoteData.getDriverDetailsFromBackEnd(jsonData));
	}
}
