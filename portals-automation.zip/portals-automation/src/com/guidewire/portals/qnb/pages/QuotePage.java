package com.guidewire.portals.qnb.pages;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import org.openqa.selenium.By;

import java.util.HashMap;

public class QuotePage {

    By HOME_MENU_BUTTON	= By.cssSelector("a[href='#/home']");

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();



    public void clickMenuButton() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS( seleniumCommands.findElement(HOME_MENU_BUTTON));
        new AlertHandler().closeAlert();
    }
}
