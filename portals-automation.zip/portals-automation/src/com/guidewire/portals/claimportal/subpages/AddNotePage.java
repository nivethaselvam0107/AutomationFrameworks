package com.guidewire.portals.claimportal.subpages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;

public class AddNotePage 
{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(id = "note-body")
	WebElement NOTE_BODY_TXT_ID;
	
	@FindBy(xpath = "//*[@id='note-body']/../following-sibling::div[@class='gw-inline-messages']")
	WebElement NOTE_BODY_ERROR_MSG_XPATH;
	
	@FindBy(css = "[ng-model='model.value']")
	WebElement NOTE_SUBJECT_TXT_CSS;
	
	@FindBy(css = "[ng-click='createNote(claimNoteForm)'], [ng-click='sendNote(newNoteForm)'")
	WebElement SAVE_NOTE_BTN_CSS;
	
	@FindBy(css = "[ng-click='cancel()']")
	WebElement CANCEL_NOTE_BTN_CSS;

	@FindBy(css = "[class*='gw-nav']  li:nth-of-type(1), [id='notesTable']")
	WebElement NOTE_TABLE_CSS;
	
	public AddNotePage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	public ClaimSummaryPage addNoteDetails() {
		seleniumCommands.waitForElementToBeVisible(NOTE_SUBJECT_TXT_CSS);
		seleniumCommands.type(NOTE_SUBJECT_TXT_CSS, data.get("NoteSubject"));
		seleniumCommands.type(NOTE_BODY_TXT_ID, data.get("NoteBody"));
		saveNotes();
		seleniumCommands.waitForElementToBeVisible(NOTE_TABLE_CSS);
		return new ClaimSummaryPage();
	}
	
	public AddNotePage cancelNote() {
		seleniumCommands.clickbyJS(CANCEL_NOTE_BTN_CSS);
		return this;
	}
	
	public AddNotePage saveNotes() {
		seleniumCommands.clickbyJS(SAVE_NOTE_BTN_CSS);
		return this;
	}

	//Validation
	public Validation validateMandatoryFieldsErrorOnNotePage() {
		new Validation(seleniumCommands.getErrorMessageForTxtBox(NOTE_SUBJECT_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Notes Subject Error field is not marked with Mandatory error");
		new Validation(seleniumCommands.getTextAtLocator(NOTE_BODY_ERROR_MSG_XPATH), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Notes Subject Error field is not marked with Mandatory error");
		return new Validation(true);
	}
		
}
