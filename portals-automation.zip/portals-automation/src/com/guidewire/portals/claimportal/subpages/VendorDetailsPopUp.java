package com.guidewire.portals.claimportal.subpages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class VendorDetailsPopUp 
{
	
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[class*='gw-fade']")
	WebElement VENDOR_DETAIL_POP_UP_CSS;
	
	@FindBy(css = "[class*='gw-fade'] [class='gw-control-group']:nth-of-type(1) div:nth-of-type(2)")
	WebElement VENDOR_ADDRESS_VALUE_CSS;
	
	@FindBy(css = "[class*='gw-fade'] [class='gw-control-group']:nth-of-type(2) div:nth-of-type(2)")
	WebElement VENDOR_PHONE_NUM_VALUE_CSS;
	
	@FindBy(css = "[class*='gw-fade'] [class='gw-control-group']:nth-of-type(3) div:nth-of-type(2)")
	WebElement VENDOR_FAX_NUM_VALUE_CSS;
	
	@FindBy(xpath = "//div[@class='gw-read-only gw-contacts-form']/div[3]/div[2]")
	WebElement VENDOR_EMAIL_VALUE_CSS;
	
	@FindBy(css = "[class='gw-modal-footer ng-scope'] button")
	WebElement VENDOR_POPUP_CLOSE_BTN_CSS;
	
	public VendorDetailsPopUp() {
		PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	private VendorDetailsPopUp openVendor()
	{
		seleniumCommands.click(By.linkText(ThreadLocalObject.getData().get("VendorName")));
		seleniumCommands.waitForElementToBeVisible(VENDOR_DETAIL_POP_UP_CSS);
		return this;
	}
	
	private Validation validateVendorPopUpDetails()
	{
		new Validation(VENDOR_ADDRESS_VALUE_CSS.getText().replace("\n", " "), data.get("Vendor1Address")).shouldBeEqual("Vendor Address details are not correct");
		new Validation(VENDOR_EMAIL_VALUE_CSS.getText(), data.get("Vendor1Email")).shouldBeEqual("Vendor Email is not correct");
		if(System.getProperty("platform").equals("Emerald"))
		{
			new Validation(VENDOR_PHONE_NUM_VALUE_CSS.getText().replaceAll("-", ""), data.get("Vendor1PhoneNum").replaceAll("-", "")).shouldBeEqual("Vendor Phone Number is not correct");
			new Validation(VENDOR_FAX_NUM_VALUE_CSS.getText().replaceAll("-", ""), data.get("Vendor1FaxNumber").replaceAll("-", "")).shouldBeEqual("Vendor Fax Number is not correct");
		}
		else
		{
			new Validation(VENDOR_PHONE_NUM_VALUE_CSS.getText().replaceAll("-", ""), data.get("Vendor1PhoneNum").replaceAll("-", "")).shouldBeEqual("Vendor Phone Number is not correct");
			new Validation(VENDOR_FAX_NUM_VALUE_CSS.getText().replaceAll("-", ""), data.get("Vendor1FaxNumber").replaceAll("-", "")).shouldBeEqual("Vendor Fax Number is not correct");
		}
		closeVendor();
		return new Validation(true);
	}
	
	private VendorDetailsPopUp closeVendor()
	{
		seleniumCommands.click(VENDOR_POPUP_CLOSE_BTN_CSS);
		return this;
	}
	
	//Validation Methods
	
	public Validation openAndValidateVendorPopDetails()
	{
		this.openVendor();
		return validateVendorPopUpDetails();
	}

}
