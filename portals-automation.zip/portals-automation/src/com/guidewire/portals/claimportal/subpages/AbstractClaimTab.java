package com.guidewire.portals.claimportal.subpages;

import com.guidewire.capabilities.common.interfaces.IClaimTab;
import com.guidewire.capabilities.common.scenarios.CommonScenario;

public abstract class AbstractClaimTab extends CommonScenario implements IClaimTab {

    public AbstractClaimTab() {
        super();
    }

    @Override
    public IClaimTab openTab() {
        if (!isTabActive()) {
            seleniumCommands.clickbyJS(this.getTabButton());
            return this.waitTabContent();
        }
        return this;
    }

    @Override
    public IClaimTab waitTabContent() {
        seleniumCommands.waitForElementToBeVisible(this.getTabContent());
        return this;
    }

    @Override
    public boolean isTabActive() {
        return seleniumCommands.findElement(this.getTab()).getAttribute("class").contains("gw-active");
    }

    @Override
    public boolean isTabAvailable() {
        return seleniumCommands.isElementPresent(this.getTab());
    }
}
