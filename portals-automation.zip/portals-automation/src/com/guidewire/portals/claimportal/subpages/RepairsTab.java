package com.guidewire.portals.claimportal.subpages;

import com.guidewire.capabilities.common.dto.ServiceRequestDto;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ServiceRequestStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;
import java.util.stream.Collectors;

public class RepairsTab extends AbstractClaimTab {

    private static final By TAB = By.cssSelector("li[gw-test-claim-details-repairs]");
    private static final By TAB_BUTTON = By.cssSelector("li[gw-test-claim-details-repairs] a");
    private static final By TAB_CONTENT = By.cssSelector("[class*='gw-active'] [service-requests='details.claim.serviceRequests']");

    private static final By SERVICE_REQUEST = By.cssSelector("[class*='ClaimServiceRequests-hashed__serviceRequest']");
    private static final By NO_REQUEST = By.cssSelector("[ng-if='!$ctrl.hasServiceRequests()']");
    private static final By STATUS =  By.xpath("//div[@class='gw-one-quarter-size'][1]//p");
    private static final By NUMBER =  By.xpath("//div[@class='gw-one-quarter-size'][2]/div[1]//p[@class='ng-binding']");
    private static final By ACTION =  By.xpath("//div[@class='gw-one-quarter-size'][2]/div[2]//p[@class='ng-binding']");
    private static final By TYPE =    By.xpath("//div[@class='gw-one-quarter-size'][3]/div[1]//p[@class='ng-binding']");
    private static final By DATE =    By.xpath("//div[@class='gw-one-quarter-size'][3]/div[2]//p[@class='ng-binding']");
    private static final By VENDOR =  By.xpath("//div[@class='gw-one-quarter-size'][4]/div[1]/a");
    private static final By CONTACT = By.xpath("//div[@class='gw-one-quarter-size'][4]/div[2]/p/a");

    public RepairsTab() {
        super();
    }

    @Override
    public By getTab() {
        return TAB;
    }

    @Override
    public By getTabButton() {
        return TAB_BUTTON;
    }

    @Override
    public By getTabContent() {
        return TAB_CONTENT;
    }

    public RepairsTab validateServiceRequest() {
        ServiceRequestDto request = this.getServiceRequestList().get(0);

        new Validation(
                request.Status.equals(
                        ServiceRequestStatus.IN_PROGRESS.toString()
                )).shouldBeTrue("Request status wrong");
        new Validation(
                request.Vendor.equals(
                        data.get("VendorName")
                )).shouldBeTrue("Vendor Name wrong");

        if (suiteName == SuiteName.GPA || suiteName == SuiteName.CPAGENT ) {
            new Validation(
                    request.PrimaryContact.equals(
                            data.get("MAIN_CONTACT_DISPLAY_NAME")
                    )).shouldBeTrue("Primary Contact wrong");
        }

        this.validateDynamicProperties(request);


        return this;
    }

    public RepairsTab validateNoRequest() {
        new Validation(seleniumCommands.findElement(NO_REQUEST).isDisplayed())
                .shouldBeTrue("No message that are no service requests associated with this claim");

        return this;
    }

    private void validateDynamicProperties(ServiceRequestDto request) {
        switch (data.get("ClaimSubType")) {
            case "Collision" :
                new Validation(
                        request.ServiceType.equals(
                                ServiceRequestStatus.Service.BODY.toString()
                        )).shouldBeTrue("Service type wrong");

                new Validation(
                        request.NextAction.equals(
                                ServiceRequestStatus.Action.AGREE_QUOTE.toString()
                        )).shouldBeTrue("Next Action wrong");

                break;
            case "Glass":
                new Validation(
                        request.ServiceType.equals(
                                ServiceRequestStatus.Service.GLASS.toString()
                        )).shouldBeTrue("Service type wrong");

                new Validation(
                        request.NextAction.equals(
                                ServiceRequestStatus.Action.AGREE_SERVICE.toString()
                        )).shouldBeTrue("Next Action wrong");

                break;
            case "Theft":
                new Validation(
                        request.ServiceType.equals(
                                ServiceRequestStatus.Service.AUDIO.toString()
                        )).shouldBeTrue("Service type wrong");

                new Validation(
                        request.NextAction.equals(
                                ServiceRequestStatus.Action.AGREE_QUOTE.toString()
                        )).shouldBeTrue("Next Action wrong");
                break;
            default:
                new Validation(false).shouldBeTrue("Data does not match");
        }
    }

    private List<ServiceRequestDto> getServiceRequestList() {
        seleniumCommands.waitForElement(SERVICE_REQUEST, 5);
        return seleniumCommands.findElements(SERVICE_REQUEST).stream().map(e -> toDto(e)).collect(Collectors.toList());
    }

    private ServiceRequestDto toDto(WebElement element) {
        ServiceRequestDto dto = new ServiceRequestDto();

        WebElement property = element.findElement(STATUS);
        dto.Status = property.getText();
        property = element.findElement(NUMBER);
        dto.ServiceNumber = property.getText();
        property = element.findElement(ACTION);
        dto.NextAction = property.getText();
        property = element.findElement(TYPE);
        dto.ServiceType = property.getText();
        property = element.findElement(VENDOR);
        dto.Vendor = property.getText();
        //only for Glass service there is a service completion date, otherwise it is waiting for quote(therefore date not present)
        if (dto.ServiceType.equals("Glass")) {
            property = element.findElement(DATE);
            dto.CompletionDate = property.getText();
        }
        if (suiteName == SuiteName.GPA || suiteName == SuiteName.CPAGENT ) {
            property = element.findElement(CONTACT);
            dto.PrimaryContact = property.getText();
        }

        return dto;
    }

}
