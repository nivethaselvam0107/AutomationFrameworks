package com.guidewire.portals.claimportal.subpages;

import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.guidewire.common.testNG.Validation;

public class NotesTab extends AbstractClaimTab {

	private static final By TAB = By.cssSelector("li[gw-test-claim-details-notes]");
	private static final By TAB_BUTTON = By.cssSelector("li[gw-test-claim-details-notes] a");
	private static final By TAB_CONTENT = By.cssSelector("[class*='gw-active'] [notes='details.notes']");
	
	@FindBy(css = "[ng-model='notesQuery']")
	WebElement NOTE_SEARCH_TXT_CSS;

	@FindBy(css = "[data-ng-click='onNewNote()']")
	WebElement ADD_NOTE_BTN_CSS;
	
	@FindBy(id = "notesTable")
	WebElement NOTE_TABLE_ID;

	private static final By NOTE_SUBJECT_XPATH = By.xpath("./tbody/tr[1]/td[3]");
	private static final By NOTE_BODY_XPATH = By.xpath("./tbody/tr[1]/td[4]");
	private static final By NOTE_USER_XPATH = By.xpath("./tbody/tr[1]/td[1]");

	public NotesTab() {
		super();
	}
	
	public NotesTab searchNote() {
		seleniumCommands.type(NOTE_SEARCH_TXT_CSS, data.get("NoteSubject"));
		return this;
	}
	
	public AddNotePage addNote() {
		seleniumCommands.clickbyJS(ADD_NOTE_BTN_CSS);
		return new AddNotePage();
	}

	public NotesTab addANewNote() {
		this.addNote().addNoteDetails();
		new ClaimSummaryPage().openNoteTab();
		return this;
	}
	
	//Validation
	public Validation isNotesAdded() {
		searchNote();
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_SUBJECT_XPATH)), data.get("NoteSubject")).shouldBeEqual("Notes Subject is not correct");
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_BODY_XPATH)), data.get("NoteBody")).shouldBeEqual("Notes Body is not correct");
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_USER_XPATH)), data.get("USER")).shouldBeEqual("Notes added by is not correct");
		return new Validation(true);
	}

	public Validation validateNotePageElements() {
		new Validation(seleniumCommands.isElementPresent(ADD_NOTE_BTN_CSS)).shouldBeTrue("Add Note button is not presented");
		new Validation(seleniumCommands.isElementPresent(NOTE_SEARCH_TXT_CSS)).shouldBeTrue("Search Note field is not presented");
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_SUBJECT_XPATH)), data.get("NoteSubject")).shouldBeEqual("Notes Subject is not correct");
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_BODY_XPATH)), data.get("NoteBody")).shouldBeEqual("Notes Body is not correct");
		new Validation(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(NOTE_TABLE_ID, NOTE_USER_XPATH)), data.get("USER")).shouldBeEqual("Notes added by is not correct");
		return new Validation(true);
	}

	@Override
	public By getTab() {
		return TAB;
	}

	@Override
	public By getTabButton() {
		return TAB_BUTTON;
	}

	@Override
	public By getTabContent() {
		return TAB_CONTENT;
	}
}
