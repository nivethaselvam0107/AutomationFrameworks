package com.guidewire.portals.claimportal.subpages;

import org.openqa.selenium.By;

public class SummaryTab extends AbstractClaimTab {

    private static final By TAB = By.cssSelector("li[gw-test-claim-details-summary]");
    private static final By TAB_BUTTON = By.cssSelector("li[gw-test-claim-details-summary] a");
    private static final By TAB_CONTENT = By.cssSelector("[class*='gw-active'] div[class*='ng-scope'] section[class*='gw-clearfix']");

    public SummaryTab() {
        super();
    }

    @Override
    public By getTab() {
        return TAB;
    }

    @Override
    public By getTabButton() {
        return TAB_BUTTON;
    }

    @Override
    public By getTabContent() {
        return TAB_CONTENT;
    }
}
