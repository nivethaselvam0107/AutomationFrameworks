package com.guidewire.portals.claimportal.subpages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimListPage;

public class ContactUSPage 
{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[class*='ContactAgent']")
	WebElement CONTACT_US_PAGE_TITLE_CLASS;
	
	@FindBy(xpath = "//*[contains(@class,'ContactAgent')]/following-sibling::p[1]")
	WebElement ERROR_MESSAGE1_CSS;
	
	@FindBy(xpath = "//*[contains(@class,'ContactAgent')]/following-sibling::p[2]")
	WebElement ERROR_MESSAGE2_CSS;
	
	@FindBy(css = "[ng-click*='goBackToHomeState()']")
	WebElement BACK_TO_CLAIM_BTN_CSS;
	
	public ContactUSPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}
	
	@Deprecated
	public ClaimListPage goToClaimPage() {
		seleniumCommands.clickbyJS(BACK_TO_CLAIM_BTN_CSS);
		return new ClaimListPage();
	}

	private void clickBackToClaim() {
		seleniumCommands.clickbyJS(BACK_TO_CLAIM_BTN_CSS);
	}
	public CP_ClaimListPage goToClaimPageCP() {
		this.clickBackToClaim();
		return new CP_ClaimListPage();
	}

	public GPA_ClaimListPage goToClaimPageGPA() {
		this.clickBackToClaim();
		return new GPA_ClaimListPage();
	}

	public AMP_ClaimListPage goToClaimPageAMP() {
		this.clickBackToClaim();
		return new AMP_ClaimListPage();
	}

	public AccountSummaryPage goToHomePage() {
		seleniumCommands.clickbyJS(BACK_TO_CLAIM_BTN_CSS);
		return new AccountSummaryPage();
	}

	public AccountSummary backToClaims() {
		seleniumCommands.clickbyJS(BACK_TO_CLAIM_BTN_CSS);
		return new AccountSummary();
	}

	public Validation isContactUsPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(ERROR_MESSAGE1_CSS);
		new Validation(seleniumCommands.isElementPresent(BACK_TO_CLAIM_BTN_CSS)).shouldBeTrue("Back to Claim button not visible");
		new Validation(seleniumCommands.getTextAtLocator(ERROR_MESSAGE1_CSS), DataConstant.CAN_NOT_PROCESS_CLAIM_ERROR).shouldBeEqual("Can Not proceed error message is not correct");
		new Validation(seleniumCommands.getTextAtLocator(ERROR_MESSAGE2_CSS), DataConstant.CALL_AGENT_FOR_CLAIM_ASSISTANCE_ERROR).shouldBeEqual("Call agent error message is not correct");
		return new Validation(true);
	}

}
