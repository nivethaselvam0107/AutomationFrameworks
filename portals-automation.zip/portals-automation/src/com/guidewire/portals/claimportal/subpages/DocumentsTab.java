package com.guidewire.portals.claimportal.subpages;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import com.guidewire.capabilities.agent.data.DocumentData;
import com.guidewire.capabilities.agent.data.ParseDocumentData;
import com.guidewire.data.DataFetch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Modal;

public class DocumentsTab extends AbstractClaimTab {

    private static final By TAB = By.cssSelector("li[gw-test-claim-details-documents]");
    private static final By TAB_BUTTON = By.cssSelector("li[gw-test-claim-details-documents] a");
    private static final By TAB_CONTENT = By.cssSelector("[class*='gw-active'] [documents='details.claim.documents']");

    @FindBy(css = "[list='filteredDocuments'] [title='Name']")
    WebElement FIRST_DOC_NAME_CSS;

    @FindBy(css = "input[ng-model='documentQuery']")
    WebElement DOC_SEARCH_FIELD_CSS;

    @FindBy(css = "[id='uploadButton']")
    WebElement UPLOAD_DOC_BTN_CSS;

    @FindBy(css = "[ng-click='removeDocument(item)']")
    WebElement DELETE_DOC_BTN_CSS;

    @FindBy(css = "th[ng-click*='name'], [list='filteredDocuments'] th:nth-of-type(1)")
    WebElement DOC_NAME_HEADER_CSS;

    @FindBy(css = "th[ng-click*='dateModified']")
    WebElement DOC_DATA_MODIFIED_HEADER_CSS;
    
    @FindBy(css = "[list='filteredDocuments'] th:nth-of-type(2)")
    WebElement DOC_DATA_UPLOADED_HEADER;

    @FindBy(css = "[list='filteredDocuments'] [class='fa fa-file']")
    WebElement DOC_VIEW_ICON;

    @FindBy(css = "[list='filteredDocuments'] th:nth-of-type(3)")
    WebElement DOC_REMOVE_HEADER_CSS;
    
    @FindBy(css = "[list='filteredDocuments'] [class='fa fa-trash']")
    WebElement DOC_REMOVE_ICON;

    final String DOC_TABLE_CSS = "table[list='filteredDocuments'] tbody tr";

    final String UPLOAD_DOC_INPUT_CSS = "[id='uploadButton'][aria-disabled='false'] input";
    
    private static int value = 0;
    
    private final String DOC_NAME_HEADER = "NAME";
    
    private final String DOC_UPLOADED_HEADER = "DATE UPLOADED";
    
    private final String DOC_REMOVE_HEADER = "REMOVE";

    public DocumentsTab() {
        super();
    }

    public DocumentsTab searchDoc() {
        seleniumCommands.waitForElementToBeVisible(DOC_SEARCH_FIELD_CSS);
        if (data.get("DocType") != null) {
            seleniumCommands.type(DOC_SEARCH_FIELD_CSS, data.get("DocType") + "File");
        } else {
            seleniumCommands.type(DOC_SEARCH_FIELD_CSS, "SAMPLEFile.docx");
        }
        return this;
    }

    public DocumentsTab uploadDocFromSummary() {
        seleniumCommands.waitForElementToBeVisible(UPLOAD_DOC_BTN_CSS);
        value = seleniumCommands.findElements(By.cssSelector(DOC_TABLE_CSS)).size();
        String docType;
        if (data.containsKey("DocType")) {
            docType = data.get("DocType");
        } else {
            docType = "SAMPLE";
        }
        seleniumCommands.uploadClaimDoc(UPLOAD_DOC_INPUT_CSS, docType);
        return this;
    }

    public DocumentsTab deleteDoc(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(DELETE_DOC_BTN_CSS);
        new Modal().confirm();
        seleniumCommands.waitForElementListHaveLessValuesThan(By.cssSelector(DOC_TABLE_CSS), 1);
        return this;
    }

    //Validation
    public Validation isDocAdded() {
        seleniumCommands.waitForElementListHaveMoreValuesThan(By.cssSelector(DOC_TABLE_CSS), value);
        if (data.get("DocType") != null) {
            String searchValue = (data.get("DocType") + "File." + data.get("DocType")).toLowerCase();
            seleniumCommands.type(DOC_SEARCH_FIELD_CSS, searchValue);
            return new Validation(FIRST_DOC_NAME_CSS.getText().toLowerCase(), searchValue);
        }

        return new Validation(FIRST_DOC_NAME_CSS.getText(), "SAMPLEFile.docx");
    }

    public Validation isDocTableEmpty() {
        return new Validation(!seleniumCommands.isElementPresent(DOC_SEARCH_FIELD_CSS));
    }

    public Validation validateClaimDocumentDataWithBackEnd(String claimNumber) throws ParseException {
        seleniumCommands.logInfo("Validating Claim Document data with backend");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<HashMap<String, String>> documentsDataList = ParseDocumentData.getClaimDocumentDataFromBackEnd(DataFetch.getAgentClaimData(claimNumber));
        if (documentsDataList.size() != 0) {
            HashMap<String, String> documentRow = documentsDataList.stream().filter(map -> map.get(DocumentData.DOC_NAME.toString()).equals(data.get(DocumentData.DOC_NAME.toString()))).findFirst().get();
            return new Validation(documentRow.size() > 0);
        }

        return new Validation(false);
    }

    public Validation validateDocPageElementsOnClaimSummary() {
        seleniumCommands.logInfo("Validating Doc tab UI elements on claim summary");
        new Validation(seleniumCommands.isElementPresent(UPLOAD_DOC_BTN_CSS)).shouldBeTrue("Upload Document button is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_SEARCH_FIELD_CSS)).shouldBeTrue("Search Document field is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_NAME_HEADER_CSS)).shouldBeTrue("Document name header is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_DATA_MODIFIED_HEADER_CSS)).shouldBeTrue("Document data modified header is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_VIEW_ICON)).shouldBeTrue("Document view icon is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_REMOVE_ICON)).shouldBeTrue("Document remove icon is not presented");
        return new Validation(true);
    }
    
    public Validation validateDocTileElements() {
        seleniumCommands.logInfo("Validating doc tile UI elements");
        new Validation(seleniumCommands.isElementPresent(UPLOAD_DOC_BTN_CSS)).shouldBeTrue("Upload Document button is not presented");
        new Validation(seleniumCommands.isElementPresent(DOC_SEARCH_FIELD_CSS)).shouldBeTrue("Search Document field is not presented");
        new Validation(seleniumCommands.getTextAtLocator(DOC_NAME_HEADER_CSS), DOC_NAME_HEADER).shouldBeEqual("Search Document field is not presented");
        new Validation(seleniumCommands.getTextAtLocator(DOC_DATA_UPLOADED_HEADER), DOC_UPLOADED_HEADER).shouldBeEqual("Search Document field is not presented");
        new Validation(seleniumCommands.getTextAtLocator(DOC_REMOVE_HEADER_CSS), DOC_REMOVE_HEADER).shouldBeEqual("Search Document field is not presented");
        return new Validation(true);
    }

    public Validation validateErrorPopUpOnUploadingDoc(){
        AlertHandler errorAlert = new AlertHandler();
        new Validation(errorAlert.getAlertHeader().toString(),DataConstant.ERROR_TITLE).shouldBeEqual("Alert header is not Error");
        new Validation(errorAlert.getAlertText(),DataConstant.UPLOAD_FAILED_ERR_DESC).shouldBeEqual("Error message is not correct");
        return new Validation(true);
    }


    @Override
    public By getTab() {
        return TAB;
    }

    @Override
    public By getTabButton() {
        return TAB_BUTTON;
    }

    @Override
    public By getTabContent() {
        return TAB_CONTENT;
    }
}
