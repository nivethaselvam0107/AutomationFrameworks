package com.guidewire.portals.claimportal.uidataenum;

public class ClaimPortalUiDataEnum {


	public enum booleanData {
		YES("True"), NO("No");

		private String booleanValue;

		private booleanData(String bool) {
			this.booleanValue = bool;
		}

		public String getName() {
			return booleanValue;

		}
	}

		public enum policyType {
			HO("HO"), 
			PA("PA");
			private String policy;

			private policyType(String value) {
				this.policy = value;
			}

			public String getName() {
				return policy;

			}
		}
		
		public enum locationType {
			InCityLimits("In City Limits"), 
			InFireDistrict("In Fire District"),
			InProtectedSuburb("In protected suburb"),
			InUnprotectedArea("In unprotected area"),
			Other("Other");
			
			private String location;

			private locationType(String value) {
				this.location = value;
			}

			public String getName() {
				return location;

			}
		}
}
