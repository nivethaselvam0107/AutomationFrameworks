package com.guidewire.portals.claimportal.uidataenum;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URL;

import org.apache.commons.httpclient.util.HttpURLConnection;
public class CreateClaimOnPolicy {

	public static void main(String args[]) throws IOException {

		URL url = new URL("http://localhost:8080/cc/ws/gw/webservice/TestAPI?WSDL");
		HttpURLConnection rc = (HttpURLConnection) url.openConnection();

		rc.setRequestProperty("Content-Type", "application/soap+xml;charset=UTF-8");
		rc.setRequestProperty("Accept-Encoding", "gzip,deflate");
		rc.setRequestProperty("Content-Length", "648");
		rc.setRequestProperty("Connection:", "Keep-Alive");
		
		
		// and here comes some dummy SOAP message
		String reqStr = "<soapenv:Envelope xmlns:soapenv=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:soap1=\"http://guidewire.com/ws/soapheaders\" xmlns:pcc=\"http://guidewire.com/cc/ws/gw/webservice/cc/cc800/pcintegration/PCClaimSearchIntegrationAPI\">"
				 + "<soap:Header>" + "<soap1:locale>en_US</soap1:locale>" 
				+ "<soap1:authentication>" + "<soap1:username>su</soap1:username>" + "<soap1:password>gw</soap1:password>" + "</soap1:authentication>"
				 +" </soap:Header>"
				 	+ "<soap:Body>"
				 		+ "<tes:createAutoClaimOnPolicy>"
				 			+"<!--Optional:-->"
				 				+"<tes:policyNumber>54-253465</tes:policyNumber>"
				 			+"</tes:createAutoClaimOnPolicy>"
				 	+ "</soap:Body>"
				 + "</soap:Envelope>";
				 	
		// several more definitions to request
		int len = reqStr.length();
	
		rc.connect();
		// write XML to the server
		OutputStreamWriter outStr = new OutputStreamWriter(rc.getOutputStream());
		outStr.write(reqStr, 0, len);
		outStr.flush();
	}

}