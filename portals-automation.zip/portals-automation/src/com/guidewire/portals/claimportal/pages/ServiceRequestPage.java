package com.guidewire.portals.claimportal.pages;

public class ServiceRequestPage {

}
