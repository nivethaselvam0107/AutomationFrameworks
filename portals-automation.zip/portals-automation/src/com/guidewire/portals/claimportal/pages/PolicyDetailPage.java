package com.guidewire.portals.claimportal.pages;

import java.text.ParseException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;

public class PolicyDetailPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	By POLICY_PAGE = By.cssSelector("[class*='gw-table']");

	// Vehicle Coverage
	@FindBy(css = "[class*='vehicle'] tbody tr:nth-of-type(1)")
	WebElement VEHICLE1_ROW_CSS;

	@FindBy(css = "[class='gw-table gw-vehicle-table ng-scope'] tbody tr:nth-of-type(2)")
	WebElement VEHICLE2_ROW_CSS;

	@FindBy(css = "[class='gw-coverage-table gw-table'] tbody tr")
	WebElement COVERAGE_ROW_CSS;
	
	By CHANGE_POLICY_BUTTON = By.cssSelector("[on-click='showChangeForm()']");

	String COV_HEADER_XPATH = "//table[@class='gw-coverage-table gw-table']/tbody/tr";
	
	String LOCATION_HEADER_XPATH = "//table[@class='gw-location-table gw-table']/tbody/tr";
	
	String VECHICLE_LIST_HEADER_XPATH = "//table[@class='gw-table gw-vehicle-table ng-scope']/tbody/tr";

	String POLICY_LEVEL_COV_HEADER_XPATH = "//table[@class='gw-policy-table gw-table']/tbody/tr";
	
	By COV_CURRENCY_XPATH = By.xpath("//*[contains(text(),'$')]");

	public PolicyDetailPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		seleniumCommands.waitForElementToBeVisible(POLICY_PAGE);
	}
	
	public HashMap<String, String> getPAPolicyLevelCoverageDataFromUI() {
		HashMap<String, String> coverage = new HashMap<>();
		seleniumCommands.waitForElementToBeVisible(VEHICLE1_ROW_CSS);
		int rowCount = seleniumCommands.getElements(By.xpath(POLICY_LEVEL_COV_HEADER_XPATH)).size();
		System.out.println(rowCount + "Row") ;
		for (int i = 2; i <= rowCount; i++) {
			String rowPath = POLICY_LEVEL_COV_HEADER_XPATH + "[" + i +"]";
			System.out.println(seleniumCommands.getElement(By.xpath(rowPath)).getText());
			if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Medical Payments"))
			{
				coverage.put("MED_PAY_TYPE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
				coverage.put("MED_PAY_LIMIT_TYPE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
				coverage.put("MED_PAY_LIMIT_VALUE_PER_PERSON",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]")));
			}

			else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Liability - Bodily Injury and Property Damage"))
			{
				coverage.put("LIB_BI_PROP_DAMAGE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
				coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]/*[@ng-show='coverage.incidentLimit']")));
				coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_PERSON",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]/*[@ng-show='coverage.exposureLimit']")));

				coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='coverage.exposureLimit']")));
				coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='coverage.incidentLimit']")));
			}

			else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Uninsured Motorist - Bodily Injury"))
			{
				coverage.put("UI_MOTO_BI_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
				coverage.put("UI_MOTO_BI_LIMIT_TYPE_PER_ACCIDENT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]/*[@ng-show='coverage.incidentLimit']")));
				coverage.put("UI_MOTO_BI_LIMIT_TYPE_PER_PERSON",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]/*[@ng-show='coverage.exposureLimit']")));

				coverage.put("UI_MOTO_BI_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='coverage.exposureLimit']")));
				coverage.put("UI_MOTO_BI_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='coverage.incidentLimit']")));

			}
			else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Uninsured Motorist - Property Damage"))
			{
				coverage.put("UI_MOTO_PROP_DAMAGE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
				coverage.put("UI_MOTO_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]/*[@ng-show='coverage.incidentLimit']")));
				coverage.put("UI_MOTO_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='coverage.incidentLimit']")));

			}
			else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Mexico Coverage - Limited"))
			{
				coverage.put("MEXICO_COV_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
			}

		}

		return coverage;
	}

	public HashMap<String, String> 	getVehicleCoverageDataFromUI() {
		HashMap<String, String> coverage = new HashMap<>();

		int vehCount = seleniumCommands.getElements(By.xpath(VECHICLE_LIST_HEADER_XPATH)).size();
		System.out.println(vehCount + "vehCount") ;
		for (int j = 1; j <= vehCount; j++)
		{
			seleniumCommands.click(By.xpath(VECHICLE_LIST_HEADER_XPATH + "[" + j +"]"));
			String LICENSE = seleniumCommands.getTextAtLocator(By.xpath(VECHICLE_LIST_HEADER_XPATH+"[" + j + "]/td[4]"));
			coverage.put("VEHICLE_MAKE_"+ LICENSE,
					seleniumCommands.getTextAtLocator(By.xpath(VECHICLE_LIST_HEADER_XPATH+"[" + j + "]/td[1]")));
			coverage.put("VEHICLE_YEAR_"+ LICENSE,
					seleniumCommands.getTextAtLocator(By.xpath(VECHICLE_LIST_HEADER_XPATH+"[" + j + "]/td[3]")));
			coverage.put("VEHICLE_LICENSE_PLATE_"+ LICENSE,
					seleniumCommands.getTextAtLocator(By.xpath(VECHICLE_LIST_HEADER_XPATH+"[" + j + "]/td[4]")));
			coverage.put("VEHICLE_MODEL_"+ LICENSE,
					seleniumCommands.getTextAtLocator(By.xpath(VECHICLE_LIST_HEADER_XPATH+"[" + j + "]/td[2]")));

			int rowCount = seleniumCommands.getElements(By.xpath(COV_HEADER_XPATH)).size();
			System.out.println(rowCount + "Row") ;
			for (int i = 1; i <= rowCount; i++) {
				String rowPath = COV_HEADER_XPATH + "[" + i +"]";
				System.out.println(seleniumCommands.getElement(By.xpath(rowPath)).getText());
				if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Medical Payments"))
				{
					coverage.put("MED_PAY_TYPE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("MED_PAY_DEDUCTIBLE_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("MED_PAY_LIMIT_VALUE_PER_PERSON_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]")));
					coverage.put("MED_PAY_LIMIT_VALUE_PER_ACCIDENT_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Liability - Bodily Injury and Property Damage"))
				{
					coverage.put("LIB_BI_PROP_DAMAGE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("LIB_BI_PROP_DAMAGE_DEDUCTIBLE_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.incidentLimit']")));
					coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_PERSON_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.exposureLimit']")));

					coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_PERSON_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Collision"))
				{
					coverage.put("COLLISION_TYPE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("COLLISION_DEDUCTIBLE_LIMIT_VALUE_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("COLLISION_LIMIT_TYPE_PER_ACCIDENT_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.incidentLimit']")));
					coverage.put("COLLISION_LIMIT_TYPE_PER_PERSON",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.exposureLimit']")));

					coverage.put("COLLISION_LIMIT_VALUE_PER_PERSON_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("COLLISION_LIMIT_VALUE_PER_ACCIDENT_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Comprehensive"))
				{
					coverage.put("COMPREHENSIVE_TYPE_TEXT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("COMPREHENSIVE_DEDUCTIBLE_LIMIT_VALUE_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("COMPREHENSIVE_LIMIT_TYPE_PER_ACCIDENT_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.incidentLimit']")));
					coverage.put("COMPREHENSIVE_LIMIT_TYPE_PER_PERSON_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[3]/*[@ng-show='item.exposureLimit']")));

					coverage.put("COMPREHENSIVE_LIMIT_VALUE_PER_PERSON_"+ LICENSE, seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("COMPREHENSIVE_LIMIT_VALUE_PER_ACCIDENT_"+ LICENSE,	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
			}
		}

		return coverage;
	}


	public HashMap<String, String> 	getHOPolicyLocationCoverageDataFromUI() {
		HashMap<String, String> coverage = new HashMap<>();
		seleniumCommands.waitForElementToBeVisible(COV_CURRENCY_XPATH);
		int locCount = seleniumCommands.getElements(By.xpath(LOCATION_HEADER_XPATH)).size();
		System.out.println(locCount + "locCount") ;
		for (int j = 1; j <= locCount; j++)
		{
			seleniumCommands.click(By.xpath(LOCATION_HEADER_XPATH + "[" + j +"]"));
			coverage.put("LOCATION" ,
					seleniumCommands.getTextAtLocator(By.xpath(LOCATION_HEADER_XPATH+"[" + j + "]/td[1]")));
			coverage.put("LOCATION_DESC ",
					seleniumCommands.getTextAtLocator(By.xpath(LOCATION_HEADER_XPATH+"[" + j + "]/td[2]")));
			coverage.put("LOCATION_ADDRESS" ,
					seleniumCommands.getTextAtLocator(By.xpath(LOCATION_HEADER_XPATH+"[" + j + "]/td[3]")));
			coverage.put("LOCATION_LISTED" ,
					seleniumCommands.getTextAtLocator(By.xpath(LOCATION_HEADER_XPATH+"[" + j + "]/td[4]")));

			int rowCount = seleniumCommands.getElements(By.xpath(COV_HEADER_XPATH)).size();
			System.out.println(rowCount + "Row") ;
			for (int i = 1; i <= rowCount; i++) {
				String rowPath = COV_HEADER_XPATH + "[" + i +"]";
				if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Loss Of Use"))
				{
					System.out.println(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText());
					coverage.put("HO_LOSS_OF_USE", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_LOSS_OF_USE_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_LOSS_OF_USE_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_LOSS_OF_USE_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
					
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Dwelling"))
				{
					coverage.put("HO_DWEL", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_DWEL_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_DWEL_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_DWEL_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Section I Deductibles"))
				{
					coverage.put("HO_SEC", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_SEC_DEDUCT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Other Structures"))
				{
					coverage.put("HO_OTR_STRU", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_OTR_STRU_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_OTR_STRU_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_OTR_STRU_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Ordinance Or Law"))
				{
					coverage.put("HO_ORD_LAW", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_OTR_STRU_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_ORD_LAW_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_ORD_LAW_LIMIT_VALUE_PER_ACCIDENT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Personal Property"))
				{
					coverage.put("HO_PER_PROP", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_PER_PROP_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_PER_PROP_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_PER_PROP_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
					logger.info("-----------------------" +seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Medical Payments"))
				{
					coverage.put("HO_MED_PAY", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_MED_PAY_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_MED_PAY_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_MED_PAY_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Homeowners Personal Liability"))
				{
					coverage.put("HO_PER_LIB", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("HO_PER_LIB_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("HO_PER_LIB_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("HO_PER_LIB_LIMIT_VALUE_PER_ACCIDENT",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
				else if(seleniumCommands.getElement(By.xpath(rowPath+"/td[1]")).getText().equals("Limited Fungi, Wet or Dry Rot or Bacteria"))
				{
					coverage.put("LMT_FUNGI_WET_BACT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[1]")));
					coverage.put("LMT_FUNGI_WET_BACT_DEDUCTIBLE",	seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[2]")));
					coverage.put("LMT_FUNGI_WET_BACT_LIMIT_VALUE_PER_PERSON", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.exposureLimit']")));
					coverage.put("LMT_FUNGI_WET_BACT_LIMIT_VALUE_PER_ACCIDENT", seleniumCommands.getTextAtLocator(By.xpath(rowPath + "/td[4]/*[@ng-show='item.incidentLimit']")));
				}
			}
		}
		logger.info("Data from UI----------------------------"+coverage.toString());
		return coverage;
		}
	
	//Validtion Method
	public Validation isPolicyDetailsPageLoaded()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new Validation(seleniumCommands.isElementPresent(CHANGE_POLICY_BUTTON));
	}
	
	public Validation arePAPolicyVehicleCoverageDetailsAreMatchingBackEnd() throws ParseException
	{
		return MapCompare.compareMap(getVehicleCoverageDataFromUI(), ParseClaimData.getPAClaimVehicleCoverageDataFromBackEnd(DataFetch.getClaimPolicyData(data.get("ClaimSearchValue"))));
	}
	
	public Validation arePAPolicyLevelCoverageDetailsAreMatchingBackEnd() throws ParseException
	{
		return MapCompare.compareMap(getPAPolicyLevelCoverageDataFromUI(), ParseClaimData.getPAClaimPolicyLevelCoverageDataFromBackEnd(DataFetch.getClaimPolicyData(data.get("ClaimSearchValue"))));
	}
	
	public Validation areHOPolicyLocationCoverageDetailsAreMatchingBackEnd() throws ParseException
	{
		return MapCompare.compareMap(getHOPolicyLocationCoverageDataFromUI(), ParseClaimData.getHOClaimPolicyLocationCoverageDataFromBackEnd(DataFetch.getClaimPolicyData(data.get("ClaimSearchValue"))));
	}

}
