package com.guidewire.portals.claimportal.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class PolicyEnrollmentPage 
{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());
	@FindBy(name = "firstname")
	WebElement FIRST_NAME;
	
	@FindBy(name = "lastname")
	WebElement LAST_NAME;
	
	@FindBy(name = "policyNumber")
	WebElement POLICY_NUM;

	@FindBy(name = "address1")
	WebElement ADD_LINE1;
	
	@FindBy(name = "[ng-click='enrollPolicy()']")
	WebElement ADD_POLICY_BTN;
	
	
	public PolicyEnrollmentPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	
	public PolicyEnrollmentPage setPolicyEnrollmentData()
	{
		seleniumCommands.type(FIRST_NAME, data.get("POLICY_ENROLL_FIRSTNAME"));
		seleniumCommands.type(LAST_NAME, data.get("POLICY_ENROLL_LASTNAME"));
		seleniumCommands.type(POLICY_NUM, data.get("POLICY_NUM"));
		seleniumCommands.type(ADD_LINE1, data.get("AddLine1"));
		return this;
	}
	
	//Validation
	
	public Validation validateRequiredFieldErrorMessage()
	{
		return new AlertHandler().validateEnrollmentDataErrorPopUpContent();
	}
}
