package com.guidewire.portals.claimportal.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairFacilityPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class NewClaimDocumentPage extends ClaimWizardPage {

	@FindBy(css = "[ng-model='vehicleIncident.vehicle.value']")
	WebElement VEHICLE_DROP_CSS;

	@FindBy(css = "[ng-model='vehicleIncident.driver.value']")
	WebElement DRIVER_DROP_CSS;

	@FindBy(css = "[model='vehicleIncident.safeToDrive'] label[class=second]")
	WebElement SAFE_TO_DRIVE_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.safeToDrive'] label[class=second]")
	WebElement SAFE_TO_DRIVE_RBTN_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.airbagsDeployed'] label[class=second]")
	WebElement AIRBAG_DEPLOYED_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.airbagsDeployed'] label[class=second]")
	WebElement AIRBAG_DEPLOYED_RBTN_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.equipmentFailure'] label[class=second]")
	WebElement EQUIP_FAIL_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.equipmentFailure'] label[class=second]")
	WebElement EQUIP_FAIL_RBTN_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.vehicleTowed'] label[class=second]")
	WebElement VEHICLE_TOWED_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.vehicleTowed'] label[class=second]")
	WebElement VEHICLE_TOWED_RBTN_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.rentalRequired'] label[class=second]")
	WebElement RENTAL_REQ_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.rentalRequired'] label[class=second]")
	WebElement RENTAL_REQ_RBTN_YES_CSS;

	@FindBy(id = "frontBumper")
	WebElement FRONT_BUMPER_ID;

	@FindBy(id = "frontLeftCorner")
	WebElement LEFT_CORNER_ID;

	@FindBy(id = "frontRightCorner")
	WebElement RIGHT_CORNER_ID;

	@FindBy(id = "hood")
	WebElement HOOD_ID;

	@FindBy(id = "frontRightSide")
	WebElement FRONT_RIGHT_SIDE_ID;

	@FindBy(id = "frontLeftSide")
	WebElement FRONT_LEFT_SIDE_ID;

	@FindBy(id = "roof")
	WebElement ROOF_ID;

	@FindBy(css = "[ng-click='goToPrevious()']")
	WebElement PREVIOUS_BTN_CSS;

	// ADD passenger

	@FindBy(css = "[ng-click='addVehicleIncident(collisionVehiclesForm)']")
	WebElement ADD_ANOTHER_VEHICLE_BTN_CSS;

	@FindBy(css = "[class*='gw-btn-primary gw-dropdown-toggle']")
	WebElement ADD_PERSON_BTN_CSS;

	@FindBy(css = "[ng-click='addRelatedContact(null, $event)'] a")
	WebElement NEW_PERSON_OPTION_CSS;

	@FindBy(css = "input[ng-model='c.contact.firstName.value']")
	WebElement NEW_PERSON_FIRSTNAME_CSS;

	@FindBy(css = "input[ng-model='c.contact.lastName.value']")
	WebElement NEW_PERSON_LASTNAME_CSS;

	@FindBy(css = "[gw-pl-select='c.role.value']")
	WebElement NEW_PERSON_ROLE_CSS;

	@FindBy(css = "input[ng-model='c.contact.homeNumber.value']")
	WebElement NEW_PERSON_CONTACTNUM_CSS;

	@FindBy(css = "[ng-model='c.injured.value']")
	WebElement NEW_PERSON_INJURED_STATUS_CSS;

	@FindBy(css = "[ng-click='removePassenger(passenger.value)']")
	WebElement NEW_PERSON_DELETE_CSS;

	@FindBy(css = "[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;

	@FindBy(css = "[ng-click='handleClick(params)'][icon='upload']")
	WebElement UPLOAD_DOC_BTN_CSS;

	final String UPLOAD_DOC_INPUT_CSS = "[id='uploadButton'][aria-disabled='false'] input";
	
	final String UPLOADED_DOC_LIST_CSS = "[ng-repeat*='document']";

	String PASSENGER_NAME = "a:contains('NAME-PASSENGER')";
	String SELECT_ANOTHER_PERSON = "a:contains('Another person')";
	String DOCUMENT_CHECK = "[class='fa fa-check-square-o']";
	String ADD_PERSON = "[class*='gw-btn-primary gw-dropdown-toggle']";
	String ERROR_CLASS_INPUT = "gw-input-block-level ng-pristine ng-untouched ng-valid ng-empty ng-invalid";

	public NewClaimDocumentPage() {
		super();
		seleniumCommands.pageWebElementLoader(this);
	}

	public Validation isPageLoaded() {
		seleniumCommands.waitForElementToBeClickable(By.cssSelector(ADD_PERSON));
		return new Validation(true);
	}

	public NewClaimDocumentPage withNewContactPerson() {
		ThreadLocalObject.getData().put("WithNewContact", "true");
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_PERSON));
		addNewContactPerson();
		seleniumCommands.type(NEW_PERSON_FIRSTNAME_CSS, data.get("FirstNameNewPerson"));
		seleniumCommands.type(NEW_PERSON_LASTNAME_CSS, data.get("LastNameNewPerson"));
		seleniumCommands.selectDropDownValueByText(NEW_PERSON_ROLE_CSS, data.get("NewPersonInvolvementWitness"));
		seleniumCommands.type(NEW_PERSON_CONTACTNUM_CSS, data.get("NewPersonHomePhone"));
		seleniumCommands.selectDropDownValueByText(NEW_PERSON_INJURED_STATUS_CSS, data.get("NewPersonInjured"));

		if (data.get("NewPersonInvolvementWitness").equalsIgnoreCase("witness")) {
			ThreadLocalObject.getData().put("WITNESS_DISPLAY_NAME", data.get("FirstNameNewPerson") + " " + data.get("LastNameNewPerson"));
			ThreadLocalObject.getData().put("WITNESS_CONTACT_NUM", data.get("NewPersonHomePhone"));
		}

		if (data.get("NewPersonInjured").equalsIgnoreCase("yes")) {
			ThreadLocalObject.getData().put("INJURED_DISPLAY_NAME", data.get("FirstNameNewPerson") + " " + data.get("LastNameNewPerson"));
			ThreadLocalObject.getData().put("INJURED_CONTACT_NUM", data.get("NewPersonHomePhone"));
		}
		
		return this;
	}

	public NewClaimDocumentPage addNewContactPerson() {
		logger.info("Adding New Contact Person");
		seleniumCommands.click(ADD_PERSON_BTN_CSS);
		seleniumCommands.waitForElementToBeVisible(NEW_PERSON_OPTION_CSS);
		seleniumCommands.click(NEW_PERSON_OPTION_CSS);
		seleniumCommands.waitForElementToBeVisible(NEW_PERSON_FIRSTNAME_CSS);
		return this;
	}

	public NewClaimContactPersonPage goNext() {
		clickNext();
		return new NewClaimContactPersonPage();
	}

	public NewClaimRepairFacilityPage getBackToNewRepairFacilityDetails() {
		clickPrevious();
		return new NewClaimRepairFacilityPage();
	}

	public NewClaimRecommendedRepairFacilityPage getBackToRecommendedRepairFacilityDetails() {
		clickPrevious();
		return new NewClaimRecommendedRepairFacilityPage();
	}

	public NewClaimRepairChoicePage getBackToRepairChoice() {
		clickPrevious();
		return new NewClaimRepairChoicePage();
	}

	public AlertHandler cancelClaim() {
		clickCancel();
		return new AlertHandler();
	}

	// Get Method

	public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}

	// Validation

	public Validation validateNewContactMandatoryFieldsErrorMessag() {
		logger.info("Validating the Mandatory field Error for New Contact Person");
		new Validation(seleniumCommands.getAttributeValueAtLocator(NEW_PERSON_FIRSTNAME_CSS, "class").contains(
				INVALID_INPUT_NEW_ERROR_CLASS))
						.shouldBeTrue("New Contact FirstName is not marked with error.");
		new Validation(seleniumCommands.getAttributeValueAtLocator(NEW_PERSON_LASTNAME_CSS, "class").contains(
				INVALID_INPUT_NEW_ERROR_CLASS))
						.shouldBeTrue("New Contact LastName is not marked with error.");
		return new Validation(true);
	}

	public Validation areNewPersonDetailsAreSaved() {
		logger.info("Validating if Passenger details are saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(NEW_PERSON_FIRSTNAME_CSS),
				data.get("FirstNameNewPerson")).shouldBeEqual("New Person First Name is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(NEW_PERSON_LASTNAME_CSS),
				data.get("LastNameNewPerson")).shouldBeEqual("New Person Last Name is not saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(NEW_PERSON_ROLE_CSS),
				data.get("NewPersonInvolvementWitness")).shouldBeEqual("New Person Involvment value is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(NEW_PERSON_CONTACTNUM_CSS),
				data.get("NewPersonHomePhone")).shouldBeEqual("New Person contact num is not saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(NEW_PERSON_INJURED_STATUS_CSS),
				data.get("NewPersonInjured")).shouldBeEqual("New Person injurt status is not saved");
		return new Validation(true);
	}

	public NewClaimDocumentPage uploadDocFromFNOL() {
		logger.info("Uploading document");
		seleniumCommands.waitForElementToBeVisible(UPLOAD_DOC_BTN_CSS);
		seleniumCommands.uploadClaimDoc(UPLOAD_DOC_INPUT_CSS, "PNG");
		return this;
	}
	
	public Validation isDocumentUplaoded() {
		logger.info("Checking uploaded document");
		boolean uploaded = false;
		seleniumCommands.waitForLoaderToDisappearFromPage();
		for(WebElement uplaodedFiles : seleniumCommands.findElements(By.cssSelector(UPLOADED_DOC_LIST_CSS)))
		{
			if(seleniumCommands.getFileType(ThreadLocalObject.getData().get("DocType")).contains(uplaodedFiles.getText()));
			{
				return new Validation(true);
			}
		}
		return new Validation(uploaded);
	}
}
