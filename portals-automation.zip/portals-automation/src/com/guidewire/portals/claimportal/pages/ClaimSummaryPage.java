package com.guidewire.portals.claimportal.pages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import com.guidewire.common.util.DateUtil;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.claims.model.component.PartiesInvolvedPopUp;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.dto.PropertyDTO;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;
import com.guidewire.data.PolicyData;
import com.guidewire.data.ReadTestData;
import com.guidewire.portals.claimportal.subpages.AddNotePage;
import com.guidewire.portals.claimportal.subpages.ChecksTab;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.portals.claimportal.subpages.NotesTab;
import com.guidewire.portals.claimportal.subpages.RepairsTab;
import com.guidewire.portals.claimportal.subpages.SummaryTab;
import com.guidewire.portals.claimportal.subpages.VendorDetailsPopUp;
import com.guidewire.widgetcomponents.table.Table;

public final class ClaimSummaryPage extends SummaryTab {

	private final Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(id = "createNoteButton")
	WebElement ADD_NOTE_BTN_ID;

	@FindBy(xpath = "(//section//p)[1]")
	WebElement POLICY_NUMBER_VALUE_XPATH;

	@FindBy(css = "[class='gw-btn-back']")
	WebElement GO_BACK_TO_CLAIM_LIST_BTN_CSS;

	@FindBy(xpath = "(//section//p)[5]")
	WebElement ACCOUNT_NUMBER_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[2]")
	WebElement CLAIM_STATUS_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[3]")
	WebElement REPORTER_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[4]")
	WebElement LOSS_LOCATION_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[6]")
	WebElement CLAIM_DOL_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[7]")
	WebElement CLAIM_NOTIFICATION_DATE_XPATH;

	@FindBy(xpath = "(//section//p)[7]")
	WebElement PRIMARY_CONTACT_VALUE_XPATH;

	@FindBy(xpath = "(//section//p)[8]")
	WebElement PRIMARY_CONTACT_VALUE_WC_XPATH;

	@FindBy(xpath = "(//*[@ng-show='details.claim.adjuster']//p)[1]")
	WebElement ADJUSTER_NAME_VALUE_XPATH;

	@FindBy(xpath = "(//*[@ng-show='details.claim.adjuster']//p)[2]")
	WebElement ADJUSTER_CONTACTNUM_XPATH;

	// Vehicle Coverage
	@FindBy(css = "[class='gw-table gw-vehicle-table ng-scope'] tbody tr:nth-of-type(1)")
	WebElement VEHICLE1_ROW_CSS;

	@FindBy(css = "div[class*='gw-claim-detail-page']")
	WebElement CLAIM_PAGE;

	By FINANCIAL_DATA_SECTION_CSS = By.cssSelector("[ng-show='canAccessFinancials()'][aria-hidden='false']");
	By POLICY_LINK = By.xpath("(//section//p)[1]//a");
	By ACCOUNT_LINK = By.xpath("(//section//p)[5]//a");
	By POLICY_LABEL_VALUE_XPATH = By.xpath("//*[text()='"+data.get(PolicyData.POLICY_NUM.toString())+"']");
	//Parties Involvement

	private static final String PARTIES_INVOLVEMENT_ROW_CSS = "[id='partiesInvolved'] tbody tr";
	private static final String SUMMARY_SECTION = ".gw-clearfix";
	private static final String ADJUSTER_SECTION = ".gw-adjuster-section";
	private static final String VENDORS_SECTION = "[ng-repeat] [class*='gw-parties-section']";

	protected By PARTIES_INVOLVED_TITLE = By.xpath("//div[@class='gw-parties-section ng-scope']/h2");
	protected By PARTIES_INVOLVED_TABLE = By.xpath("//table[@id='partiesInvolved']");
	protected By ACTIVITIES_TITLE = By.cssSelector("div[class='gw-page-section-title ng-binding']");
	protected By ACTIVITIES_TABLE = By.xpath("//table[@id='activitiesTable']");

	public ClaimSummaryPage() {
		super();
	}

	public AddNotePage addNote() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(ADD_NOTE_BTN_ID);
		return new AddNotePage();
	}

	public PolicyDetailPage clickPolicyNumber() {
		seleniumCommands.clickbyJS(POLICY_LINK);
		return new PolicyDetailPage();
	}

	public AccountSummaryPage clickAccountNumber() {
		seleniumCommands.clickbyJS(ACCOUNT_LINK);
		return new AccountSummaryPage();
	}

	public PartiesInvolvedPopUp clickInvolvedPartiesByAccountName() {
		String accountName=ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString()) + " " + ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString());
		seleniumCommands.waitForElementToBeVisible(By.linkText(accountName));
		seleniumCommands.findElement(By.linkText(accountName)).click();
		return new PartiesInvolvedPopUp();
	}

	private void goBackClick() {
		seleniumCommands.clickbyJS(GO_BACK_TO_CLAIM_LIST_BTN_CSS);
	}

	public CP_ClaimListPage goBackCP() {
		this.goBackClick();
		return new CP_ClaimListPage();
	}

	@Deprecated
	public NotesTab openNoteTab() {
		NotesTab tab = new NotesTab();
		tab.openTab();
		return tab;
	}

	@Deprecated
	public DocumentsTab openDocTab() {
		DocumentsTab tab = new DocumentsTab();
		tab.openTab();
		return tab;
	}

	public HashMap<String, String> getClaimSummaryDataFromUI() {
		HashMap<String, String> summary = new HashMap<>();
		seleniumCommands.waitForElementToBeVisible(POLICY_LABEL_VALUE_XPATH);
		summary.put(ClaimData.POLICY_NUM.getValue(),
				seleniumCommands.getTextAtLocator(POLICY_NUMBER_VALUE_XPATH));
		summary.put(ClaimData.ACCOUNT_NUM.getValue(),
				seleniumCommands.getTextAtLocator(ACCOUNT_NUMBER_VALUE_XPATH));
		summary.put(ClaimData.CLAIM_STATE.getValue(),
				seleniumCommands.getTextAtLocator(CLAIM_STATUS_VALUE_XPATH));
		summary.put(ClaimData.DATE_OF_LOSS.getValue(),
				seleniumCommands.getTextAtLocator(CLAIM_DOL_VALUE_XPATH));
		summary.put(ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(),
				seleniumCommands.getTextAtLocator(REPORTER_VALUE_XPATH));

		String primaryContact;
		if (data.get("ClaimType").equals("WorkersComp")) {
			primaryContact = seleniumCommands.getTextAtLocator(PRIMARY_CONTACT_VALUE_WC_XPATH);
		} else {
			primaryContact = seleniumCommands.getTextAtLocator(PRIMARY_CONTACT_VALUE_XPATH);
		}
		summary.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(),
				primaryContact);
		summary.put(ClaimData.ADJUSTER_DISPLAY_NAME.getValue(),
				seleniumCommands.getTextAtLocator(ADJUSTER_NAME_VALUE_XPATH));
		summary.put(ClaimData.ADJUSTER_CONTACT_NUM.getValue(),
				seleniumCommands.getTextAtLocator(ADJUSTER_CONTACTNUM_XPATH));
		//AMP is not having vehicle table section on claim summary.
		if (data.get("ClaimType").equals("PersonalAuto") && !ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.AMP.toString())) {
			summary.put(ClaimData.LOSS_LOCATION_DISPLAY_NAME.getValue(),
					seleniumCommands.getTextAtLocator(LOSS_LOCATION_VALUE_XPATH).replaceAll("[\\t\\n\\r]",""));
			summary.put(ClaimData.VEHICLE_MAKE.getValue(),
					seleniumCommands.getTextAtLocator(VEHICLE1_ROW_CSS.findElement(By.xpath("./td[1]"))));
			summary.put(ClaimData.VEHICLE_YEAR.getValue(),
					seleniumCommands.getTextAtLocator(VEHICLE1_ROW_CSS.findElement(By.xpath("./td[3]"))));
			summary.put(ClaimData.VEHICLE_LICENSE_PLATE.getValue(),
					seleniumCommands.getTextAtLocator(VEHICLE1_ROW_CSS.findElement(By.xpath("./td[4]"))));
			summary.put(ClaimData.VEHICLE_MODEL.getValue(),
					seleniumCommands.getTextAtLocator(VEHICLE1_ROW_CSS.findElement(By.xpath("./td[2]"))));
		}

		if (data.get("ClaimType").equals("WorkersComp")) {
			summary.put(ClaimData.LOSS_LOCATION_DISPLAY_NAME.getValue(),
					seleniumCommands.getTextAtLocator(LOSS_LOCATION_VALUE_XPATH).replaceAll("[\\t\\n\\r]",""));
			summary.put(ClaimData.DATE_NOTIFIED.getValue(),
					seleniumCommands.getTextAtLocator(CLAIM_NOTIFICATION_DATE_XPATH));
		}

		if (data.get("Suite").equals("CP-Producer") || ThreadLocalObject.getSuitenName().equals(SuiteName.GPA.toString())){
			summary.putAll(getPartiesInvolvedDataFromUI());
		}

		return summary;
	}

	private HashMap<String, String> getPartiesInvolvedDataFromUI() {
		HashMap<String, String> partiesData = new HashMap<>();
		int row = seleniumCommands.getElements(By.cssSelector(PARTIES_INVOLVEMENT_ROW_CSS)).size();
		for (int i = 1; i <= row; i++) {
			String name = seleniumCommands.getTextAtLocator(By.cssSelector(PARTIES_INVOLVEMENT_ROW_CSS+":nth-of-type(" + i +") td:nth-of-type(1) a"));
			String involvment = seleniumCommands.getTextAtLocator(By.cssSelector(PARTIES_INVOLVEMENT_ROW_CSS+":nth-of-type(" + i +") td:nth-of-type(2)"));
			String[] roles = involvment.split(",");

			for(String s : roles) {
				if (s.trim().equalsIgnoreCase("Witness")) {
					partiesData.put(ClaimData.WITNESS_DISPLAY_NAME.getValue(), name);
				} else if (s.trim().equalsIgnoreCase("Injured Party")) {
					partiesData.put(ClaimData.INJURED_DISPLAY_NAME.getValue(), name);
				} else if (s.trim().equalsIgnoreCase("Insured")) {
					partiesData.put(ClaimData.INSURED_DISPLAY_NAME.getValue(), name);
				} else if (s.trim().equalsIgnoreCase("Main Contact")) {
					partiesData.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(), name);
				} else if (s.trim().equalsIgnoreCase("Reporter")) {
					partiesData.put(ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(), name);
				} else if (s.trim().equalsIgnoreCase("Service Vendor")) {
					partiesData.put(ClaimData.VENDOR_NAME.getValue(), name);
				}
			}
		}
		return partiesData;
	}

	private static ArrayList<String> getHOPageSectionSelectors() {
		ArrayList returnArray = new ArrayList<>(Arrays.asList(SUMMARY_SECTION, ADJUSTER_SECTION, VENDORS_SECTION));
		return returnArray;
	}

	private static ArrayList<String> getPAPageSectionSelectors() {
		ArrayList<String> returnArray = getHOPageSectionSelectors();
		//AMP is not having vehicle table section on claim summary.
		//returnArray.add(VEHICLES_SECTION);
		return returnArray;
	}

	// Validation Methods

	public Validation isClaimSummaryDataMatchingWithBackEnd(String claimNum) throws Exception {
		return MapCompare.compareMap(getClaimSummaryDataFromUI(),
				ParseClaimData.getClaimSummaryDataFromBackEnd(DataFetch.getClaimData(claimNum)));
	}

	public Validation isClaimSummaryDataForAgentMatchingWithBackEnd(String claimNum) throws Exception {
		return MapCompare.compareMap(getClaimSummaryDataFromUI(),
				ParseClaimData.getClaimSummaryDataFromBackEnd(DataFetch.getAgentClaimData(claimNum)));
	}

	public Validation isClaimSummaryDataMatchingWithProvidedToWizard(String claimNum) throws Exception {
		HashMap<String, String> summaryData = new HashMap<>();
		Map<String, String> wizardData = ThreadLocalObject.getData();

		summaryData.put(ClaimData.POLICY_NUM.getValue(), wizardData.get("POLICY_NUM"));
		summaryData.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(), data.get("EXISTING_CONTACT"));

		return MapCompare.compareMap(getClaimSummaryDataFromUI(),summaryData);
	}

	public Validation validateClaimNumberFormat(String claimNum) {
		String[] claim = claimNum.split("-");
		new Validation(claim.length, 3).shouldBeEqual("Claim num "+ claimNum + " format is not correct ");
		new Validation(claim[0].length(), 3).shouldBeEqual("Claim num "+ claimNum + " first half is not having 3 digit " + claim[0]);
		new Validation(claim[1].length(), 2).shouldBeEqual("Claim num "+ claimNum + " second half is not having 2 digit " + claim[1]);
		new Validation(claim[2].length(), 6).shouldBeEqual("Claim num "+ claimNum + " third half is not having 3 digit " + claim[2]);
		return new Validation(true);
	}

	private Map<String, Map<String,String>> getLossCauseDataTransformations() {
		Map<String, String> lossCauseTransformations = ReadTestData.getTestData("lossCauseTransformations");
		Map<String, Map<String,String>> dataTransformations = new HashMap<>();
		dataTransformations.put(ClaimData.LOSS_CAUSE.getValue(), lossCauseTransformations);
		return dataTransformations;
	}

	public Validation isClaimDetailsDataMatchingWithBackEnd(String claimNum) throws Exception {
		//ThreadLocalObject.getData().put("VendorName",ThreadLocalObject.getData().get("RepairFacilityName"));
		return MapCompare.compareMap(
			data,
			ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)),
			getLossCauseDataTransformations()
		);
	}

	public Validation isClaimDetailsDataForAgentMatchingWithBackEnd(String claimNum) throws Exception {
		return MapCompare.compareMap(
				data,
				ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getAgentClaimData(claimNum)),
				getLossCauseDataTransformations()
		);
	}

	public Validation isClaimSummaryPageLoaded() {
		logger.info("Validating claim summary screen");

		if (suiteName.equals(SuiteName.CPAGENT) || suiteName.equals(SuiteName.GPA)) {
			new Validation(seleniumCommands.isElementPresent(FINANCIAL_DATA_SECTION_CSS)).shouldBeTrue("Claim summary financial data NOT visible");
		}
		else {
			new Validation(seleniumCommands.isElementNotPresent(FINANCIAL_DATA_SECTION_CSS)).shouldBeTrue("Claim summary financial data IS visible");
		}

		return new Validation(seleniumCommands.isElementPresent(CLAIM_PAGE));
	}

	public Validation validateClaimSummaryTabsPresenceForVendorEngage() {
		new Validation(new SummaryTab().isTabAvailable()).shouldBeTrue("SummaryTab not available");
		new Validation(new NotesTab().isTabAvailable()).shouldBeTrue("NotesTab not available");
		new Validation(new DocumentsTab().isTabAvailable()).shouldBeTrue("DocumentsTab not available");
		return new Validation(true);
	}

	public Validation validateClaimSummaryTabsPresence() {
		new Validation(new SummaryTab().isTabAvailable()).shouldBeTrue("SummaryTab not available");
		new Validation(new NotesTab().isTabAvailable()).shouldBeTrue("NotesTab not available");
		new Validation(new DocumentsTab().isTabAvailable()).shouldBeTrue("DocumentsTab not available");

		if (suiteName.equals(SuiteName.CPVENDOR)) {
			new Validation(new ChecksTab().isTabAvailable()).shouldBeFalse("ChecksTab IS available");
			new Validation(new RepairsTab().isTabAvailable()).shouldBeFalse("RepairsTab IS available");
		} else {
			new Validation(new ChecksTab().isTabAvailable()).shouldBeTrue("ChecksTab not available");
			new Validation(new RepairsTab().isTabAvailable()).shouldBeTrue("RepairsTab not available");
		}

		return new Validation(true);
	}

	public Validation isPartiesInvolvedDetailsDataMatchingWithBackEndForVendor(){
		new Validation(seleniumCommands.getTextAtLocator(PARTIES_INVOLVED_TITLE), "Parties Involved" ).shouldBeEqual("Mismatch in Parties Involved Header");
		if(this.partiesTable().getRowByIndex(0).getCellByIndex(0).getText().equals(data.get("VendorName"))){
			new Validation(this.partiesTable().getRowByIndex(0).getCellByIndex(1).getText().equalsIgnoreCase("Insured, Reporter") || this.partiesTable().getRowByIndex(0).getCellByIndex(1).getText().equalsIgnoreCase("Reporter, Insured")).shouldBeTrue("Mismatch in Vendor, Involvement");
			new Validation(this.partiesTable().getRowByIndex(1).getCellByIndex(0).getText(), data.get("VendorCompanyName")).shouldBeEqual("Mismatch in Vendor Company Name");
			new Validation(this.partiesTable().getRowByIndex(1).getCellByIndex(1).getText(), "Activity Owner").shouldBeEqual("Mismatch in Vendor Company, Involvement");
		}else if(this.partiesTable().getRowByIndex(0).getCellByIndex(0).getText().equals(data.get("VendorCompanyName")))
		{
			new Validation(this.partiesTable().getRowByIndex(0).getCellByIndex(1).getText(), "Activity Owner").shouldBeEqual("Mismatch in Vendor Company, Involvement");
			new Validation(this.partiesTable().getRowByIndex(1).getCellByIndex(0).getText(), data.get("VendorName")).shouldBeEqual("Mismatch in Vendor Name");
			new Validation(this.partiesTable().getRowByIndex(1).getCellByIndex(1).getText().equalsIgnoreCase("Insured, Reporter") || this.partiesTable().getRowByIndex(0).getCellByIndex(1).getText().equalsIgnoreCase("Reporter, Insured")).shouldBeTrue("Mismatch in Vendor, Involvement");
		}else{
				new Validation(false).shouldBeTrue("Involved parties data not found");
		}

		return new Validation(true);
	}

	public Validation isActivitiesDataMatchingWithBackEndForVendor(){
		new Validation(seleniumCommands.getTextAtLocator(ACTIVITIES_TITLE), "Activities" ).shouldBeEqual("Mismatch in Activities Header");
		new Validation(this.activitiesTable().getRowByIndex(0).getCellByIndex(0).getText(), DateUtil.formatDateTo(data.get("VendorDueDate"), "yyyy-MM-dd", "MMMM d, YYYY")).shouldBeEqual("Mismatch in Due Date");
		new Validation(this.activitiesTable().getRowByIndex(0).getCellByIndex(1).getText().equalsIgnoreCase(data.get("VendorPriority"))).shouldBeTrue("Mismatch in Activity Priority");
		new Validation(this.activitiesTable().getRowByIndex(0).getCellByIndex(2).getText().equalsIgnoreCase(data.get("VendorStatus"))).shouldBeTrue("Mismatch in Activity Status");
		new Validation(this.activitiesTable().getRowByIndex(0).getCellByIndex(3).getText(), data.get("VendorSubject")).shouldBeEqual("Mismatch in Activity Subject");
		new Validation(this.activitiesTable().getRowByIndex(0).getCellByIndex(4).getText(), data.get("VendorFirstName") + " "+data.get("VendorLastName")).shouldBeEqual("Mismatch in Activity Assigned Name");
		return new Validation(true);
	}

	public Table activitiesTable(){
		return new Table(seleniumCommands.findElement(ACTIVITIES_TABLE));
	}


	public Table partiesTable(){
		return new Table(seleniumCommands.findElement(PARTIES_INVOLVED_TABLE));
	}

	public Validation areVendorDetailsOnPopUpCorrect() throws Exception {
		return new VendorDetailsPopUp().openAndValidateVendorPopDetails();
	}
	
	public Validation areNotesValueMatchingWithBackEnd() throws Exception {
		return areNotesValueMatchingWithBackEnd(data.get("ClaimSearchValue"));
	}

	public Validation areNotesValueMatchingWithBackEnd(String claimvalue) throws Exception {
		return MapCompare.compareMap(data,
				this.getNoteMapForDataNoteSubject(ParseClaimData.getClaimNotesDataFromBackEnd(DataFetch.getClaimData(claimvalue))));
	}

	public Validation isDocAddedMatchingWithBackEnd(String claimNum) throws Exception {
		return MapCompare.compareMap(data,
				this.getDocMapForDataDocName(ParseClaimData.getClaimDocumentDataFromBackEnd(DataFetch.getClaimData(claimNum))));
	}

	private HashMap<String, String> getNoteMapForDataNoteSubject(List<HashMap<String, String>> notesList ) {
		String noteSubject = data.get("NoteSubject");
		logger.debug("Searching for NoteSubject: " + noteSubject);
		for (HashMap note : notesList) {
			if (note.containsValue(noteSubject)) {
				return note;
			}
		}
		return null;
	}

	private HashMap<String, String> getDocMapForDataDocName(List<HashMap<String, String>> allDocs ) {
		if (data.containsKey("DocType")) {
			logger.info("Inside doctype");
			String docName = data.get("DocType") + "File." + data.get("DocType");
			logger.debug("Searching for Document Name: " + docName);
			for (HashMap doc : allDocs) {
				if (doc.containsValue(docName.toLowerCase())) {
					return doc;
				}
			}
		} else {
			logger.debug("Searching for Sample File uploaded ");
			for (HashMap doc : allDocs) {
				if (doc.containsValue(seleniumCommands.getFileType("SAMPLE"))) {
					return doc;
				}
			}
		}
		return null;
	}

	public Validation isPAPageDisplayedCorrectly() {
		seleniumCommands.waitForElementToContainText(seleniumCommands.findElement(By.xpath("(//div[@class='gw-control-group']//p)[2]")), "Open");
		ArrayList<String> selectors = getPAPageSectionSelectors();
		boolean allSectionShow;
		allSectionShow = selectors.stream().allMatch(selector -> seleniumCommands.isElementPresent(By.cssSelector(selector)) && seleniumCommands.doesElementHaveChildren(By.cssSelector(selector)));
		return new Validation(allSectionShow);
	}

    public Validation isHOPageDisplayedCorrectly() {
    	seleniumCommands.waitForElementToBeVisible(By.cssSelector(VENDORS_SECTION));
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(SUMMARY_SECTION))).shouldBeTrue("Summary section is not present");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(ADJUSTER_SECTION))).shouldBeTrue("Adjuster section is not present");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(VENDORS_SECTION))).shouldBeTrue("Vendor section is not present");
        return new Validation(true);
    }

    public void isClaimDetailsDataBackendCallsContainingFinancialData(String claimNum) {
		String claimData = DataFetch.getClaimData(claimNum);

		if (suiteName.equals(SuiteName.CPAGENT) || suiteName.equals(SuiteName.GPA)) {
			new Validation(claimData.contains("totalIncurredNet")).shouldBeTrue("Financial data[totalIncurredNet] NOT present on backend call for claim summary");
			new Validation(claimData.contains("totalPayments")).shouldBeTrue("Financial data[totalPayments] NOT present on backend call for claim summary");
		} else {
			new Validation(claimData.contains("totalIncurredNet")).shouldBeFalse("Financial data[totalIncurredNet] IS present on backend call for claim summary");
			new Validation(claimData.contains("totalPayments")).shouldBeFalse("Financial data[totalPayments] IS present on backend call for claim summary");
		}
	}

	public Validation isCPPropertiesMatchingWithBackEnd(String claimNum) {
		List<PropertyDTO> claimProps = ParseClaimData.getCPClaimProperties(DataFetch.getClaimData(claimNum));
		long claimSize = claimProps.size();
		List<PropertyDTO> selectedProps = PropertyDTO.fromJson(data.get("SELECTED_PROPERTIES"));
		long selectedSize = selectedProps.size();

		if(System.getProperty("platform").equals("Diamond")){
			return new Validation(claimSize==selectedSize);
		}
		long countUnique = Stream.concat(claimProps.stream(), selectedProps.stream()).distinct().count();

		return new Validation(countUnique == claimSize, countUnique == selectedSize);
	}
}
