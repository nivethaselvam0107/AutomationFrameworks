package com.guidewire.portals.claimportal.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.fnol.model.component.WizardNavBar;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class NewClaimLocationPage extends ClaimWizardPage {

	@FindBy(css = "label[for='exactAddress']")
	WebElement EXACT_ADDRESS_LBL_CSS;

	@FindBy(css = "label[for='cityOnly']")
	WebElement CITY_ONLY_LBL_CSS;

	@FindBy(css = "label[for='map']")
	WebElement MAP_LBL_CSS;

	@FindBy(css = "[id='lossLocationMap'] div[class='gm-style']")
	WebElement MAP;

	By MAP_LIST_SELECTOR_CSS = By.cssSelector("[id='lossLocationMap'] div[class='gm-style'] div[aria-hidden='true'] img");

	@FindBy(css = "[model='address.addressLine1'] input")
	WebElement ADDLINE1_TXT_CSS;

	@FindBy(css = "[model='address.addressLine2'] input")
	WebElement ADDLINE2_TXT_CSS;

	@FindBy(css = "[model='address.addressLine3'] input")
	WebElement ADDLINE3_TXT_CSS;

	@FindBy(css = "[model='address.city'] input")
	WebElement CITY_TXT_CSS;

	@FindBy(css = "[model='address.postalCode'] input")
	WebElement ZIP_TXT_CSS;

	@FindBy(css = "[model='address.state'] select")
	WebElement STATE_DROP_CSS;

	@FindBy(css = "[model='claimVm.description'] textarea")
	WebElement CLAIM_DESC_TXT_CSS;

	@FindBy(css = "label[class=second]")
	WebElement PROP_DEMAGE_RBTN_NO_CSS;

	@FindBy(css = "[model='claimVm.lobs.personalAuto.fixedPropertyIncident.propertyDescription'] textarea")
	WebElement PROP_DAMAGE_DESC_TXT_CSS;

	@FindBy(css = "label[class=gw-first]")
	WebElement PROP_DEMAGE_RBTN_YES_CSS;

	@FindBy(id = "vehicleID")
	WebElement VEHICLE_ID;

	@FindBy(css = "[for='theftentire']")
	WebElement VEHICLE_THEFT_CSS;

	@FindBy(css = "[for='theftparts']")
	WebElement VEHICLE_PART_THEFT_CSS;

	@FindBy(id = "theftentire")
	WebElement VEHICLE_THEFT_RDBTN_ID;

	@FindBy(id = "theftparts")
	WebElement VEHICLE_PART_THEFT_RDBTN_ID;

	@FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;

	@FindBy(css = "[ng-show='explicitErrorMessage'][aria-hidden='false']")
	WebElement ERROR_TEXT;

	public NewClaimLocationPage() {
		super();
		seleniumCommands.waitForElementToBeVisible(EXACT_ADDRESS_LBL_CSS);
	}

	public NewClaimLocationPage withLossLocation()
	{
		if(data.get("LossLocationInput").equals("Exact"))
		{
			withExactAccidentAddress();
		}
		else if(data.get("LossLocationInput").equals("CityOnly"))
		{
			withOnlyCity();
		}
		else if(data.get("LossLocationInput").equals("Map")) {
			withLocationOnMap();
		}
		return this;
	}

	public NewClaimLocationPage withExactAccidentAddress()
	{
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("State"));
		seleniumCommands.type(ADDLINE1_TXT_CSS, data.get("AddLine1"));
		seleniumCommands.type(ADDLINE2_TXT_CSS, data.get("AddLine2"));
		seleniumCommands.type(ADDLINE3_TXT_CSS, data.get("AddLine3"));
		seleniumCommands.type(CITY_TXT_CSS, data.get("City"));
		seleniumCommands.type(ZIP_TXT_CSS, data.get("ZipCode"));
		
		ThreadLocalObject.getData().put("LOSS_LOCATION_DISPLAY_NAME", 
				data.get("AddLine1") + " " + data.get("AddLine2") + " " + data.get("AddLine3") + " " + data.get("City") + " " + data.get("StateValue") + " " + data.get("ZipCode"));
		return this;
	}

	public NewClaimLocationPage withDefaultCityOnly() {
		new CPPageFactory().setDataForDefaultCityOnlyLocation();
		return this.withOnlyCity();
	}

	public NewClaimLocationPage withOnlyCity()
	{
		this.openCityOnlyLocationSection();
		seleniumCommands.type(CITY_TXT_CSS, data.get("City"));
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("State"));
		return this;
	}

	private NewClaimLocationPage withLocationOnMap() {
		seleniumCommands.click(MAP_LBL_CSS);
		seleniumCommands.waitForElementToBeVisible(MAP);
		seleniumCommands.waitForElementToBePresent(MAP_LIST_SELECTOR_CSS);

		for (WebElement el : seleniumCommands.findElements(MAP_LIST_SELECTOR_CSS)) {
			if (seleniumCommands.isElementVisible(el)) {
				seleniumCommands.clickbyJS(el);
				logger.info("SELECTED PIN ON THE MAP WITH:");
				logger.info("\tLatitude:  " + Double.toString((Double)seleniumCommands.getAngularScopeItem(el, "$ctrl.coords.latitude")));
				logger.info("\tLongitude: " + Double.toString((Double)seleniumCommands.getAngularScopeItem(el, "$ctrl.coords.longitude")));
				break;
			}
		}

		try {
			seleniumCommands.waitForElementToBePresent(By.id("google"), 3000);
		} catch (Exception e) {
			// imitation of google map api reaction
		}

		return this;
	}

	public NewClaimRepairChoicePage goToRepairChoicePage() {
		clickNext();
		return new NewClaimRepairChoicePage();
	}

	public NewClaimLocationPage openCityOnlyLocationSection()
	{
		String browser = ThreadLocalObject.getBrowserName();
		if (browser.equalsIgnoreCase("NEXUS5"))
		{
//			AndroidDriver driver = (AndroidDriver)ThreadLocalObject.getDriver();
//			seleniumCommands.rotateMobileViewToLandscape();
		}
		else if(browser.equalsIgnoreCase("IPHONE6"))
		{

		}
		seleniumCommands.clickbyJS(CITY_ONLY_LBL_CSS);
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[hide-fields*='hideFields']"));
		return this;
	}

	public NewClaimLocationPage withClaimDescription()
	{
		seleniumCommands.type(CLAIM_DESC_TXT_CSS, data.get("LOSS_DESC"));
		return this;
	}

	public NewClaimLocationPage withPropDamageDetails()
	{
		seleniumCommands.clickbyJS(PROP_DEMAGE_RBTN_YES_CSS);
		seleniumCommands.waitForElementToBeVisible(PROP_DAMAGE_DESC_TXT_CSS);
		seleniumCommands.type(PROP_DAMAGE_DESC_TXT_CSS, data.get("WithPropDamage"));
		return this;
	}

	private String selectFirstAvailableOption(WebElement selectionElement) {
		List<String> possibleOptions = seleniumCommands.getAllOptionsFromDropDown(selectionElement);
		String optionToBeSelected = "";
		for(String anOption : possibleOptions) {
			if(!anOption.toLowerCase().contains("choose") && !anOption.toLowerCase().contains("other")) {
				optionToBeSelected = anOption;
			}
		}
		return optionToBeSelected;
	}

	public NewClaimLocationPage selectFirstAvailableVehicle() {
		String optionToBeSelected = selectFirstAvailableOption(VEHICLE_ID);
		logger.info("Selecting [" + optionToBeSelected + "] vehicle");
		seleniumCommands.selectDropDownValueByText(VEHICLE_ID, optionToBeSelected);
		data.put("VehicleDamaged", optionToBeSelected);
		String[] vehicleData = optionToBeSelected.split(" ");
		data.put("Model", vehicleData[1]);
		data.put("Make", vehicleData[0]);
		data.put("VehicleYear", vehicleData[2]);
		return this;
	}

	public NewClaimLocationPage withVehicleInvolved() {
		if (data.get("VehicleDamaged") == null || data.get("VehicleDamaged").isEmpty()) {
			return this.selectFirstAvailableVehicle();
		}
		seleniumCommands.selectDropDownValueByText(VEHICLE_ID, data.get("VehicleDamaged"));
		return this;
	}

	public NewClaimLocationPage withAnyVehicleInvolved() {
		return this.selectFirstAvailableVehicle();
	}

	public NewClaimLocationPage withTheftVehicleDamageDetails()
	{
		if(data.get("TheftType").equals("VehicleStolen"))
		{
			seleniumCommands.clickbyJS(VEHICLE_THEFT_CSS);
		}
		else if(data.get("TheftType").equals("AudioStolen"))
		{
			seleniumCommands.clickbyJS(VEHICLE_PART_THEFT_CSS);
		}
		return this;
	}

	public NewClaimVehicleDriverPage goToVehicleDriverPage()
	{
		clickNext();
		return new NewClaimVehicleDriverPage();
	}

	public NewClaimDocumentPage goToDocumentPage() {
		clickNext();
		return new NewClaimDocumentPage();
	}

	public AlertHandler cancelClaim() {
		clickCancel();
		return new AlertHandler();
	}

	public PropertyDetailsPage goBackToPropertyDetailsPage() {
		clickPrevious();
		AlertHandler confirmationAlert = new AlertHandler();
		confirmationAlert.closeAlertIfPresent();
		return new PropertyDetailsPage();
	}

	public NewClaimPropertiesSelectionPage jumpDirectlyToPropertySelectionPage() {
		return new WizardNavBar().goToPropertySelectionPage();
	}

	public PropertyDetailsPage jumpDirectlyToPropertyDetailsPage() {
		return new WizardNavBar().goToPropertyDetailsPage();
	}

	//Get Method
	public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}

	//Validation

	public Validation validateCityFieldErrorMessage() {
		logger.info("Validating the Mandatory Error for City Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(CITY_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}

	public Validation areClaimLocationDetailsAreSaved() {
		logger.info("Validating if Claim Location data is saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDLINE1_TXT_CSS), data.get("AddLine1")).shouldBeEqual("Address line1 is not correct");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDLINE2_TXT_CSS), data.get("AddLine2")).shouldBeEqual("Address line2 is not correct");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDLINE3_TXT_CSS), data.get("AddLine3")).shouldBeEqual("Address line3 is not correct");
		new Validation(seleniumCommands.getValueAttributeFromLocator(CITY_TXT_CSS), data.get("City")).shouldBeEqual("City is not correct");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ZIP_TXT_CSS), data.get("ZipCode")).shouldBeEqual("ZipCode line1 is not correct");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS), data.get("State")).shouldBeEqual("State is not correct");
		if (data.get("ClaimSubType").equals("Collision"))
		{
			new Validation(seleniumCommands.getValueAttributeFromLocator(CLAIM_DESC_TXT_CSS), data.get("LOSS_DESC")).shouldBeEqual("Claim Description is not correct");
			new Validation(seleniumCommands.getValueAttributeFromLocator(PROP_DAMAGE_DESC_TXT_CSS), data.get("WithPropDamage")).shouldBeEqual("Property Damage is not correct");
		}
		else if (data.get("ClaimSubType").equals("Theft"))
		{
			new Validation(seleniumCommands.getValueAttributeFromLocator(CLAIM_DESC_TXT_CSS), data.get("LOSS_DESC")).shouldBeEqual("Claim Description is not correct");
			new Validation(seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_ID), data.get("VehicleDamaged")).shouldBeEqual("Vehicle Damaged is not correct");
			String stolenItem = null;
			if(new Boolean(seleniumCommands.getAttributeValueAtLocator(VEHICLE_THEFT_RDBTN_ID, "aria-checked")))
			{
				new Validation(VEHICLE_THEFT_RDBTN_ID.findElement(By.xpath("./following-sibling::label")).getText(), DataConstant.ENTIRE_VEH_STOLEN_LABEL).shouldBeEqual("Entire vehicle stolen button is not selected");
			}
			else
			{
				new Validation(VEHICLE_PART_THEFT_RDBTN_ID.findElement(By.xpath("./following-sibling::label")).getText(), DataConstant.AUDIO_EQUIP_STOLEN_LABEL).shouldBeEqual("Vehicle audio equipment stolen button is not selected");
			}
		} else if (data.get("ClaimSubType").equals("Glass"))
		{
			new Validation(seleniumCommands.getValueAttributeFromLocator(CLAIM_DESC_TXT_CSS), data.get("LOSS_DESC")).shouldBeEqual("Claim Description is not correct");
			new Validation(seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_ID), data.get("VehicleDamaged")).shouldBeEqual("Vehicle Damaged is not correct");
		}
		return new Validation(true);
	}

	public Validation validatePolicyAddressErrorMessage() {
		logger.info("Validating the Mandatory Error for Policy Address selection");
		return new Validation(seleniumCommands.getTextAtLocator(ERROR_TEXT), DataConstant.NO_POLICY_ADDRESS_SELECTED_ERROR);
	}
}
