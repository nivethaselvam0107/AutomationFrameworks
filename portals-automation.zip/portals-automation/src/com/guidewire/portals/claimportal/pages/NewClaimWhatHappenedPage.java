package com.guidewire.portals.claimportal.pages;

import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.common.selenium.Gender;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Select;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class NewClaimWhatHappenedPage extends ClaimWizardPage {

	@FindBy(css = "[src*='collision']")
	WebElement COLLISION_TILE_CSS;

	@FindBy(css = "[src*='theft']")
	WebElement THEFT_TILE_CSS;

	@FindBy(css = "[src*='glass']")
	WebElement GLASS_TILE_CSS;

	@FindBy(css = "[src*='other']")
	WebElement OTHER_TILE_CSS;
	
	@FindBy(css = "//*[@class='gw-pa-fnol-damage-type']/div[contains(@class,' gw-medium-blue')]/span")
	WebElement SELECTED_TILE_CSS;

	@FindBy(css = "[gw-pl-select='claimVm.lossCause.value']")
	WebElement COLLISION_TYPE_CSS;

	@FindBy(css = "div[class='gw-ho-fnol-damage-type'] [image*='fire']")
	WebElement FIRE_TILE_CSS;

	@FindBy(css = "div[class='gw-ho-fnol-damage-type'] [image*='water']")
	WebElement WATER_TILE_CSS;

	@FindBy(css = "div[class='gw-ho-fnol-damage-type'] [image*='criminal_damage']")
	WebElement CRIME_TILE_CSS;

	@FindBy(css = "div[class='gw-ho-fnol-damage-type'] [image*='other']")
	WebElement OTHER_HO_TILE_CSS;
	
	@FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;

	@FindBy(css = "[name='collisionDetailsForm']")
	WebElement FORM;

	@FindBy(css = "[model='claimVm.lossCause'] select")
	WebElement LOSS_CAUSE_SELECT_CSS;

	@FindBy(id = "lossDescription")
	WebElement LOSS_DESC_TEXTAREA_ID;

	@FindBy(id = "fixedPropertyIncident")
	WebElement DAMAGE_DESC_TEXTAREA_ID;

	@FindBy(css = "[model='claimVm.lossCause'] select")
	WebElement LOSS_CAUSE_DROPDOWN;

	@FindBy(xpath = "//*[@model='contact.firstName']//input")
	WebElement EMPLOYEE_F_NAME_XPATH;

	@FindBy(xpath = "//*[@model='claimVm.lobs.workersComp.injuryIncident.injured.gender']//select")
	WebElement EMPLOYEE_GENDER_SELECT;

	@FindBy(css = "[ng-model='claimVm.lobs.workersComp.injuryIncident.injured.dateOfBirth.value'] .datetimepicker-wrapper input")
	WebElement EMPLOYEE_DOB_CSS;

	@FindBy(xpath = "//*[@model='contact.lastName']//input")
	WebElement EMPLOYEE_L_NAME_XPATH;

	@FindBy(css = "[model='claimVm.lobs.workersComp.injuryIncident.injured.cellNumber'] input")
	WebElement EMPLOYEE_PHONE_CSS;

	@FindBy(css = "[model='claimVm.lobs.workersComp.injuryIncident.injured.taxID'] input")
	WebElement EMPLOYEE_SSN_CSS;

	@FindBy(xpath = "//*[@model='address.city']//input")
	WebElement EMPLOYEE_CITY_XPATH;

	@FindBy(xpath = "//*[@model='address.postalCode']//input")
	WebElement EMPLOYEE_ZIP_XPATH;

	@FindBy(xpath = "//*[@model='address.state']//select")
	WebElement EMPLOYEE_STATE_XPATH;

	@FindBy(css = "[ng-model='claimVm.lobs.commercialProperty.dateOfNotice.value'] .datetimepicker-wrapper input")
	WebElement NOTICE_DOB_CSS;

	public final String SUBMIT_AS_REPORT_SELECTOR_CSS = "[model='claimVm.lobs.workersComp.incidentReport'] input[class*='%s']";
	private String ADDRESS_LINE_SELECTOR_CSS = "[model='address.addressLine%s'] input";

	public NewClaimWhatHappenedPage() {
		super();
		this.REQUIRED_FIELDS = new String[]{"address.city", "address.state"};
	}

	public NewClaimWhatHappenedPage selectPAClaimType() {
		seleniumCommands.waitForElementToBeVisible(By.className("gw-pa-fnol-damage-type"));
		if (data.get("ClaimSubType").equals("Collision")) {
			seleniumCommands.waitForElementToBeVisible(COLLISION_TILE_CSS);
			seleniumCommands.clickbyJS(COLLISION_TILE_CSS);
		} else if (data.get("ClaimSubType").equals("Theft")) {
			seleniumCommands.waitForElementToBeVisible(THEFT_TILE_CSS);
			seleniumCommands.clickbyJS(THEFT_TILE_CSS);
		} else if (data.get("ClaimSubType").equals("Glass")) {
			seleniumCommands.waitForElementToBeVisible(GLASS_TILE_CSS);
			seleniumCommands.clickbyJS(GLASS_TILE_CSS);
		} else if (data.get("ClaimSubType").equals("Other")) {
			seleniumCommands.waitForElementToBeVisible(OTHER_TILE_CSS);
			seleniumCommands.clickbyJS(OTHER_TILE_CSS);
		}

		return this;
	}

	public NewClaimWhatHappenedPage selectHOClaimType() {
		seleniumCommands.waitForElementToBeVisible(By.className("gw-ho-fnol-damage-type"));
		if (data.get("ClaimSubType").equals("Other")) {
			seleniumCommands.waitForElementToBeVisible(OTHER_HO_TILE_CSS);
			seleniumCommands.clickbyJS(OTHER_HO_TILE_CSS);
		}

		else if (data.get("ClaimSubType").equals("Fire")) {
			seleniumCommands.waitForElementToBeVisible(FIRE_TILE_CSS);
			seleniumCommands.clickbyJS(FIRE_TILE_CSS);
		}

		else if (data.get("ClaimSubType").equals("Water")) {
			seleniumCommands.waitForElementToBeVisible(WATER_TILE_CSS);
			seleniumCommands.clickbyJS(WATER_TILE_CSS);
		}

		else if (data.get("ClaimSubType").equals("Crime")) {
			seleniumCommands.waitForElementToBeVisible(CRIME_TILE_CSS);
			seleniumCommands.clickbyJS(CRIME_TILE_CSS);
		}
		return this;
	}

	public NewClaimWhatHappenedPage selectClaimType() {

		seleniumCommands.waitForElementToBeVisible(LOSS_CAUSE_SELECT_CSS);
		Select lossCauseSelect = new Select(LOSS_CAUSE_SELECT_CSS);
		lossCauseSelect.setValue(data.get("LOSS_CAUSE"));

		return this;
	}

	public NewClaimWhatHappenedPage selectGeneralClaimType() {
		return selectClaimType();
	}

	public NewClaimWhatHappenedPage selectWCClaimType() {
		return selectClaimType();
	}

	private NewClaimWhatHappenedPage selectLossDesc() {
		seleniumCommands.type(LOSS_DESC_TEXTAREA_ID, data.get("LossDescription"));
		return this;
	}

	public NewClaimWhatHappenedPage submitAsReportOnly(boolean asReport) {
		selectYesNo(asReport, SUBMIT_AS_REPORT_SELECTOR_CSS);
		return this;
	}

	public NewClaimWhatHappenedPage setGeneralLossDesc() {
		return selectLossDesc();
	}

	public NewClaimWhatHappenedPage setWCLossDesc() {
		return selectLossDesc();
	}

	public NewClaimWhatHappenedPage setNotificationDateInThePast() {
		DateTime today = new DateTime();
		today = today.minusDays(7);
		return this.setNotificationDate(today);
	}

	public NewClaimWhatHappenedPage setNotificationDate(DateTime date) {
		fillDatePicker(date);
		return this;
	}

	public NewClaimWhatHappenedPage setInjuredEmployeeName(){
		data.put("EmployeeFName", "Dharmesh");
		data.put("EmployeeLName", "Gangwar");
		seleniumCommands.type(EMPLOYEE_F_NAME_XPATH, data.get("EmployeeFName"));
		seleniumCommands.type(EMPLOYEE_L_NAME_XPATH, data.get("EmployeeLName"));
		return this;
	}

	public NewClaimWhatHappenedPage setInjuredEmployeeDateOfBirth(){
		String date = DateUtil.getPastDateUsingDays();
		fillDatePicker(date, EMPLOYEE_DOB_CSS);
		logger.info("Setting injured employee birth date [" + date + "]");
		return this;
	}
	public NewClaimWhatHappenedPage setInjuredEmployeeDateOfBirth(DateTime date){
		fillDatePicker(date, EMPLOYEE_DOB_CSS);
		return this;
	}

	public NewClaimWhatHappenedPage setInjuredEmployeeGender(){
		String gender = data.get("EmployeeGender");
		if (gender == null || gender.isEmpty()) {
			setGender(true);
		} else {
			setGender(gender.toLowerCase().startsWith("f"));
		}
		return this;
	}
	private void setGender(boolean female) {
		Select genderSelect = new Select(EMPLOYEE_GENDER_SELECT);
		if (female) {
			genderSelect.setValue(Gender.FEMALE.toString());
		} else {
			genderSelect.setValue(Gender.MALE.toString());
		}
	}

	public NewClaimWhatHappenedPage setInjuredEmployeeAddress(){
		for (int i = 1; i < 4; i++) {
			if (data.containsKey("AddressLine" + i)) {
				seleniumCommands.type(
						seleniumCommands.findElement(By.cssSelector(String.format(ADDRESS_LINE_SELECTOR_CSS, i)))
						, data.get("AddressLine" + i));
			}
		}

		seleniumCommands.type(EMPLOYEE_CITY_XPATH, data.get("City"));
		seleniumCommands.type(EMPLOYEE_ZIP_XPATH, data.get("Zip"));
		Select stateSelect = new Select(EMPLOYEE_STATE_XPATH);
		stateSelect.setValue(data.get("State"));
		return this;
	}

	public NewClaimWhatHappenedPage setInjuredEmployeePhone(){
		if (data.containsKey("InjuredEmployeePhone")) {
			seleniumCommands.type(EMPLOYEE_PHONE_CSS, data.get("InjuredEmployeePhone"));
		}
		return this;
	}

	public NewClaimWhatHappenedPage setInjuredEmployeeSSN(){
		if (data.containsKey("InjuredEmployeeSSN")) {
			seleniumCommands.type(EMPLOYEE_SSN_CSS, data.get("InjuredEmployeeSSN"));
		}
		return this;
	}

	public NewClaimWhatHappenedPage setGeneralDamageDesc() {
		seleniumCommands.type(DAMAGE_DESC_TEXTAREA_ID, data.get("DamageDescription"));
		return this;
	}

	public NewClaimWhatHappenedPage selectCollisionClaimType() {
		seleniumCommands.selectDropDownValueByText(COLLISION_TYPE_CSS, data.get("ClaimTypeCollision"));
		return this;
	}

	public NewClaimWhatHappenedPage selectDefaultCollisionClaimType() {
		ThreadLocalObject.getData().putIfAbsent("ClaimTypeCollision", "Collision with motor vehicle");
		return this.selectCollisionClaimType();
	}

	public NewClaimLocationPage goNext() {
		clickNext();
		return new NewClaimLocationPage();
	}
	
	public CP_ClaimListPage cancelClaim() {
		clickCancel();
		new AlertHandler().closeClaimSubmissionAlert();
		return new CP_ClaimListPage();
	}

	public ContactUSPage goToContactUsPage() {
		clickNext();
		return new ContactUSPage();
	}

	public NewFireClaimDetails goToFireDamageDetailsPage() {
		clickNext();
		return new NewFireClaimDetails();
	}

	public NewGeneralClaimDetails goToDetailsPage() {
		clickNext();
		return new NewGeneralClaimDetails();
	}

	public NewGeneralClaimDetails goToGeneralDetailsPage() {
		return goToDetailsPage();
	}

	public NewInjuryClaimDetails goToWCInjuryDetailsPage() {
		clickNext();
		return new NewInjuryClaimDetails();
	}

	public NewClaimWaterDetails goToWaterDamageDetailsPage() {
		clickNext();
		return new NewClaimWaterDetails();
	}

	public NewClaimCrimeDetails goToCrimeDetailsPage() {
		clickNext();
		return new NewClaimCrimeDetails();
	}
	
	//Get Method
	
	public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}

	// Validation
	public Validation areClaimTypeDetailsAreSaved() {
		logger.info("Validating if Claim type data is saved");
		new Validation(seleniumCommands.getTextAtLocator(SELECTED_TILE_CSS), data.get("ClaimSubType"));
		if (data.get("ClaimSubType").equals("Collision")) {
			new Validation(seleniumCommands.getValueAttributeFromLocator(COLLISION_TYPE_CSS), data.get("LOSS_CAUSE"));
		}
		return new Validation(true);
	}

	public Validation validateLossCauseFieldErrorMessage() {
		logger.info("Validating the Mandatory Error for Loss Cause Field");
		return new Validation(seleniumCommands.getErrorMessageForDropdown(LOSS_CAUSE_DROPDOWN), DataConstant.MANDATORY_ERROR_MSG);
	}

	// Commercial Property LOB
	public NewClaimWhatHappenedPage selectLossCause() {
		if (data.get("LOSS_CAUSE") == null) {
			data.put("LOSS_CAUSE", "Fire");
		}
		seleniumCommands.waitForElementToBeVisible(LOSS_CAUSE_SELECT_CSS);
		Select lossCauseSelect = new Select(LOSS_CAUSE_SELECT_CSS);
		lossCauseSelect.setValue(data.get("LOSS_CAUSE"));

		return this;
	}

	public NewClaimWhatHappenedPage setNoticeDate(){
		String date = DateUtil.getPastDateUsingDays();
		date = date + " 02:30 PM";
		fillDatePicker(date, NOTICE_DOB_CSS);
		logger.info("Setting notice date [" + date + "]");
		return this;
	}

	public NewClaimPropertiesSelectionPage goToProperties() {
		clickNext();
		return new NewClaimPropertiesSelectionPage();
	}

}
