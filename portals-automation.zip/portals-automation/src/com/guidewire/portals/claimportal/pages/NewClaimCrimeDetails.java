package com.guidewire.portals.claimportal.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.testNG.Validation;

public class NewClaimCrimeDetails extends ClaimWizardPage {

	@FindBy(css = "label[for='burglary']")
	WebElement CRIME_BURGLARY_RBTN_CSS;
	
	@FindBy(css = "label[for='vandalism']")
	WebElement CRIME_VANDALISM_RBTN_CSS;
	
	@FindBy(css = "label[for='riots']")
	WebElement CRIME_RIOT_RBTN_CSS;
	
	@FindBy(css = "[name='OtherCrimeDetails']")
	WebElement CRIME_DESCRIPTION_TXT_NAME;

	
	public NewClaimCrimeDetails() {
		super();
	}
	
	public NewClaimCrimeDetails setCrimeDetails() {
		seleniumCommands.type(CRIME_DESCRIPTION_TXT_NAME, data.get("LOSS_DESC"));
		withCrimeType();
		return this;
	}

	public NewClaimCrimeDetails withCrimeType() {
		if(data.get("CrimeDamageType").equals("Burglary"))
		{
			seleniumCommands.clickbyJS(CRIME_BURGLARY_RBTN_CSS);
		}
		else if(data.get("CrimeDamageType").equals("Vandalism"))
		{
			seleniumCommands.clickbyJS(CRIME_VANDALISM_RBTN_CSS);
		}
		else if(data.get("CrimeDamageType").equals("Riot"))
		{
			seleniumCommands.clickbyJS(CRIME_RIOT_RBTN_CSS);
		}
		return this;
	}
	
	public NewClaimCrimeDetails withCrimeType(String crime) {
		if(data.get("CrimeDamageType").equals(crime))
		{
			seleniumCommands.clickbyJS(CRIME_BURGLARY_RBTN_CSS);
		}
		else if(data.get("CrimeDamageType").equals(crime))
		{
			seleniumCommands.clickbyJS(CRIME_VANDALISM_RBTN_CSS);
		}
		else if(data.get("CrimeDamageType").equals(crime))
		{
			seleniumCommands.clickbyJS(CRIME_RIOT_RBTN_CSS);
		}
		return this;
	}
	
	public NewClaimDocumentPage goNext() {
		clickNext();
		return new NewClaimDocumentPage();
	}

	// Get Method
	public String getCrimeDescriptionText() {
		seleniumCommands.waitForElementToBeEnabled(CRIME_DESCRIPTION_TXT_NAME);
		return seleniumCommands.getValueAttributeFromLocator(CRIME_DESCRIPTION_TXT_NAME);
	}

	//Validations

	public Validation validateExistingCrimeDescription() {
		logger.info("Validating the entered Crime Description.");
		return new Validation(this.getCrimeDescriptionText(), data.get("LOSS_DESC"));
	}

}
