package com.guidewire.portals.claimportal.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NewFireClaimDetails extends ClaimWizardPage {

	@FindBy(css = "[label*='What caused the fire'] textarea")
	WebElement FIRE_CAUSE_TXT_NAME;
	
	@FindBy(css = "[name='HowWasFireDiscovered']")
	WebElement FIRE_DISCOVERY_TXT_NAME;
	
	@FindBy(css = "[name='OtherFireDetails']")
	WebElement FIRE_DESCRIPTION_TXT_NAME;
	
	@FindBy(css = "[for='homeHabitable-yes']")
	WebElement HOM_HABITABLE_RBTN_YES_CSS;
	
	@FindBy(css = "[for='homeHabitable-no']")
	WebElement HOM_HABITABLE_RBTN_NO_CSS;
	
	@FindBy(css = "[for='homeHabitable-yes']")
	WebElement HOM_HABITABLE_RBTN_NTSURE_CSS;
	
	@FindBy(css = "[for='homeSecure-yeah']")
	WebElement HOM_SECURE_RBTN_YES_CSS;
	
	@FindBy(css = "[for='homeSecure-nah']")
	WebElement HOM_SECURE_RBTN_NO_CSS;
	
	@FindBy(css = "[for='homeSecure-dunno']")
	WebElement HOM_SECURE_RBTN_NTSURE_CSS;
	
	public NewFireClaimDetails() {
		super();
	}
	
	public NewFireClaimDetails setFireDetails() {
		seleniumCommands.type(FIRE_CAUSE_TXT_NAME, data.get("FireCause"));
		seleniumCommands.type(FIRE_DISCOVERY_TXT_NAME, data.get("FireDiscovery"));
		seleniumCommands.type(FIRE_DESCRIPTION_TXT_NAME, data.get("LOSS_DESC"));
		
		return this;
	}
	
	public NewFireClaimDetails withHomeHabitableValue() {
		if(data.get("HomeHabitable").equals("Yes"))
		{
			seleniumCommands.clickbyJS(HOM_HABITABLE_RBTN_YES_CSS);
		}
		else if(data.get("HomeHabitable").equals("No"))
		{
			seleniumCommands.clickbyJS(HOM_HABITABLE_RBTN_NO_CSS);
		}
		else if(data.get("HomeHabitable").equals("NotSure"))
		{
			seleniumCommands.clickbyJS(HOM_HABITABLE_RBTN_NTSURE_CSS);
		}
		return this;
	}
	
	public NewFireClaimDetails withHomeSecureValue() {
		if(data.get("HomeSecure").equals("Yes"))
		{
			seleniumCommands.clickbyJS(HOM_SECURE_RBTN_YES_CSS);
		}
		else if(data.get("HomeSecure").equals("No"))
		{
			seleniumCommands.clickbyJS(HOM_SECURE_RBTN_NO_CSS);
		}
		else if(data.get("HomeSecure").equals("NotSure"))
		{
			seleniumCommands.clickbyJS(HOM_SECURE_RBTN_NTSURE_CSS);
		}
		return this;
	}
	
	public NewClaimDocumentPage goNext() {
		clickNext();
		return new NewClaimDocumentPage();
	}

}
