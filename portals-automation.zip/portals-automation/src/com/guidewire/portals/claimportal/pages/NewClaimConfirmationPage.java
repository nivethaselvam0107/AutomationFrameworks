package com.guidewire.portals.claimportal.pages;
import java.util.HashMap;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class NewClaimConfirmationPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "div[ng-show='confirmedClaimId']")
	WebElement POLICY_CONFIRMATION_MSG_VALUE_XPATH;

	@FindBy(css = "[ng-click='printConfirmation()']")
	WebElement PRINT_CONFIRMATION_BUTTON_CSS;

	@FindBy(css = "[ng-click='gotBackToHomeState()']")
	WebElement BACK_TO_HOME_BUTTON_CSS;

	@FindBy(css = "[href*='/home']")
	WebElement HOME_BUTTON_CSS;

	@FindBy(xpath = "//div[@ng-show='confirmedClaimId']")
	WebElement REFERENCE_NUMBER;

	public NewClaimConfirmationPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		seleniumCommands.waitForElementToBeVisible(PRINT_CONFIRMATION_BUTTON_CSS);
	}

	public String getClaimNumber() {
		System.out.println(seleniumCommands.getTextAtLocator(POLICY_CONFIRMATION_MSG_VALUE_XPATH).split(" ")[3].trim());
		return seleniumCommands.getTextAtLocator(POLICY_CONFIRMATION_MSG_VALUE_XPATH).split(" ")[3].trim();
	}

	public AccountSummaryPage goToAccountSummaryPage() {
		seleniumCommands.click(BACK_TO_HOME_BUTTON_CSS);
		return new AccountSummaryPage();
	}

	public AccountSummary goToAccountSummary() {
		seleniumCommands.click(BACK_TO_HOME_BUTTON_CSS);
		return new AccountSummary();
	}

	public CP_ClaimListPage clickGoHomeButton() {
		seleniumCommands.click(BACK_TO_HOME_BUTTON_CSS);
		return new CP_ClaimListPage();
	}

	public PolicySummary goToPolicySummaryPage() {
		seleniumCommands.click(BACK_TO_HOME_BUTTON_CSS);
		return new PolicySummary();
	}

	public AgentDashboard goToDashboard() {
		seleniumCommands.clickbyJS(HOME_BUTTON_CSS);
		return new AgentDashboard();
	}

	public Validation validateReferenceNumberFormat(){
		String referenceNumber = REFERENCE_NUMBER.getText().replace("Claim reference number ", "");
		return new Validation( referenceNumber.matches("\\d{3}-\\d{2}-\\d{6}") ) ;
	}

}
