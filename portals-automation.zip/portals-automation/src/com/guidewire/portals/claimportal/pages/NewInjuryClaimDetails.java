package com.guidewire.portals.claimportal.pages;

import com.guidewire.widgetcomponents.Select;
import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NewInjuryClaimDetails extends ClaimWizardPage {

	@FindBy(css = "[model='$ctrl.workersComp.injuryIncident.detailedInjuryType'] select")
	WebElement INJURY_TYPE_SELECT_CSS;

	@FindBy(css = "[model='$ctrl.workersComp.injuryIncident.description'] textarea")
	WebElement INJURY_DESC_TEXTAREA_CSS;

	private static final String DEATH_REPORT_RBTN_SELECTOR_CSS = "[model='$ctrl.workersComp.deathReport'] input[class*='%s']";
	By DEATH_REPORT_RBTN_CSS = By.cssSelector("[model='$ctrl.workersComp.deathReport']");
	private static final String LOST_TIME_FROM_WORK_RBTN_CSS = "[model='$ctrl.workersComp.timeLossReport'] input[class*='%s']";
	private static final String INJURY_IN_COURSE_OF_EMPLOYMENT_RBTN_CSS = "[model='$ctrl.workersComp.employmentInjury'] input[class*='%s']";
	private static final String MEDICAL_TREATMENT_REQUIRED_RBTN_CSS = "[model='$ctrl.workersComp.medicalReport'] input[class*='%s']";

	@FindBy(css = "button[ng-click='addBodyPartDetails()']")
	WebElement BODY_INJURIES_AREA_ADD_BTN_CSS;

	private static final String  BODY_INJURIES_AREA_OF_BODY_SELECT_XPATH = "(//*[@model='bodyPart.primaryBodyPart']//select)[%s]";

	private static final By  BODY_INJURIES_BODY_PART_SELECT_XPATH = By.xpath("(//*[@model='bodyPart.detailedBodyPart']//select)[%s]");
	private static final By  BODY_INJURIES_BODY_PART_DESC_SELECT_XPATH = By.xpath("(//*[@model='bodyPart.detailedBodyPartDesc']//select)[%s]");
	private static final By  BODY_INJURIES_SIDE_SELECT_XPATH = By.xpath("(//*[@model='bodyPart.sideOfBody']//select)[%s]");
	private static final By  BODY_INJURIES_PPD_TXT_XPATH = By.xpath("(//*[@model='bodyPart.impairmentPercentage']//input)[%s]");

	@FindBy(css = "[model='contact.firstName'] input")
	WebElement MEDICAL_TREATMENT_DOCTOR_FIRST_NAME_TXT_CSS;

	@FindBy(css = "[model='contact.lastName'] input")
	WebElement MEDICAL_TREATMENT_DOCTOR_LAST_NAME_TXT_CSS;

	public NewInjuryClaimDetails() {
		super();
		seleniumCommands.waitForLoaderToDisappearFromPage();
	}

	public NewClaimLocationPage goNext() {
		clickNext();
		return new NewClaimLocationPage();
	}

	public NewClaimWhatHappenedPage goPrevious() {
		clickPrevious();
		return new NewClaimWhatHappenedPage();
	}

	public NewInjuryClaimDetails selectInjuryType() {
		seleniumCommands.waitForElementToBeVisible(INJURY_TYPE_SELECT_CSS);
		Select injuryTypeSelect = new Select(INJURY_TYPE_SELECT_CSS);
		injuryTypeSelect.setValue(data.get("InjuryType"));

		return this;
	}

	public NewInjuryClaimDetails setInjuryDescription() {
		if (data.containsKey("InjuryDesc")) {
			seleniumCommands.type(INJURY_DESC_TEXTAREA_CSS, data.get("InjuryDesc"));
		}
		return this;
	}

	public NewInjuryClaimDetails setDeathReport(boolean isDeathReport) {
		selectYesNo(isDeathReport, DEATH_REPORT_RBTN_SELECTOR_CSS);
		return this;
	}

	public NewInjuryClaimDetails setLostTimeFromWork(boolean lostTime) {
		selectYesNo(lostTime, LOST_TIME_FROM_WORK_RBTN_CSS);
		return this;
	}

	public NewInjuryClaimDetails setEmploymentInjury(boolean isEmploymentInjury) {
		selectYesNo(isEmploymentInjury, INJURY_IN_COURSE_OF_EMPLOYMENT_RBTN_CSS);
		return this;
	}

	public NewInjuryClaimDetails setMedicalTreatment(boolean isMedicalTreatment) {
		selectYesNo(isMedicalTreatment, MEDICAL_TREATMENT_REQUIRED_RBTN_CSS);
		return this;
	}

	public NewInjuryClaimDetails setDoctorFName() {
		seleniumCommands.type(MEDICAL_TREATMENT_DOCTOR_FIRST_NAME_TXT_CSS, data.get("DoctorFName"));
		return this;
	}

	public NewInjuryClaimDetails setDoctorLName() {
		seleniumCommands.type(MEDICAL_TREATMENT_DOCTOR_LAST_NAME_TXT_CSS, data.get("DoctorLName"));
		return this;
	}

	public NewInjuryClaimDetails setMedicalExaminationDateInThePast() {
		DateTime today = new DateTime();
		today = today.minusDays(7);
		return this.setMedicalExaminationDate(today);
	}

	public NewInjuryClaimDetails setMedicalExaminationDate(DateTime date) {
		fillDatePicker(date);
		return this;
	}


	public boolean isResultInDeathNotPresent() {
		return seleniumCommands.isElementNotPresent(DEATH_REPORT_RBTN_CSS);
	}
}
