package com.guidewire.portals.claimportal.pages;

import com.guidewire.capabilities.fnol.data.USStatesAbbreviations;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.form.RadioButton;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class NewGeneralClaimDetails extends ClaimWizardPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "#predefinedAddress")
    WebElement PREDEFINED_ADDRESS_OPTION_CSS;

    @FindBy(css = "#exactAddress")
    WebElement EXACT_ADDRESS_OPTION_CSS;

    @FindBy(css = "#cityOnly")
    WebElement CITY_ONLY_OPTION_CSS;

    @FindBy(css = "[model='address.city'] input")
    WebElement CITY_INPUT_CSS;

    @FindBy(css = "[model='address.state'] select")
    WebElement STATE_SELECT_CSS;

    @FindBy(css = 	"[class='gw-pull-right ng-binding']")
    WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;
    
    By POLICY_ADDRESS_SELECT_CSS = By.cssSelector("[model='lossLocation'] select");

    By CLAIM_ADDRESS_LINE1_CSS = By.cssSelector("[address='lossLocation'] [ng-if*='AddressLine1']");

    By CLAIM_ADDRESS_LINE2_CSS = By.cssSelector("[address='lossLocation'] [ng-if*='AddressLine2']");

    By CLAIM_ADDRESS_LINE3_CSS = By.cssSelector("[address='lossLocation'] [ng-if*='AddressLine3']");

    By CLAIM_ADDRESS_CITY_CSS = By.cssSelector("[model='address.city'] [ng-if*='metatype']");

    By CLAIM_ADDRESS_ZIP_CSS = By.cssSelector("[model='address.postalCode'] [ng-if*='metatype']");

    By CLAIM_ADDRESS_STATE_CSS = By.cssSelector("[model='address.state'] [ng-if*='metatype']");

    public NewGeneralClaimDetails() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public NewClaimDocumentPage goNext() {
        clickNext();
        return new NewClaimDocumentPage();
    }

    public NewGeneralClaimDetails selectPredefinedAddress() {
        logger.info("Setting Location Type to the predefined one");
        seleniumCommands.clickbyJS(PREDEFINED_ADDRESS_OPTION_CSS);
        return this;
    }

    public NewGeneralClaimDetails selectExactAddress() {
        logger.info("Setting Location Type to the exact one");
        seleniumCommands.clickbyJS(EXACT_ADDRESS_OPTION_CSS);
        return this;
    }

    public NewGeneralClaimDetails selectCityOnlyAddress() {
        logger.info("Setting Location Type to the city only one");
        seleniumCommands.clickbyJS(CITY_ONLY_OPTION_CSS);
        return this;
    }

    public NewGeneralClaimDetails getAddress() {
        seleniumCommands.waitForElementToBeVisible(CLAIM_ADDRESS_LINE1_CSS);
        String address=null;
        if (ThreadLocalObject.getData().get("ClaimType").equals("InlandMarine")){
            address = seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_LINE1_CSS) + ", " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_CITY_CSS) + ", CA " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_ZIP_CSS);
        }
        else {
            address = seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_LINE1_CSS) + ", " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_LINE2_CSS) + ", " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_LINE3_CSS) + ", " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_CITY_CSS) + ", CA " + seleniumCommands.getTextAtLocator(CLAIM_ADDRESS_ZIP_CSS);
        }
        ThreadLocalObject.getData().put("LOSS_LOCATION_DISPLAY_NAME", address);
        return this;
    }

    public Validation validateMissingCity() {
        logger.info("Validating the Mandatory Error for City Field");
        return new Validation(seleniumCommands.getErrorMessageForTxtBox(CITY_INPUT_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation validateMissingState() {
        logger.info("Validating the Mandatory Error for State Field");
        return new Validation(seleniumCommands.getErrorMessageForDropdown(STATE_SELECT_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }

    public String getDraftClaimNumber() {
        return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
    }

    public NewGeneralClaimDetails getLossLocationAddressData() {
    	seleniumCommands.waitForElementToBePresent(PREDEFINED_ADDRESS_OPTION_CSS);
    	if(seleniumCommands.isElementPresent(POLICY_ADDRESS_SELECT_CSS)) {
    		seleniumCommands.selectFromDropdownByIndex(POLICY_ADDRESS_SELECT_CSS, 1);
    		seleniumCommands.waitForElementToBeVisible(CLAIM_ADDRESS_LINE1_CSS);
    	}
        HashMap<String, String> data = ThreadLocalObject.getData();
        List<String> address = new ArrayList<>();
        List<By> addressElements = Arrays.asList(
                    CLAIM_ADDRESS_LINE1_CSS,
                    CLAIM_ADDRESS_LINE2_CSS,
                    CLAIM_ADDRESS_LINE3_CSS,
                    CLAIM_ADDRESS_CITY_CSS,
                    CLAIM_ADDRESS_STATE_CSS,
                    CLAIM_ADDRESS_ZIP_CSS
                );

        if (new RadioButton(PREDEFINED_ADDRESS_OPTION_CSS).isSelected()) {
            addressElements.forEach( elSelector -> {
                if (seleniumCommands.isElementPresent(elSelector)) {
                    if (elSelector.equals(CLAIM_ADDRESS_STATE_CSS)) {
                        address.add(USStatesAbbreviations.getStateAbbreviation(seleniumCommands.getTextAtLocator(elSelector)));
                    } else {
                        address.add(seleniumCommands.getTextAtLocator(elSelector));
                    }
                }
            });

            data.put(ClaimData.LOSS_LOCATION_DISPLAY_NAME.getValue(), address.toString());
        }

        return this;
    }
}
