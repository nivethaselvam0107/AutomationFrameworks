package com.guidewire.portals.claimportal.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;

public class OpenAMSignInPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	final static String CLAIMS_TABLE_CSS = "[class='gw-claimsTable gw-table ng-scope'] tbody tr";
	String suite = "";

	@FindBy(xpath = "//input[@type='text']")
	WebElement USERNAME_XPATH;

	@FindBy(xpath = "//input[@type='password']")
	WebElement PWD_XPATH;

	@FindBy(xpath = "//input[@value][@class='button' or @type='button']")
	WebElement LOG_IN_BTN_XPATH;

	public OpenAMSignInPage() {

		this.refreshPageObjects();
		this.suite = ThreadLocalObject.getData().get("Suite");
	}

	private void refreshPageObjects() {

		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public Object loginOpenAM() throws Exception {

		String url = ThreadLocalObject.getDriver().getCurrentUrl();

		if (url.contains("openam") || url.contains("apple.com")) {
			this.refreshPageObjects();
			seleniumCommands.waitForElementToBeVisible(USERNAME_XPATH);
			this.fillCredentials();
		}

		if (this.suite.equals("CP-PolicyHolder") || this.suite.equals("CP-Producer")) {
			seleniumCommands.waitForElementToBeVisible(By.cssSelector(CLAIMS_TABLE_CSS));
			return new ClaimListPage();
		}

		return this;
	}

	private void fillCredentials() throws Exception {

		logger.info("Fill openAM credentials");
		if (data.get("USER").contains("${")) {
			logger.error("NO USER SET FOR openAM. Please make sure to add -Duid=userName to execution parameters.");
			throw new Exception("NO USER SET FOR openAM");
		}
		seleniumCommands.type(USERNAME_XPATH, data.get("USER"));
		seleniumCommands.type(PWD_XPATH, data.get("PWD"));
		seleniumCommands.clickbyJS(LOG_IN_BTN_XPATH);
	}
}
