package com.guidewire.portals.claimportal.pages;

import com.guidewire.capabilities.common.dto.PropertyDTO;
import com.guidewire.capabilities.common.interfaces.IPaginationPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class NewClaimPropertiesSelectionPage
        extends ClaimWizardPage
        implements IPaginationPage{

    @FindBy(css = "[ng-hide='explicitErrorMessage'][aria-hidden='false']")
    WebElement ERROR_TEXT;

    private static final By PROPERTIES_TABLE_ROWS_CSS = By.cssSelector("table tbody tr[ng-repeat*='item in filteredRiskUnits']");
    private static final By ALL_PROPERTIES_COUNT = By.cssSelector("span[class*='PaginationNavigation-hashed__label']");

    private static final By ROW_CHECKBOX = By.cssSelector("input[type='checkbox']");
    private static final By ROW_ADDRESS = By.cssSelector("td[attribute='address']");
    private static final By ROW_LOCATION_NUMBER = By.cssSelector("td[attribute='locationNumber']");
    private static final By ROW_BUILDING_DETAILS = By.cssSelector("td[attribute='description']");
    private static final By ROW_BUILDING_NUMBER = By.cssSelector("td[attribute='buildingNumber']");

    private static final By SEARCH_INPUT = By.cssSelector("input[ng-model='$ctrl.queryString']");

    private static final By RIBBON_ACCORDION_TRIGGER = By.cssSelector(".gw-accordion-chevron");
    private static final By RIBBON_ENTRY = By.cssSelector("[ng-repeat='item in $ctrl.selectedRiskUnits | orderBy:predicate:descending']");

    public NewClaimPropertiesSelectionPage(){
        super();
    }

    public PropertyDetailsPage goNext() {
        clickNext();
        return new PropertyDetailsPage();
    }

    public int countAllProperties() {
        seleniumCommands.waitForElementToBeClickable(PROPERTIES_TABLE_ROWS_CSS);
        if (seleniumCommands.isElementClickable(ALL_PROPERTIES_COUNT)) {
            String count = seleniumCommands.findElement(ALL_PROPERTIES_COUNT).getText();
            count = count.split(" of ")[1];
            return Integer.parseInt(count);
        } else {
            return seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS).size();
        }
    }

    public int countPropertiesOnPage() {
        seleniumCommands.waitForElementToBeClickable(PROPERTIES_TABLE_ROWS_CSS);
        return seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS).size();
    }

    private List<WebElement> openRibbonAndGetEntries() {
        seleniumCommands.waitForElementToBeVisible(RIBBON_ACCORDION_TRIGGER);

        WebElement ribbonAccordionTrigger = seleniumCommands.findElement(RIBBON_ACCORDION_TRIGGER);
        if(!ribbonAccordionTrigger.getAttribute("class").contains("gw-accordion-chevron_open")) {
            seleniumCommands.clickbyJS(ribbonAccordionTrigger);
        }

        return seleniumCommands.findElements(RIBBON_ENTRY);
    }

    private void selectPropertyRow(final WebElement row, StringBuilder jsonBuilder, boolean comma) {
        PropertyDTO dto = this.parsePropertyFromRow(row);
        seleniumCommands.clickbyJS(row);
        jsonBuilder.append(comma ? "," + dto.toString() : dto.toString());
    }
    private PropertyDTO parsePropertyFromRow(final WebElement row) {
        PropertyDTO dto = new PropertyDTO();
        dto.setLocationNumber(row.findElement(ROW_LOCATION_NUMBER).getText());
        dto.setBuildingNumber(row.findElement(ROW_BUILDING_NUMBER).getText());
        dto.setDescription(row.findElement(ROW_BUILDING_DETAILS).getText());
        dto.setAddress(row.findElement(ROW_ADDRESS).getText());
        return dto;
    }

    public NewClaimPropertiesSelectionPage addProperties(int startIndex, int endIndex) {
        seleniumCommands.waitForElementToBeClickable(PROPERTIES_TABLE_ROWS_CSS);
        StringBuilder json = new StringBuilder();
        int allBuildings = this.countAllProperties();
        int pagination = this.countPropertiesOnPage();

        if (endIndex > allBuildings) {
            endIndex = allBuildings;
        }

        List<WebElement> rows = seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS);
        boolean comma = false;
        for (int i = startIndex; i < endIndex; i++) {
            this.selectPropertyRow(rows.get(i), json, comma);
            comma = true;

            if ((i + 1) % pagination == 0 && this.nextButtonEnabled()) {
                this.nextPage();
                rows.addAll(seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS));
            }
        }

        this.updateSelectedProperties(json);
        return this;
    }

    public NewClaimPropertiesSelectionPage addProperties(int count) {
        return this.addProperties(0, count);
    }

    public NewClaimPropertiesSelectionPage addMoreProperties(int count) {
        Integer selectedPropertiesAmount = openRibbonAndGetEntries().size();
        return this.addProperties(selectedPropertiesAmount, selectedPropertiesAmount + count);
    }

    private void updateSelectedProperties(StringBuilder json) {
        if (data.get("SELECTED_PROPERTIES") != null) {
            PropertyDTO
                    .fromJson(data.get("SELECTED_PROPERTIES"))
                    .forEach(dto -> json.append(", " + dto.toString()));
        }
        data.put("SELECTED_PROPERTIES", "[" + json.toString() + "]");
    }

    public NewClaimPropertiesSelectionPage searchProperty(String searchParam) {
        seleniumCommands.waitForElementToBeEnabled(SEARCH_INPUT);
        seleniumCommands.waitRefreshWithAction(
                PROPERTIES_TABLE_ROWS_CSS,
                SEARCH_INPUT,
                searchParam,
                seleniumCommands::type,
                seleniumCommands::waitForElementToBeEnabled
        );
        return this;
    }

    public Validation verifySelectedProperty(PropertyDTO selectedProperty) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        boolean onPage = false;
        boolean iterate = true;

        while (iterate) {
            if (seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS).size()>1) {
                onPage = seleniumCommands
                        .findElements(PROPERTIES_TABLE_ROWS_CSS)
                        .stream()
                        .filter(el -> parsePropertyFromRow(el).equals(selectedProperty))
                        .findFirst()
                        .isPresent();
            }else
            onPage = seleniumCommands.isElementPresent(PROPERTIES_TABLE_ROWS_CSS);
            if (this.nextButtonEnabled()) {
                this.nextPage();
                iterate = !onPage;
            } else {
                iterate = false;
            }
        }

        return new Validation(onPage);
    }

    // DO NOT COVER NULL_POINTER_EXCEPTION HERE
    public NewClaimPropertiesSelectionPage selectProperties(int count) {
        String properties = data.get("SELECTED_PROPERTIES");
        if (properties == null || properties.isEmpty()) {
            return this.addProperties(count);
        }
        seleniumCommands.waitForElementToBeClickable(PROPERTIES_TABLE_ROWS_CSS);

        List<PropertyDTO> propertyList = PropertyDTO.fromJson(properties);

        for (int i = 0; i < propertyList.size(); i++) {
            PropertyDTO dto = propertyList.get(i);
            boolean found = false;
            WebElement target = null;

            while (!found && nextButtonEnabled()) {
                Stream<WebElement> rows = seleniumCommands.findElements(PROPERTIES_TABLE_ROWS_CSS).stream();
                Optional<WebElement> row = rows.filter(
                        el -> (el.findElement(ROW_BUILDING_NUMBER).getText().equals(dto.getBuildingNumber())
                                && el.findElement(ROW_ADDRESS).getText().equals(dto.getAddress())
                                && el.findElement(ROW_LOCATION_NUMBER).getText().equals(dto.getLocationNumber()))
                ).findFirst();

                if (found = row.isPresent()) {
                    target = row.get();
                }
            }
            seleniumCommands.clickbyJS(target.findElement(ROW_CHECKBOX));
        }

        return this;
    }

    @Override
    public IPaginationPage previousPage() {
        seleniumCommands.waitForElementToBeClickable(PREVIOUS_BUTTON);
        seleniumCommands.waitRefreshWithAction(
                PROPERTIES_TABLE_ROWS_CSS,
                PREVIOUS_BUTTON,
                seleniumCommands::clickbyJS
        );
        return this;
    }
    @Override
    public IPaginationPage nextPage() {
        seleniumCommands.waitForElementToBeClickable(NEXT_BUTTON);
        seleniumCommands.waitRefreshWithAction(
                PROPERTIES_TABLE_ROWS_CSS,
                NEXT_BUTTON,
                seleniumCommands::clickbyJS
        );
        return this;
    }
    @Override
    public boolean previousButtonEnabled() {
        return seleniumCommands
                .findElement(PREVIOUS_BUTTON)
                .getAttribute("disabled") == null;
    }
    @Override
    public boolean nextButtonEnabled() {
        return seleniumCommands
                .findElement(NEXT_BUTTON)
                .getAttribute("disabled") == null;
    }

    public Validation containsAllSelectedProperties() {
        List<WebElement> ribbonEntries = openRibbonAndGetEntries();

        String selectedPropertiesData = data.get("SELECTED_PROPERTIES");
        if (selectedPropertiesData == null || selectedPropertiesData.isEmpty()) {
            return new Validation(false);
        }

        List<PropertyDTO> selectedProperties = PropertyDTO.fromJson(selectedPropertiesData);
        if (selectedProperties == null || selectedPropertiesData.isEmpty()) {
            return new Validation(false);
        }

        return new Validation(ribbonEntries.size() == selectedProperties.size());
    }

    public Validation validatePropertySelectionErrorMessage() {
        logger.info("Validating the Mandatory Error for Buildings selection");
        return new Validation(seleniumCommands.getTextAtLocator(ERROR_TEXT), DataConstant.NO_BUILDING_SELECTED_ERROR);
    }
}
