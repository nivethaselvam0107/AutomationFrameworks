package com.guidewire.portals.claimportal.pages;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.fnol.model.component.WizardNavBar;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Modal;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public abstract class ClaimWizardPage extends WizardNavBar {
    static final DateTimeFormatter DATE_FORMAT = DateTimeFormat.forPattern("MM/dd/yyyy hh:mm aa");
    Logger logger = Logger.getLogger(this.getClass().getName());
    static final By NEXT_BTN = By.cssSelector("[on-click='goToNext()'],[on-click='next()']");
    static final By NEXT_BTN_DISABLED = By.cssSelector("[on-click='goToNext()'][disabled='disabled']");
    static final By PREVIOUS_BTN = By.cssSelector("[on-click='goToPrevious()'],[on-click='previous()'],[ng-click='previous()']");
    static final By CANCEL_BTN = By.cssSelector("[on-click='goToCancel()'],[on-click='cancel()'],[ng-click='cancel()']");
    
    @FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;

    String[] REQUIRED_FIELDS;

    static final String INVALID_INPUT_NEW_ERROR_CLASS = "ng-invalid";
    // DateOfLoss, DateEmployerNotified, DateMedicalTreatment
    static final By FIRST_DATE_INPUT = By.xpath("(//div[@class[contains(.,'datetimepicker-wrapper')]]/input)");

    public ClaimWizardPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public ViewModelForm getForm() {
        return null;
    }

    public void clickNext() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.clickButton(NEXT_BTN);
    }

    public void clickPrevious() {
        this.clickButton(PREVIOUS_BTN);
        if(seleniumCommands.isElementPresent(By.cssSelector("[class*='gw-modal'] p")))
            new Modal().confirm();
    }

    public void clickCancel() {
        this.clickButton(CANCEL_BTN);
    }

    private void clickButton(By locator) {
        seleniumCommands.waitForElementToBeClickable(locator);
        seleniumCommands.waitForElementToBeEnabled(locator);
        if (browserType.equals(BrowserType.IPHONE6) || browserType.equals(BrowserType.IPHONE6S)) {
            seleniumCommands.click(locator);
        } else {
            seleniumCommands.clickbyJS(locator);
        }
    }

    public Validation verifyRequiredFieldsErrorDisplayed() {
        boolean allDisplayed;
        List<String> requiredFields = Arrays.asList(REQUIRED_FIELDS);
        ViewModelForm form = getForm();
        List<ViewModelInput> displayedRequiredFields = form.getAllRequiredInputs();
        allDisplayed = displayedRequiredFields.size() == REQUIRED_FIELDS.length;
        if (allDisplayed) {
            allDisplayed = displayedRequiredFields.stream().allMatch(
                    field -> requiredFields.contains(field.getModel()) && field.isShowingError());
        }

        return new Validation(allDisplayed);
    }

    public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}

    void fillDatePicker(DateTime date) {
        fillDatePicker(DATE_FORMAT.print(date));
    }
    void fillDatePicker(DateTime date, WebElement element) {
        fillDatePicker(DATE_FORMAT.print(date), element);
    }

    void fillDatePicker(String date) {
        seleniumCommands.type(FIRST_DATE_INPUT, date);
        seleniumCommands.click(FIRST_DATE_INPUT);
    }

    void fillDatePicker(String date, WebElement element) {
        seleniumCommands.type(element, date);
        seleniumCommands.click(element);
    }

    private void cancelWizardPopup() {
        clickCancel();
        new AlertHandler().closeSubmissionAlert();
    }

    public CP_ClaimListPage cancelWizardCP() {
        this.cancelWizardPopup();
        return new CP_ClaimListPage();
    }

    public AMP_ClaimListPage cancelWizardAMP() {
        this.cancelWizardPopup();
        return new AMP_ClaimListPage();
    }

    public GPA_ClaimListPage cancelWizardGPA() {
        this.cancelWizardPopup();
        return new GPA_ClaimListPage();
    }

    private By getCssSelector(String selector, String property) {
        String finalSelector = String.format(selector, property);
        return By.cssSelector(finalSelector);
    }

    public void selectYesNo(boolean yesNo, String cssSelector) {
        if (yesNo) {
            seleniumCommands.clickbyJS(getCssSelector(cssSelector, "gw-first"));
        } else {
            seleniumCommands.clickbyJS(getCssSelector(cssSelector, "gw-second"));
        }
    }

    public void selectYesNo(boolean yesNo, WebElement element) {
        if (yesNo) {
            seleniumCommands.clickbyJS(element.findElement(By.cssSelector(".gw-first")));
        } else {
            seleniumCommands.clickbyJS(element.findElement(By.cssSelector(".gw-second")));
        }
    }
}
