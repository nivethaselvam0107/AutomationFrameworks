package com.guidewire.portals.claimportal.pages;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.CarPart;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class NewClaimVehicleDriverPage extends ClaimWizardPage {

	@FindBy(css = "select[ng-model*='vehicleIncident'][name='Vehicle']")
	WebElement VEHICLE_DROP_CSS;

	@FindBy(css = "[ng-model='vehicleIncident.driver.value']")
	WebElement DRIVER_DROP_CSS;

	@FindBy(css = "[model='vehicleIncident.safeToDrive'] label[class=gw-second]")
	WebElement SAFE_TO_DRIVE_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.safeToDrive'] label[class=gw-first]")
	WebElement SAFE_TO_DRIVE_RBTN_YES_CSS;
	
	@FindBy(css = "[ng-model='vehicleIncident.safeToDrive.value'][ng-value='true']")
	WebElement SAFE_TO_DRIVE_RBTN_VALUE_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.airbagsDeployed'] label[class=gw-second]")
	WebElement AIRBAG_DEPLOYED_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.airbagsDeployed'] label[class=gw-first]")
	WebElement AIRBAG_DEPLOYED_RBTN_YES_CSS;
	
	@FindBy(css = "[ng-model='vehicleIncident.airbagsDeployed.value'][ng-value='true']")
	WebElement AIRBAG_DEPLOYED_RBTN_VALUE_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.equipmentFailure'] label[class=gw-second]")
	WebElement EQUIP_FAIL_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.equipmentFailure'] label[class=gw-first]")
	WebElement EQUIP_FAIL_RBTN_YES_CSS;
	
	@FindBy(css = "[ng-model='vehicleIncident.equipmentFailure.value'][ng-value='true']")
	WebElement EQUIP_FAIL_RBTN_VALUE_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.vehicleTowed'] label[class=gw-second]")
	WebElement VEHICLE_TOWED_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.vehicleTowed'] label[class=gw-first]")
	WebElement VEHICLE_TOWED_RBTN_YES_CSS;
	
	@FindBy(css = "[ng-model='vehicleIncident.vehicleTowed.value'][ng-value='true']")
	WebElement VEHICLE_TOWED_RBTN_VALUE_YES_CSS;

	@FindBy(css = "[model='vehicleIncident.rentalRequired'] label[class=gw-second]")
	WebElement RENTAL_REQ_RBTN_NO_CSS;

	@FindBy(css = "[model='vehicleIncident.rentalRequired'] label[class=gw-first]")
	WebElement RENTAL_REQ_RBTN_YES_CSS;
	
	@FindBy(css = "[ng-model='vehicleIncident.rentalRequired.value'][ng-value='true']")
	WebElement RENTAL_REQ_RBTN_VALUE_YES_CSS;

	@FindBy(id = "frontBumper")
	WebElement FRONT_BUMPER_ID;
	@FindBy(id = "rearBumper")
	WebElement REAR_BUMPER_ID;
	@FindBy(id = "rearLeftSide")
	WebElement REAR_LEFT_SIDE_ID;
	@FindBy(id = "rearRightSide")
	WebElement REAR_RIGHT_SIDE_ID;
	@FindBy(id = "frontLeftSide")
	WebElement FRONT_LEFT_SIDE_ID;
	@FindBy(id = "frontRightSide")
	WebElement FRONT_RIGHT_SIDE_ID;
	@FindBy(id = "frontLeftCorner")
	WebElement LEFT_CORNER_ID;
	@FindBy(id = "frontRightCorner")
	WebElement RIGHT_CORNER_ID;
	@FindBy(id = "frontLeftDoor")
	WebElement FRONT_LEFT_DOOR_ID;
	@FindBy(id = "frontRightDoor")
	WebElement FRONT_RIGHT_DOOR_ID;
	@FindBy(id = "rearLeftDoor")
	WebElement REAR_LEFT_DOOR_ID;
	@FindBy(id = "rearRightDoor")
	WebElement REAR_RIGHT_DOOR_ID;
	@FindBy(id = "roof")
	WebElement ROOF_ID;

	@FindBy(id = "hood")
	WebElement HOOD_ID;

	@FindBy(xpath = "//img[contains(@src, 'onhover')]/..")
	WebElement DAMAGE_VEHICLE_PART_XPATH;

	@FindBy(css = "[ng-click='next(collisionVehiclesForm)']")
	WebElement NEXT_BTN_CSS;

	// ADD passenger

	@FindBy(css = "[ng-click='addVehicleIncident(collisionVehiclesForm)']")
	WebElement ADD_ANOTHER_VEHICLE_BTN_CSS;

	@FindBy(css = "[class*='gw-btn-primary gw-dropdown-toggle']")
	WebElement ADD_PASSENGER_BTN_CSS;

	@FindBy(css = "li[ng-click='addPassenger(null, $event)']")
	WebElement NEW_PASSENGER_OPTION_CSS;

	@FindBy(css = "li[ng-click='a:contains('Another person')")
	WebElement ANOTHER_PASSENGER_ADD_BTN_CSS;

	@FindBy(css = "input[ng-model='passenger.firstName.value']")
	WebElement PASSENGER_FIRSTNAME_CSS;

	@FindBy(css = "input[ng-model='passenger.lastName.value']")
	WebElement PASSENGER_LASTNAME_CSS;

	@FindBy(css = "input[ng-model='passenger.homeNumber.value']")
	WebElement PASSENGER_CONTACTNUM_CSS;

	@FindBy(css = "[ng-click='removePassenger(passenger.value)']")
	WebElement PASSENGER_DELETE_CSS;

	String PASSENGER_NAME = "a:contains('NAME-PASSENGER')";

	String SELECT_ANOTHER_PERSON = "a:contains('Another person')";

	// New Vehicle

	@FindBy(css = "[model='newVehicle.color'] input")
	WebElement VEH_COLOR_TXT_CSS;

	@FindBy(css = "[model='newVehicle.licensePlate'] input")
	WebElement VEH_LICENSE_TXT_CSS;

	@FindBy(css = "[model='newVehicle.make'] input")
	WebElement VEH_MAKE_TXT_CSS;

	@FindBy(css = "[model='newVehicle.model'] input")
	WebElement VEH_MODEL_TXT_CSS;

	@FindBy(css = "[model='newVehicle.state'] select")
	WebElement VEH_STATE_DROP_CSS;

	@FindBy(css = "[model='newVehicle.vIN'] input, [model='newVehicle.vin'] input")
	WebElement VEH_VIN_TXT_CSS;

	@FindBy(css = "[model='newVehicle.year'] select")
	WebElement VEH_YEAR_TXT_CSS;
	
	@FindBy(xpath = "//*[@id='Year']/parent::*/..//div[@class='gw-inline-messages']")
	WebElement VEH_YEAR_ERROR_XPATH;
	
	// New Driver

	@FindBy(css = "[model='contact.firstName'] input")
	WebElement DRIVER_FIRST_NAME_TXT_CSS;

	@FindBy(css = "[model='contact.lastName'] input")
	WebElement DRIVER_LAST_NAME_TXT_CSS;

	@FindBy(css = "[model='contact.homeNumber'] input")
	WebElement DRIVER_CONTACT_NUM_TXT_CSS;

	@FindBy(css = "[model='contact.cellNumber'] input")
	WebElement DRIVER_CELL_NUM_TXT_CSS;
	
	@FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;

	@FindBy(css = "[name='collisionVehiclesForm']")
	WebElement FORM;
	
	String ADD_PERSON = "[class='gw-btn-caret fa fa-sort-desc']";

	//Additional Vehicle & Driver
	private final By VEHICLE_TAB_CSS = By.cssSelector("[ng-click='select()']");
	private final By VEHICLE_DROP =  By.cssSelector("[ng-model='vehicleIncident.vehicle.value']");
	private final By DRIVER_DROP = By.cssSelector("[ng-model='vehicleIncident.driver.value']");
	private final By VEHICLE_MAKE = By.cssSelector("[model='newVehicle.make'] input");
	private final By VEHICLE_MODEL = By.cssSelector("[model='newVehicle.model'] input");
	private final By VEHICLE_YEAR = By.cssSelector("[model='newVehicle.year'] select");
	private final By DRIVER_FIRST_NAME = By.cssSelector("[model='contact.firstName'] input");
	private final By DRIVER_LAST_NAME = By.cssSelector("[model='contact.lastName'] input");
	private final String OTHER_VEHICLE = "Other Vehicle";
	private final String OTHER_DRIVER = "Other Driver";

	public NewClaimVehicleDriverPage() {
		super();
		this.REQUIRED_FIELDS = new String[]{"vehicleIncident.vehicle", "vehicleIncident.driver"};
	}

	public NewClaimVehicleDriverPage selectVehicle() {
		if (data.get("VehicleDamaged") == null || data.get("VehicleDamaged").isEmpty()) {
			return this.selectFirstAvailableVehicle();
		}
		seleniumCommands.selectDropDownValueByText(VEHICLE_DROP_CSS, data.get("VehicleDamaged"));
		return this;
	}

	public NewClaimVehicleDriverPage selectDriver() {
		if (data.get("DriverInvolved") == null || data.get("DriverInvolved").isEmpty()) {
			return this.selectFirstAvailableDriver();
		}
		seleniumCommands.selectDropDownValueByText(DRIVER_DROP_CSS, data.get("DriverInvolved"));
		return this;
	}

	private String selectFirstAvailableOption(WebElement selectionElement) {
		List<String> possibleOptions = seleniumCommands.getAllOptionsFromDropDown(selectionElement);
		String optionToBeSelected = "";
		for(String anOption : possibleOptions) {
			if(!anOption.toLowerCase().contains("choose") && !anOption.toLowerCase().contains("other")) {
				optionToBeSelected = anOption;
			}
		}
		return optionToBeSelected;
	}

	public NewClaimVehicleDriverPage selectFirstAvailableDriver() {
		String optionToBeSelected = selectFirstAvailableOption(DRIVER_DROP_CSS);
		logger.info("Selecting [" + optionToBeSelected + "] driver");
		seleniumCommands.selectDropDownValueByText(DRIVER_DROP_CSS, optionToBeSelected);
		String driverName = seleniumCommands.getSelectedOptionFromDropDown(DRIVER_DROP_CSS);
		HashMap<String, String> data  = ThreadLocalObject.getData();
		data.put(ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(), driverName);
		data.put(ClaimData.INSURED_DISPLAY_NAME.getValue(), driverName);
		data.put(ClaimData.DRIVER_DISPLAY_NAME.getValue(), driverName);
		data.put("EXISTING_CONTACT", driverName);
		data.put("DriverInvolved", driverName);
		return this;
	}

	public NewClaimVehicleDriverPage selectFirstAvailableVehicle() {
		String optionToBeSelected = selectFirstAvailableOption(VEHICLE_DROP_CSS);
		logger.info("Selecting [" + optionToBeSelected + "] vehicle");
		seleniumCommands.selectDropDownValueByText(VEHICLE_DROP_CSS, optionToBeSelected);
		String[] vehicleData = seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_DROP_CSS).split(" ");
		ThreadLocalObject.getData().put("Make",vehicleData[0]);
		ThreadLocalObject.getData().put("Model",vehicleData[1]);
		ThreadLocalObject.getData().put("VehicleYear",vehicleData[2]);
		ThreadLocalObject.getData().put("VehicleDamaged", optionToBeSelected);
		return this;
	}
	
	public NewClaimVehicleDriverPage selectOtherDriver() {
		seleniumCommands.selectDropDownValueByText(DRIVER_DROP_CSS, this.OTHER_DRIVER);
		return this;
	}
	
	public NewClaimVehicleDriverPage selectOtherVehicle() {
		seleniumCommands.selectDropDownValueByText(VEHICLE_DROP_CSS, this.OTHER_VEHICLE);
		return this;
	}

	public NewClaimVehicleDriverPage selectVehicleOnAdditionalVehiclePage() {
		return selectVehicleOnAdditionalVehiclePage(1);
	}
	public NewClaimVehicleDriverPage selectVehicleOnAdditionalVehiclePage(int tabNumber) {
		seleniumCommands.selectFromDropdownByIndex(seleniumCommands.findElements(VEHICLE_DROP).get(tabNumber), 1);
		return this;
	}

	public NewClaimVehicleDriverPage selectOtherVehicleOnAdditionalVehiclePage() {
		return selectOtherVehicleOnAdditionalVehiclePage(1);
	}
	public NewClaimVehicleDriverPage selectOtherVehicleOnAdditionalVehiclePage(int tabNumber) {
		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(VEHICLE_DROP).get(tabNumber), this.OTHER_VEHICLE);
		return this;
	}

	public NewClaimVehicleDriverPage selectDriverOnAdditionalVehiclePage(int tabNumber) {
		seleniumCommands.selectFromDropdownByIndex(seleniumCommands.findElements(DRIVER_DROP).get(tabNumber), 1);
		return this;
	}

	public NewClaimVehicleDriverPage selectOtherDriverOnAdditionalVehiclePage() {
		return selectOtherDriverOnAdditionalVehiclePage(1);
	}
	public NewClaimVehicleDriverPage selectOtherDriverOnAdditionalVehiclePage(int tabNumber) {
		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(DRIVER_DROP).get(tabNumber), this.OTHER_DRIVER);
		return this;
	}

	public NewClaimVehicleDriverPage addAdditionalVehicle() {
		return addAdditionalVehicle(1);
	}
	public NewClaimVehicleDriverPage addAdditionalVehicle(int tabNumber) {
		seleniumCommands.clickbyJS(ADD_ANOTHER_VEHICLE_BTN_CSS);
		seleniumCommands.waitForElementListHaveMoreValuesThan(VEHICLE_TAB_CSS, tabNumber);
		seleniumCommands.pageWebElementLoader(this);
		return this;
	}

	public NewClaimVehicleDriverPage setVehicleSafetyToDrive() {
		if (data.get("SAFE_TO_DRIVE") != null && new Boolean(data.get("SAFE_TO_DRIVE"))) {
			seleniumCommands.clickbyJS(SAFE_TO_DRIVE_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(SAFE_TO_DRIVE_RBTN_NO_CSS);
		}
		return this;
	}
	
	public NewClaimVehicleDriverPage setAirBagDeployStatus() {
		if (data.get("AIRBAG_DEPLOYED") != null && new Boolean(data.get("AIRBAG_DEPLOYED"))) {
			seleniumCommands.clickbyJS(AIRBAG_DEPLOYED_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(AIRBAG_DEPLOYED_RBTN_NO_CSS);
		}
		return this;
	}
	
	public NewClaimVehicleDriverPage setEquiFailureStatus() {
		if (data.get("EQUIP_FAIL") != null && new Boolean(data.get("EQUIP_FAIL"))) {
			seleniumCommands.clickbyJS(EQUIP_FAIL_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(EQUIP_FAIL_RBTN_NO_CSS);
		}
		return this;
	}
	
	public NewClaimVehicleDriverPage setVehicleTowStatus() {
		if (data.get("VEH_TOWED") != null && new Boolean(data.get("VEH_TOWED"))) {
			seleniumCommands.clickbyJS(VEHICLE_TOWED_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(VEHICLE_TOWED_RBTN_NO_CSS);
		}
		return this;
	}
	
	public NewClaimVehicleDriverPage setVehicleRentalStatus() {
		if (data.get("VEH_RENTAL") != null && new Boolean(data.get("VEH_RENTAL"))) {
			seleniumCommands.clickbyJS(RENTAL_REQ_RBTN_YES_CSS);
		} else {
			seleniumCommands.clickbyJS(RENTAL_REQ_RBTN_NO_CSS);
		}
		return this;
	}
	
	public NewClaimVehicleDriverPage setVehicleCollisionPoint() {
		CarPart part;
		try {
			part = CarPart.valueOf(data.get("COLLISION_POINT_HOOD"));
		} catch (Exception e) {
			logger.warn("Please use COLLISION_POINT_HOOD in data following by com.guidewire.common.selenium.CarPart");
			part = CarPart.FRONT_DOOR_LEFT;
		}

		switch (part) {
			case ROOF:
				seleniumCommands.clickbyJS(ROOF_ID);
				break;
			case FRONT_PART:
				seleniumCommands.clickbyJS(FRONT_BUMPER_ID);
				break;
			case REAR_PART:
				seleniumCommands.clickbyJS(REAR_BUMPER_ID);
				break;
			case QUARTER_PANEL_LEFT:
				seleniumCommands.clickbyJS(REAR_LEFT_SIDE_ID);
				break;
			case QUARTER_PANEL_RIGHT:
				seleniumCommands.clickbyJS(REAR_RIGHT_SIDE_ID);
				break;
			case FRONT_SIDE_LEFT:
				seleniumCommands.clickbyJS(FRONT_LEFT_SIDE_ID);
				break;
			case FRONT_SIDE_RIGHT:
				seleniumCommands.clickbyJS(FRONT_RIGHT_SIDE_ID);
				break;
			case FRONT_FENDER_LEFT:
				seleniumCommands.clickbyJS(LEFT_CORNER_ID);
				break;
			case FRONT_FENDER_RIGHT:
				seleniumCommands.clickbyJS(RIGHT_CORNER_ID);
				break;
			case REAR_DOOR_LEFT:
				seleniumCommands.clickbyJS(REAR_LEFT_DOOR_ID);
				break;
			case REAR_DOOR_RIGHT:
				seleniumCommands.clickbyJS(REAR_RIGHT_DOOR_ID);
				break;
			case FRONT_DOOR_RIGHT:
				seleniumCommands.clickbyJS(FRONT_RIGHT_DOOR_ID);
				break;
			default:
				seleniumCommands.clickbyJS(FRONT_LEFT_DOOR_ID);
				break;

		}

		return this;
	}
	
	public NewClaimVehicleDriverPage withExistingPassenger() {
		seleniumCommands.click(ADD_PASSENGER_BTN_CSS);
		seleniumCommands.click(By.cssSelector(PASSENGER_NAME.replace("NAME-PASSENGER", data.get("EXISTING_PASSENGER"))));
		return this;
	}
	
	public NewClaimVehicleDriverPage withNewPassenger() {
		addNewPassenger();
		seleniumCommands.type(PASSENGER_FIRSTNAME_CSS, data.get("FirstNamePassenger1"));
		seleniumCommands.type(PASSENGER_LASTNAME_CSS, data.get("LastNamePassenger1"));
		seleniumCommands.type(PASSENGER_CONTACTNUM_CSS, data.get("PassengerHomePhone"));
		return this;
	}
	
	public NewClaimVehicleDriverPage addNewPassenger() {
		seleniumCommands.waitForElementToBeVisible(ADD_PASSENGER_BTN_CSS);
		seleniumCommands.click(ADD_PASSENGER_BTN_CSS);
		seleniumCommands.click(NEW_PASSENGER_OPTION_CSS);
		seleniumCommands.waitForElementToBeVisible(PASSENGER_FIRSTNAME_CSS);
		return this;
	}
	
	public NewClaimVehicleDriverPage withNewVehicle() {
		selectOtherVehicle();
		seleniumCommands.waitForElementToBeVisible(VEH_COLOR_TXT_CSS);
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.type(VEH_COLOR_TXT_CSS, data.get("NEW_VEH_COLOR"));
		seleniumCommands.type(VEH_LICENSE_TXT_CSS, data.get("NEW_VEH_LICENSE"));
		seleniumCommands.type(VEH_MAKE_TXT_CSS, data.get("NEW_VEH_MAKE"));
		seleniumCommands.type(VEH_MODEL_TXT_CSS, data.get("NEW_VEH_MODEL"));
		seleniumCommands.selectDropDownValueByText(VEH_STATE_DROP_CSS, data.get("NEW_VEH_STATE"));
		seleniumCommands.type(VEH_VIN_TXT_CSS, data.get("NEW_VEH_VIN"));
		seleniumCommands.selectDropDownValueByText(VEH_YEAR_TXT_CSS, data.get("NEW_VEH_YEAR"));
		return this;
	}

	private NewClaimVehicleDriverPage withOtherVehicle(HashMap<String, String> inData, int tabNumber) {
		int numberInCollection = tabNumber;
		if (seleniumCommands.findElements(VEHICLE_MAKE).size() < (tabNumber + 1))
			numberInCollection = tabNumber - 1;
		seleniumCommands.waitForElementToBeClickable(seleniumCommands.findElements(VEHICLE_MAKE).get(numberInCollection));
		seleniumCommands.type(seleniumCommands.findElements(VEHICLE_MAKE).get(numberInCollection), inData.get(ClaimData.VEHICLE_MAKE.toString()));
		seleniumCommands.type(seleniumCommands.findElements(VEHICLE_MODEL).get(numberInCollection), inData.get(ClaimData.VEHICLE_MODEL.toString()));
		seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(VEHICLE_YEAR).get(numberInCollection), inData.get(ClaimData.VEHICLE_YEAR.toString()));
		return this;
	}

	public NewClaimVehicleDriverPage withFirstOtherVehicle() {
		HashMap<String, String> outData = new HashMap<>();
		outData.put(ClaimData.VEHICLE_MAKE.toString(), data.get(ClaimData.VEHICLE_MAKE1.toString()));
		outData.put(ClaimData.VEHICLE_MODEL.toString(), data.get(ClaimData.VEHICLE_MODEL1.toString()));
		outData.put(ClaimData.VEHICLE_YEAR.toString(), data.get(ClaimData.VEHICLE_YEAR1.toString()));
		return this.withOtherVehicle(outData, 1);
	}

	public NewClaimVehicleDriverPage withSecondOtherVehicle() {
		HashMap<String, String> outData = new HashMap<>();
		outData.put(ClaimData.VEHICLE_MAKE.toString(), data.get(ClaimData.VEHICLE_MAKE2.toString()));
		outData.put(ClaimData.VEHICLE_MODEL.toString(), data.get(ClaimData.VEHICLE_MODEL2.toString()));
		outData.put(ClaimData.VEHICLE_YEAR.toString(), data.get(ClaimData.VEHICLE_YEAR2.toString()));
		return this.withOtherVehicle(outData, 2);
	}

	public NewClaimVehicleDriverPage withNewDriver() {
		selectOtherDriver();
		seleniumCommands.type(DRIVER_FIRST_NAME_TXT_CSS, data.get("NEW_DRIVER_FIRSTNAME"));
		seleniumCommands.type(DRIVER_LAST_NAME_TXT_CSS, data.get("NEW_DRIVER_LASTNAME"));
		seleniumCommands.type(DRIVER_CONTACT_NUM_TXT_CSS, data.get("NEW_DRIVER_CONTACTNUM"));
		seleniumCommands.type(DRIVER_CELL_NUM_TXT_CSS, data.get("NEW_DRIVER_CELLNUM"));
		return this;
	}

	private NewClaimVehicleDriverPage withOtherDriver(HashMap<String, String> inData, int tabNumber) {
		int numberInCollection = tabNumber;
		if (seleniumCommands.findElements(DRIVER_FIRST_NAME).size() < (tabNumber + 1) )
			numberInCollection = tabNumber - 1;
		seleniumCommands.waitForElementToBeClickable(seleniumCommands.findElements(DRIVER_FIRST_NAME).get(numberInCollection));
		seleniumCommands.type(seleniumCommands.findElements(DRIVER_FIRST_NAME).get(numberInCollection), inData.get(ClaimData.OTHER_DRIVER_FIRST_NAME.toString()));
		seleniumCommands.type(seleniumCommands.findElements(DRIVER_LAST_NAME).get(numberInCollection), inData.get(ClaimData.OTHER_DRIVER_LAST_NAME.toString()));
		return this;
	}

	public NewClaimVehicleDriverPage withFirstOtherDriver() {
		HashMap<String, String> outData = new HashMap<>();
		outData.put(ClaimData.OTHER_DRIVER_FIRST_NAME.toString(), data.get(ClaimData.OTHER_DRIVER_FIRST_NAME1.toString()));
		outData.put(ClaimData.OTHER_DRIVER_LAST_NAME.toString(), data.get(ClaimData.OTHER_DRIVER_LAST_NAME1.toString()));
		return this.withOtherDriver(outData, 1);
	}

	public NewClaimVehicleDriverPage withSecondOtherDriver() {
		HashMap<String, String> outData = new HashMap<>();
		outData.put(ClaimData.OTHER_DRIVER_FIRST_NAME.toString(), data.get(ClaimData.OTHER_DRIVER_FIRST_NAME2.toString()));
		outData.put(ClaimData.OTHER_DRIVER_LAST_NAME.toString(), data.get(ClaimData.OTHER_DRIVER_LAST_NAME2.toString()));
		return this.withOtherDriver(outData, 2);
	}

	public NewClaimRepairChoicePage goToRepairChoicePage() {
		this.goNext();
		return new NewClaimRepairChoicePage();
	}

	public NewClaimDocumentPage goToDocumentPage() {
		this.goNext();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_PERSON));
		return new NewClaimDocumentPage();
	}

	public NewClaimVehicleDriverPage goNext() {
		seleniumCommands.click(NEXT_BTN_CSS);
		return this;
	}
	
	public NewClaimVehicleDriverPage goBack() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[on-click='goToPrevious()']"));
		seleniumCommands.clickbyJS(By.cssSelector("[on-click='goToPrevious()']"));
		return this;
	}
	
	public AlertHandler cancelClaim() {
		clickCancel();
		return new AlertHandler();
	}
	
	//Get Methods
	
	public boolean getVehicleSafetyToDriveStatus() {
		return SAFE_TO_DRIVE_RBTN_VALUE_YES_CSS.isSelected();
	}
	
	public boolean getAirBagDeployStatus() {
			return VEHICLE_TOWED_RBTN_VALUE_YES_CSS.isSelected();
	}
	
	public boolean getEquiFailureStatus() {
			return VEHICLE_TOWED_RBTN_VALUE_YES_CSS.isSelected();
	}
	
	public boolean getVehicleTowStatus() {
			return VEHICLE_TOWED_RBTN_VALUE_YES_CSS.isSelected();
	}
	
	public boolean getVehicleRentalStatus() {
		return VEHICLE_TOWED_RBTN_VALUE_YES_CSS.isSelected();
	}
	
	public String getVehicleDamagePart() {
		return seleniumCommands.getAttributeValueAtLocator(DAMAGE_VEHICLE_PART_XPATH, "part");
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}
	
	public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}
	
	//Validation
	
	public Validation isVehicleDriverPageLoaded() {
		logger.info("Validating is Vheilce Driver page is opened");
		seleniumCommands.waitForElementToBeVisible(DRIVER_DROP_CSS);
		return new Validation(seleniumCommands.isElementPresent(VEHICLE_DROP_CSS));
	}
	
	public Validation validateVehicleDropDownFieldErrorMessage() {
		logger.info("Validating the Mandatory Error for City Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(VEHICLE_DROP_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation validateDriverDropDownFieldErrorMessage() {
		logger.info("Validating the Mandatory Error for City Field");
		return new Validation(seleniumCommands.getErrorMessageForDatePicker(DRIVER_DROP_CSS), DataConstant.MANDATORY_ERROR_MSG);
	}
	
	public Validation validatePassengerMandatoryFieldsErrorMessage() {
		logger.info("Validating the Mandatory field Error for Passenger");
		new Validation(seleniumCommands.getAttributeValueAtLocator(PASSENGER_FIRSTNAME_CSS, "class").contains(INVALID_INPUT_NEW_ERROR_CLASS)).shouldBeTrue("Passenger FirstName is not marked with error.");
		new Validation(seleniumCommands.getAttributeValueAtLocator(PASSENGER_LASTNAME_CSS, "class").contains(INVALID_INPUT_NEW_ERROR_CLASS)).shouldBeTrue("Passenger LastName is not marked with error.");
		return new Validation(true);
	}
	
	public Validation validateNewVehicleMandatoryFieldsErrorMessage() {
		logger.info("Validating the Mandatory field Error for New Vehicle");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(VEH_MAKE_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Vehicle Make field's error message is not correct");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(VEH_MODEL_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Vehicle Model field's error message is not correct");
		new Validation(seleniumCommands.getTextAtLocator(VEH_YEAR_ERROR_XPATH), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Vehicle Year field's error message is not correct");
		return new Validation(true);
	}
	
	public Validation validateNewDriverMandatoryFieldsErrorMessage() {
		logger.info("Validating the Mandatory field Error for New Driver");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(DRIVER_FIRST_NAME_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Driver First Name field's error message is not correct");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(DRIVER_LAST_NAME_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Driver Last Name field's error message is not correct");
		return new Validation(true);
	}
	
	public Validation areVehicleDriverDetailsAreSaved() {
		logger.info("Validating if Vehicle Driver data is saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_DROP_CSS), data.get("VehicleDamaged")).shouldBeEqual("Vehicle selection is not saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(DRIVER_DROP_CSS), data.get("DriverInvolved")).shouldBeEqual("Driver selection is not saved");
		new Validation(getVehicleSafetyToDriveStatus()).shouldBeTrue("Vehicle Drive to safe status is not saved");
		new Validation(getAirBagDeployStatus()).shouldBeTrue("Air Bag deploy status is not saved");
		new Validation(getEquiFailureStatus()).shouldBeTrue("Equip Failure status is not saved");
		new Validation(getVehicleTowStatus()).shouldBeTrue("Vehicle Tow status is not saved");
		new Validation(getVehicleRentalStatus()).shouldBeTrue("Vehicle Rental status is not saved");
		new Validation(getVehicleDamagePart(), data.get("COLLISION_POINT_HOOD")).shouldBeEqual("Vehicle Damage part value is not saved");
		return new Validation(true);
	}
	
	public Validation isVehicleDriverDetailsDataMatchingWithBackEnd(String claimNum) {
		logger.info("Validating if Vehicle Driver data is matching backend");
		HashMap<String, String> backEndData = ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getAgentClaimData(claimNum));
		String vehicle = backEndData.get("Make") + " " + backEndData.get("Model") + " " + backEndData.get("VehicleYear");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_DROP_CSS), vehicle).shouldBeEqual("Vehicle selection is not saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(DRIVER_DROP_CSS), ThreadLocalObject.getData().get(ClaimData.DRIVER_DISPLAY_NAME.getValue())).shouldBeEqual("Vehicle selection is not saved");
		new Validation(getVehicleSafetyToDriveStatus(), new Boolean(backEndData.get("AIRBAG_DEPLOYED"))).shouldBeEqual("Vehicle Drive to safe status is not saved");
		new Validation(getAirBagDeployStatus(), new Boolean(backEndData.get("AIRBAG_DEPLOYED"))).shouldBeEqual("Air Bag deploy status is not saved");
		new Validation(getEquiFailureStatus(), new Boolean(backEndData.get("EQUIP_FAIL"))).shouldBeEqual("Equip Failure status is not saved");
		new Validation(getVehicleTowStatus(), new Boolean(backEndData.get("VEH_TOWED"))).shouldBeEqual("Vehicle Tow status is not saved");
		new Validation(getVehicleRentalStatus(), new Boolean(backEndData.get("VEH_RENTAL"))).shouldBeEqual("Vehicle Rental status is not saved");
		new Validation(getVehicleDamagePart(), data.get("COLLISION_POINT_HOOD")).shouldBeEqual("Vehicle Damage part value is not saved");
		return new Validation(true);
	}
	
	public Validation arePassengerDetailsAreSaved() {
		logger.info("Validating if Passenger details are saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(PASSENGER_FIRSTNAME_CSS), data.get("FirstNamePassenger1")).shouldBeEqual("Passenger First Name is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(PASSENGER_LASTNAME_CSS), data.get("LastNamePassenger1")).shouldBeEqual("Passenger Last Name is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(PASSENGER_CONTACTNUM_CSS), data.get("PassengerHomePhone")).shouldBeEqual("Passenger contact num is not saved");
		return new Validation(true);
	}

}
