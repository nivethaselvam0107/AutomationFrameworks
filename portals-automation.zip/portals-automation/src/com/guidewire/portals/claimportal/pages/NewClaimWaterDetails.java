package com.guidewire.portals.claimportal.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class NewClaimWaterDetails extends ClaimWizardPage {

	@FindBy(css = "[for='water']")
	WebElement WATER_DAMAGE_RBTN_CSS;
	
	@FindBy(css = "[for='mold']")
	WebElement MOLD_DAMAGE_RBTN_CSS;
	
	@FindBy(css = "[model='claimVm.description'] textarea")
	WebElement WATER_DESCRIPTION_TXT_CSS;
	
	@FindBy(css = "[for='plumbing']")
	WebElement WATER_SOURCE_PLUMB_WATER_RBTN_CSS;
	
	@FindBy(css = "[for='roof']")
	WebElement WATER_SOURCE_ROOF_LEAK_RBTN_CSS;
	
	@FindBy(css = "[for='other']")
	WebElement WATER_SOURCE_NTSURE_CSS;
	
	@FindBy(css = "[for='yeah']")
	WebElement WATER_TURNOFF_RBTN_YES_CSS;
	
	@FindBy(css = "[for='nah']")
	WebElement WATER_TURNOFF_RBTN_NO_CSS;
	
	@FindBy(css = "[for='dunno']")
	WebElement WATER_TURNOFF_RBTN_NTSURE_CSS;
	
	@FindBy(css = "[for='yeah']")
	WebElement ROOF_FIXED_RBTN_YES_CSS;
	
	@FindBy(css = "[for='nah']")
	WebElement ROOF_FIXED_RBTN_NO_CSS;
	
	@FindBy(css = "[for='dunno']")
	WebElement ROOF_FIXED_RBTN_NTSURE_CSS;
	
	public NewClaimWaterDetails() {
		super();
	}
	
	public NewClaimWaterDetails setWaterDamageDetails() {
		withWaterDamageType();
		seleniumCommands.type(WATER_DESCRIPTION_TXT_CSS, data.get("LOSS_DESC"));
		withWaterDamageSource();
		withWaterTurnOffStatus();
		return this;
	}
	
	public NewClaimWaterDetails withWaterDamageType() {
		if(data.get("WaterDamageType").equals("WaterDamage"))
		{
			seleniumCommands.clickbyJS(WATER_DAMAGE_RBTN_CSS);
		}
		else if(data.get("WaterDamageType").equals("Mold"))
		{
			seleniumCommands.clickbyJS(MOLD_DAMAGE_RBTN_CSS);
		}
		return this;
	}
	
	public NewClaimWaterDetails withWaterDamageSource() {
		if(data.get("WaterDamageSource").equals("Plumbing"))
		{
			seleniumCommands.clickbyJS(WATER_SOURCE_PLUMB_WATER_RBTN_CSS);
		}
		else if(data.get("WaterDamageSource").equals("Roof"))
		{
			seleniumCommands.clickbyJS(WATER_SOURCE_ROOF_LEAK_RBTN_CSS);
			withRoofFixStatus();
		}
		else if(data.get("WaterDamageSource").equals("NotSure"))
		{
			seleniumCommands.clickbyJS(WATER_SOURCE_NTSURE_CSS);
		}
		return this;
	}
	
	public NewClaimWaterDetails withWaterTurnOffStatus() {
		if(data.get("WaterTurnOff").equals("Yes"))
		{
			seleniumCommands.clickbyJS(WATER_TURNOFF_RBTN_YES_CSS);
		}
		else if(data.get("WaterTurnOff").equals("No"))
		{
			seleniumCommands.clickbyJS(WATER_TURNOFF_RBTN_NO_CSS);
		}
		else if(data.get("WaterTurnOff").equals("NotSure"))
		{
			seleniumCommands.clickbyJS(WATER_TURNOFF_RBTN_NTSURE_CSS);
		}
		return this;
	}
	
	public NewClaimWaterDetails withRoofFixStatus() {
		if(data.get("ROOF_FIXED").equals("Yes"))
		{
			seleniumCommands.clickbyJS(ROOF_FIXED_RBTN_YES_CSS);
		}
		else if(data.get("ROOF_FIXED").equals("No"))
		{
			seleniumCommands.clickbyJS(ROOF_FIXED_RBTN_NO_CSS);
		}
		else if(data.get("ROOF_FIXED").equals("NotSure"))
		{
			seleniumCommands.clickbyJS(ROOF_FIXED_RBTN_NTSURE_CSS);
		}
		return this;
	}
	
	public NewClaimDocumentPage goNext() {
		clickNext();
		return new NewClaimDocumentPage();
	}
}
