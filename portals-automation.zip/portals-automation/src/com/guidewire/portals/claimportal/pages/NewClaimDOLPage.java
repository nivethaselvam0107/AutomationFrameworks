package com.guidewire.portals.claimportal.pages;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class NewClaimDOLPage extends ClaimWizardPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[class*='gw-alert'] div span")
	WebElement NO_POLICY_ERROR_CSS;

	String POLICY_XPATH = "//label[contains(text(),'POLICYNUM')]";

	String POLICY_LABEL_SELECTION_XPATH = "//label[contains(text(),'POLICYNUM')]/../preceding-sibling::td/label[@for]";
	final By LIST_POLICY_TYPE_XPATH = By.xpath("//label[@for]/img");

	@FindBy(css = "[for='searchByPolicyDetails']")
	WebElement POLICY_SEARCH_RBTN_CSS;

	@FindBy(css = "[model='criteriaVM.firstName'] input")
	WebElement FIRSTNAME_TXT_CSS;

	@FindBy(css = "[model='criteriaVM.lastName'] input")
	WebElement LASTNAME_TXT_CSS;

	@FindBy(css = "[model='criteriaVM.policyType'] select")
	WebElement POLICYTYPE_DROP_CSS;

	@FindBy(css = "[model='criteriaVM.city'] input")
	WebElement CITY_TXT_CSS;

	@FindBy(css = "[model='criteriaVM.state'] select")
	WebElement STATE_DROP_CSS;

	@FindBy(css = "[model='criteriaVM.zip'] input")
	WebElement ZIP_TXT_CSS;

	@FindBy(css = "[ng-click='resetSearchCriteria()']")
	WebElement RESET_SEARCH_BTN_CSS;

	@FindBy(css = ".gw-alert__content  span")
	WebElement NO_POLICY_SEARCH_ERROR_CSS;

	@FindBy(css = "table[list='policies'], table[list='inForcePolicies']")
	WebElement POLICY_SEARCH_RESULT_TABLE_CSS;

	@FindBy(css = "[model='claimVm.lossDate']")
	WebElement DATE_OF_LOSS_INPUT;

	// Producer Locators

	@FindBy(id = "PolicyNumber")
	WebElement POLICY_SEARCH_TXT_ID;

	private static String NEXT_PAGE_BUTTON = "[gw-wizard-page-actions] [on-click='goToNext()']";

	private final String SEARCH_BUTTON_PROPERTY = "ng-click";

	private final String SEARCH_BUTTON_PROPERTY_VALUE= "search()";

	private final String SEARCH_BUTTON_DISABLED_CSS = "[ng-click='search()'][disabled='disabled']";
	
	private final By DATE_ERROR_XPATH = By.xpath("//*[@model='claimVm.lossDate']//*[contains(@class,'inline-messages')]/*[@aria-hidden='false']");

	public NewClaimDOLPage() {
		super();
	}

	public NewClaimDOLPage withClaimDateOfLoss() {
		fillDatePicker(data.get("CLAIM_DOL"));
		hideDoL();
		return this;
	}

	public NewClaimDOLPage withClaimDateOfLoss(String dol) {
		fillDatePicker(dol);
		hideDoL();
		return this;
	}

	public NewClaimDOLPage withClaimDateOfLoss(DateTime date) {
		fillDatePicker(date);
		hideDoL();
		return this;
	}

	public NewClaimDOLPage hideDoL() {
		if(suiteName == SuiteName.CPPH) {
			seleniumCommands.click(By.cssSelector("[model] span"));
		} else if (suiteName == SuiteName.CPAGENT) {
			searchPolicyByNumber();
		} else if (suiteName == SuiteName.GPA) {
			seleniumCommands.click(By.xpath("//img"));
		}
		return this;
	}

	public NewClaimDOLPage selectPolicy(String policyNumber) {
		if (suiteName == SuiteName.CPPH || suiteName == SuiteName.AMP) {
			seleniumCommands
					.waitForElementToBeClickable(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", policyNumber)));
			seleniumCommands.clickbyJS(ThreadLocalObject.getDriver()
					.findElement(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", policyNumber))));
		} else if (suiteName == SuiteName.CPAGENT) {
			searchPolicyByNumber();
		} else if (suiteName == SuiteName.GPA) {
			seleniumCommands
					.waitForElementToBeVisible(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", policyNumber)));
			seleniumCommands.clickbyJS(ThreadLocalObject.getDriver()
					.findElement(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", policyNumber))));
		}

		return this;
	}

	public NewClaimDOLPage selectPolicy() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this.selectPolicy(data.get("POLICY_NUM"));
	}

	public NewClaimDOLPage selectPolicyByPolicyType(String policyType) {
		if (ThreadLocalObject.getData().get("FOR_SPECIFIC_POLICY") ==null) {
			By locator = By.xpath(String.format("(//table[@list='inForcePolicies']//tr[descendant::img/@title='%s']//label)[2]", PolicyType.forId(policyType).getIconType()));
			seleniumCommands.waitForElementToBeVisible(locator);
			String policyNum = seleniumCommands.getTextAtLocator(locator);
			ThreadLocalObject.getData().put(PolicyData.POLICY_NUM.toString(), policyNum);
			return this.selectPolicy(policyNum);
		}
		return this;
	}

	public NewClaimDOLPage selectPolicyByPolicyType() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this.selectPolicyByPolicyType(ThreadLocalObject.getData().get("POLICY_TYPE"));
	}

	public NewClaimDOLPage selectPolicyFromSearchResult() {
		seleniumCommands
				.waitForElementToBeVisible(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", data.get("POLICY_NUM"))));
		seleniumCommands.clickbyJS(ThreadLocalObject.getDriver()
				.findElement(By.xpath(POLICY_LABEL_SELECTION_XPATH.replace("POLICYNUM", data.get("POLICY_NUM")))));
		return this;
	}

	public NewClaimDOLPage searchPolicyByNumber() {
		return searchPolicyByNumber(data.get("POLICY_NUM"));
	}

	public NewClaimDOLPage searchPolicyByNumber(String policyNum) {
		seleniumCommands.waitForElementToBeEnabled(POLICY_SEARCH_TXT_ID);
		seleniumCommands.type(POLICY_SEARCH_TXT_ID, policyNum);
		return this;
	}

	private NewClaimDOLPage selectPolicySearchOption() {
		seleniumCommands.click(POLICY_SEARCH_RBTN_CSS);
		seleniumCommands.waitForElementToBeVisible(FIRSTNAME_TXT_CSS);
		return this;
	}

	public NewClaimDOLPage searchPolicyByFirstName() {
		selectPolicySearchOption();
		seleniumCommands.type(FIRSTNAME_TXT_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage searchPolicyByLastName() {
		selectPolicySearchOption();
		seleniumCommands.type(LASTNAME_TXT_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage searchPolicyByCity() {
		selectPolicySearchOption();
		seleniumCommands.type(CITY_TXT_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage searchPolicyByState() {
		selectPolicySearchOption();
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage searchPolicyByZipCode() {
		selectPolicySearchOption();
		seleniumCommands.type(ZIP_TXT_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage setAllPolicySearchText() {
		selectPolicySearchOption();
		seleniumCommands.type(FIRSTNAME_TXT_CSS, data.get("PolicyFirstName"));
		seleniumCommands.type(LASTNAME_TXT_CSS, data.get("PolicyLastName"));
		seleniumCommands.type(CITY_TXT_CSS, data.get("PolicyCity"));
		seleniumCommands.type(ZIP_TXT_CSS, data.get("PolicyZip"));
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("PolicyState"));
		seleniumCommands.selectDropDownValueByText(POLICYTYPE_DROP_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage setAllPolicySearchText( String city, String zip, String state, String policyType) {
		logger.info("Validating the policy search reset button functionality");
		selectPolicySearchOption();
		seleniumCommands.type(FIRSTNAME_TXT_CSS, data.get("FIRST_NAME"));
		seleniumCommands.type(LASTNAME_TXT_CSS, data.get("LAST_NAME"));
		seleniumCommands.type(CITY_TXT_CSS, city);
		seleniumCommands.type(ZIP_TXT_CSS, zip);
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, state);
		seleniumCommands.selectDropDownValueByText(POLICYTYPE_DROP_CSS, policyType);
		return this;
	}

	public NewClaimDOLPage searchByPolicyType() {
		selectPolicySearchOption();
		seleniumCommands.selectDropDownValueByText(POLICYTYPE_DROP_CSS, data.get("PolicySearchValue"));
		return this;
	}

	public NewClaimDOLPage clickSearchButton() {
		new Button().clickbyProperty(SEARCH_BUTTON_PROPERTY, SEARCH_BUTTON_PROPERTY_VALUE);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public NewClaimDOLPage withValidValue() {
		this.clickSearchButton();
		seleniumCommands.waitForElementToBeEnabled(POLICY_SEARCH_RESULT_TABLE_CSS);
		return this;
	}

	public NewClaimDOLPage withInvalidValue() {
		this.clickSearchButton();
		seleniumCommands.waitForElementToBeVisible(NO_POLICY_ERROR_CSS);
		return this;
	}

	public NewClaimDOLPage goNextWithInvalidPolicyValue() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.click(By.cssSelector("[og-click='goToNext()']"));
		//seleniumCommands.click(By.cssSelector("[ng-click='goToNext()']"));
		seleniumCommands.waitForElementToBeVisible(NO_POLICY_SEARCH_ERROR_CSS);
		return this;
	}

	public NewClaimDOLPage resetSearchData() {
		seleniumCommands.click(RESET_SEARCH_BTN_CSS);
		seleniumCommands.waitForElementToBePresent(By.cssSelector(SEARCH_BUTTON_DISABLED_CSS));
		return this;
	}

	public WebElement getNextButton() {
		if (suiteName == SuiteName.CPPH || suiteName == SuiteName.AMP || suiteName == SuiteName.GPA) {
			return seleniumCommands.findElement(By.cssSelector(NEXT_PAGE_BUTTON));
		} else if (suiteName == SuiteName.CPAGENT) {
			return seleniumCommands.findElement(By.cssSelector("[on-click='goToNext()'][aria-hidden='false']"));
		}

		return null;
	}

	public NewClaimWhatHappenedPage goNext() {
		pressNext();
		return new NewClaimWhatHappenedPage();
	}

	public NewClaimWhatHappenedPage goToWhatPage() {
		pressNext();
		return new NewClaimWhatHappenedPage();
	}

	public NewClaimDOLPage pressNext() {
		if (suiteName == SuiteName.CPPH || suiteName == SuiteName.AMP || suiteName == SuiteName.GPA) {
			WebElement nextButton = this.getNextButton();
			seleniumCommands.waitForElementToBeEnabled(nextButton);
			seleniumCommands.clickbyJS(nextButton);
		} else if (suiteName == SuiteName.CPAGENT) {
			seleniumCommands.clickbyJS(this.getNextButton());
		}
		return this;
	}

	public boolean isNextEnabled() {
		return seleniumCommands.getAttributeValueAtLocator(NEXT_BTN, "disabled") == null;
	}

	//use cancelWizardxx method for specific portal instead
	@Deprecated
	public CP_ClaimListPage cancelClaim() {
		clickCancel();
		new AlertHandler().closeClaimSubmissionAlert();
		return new CP_ClaimListPage();
	}

	// Validation

	public Validation validateDateOfLossFieldError() {
		logger.info("Validating the date Error for Date of loss field");
		seleniumCommands.waitForElementToBeVisible(DATE_ERROR_XPATH);
		return new Validation(seleniumCommands.getTextAtLocator(DATE_ERROR_XPATH), DataConstant.DATE_PAST_ERROR);
	}

	public Validation verifyNoPolicyListingWhenDOLNotMatchingPolicyValidity() {
		logger.info("Validating that policy is not listed");
		seleniumCommands.waitForElementToBeVisible(NO_POLICY_ERROR_CSS);
		return new Validation(seleniumCommands.getTextAtLocator(NO_POLICY_ERROR_CSS), DataConstant.NO_POLICY_LISTED_ERROR);
	}

	public Validation verifySearchReturnedNoPolicyError() {
		logger.info("Validating that policy is not listed by search criteria");
		return new Validation(seleniumCommands.getTextAtLocator(NO_POLICY_SEARCH_ERROR_CSS), DataConstant.NO_POLICY_LISTED_ERROR);
	}

	public Validation isNextButtonDisabledBeforePolicySelection() {
		logger.info("Validating if Next button is disabled before policy selection");
		return new Validation(seleniumCommands.isElementPresent(NEXT_BTN_DISABLED), "true");
	}

	public Validation isPolicyListedForSelection() {
		logger.info("Validating the policy listing on the list");
		seleniumCommands.waitForElementToBeVisible(POLICY_SEARCH_RESULT_TABLE_CSS);
		return new Validation(seleniumCommands.isElementPresent(By.xpath(POLICY_XPATH.replace("POLICYNUM", data.get("POLICY_NUM")))));
	}

	public Validation isPolicyListedForSelection(String policyNumber) {
		logger.info("Validating the policy listing on the list");
		seleniumCommands.waitForElementToBeVisible(POLICY_SEARCH_RESULT_TABLE_CSS);
		return new Validation(seleniumCommands.isElementPresent(By.xpath(POLICY_XPATH.replace("POLICYNUM", policyNumber))));
	}

	public Validation validatePolicyResetButton() {
		logger.info("Validating the policy search reset button functionality");
		new Validation(seleniumCommands.getTextAtLocator(FIRSTNAME_TXT_CSS), "").shouldBeEqual("First name value is not reset");
		new Validation(seleniumCommands.getTextAtLocator(LASTNAME_TXT_CSS), "").shouldBeEqual("Last name value is not reset");;
		new Validation(seleniumCommands.getTextAtLocator(CITY_TXT_CSS), "").shouldBeEqual("City value is not reset");;
		new Validation(seleniumCommands.getTextAtLocator(ZIP_TXT_CSS), "").shouldBeEqual("Zip code value is not reset");;
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS), "-- Choose State --").shouldBeEqual("State value is not reset");;
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(POLICYTYPE_DROP_CSS), "-- Choose Policy Type --").shouldBeEqual("Policy Type value is not reset");;
		return new Validation(true);
	}

	private Validation onlyPolicyListed(PolicyType policyType) {
		logger.info("Validating the policy type [" + policyType + "] on the list");
		String policyTypeAsIconTitle = policyType.getIconType();
		logger.info("POLICY NAME: " + policyTypeAsIconTitle);
		for(WebElement el : seleniumCommands.findElements(LIST_POLICY_TYPE_XPATH)) {
			String title = seleniumCommands.getAttributeValueAtLocator(el, "title");
			logger.info("ICON TITLE: " + title);
			if(! title.equals(policyTypeAsIconTitle) )
				return new Validation(false);
		}
		return new Validation(true);
	}

	public Validation onlyHOPolicyListed() {
		return onlyPolicyListed(PolicyType.HO);
	}

	public Validation validateDateOfLossRequiredError() {
		logger.info("Validating is next button is disabled when date of loss field is empty.");
		return new Validation(isNextEnabled());
	}

}
