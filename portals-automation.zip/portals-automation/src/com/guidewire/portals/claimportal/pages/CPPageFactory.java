package com.guidewire.portals.claimportal.pages;
import java.util.Map;
import java.util.HashMap;
import com.guidewire.capabilities.fnol.data.FnolData;
import com.guidewire.data.ClaimType;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;

public class CPPageFactory {

	private final Logger logger = Logger.getLogger(this.getClass().getName());
	protected SeleniumCommands seleniumCommands = new SeleniumCommands();
	private static final String FILE_CLAIM_CSS = "a[href='#/fnol']";
	private static final By CLAIM_SEARCH_RESULT_CSS = By.cssSelector("table[class*='gw-table ng-scope'] tbody tr, [list='pageListData.items'], [ng-hide*='failToGetClaims'][aria-hidden='false']");

	public CPPageFactory() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public NewClaimContactPersonPage createCollisionClaim() {
		logger.info("Creating Collision Claim");
		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.selectCollisionClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withPropDamageDetails()
				.goToVehicleDriverPage()
				.selectFirstAvailableDriver()
				.selectFirstAvailableVehicle()
				.setVehicleSafetyToDrive()
				.setAirBagDeployStatus()
				.setEquiFailureStatus()
				.setVehicleTowStatus()
				.setVehicleRentalStatus()
				.setVehicleCollisionPoint()
				.withNewPassenger()
				.goToRepairChoicePage()
				.selectNoFacility()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}

	public NewClaimContactPersonPage createCollisionWithVehicleClaim() {
		this.setDataForPAClaimType();
		this.setDataForCollisionWithVehicleLossType();
		this.setDataForDefaultCityOnlyLocation();
		this.setDataForPassenger();
		this.setDataForInjuredPerson();
		return this.createCollisionClaim();
	}

	public NewClaimRepairChoicePage createCollisionClaimForVendorChoice() {
		logger.info("Creating Collision Claim");
		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.selectCollisionClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withPropDamageDetails()
				.goToVehicleDriverPage()
				.selectFirstAvailableDriver()
				.selectFirstAvailableVehicle()
				.setVehicleSafetyToDrive()
				.setAirBagDeployStatus()
				.setEquiFailureStatus()
				.setVehicleTowStatus()
				.setVehicleRentalStatus()
				.setVehicleCollisionPoint()
				.withNewPassenger()
				.goToRepairChoicePage();
	}

	public NewClaimRepairChoicePage createCollisionClaimWithDefaultForVendorChoice() {
		logger.info("Creating Collision Claim");
		this.setDataForPAClaimType();
		this.setDataForCollisionWithVehicleLossType();
		this.setDataForDefaultCityOnlyLocation();

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.goNext()
				.withLossLocation()
				.goToVehicleDriverPage()
				.selectFirstAvailableDriver()
				.selectFirstAvailableVehicle()
				.goToRepairChoicePage();
	}

	public NewClaimRepairChoicePage createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice() {
		logger.info("Creating Collision Claim");
		this.setDataForPAClaimType();
		this.setDataForDefaultCityOnlyLocation();
		FnolData.setFirstOtherCarDefaultData();
		FnolData.setSecondOtherCarDefaultData();
		FnolData.setFirstOtherDriverDefaultData();
		FnolData.setSecondOtherDriverDefaultData();

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.goNext()
				.withLossLocation()
				.goToVehicleDriverPage()
				.selectFirstAvailableDriver()
				.selectFirstAvailableVehicle()
				.addAdditionalVehicle()
				.selectOtherVehicleOnAdditionalVehiclePage()
				.withFirstOtherVehicle()
				.selectOtherDriverOnAdditionalVehiclePage()
				.withFirstOtherDriver()
				.addAdditionalVehicle(2)
				.selectOtherVehicleOnAdditionalVehiclePage(2)
				.withSecondOtherVehicle()
				.selectOtherDriverOnAdditionalVehiclePage(2)
				.withSecondOtherDriver()
				.goToRepairChoicePage();
	}

	protected void setDataForDefaultCityOnlyLocation() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("LossLocationInput", "CityOnly");
		data.putIfAbsent("City", "San Francisco");
		data.putIfAbsent("State", "California");
	}

	private void setDataForPAClaimType() {
		ThreadLocalObject.getData().putIfAbsent("ClaimType", "PersonalAuto");
	}

	private void setDataForCollisionWithVehicleLossType() {
		Map<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("ClaimSubType", "Collision");
		data.putIfAbsent("ClaimTypeCollision", "Collision with motor vehicle");
	}

	private void setDataForInjuredPerson() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		String firstName = "FirstName1";
		String lastName = "LastName1";

		data.putIfAbsent("FirstNameNewPerson", firstName);
		data.putIfAbsent("LastNameNewPerson", lastName);
		data.putIfAbsent("NewPersonInvolvementWitness", "Witness");
		data.putIfAbsent("NewPersonHomePhone", "202-555-0146");
		data.putIfAbsent("NewPersonInjured", "Yes");
		data.putIfAbsent("StateNewContact", "California");
		data.putIfAbsent("CityNewContact", "Foster City");
		data.putIfAbsent("EXISTING_CONTACT", firstName + " " + lastName);
	}

	private void setDataForPassenger() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("FirstNamePassenger1", "FirstName1");
		data.putIfAbsent("LastNamePassenger1", "LastName1");
		data.putIfAbsent("PassengerHomePhone", "202-555-0122");
	}

	public NewClaimContactPersonPage createTheftVehicleStolenClaimWithDefaultData() {
		this.setDataForDefaultCityOnlyLocation();
		this.setDataForInjuredPerson();

		return createTheftVehicleStolenClaim();
	}

	public NewClaimRepairChoicePage createTheftClaimForVendorChoiceWithDefaultData() {
		this.setDataForDefaultCityOnlyLocation();
		this.setDataForInjuredPerson();

		return createTheftClaimForVendorChoice();
	}

	public NewClaimContactPersonPage createTheftVehicleStolenWithDefaultData() {
		this.setDataForDefaultCityOnlyLocation();
		this.setDataForInjuredPerson();

		return createTheftVehicleStolenClaim();
	}

	public NewClaimContactPersonPage createTheftVehicleStolenClaim() {
		ThreadLocalObject.getData().put("TheftType", "VehicleStolen");
		return this.createTheftClaim();
	}

	public NewClaimContactPersonPage createTheftClaim() {
		logger.info("Creating Theft Claim");
		this.setDataForPAClaimType();
		ThreadLocalObject.getData().put("ClaimSubType", "Theft");

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withVehicleInvolved()
				.withTheftVehicleDamageDetails()
				.goToRepairChoicePage()
				.selectNoFacility()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}

	public NewClaimRepairChoicePage createTheftClaimForVendorChoice() {
		logger.info("Creating Theft Claim");
		this.setDataForPAClaimType();
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withVehicleInvolved()
				.withTheftVehicleDamageDetails()
				.goToRepairChoicePage();
	}

	public NewClaimRepairChoicePage createGlassClaimForVendorChoiceWithDefaultData() {
		this.setDataForDefaultCityOnlyLocation();
		this.setDataForInjuredPerson();

		return createGlassClaimForVendorChoice();
	}

	public NewClaimContactPersonPage createGlassClaim() {
		logger.info("Creating PA Glass Claim");
		this.setDataForPAClaimType();
		ThreadLocalObject.getData().put("ClaimSubType", "Glass");

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withVehicleInvolved()
				.goToRepairChoicePage()
				.selectNoFacility()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}

	public NewClaimRepairChoicePage createGlassClaimForVendorChoice() {
		logger.info("Creating PA Glass Claim(with vendor choice)");
		this.setDataForPAClaimType();
		ThreadLocalObject.getData().put("ClaimSubType", "Glass");

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.goNext()
				.withLossLocation()
				.withClaimDescription()
				.withVehicleInvolved()
				.goToRepairChoicePage();
	}

	public ContactUSPage createPAOtherClaim() {
		logger.info("Creating Other Claim");
		this.setDataForPAClaimType();

		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectPAClaimType()
				.goToContactUsPage();
	}

	public ContactUSPage createHOOtherClaim() {
		logger.info("Creating Glass Claim");
		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectHOClaimType()
				.goToContactUsPage();
	}

	@Deprecated
	public Object loginOpenAM() {
		logger.info("Logging open AM");
		try {
			new LoginPage().login();
			seleniumCommands.waitForElementToBeVisible(By.cssSelector(FILE_CLAIM_CSS));
		} catch (Exception e) {
			logger.error(e);
		}
		return new ClaimListPage();
	}

	public CP_ClaimListPage login() {
		logger.info("Logging open");
		try {
			new LoginPage().login();
			seleniumCommands.waitForElementToBeVisible(CLAIM_SEARCH_RESULT_CSS);
		} catch (Exception e) {
			logger.error(e);
		}
		return new CP_ClaimListPage();
	}

	public NewClaimContactPersonPage createFireClaim() {
		logger.info("Creating Fire Claim");
		CP_ClaimListPage claimListPage =  login();
		return claimListPage.fileAClaim()
				.selectPolicy()
				.goNext()
				.selectHOClaimType()
				.goToFireDamageDetailsPage()
				.setFireDetails()
				.withHomeHabitableValue()
				.withHomeSecureValue()
				.goNext()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}


	public NewClaimContactPersonPage createWaterClaim() {
		logger.info("Creating Water Claim");
		return this.startAClaim()
				.selectHOClaimType()
				.goToWaterDamageDetailsPage()
				.setWaterDamageDetails()
				.goNext()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}

	public NewClaimContactPersonPage createHODefaultClaim() {
		logger.info("Creating HO Default Claim");
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("FireCause","Short Circuit");
		data.put("FireDiscovery","Smoke");
		data.put("HomeSecure","Yes");
		data.put("LOSS_DESC","House on Fire");
		data.put("HomeHabitable","Yes");
		return this.login().fileAClaim()
				.selectPolicy().goNext().selectHOClaimType().goToFireDamageDetailsPage().setFireDetails().goNext().withNewContactPerson().goNext().withNewContactPerson().withContactCellNum();
}
	private void setHOCrimeClaim() {
		Map data = ThreadLocalObject.getData();
		data.put("ClaimType", "HomeOwner");
		data.put("ClaimSubType", "Crime");
	}

	public NewClaimContactPersonPage createDefaultBurglaryCrimeClaim() {
		logger.info("Creating default HO Burglary Crime Claim");
		this.setHOCrimeClaim();
		Map data = ThreadLocalObject.getData();
		data.put("LOSS_DESC", "Crime scene description");
		data.put("CrimeDamageType", "Burglary");

		return this.startAClaim()
				.selectHOClaimType()
				.goToCrimeDetailsPage()
				.setCrimeDetails()
				.goNext()
				.goNext();
	}

	public NewClaimContactPersonPage createCrimeClaim() {
		logger.info("Creating HO Crime Claim");
		return this.startAClaim()
				.selectHOClaimType()
				.goToCrimeDetailsPage()
				.setCrimeDetails()
				.goNext()
				.uploadDocFromFNOL()
				.withNewContactPerson()
				.goNext();
	}

	public NewClaimContactPersonPage createGeneralClaim() {

		logger.info("Creating General Claim");
		return this.startAClaim()
				.selectGeneralClaimType()
				.setGeneralLossDesc()
				.setGeneralDamageDesc()
				.goToGeneralDetailsPage()
				.getLossLocationAddressData()
				.goNext()
				.uploadDocFromFNOL()
				.goNext();
	}

	public NewClaimContactPersonPage createWCClaim() {
		logger.info("Creating WC Claim");
		ThreadLocalObject.getData().putIfAbsent("ClaimType", "WorkersComp");

		return this.startAClaim()
				.selectWCClaimType()
				.setWCLossDesc()
				.setNotificationDateInThePast()
				.setInjuredEmployeeName()
				.setInjuredEmployeeDateOfBirth()
				.setInjuredEmployeeGender()
				.setInjuredEmployeePhone()
				.setInjuredEmployeeSSN()
				.setInjuredEmployeeAddress()
				.goToWCInjuryDetailsPage()
				.selectInjuryType()
				.setDeathReport(false)
				.setLostTimeFromWork(false)
				.setEmploymentInjury(false)
				.setMedicalTreatment(false)
				.goNext()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext();
	}

	public NewClaimWhatHappenedPage startAClaim() {
		CP_ClaimListPage claimListPage =  login();
		return claimListPage
				.fileAClaim()
				.selectPolicy()
				.goNext();
	}

	public NewClaimWhatHappenedPage startWCClaimWithDefaultData() {
		this.setWCInjuredEmployeeDefaultData();

		return this.startAClaim();
	}

	public CPPageFactory setWCInjuredEmployeeDefaultData() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("ClaimType", "WorkersComp");
		data.putIfAbsent("LOSS_CAUSE", "Miscellaneous causes");
		data.putIfAbsent("LossDescription", "Miscellaneous causes description data");
		data.putIfAbsent("EmployeeFName", "Jon");
		data.putIfAbsent("EmployeeLName", "Doe");
		data.putIfAbsent("AddressLine1", seleniumCommands.generateUUID());
		data.putIfAbsent("City", seleniumCommands.generateUUID());
		data.putIfAbsent("Zip", "94404");
		data.putIfAbsent("State", "California");
		data.putIfAbsent("InjuryType", "Angina pectoris");
		data.putIfAbsent("InjuryDesc", "Angina pectoris description data");
		return this;
	}

	public NewClaimWhatHappenedPage setWCInjuredEmployeeAllData() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("AddressLine2", "AddressLine 2");
		data.putIfAbsent("AddressLine3", "AddressLine 3");
		data.putIfAbsent("InjuredEmployeePhone", "202-555-0123");
		data.putIfAbsent("InjuredEmployeeSSN", "12-3456789");
		setWCInjuredEmployeeDefaultData();
		return this.startAClaim();
	}

	public NewClaimContactPersonPage createWCClaimWWitDefaultMedicalTreatment() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.putIfAbsent("LOSS_CAUSE", "Miscellaneous causes");
		data.putIfAbsent("DoctorFName", "Doctor Who");
		data.putIfAbsent("DoctorLName", "Doctor WhoLN");

		return this.setWCInjuredEmployeeAllData()
				.selectWCClaimType()
				.setWCLossDesc()
				.setNotificationDateInThePast()
				.setInjuredEmployeeName()
				.setInjuredEmployeeDateOfBirth()
				.setInjuredEmployeeGender()
				.setInjuredEmployeePhone()
				.setInjuredEmployeeSSN()
				.setInjuredEmployeeAddress()
				.goToWCInjuryDetailsPage()
				.selectInjuryType()
				.setInjuryDescription()
				.setDeathReport(false)
				.setLostTimeFromWork(false)
				.setEmploymentInjury(false)
				.setMedicalTreatment(true)
				.setDoctorFName()
				.setDoctorLName()
				.setMedicalExaminationDateInThePast()
				.goNext()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext();
	}

	private NewClaimPropertiesSelectionPage startBasicCPClaim() {
		return login()
				.fileAClaim()
				.selectPolicy()
				.goToWhatPage()
				.selectLossCause()
				.setNoticeDate()
				.goToProperties();
	}

	public NewClaimContactPersonPage createBasicCPClaimWithDefault() {
		logger.info("Creating Commercial Property Claim");
		this.setDataForCPClaimType();
		this.setDataForDefaultCityOnlyLocation();

		return startBasicCPClaim()
			.selectProperties(1)
			.goNext()
			.goNext()
			.withLossLocation()
			.goToDocumentPage()
			.uploadDocFromFNOL()
			.goNext();
	}

	public PropertyDetailsPage openBasicCPClaimWithMultiplePropertiesSelected(int propertiesAmount) {
		logger.info("Creating Commercial Property Claim");
		this.setDataForCPClaimType();
		this.setDataForDefaultCityOnlyLocation();

		return startBasicCPClaim()
			.selectProperties(propertiesAmount)
			.goNext();
	}

	public NewClaimPropertiesSelectionPage createBasicCPClaimForPropertySelection() {
		logger.info("Creating Commercial Property Claim");
		this.setDataForCPClaimType();
		this.setDataForDefaultCityOnlyLocation();

		return login()
				.fileAClaim()
				.selectPolicy()
				.goToWhatPage()
				.selectLossCause()
				.setNoticeDate()
				.goToProperties();
	}

	private void setDataForCPClaimType() {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put(ClaimType.typeName, ClaimType.CP.lob());
		data.put("LOSS_CAUSE", "Fire");
		data.put("LossDescription", "CP LossDescription");
	}
}
