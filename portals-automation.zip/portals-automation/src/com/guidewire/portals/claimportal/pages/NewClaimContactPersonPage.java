package com.guidewire.portals.claimportal.pages;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.AlertHandler;

import io.restassured.path.json.JsonPath;

public class NewClaimContactPersonPage extends ClaimWizardPage {

	@FindBy(css = "[ng-model='claimSubmitCtxModel.mainContact.value']")
	WebElement CONTACT_DROP_CSS;

	@FindBy(css = "[model='contact.firstName'] input")
	WebElement FIRSTNAME_VALUE_CSS;
	
	@FindBy(css = "[model='contact.lastName'] input")
	WebElement LASTNAME_VALUE_CSS;	
	
	@FindBy(css = "[model='address.addressLine1'] input")
	WebElement ADDRESS_LINE1_TXT_CSS;
	
	@FindBy(css = "[model='address.addressLine2'] input")
	WebElement ADDRESS_LINE2_TXT_CSS;
	
	@FindBy(css = "[model='address.addressLine3'] input")
	WebElement ADDRESS_LINE3_TXT_CSS;
	
	@FindBy(css = "[model='address.city'] input")
	WebElement CITY_TXT_CSS;
	
	@FindBy(css = "[model='address.postalCode'] input")
	WebElement ZIPCODE_TXT_CSS;
	
	@FindBy(css = "[model='address.state'] select")
	WebElement STATE_DROP_CSS;
	
	@FindBy(css = "[model='address.addressLine1'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement ADDRESS_LINE1_VALUE_CSS;
	
	@FindBy(css = "[model='address.addressLine2'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement ADDRESS_LINE2_VALUE_CSS;
	
	@FindBy(css = "[model='address.addressLine3'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement ADDRESS_LINE3_VALUE_CSS;
	
	@FindBy(css = "[model='address.city'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement CITY_VALUE_CSS;
	
	@FindBy(css = "[model='address.postalCode'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement ZIPCODE_VALUE_CSS;
	
	@FindBy(css = "[model='address.state'] span[class='gw-non-input-field ng-binding ng-scope']")
	WebElement STATE_VALUE_CSS;
	
	@FindBy(css = "[ng-model='phone.homeNumber.value']")
	WebElement HOMENUM_TXT_CSS;
	
	@FindBy(css = "[ng-model='phone.workNumber.value']")
	WebElement WORKNUM_TXT_CSS;
	
	@FindBy(css = "[ng-model='phone.cellNumber.value']")
	WebElement CELLNUM_TXT_CSS;
	
	@FindBy(css = "[model='claimSubmitCtxModel.mainContact.emailAddress1'] input")
	WebElement EMAIL_TXT_CSS;
	
	@FindBy(css = "[model='claimSubmitCtxModel.mainContact.emailAddress1'] label")
	WebElement EMAIL_LBL_CSS;
	
	@FindBy(css = "[for*='HomeNumberPrimaryPhoneType']")
	WebElement HOME_NUM_RDBTN_CSS;
	
	@FindBy(css = "[for*='WorkNumberPrimaryPhoneType']")
	WebElement WORK_NUM_RDBTN_CSS;
	
	@FindBy(css = "[for*='CellNumberPrimaryPhoneType']")
	WebElement CELL_NUM_RDBTN_CSS;

	@FindBy(xpath = "//*[@class='gw-alert__content']/..")
	WebElement CONTACT_NUM_REQUIRED_ERR_CSS;
	
	@FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;
	
	String FIRST_NAME_INPUT_CSS = "[model='contact.firstName'] input";
	
	HashMap<String, String> data = ThreadLocalObject.getData();
	
	
	public NewClaimContactPersonPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public Validation isPageLoaded() {
		return new Validation(seleniumCommands.isElementPresent(CONTACT_DROP_CSS));
	}

	public NewClaimDocumentPage getBackToDocumentPage() {
		logger.info("Going to repair choice page");
		clickPrevious();
		return new NewClaimDocumentPage();
	}

	public NewClaimContactPersonPage withNewContactPerson() {
		this.addNewContact();
		this.setNewContactPersonDetails();
		return this;
	}
	
	public NewClaimContactPersonPage setNewContactPersonDetails() {
		seleniumCommands.type(FIRSTNAME_VALUE_CSS, data.get("FirstNameNewContact"));
		seleniumCommands.type(LASTNAME_VALUE_CSS, data.get("LastNameNewContact"));
		seleniumCommands.type(ADDRESS_LINE1_TXT_CSS, data.get("AddLine1NewContact"));
		seleniumCommands.type(ADDRESS_LINE2_TXT_CSS, data.get("AddLine2NewContact"));
		seleniumCommands.type(ADDRESS_LINE3_TXT_CSS, data.get("AddLine3NewContact"));
		seleniumCommands.type(CITY_TXT_CSS, data.get("CityNewContact"));
		seleniumCommands.type(ZIPCODE_TXT_CSS, data.get("ZipNewContact"));
		this.withState();
		return this;
	}

	private void typeGivenNumber(String numberName, WebElement fieldSelector) {
		String number = data.get(numberName);
		if (number != null && !number.isEmpty()) {
			seleniumCommands.type(fieldSelector, number);
		}
		
		JsonPath path = new JsonPath(DataFetch.getAccountPolicyData(data.get(PolicyData.POLICY_NUM.toString())));
		int contactList = path.getList("currentPeriod.contacts").size();
		
		String contactPerson = seleniumCommands.getSelectedOptionFromDropDown(CONTACT_DROP_CSS);
		String contactAddress = null;
		for (int i = 0; i <contactList; i++) {
			String currentSelector = "currentPeriod.contacts[" + i + "].contact";
			String displayName = DataFormatUtil.getNodeValue(path , currentSelector, "displayName");
			if (displayName.equalsIgnoreCase(contactPerson)) {
				if(System.getProperty("platform").equals("Diamond")){
					contactAddress = DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "addressLine1") + " "
							+ DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "addressLine2")+ " ";
					if(DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "addressLine3") != null)
						contactAddress += DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "addressLine3")+ " ";
					contactAddress += DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "city")+ " "
							+ DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "state")+ " "
							+ DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "postalCode");
				}else
					contactAddress = DataFormatUtil.getNodeValue(path, currentSelector + ".primaryAddress", "displayName");
				break;
			}
		}

		String displayAddress = ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.GPA.toString()) ? DataFormatUtil.getNodeValue( new JsonPath(DataFetch.getAgentPolicyData(data.get("POLICY_NUM"))), "contacts[0].contact.primaryAddress", "displayName") :  contactAddress;
		data.put(ClaimData.DRIVER_ADDRESS_DISPLAY_NAME.getValue(), displayAddress);
		if(!seleniumCommands.isElementPresent(By.cssSelector(FIRST_NAME_INPUT_CSS)))
		{
			data.put(ClaimData.INSURED_DISPLAY_NAME.getValue(), contactPerson);
			data.put(ClaimData.MAIN_CONTACT_DISPLAY_ADDRESS.getValue(), displayAddress);
			data.put(ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(), contactPerson);
			data.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(), contactPerson);
		}
		else
		{
			data.put(ClaimData.INSURED_DISPLAY_NAME.getValue(), data.get(ClaimData.DRIVER_DISPLAY_NAME.getValue()));
			data.put(ClaimData.MAIN_CONTACT_DISPLAY_ADDRESS.getValue(),
					data.get("AddLine1NewContact") + " "+
					data.get("AddLine2NewContact") + " "+
					data.get("AddLine3NewContact") + " " +
					data.get("CityNewContact") +  " "+
					data.get("StateValueNewContact") + " " +
					data.get("ZipNewContact")) ;
			data.put(ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(), data.get(ClaimData.DRIVER_DISPLAY_NAME.getValue()));
			data.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(), data.get("FirstNameNewContact") +  " "+ data.get("LastNameNewContact"));
		}
	}
	
	public NewClaimContactPersonPage withContactHomeNum() {
		typeGivenNumber("HomePhoneNewContact", HOMENUM_TXT_CSS);
	//	seleniumCommands.click(HOME_NUM_RDBTN_CSS);
		withContactEmail();
		return this;
	}
	
	public NewClaimContactPersonPage withContactWorkNum() {
		typeGivenNumber("WorkPhoneNewContact", WORKNUM_TXT_CSS);
	//	seleniumCommands.click(WORK_NUM_RDBTN_CSS);
		withContactEmail();
		return this;
	}
	
	public NewClaimContactPersonPage withContactCellNum() {
		typeGivenNumber("CellPhoneNewContact", CELLNUM_TXT_CSS);
	//	seleniumCommands.click(CELL_NUM_RDBTN_CSS);
		withContactEmail();
		return this;
	}
	
	public NewClaimContactPersonPage withContactEmail() {
		seleniumCommands.type(EMAIL_TXT_CSS, data.get("EmailNewContact"));
		return this;
	}

	public NewClaimContactPersonPage withCity() {
		seleniumCommands.type(CITY_TXT_CSS, data.get("CityNewContact"));
		return this;
	}

	public NewClaimContactPersonPage withoutHomeNumber() {
		seleniumCommands.type(HOMENUM_TXT_CSS, "");
		return this;
	}

	public NewClaimContactPersonPage withoutCellNumber() {
		seleniumCommands.type(CELLNUM_TXT_CSS, "");
		return this;
	}

	public NewClaimContactPersonPage withoutWorkNum() {
		seleniumCommands.type(WORKNUM_TXT_CSS,"");
		return this;
	}

	public NewClaimContactPersonPage withState() {
		seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get("StateNewContact"));
		return this;
	}

	public NewClaimContactPersonPage withContactEmail(String email) {
		seleniumCommands.type(EMAIL_TXT_CSS, email);
		CELLNUM_TXT_CSS.click();
		return this;
	}
	
	public NewClaimContactPersonPage selectContact() {
		return this.selectContact(data.get("EXISTING_CONTACT"));
	}

	public NewClaimContactPersonPage selectContact(String contact) {
		seleniumCommands.selectDropDownValueByText(CONTACT_DROP_CSS, contact);
		return this;
	}
	
	public NewClaimContactPersonPage addNewContact() {
		seleniumCommands.selectDropDownValueByText(CONTACT_DROP_CSS, "Other Person");
		return this;
	}
	
	public NewClaimSummaryPage goToSummary() {
		goNext();
		return new NewClaimSummaryPage();
	}
	
	public AlertHandler cancelClaim() {
		pressCancelClaim();
		new AlertHandler().closeClaimSubmissionAlert();
		return new AlertHandler();
	}
	
	public AlertHandler pressCancelClaim() {
		clickCancel();
		return new AlertHandler();
	}
	
	public NewClaimContactPersonPage goNext() {
		seleniumCommands.clickbyJS(CELLNUM_TXT_CSS);
		clickNext();
		return this;
	}

	// Get Method
	public String getDraftClaimNumber() {
		return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}
	
	//Validation
	
	public Validation validatePhoneNumberMissingErrorOnOnContactPage() {
		logger.info("Validating the Error message for mandatory Contact Number");
		return new Validation(seleniumCommands.getTextAtLocator(CONTACT_NUM_REQUIRED_ERR_CSS), DataConstant.CONTACT_NUM_REQUIRED_ERROR);
	}
	
	public Validation validateEmailFieldOnSummaryPage() {
		logger.info("Validating the Error message for Email format");
		this.withContactEmail("test").goNext().validateEmailFieldErrorMessage().shouldBeEqual("Email error is not correct");
		this.withContactEmail("test@").goNext().validateEmailFieldErrorMessage().shouldBeEqual("Email error is not correct");
		this.withContactEmail("test@dd").goNext().validateEmailFieldErrorMessage().shouldBeEqual("Email error is not correct");
		this.withContactEmail("test@dd.").goNext().validateEmailFieldErrorMessage().shouldBeEqual("Email error is not correct");
		return new Validation(true);
	}
	
	private Validation validateEmailFieldErrorMessage() {
		return new Validation(seleniumCommands.getErrorMessageForTxtBox(EMAIL_TXT_CSS), DataConstant.EMAIL_FORMAT_ERROR);
	}
	
	public Validation validateNewlyCreatedPersonListing() {
		System.out.println(seleniumCommands.getAllOptionsFromDropDown(CONTACT_DROP_CSS) + " " + data.get("NEW_PERSON_DISPLAY_NAME"));
		return new Validation(seleniumCommands.getAllOptionsFromDropDown(CONTACT_DROP_CSS).contains(data.get("NEW_PERSON_DISPLAY_NAME")));
	}
	
	public Validation validateMandatoryErrorMessageForNewPersonFields() {
		new Validation(seleniumCommands.getErrorMessageForTxtBox(FIRSTNAME_VALUE_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("FirstName mandatory error message is not correct");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(LASTNAME_VALUE_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("FirstName mandatory error message is not correct");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(CITY_TXT_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("FirstName mandatory error message is not correct");
		new Validation(seleniumCommands.getErrorMessageForTxtBox(STATE_DROP_CSS), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("FirstName mandatory error message is not correct");
		return new Validation(true);
	}
	
	public Validation areContactPersonDetailsAreSaved() {
		logger.info("Validating if New Contact details are saved");
		seleniumCommands.selectDropDownValueByText(CONTACT_DROP_CSS, data.get("FirstNameNewContact") + " " +data.get("LastNameNewContact") );
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE1_TXT_CSS), data.get("AddLine1NewContact")).shouldBeEqual("New Contact Add line 1 is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE2_TXT_CSS), data.get("AddLine2NewContact")).shouldBeEqual("New Contact Add line 2 is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE3_TXT_CSS), data.get("AddLine3NewContact")).shouldBeEqual("New Contact Add line 3 is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(CITY_TXT_CSS), data.get("CityNewContact")).shouldBeEqual("New Contact city is not saved");
		new Validation(seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS), data.get("StateNewContact")).shouldBeEqual("New Contact state is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(ZIPCODE_TXT_CSS), data.get("ZipNewContact")).shouldBeEqual("New Contact zip is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(WORKNUM_TXT_CSS), data.get("WorkPhoneNewContact")).shouldBeEqual("New Contact work Num is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(CELLNUM_TXT_CSS), data.get("CellPhoneNewContact")).shouldBeEqual("New Contact Cell Num is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(HOMENUM_TXT_CSS), data.get("HomePhoneNewContact")).shouldBeEqual("New Contact Home Num is not saved");
		new Validation(seleniumCommands.getValueAttributeFromLocator(EMAIL_TXT_CSS), data.get("EmailNewContact")).shouldBeEqual("New Contact email is not saved");
		return new Validation(true);
	}

	public NewClaimContactPersonPage setContactData() {
		data.put(ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(), seleniumCommands.getSelectedOptionFromDropDown(CONTACT_DROP_CSS));
		return this;
	}
}

