package com.guidewire.portals.claimportal.pages;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.dto.PropertyDTO;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.portals.qnb.pages.AlertHandler;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class PropertyDetailsPage extends ClaimWizardPage {

    private static final By LISTED_PROPERTIES = By.cssSelector("[ng-repeat='incident in propertyIncidentsVm.children']");
    private static final By ACCORDION_TRIGGER = By.cssSelector(".gw-accordion-chevron");
    private static final By LOCATION_CONTAINER = By.cssSelector("[ng-repeat='incident in propertyIncidentsVm.children']");
    private static final By LOCATION_NAME = By.cssSelector("h2");
    private static final By BUILDINGS = By.cssSelector("[ng-repeat='building in buildingsInLocation(incident)'] *");

    private static final By PROPERTY_DESCRIPTION_INPUT = By.cssSelector("[model='incident.propertyDescription'] input");
    private static final By DAMAGE_DESCRIPTION_INPUT = By.cssSelector("[model='incident.description'] textarea");
    private static final By REPAIR_ESTIMATE_SELECT = By.cssSelector("[model='incident.estimateReceived'] select");
    private static final By ESTIMATE_REPAIR_COST_INPUT = By.cssSelector("[model='incident.estRepairCost'] input");
    private static final By ESTIMATE_REPAIR_COST_ERROR = By.cssSelector("[model='incident.estRepairCost'] [class*='gw-error-inline']");
    private static final By ESTIMATE_REPAIR_TIME_INPUT = By.cssSelector("[model='incident.estRepairTime'] input");
    private static final By ESTIMATE_DAMAGE_SELECT = By.cssSelector("[model='incident.estDamage'] select");
    private static final By ESTIMATE_LOSS_INPUT = By.cssSelector("[model='incident.lossEstimate'] input");
    private static final By ESTIMATE_LOSS_ERROR = By.cssSelector("[model='incident.lossEstimate'] [class*='gw-error-inline']");
    private static final By ALREADY_REPAIRED_RADIO = By.cssSelector("[model='incident.alreadyRepaired']");
    private static final By CLASS_TYPE_SELECT = By.cssSelector("[model='incident.classType'] select");
    private static final By NUMBER_OF_STORIES_INPUT = By.cssSelector("[model='incident.numStories'] input");
    private static final By NUMBER_OF_STORIES_ERROR = By.cssSelector("[model='incident.numStories'] [class*='gw-error-inline']");
    private static final By ROOF_MATERIAL_SELECT = By.cssSelector("[model='incident.roofMaterial'] select");
    private static final By EXTERIOR_WALL_MATERIAL_SELECT = By.cssSelector("[model='incident.extWallMat'] select");
    private static final By TYPE_OF_OCCUPANCY_SELECT = By.cssSelector("[model='incident.typeOfOccupancy'] select");
    private static final By LOSS_AREA_SELECT = By.cssSelector("[model='incident.lossArea'] select");

    public PropertyDetailsPage() {
        super();
        seleniumCommands.waitForElementToBePresent(LISTED_PROPERTIES);
    }

    public NewClaimLocationPage goNext() {
        this.clickNext();
        return new NewClaimLocationPage();
    }

    public PropertyDetailsPage setDefaultPropertyData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.PROPERTY_DESCRIPTION.getValue(), "PropertyDescriptionExample");
        data.putIfAbsent(ClaimData.DAMAGE_DESCRIPTION.getValue(), "DamageDescriptionExample");
        data.putIfAbsent(ClaimData.REPAIR_ESTIMATE_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.ESTIMATE_REPAIR_COST.getValue(), "222.22");
        data.putIfAbsent(ClaimData.ESTIMATE_REPAIR_TIME.getValue(), "a few days");
        data.putIfAbsent(ClaimData.ESTIMATE_DAMAGE_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.ESTIMATE_LOSS.getValue(), "111.11");
        data.putIfAbsent(ClaimData.ALREADY_REPAIRED.getValue(), "true");
        data.putIfAbsent(ClaimData.CLASS_TYPE_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.NUMBER_OF_STORIES.getValue(), "11");
        data.putIfAbsent(ClaimData.ROOF_MATERIAL_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.EXTERIOR_WALL_MATERIAL_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.TYPE_OF_OCCUPANCY_INDEX.getValue(), "1");
        data.putIfAbsent(ClaimData.LOSS_AREA_INDEX.getValue(), "1");
        return this;
    }

    private void ensureLocationAccordionIsOpened(WebElement locationElement) {
        WebElement accordionTrigger = locationElement.findElement(ACCORDION_TRIGGER);
        if (!accordionTrigger.getAttribute("class").contains("gw-accordion-chevron_open")) {
            seleniumCommands.clickbyJS(accordionTrigger);
        }
    }

    private void waitForLocationElementsVisibility(WebElement locationElement) {
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(PROPERTY_DESCRIPTION_INPUT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(DAMAGE_DESCRIPTION_INPUT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(REPAIR_ESTIMATE_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ESTIMATE_DAMAGE_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ESTIMATE_LOSS_INPUT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ALREADY_REPAIRED_RADIO));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(CLASS_TYPE_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(NUMBER_OF_STORIES_INPUT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ROOF_MATERIAL_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(EXTERIOR_WALL_MATERIAL_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(TYPE_OF_OCCUPANCY_SELECT));
        seleniumCommands.waitForElementToBeVisible(locationElement.findElement(LOSS_AREA_SELECT));
    }

    private void ensureLocationDetailsAreAvailable(WebElement locationElement) {
        this.ensureLocationAccordionIsOpened(locationElement);
        this.waitForLocationElementsVisibility(locationElement);
    }

    private void provideDataForLocation(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        HashMap<String, String> data = ThreadLocalObject.getData();

        seleniumCommands.type(
                locationElement.findElement(PROPERTY_DESCRIPTION_INPUT),
                data.get(ClaimData.PROPERTY_DESCRIPTION.getValue())
        );
        seleniumCommands.type(
                locationElement.findElement(DAMAGE_DESCRIPTION_INPUT),
                data.get(ClaimData.DAMAGE_DESCRIPTION.getValue())
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(REPAIR_ESTIMATE_SELECT),
                Integer.parseInt(data.get(ClaimData.REPAIR_ESTIMATE_INDEX.getValue()))
        );

        if (data.get(ClaimData.REPAIR_ESTIMATE_INDEX.getValue()).equals("1")) {
            seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ESTIMATE_REPAIR_COST_INPUT));
            seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ESTIMATE_REPAIR_TIME_INPUT));
            seleniumCommands.type(
                    locationElement.findElement(ESTIMATE_REPAIR_COST_INPUT),
                    data.get(ClaimData.ESTIMATE_REPAIR_COST.getValue())
            );
            seleniumCommands.type(
                    locationElement.findElement(ESTIMATE_REPAIR_TIME_INPUT),
                    data.get(ClaimData.ESTIMATE_REPAIR_TIME.getValue())
            );
        }

        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(ESTIMATE_DAMAGE_SELECT),
                Integer.parseInt(data.get(ClaimData.ESTIMATE_DAMAGE_INDEX.getValue()))
        );
        seleniumCommands.type(
                locationElement.findElement(ESTIMATE_LOSS_INPUT),
                data.get(ClaimData.ESTIMATE_LOSS.getValue())
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(CLASS_TYPE_SELECT),
                Integer.parseInt(data.get(ClaimData.CLASS_TYPE_INDEX.getValue()))
        );
        seleniumCommands.type(
                locationElement.findElement(NUMBER_OF_STORIES_INPUT),
                data.get(ClaimData.NUMBER_OF_STORIES.getValue())
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(ROOF_MATERIAL_SELECT),
                Integer.parseInt(data.get(ClaimData.ROOF_MATERIAL_INDEX.getValue()))
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(EXTERIOR_WALL_MATERIAL_SELECT),
                Integer.parseInt(data.get(ClaimData.EXTERIOR_WALL_MATERIAL_INDEX.getValue()))
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(TYPE_OF_OCCUPANCY_SELECT),
                Integer.parseInt(data.get(ClaimData.TYPE_OF_OCCUPANCY_INDEX.getValue()))
        );
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(LOSS_AREA_SELECT),
                Integer.parseInt(data.get(ClaimData.LOSS_AREA_INDEX.getValue()))
        );

        this.selectYesNo(
            Boolean.valueOf(data.get(ClaimData.ALREADY_REPAIRED.getValue())),
            locationElement.findElement(ALREADY_REPAIRED_RADIO)
        );
    }

    public PropertyDetailsPage selectRepairEstimate() {
        return this.selectRepairEstimate(0);
    }

    public PropertyDetailsPage selectRepairEstimate(int locationIndex) {
        return this.selectRepairEstimate(seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex));
    }

    public PropertyDetailsPage selectRepairEstimate(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        seleniumCommands.selectFromDropdownByIndex(
                locationElement.findElement(REPAIR_ESTIMATE_SELECT),
                Integer.parseInt(ThreadLocalObject.getData().get(ClaimData.REPAIR_ESTIMATE_INDEX.getValue()))
        );
        return this;
    }

    public PropertyDetailsPage setEstimatedRepairCost() {
        return this.setEstimatedRepairCost(0);
    }

    public PropertyDetailsPage setEstimatedRepairCost(int locationIndex) {
        return this.setEstimatedRepairCost(seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex));
    }

    public PropertyDetailsPage setEstimatedRepairCost(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        String value = data.get(ClaimData.ESTIMATE_REPAIR_COST.getValue());
        logger.info("Setting Estimate repair cost: " + value);
        if (data.get(ClaimData.REPAIR_ESTIMATE_INDEX.getValue()).equals("1")) {
            seleniumCommands.waitForElementToBeVisible(locationElement.findElement(ESTIMATE_REPAIR_COST_INPUT));
            seleniumCommands.type(
                    locationElement.findElement(ESTIMATE_REPAIR_COST_INPUT),
                    value + Keys.TAB
            );
        }
        return this;
    }

    public Validation validateEstimatedRepairCostErrorMessage(String errorMessage) {
        return this.validateEstimatedRepairCostErrorMessage(0, errorMessage);
    }

    public Validation validateEstimatedRepairCostErrorMessage(int locationIndex, String errorMessage) {
        return this.validateEstimatedRepairCostErrorMessage(
                seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex),
                errorMessage);
    }

    public Validation validateEstimatedRepairCostErrorMessage(WebElement locationElement, String errorMessage) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        logger.info("Validating the Error for Estimated Repair Cost field.");
        return this.validateErrorMessage(
                locationElement,
                ESTIMATE_REPAIR_COST_ERROR,
                errorMessage);
    }

    public PropertyDetailsPage setEstimateOfLoss() {
        return this.setEstimateOfLoss(0);
    }

    public PropertyDetailsPage setEstimateOfLoss(int locationIndex) {
        return this.setEstimateOfLoss(seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex));
    }

    public PropertyDetailsPage setEstimateOfLoss(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        String value = data.get(ClaimData.ESTIMATE_LOSS.getValue());
        logger.info("Setting Estimate of loss: " + value);
        seleniumCommands.type(
                locationElement.findElement(ESTIMATE_LOSS_INPUT),
                value + Keys.TAB
        );
        return this;
    }

    public Validation validateEstimateOfLossErrorMessage(String errorMessage) {
        return this.validateEstimateOfLossErrorMessage(0, errorMessage);
    }

    public Validation validateEstimateOfLossErrorMessage(int locationIndex, String errorMessage) {
        return this.validateEstimateOfLossErrorMessage(
                seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex),
                errorMessage);
    }

    public Validation validateEstimateOfLossErrorMessage(WebElement locationElement, String errorMessage) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        logger.info("Validating the Error for Estimate Of Loss field.");
        return this.validateErrorMessage(
                locationElement,
                ESTIMATE_LOSS_ERROR,
                errorMessage);
    }

    public PropertyDetailsPage setNumberOfStories() {
        return this.setNumberOfStories(0);
    }

    public PropertyDetailsPage setNumberOfStories(int locationIndex) {
        return this.setNumberOfStories(seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex));
    }

    public PropertyDetailsPage setNumberOfStories(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        String value = data.get(ClaimData.NUMBER_OF_STORIES.getValue());
        logger.info("Setting Number of stories: " + value);
            seleniumCommands.type(
                    locationElement.findElement(NUMBER_OF_STORIES_INPUT),
                    value + Keys.TAB
            );
        return this;
    }

    public Validation validateNumberOfStorieErrorMessage(String errorMessage) {
        return this.validateNumberOfStorieErrorMessage(0, errorMessage);
    }

    public Validation validateNumberOfStorieErrorMessage(int locationIndex, String errorMessage) {
        return this.validateNumberOfStorieErrorMessage(
                seleniumCommands.findElements(LOCATION_CONTAINER).get(locationIndex),
                errorMessage);
    }

    public Validation validateNumberOfStorieErrorMessage(WebElement locationElement, String errorMessage) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        logger.info("Validating the Error for Number of Stories field.");
        return this.validateErrorMessage(
                locationElement,
                NUMBER_OF_STORIES_ERROR,
                errorMessage);
    }

    public Validation validateErrorMessage(WebElement locationElement, By elementSelector, String errorMessage) {
        this.ensureLocationDetailsAreAvailable(locationElement);
        return new Validation(
                seleniumCommands.getTextAtLocator(elementSelector),
                errorMessage);
    }

    public PropertyDetailsPage provideDataForAllListedLocations() {
        seleniumCommands.findElements(LOCATION_CONTAINER).forEach(this::provideDataForLocation);
        return this;
    }

    private List<PropertyDTO> getAllListedProperties() {
        return seleniumCommands.findElements(LOCATION_CONTAINER)
                .stream()
                .flatMap(locationElement -> {
                    this.ensureLocationDetailsAreAvailable(locationElement);
                    String address = locationElement.findElement(LOCATION_NAME).getText().split("\\n")[0];

                    return locationElement.findElements(BUILDINGS)
                            .stream()
                            .map(buildingElement -> {
                                final PropertyDTO property = new PropertyDTO();
                                property.setAddress(address);
                                property.setDescription(buildingElement.getText().split(",")[0]);
                                return property;
                            });
                })
                .collect(Collectors.toList());
    }

    public Validation containsAllSelectedProperties() {
        String selectedPropertiesData = data.get("SELECTED_PROPERTIES");
        if (selectedPropertiesData == null || selectedPropertiesData.isEmpty()) {
            return new Validation(false);
        }

        List<PropertyDTO> selectedProperties = PropertyDTO.fromJson(selectedPropertiesData);
        if (selectedProperties == null || selectedPropertiesData.isEmpty()) {
            return new Validation(false);
        }

        List<PropertyDTO> listedProperties = getAllListedProperties();

        Boolean areAllSelectedPropertiesListed = selectedProperties.stream()
            .allMatch(selectedProperty -> {
                return listedProperties.stream()
                    .anyMatch(listedProperty -> {
                        Boolean addressMatches = listedProperty.getAddress().contains(selectedProperty.getAddress());
                        Boolean descriptionMatches = listedProperty.getDescription().equals(selectedProperty.getDescription());
                        return addressMatches && descriptionMatches;
                    });
            });

        return new Validation(areAllSelectedPropertiesListed);
    }

    public CP_ClaimListPage cancelClaim() {
        clickCancel();
        new AlertHandler().closeClaimSubmissionAlert();
        return new CP_ClaimListPage();
    }

    public NewClaimPropertiesSelectionPage goBackToPropertiesSelection() {
        clickPrevious();
        return new NewClaimPropertiesSelectionPage();
    }

    private boolean isCompleteLocationDataProvided(WebElement locationElement) {
        this.ensureLocationDetailsAreAvailable(locationElement);

        boolean basicFieldsResult = Stream.of(new Boolean[] {
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(PROPERTY_DESCRIPTION_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(DAMAGE_DESCRIPTION_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(REPAIR_ESTIMATE_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(ESTIMATE_REPAIR_COST_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(ESTIMATE_REPAIR_TIME_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(ESTIMATE_DAMAGE_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(ESTIMATE_LOSS_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(CLASS_TYPE_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(NUMBER_OF_STORIES_INPUT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(ROOF_MATERIAL_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(EXTERIOR_WALL_MATERIAL_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(TYPE_OF_OCCUPANCY_SELECT)).isEmpty(),
               seleniumCommands.getValueAttributeFromLocator(locationElement.findElement(LOSS_AREA_SELECT)).isEmpty(),
       })
           .map(result -> !result) // ensure fields are NOT empty
           .reduce((previous, current) -> previous && current)
           .orElse(false);

       boolean radioFieldsResult = locationElement.findElement(ALREADY_REPAIRED_RADIO)
           .findElements(By.tagName("input"))
           .stream()
           .anyMatch(WebElement::isSelected);

       return basicFieldsResult && radioFieldsResult;
    }

    public Validation containsAllFieldsFulfilled() {
        boolean isLocationDataProvidedForAll = seleniumCommands.findElements(LOCATION_CONTAINER)
            .stream()
            .map(this::isCompleteLocationDataProvided)
            .reduce((previous, current) -> previous && current)
            .orElse(false);

        return new Validation(isLocationDataProvidedForAll);
    }
}
