package com.guidewire.portals.claimportal.pages;

import java.text.ParseException;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class NewClaimSummaryPage extends ClaimWizardPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(xpath = "(//section//div[@class='gw-controls'])[1]")
	WebElement POLICY_NUMBER_VALUE_XPATH;
	
	@FindBy(xpath = "(//section//div[@class='gw-controls'])[2]")
	WebElement WHAT_HAPPENED_VALUE_XPATH;
	
	@FindBy(xpath = "(//section//div[@class='gw-controls'])[3]")
	WebElement WHEN_VALUE_XPATH;
	
	@FindBy(xpath = "(//section//div[@class='gw-controls'])[4]")
	WebElement WHERE_VALUE_XPATH;
	
	@FindBy(xpath = "(//section//div[@class='gw-controls'])[5]")
	WebElement CONTACT_VALUE_XPATH;

	@FindBy(xpath = "(//section//div[@class='gw-controls'])[6]")
	WebElement VENDOR_VALUE_XPATH;

	@FindBy(css = "button[on-click='goToNext()']")
	WebElement SUBMIT_CLAIM_BTN_CSS;
	
	@FindBy(css = 	"[class='gw-pull-right ng-binding']")
	WebElement CLAIM_DRAFT_NUMBER_CSS_CSS;
	
	@FindBy(css = 	"[ng-click='beginCreateNote()']")
	WebElement ADD_NOTE_ADJUSTER_CSS;
	
	@FindBy(css = 	"[ng-show='fnol.claim.adjusterNote.value'] [class='gw-clearfix'] span")
	WebElement NOTE_ADJUSTER_BODY_CSS;
	
	@FindBy(css = 	"[ng-show='fnol.claim.adjusterNote.value'] [class='gw-note ng-isolate-scope']")
	WebElement NOTE_ADJUSTER_SUB_CSS;

	public NewClaimSummaryPage() {
		super();
	}

	public NewClaimContactPersonPage getBackToClaimContactPage() {
		clickPrevious();
		return new NewClaimContactPersonPage();
	}

	public NewClaimCrimeDetails clikDetailsInWizard(){
		seleniumCommands.click(By.xpath("//div[@class='gw-wizard-sidebar-steps ng-isolate-scope']/ul/li[3]"));
		return new NewClaimCrimeDetails();
	}

	public HashMap<String, String> getBasicClaimSummaryDetails() {
		HashMap<String, String> summary =  new HashMap<>();
		summary.put("POLICY_NUM", seleniumCommands.getTextAtLocator(POLICY_NUMBER_VALUE_XPATH));
		summary.put("WHAT_HAPPENED", seleniumCommands.getTextAtLocator(WHAT_HAPPENED_VALUE_XPATH));
		summary.put("WHEN", seleniumCommands.getTextAtLocator(WHEN_VALUE_XPATH));
		summary.put("WHERE", seleniumCommands.getTextAtLocator(WHERE_VALUE_XPATH));
		summary.put("CONTACT_PERSON", this.getContactValue().split("ext.")[0].trim());
		return summary;
	}

	public String getContactValue() {
		return seleniumCommands.getTextAtLocator(CONTACT_VALUE_XPATH);
	}

	public HashMap<String, String> getHOClaimSummaryDetails() {
		HashMap<String, String> summary =  new HashMap<>();
		summary.put("POLICY_NUM", seleniumCommands.getTextAtLocator(POLICY_NUMBER_VALUE_XPATH));
		summary.put("WHAT_HAPPENED", seleniumCommands.getTextAtLocator(WHAT_HAPPENED_VALUE_XPATH));
		summary.put("WHEN", seleniumCommands.getTextAtLocator(WHEN_VALUE_XPATH));
		summary.put("CONTACT_PERSON", getContactValue());
		return summary;
	}
	
	public NewClaimConfirmationPage  submitClaim() {
		seleniumCommands.clickbyJS(SUBMIT_CLAIM_BTN_CSS);
		return new NewClaimConfirmationPage();
	}
	
	public AlertHandler cancelClaim() {
		clickCancel();
		new AlertHandler().closeSubmissionAlert();
		return new AlertHandler();
	}
	
	public AlertHandler addNotesForAdjuster() {
		seleniumCommands.clickbyJS(ADD_NOTE_ADJUSTER_CSS);
		return new AlertHandler();
	}
	
	// Get Method
	public String getDraftClaimNumber() {
			return seleniumCommands.getTextAtLocator(CLAIM_DRAFT_NUMBER_CSS_CSS);
	}
	
	//Validation
	public Validation validateExistingContactsDetailsOnSummaryPage() {
		logger.info("Validating Existing Contact Details on Summary Page");

		String contactDetails;
		String existingContact = data.get("EXISTING_CONTACT");
		String homePhone = data.get("HomePhoneNewContact");

		if(existingContact != null && homePhone != null) {
			contactDetails = existingContact + "," + homePhone;
		} else {
			contactDetails = ParsePolicyData.getContactDetails(DataFetch.getPolicyData(data.get("USER"), data.get("POLICY_NUM")));
		}
		return new Validation(contactDetails, getBasicClaimSummaryDetails().get("CONTACT_PERSON").replace("(", "").replace(") ", "-"));
	}
	
	public Validation validateNewContactsDetailsOnSummaryPage() {
		logger.info("Validating New Contact Details on Summary Page");

		String contactDetails = null;
		String firstName = data.get("FirstNameNewContact");
		String lastName = data.get("LastNameNewContact");
		String homePhone = data.get("HomePhoneNewContact");

		if(firstName != null && lastName != null && homePhone != null) {
			contactDetails = firstName + " " + lastName + "," + homePhone;
		} else {
			contactDetails = ParsePolicyData.getContactDetails(DataFetch.getPolicyData(data.get("USER"), data.get("POLICY_NUM")));
		}
		return new Validation(contactDetails, getBasicClaimSummaryDetails().get("CONTACT_PERSON").replace("(", "").replace(") ", "-"));
	}
	
	public Validation validateNoteToAdjusterDetailsOnSummaryPage() {
		logger.info("Validating the notes text");
		new Validation(seleniumCommands.getTextAtLocator(NOTE_ADJUSTER_BODY_CSS), data.get("NoteBody")).shouldBeEqual("Notes body for adjuster is not matched");
		new Validation(seleniumCommands.getTextAtLocator(NOTE_ADJUSTER_SUB_CSS), data.get("NoteSubject")).shouldBeEqual("Notes subject for adjuster is not matched");
		return new Validation(true);
	}
	
	public Validation validateClaimSummaryPageData(HashMap<String, String> data) throws ParseException {
		logger.info("Validating the claim summay data");
		MapCompare.compareMap(data, this.getBasicClaimSummaryDetails());
		return new Validation(true);
	}

	public Validation validateVendorChoice(VendorDto vendorDto) throws ParseException {
		logger.info("Validating vendor choice");

		if (vendorDto != null) {
			String expectedData = "";
			expectedData += vendorDto.VendorName;
			expectedData += vendorDto.Address;

			String vendorInfo = seleniumCommands.getTextAtLocator(VENDOR_VALUE_XPATH).replace("\n", "");
			StringBuilder strb=new StringBuilder(vendorInfo);    
			int index=strb.lastIndexOf(",");    
			strb.replace(index,vendorInfo.length()+index,"");    
			new Validation(strb.toString() + vendorInfo.substring(index+1), expectedData).shouldBeEqual("Vendor should be displayed on summary page");
		} else {
			String vendorInfo = seleniumCommands.getTextAtLocator(VENDOR_VALUE_XPATH).replace("\n", "");
			new Validation(vendorInfo, "No repair requested").shouldBeEqual("No vendor requested should be displayed on summary page");
		}

		return new Validation(true);
	}

}

