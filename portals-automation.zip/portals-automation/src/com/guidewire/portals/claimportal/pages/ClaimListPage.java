package com.guidewire.portals.claimportal.pages;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;
import com.guidewire.portals.claimportal.subpages.VendorDetailsPopUp;

/**
 * @deprecated
 * please use specific xx_ClaimListPage from  /src/com/guidewire/capabilities/claims/model/page/xx_ClaimListPage.java
 */
@Deprecated
public class ClaimListPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[class*='gw-header-nav'] a")
	WebElement HOME_BTN_CSS;

	@FindBy(css = "[model='tableConfig.claimQuery'] input[ng-keypress], [ng-model='_model.value']")
	WebElement SEARCH_TXT_CSS;

	@FindBy(id = "LOBSelect")
	WebElement LOB_SELECT_CSS;

	@FindBy(id = "closedClaimsLabel")
	WebElement CLOSE_CLAIM_LABLE_SELECT_CSS;

	@FindBy(css = "[class='gw-claimsTable gw-table ng-scope'], [list='getFilteredClaimSummaries()']")
	WebElement CLAIM_LIST_SELECT_CSS;

	@FindBy(css ="div[class='gw-vertical-align-item gw-show-for-phone-landscape-up ng-scope']")
	WebElement ADD_POLICY_BTN_CSS;
	
	@FindBy(id = "createNoteButton")
	WebElement ADD_NOTE_BTN_ID;
	
	@FindBy(css = "a[href='#/fnol']")
	WebElement FILE_CLAIM_BTN_XPATH;

	@FindBy(css = "table[class='gw-claimsTable gw-table ng-scope'] tbody tr")
	WebElement CLAIM_TABLE_ROW_CSS;

	private final By CLAIM_SEARCH_RESULT_CSS = By.cssSelector("table[class='gw-claimsTable gw-table ng-scope'] tbody tr, [ng-hide*='failToGetClaims'][aria-hidden='false']");

	@FindBy(css = "table[class='gw-claimsTable gw-table ng-scope'] tbody tr")
	List<WebElement> CLAIM_TABLE_ROWS_CSS;

	@FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr/td[@attribute='normalizedLobCode']/img")
	List<WebElement> CLAIM_LIST_LOB_XPATH;

	@FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr/td[@attribute='totalPayments.amount']")
	List<WebElement> CLAIM_LIST_PAID_XPATH;

	@FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr/td[@attribute='totalPayments.amount']")
	List<WebElement> CLAIM_LIST_TOTAL_INCURRED_XPATH;

	@FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[1]/td[@attribute='claimState']")
	WebElement CLAIM_STATUS_ROW_1_CSS;

	@FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[4]/td[@attribute='claimState']")
	WebElement CLAIM_STATUS_OF_CLOSED_CLAIM;
	
	@FindBy(xpath = "//th[text()='Line']")
	WebElement LINE_COL_XPATH;
	
	@FindBy(xpath = "//th[text()='Claim Number']")
	WebElement CLAIMNUM_COL_XPATH;

	By CLAIMNUM_CSS = By.cssSelector("td[title='Claim Number']");

	@FindBy(xpath = "//th[text()='Date of Loss']")
	WebElement DOL_COL_XPATH;
	
	@FindBy(xpath = "//th[text()='Status']")
	WebElement STATUS_COL_XPATH;

	By CLAIM_STATUS_CSS = By.cssSelector("td[title='Status']");
	
	@FindBy(xpath = "//th[text()='Vendor(s)']")
	WebElement VENDOR_COL_XPATH;
	
	@FindBy(xpath = "//th[contains(text(),'Policy')]")
	WebElement POLICY_COL_XPATH;

	@FindBy(xpath = "//th[@ng-click[contains(.,'totalPayments.amount')]]")
	WebElement PAID_COL_XPATH;

	@FindBy(xpath = "//th[@ng-click[contains(.,'totalIncurredNet.amount')]]")
	WebElement NET_INCURRED_COL_XPATH;

	@FindBy(css = ".gw-icon-caret.fa.fa-caret-down")
	WebElement LOGOUT_ARRORW_CSS;

	@FindBy(css = "[href*='/logout']")
	WebElement LOGOUT_BUTTON_CSS;

	@FindBy(css = "[ui-sref='accounts.detail.claims']")
	WebElement CLAIM_TILE;

	By  SORT_ICON_XPATH = By.xpath("i[@ng-class[contains(.,'getSortIcon')]]");

	static final String LOADER_IMAGE_CSS = "[src='../styles/images/common/ajax-loader.gif']";

	List<String> LOB_DROPDOWN_LIST = Arrays.asList("All Lines of Business", "Businessowners", "General Liability", "Homeowners", "Inland Marine", "Personal Auto", "Workers' Compensation");

	String CLAIM_LIST_HEADER = "table thead th";
	
	By CLAIM_LIST_CSS = By.cssSelector("table[class='gw-claimsTable gw-table ng-scope'] tbody tr");
	
	By CLAIM_XPATH = By.xpath("//a[text()='" + data.get("ClaimSearchValue") + "']");

	public ClaimListPage() {
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitTillPageIsLoaded();
		seleniumCommands.waitForLoaderToDisappearFromPage();
	}

	public NewClaimDOLPage fileAClaim() {
		if(ThreadLocalObject.getSuitenName().equals(SuiteName.CPPH.toString())) {
			DataFetch.getFNOLPolicyList(data.get("USER"));
		}
		seleniumCommands.clickbyJS(FILE_CLAIM_BTN_XPATH);
		return new NewClaimDOLPage();
	}

	public ClaimListPage clickIncludeClaimsClosedCheckBox()
	{
		seleniumCommands.click(CLOSE_CLAIM_LABLE_SELECT_CSS);
		return this;
	}

	public ClaimListPage goToClaimTile() {
		new Tiles().selectByTitle("Claims");
		return this;
	}

	public ClaimListPage goToHome() {
		seleniumCommands.clickbyJS(HOME_BTN_CSS);
		seleniumCommands.waitForElementToBeVisible(CLAIM_TABLE_ROW_CSS);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new ClaimListPage();
	}
	
	public ClaimSummaryPage openClaimSummary(String claim) {
		seleniumCommands.click(By.xpath("//a[text()='" + claim + "']"));
		seleniumCommands.waitForElementToBeClickable(new ClaimSummaryPage().POLICY_LABEL_VALUE_XPATH);
		return new ClaimSummaryPage();
	}
	
	public ClaimSummaryPage openClaimSummary() {
		seleniumCommands.waitForElementToBeVisible(CLAIM_XPATH);
		seleniumCommands.clickbyJS(CLAIM_XPATH);
		return new ClaimSummaryPage();
	}
	public PolicyDetailPage openPolicyDetailsPage() {
		filterClaimByTextSearch();
		seleniumCommands.waitForElementToBeVisible(CLAIM_XPATH);
		seleniumCommands.clickbyJS(By.xpath("//a[text()='" + data.get("POLICY_NUM") + "']"));
		return new PolicyDetailPage();
	}
	
	public Object openDraftClaim(String draftNum) {
		seleniumCommands.clickbyJS(By.linkText(draftNum));
		
		if(data.get("ClaimSubType").equalsIgnoreCase("Theft"))
		{
			return new NewClaimLocationPage();
		}
		else 
		{
			return new NewClaimVehicleDriverPage();
		}
	}

	public NewGeneralClaimDetails openClaimDetailsPage(String claim) {
		seleniumCommands.click(By.linkText(claim));
		return new NewGeneralClaimDetails();
	}

	public NewClaimDOLPage searchClaim(String value) {
		seleniumCommands.waitForElementToDisappear(By.cssSelector(LOADER_IMAGE_CSS));
		seleniumCommands.waitForElementToBeEnabled(SEARCH_TXT_CSS);

		final WebElement searchResult = seleniumCommands.findElement(CLAIM_SEARCH_RESULT_CSS);
		seleniumCommands.type(SEARCH_TXT_CSS, value);
		// waiting result for search callback
		boolean exist = true;
		while (exist) {
			try {
				searchResult.getText();
			} catch (StaleElementReferenceException e) {
				exist = false;
			}
		}
		seleniumCommands.waitForElementToBeClickable(CLAIM_SEARCH_RESULT_CSS);

		return new NewClaimDOLPage();
	}
	
	public ClaimListPage searchClaim() {
		seleniumCommands.type(SEARCH_TXT_CSS, data.get("ClaimSearchValue"));
		return  this;
	}
	
	public ClaimListPage filterClaimByTextSearch() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.type(SEARCH_TXT_CSS, data.get("ClaimSearchValue"));
		return this;
	}

	public ClaimListPage filterClaimByTextSearch(String searchValue) {
		seleniumCommands.type(SEARCH_TXT_CSS, searchValue);
		return this;
	}

	public ClaimListPage clearTextSearch() {
		seleniumCommands.type(SEARCH_TXT_CSS, "");
		return this;
	}

	public ClaimListPage selectLOB() {

		seleniumCommands.selectDropDownValueByText(LOB_SELECT_CSS, data.get("ClaimSearchValue"));
		seleniumCommands.waitForElementToDisappear(By.cssSelector(LOADER_IMAGE_CSS));
		return this;
	}

	public List<String> getOpenClaimIds() {

		logger.info("Getting open claim ids");
		List<String> result = new ArrayList<>();

		seleniumCommands.findElements(CLAIM_LIST_CSS).forEach(el->{
			if ( seleniumCommands.findElement(el, CLAIM_STATUS_CSS).getText().equals("Open") ) {
				result.add( seleniumCommands.getTextAtLocator(seleniumCommands.findElement(el, CLAIMNUM_CSS)) );
			}
		});

		if ( result.size() == 0 ) {
			logger.warn("NO OPEN Claims in the portal, check data.");
		}
		return result;
	}

	private boolean checkIfClaimIsListedinSearchResult(String value) {
		int row = seleniumCommands.getElements(CLAIM_TABLE_ROW_CSS).size();
		for (int i = 1; i <= row; i++) {
			if (seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr["+ i +"]/td[@attribute='claimNumber']")).equals(value)) {
				return true;
			}
		}
		return false;
	}
	
	public boolean checkIfClaimIsFilteredAsPerSearchText(String ColumnName, String value)
	{
		boolean flag = false;
		int row = ThreadLocalObject.getDriver().findElements(By.cssSelector("table[class='gw-claimsTable gw-table ng-scope'] tbody tr")).size();
		System.out.println(row);
		if(ColumnName.equals("ExactClaimNumber"))
		{
		for (int i = 1; i <= row; i++) 
		{
			if(seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr["+ i +"]/td[@attribute='claimNumber']")).equals(value))
			{
				flag = true;
			}
		}
		return flag;
		}
		else if(ColumnName.equals("PartialClaimNumber"))
		{
			flag = true;
		for (int i = 1; i <= row; i++) 
		{
			if(!seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr["+ i +"]/td[@attribute='claimNumber']")).contains(value))
			{
				flag = false;
				return flag; 
			}
		}
		return flag;
		}
		else if(ColumnName.equals("ClaimStatus"))
		{
			flag = true;
			for (int i = 1; i <= row; i++) 
			{
				System.out.println(seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr["+ i +"]/td[@attribute='claimState']")) + i);
				if(!seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr["+ i +"]/td[@attribute='claimState']")).equals(value))
				{
					flag = false;
					return flag; 
				}
			}
			return flag;
		}
		
		else if(ColumnName.equals("LOB"))
		{
			flag = this.validateLOBOptionSelection(value);
		}
		
		return flag;
	}

	// Function passes through all the claims in the list, finds the first status that is "Closed" and than exits
	public Validation findIfStatusIsPresented( String value) {
		seleniumCommands.waitForElementToDisappear(By.cssSelector(LOADER_IMAGE_CSS));
		int row = CLAIM_TABLE_ROWS_CSS.size(); //counts how much claims are in the table
			for (int i = 1; i <= row; i++) {
				if (seleniumCommands.getTextAtLocator(By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[" + i + "]/td[@attribute='claimState']")).equals(value)) {
					return new Validation(true);
				}
			}
		return new Validation(false);
}


	public boolean checkIfClaimIsNotFilteredAsPerSearchText(String ColumnName, String value)
	{
		boolean flag = false;
		int row = ThreadLocalObject.getDriver().findElements(By.cssSelector("table[class='gw-claimsTable gw-table ng-scope'] tbody tr")).size();
		System.out.println(row);
		if(ColumnName.equals("DateOfLoss"))
		{
			if(row==0)
			{
				return true;
			}
		}
		else if(ColumnName.equals("Vendor"))
		{
			if(row==0)
			{
				return true;
			}
		}
		else if(ColumnName.equals("Policy"))
		{
			if(row==0)
			{
				return true;
			}
		}
		return flag;
	}
	
	//Get Method
	
	public String getClaimStatus(String claimNum) {
		searchClaim(claimNum);
		return  seleniumCommands.getTextAtLocator(CLAIM_STATUS_ROW_1_CSS);
	}
	

	// Validate a Claim
	public Validation validateClaimListing(String claimNum) {
		searchClaim(claimNum);
		return new Validation(checkIfClaimIsListedinSearchResult(claimNum));
	}
	
	public Validation validateClaimDraftStatus(String claimNum) {
		System.out.println(ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)).get("CLAIM_STATE"));
		new Validation(ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)).get("CLAIM_STATE"), "draft").shouldBeEqual("Claim is not saved as Draft in backend");
		new Validation(getClaimStatus(claimNum), "Draft").shouldBeEqual("Claim is not saved as Draft On Claim List");
		return new Validation(1,1);
	}
	
	public Validation validateClaimOpenStatus(String claimNum) {
		return new Validation(getClaimStatus(claimNum), "Open");
	}
	
	public Validation validateClaimClosedStatus(String claimNum) {
		return new Validation(getClaimStatus(claimNum), "Closed");
	}

	public Validation validateClaimClosedStatusInList() {
		return new Validation(checkIfClaimIsFilteredAsPerSearchText("ClaimStatus","Closed"));
	}

	public Validation areVendorDetailsOnPopUpCorrect() throws Exception {
		return new VendorDetailsPopUp().openAndValidateVendorPopDetails();
	}
	
	public Validation validateLOBDropDown() {

		new Validation(seleniumCommands.getSelectedOptionFromDropDown(LOB_SELECT_CSS), LOB_DROPDOWN_LIST.get(0)).shouldBeEqual("LOD default option is not correct.");
		new Validation(seleniumCommands.getAllOptionsFromDropDown(LOB_SELECT_CSS), LOB_DROPDOWN_LIST).shouldBeEqual("LOB options are not listed correctly");
		return new Validation(true);
	}

	public Validation validateClaimNumberFormat(String claimNum) throws Exception {
		String[] claim = claimNum.split("-");
		new Validation(claim.length, 3).shouldBeEqual("Claim num "+ claimNum + " format is not correct ");
		new Validation(claim[0].length(), 3).shouldBeEqual("Claim num "+ claimNum + " first half is not having 3 digit " + claim[0]);
		new Validation(claim[1].length(), 2).shouldBeEqual("Claim num "+ claimNum + " second half is not having 3 digit " + claim[1]);
		new Validation(claim[2].length(), 6).shouldBeEqual("Claim num "+ claimNum + " third half is not having 3 digit " + claim[2]);
		return new Validation(true);
	}
	
	public Validation validateDraftClaimNumberFormat(String claimNum) throws Exception {
		String claimPrefix = claimNum.substring(0, 9);
		String draftNum = claimNum.substring(10);
		new Validation(claimPrefix, "999-99-99").shouldBeEqual("Claim prfix "+ claimPrefix + " format is not correct ");
		new Validation(draftNum.length(), 3).shouldBeEqual("Claim draft num "+ draftNum + " format is not correct ");
		return new Validation(true);
	}
	
	private boolean validateLOBOptionSelection(String option) {

		seleniumCommands.selectDropDownValueByText(LOB_SELECT_CSS, option);
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeClickable(CLAIM_LIST_SELECT_CSS);

		List<String> expectedOptions = new ArrayList<>();
		if (option.equals(LOB_DROPDOWN_LIST.get(0))) {
			for( int i = 1; i < LOB_DROPDOWN_LIST.size(); i++ ) {
				expectedOptions.add(LOB_DROPDOWN_LIST.get(i).toLowerCase().replace(" ","").replace("'",""));
			}
		} else {
			expectedOptions.add(option.toLowerCase().replace(" ","").replace("'",""));
		}

		for(WebElement el : CLAIM_LIST_LOB_XPATH) {
			logger.info("ELEMENT ICON TITLE:  " + seleniumCommands.getAttributeValueAtLocator(el, "title"));
			String title = seleniumCommands.getAttributeValueAtLocator(el, "title").replace("-","");
			if (!expectedOptions.stream().anyMatch(expected -> expected.contains(title))) {
				return false;
			}
		}

		return true;
	}


	private void sort(WebElement sortingHeader, String sortOrder) {
		WebElement sortingIndicator = seleniumCommands.findElement(sortingHeader, SORT_ICON_XPATH);
		String expectedSortingClassValue = "";
		String actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");

		switch(sortOrder.toLowerCase()) {
			case "asc":
				expectedSortingClassValue = "up";
				break;
			case "desc":
				expectedSortingClassValue = "down";
				break;
			default:
				logger.error(String.format("Unsupported sorting type [%s]", sortOrder));
		}

		if(actualSortingClassValue.toLowerCase().contains("minus")) {
			seleniumCommands.click(sortingHeader);
			actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");
		}

		if (!actualSortingClassValue.contains(expectedSortingClassValue))
			seleniumCommands.click(sortingHeader);

		actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");
		if (actualSortingClassValue.contains(expectedSortingClassValue))
			logger.info(String.format("Sorting [%s] done successfully", sortOrder));
		else
			logger.error(String.format("Sorting [%s] FAILED", sortOrder));
	}

	private List<String> getColumnData(List<WebElement> columnDataCollection) {
		List<String> colDataList = new ArrayList<>();
		columnDataCollection.forEach(el ->
			colDataList.add(seleniumCommands.getTextAtLocator(el).trim())
		);
		return colDataList;
	}

	private Validation validateClaimListIsSorted(String column, String sortOrder) {
		List<String> colDataList = new ArrayList<>();
		List<String> actualList = new ArrayList<>();
		List<String> expectedList = new ArrayList<>();

		colDataList.addAll(getColumnData(CLAIM_LIST_PAID_XPATH));
		Collections.sort(colDataList);

		if(sortOrder.toLowerCase().equals("desc"))
			Collections.reverse(colDataList);

		expectedList.addAll(colDataList);

		logger.info("Sorting COL[" + column + "]");
		switch(column.toLowerCase()) {
			case "paid":
				sort(PAID_COL_XPATH, sortOrder);
				break;

			default:
				logger.error(String.format("Unsupported COL[%s]", column));
		}

		//add actual list after sorting
		colDataList.clear();
		colDataList.addAll(getColumnData(CLAIM_LIST_PAID_XPATH));
		actualList.addAll(colDataList);

		for(int i=0; i< expectedList.size(); i++) {
			if(!expectedList.get(i).equals(actualList.get(i))) {
				logger.error(String.format("Sorting test[%s] for COL[%s] FAILED: ", sortOrder, column));
				logger.error(String.format("\t EXPECTED VALUE[%s],COL[%s]", expectedList.get(i), column));
				logger.error(String.format("\t ACTUAL VALUE[%s],COL[%s]", actualList.get(i), column));
				return new Validation(false);
			}
		}
		logger.info(String.format("Sorting test[%s] for COL[%s] SUCCESSFUL", sortOrder, column));
		return new Validation(true);
	}

	public Validation validateClaimListPaidColIsSortedAsc() {
		return validateClaimListIsSorted("paid", "asc");
	}

	public Validation validateClaimListPaidColIsSortedDesc() {
		return validateClaimListIsSorted("paid", "desc");
	}

	public Validation validateClaimListIsFiltered(String column) {
		return new Validation(checkIfClaimIsFilteredAsPerSearchText(column, data.get("ClaimSearchValue")));
	}

	public Validation validateClaimListIsFiltered(String column, String claimNum) {
		return new Validation(checkIfClaimIsFilteredAsPerSearchText(column, claimNum));
	}

	public Validation validateClaimListIsNotFiltered(String column) {
		return new Validation(checkIfClaimIsNotFilteredAsPerSearchText(column, data.get("ClaimSearchValue")));
	}

	public Validation isClaimListPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
		new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_XPATH)).shouldBeTrue("File a Claim button not visible");
		new Validation(seleniumCommands.isElementPresent(CLAIM_LIST_SELECT_CSS)).shouldBeTrue("Claim table is not displayed");
		new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
		new Validation(seleniumCommands.isElementPresent(LOB_SELECT_CSS)).shouldBeTrue("LOB dropdown is not displayed");
		new Validation(seleniumCommands.isElementPresent(CLOSE_CLAIM_LABLE_SELECT_CSS)).shouldBeTrue("Closed claim chkbox is not displayed");
		if(ThreadLocalObject.getBrowserName().equals(DataConstant.NEXUS5) || ThreadLocalObject.getBrowserName().equals(DataConstant.IPHONE6))
		{
			new Validation(seleniumCommands.findElements(By.cssSelector(CLAIM_LIST_HEADER)).size(), 6);
		}
		else
		{
			new Validation(seleniumCommands.isElementPresent(LINE_COL_XPATH)).shouldBeTrue("Claim List Line Column is not visible");
			new Validation(seleniumCommands.isElementPresent(CLAIMNUM_COL_XPATH)).shouldBeTrue("Claim List ClaimNum Column is not visible");
			new Validation(seleniumCommands.isElementPresent(DOL_COL_XPATH)).shouldBeTrue("Claim List Date of Loss Column is not visible");
			new Validation(seleniumCommands.isElementPresent(STATUS_COL_XPATH)).shouldBeTrue("Claim List Status Column is not visible");
			new Validation(seleniumCommands.isElementPresent(VENDOR_COL_XPATH)).shouldBeTrue("Claim List Vendor Column is not visible");
			new Validation(seleniumCommands.isElementPresent(POLICY_COL_XPATH)).shouldBeTrue("Claim List Policy Column is not visible");

		}
		seleniumCommands.click(LOGOUT_ARRORW_CSS);
		new Validation(seleniumCommands.isElementPresent(LOGOUT_BUTTON_CSS)).shouldBeTrue("Log Out button is not visible");
		return new Validation(true);
	}

	public Validation isSimpleClaimListPageLoaded() {
		seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
		return new Validation(seleniumCommands.isElementPresent(CLAIM_LIST_SELECT_CSS));
	}
	
	public Validation isPolicyAddButtonPresent() {
		if(data.get("Suite").equalsIgnoreCase("CP-PolicyHolder"))
		{
			new Validation(seleniumCommands.isElementPresent(ADD_POLICY_BTN_CSS)).shouldBeTrue("Add policy button is not visible");
		}
		return new Validation(true);
	}
	
	public Validation validateVendorPopUpDetails() {
		return new VendorDetailsPopUp().openAndValidateVendorPopDetails();
	}

	public Validation validateClaimDataWithBackEnd(String claimNum) throws ParseException {
		HashMap<String, String> claimData = new HashMap<>();
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", data.get("MAIN_CONTACT_DISPLAY_ADDRESS"));
		claimData.put("CLAIM_STATE", "draft");
		claimData.put("VehicleYear", data.get("VehicleYear"));
		claimData.put("Model", data.get("Model"));
		claimData.put("Make", data.get("Make"));
		claimData.put("ACCOUNT_NUM", data.get("ACCOUNT_NUM"));
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", data.get("CLAIM_REPORTER_DISPLAY_NAME"));
		claimData.put("POLICY_NUM", data.get("POLICY_NUM"));
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", data.get("MAIN_CONTACT_DISPLAY_NAME"));
		claimData.put("LOSS_LOCATION_DISPLAY_NAME", data.get("LOSS_LOCATION_DISPLAY_NAME"));
		claimData.put("CLAIM_REPORTER_DISPLAY_ADDRESS", data.get("CLAIM_REPORTER_DISPLAY_ADDRESS"));
		claimData.put("LOSS_CAUSE", data.get("LOSS_CAUSE"));
		claimData.put("LOSS_DESC", data.get("LOSS_DESC"));
		claimData.put("DATE_OF_LOSS", data.get("DATE_OF_LOSS"));
		
			return MapCompare.compareMap(data,
					ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)));
	}
}
