package com.guidewire.ci.cp.agent;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.DriverTimeout;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.HashMap;

public class CI_CPAgentTest {
    CPPageFactory cpPageFactory = new CPPageFactory();

    private String fileClaim() {
        return cpPageFactory.createGeneralClaim()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();
    }

    private void validateClaim(String lob, String claimNum) throws Exception{
        CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
        claimListPage
                .goToHome()
                .validateClaimListing(claimNum)
                .shouldBeTrue("CP-Agent " + lob + " claim failed : not listed");

        ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
        claimSummary
                .isClaimSummaryDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP-Agent " + lob + " claim failed : does not match backend");
    }

    @Parameters("browserName")
    @Test(groups = {"CI"})
    public void testBOClaim(String browserName) throws Exception {
        DriverTimeout.setTimeout(10);
        PolicyGenerator.createBasicBoundBOPolicy();

        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ClaimType", "BusinessOwner");
        data.put("LOSS_CAUSE", "Fire");
        data.put("LossDescription", "LossDescription");
        data.put("DamageDescription", "DamageDescription");

        String claimNum = this.fileClaim();
        this.validateClaim("BO", claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"CI"})
    public void testIMClaim(String browserName) throws Exception {
        DriverTimeout.setTimeout(10);
        PolicyGenerator.createBasicBoundIMPolicy();

        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ClaimType", "InlandMarine");
        data.put("LOSS_CAUSE", "Fire");
        data.put("LossDescription", "LossDescription");
        data.put("DamageDescription", "DamageDescription");

        String claimNum = this.fileClaim();
        this.validateClaim("IM", claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"CI"})
    public void testGLClaim(String browserName) throws Exception {
        DriverTimeout.setTimeout(10);
        PolicyGenerator.createBasicBoundGLPolicy();

        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ClaimType", "GeneralLiability");
        data.put("LOSS_CAUSE", "Fire");
        data.put("LossDescription", "LossDescription");
        data.put("DamageDescription", "DamageDescription");

        String claimNum = this.fileClaim();
        this.validateClaim("GL", claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"CI"})
    public void testPAClaim(String browserName) throws Exception {
        DriverTimeout.setTimeout(10);
        PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice();
        String claimNum = repairChoicePage
                .selectNewFacility()
                .withContactData()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();
        this.validateClaim("PA", claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"CI"})
    public void testWCClaim(String browserName) throws Exception {
        DriverTimeout.setTimeout(10);
        PolicyGenerator.createBasicBoundWCPolicy();
        String claimNum = cpPageFactory.createWCClaimWWitDefaultMedicalTreatment()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();
        this.validateClaim("WC", claimNum);
    }
}
