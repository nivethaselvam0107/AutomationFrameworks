package com.guidewire.data;

import com.guidewire.common.util.EnumHelper;

public enum PolicyData {

    POLICY_NUM("POLICY_NUM"),
    ACCOUNT_NAME("ACCOUNT_NAME"),
    POLICY_TYPE("POLICY_TYPE"),
    POLICY_EXPIRATION_DATE("POLICY_EXPIRATION_DATE"),
    POLICY_START_DATE("POLICY_START_DATE"),
    ACCOUNT_NUMBER("ACCOUNT_NUMBER"),
    ACCOUNT_FIRST_NAME("ACCOUNT_FIRST_NAME"),
    ACCOUNT_LAST_NAME("ACCOUNT_LAST_NAME"),
    ACCOUNT_ADDLINE1("ACCOUNT_ADDLINE1"),
    POLICY_INCEPTION("POLICY_INCEPTION"),
    POLICY_EXPIRATION("POLICY_EXPIRATION"),
    POLICY_STATUS("POLICY_STATUS"),
    PRODUCER_OF_RECORD("PRODUCER_OF_RECORD"),
    PRODUCER_OF_SERVICE("PRODUCER_OF_SERVICE"),
    TOTAL_PREMIUM("TOTAL_PREMIUM"),
    TAXES_AND_FEES("TAXES_AND_FEES"),
    TOTAL_COST("TOTAL_COST");

    private final String propertyName;

    PolicyData(final String propertyName) {
        this.propertyName = propertyName;
    }

    @Override
    public String toString() {
        return this.propertyName;
    }

    public static PolicyData fromString(String name) {
        return EnumHelper.fromString(PolicyData.class, name);
    }
}