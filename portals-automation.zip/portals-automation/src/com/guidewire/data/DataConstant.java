package com.guidewire.data;

import com.guidewire.common.selenium.DriverTimeout;

public class DataConstant {


	public static final int PAGEFACTORY_TIMEOUT = DriverTimeout.getDefaultWaitInSeconds();
	
	public static final String CP_POLICYHOLDER_URL = "https://" + System.getProperty("host.name") + (System.getProperty("vm.type").equals("local") || System.getProperty("vm.type").equals("dev")? "/CustomerEngage-Claims/dist/html/index-policyholder.html" : "/CustomerEngage-Claims/dist/html/index-policyholder.html");

	public static final String CP_PRODUCER_URL = "https://" + System.getProperty("host.name") + (System.getProperty("vm.type").equals("local") || System.getProperty("vm.type").equals("dev") ? "/ProducerEngage-Claims/dist/html/index-producer.html" : "/ProducerEngage-Claims/dist/html/index-producer.html#/claims/list");

	public static final String QnB_URL = "https://" + System.getProperty("host.name") +  ( System.getProperty("vm.type").equals("local") || System.getProperty("vm.type").equals("dev")  ? "/CustomerEngage-Quote_and_Buy/dist/html/index.html#" : "/CustomerEngage-Quote_and_Buy/dist/html/index.html#");

	public static final String GPA_URL ="https://" + System.getProperty("host.name") + (System.getProperty("vm.type").equals("local") || System.getProperty("vm.type").equals("dev")  ? "/ProducerEngage/dist/html/index-agents.html#/home" : "/ProducerEngage/dist/html/index-agents.html");
	
	public static final String AMP_URL = "https://"  + System.getProperty("host.name") +  ( System.getProperty("vm.type").equals("local") || System.getProperty("vm.type").equals("dev")  ? "/CustomerEngage-Account_Management/dist/html/index.html" : "/CustomerEngage-Account_Management/dist/html/index.html" );

	//Error Message
	public static final String ERROR_TITLE = "Error";

	public static final String MANDATORY_ERROR_MSG = "This is a required field";

	public static final String ZIP_CODE_MISSING_ERROR_MSG = "Please enter a ZIP code.";

	public static final String ZIP_CODE_INVALID_ERROR_MSG = "Value must be a valid postal code";

	public static final String POLICY_SELECTION_ERROR_MSG = "Please select a policy type.";

	public static final String NO_BUILDING_ERROR_MSG = "Please add at least one building to this location.";

	public static final String NO_PAYMENT_PLAN_ERROR_MSG = "Please select a payment plan and try again.";

	public static final String NUMBER_FORMAT_ERROR_MSG = "Please enter numbers only.";

	public static final String DATE_FUTURE_ERROR = "Value must be a date in the future";

	public static final String DATE_PAST_ERROR = "Value must be a date in the past";

	public static final String NO_POLICY_LISTED_ERROR = "No policies were found that match the search criteria.";

	public static final String NO_POLICY_ERROR = "No policies found";

	public static final String CONTACT_US_PAGE_ERROR = "Please contact us with the reference number below and we would be pleased to assist you.";

	public static final String UNABLE_TO_QUOTE_ERROR = "Sorry, we were not able to complete your quote online.";

	public static final String MAX_HOUSE_VALUE_ERROR = "Maximum value is 2000000000";

	public static final String UPGRADE_YEAR_SHOULD_BE_LATER_THAN_2010_ERROR = "Value must not be lesser than year of construction build 2010";

	public static final String CAN_NOT_PROCESS_CLAIM_ERROR = "Based on the information you have provided, we are unable to process this claim online.";

	public static final String CALL_AGENT_FOR_CLAIM_ASSISTANCE_ERROR = "Please call one of our agents at 1-866-555-0124 for assistance with submitting your claim.";

	public static final String CONTACT_NUM_REQUIRED_ERROR = "At least one contact number must be provided";

	public static final String EMAIL_FORMAT_ERROR = "Value must be a valid email address";

	public static final String INVALID_CREDIT_CARD_ERROR = "Number must be a valid credit card number";

	public static final String INVALID_PROP_CLASS_CODE_ERROR = "Please specify a valid property class code";

	public static final String NO_ACTIVITIES_WARNING_TEXT="No Activities found.";

	public static final String NO_REPAIR_OPTION_SELECTED_ERROR = "Repair option selection is required";

	public static final String NO_REPAIR_FACILITY_SELECTED_ERROR = "Please select a repair facility";

	public static final String NO_BUILDING_SELECTED_ERROR = "Please select at least one building to proceed.";

	public static final String NO_POLICY_ADDRESS_SELECTED_ERROR = "Please provide an address.";

	public static final String NOTE_CREATED_MSG = "Note Created";
	
	public static final String NO_VEHICLE_ASSIGNED_MSG = "Please assign a vehicle to";
	
	public static final String NO_DRIVER_ASSIGNED_MSG = "No driver assigned to";

	//Page URL SubString

	public static final String ASTERISK = "*";

	public static final String PA_YOUR_INFO_PAGE = "contact-details";

	public static final String PA_QUALIFICATION_PAGE = "prequal-questions";

	public static final String PA_DRIVER_PAGE = "driver-details";

	public static final String PA_PAYMENT_PAGE = "payment-details";

	public static final String PA_VEHICLE_PAGE = "vehicle-details";

	public static final String QUOTE_PAGE = "quote-details";

	public static final String POLICY_INFO_PAGE = "policy-info";

	public static final String POLICY_CHANGE_PAGE_TITLE = "Policy Changes";

	public static final String PA_PAYMENT_DETAILS_PAGE = "payment-details";

	public static final String PA_CONFIRMATION_PAGE = "confirmation";

	public static final String HO_YOUR_HOME_PAGE = "your-home";

	public static final String HO_CONSTRUCTION_PAGE = "construction";

	public static final String HO_DISCOUNT_PAGE = "rating";

	public static final String QnB_HOME_PAGE = "home";


	// Alert Pop Up

	public static final String NO_PERIOD_FOR_POLICY_ERROR = "Cannot cancel policy: No period for this effective date";

	public static final String CAN_NOT_PROCEED_HEADER = "Unable to Generate a Quote";
	
	public static final String UNABLE_TO_PURCHASE_QUOTE_HEADER = "Unable to purchase quote";

	public static final String CALCULATING_QUOTE = "Calculating Quote...";

	public static final String CAN_NOT_PROCEED_DESC = "An error occurred while attempting to calculate a quote.";
	
	public static final String CAN_NOT_BIND_DESC = "An error occurred while attempting to bind your quote submission";

	public static final String CANCEL_SUBMISSION_HEADER = "Want to Cancel?";

	public static final String NO_BUILDING_HEADER = "No Building Added";

	public static final String NO_PAYMENT_PLAN_HEADER = "No Payment Plan Selected";

	public static final String QUOTE_RETRIVAL_ERROR_HEADER = "Error retrieving submission";

	public static final String PROCESSING_PAYMENT_HEADER = "Processing Payment...";

	public static final String CANCEL_CONFIRMATION_TEXT = "Are you sure you want to cancel the submission?";

	public static final String CANCEL_QUOTE_SUBMISSION_DESC = "The information previously entered will be stored as a draft";

	public static final String CANCEL_CLAIM_SUBMISSION_DESC = "The information previously entered will be stored as a draft claim.";

	public static final String QUOTE_RETRIVAL_ERROR_DESC = "Sorry, but we can't seem to locate a quote with that number and that ZIP code. Please try again.";

	public static final String DATA_ENTRY_ENROLLMENT_ERROR = "All fields are required. Please ensure all fields are completed.";

	public static final String INVALID_PROP_CLASS_CODE_HEADER = "Invalid property class code";
	
	public static final String CHANGE_BOUND_MSG = "Your change was bound successfully.";
	
	public static final String CHANGE_BOUND_ALERT_HEADER_MSG = "Change bound";

	public static final String UPLOAD_FAILED_HEADER_MSG = "Error";

	public static final String UPLOAD_FAILED_ERR_DESC = "Failed to upload file, either you do not have permission or a file exists with the same name.";


	public static final String POLICYTYPE_DATA_COL = "PolicyType";

	public static final String HO = "HomeOwner";

	public static final String PA = "PersonalAuto";

	public static final String BOP = "BusinessOwner";

	public static final String HOUSE_VALUE_2000000001 = 	"2000000001";

	public static final String HOUSE_VALUE_2000000000 = 	"2000000000";

	public static final Object PAYMENT_PLAN_CONF_HEADER = "No Payment Plan Selected";

	public static final Object PAYMENT_PLAN_CONF_BODY = "Please select a payment plan and try again.";

	public static final Object INFO_BAR_ADDRESS = "[MounJoy Square, Dublin, CA 94404]";

	public static final Object FULL_PAY_ANNUAL_PLAN = "F Annual 100% Down, 0 Max installments";
	public static final Object INOW_FULL_PAY_ANNUAL_PLAN = "Direct Bill Pay In Full";
	public static final Object INOW_AUTOMATED_12_MONTHS_PLAN = "Automated 12 Payments";

	//Claim Portal

	public static final Object ENTIRE_VEH_STOLEN_LABEL = "The entire vehicle";

	public static final Object AUDIO_EQUIP_STOLEN_LABEL = "Audio or other equipment on or in the vehicle";

	// AMP

	public static final String ADD_ACTION = "added";

	public static final String REMOVE_ACTION = "removed";

	public static final String REPLACE_ACTION = "Payment Complete";

	public static final String EDIT_ACTION = "change";

	public static final String PAYMENT_COMPLETE_TEXT = "Payment Complete";
	
	public static final String PAYMENT_INVOICE_APPLIED_TEXT = "Payment of $%s has been applied to your account.\n"+
			"OK";
	public static final String OVERPAY_ERROR_TEXT = "Overpay is not supported.";

	public static final String POSITIVE_PAYMENT_TEXT = "Payment amount must be positive.";

	public static final String REQUIRED_PAYMENT_AMOUNT_TEXT = "This is a required field";

	public static final String MUST_BE_NUMBER_TEXT = "Please enter numbers only.";

	public static final String AUTOMATIC_PAYMENT_ENABLED_TEXT = "Your payment method has been successfully updated to automatic renewal.\n" +
            "Your automatic payments will begin on %s\n"+
            "OK";
	
	public static final String AUTOMATIC_PAYMENT_CHANGED_TEXT = "Payment method has been changed.\n"+
			"OK";

	public static final String ACCOUNT_SUMMARY_TITLE_TEXT = "Account Summary";

	public static final String BILLING_SUMMARY_TITLE_TEXT = "Billing Summary";

	public static final String MAKE_PAYMENY_TITLE_TEXT = "Make a Payment";

	public static final String CANCEL_ACCOUNT_UPDATE_TEXT = "Are you sure you want to cancel your account contact profile changes?";

	public static final String UPDATE_SUBMISSION_TEXT_ADDRESS = "Your changes have been recorded and must be reviewed before they can be approved. This approval process can take a number of days and it may be required to contact you.";

	public static final String UPDATE_SUBMISSION_TEXT_PHONE = "You have successfully updated your accounts contact information.";

	public static final String ACTIVITY_CREATED_MODAL_TEXT = "Activity created";

	public static final String YOU_MUST_CHOOSE_AN_ACTIVITY_TYPE_ERROR_TEXT = "No Activity Type Selected";

	public static final String BASIC_QUOTE_LABEL = "Basic Program";

	public static final String BASE_QUOTE_LABEL = "Base";

	public static final String STANDARD_QUOTE_LABEL = "Standard Program";

	public static final String PREMIUM_QUOTE_LABEL = "Premium Program";

	public static final String CUSTOM_QUOTE_LABEL = "Custom";

	public static final String BUY_NOW_BUTTON_TXT = "Buy Now";

	public static final String STANDARD_PROGRAM = "Standard Program";

	public static final String PREMIUM_PROGRAM = "Premium Program";
	
	public static final String NEXUS5 = "NEXUS5";
	
	public static final String IPHONE6 = "IPHONE6";

	public static String ACTIVITY_COMPLETE_TEXT = "COMPLETED";

	public static String ME = "Me";


	// GPA

	public static String EXPIRED_DATE_ERROR_MESSAGE = "Please set a date that is before the expiry date of the policy";

	public static String INFO_MESSAGE_TEXT = "There are underwriting issues associated with the Basic Program, Standard Program and Premium Program offerings. View More Details.";

	public static String UNDERWRITING_MESSAGE_TITLE_TEXT = "Underwriting issues have been raised for this quote.";

	public static String UNDERWRITING_MESSAGE_TITLE_TEXT_2 = "Underwriting issues have been raised for the following quotes:";
	
	public static String UNDERWRITING_MESSAGE_LINE1_TEXT = "You cannot complete this quote until these issues have been resolved. You can do the following:";

	public static String UNDERWRITING_MESSAGE_LINE2_TEXT = "Edit the quote if the customer is willing to accept the changes.";

	public static String UNDERWRITING_MESSAGE_LINE3_TEXT = "Refer the quote to an underwriter for review.";

	public static String UNDERWRITING_MESSAGE_LINE4_TEXT = "Withdraw this quote if you do not wish to continue.";

	public static String UNDERWRITING_MESSAGE_LIST_LINE1 = "Edit the quote if the customer is willing to accept the change";

	public static String UNDERWRITING_MESSAGE_LIST_LINE2 = "Approve the issue(s)";

	public static String UNDERWRITING_MESSAGE_LIST_LINE3 = "Refer the quote to the underwriter";

	public static String UNDERWRITING_MESSAGE_LIST_LINE4 = "Withdraw the quote";
	
	public static String UNDERWRITING_MESSAGE_POLICY_CHANGE_TITLE_TEXT = "Underwriting issues have been raised for this policy change.";
	
	public static String UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE1_TEXT = "You cannot complete this policy change until these issues have been resolved. You can do the following:";

	public static String UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE2_TEXT = "Edit the policy change if the customer is willing to accept the changes.";

	public static String UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE3_TEXT = "Refer the policy change to an underwriter for review.";

	public static String UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE4_TEXT = "this policy change if you do not wish to continue.";

	public static String UNDERWRITING_MESSAGE_HEADER_ENDORSMENT_PAYMENT_PAGE = "Contact Underwriter";

	public static String UNDERWRITING_MESSAGE_LINE1_ENDORSMENT_PAYMENT_PAGE = "We are unable to process this policy change online.";

	public static String UNDERWRITING_MESSAGE_LINE2_ENDORSMENT_PAYMENT_PAGE = "Please call one of our underwriters for assistance in submitting your policy change.";

	public static String SD_HIGH_VALUE_VEHICLE_TEXT = "High-value vehicle";

	public static String BASIC_PROGRAM_TEXT = "Blocks Bind";

	public static String NO_ADD_CVG_MSG_TEXT = "No Additional Coverages";

	public static String ADD_BLDNG_FOR_CVG_MSG_TEXT = "Please provide building details to see the coverages.";

	public static String CUSTOM_STATUS_TEXT = "Blocks Quote";

	public static String SD_PRIMARY_DRIVER_UNDER_25_TEXT = "Primary Driver under 25";

	public static String SD_DRIVER_UNDER_25_TEXT = "Driver under 25";

	public static String DISQUALIFICATION = "Disqualification: Applicant has a suspended/revoked license.";

	public static String POLICY_DECLINED_HISTOTY_TEXT = "Policy has been declined, canceled, or non-renewed during the prior 3 years";

	public static String QUOTE_WITHDRAWN_TITLE_TEXT = "This quote has been withdrawn.";

	public static String REFERED_TO_UNDERWRITER_FOR_REVIEW_TEXT = "This quote has been referred to an underwriter for review.";

	public static String REFER_TO_UNDERWRITER_TEXT = "Once referred, a high priority activity will be created for the underwriter. You will not be able to edit the quote until the underwriter releases it back to you.";

	public static String ACTIVITY_TITLE = "DUE TOMORROW";

	public static String ACTIVITY_TYPE = "Review and approve";

	public static String NOTE_TEXT = "This is my Note";

	public static String QUOTED_CANCELLATION_MESSAGE_HEADER = "The cancellation refund amount has been calculated.";

	public static String QUOTED_CANCELLATION_MESSAGE_BODY = "You can either bind or withdraw the cancellation.";

	public static String BOUND_CANCELLATION_MESSAGE_HEADER = "This cancellation has been bound.";

	public static String BOUND_CANCELLATION_MESSAGE_BODY = "If you need to reinstate this policy, please contact the underwriter.";

	public static String NO_BUILDING_TOOLTIP_TXT = "You need to add at least 1 building to get a quote.";

	public static String BUILDING_SAVED_ALERT_MSG = "Building saved.";

	public static String BUILDING_CHANGES_SAVED_ALERT_MSG = "Building changes saved.";

	public static String EDIT_LOC_MULT_BUILDINGS_ALERT_MSG = "You are editing a location used for 2 Buildings and the changes you make here will apply to all of them.\n" +
			"If you want to change the location for individual building, proceed as follows:\n" +
			"Click View Buildings.\n" +
			"Select the building.\n" +
			"Expand \"Location\" and choose either new or existing location.";

	public static String TRANSACTION_CONFIRMATION_MSG = "Your changes have been confirmed.\n" +
			"Reference Number: jobNum\n" +
			"Businessowners policy: policyNum\n" +
			"You can check the payment schedule and invoices here: Policy Billing Page\n" +
			"View Policy Change Details\n" +
			"View Policy";

	public static String QUOTE_ALERT_NO_CHANGE_MSG = "There are no changes to the premium.\n" +
			"The changes you've made to the policy don't affect the premium.";

	public static String QUOTE_ALERT_DECREASE_MSG = "There is a decrease in the premium\n" +
			"The new premium is now $newPremium. That is $changePremium less than the current premium and will be reflected in upcoming invoices.";

	public static String QUOTE_ALERT_INCREASE_MSG = "There is an increase in the premium\n" +
			"The new premium is now $newPremium. This is an increase of $changePremium on the current premium and will be reflected in upcoming invoices.";

	public static final String[] BOP_MESSAGE_QUOTED_RENEWAL = {"The renewal for Businessowners policy $policyNum is quoted. It will be bound automatically on", "If you need to make a change, click Edit Renewal.", "If you need to withdraw this renewal transaction, click Withdraw Renewal."};

	public static final String[] BOP_MESSAGE_DRAFT_RENEWAL = {"The renewal for Businessowners Policy $policyNum has been successfully started.", "If you need to make a change, click Edit Renewal.", "If you need to withdraw this renewal transaction, click Withdraw Renewal."};

	public static final String[] RENEWAL_PAYMENT_MSG_AGENT = {"You do not have permission to issue this renewal", "If you would like this renewal to be issued, please refer it to an underwriter for their consideration."};

	public static final String[] BOP_MESSAGE_NOT_TAKEN_RENEWAL = {"This renewal has not been taken.", "If you need to make a change, click Edit Renewal.", "If you need to withdraw this renewal transaction, click Withdraw Renewal."};

	public static final String[] BOP_MESSAGE_NOT_RENEWING_RENEWAL = {"This renewal is non-renewing.", "If you need to make a change, click Edit Renewal.", "If you need to withdraw this renewal transaction, click Withdraw Renewal."};

	//SignUp

	public static final String SIGN_UP_FIELDS_VALIDATION_MESSAGE = "All fields are required to sign up.";

	public static final String SIGN_UP_EMAIL_VALIDATION_MESSAGE = "Please enter a valid email address.";

	public static final String SIGN_UP_PASSWORD_MATCH_VALIDATION_MESSAGE = "Fields password and confirmation do not match.";

	public static final String EMAIL_ALREADY_EXISTS_MESSAGE = "Email already exists";

	//Quote&Buy

	public static final String GTP_PRODUCT_OFFERING_HEADER_TEXT = "Based on what you told us, you could consider";

	public static final String PRODUCT_CODE_COMMERCIAL_AUTO = "Commercial Auto";

	public static final String PRODUCT_CODE_BUSINESSOWNER = "Businessowners";

	public static final String PRODUCT_CODE_WORKERS_COMPENSATION = "Workers' Compensation";

	public static final Object POLICY_REGISTRATION_DATA_ERROR = "Enter your policy number and the first line of your address to associate your policy with this account.";


}
