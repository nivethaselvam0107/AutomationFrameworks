package com.guidewire.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.guidewire.common.util.DataFormatUtil;
import io.restassured.path.json.JsonPath;


public class ParseEndorsementData {

    public static List<HashMap<String,String>> getDrivers(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        List<HashMap<String,Object>> list = path.getList("lobs.personalAuto.drivers");
        List<HashMap<String,String>> drivers = new ArrayList<>();

        for (HashMap<String, Object> driverData : list){
            HashMap<String, String> driver = new HashMap();
            for (String key : driverData.keySet()){
                if (!key.equals("person")){
                    driver.put(key, driverData.get(key).toString());
                }
            }

            HashMap<String, String> person = (HashMap<String,String>)driverData.get("person");
            driver.put("firstName", person.get("firstName"));
            driver.put("lastName", person.get("lastName"));
            drivers.add(driver);
        }
        return drivers;
    }

    public static List<HashMap<String,String>> getVehicles(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        List<HashMap<String,Object>> list = path.getList("lobs.personalAuto.vehicles");
        List<HashMap<String,String>> vehicles = new ArrayList<>();

        for (HashMap<String, Object> vehicleData : list){
            HashMap<String, String> vehicle = new HashMap();
            for (String key : vehicleData.keySet()){
                if (!key.equals("costNew")){
                    vehicle.put(key, vehicleData.get(key).toString());
                }
            }

            vehicle.put("costNew",((HashMap<String,Object>)vehicleData.get("costNew"))
                    .get("amount").toString().replace(".0", ""));
            vehicles.add(vehicle);
        }

        return vehicles;
    }

    public static List<HashMap<String,Object>> getVehicleCoverages(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        List<HashMap<String,Object>> vehicleCoveragesFromBackend = path.getList("coverageLobs.personalAuto.vehicleCoverages");
        List<HashMap<String,Object>> vehicleCoverages = new ArrayList<>();

        for (HashMap<String, Object> vehicleCoverage : vehicleCoveragesFromBackend){
            HashMap<String, Object> coverage = new HashMap();
            coverage.put("vehicleName",vehicleCoverage.get("vehicleName").toString());
            coverage.put("coverages", getCoveragesFromList((List<HashMap<String,Object>>)vehicleCoverage.get("coverages")));
            vehicleCoverages.add(coverage);
        }


        return vehicleCoverages;
    }

    public static List<HashMap<String,String>> getLineCoverages(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        List<HashMap<String,Object>> lineCoveragesFromBackend = path.getList("lobData.personalAuto.offerings.coverages.lineCoverages[0]");
        List<HashMap<String,String>> lineCoverages = new ArrayList<>();
        return getCoveragesFromList(lineCoveragesFromBackend);
    }

    private static List<HashMap<String,String>> getCoveragesFromList(List<HashMap<String,Object>> coverages){
        List<HashMap<String,String>> parsedCoverages = new ArrayList<>();

        for (HashMap<String, Object> lineCoverage : coverages){
            HashMap<String, String> coverage = new HashMap();
            coverage.put("name",lineCoverage.get("name").toString());
            coverage.put("selected",lineCoverage.get("selected").toString());
            coverage.put("required",lineCoverage.get("required").toString());
            parsedCoverages.add(coverage);
        }

        return parsedCoverages;
    }

    public static List<HashMap<String,String>> getHistory(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        return path.getList("history");
    }

    public static void main(String[] args) {
        try {
            System.out.println((getVehicleCoverages(DataFetch.getPolicyChangeData("4114666523", "mmurphy"))));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static String getPeriodEndDate(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String periodEnd = path.getString("periodEnd");
        return periodEnd;
    }

    public static HashMap<String,String> getBOPLineGeneralCoveragesForPolicyChange(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        String lineGenCoveIteration = "lobData.businessOwners.coverages.lobCoverages";
        int baseCovCount = path.getList(lineGenCoveIteration).size();
        HashMap<String, String> genCoverage = new HashMap();
        for (int i = 0; i < baseCovCount; i++) {

            String covItr = lineGenCoveIteration + "[" + i + "]";
            // BOP General Coverage - Employee Dishonesty
            if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("Employee Dishonesty")) {

               DataFormatUtil.putData(genCoverage, "Employee_Dishonesty_Selected", DataFormatUtil.getNodeValue(path, covItr , "selected"));
               DataFormatUtil.putData(genCoverage, "Employee_Dishonesty_Limit", DataFormatUtil.getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
               DataFormatUtil.putData(genCoverage, "No_Covered_Employees", DataFormatUtil.getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
               DataFormatUtil.putData(genCoverage, "No_Covered_Locations", DataFormatUtil.getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));

            }
        }
        return genCoverage;
    }

    public static HashMap<String,String> getBOPLineAdditionalCoveragesForPolicyChange(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        String lineAddtnlCoveIteration = "lobData.businessOwners.coverages.additionalCoverages";
        int addtnlCovCount = path.getList(lineAddtnlCoveIteration).size();
        HashMap<String, String> addtnlCoverage = new HashMap();
        for (int i = 0; i < addtnlCovCount; i++) {

            String covItr = lineAddtnlCoveIteration + "[" + i + "]";
            // BOP Additional Coverage - Guests Property In Safe Deposit
            if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("Guests Property In Safe Deposit")) {

                DataFormatUtil.putData(addtnlCoverage, "Guest_Prop_Safe_deposit_Selected", DataFormatUtil.getNodeValue(path, covItr , "selected"));
                DataFormatUtil.putData(addtnlCoverage, "Guest_Prop_Safe_deposit_Limit", DataFormatUtil.getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
            }
        }
        return addtnlCoverage;
    }

    public static HashMap<String,String> getBOPLinePolicyDetailsForPolicyChange(String jsonData){
       JsonPath path = new JsonPath(jsonData);
       HashMap<String, String> bopPolicyDetails = new HashMap();
       DataFormatUtil.putData(bopPolicyDetails, "Small_Bus_Type", DataFormatUtil.getNodeValue(path,"lobData.businessOwners.smallBusinessType"));
       DataFormatUtil.putData(bopPolicyDetails, "Org_Type", DataFormatUtil.getNodeValue(path, "lobData.businessOwners.accountOrgType"));
       return bopPolicyDetails;
    }

    public static HashMap<String,String> getCPLinePolicyDetailsForPolicyChange(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        HashMap<String, String> cpPolicyDetails = new HashMap();
        DataFormatUtil.putData(cpPolicyDetails, "Org_Type", DataFormatUtil.getNodeValue(path,"lobData.commercialProperty.accountOrgType"));
        return cpPolicyDetails;
    }

    public static String getJobStatus(String jsonData){
        JsonPath path = new JsonPath(jsonData);
        return path.get("status");
    }

    public static HashMap<String,String> getQuoteDetailsForPolicyChange(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        HashMap<String, String> quoteDetails = new HashMap();
        DataFormatUtil.putData(quoteDetails, "Total_Premium", DataFormatUtil.getNodeValue(path, "totalCost.amount")+"0");
        DataFormatUtil.putData(quoteDetails, "Previous_Total", DataFormatUtil.getNodeValue(path, "previousTotalCost.amount")+"0");
        DataFormatUtil.putData(quoteDetails, "Taxes", DataFormatUtil.getNodeValue(path, "taxes.amount")+"0");
        String changeInPremium = DataFormatUtil.getNodeValue(path, "transactionCost.amount")+"0";
        if(changeInPremium.contains("-")){
            DataFormatUtil.putData(quoteDetails, "Premium_Increase", "false");
            DataFormatUtil.putData(quoteDetails, "Premium_Change", changeInPremium.replace("-",""));
        }
        else {
            DataFormatUtil.putData(quoteDetails, "Premium_Increase", "true");
            DataFormatUtil.putData(quoteDetails, "Premium_Change", changeInPremium);
        }
        return quoteDetails;
    }

    public static HashMap<String,String> getBOPBuildingDetailsForPolicyChange(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String buildingDetailsFirstBldng = "lobData.businessOwners.coverables.locations[0]";
        int buildingCovCount =  path.getList(buildingDetailsFirstBldng+".buildings[0].baseCoverages").size();
        HashMap<String, String> buildingDetails = new HashMap();
        DataFormatUtil.putData(buildingDetails, "Building_Desc", DataFormatUtil.getNodeValue(path, buildingDetailsFirstBldng , "buildings[0].name"));
        DataFormatUtil.putData(buildingDetails, "Basis_Amount", DataFormatUtil.getNodeValue(path, buildingDetailsFirstBldng , "buildings[0].basisAmount"));

        for (int i = 0; i < buildingCovCount; i++) {
            String covItr = buildingDetailsFirstBldng + ".buildings[0].baseCoverages" + "[" + i + "]";
            if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Building")) {
                DataFormatUtil.putData(buildingDetails, "Building_Limit", DataFormatUtil.getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
            }
        }
        return buildingDetails;
    }
}
