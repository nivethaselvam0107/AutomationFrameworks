package com.guidewire.data;

import java.net.HttpURLConnection;
import com.thetransactioncompany.jsonrpc2.client.ConnectionConfigurator;

import java.util.Base64;


public class BasicAuthenticator implements ConnectionConfigurator {

	private String user;
	private String pass;

	public void setCredentials(String user, String pass) {
		this.user = user;
		this.pass = pass;
	}

	@Override
	public void configure(HttpURLConnection connection) {
		String value = user + ":" + pass;
		byte[] encoded = Base64.getEncoder().encode(value.getBytes());
		// add custom HTTP header
		connection.addRequestProperty("Authorization", "Basic " + new String(encoded));
	}
}