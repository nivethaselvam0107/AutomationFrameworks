package com.guidewire.data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.guidewire.capabilities.quote.data.HOPQuoteData;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.DateUtil;

import io.restassured.path.json.JsonPath;

public class ParseQuoteData {
	public static HashMap<String, String> getPersonalInfoFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String accHolder = "baseData.accountHolder";
		info.put("FirstName", getNodeValue(path, accHolder, "firstName"));
		info.put("LastName", getNodeValue(path, accHolder, "lastName"));
		info.put("PolicyHolderDisplayName", getNodeValue(path, accHolder, "displayName"));
		String phoneNum = getNodeValue(path, accHolder, "homeNumber");
		if (phoneNum != null) {
			info.put("PhoneNumber", getNodeValue(path, accHolder, "homeNumber"));
		}
		info.put("Email", getNodeValue(path, accHolder, "emailAddress1"));
		// Month is incremented by 1 here as javascript month index is 0 based.
		String accholderDOB = "baseData.accountHolder.dateOfBirth";
		if (ThreadLocalObject.getData().get("PolicyType").equals("PersonalAuto")) {
			info.put("DOB", ((Integer.parseInt(getNodeValue(path, accholderDOB, "month"))) + 1) + "/" + getNodeValue(path, accholderDOB, "day") + "/" + getNodeValue(path, accholderDOB, "year"));
		}
		String policyAdd = "baseData.policyAddress";
		info.put("CovStartDate", getNodeValue(path, policyAdd, "day") + "/" + getNodeValue(path, policyAdd, "month") + "/" + getNodeValue(path, policyAdd, "year"));
		info.putAll(getHOPolicyAdressFromBackEnd(jsonData));
		return info;
	}
	
	public static HashMap<String, String> getQuickQuoteDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		info.putAll(getPersonalInfoFromBackEnd(jsonData));
		info.putAll(getVehicelDetailsFromBackEnd(jsonData));
		info.putAll(getDriverDetailsFromBackEnd(jsonData));
		info.putAll(getPolicySummaryDataFromBackEnd(jsonData));
		return info;
	}

	public static HashMap<String, String> getHOPolicyAdressFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String policyAdd = "baseData.policyAddress";
		info.put("ZipCode", getNodeValue(path, policyAdd, "postalCode"));
		info.put("AddressLine1", getNodeValue(path, policyAdd, "addressLine1"));
		info.put("AddressLine2", getNodeValue(path, policyAdd, "addressLine2"));
		info.put("AddressLine3", getNodeValue(path, policyAdd, "addressLine3"));
		info.put("AddressType", getNodeValue(path, policyAdd, "addressType"));
		info.put("City", getNodeValue(path, policyAdd, "city"));
		info.put("AddressDisplayName", getNodeValue(path, policyAdd, "displayName"));
		info.put("Country", getNodeValue(path, policyAdd, "country"));
		info.put("CityValue", getNodeValue(path, policyAdd, "state"));
		return info;
	}

	public static HashMap<String, String> getHOPreQualificationAnswerFromBackEnd(String jsonData) throws Exception {
		String question = "lobData.homeowners.preQualQuestionSets[0].answers";
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		info.put("TypeOfBusiness", getNodeValue(path, question, "HOBusinesType_HOE"));
		info.put("CoverageDeclineStatus", getNodeValue(path, question, "HOCovDeclined_HOE"));
		info.put("BusinessOnPremiseStatus", getNodeValue(path, question, "HOBusiness_HOE"));
		info.put("OtherBusinessDesc", getNodeValue(path, question, "HOBusTypeOther_HOE"));
		return info;
	}

	public static HashMap<String, String> getPAPreQualificationAnswerFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String answersPath = "lobData.personalAuto.preQualQuestionSets.answers";
		info.put("InsuranceStatusValue", getNodeValue(path, answersPath, "PACurrentlyInsured"));
		info.put("CurrentLicencseStatus", getNodeValue(path, answersPath, "CurrentSuspense"));
		info.put("LicencseCancelledAnyTime", getNodeValue(path, answersPath, "Suspense"));
		info.put("TrafficeViolationHistoryDetails", getNodeValue(path, answersPath, "DriverNameConviction"));
		info.put("TrafficeViolationHistory", getNodeValue(path, answersPath, "MovingViolations2"));
		info.put("PolicyDeclinedHistory", getNodeValue(path, answersPath, "PriorDeclinedPolicy"));
		return info;
	}

	public static HashMap<String, String> getYourHomeDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String homePath = "lobData.homeowners.coverables.yourHome";
		info.put("LocTypeValue", getNodeValue(path, homePath, "dwellingLocation"));
		info.put("HomeUsageValue", getNodeValue(path, homePath, "dwellingUsage"));
		info.put("FloodFireHazard", getNodeValue(path, homePath, "floodingOrFireHazard"));
		info.put("DistanceToFireStationValue", getNodeValue(path, homePath, "distanceToFireStation"));
		info.put("HomeValue", getNodeValue(path, homePath, "replacementCost"));
		info.put("DistanceToFireHydrantValue", getNodeValue(path, homePath, "distanceToFireHydrant"));
		info.put("OccupencyTypeValue", getNodeValue(path, homePath, "occupancy"));
		info.put("ResTypeValue", getNodeValue(path, homePath, "residenceType"));
		info.put("NearCommerProp", getNodeValue(path, homePath, "nearCommercial"));
		return info;
	}

	public static HashMap<String, String> getDriverDetailsFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String driver = "lobData.personalAuto.coverables.drivers[0]";
		String driverName = driver + ".person";
		String driverDOB = driver + ".dateOfBirth";
		info.put("DriverLastName", getNodeValue(path, driverName, "lastName"));
		info.put("DriverFirstName", getNodeValue(path, driverName, "firstName"));
		// Month is incremented by 1 here as javascript month index is 0 based.
		info.put("DriverDOB", (Integer.parseInt(getNodeValue(path, driverDOB, "month")) + 1) + "/" + getNodeValue(path, driverDOB, "day") + "/" + getNodeValue(path, driverDOB, "year"));
		info.put("DriverGendorValue", getNodeValue(path, driver, "gender"));
		info.put("DriverLicenseNum", getNodeValue(path, driver, "licenseNumber"));
		info.put("DriverLicenseStateValue", getNodeValue(path, driver, "licenseState"));
		info.put("FirstYearLicensed", getNodeValue(path, driver, "yearLicensed"));
		info.put("ViolationNum", getNodeValue(path, driver, "violations"));
		info.put("AccidentNum", getNodeValue(path, driver, "accidents"));
		info.put("DriverFullName", getNodeValue(path, driverName, "firstName") + " " + getNodeValue(path, driverName, "lastName"));
		return info;
	}
	
	public static HashMap<String, String> getNewAdditionalDriverDetailsFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String driver = "lobData.personalAuto.coverables.drivers";
		int driverCount = path.getList(driver).size();
		for(int i =0 ; i< driverCount; i++) {
			String driverIndex = driver + "[" + i + "]";
			if(getNodeValue(path, driverIndex, "isPolicyHolder").equalsIgnoreCase("false")){
				
				String driverName = driverIndex + ".person";
				String driverDOB = driverIndex + ".dateOfBirth";
				info.put("NewDriverLastName", getNodeValue(path, driverName, "lastName"));
				info.put("NewDriverFirstName", getNodeValue(path, driverName, "firstName"));
				// Month is incremented by 1 here as javascript month index is 0 based.
				info.put("NewDriverDOB", (Integer.parseInt(getNodeValue(path, driverDOB, "month")) + 1) + "/" + getNodeValue(path, driverDOB, "day") + "/" + getNodeValue(path, driverDOB, "year"));
				info.put("NewDriverGendorValue", getNodeValue(path, driverIndex, "gender"));
				info.put("NewDriverLicenseNum", getNodeValue(path, driverIndex, "licenseNumber"));
				info.put("NewDriverLicenseStateValue", getNodeValue(path, driverIndex, "licenseState"));
				info.put("NewDriverFirstYearLicensed", getNodeValue(path, driverIndex, "yearLicensed"));
				info.put("NewDriverViolationNum", getNodeValue(path, driverIndex, "violations"));
				info.put("NewDriverAccidentNum", getNodeValue(path, driverIndex, "accidents"));
				info.put("NewDriverFullName", getNodeValue(path, driverName, "firstName") + " " + getNodeValue(path, driverName, "lastName"));
			}
		}
		return info;
	}

	public static HashMap<String, String> getVehicelDetailsFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String vehicle = "lobData.personalAuto.coverables.vehicles[0]";
		info.put("VIN", getNodeValue(path, vehicle, "vin"));
		info.put("Make", getNodeValue(path, vehicle, "make"));
		info.put("Model", getNodeValue(path, vehicle, "model"));
		info.put("VehicleYear", getNodeValue(path, vehicle, "year"));
		info.put("LicensePlate", getNodeValue(path, vehicle, "license"));
		info.put("VehicleStateValue", getNodeValue(path, vehicle, "licenseState"));
		info.put("VehicleState", "California");// Default Data
		info.put("VehicleCost", getNodeValue(path, vehicle + ".costNew", "amount"));
		info.put("VehicleDisplayName", getNodeValue(path, vehicle, "displayName"));
		return info;
	}
	
	public static HashMap<String, HashMap<String, String>> getAllVehicleDetailsFromBackEnd(String jsonData) throws Exception {
		HashMap<String, HashMap<String, String>> vehicleList = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String vehicle = "lobData.personalAuto.coverables.vehicles";
		int driverCount = path.getList(vehicle).size();
		for(int i =0 ; i< driverCount; i++) {
				String vehicleIndex = vehicle + "[" + i + "]";
				HashMap<String, String> vehicleData = new HashMap<>();
				vehicleData.put("VIN", getNodeValue(path, vehicleIndex, "vin"));
				vehicleData.put("Make", getNodeValue(path, vehicleIndex, "make"));
				vehicleData.put("Model", getNodeValue(path, vehicleIndex, "model"));
				vehicleData.put("VehicleYear", getNodeValue(path, vehicleIndex, "year"));
				vehicleData.put("LicensePlate", getNodeValue(path, vehicleIndex, "license"));
				vehicleData.put("VehicleStateValue", getNodeValue(path, vehicleIndex, "licenseState"));
				vehicleData.put("VehicleState", "California");// Default Data
				vehicleData.put("VehicleCost", getNodeValue(path, vehicleIndex + ".costNew", "amount"));
				vehicleData.put("VehicleDisplayName", getNodeValue(path, vehicleIndex, "displayName"));
				vehicleList.put(getNodeValue(path, vehicleIndex, "vin"), vehicleData);
		}
		return vehicleList;
	}

	public static HashMap<String, String> getConstructionDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String constructionPath = "lobData.homeowners.coverables.construction";
		info.put("BuildYear", getNodeValue(path, constructionPath, "yearBuilt"));
		info.put("Stories", getNodeValue(path, constructionPath, "storiesNumber"));
		info.put("HasGarage", getNodeValue(path, constructionPath, "hasGarage"));
		info.put("ConstructionTypeValue", getNodeValue(path, constructionPath, "constructionType"));
		info.put("FoundationType", getNodeValue(path, constructionPath, "foundationType"));
		info.put("RoofType", getNodeValue(path, constructionPath, "roofType"));

		String roofUpgradeExists = getNodeValue(path, constructionPath, "roofUpgradeExists");
		if (Boolean.getBoolean(roofUpgradeExists)) {
			info.put("RoofUpGradeFlag", roofUpgradeExists);
			info.put("RoofUpgradeYear", getNodeValue(path, constructionPath, "roofUpgradeYear"));
		}

		info.put("PlumbingTypeValue", getNodeValue(path, constructionPath, "plumbingType"));
		// info.put("PlumbingUpGradeFlag",
		// getNodeValue(path, "draftData.lobs.homeowners.construction",
		// "plumbingUpgradeExists"));

		String plumbingUpgradeExists = getNodeValue(path, constructionPath, "plumbingUpgradeExists");
		if (Boolean.getBoolean(plumbingUpgradeExists)) {
			info.put("PlumbingUpGradeFlag", plumbingUpgradeExists);
			info.put("PlumbingUpgradeYear", getNodeValue(path, constructionPath, "plumbingUpgradeYear"));
		}

		info.put("HeatingTypeValue", getNodeValue(path, constructionPath, "primaryHeatingType"));
		// info.put("HeatingUpGradeFlag",
		// getNodeValue(path, "draftData.lobs.homeowners.construction",
		// "heatingUpgradeExists"));

		String heatingUpgradeExists = getNodeValue(path, constructionPath, "heatingUpgradeExists");
		if (Boolean.getBoolean(heatingUpgradeExists)) {
			info.put("HeatingUpGradeFlag", heatingUpgradeExists);
			info.put("HeatingUpgradeYear", getNodeValue(path, constructionPath, "heatingUpgradeYear"));
		}

		info.put("SecondaryHeating", getNodeValue(path, constructionPath, "secondaryHeatingExists"));

		info.put("WiringTypeValue", getNodeValue(path, constructionPath, "wiringType"));
		// info.put("WiringUpGradeFlag",
		// getNodeValue(path, "draftData.lobs.homeowners.construction",
		// "wiringUpgradeExists"));

		String wiringUpgradeExists = getNodeValue(path, constructionPath, "wiringUpgradeExists");
		if (Boolean.getBoolean(wiringUpgradeExists)) {
			info.put("WiringUpGradeFlag", wiringUpgradeExists);
			info.put("WiringUpgradeYear", getNodeValue(path, constructionPath, "wiringUpgradeYear"));
		}

		info.put("ElectricalSystemTypeValue", getNodeValue(path, constructionPath, "electricalType"));
		return info;
	}

	public static HashMap<String, String> getDiscountDataFromBackEnd(String jsonData) {
		String discountRatingsPath = "lobData.homeowners.coverables.rating";
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		info.put("FireExtinguishersAvailability", getNodeValue(path, discountRatingsPath, "fireExtinguishers"));
		info.put("BurgularAlarmAvailability", getNodeValue(path, discountRatingsPath, "burglarAlarm"));
		info.put("BurgAlarmType", getNodeValue(path, discountRatingsPath, "burglarAlarmType"));
		info.put("FireAlarmReporting", getNodeValue(path, discountRatingsPath, "fireAlarm"));
		info.put("SmokeAlarmAvailability", getNodeValue(path, discountRatingsPath, "smokeAlarm"));
		info.put("AllFloorAvailability", getNodeValue(path, discountRatingsPath, "smokeAlarmOnAllFloors"));
		info.put("DeadBoltAvailability", getNodeValue(path, discountRatingsPath, "deadbolts"));
		info.put("DeadBoltCount", getNodeValue(path, discountRatingsPath, "deadboltsNumber"));
		info.put("VisibilityToNeighbour", getNodeValue(path, discountRatingsPath, "visibleToNeighbors"));
		info.put("SprinklerType", getNodeValue(path, discountRatingsPath, "sprinklerSystemType"));
		return info;
	}
	
	public static HashMap<String, String> getScheduledPropertyDataFromBackEnd(String jsonData) {
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.schedules[0]";
		HashMap<String, String> data = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int schItemCount = path.getList(baseCoveIteration + ".scheduleItems").size();
		for (int i = 0; i < schItemCount; i++) {
			String covItr = baseCoveIteration + ".scheduleItems[" + i +"].itemData";
			if(ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.QNB.toString())) {
				DataFormatUtil.putData(data,"SchedulePropertyType", getDisplayKey(jsonData, baseCoveIteration, "ArticleType", getNodeValue(path, covItr + ".ArticleType", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getNodeValue(path, covItr + ".ArticleLimit", "integerValue"));
				DataFormatUtil.putData(data,"SchedulePropertyDeductible", getDisplayKey(jsonData, baseCoveIteration, "ArticleDeductible", getNodeValue(path, covItr + ".ArticleDeductible", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyValuationMethod", getDisplayKey(jsonData, baseCoveIteration, "ArticleValuationMethod", getNodeValue(path, covItr + ".ArticleValuationMethod", "typeCodeValue")));
			} else {
				DataFormatUtil.putData(data,"SchedulePropertyType", getDisplayKey(jsonData, baseCoveIteration, "ArticleType", getNodeValue(path, covItr + ".ArticleType", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyDesc", getNodeValue(path, covItr + ".SchedItemDescriptionId", "stringValue"));
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getNodeValue(path, covItr + ".SchedItemValueId", "integerValue"));
			}
		}
		return data;
	}
	
	public static HashMap<String, String> getSpecialScheduledPropertyDataFromBackEnd(String jsonData) {
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.schedules[1]";
		HashMap<String, String> data = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int schItemCount = path.getList(baseCoveIteration + ".scheduleItems").size();
		for (int i = 0; i < schItemCount; i++) {
				String covItr = baseCoveIteration + ".scheduleItems[" + i +"].itemData";
				DataFormatUtil.putData(data,"SchedulePropertyType", getDisplayKey(jsonData, baseCoveIteration, "ArticleType", getNodeValue(path, covItr + ".ArticleType", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyDesc", getNodeValue(path, covItr + ".SchedItemDescriptionId", "stringValue"));
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getNodeValue(path, covItr + ".SchedItemValueId", "integerValue"));
		}
		return data;
	}
	
	public static HashMap<String, String> getOtherStructuresOnTheResidencePremisesPropertyDataFromBackEnd(String jsonData) {
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.schedules[2]";
		HashMap<String, String> data = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int schItemCount = path.getList(baseCoveIteration + ".scheduleItems").size();
		for (int i = 0; i < schItemCount; i++) {
				String covItr = baseCoveIteration + ".scheduleItems[" + i +"].itemData";
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getDisplayKey(jsonData, baseCoveIteration, "LimitId", getNodeValue(path, covItr + ".LimitId", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyDesc", getNodeValue(path, covItr + ".SchedItemDescriptionId", "stringValue"));
		}
		return data;
	}
	
	public static HashMap<String, String> getPersonalPropertyAtOtherResidencesDataFromBackEnd(String jsonData) {
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.schedules[3]";
		HashMap<String, String> data = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int schItemCount = path.getList(baseCoveIteration + ".scheduleItems").size();
		for (int i = 0; i < schItemCount; i++) {
				String covItr = baseCoveIteration + ".scheduleItems[" + i +"].itemData";
				String addressPath = baseCoveIteration + ".scheduleItems[" + i +"].location.address";
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getDisplayKey(jsonData, baseCoveIteration, "LimitId", getNodeValue(path, covItr + ".LimitId", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyLocation", 
								getNodeValue(path, addressPath, "addressLine1") + " " +
								getNodeValue(path, addressPath, "addressLine2") + " " +
								getNodeValue(path, addressPath, "addressLine3") + " " +
								getNodeValue(path, addressPath, "city") + " " +
								getNodeValue(path, addressPath, "state") + " " +
								getNodeValue(path, addressPath, "postalCode") 	
						);
				DataFormatUtil.putData(data,"SchedulePropertyLocationNonSpecific", getNodeValue(path, baseCoveIteration + ".scheduleItems[" + i +"].location", "isNonSpecificLocation"));
		}
		return data;
	}
	
	public static HashMap<String, String> getSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEnd(String jsonData) {
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.schedules[4]";
		HashMap<String, String> data = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int schItemCount = path.getList(baseCoveIteration + ".scheduleItems").size();
		for (int i = 0; i < schItemCount; i++) {
				String covItr = baseCoveIteration + ".scheduleItems[" + i +"].itemData";
				String addressPath = baseCoveIteration + ".scheduleItems[" + i +"].location.address";
				DataFormatUtil.putData(data,"SchedulePropertyLimit", getDisplayKey(jsonData, baseCoveIteration, "LimitId", getNodeValue(path, covItr + ".LimitId", "typeCodeValue")));
				DataFormatUtil.putData(data,"SchedulePropertyLocation", 
								getNodeValue(path, addressPath, "addressLine1") + " " +
								getNodeValue(path, addressPath, "addressLine2") + " " +
								getNodeValue(path, addressPath, "addressLine3") + " " +
								getNodeValue(path, addressPath, "city") + " " +
								getNodeValue(path, addressPath, "state") + " " +
								getNodeValue(path, addressPath, "postalCode") 	
						);
				DataFormatUtil.putData(data,"SchedulePropertyLocationDescription", getNodeValue(path, covItr + ".SchedItemDescriptionId", "stringValue"));
				DataFormatUtil.putData(data,"SchedulePropertyLocationNonSpecific", getNodeValue(path, baseCoveIteration + ".scheduleItems[" + i +"].location", "isNonSpecificLocation"));
		}
		return data;
	}
	
	private static String getDisplayKey(String  jsonData, String path, String propertyType, String typeListValue)
	{
		JsonPath jsonPath = new JsonPath(jsonData);
		for (int i = 0; i < 4; i++) {
			String propInfoPath = path + ".propertyInfos[" + i +"]";
			String itemID = getNodeValue(jsonPath, propInfoPath , "id");
			if(itemID.equals(propertyType))
			{
				if(propertyType.equals("ArticleType"))
				{
					String displayKeyPath = propInfoPath + ".availableTypeListValues";
					for (int j = 0; j < 10; j++) {
						String propCode = displayKeyPath +"[" + j +"]";
						if(getNodeValue(jsonPath, propCode , "code").equals(typeListValue))
						{
							return getNodeValue(jsonPath, propCode , "displayKey");
						}
					}
				}
				if(propertyType.equals("ArticleDeductible"))
					{
						String displayKeyPath = propInfoPath + ".availableTypeListValues";
						for (int k = 0; k< 5; k++) {
							String propCode = displayKeyPath +"[" + k +"]";
							String keyValue = getNodeValue(jsonPath, propCode , "code");
							if(keyValue.equals(typeListValue))
							{
								return getNodeValue(jsonPath, propCode , "displayKey");
							}
						}
				}
				 if(propertyType.equals("ArticleValuationMethod"))
				{
						String displayKeyPath = propInfoPath + ".availableTypeListValues";
						for (int l = 0; l < 2; l++) {
							String propCode = displayKeyPath +"[" + l +"]";
							if(getNodeValue(jsonPath, propCode , "code").equals(typeListValue))
							{
								return getNodeValue(jsonPath, propCode , "displayKey");
							}
						}
					}
				 if(propertyType.equals("LimitId"))
					{
						String displayKeyPath = propInfoPath + ".availableTypeListValues";
						for (int j = 0; j < 10; j++) {
							String propCode = displayKeyPath +"[" + j +"]";
							if(getNodeValue(jsonPath, propCode , "code").equals(typeListValue))
							{
								return getNodeValue(jsonPath, propCode , "displayKey");
							}
						}
					}
				}
		}
		return null;
	}

	public static HashMap<String, String> getDiscountDataWithAdditonalFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		info.putAll(getDiscountDataFromBackEnd(jsonData));
		// Additional Info
		String addDiscountRatingsPath = "lobData.homeowners.coverables.rating";
		info.put("RoomersOrBoardersAvailability", getNodeValue(path, addDiscountRatingsPath, "roomerBoarders"));
		info.put("RoomersOrBoardersNumber", getNodeValue(path, addDiscountRatingsPath, "roomerBoardersNumber"));
		if(!System.getProperty("platform").equalsIgnoreCase("granite"))
			info.put("NoOfUnits", getNodeValue(path, addDiscountRatingsPath, "unitsNumber"));
		info.put("FirePlaceOrWoodStoveAvailability", getNodeValue(path, addDiscountRatingsPath, "fireplaceOrWoodStoveExists"));
		info.put("FirePlaceOrWoodStoveNumber", getNodeValue(path, addDiscountRatingsPath, "fireplaceOrWoodStovesNumber"));
		info.put("PoolAvailability", getNodeValue(path, addDiscountRatingsPath, "swimmingPoolExists"));
		info.put("FenceAvailability", getNodeValue(path, addDiscountRatingsPath, "swimmingPoolFencing"));
		info.put("DivingBoardAvailability", getNodeValue(path, addDiscountRatingsPath, "swimmingPoolDivingBoard"));
		info.put("TrampolineAvailability", getNodeValue(path, addDiscountRatingsPath, "trampolineExists"));
		info.put("SafetyNetAvailability", getNodeValue(path, addDiscountRatingsPath, "trampolineSafetyNet"));
		info.put("WaterLeakage", getNodeValue(path, addDiscountRatingsPath, "knownWaterLeakage"));
		info.put("WaterLeakageHistory", getNodeValue(path, addDiscountRatingsPath, "knownWaterLeakageDescription"));
		return info;
	}

	public static HashMap<String, String> getPolicySummaryDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		info.put("ANNUAL_AMOUNT_AFTER_TAX_VALUE", getNodeValue(path, "quoteData.offeredQuotes[0].premium.total", "amount"));
		info.put("ANNUAL_BASE_PREMIUM_VALUE", getNodeValue(path, "lobData.homeowners.coverages.basePremium", "amount"));
		info.put("MONTHLY_AMOUNT_AFTER_TAX_VALUE", getNodeValue(path, "quoteData.offeredQuotes[0].premium.monthlyPremium", "amount"));
		info.put("PREMIUM_AMOUNT_VALUE", getNodeValue(path, "quoteData.offeredQuotes[0].premium.monthlyPremium", "amount"));
		info.put("POLICY_NUMBER", getNodeValue(path, "bindData", "policyNumber"));
		info.put("ACCOUNT_NUMBER", getNodeValue(path, "bindData", "accountNumber"));
		info.put("POLICY_TOTAL_AMOUNT", getNodeValue(path, "bindData.paymentPlans[0].total", "amount"));
		info.put("PAYMENT_PLAN_NAME", getNodeValue(path, "bindData.paymentPlans[0]", "name"));
		info.put("POLICY_CURRENT_PAYMENT", getNodeValue(path, "bindData.paymentPlans[0].downPayment", "amount"));
		// Month value is incremented by 1 here as javascript month is 0 index based
		String cov_start_Date = DateUtil.formatDateTo((Integer.parseInt(getNodeValue(path, "baseData.periodStartDate", "month")) + 1) + "/" + getNodeValue(path, "baseData.periodStartDate", "day") + "/" + getNodeValue(path, "baseData.periodStartDate", "year"), "MMMMM d, YYYY");
		info.put("COV_START_DATE", cov_start_Date);
		String cov_end_Date = DateUtil.formatDateTo((Integer.parseInt(getNodeValue(path, "baseData.periodEndDate", "month")) + 1) + "/" + getNodeValue(path, "baseData.periodEndDate", "day") + "/" + getNodeValue(path, "baseData.periodEndDate", "year"), "MMMMM d, YYYY");
		info.put("COV_START_DATE", cov_start_Date);
		info.put("POLICY_PERIOD", cov_start_Date.replace(" ","")+cov_end_Date.replace(" ",""));
		return info;
	}

	public static HashMap<String, String> getPolicySummaryDataFromBackEndForBOP(String jsonData) throws Exception {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		JsonPath path1 = new JsonPath(jsonData);
		int locCount = path.getList("lobData.businessOwners.coverables.locations").size();
		info.put("LOCATION_SIZE", Integer.toString(locCount));
		String lobCoverages = "lobData.businessOwners.coverages.lobCoverages";
		int covCount = path.getList(lobCoverages).size();


		for(int i=0;i<covCount; i++){

			String covItr = lobCoverages + "[" + i + "]";
			String coverageCategoryDisplayName = getNodeValue(path, covItr , "coverageCategoryDisplayName");
			String name = getNodeValue(path, covItr , "name");

			if(coverageCategoryDisplayName.equals("Liability - Required") && name.equals("Personal and Advertising Injury")){
				info.put("PERSONAL_ADVERTISING_INJURY_SELECTED",getNodeValue(path, covItr , "selected") );
			}

			if(coverageCategoryDisplayName.equals("Liability - Required") && name.equals("Liability")){
				String termsPath = covItr+".terms";
				int termsSize = path1.getList(termsPath).size();
				for(int j=0;j<termsSize; j++){
					String terms = covItr+".terms"+"[" + j + "]";
					if(getNodeValue(path, terms , "patternCode").equals("BOPLiabPDDeductible"))
					info.put("PD_DEDUCTIBLE_VALUE", getNodeValue(path, terms , "chosenTermValue") );
				}
			}

			if(coverageCategoryDisplayName.equals("Liability - Required") && name.equals("Special Coverage Packages")){
				info.put("SPECIAL_COVERAGE_PACKAGE",getNodeValue(path, covItr+".terms" , "chosenTermValue") );
			}

			if(coverageCategoryDisplayName.equals("Other Included Coverages") && name.equals("Hired Auto")){
				info.put("HIRED_AUTO_SELECTED",getNodeValue(path, covItr , "selected") );
			}

			if(coverageCategoryDisplayName.equals("Other Included Coverages") && name.equals("Non-owned Auto Liability")){
				info.put("NON_OWNED_AUTO_LIABILITY_SELECTED",getNodeValue(path, covItr , "selected") );
			}

			if(coverageCategoryDisplayName.equals("Property - Required") && name.equals("Policywide Property Deductible")){
				String termsPath = covItr+".terms";
				int termsSize = path1.getList(termsPath).size();
				for(int j=0;j<termsSize; j++){
					String terms = covItr+".terms"+"[" + j + "]";
					if(getNodeValue(path1, terms , "patternCode").equals("BOPOptCovDed")) {
						info.put("PROP_COV_DEDUCATABLE", getNodeValue(path1, terms, "chosenTermValue"));
					}

					if(getNodeValue(path1, terms , "patternCode").equals("BOPPropertyCovCauseOfLoss")) {
						info.put("CAUSE_OF_LOSS", getNodeValue(path1, terms, "chosenTermValue"));
					}
				}

			}
		}


		String cov_start_Date = DateUtil.formatDateTo((Integer.parseInt(getNodeValue(path, "baseData.periodStartDate", "month")) + 1) + "/" + getNodeValue(path, "baseData.periodStartDate", "day") + "/" + getNodeValue(path, "baseData.periodStartDate", "year"), "MMMMM d, YYYY");
		info.put("COV_START_DATE", cov_start_Date);
		String cov_end_Date = DateUtil.formatDateTo((Integer.parseInt(getNodeValue(path, "baseData.periodEndDate", "month")) + 1) + "/" + getNodeValue(path, "baseData.periodEndDate", "day") + "/" + getNodeValue(path, "baseData.periodEndDate", "year"), "MMMMM d, YYYY");
		info.put("COV_START_DATE", cov_start_Date);
		info.put("COV_END_DATE", cov_end_Date);
		String primaryAddress = getNodeValue(path, "baseData.policyAddress", "displayName");
		info.put("PrimaryAddress", primaryAddress);
		String phoneNumber = getNodeValue(path, "bindData", "contactPhone");
		info.put("PhoneNumber", phoneNumber);
		String emailAddress = getNodeValue(path, "bindData", "contactEmail");
		info.put("EmailAddress", emailAddress);
		String buildingInfo = "lobData.businessOwners.coverables.locations.buildings";
		info.put("NumberOfBuildings", Integer.toString(getNodeValue(path, buildingInfo, "basisAmount").split("\\s+").length));
		String contactName = getNodeValue(path, "baseData.accountHolder", "displayName");
		info.put("contactName", contactName);
		String emailID = getNodeValue(path, "baseData.accountHolder", "emailAddress1");
		info.put("emailID", emailID);
		String CompanyName = getNodeValue(path, "baseData.accountHolder", "contactName");
		info.put("CompanyName", CompanyName);
		String addressType = getNodeValue(path, "baseData.policyAddress", "addressType");
		info.put("AddressType", addressType);
		String termType = getNodeValue(path, "baseData", "termType");
		info.put("TermType", termType);
		String smallBusinessType = getNodeValue(path, "lobData.businessOwners", "smallBusinessType");
		info.put("SmallBusinessType", smallBusinessType);
		String accountOrgType = getNodeValue(path, "lobData.businessOwners", "accountOrgType");
		info.put("AccountOrgType", accountOrgType);
		info.put("PAYMENT_PLAN_NAME", getNodeValue(path, "bindData.paymentPlans[0]", "name"));
		String basePremiumValue = "quoteData.offeredQuotes[0].premium";
		info.put("QUOTE_ANNUAL_VALUE", getNodeValue(path, basePremiumValue + ".total", "amount"));
		info.put("QUOTE_ANNUAL_BEFORE_TAX_VALUE", getNodeValue(path, basePremiumValue + ".totalBeforeTaxes", "amount"));
		info.put("QUOTE_TAXES", getNodeValue(path, basePremiumValue + ".taxes", "amount"));
		
		String locDetails = "lobData.businessOwners.coverables.locations";
		for(int i=0;i<locCount; i++) {
			String locData = locDetails + "[" + i + "]";
			if(!getNodeValue(path, locData, "isPrimary").equalsIgnoreCase("true")) {
				locDetails = locData;
				break;
			} 
		}
		info.put("NewLocation_AddressLine", getNodeValue(path, locDetails, "displayName"));
		info.put("NewLocation_FireProtection", getNodeValue(path, locDetails, "fireProtection"));
		info.put("NewLocation_LocationCode", getNodeValue(path, locDetails, "locationCode"));
		info.put("NewLocation_Phone", getNodeValue(path, locDetails, "phone"));
		info.put("rentEquipment", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "RentEquipment").replace("[", "").replace("]", ""));
		info.put("policyRejected", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "PolicyRejected").replace("[", "").replace("]", ""));
		info.put("foreClosure", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "Foreclosure").replace("[", "").replace("]", ""));
		info.put("hazardousMaterial", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "HazardousMaterial").replace("[", "").replace("]", ""));
		info.put("athleticTeams", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "AthleticTeams").replace("[", "").replace("]", ""));
		info.put("flammables", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "Flammables").replace("[", "").replace("]", ""));
		info.put("otherBusiness2", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "OtherBusiness2").replace("[", "").replace("]", ""));
		info.put("leaseEmployees", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "LeaseEmployees").replace("[", "").replace("]", ""));
		info.put("personnelIssues", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "PersonnelIssues").replace("[", "").replace("]", ""));
		info.put("subContractorCerts", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "SubContractorCerts").replace("[", "").replace("]", ""));
		info.put("applicantArson", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "ApplicantArson").replace("[", "").replace("]", ""));
		info.put("catastrophe", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "Catastrophe").replace("[", "").replace("]", ""));
		info.put("subContractors", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "SubContractors").replace("[", "").replace("]", ""));
		info.put("manufacturing", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "Manufacturing").replace("[", "").replace("]", ""));
		info.put("fireCode", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "FireCode").replace("[", "").replace("]", ""));
		info.put("otherInsurance", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "OtherInsurance").replace("[", "").replace("]", ""));
		if(!System.getProperty("platform").equalsIgnoreCase("granite")){
			info.put("workersComp", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "WorkersComp").replace("[", "").replace("]", ""));
		} else {
			info.put("workersComp", getNodeValue(path, "lobData.businessOwners.preQualQuestionSets.answers", "BOPBusinessownersPreQualWorkersComp").replace("[", "").replace("]", ""));
		}

		return info;
	}

	public static HashMap<String, String> getHOBaseCoverageDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = getPolicySummaryDataFromBackEnd(jsonData);
		JsonPath path = new JsonPath(jsonData);
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.baseCoverages";
		String addCoveIteration = "lobData.homeowners.offerings[0].coverages.additionalCoverages";
		int baseCovCount = path.getList(baseCoveIteration).size();
		int addCovCount = path.getList(addCoveIteration).size();

		for (int i = 0; i < baseCovCount; i++) {

			String covItr = baseCoveIteration + "[" + i + "]";
			// Homeowners Personal Property
			if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("Homeowners Personal Property")) {
				DataFormatUtil.putData(info, "HO_PER_PROP_SEC", getNodeValue(path, covItr , "description"));
				DataFormatUtil.putData(info, "HO_PER_PROP_VALUATION_METHOD", getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_PER_PROP_VALUATION_METHOD_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT%_DWEL_COVG", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT%_DWEL_COVG_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Homeowners Other structure 
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Other Structures")) {

				DataFormatUtil.putData(info, "HO_OTR_STR_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_OTR_STR_LIMIT%_DWEL_COVG", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_OTR_STR_LIMIT%_DWEL_COVG_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Section I Deductibles
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Section I Deductibles")) {
				DataFormatUtil.putData(info, "DEDUCT_1_SEC", getNodeValue(path, covItr, "description"));

				DataFormatUtil.putData(info, "ALL_OTHER_PERILS", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "ALL_OTHER_PERILS_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));

				DataFormatUtil.putData(info, "HURRICANE_PERCENTAGE", getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HURRICANE_PERCENTAGE_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));

				DataFormatUtil.putData(info, "WIND_HAIL_PERCENTAGE", getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, "WIND_HAIL_PERCENTAGE_LBL", getNodeValue(path, covItr + ".terms[2]", "name"));

			}
			
			// Section I Deductibles
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Section I Deductibles")) {
				DataFormatUtil.putData(info, "DEDUCTPADDYFIELD_1_SEC", getNodeValue(path, covItr, "description"));

				DataFormatUtil.putData(info, "ALL_OTHER_PERILS", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "ALL_OTHER_PERILS_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));

				DataFormatUtil.putData(info, "HURRICANE_PERCENTAGE", getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HURRICANE_PERCENTAGE_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));

				DataFormatUtil.putData(info, "WIND_HAIL_PERCENTAGE", getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, "WIND_HAIL_PERCENTAGE_LBL", getNodeValue(path, covItr + ".terms[2]", "name"));

						}

			// Homeowners Loss Of Use
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Loss Of Use")) {
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));

			}

			// Homeowners Dwelling
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Dwelling")) {
				DataFormatUtil.putData(info, "HO_DWEL_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
				DataFormatUtil.putData(info, "HO_DWEL_DWEL_VALUATION_METHOD", getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_DWEL_DWEL_VALUATION_METHOD_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));

			}

			// Homeowners Medical Payments
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Medical Payments")) {
				DataFormatUtil.putData(info, "HO_MED_PAY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Homeowners Personal Liability
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Personal Liability")) {
				DataFormatUtil.putData(info, "HO_PER_LIABILITY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_PER_LIABILITY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_PER_LIABILITY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

		}

		// Additional Coverage
		for (int i = 0; i < addCovCount; i++) {
			String covItr = addCoveIteration + "[" + i + "]";
			// personal injury
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Personal Injury")) {
				DataFormatUtil.putData(info, "PER_INJURY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "PER_INJURY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "PER_INJURY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Limited Fungi, Wet or Dry Rot or Bacteria
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Limited Fungi, Wet or Dry Rot or Bacteria")) {
				DataFormatUtil.putData(info, "FUNGI_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "FUNGI_SEC1_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "FUNGI_SEC1_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
				DataFormatUtil.putData(info, "FUNGI_SEC2_AGG_LIMIT", getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "FUNGI_SEC2_AGG_LIMIT_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));
			}

			// Homeowners Ordinance Or Law
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Ordinance Or Law")) {
				DataFormatUtil.putData(info, "O_ORD_LAW_LBL", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_ORD_LAW_VALUE", getNodeValue(path, covItr + ".amount", "amount"));
				DataFormatUtil.putData(info, "HO_ORD_LAW_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
			}

		}
		return info;
	}


	public static HashMap<String, String> getInowHOBaseCoverageDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = getPolicySummaryDataFromBackEnd(jsonData);
		JsonPath path = new JsonPath(jsonData);
		String baseCoveIteration = "lobData.homeowners.offerings[0].coverages.baseCoverages";
		String addCoveIteration = "lobData.homeowners.offerings[0].coverages.additionalCoverages";
		int baseCovCount = path.getList(baseCoveIteration).size();
		int addCovCount = path.getList(addCoveIteration).size();

		for (int i = 0; i < baseCovCount; i++) {

			String covItr = baseCoveIteration + "[" + i + "]";
			// Homeowners Personal Property
			if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("C - Personal Property")) {
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT%_DWEL_COVG", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT%_DWEL_COVG_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Homeowners Other structure
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("B - Other Structures")) {

				DataFormatUtil.putData(info, "HO_OTR_STR_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_OTR_STR_LIMIT%_DWEL_COVG", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_OTR_STR_LIMIT%_DWEL_COVG_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}


			// Homeowners Loss Of Use
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("D - Loss Of Use")) {
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));

			}

			// Homeowners Dwelling
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("A - Dwelling")) {
				DataFormatUtil.putData(info, "HO_DWEL_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));

			}

			// E - Liability
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("E - Liability")) {
				DataFormatUtil.putData(info, "HO_LIABILITY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_LIABILITY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_LIABILITY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// F - Medical Payments
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("F - Medical Payments")) {
				DataFormatUtil.putData(info, "HO_MED_PAY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Package Coverage
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Package Coverage")) {
				DataFormatUtil.putData(info, "HO_PACKAGE_COVERAGE_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_PACKAGE_COVERAGE_VALUE", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "HO_PACKAGE_COVERAGE_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

		}

		// Additional Coverage
		for (int i = 0; i < addCovCount; i++) {
			String covItr = addCoveIteration + "[" + i + "]";
			// personal injury
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Personal Injury")) {
				DataFormatUtil.putData(info, "PER_INJURY_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "PER_INJURY_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "PER_INJURY_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
			}

			// Limited Fungi, Wet or Dry Rot or Bacteria
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Limited Fungi, Wet or Dry Rot or Bacteria")) {
				DataFormatUtil.putData(info, "FUNGI_SEC", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "FUNGI_SEC1_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, "FUNGI_SEC1_LIMIT_LBL", getNodeValue(path, covItr + ".terms[0]", "name"));
				DataFormatUtil.putData(info, "FUNGI_SEC2_AGG_LIMIT", getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, "FUNGI_SEC2_AGG_LIMIT_LBL", getNodeValue(path, covItr + ".terms[1]", "name"));
			}

			// Homeowners Ordinance Or Law
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Homeowners Ordinance Or Law")) {
				DataFormatUtil.putData(info, "O_ORD_LAW_LBL", getNodeValue(path, covItr, "description"));
				DataFormatUtil.putData(info, "HO_ORD_LAW_VALUE", getNodeValue(path, covItr + ".amount", "amount"));
				DataFormatUtil.putData(info, "HO_ORD_LAW_LIMIT", getNodeValue(path, covItr + ".terms[0]", "chosenTermValue"));
			}

		}
		return info;
	}

	public static HashMap<String, String> getHOPBaseCoverageDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = getPolicySummaryDataFromBackEnd(jsonData);
		JsonPath path = new JsonPath(jsonData);
		String baseCoveIteration = "lobData.homeowners.coverages.baseCoverages";
		String addCoveIteration = "lobData.homeowners.coverages.additionalCoverages";
		int baseCovCount = path.getList("lobData.homeowners.coverages.baseCoverages").size();
		int addCovCount = path.getList("lobData.homeowners.coverages.additionalCoverages").size();

		for (int i = 0; i < baseCovCount; i++) {

			String covItr = baseCoveIteration + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("Coverage D - Loss of Use")) {
				DataFormatUtil.putData(info, HOPQuoteData.LOU_LIMIT_PERCENT.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.LOU_LIMIT_VALUE.toString(), getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.LOU_LOSS_RENTAL_INCOME_CHECK.toString(), getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.LOU_PROBIHITED_USE_CIVIL_AUTH.toString(), getNodeValue(path, covItr + ".terms[3]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Section I Deductibles")) {

				DataFormatUtil.putData(info, HOPQuoteData.SEC1_DEDUCT_ALL_OTHER_PERIL.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Coverage C - Personal Property")) {
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_LIMIT_PERCENT.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_LIMIT_VALUE.toString(), getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_AT_OTHER_RESIDENCE.toString(), getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_SELF_STORAGE.toString(), getNodeValue(path, covItr + ".terms[3]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_CAUSE_OF_LOSS.toString(), getNodeValue(path, covItr + ".terms[4]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_PROP_VALUATION_METHOD.toString(), getNodeValue(path, covItr + ".terms[5]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Coverage A - Dwelling")) {
				DataFormatUtil.putData(info, HOPQuoteData.DWEL_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.DWEL_COINSURANCE_PERCENT.toString(), getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.DWEL_VALUATION_METHOD.toString(), getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.DWEL_CAUSE_OF_LOSS.toString(), getNodeValue(path, covItr + ".terms[3]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Coverage B - Other Structures")) {
				DataFormatUtil.putData(info, HOPQuoteData.OTR_STRUC_LIMIT_PERCENT.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.OTR_STRUC_LIMIT_VALUE.toString(), getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.OTR_STRUC_VALUATION_METHOD.toString(), getNodeValue(path, covItr + ".terms[2]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.OTR_STRUC_COINSURANCE_PERCENT.toString(), getNodeValue(path, covItr + ".terms[3]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.OTR_STRUC_CAUSE_OF_LOSS.toString(), getNodeValue(path, covItr + ".terms[4]", "chosenTermValue"));

			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Coverage E - Personal Liability")) {
				DataFormatUtil.putData(info, HOPQuoteData.PER_LIABILITY_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.PER_LIABILITY_PER_INJURY.toString(), getNodeValue(path, covItr + ".terms[1]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Coverage F - Medical Payments To Others")) {
				DataFormatUtil.putData(info, HOPQuoteData.MEDICAL_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}

		}

		// Additional Coverage
		for (int i = 0; i < addCovCount; i++) {
			String covItr = addCoveIteration + "[" + i + "]";
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Reward")) {
				DataFormatUtil.putData(info, HOPQuoteData.REWARD_RECOVERED_PROP_LIMIT_PERCENT.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.REWARD_THEFT_CONVECTION_LIMIT_PERCENT.toString(), getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Damage to Property of Others")) {
				DataFormatUtil.putData(info, HOPQuoteData.DAMAGE_OTHERS_PROPERTY_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Loss Assessment")) {
				DataFormatUtil.putData(info, HOPQuoteData.LOSS_ASSESSMENT_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Credit/Debit Card, Forgery and Counterfeit Money")) {
				DataFormatUtil.putData(info, HOPQuoteData.FORGERY_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Identity Theft Protection")) {
				DataFormatUtil.putData(info, HOPQuoteData.THEFT_PROTECTION_EXPENSE_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.THEFT_PROTECTION_DEDUCT_VALUE.toString(), getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("First Aid")) {
				DataFormatUtil.putData(info, HOPQuoteData.FIRST_AID.toString(), getNodeValue(path, covItr, "selected"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Reasonable Repairs")) {
				DataFormatUtil.putData(info, HOPQuoteData.REASONABLE_REPAIRS.toString(), getNodeValue(path, covItr, "selected"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Volcanic Action")) {
				DataFormatUtil.putData(info, HOPQuoteData.VOLCANIC_ACTION_DEDUCT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Construction Permit Increase Costs")) {
				DataFormatUtil.putData(info, HOPQuoteData.CONSTRUCTION_PERMIT_INCREASE_COST_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Refrigerated Contents")) {
				DataFormatUtil.putData(info, HOPQuoteData.REFRIGIRATED_CONTENTS_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.REFRIGIRATED_CONTENTS_LIMIT_VALUE_DEDUCT_VALUE.toString(), getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
			}
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Fungus & Mold Remediation")) {
				DataFormatUtil.putData(info, HOPQuoteData.FUNGUS_MOLD_REMED_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Collapse")) {
				DataFormatUtil.putData(info, HOPQuoteData.COLAPSE.toString(), getNodeValue(path, covItr, "selected"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Dwelling Under Construction - Extension of Coverages")) {
				DataFormatUtil.putData(info, HOPQuoteData.DWEL_COV_EXTENSION_DEDUCT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Trees, Shrubs, Plants & Lawns")) {
				DataFormatUtil.putData(info, HOPQuoteData.TREE_LAWN_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Personal Property Off Premises - Earthquake and Flood")) {
				DataFormatUtil.putData(info, HOPQuoteData.EARTHQUAKE_FOOD_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Mortgage Closing Cost Expense")) {
				DataFormatUtil.putData(info, HOPQuoteData.MORTAGEE_CLOSE_COST_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Emergency Removal of Property")) {
				DataFormatUtil.putData(info, HOPQuoteData.EMERGENCY_REMOVAL_PROP.toString(), getNodeValue(path, covItr, "selected"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Debris Removal of Trees")) {
				DataFormatUtil.putData(info, HOPQuoteData.DEBRIS_REMOVAL_TREE_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Emergency Living Expense - Power Interruption Off Premises")) {
				DataFormatUtil.putData(info, HOPQuoteData.EMERGENCY_LIVING_EXPENSE_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Debris Removal")) {
				DataFormatUtil.putData(info, HOPQuoteData.DEBRIS_REMOVAL.toString(),  getNodeValue(path, covItr , "selected"));
			}

			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Landlord's Furnishings")) {
				DataFormatUtil.putData(info, HOPQuoteData.LANDLORD_FURNISHING_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Land")) {
				DataFormatUtil.putData(info, HOPQuoteData.LAND_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Grave Markers")) {
				DataFormatUtil.putData(info, HOPQuoteData.GRAVE_MAKER_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Fire Department Service Charge")) {
				DataFormatUtil.putData(info, HOPQuoteData.FIRE_DEPT_SERVICE_CHARGE_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Lock Replacement")) {
				DataFormatUtil.putData(info, HOPQuoteData.LOCK_REPLACEMENT.toString(), getNodeValue(path, covItr, "selected"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Property Removed")) {
				DataFormatUtil.putData(info, HOPQuoteData.PROP_REMOVED_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Inflation Protection")) {
				DataFormatUtil.putData(info, HOPQuoteData.INFLATION_PROTECTION_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Ordinance Or Law")) {
				DataFormatUtil.putData(info, HOPQuoteData.ORDINANCE_LAW_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Fire Extinguisher Recharge")) {
				DataFormatUtil.putData(info, HOPQuoteData.FIRE_EXT_RECHARGE_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Data and Records")) {
				DataFormatUtil.putData(info, HOPQuoteData.DATA_RECORD_LIMIT_VALUE.toString(), getNodeValue(path, covItr +".terms[0]", "chosenTermValue"));
				DataFormatUtil.putData(info, HOPQuoteData.DATA_RECORD_PERSONAL_ONLY_CHECK.toString(), getNodeValue(path, covItr +".terms[1]", "chosenTermValue"));
			}
			
			if (DataFormatUtil.getNodeValue(path, covItr, "name").equals("Glass")) {
				DataFormatUtil.putData(info, HOPQuoteData.GLASS.toString(), getNodeValue(path, covItr, "selected"));
			}
		}
		return info;
	}

	public static HashMap<String, String> getPABaseCoverageDataFromBackEnd(String jsonData) throws Exception {
		HashMap<String, String> info = getPolicySummaryDataFromBackEnd(jsonData);
		JsonPath path = new JsonPath(jsonData);
		int baseCovCount = path.getList("lobData.personalAuto.offerings[0].coverages.lineCoverages").size();
		String offeringData = getCoveIteration("Basic Program", path);
		String lineCov = offeringData + ".coverages.lineCoverages";
		String basePremiumValue = "quoteData.offeredQuotes[0].premium";
		info.put("QUOTE_ANNUAL_VALUE", getNodeValue(path, basePremiumValue + ".total", "amount"));
		info.put("QUOTE_ANNUAL_BEFORE_TAX_VALUE", getNodeValue(path, basePremiumValue + ".totalBeforeTaxes", "amount"));
		info.put("QUOTE_MONTHLY_VALUE", getNodeValue(path, basePremiumValue + ".monthlyPremium", "amount"));
		for (int i = 0; i < baseCovCount; i++) {
			String coveIteration = lineCov + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Mexico Coverage - Limited")) {
				info.put("Mexico_Cov_Ltd_LBL", getNodeValue(path, coveIteration, "description"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("LiabilityBodilyPropDamage_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("LiabilityBodilyPropDamage", getNodeValue(path, coveIteration + ".amount", "amount"));

			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("AutoLiabilityPackage_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("AutoLiabilityPackage", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Medical Payments")) {
				info.put("MedicalPayment_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("MedicalPayment", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("MedicalLimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("MedicalLimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
		}
		return info;
	}
	
	private static String getOfferingIndex(String jsonData, String offeringName)
	{
		String offeringData = "lobData.personalAuto.offerings";
		JsonPath path = new JsonPath(jsonData);
		int stdCovCount = path.getList(offeringData).size();
		for (int i = 0; i < stdCovCount; i++) {
			String name = getNodeValue(path, offeringData + "[" +i+ "]", "branchName");
			if(name.equals(offeringName))
			{
				return "lobData.personalAuto.offerings["+ i +"]";
			}
		}
		return null;
	}

	public static HashMap<String, String> getPAStandardCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String offeringData =  getOfferingIndex(jsonData, "Standard Program");
		String lineCov = offeringData + ".coverages.lineCoverages";
		String vehCov = offeringData + ".coverages.vehicleCoverages[0].coverages";
		int vehCoveCount = path.getList("lobData.personalAuto.offerings[1].coverages.vehicleCoverages[0].coverages").size();
		int stdCovCount = path.getList("lobData.personalAuto.offerings[1].coverages.lineCoverages").size();

		String basePremiumValue = "quoteData.offeredQuotes[1].premium";
		info.put("QUOTE_ANNUAL_VALUE", getNodeValue(path, basePremiumValue + ".total", "amount"));
		info.put("QUOTE_ANNUAL_BEFORE_TAX_VALUE", getNodeValue(path, basePremiumValue + ".totalBeforeTaxes", "amount"));
		info.put("QUOTE_MONTHLY_VALUE", getNodeValue(path, basePremiumValue + ".monthlyPremium", "amount"));

		for (int i = 0; i < stdCovCount; i++) {
			String coveIteration = lineCov + "[" + i + "]";

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Mexico Coverage - Limited")) {
				info.put("Mexico_Cov_Ltd_LBL", getNodeValue(path, coveIteration, "description"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("LiabilityBodilyPropDamage_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("LiabilityBodilyPropDamage", getNodeValue(path, coveIteration + ".amount", "amount"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("AutoLiabilityPackage_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("AutoLiabilityPackage", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Medical Payments")) {
				info.put("MedicalPayment_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("MedicalPayment", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("MedicalLimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("MedicalLimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Uninsured Motorist - Bodily Injury")) {
				info.put("UninsuredMotoristBI_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("UninsuredMotoristBI", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("UninsuredMotoristBILimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("UninsuredMotoristBILimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
		}

		for (int i = 0; i < vehCoveCount; i++) {
			String coveIteration = vehCov + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Collision")) {
				info.put("Collision_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("Collision", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("CollisionDeductible_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("CollisionDeductible", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Rental Reimbursement")) {
				info.put("RentalReimbursement_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("RentalReimbursement", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("RentalPackage_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("RentalPackage", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Comprehensive")) {
				info.put("Comprehensive_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("Comprehensive", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("ComprehensiveDeductible_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("ComprehensiveDeductible", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Towing and Labor")) {
				info.put("TowingAndLabor_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("TowingAndLabor", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("TowingAndLaborLimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("TowingAndLaborLimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
		}
		return info;
	}
	
	public static HashMap<String, String> getPAPremiumCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		String offeringData = getOfferingIndex(jsonData, "Premium Program");
		String lineCov = offeringData + ".coverages.lineCoverages";
		String vehCov = offeringData + ".coverages.vehicleCoverages[0].coverages";
		int stdCovCount = path.getList(lineCov).size();
		int vehCoveCount = path.getList(vehCov).size();
		String basePremiumValue = "quoteData.offeredQuotes[2].premium";
		info.put("QUOTE_ANNUAL_VALUE", getNodeValue(path, basePremiumValue + ".total", "amount"));
		info.put("QUOTE_ANNUAL_BEFORE_TAX_VALUE", getNodeValue(path, basePremiumValue + ".totalBeforeTaxes", "amount"));
		info.put("QUOTE_MONTHLY_VALUE", getNodeValue(path, basePremiumValue + ".monthlyPremium", "amount"));

		for (int i = 0; i < stdCovCount; i++) {
			String coveIteration = lineCov + "[" + i + "]";

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Mexico Coverage - Limited")) {
				info.put("Mexico_Cov_Ltd_LBL", getNodeValue(path, coveIteration, "description"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("LiabilityBodilyPropDamage_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("LiabilityBodilyPropDamage", getNodeValue(path, coveIteration + ".amount", "amount"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Liability - Bodily Injury and Property Damage")) {
				info.put("AutoLiabilityPackage_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("AutoLiabilityPackage", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Medical Payments")) {
				info.put("MedicalPayment_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("MedicalPayment", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("MedicalLimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("MedicalLimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Uninsured Motorist - Bodily Injury")) {
				info.put("UninsuredMotoristBI_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("UninsuredMotoristBI", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("UninsuredMotoristBILimit_LBL", getNodeValue(path, coveIteration + ".terms[0]", "name"));
				info.put("UninsuredMotoristBILimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
		}

		for (int i = 0; i < vehCoveCount; i++) {
			String coveIteration = vehCov + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Collision")) {
				info.put("Collision_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("Collision", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("CollisionDeductible_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("CollisionDeductible", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Rental Reimbursement")) {
				info.put("RentalReimbursement_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("RentalReimbursement", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("RentalPackage_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("RentalPackage", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}

			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Comprehensive")) {
				info.put("Comprehensive_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("Comprehensive", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("ComprehensiveDeductible_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("ComprehensiveDeductible", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
			if (DataFormatUtil.getNodeValue(path, coveIteration, "name").equals("Towing and Labor")) {
				info.put("TowingAndLabor_LBL", getNodeValue(path, coveIteration, "description"));
				info.put("TowingAndLabor", getNodeValue(path, coveIteration + ".amount", "amount"));
				info.put("TowingAndLaborLimit_LBL", getNodeValue(path, coveIteration + ".terms", "name"));
				info.put("TowingAndLaborLimit", getNodeValue(path, coveIteration + ".terms", "chosenTermValue"));
			}
		}
		return info;
	}

	private static HashMap<String, String> getVehicleCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		info.put("Collision_LBL", getNodeValue(path, "quoteData.offeredQuotes[0].lobs.personalAuto.vehicleCoverages[0].coverages[0]", "description"));
		info.put("Collision", getNodeValue(path, "quoteData.offeredQuotes[0].lobs.personalAuto.vehicleCoverages[0].coverages[0].amount", "amount"));
		info.put("CollisionDeductible_LBL", getNodeValue(path, "quoteData.offeredQuotes[0].lobs.personalAuto.vehicleCoverages[0].coverages[0].terms", "name"));
		info.put("CollisionDeductible", getNodeValue(path, "quoteData.offeredQuotes[0].lobs.personalAuto.vehicleCoverages[0].coverages[0].terms", "chosenTermValue"));

		return info;
	}

	public static String getSubmisionStatusEqualsTo(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		 return getNodeValue(path, "baseData", "periodStatus");
	}
	
	public static Map<String, String> getQuoteUWIssuesDataFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return path.getMap("$");
	}
	
	public static String getPolicyNumber(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return getNodeValue(path, "bindData", "policyNumber");
	}

	public static String getPolicyOfferingName(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return getNodeValue(path, "quoteData.offeredQuotes[0]", "branchName");
	}

	private static String upperCaseFirst(String value) {

		char[] array = value.toCharArray();
		array[0] = Character.toUpperCase(array[0]);
		return new String(array);
	}

	private static String getNodeValue(JsonPath path, String nodePath, String nodeName) {
		String value = null;
		JsonPath jsonPath = path;
		try {
			value = jsonPath.setRoot(nodePath).get(nodeName).toString().replace(",", "");
		} catch (Exception e) {
		}
		return value;
	}

	private static String getCoveIteration(String offeringName, JsonPath path) {
		String offerings = "lobData.personalAuto.offerings";
		List<Object> list1 = path.get(offerings);
		int offeringCount = list1.size();
		for (int i = 0; i < offeringCount; i++) {
			if (getNodeValue(path, offerings + "[" + i + "]", "branchName").equalsIgnoreCase(offeringName)) {
				return offerings + "[" + i + "]";
			}
		}
		return null;
	}

	public static void main(String[] args) {
		// System.out.println(getPAStandardOrPremiumCoverageDataFromBackEnd(DataFetch.getQuoteData("90210",
		// "0026784301")));
	}

}