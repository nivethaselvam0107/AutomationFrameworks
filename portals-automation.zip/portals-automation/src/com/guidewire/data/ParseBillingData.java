package com.guidewire.data;

import java.util.ArrayList;
import java.util.List;

import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.DateUtil;

import io.restassured.path.json.JsonPath;

public class ParseBillingData {

	
    public static List<String> getActiveInvoiceDataFromBackEnd(String jsonData) {
        List<String> invoices = new ArrayList<>();
        JsonPath path = new JsonPath(jsonData);
        int activeInvoicesCount = path.getList("activeInvoices").size();
        for(int i = 0; i < activeInvoicesCount; i++) {
            invoices.add(DataFormatUtil.getNodeValue(path, "activeInvoices["+ i +"]", "number"));
        }
        return invoices;
    }

    public static String getLastPaymentData(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String lastPayment = Float.toString(path.getFloat("lastPayment.amount.amount"));
        return lastPayment;
    }

    public static String getNextInvoice(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        double d = path.getDouble("nextInvoice.amountDue.amount");
        String nextInvoice = String.valueOf(d);
        return nextInvoice;
    }
    
    public static String getNextInvoiceDueDate(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String dueDate= path.getString("nextInvoice.dueDate");
        return DateUtil.getDateFromISODateToMMDDYY(dueDate);
    }
    
    public static String getLastPaymentDate(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String dueDate= path.getString("lastPayment.paymentDate");
        return DateUtil.getDateFromISODateToMMDDYY(dueDate);
    }
    
    public static String getBalanceDueDate(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String dueDate= path.getString("activeInvoices[0].dueDate");
        return DateUtil.getDateFromISODateToMMDDYY(dueDate);
    }
    
    public static double getOverDudeBalanceData(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
      	int activeInvoice = path.getList("activeInvoices").size();
      	double Overdue = 0;
      	for(int i=0; i< activeInvoice; i++)
      	{
      		String invoiceStatus = getNodeValue(path, "activeInvoices[" + i + "]", "invoiceStatus");
      			if(invoiceStatus.equalsIgnoreCase("due"))
          		{
          			Overdue = Overdue + new Double(getNodeValue(path, "activeInvoices[" + i + "].amountDue", "amount"));
          		}
      	}
        return Overdue;
    }
    
    public static double getCurrentBilledData(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
      	int activeInvoice = path.getList("activeInvoices").size();
      	double currentBilled = 0;
      	for(int i=0; i< activeInvoice; i++)
      	{
      		if(getNodeValue(path, "activeInvoices[" + i + "]", "invoiceStatus").equals("billed"))
      		{
      			currentBilled = currentBilled + new Double(getNodeValue(path, "activeInvoices[" + i + "].amountDue", "amount"));
      			
      		}
      	}
        return currentBilled;
    }
    
    private static String getNodeValue(JsonPath path, String nodePath, String nodeName) {
		String value = null;
		try {
			value = path.setRoot(nodePath).get(nodeName).toString().replace(",", "");
		} catch (Exception e) {
		}
		return value;
	}

}
