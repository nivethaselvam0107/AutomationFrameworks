package com.guidewire.data;

import com.guidewire.common.util.EnumHelper;

public enum ServiceRequestStatus {

    OFF_TRACK("Off-track"),
    COMPLETED("Completed"),
    IN_PROGRESS("In Progress");

    private final String propertyName;

    ServiceRequestStatus(final String propertyName) {
        this.propertyName = propertyName;
    }

    @Override
    public String toString() {
        return this.propertyName;
    }

    public static ServiceRequestStatus fromString(String name) {
        return EnumHelper.fromString(ServiceRequestStatus.class, name);
    }

    public enum Action {
        AGREE_QUOTE("Agree to provide quote"),
        AGREE_SERVICE("Agree to perform service"),
        FINISH("Finish the work"),
        NONE("None - request canceled");

        private final String propertyName;

        Action(final String propertyName) {
            this.propertyName = propertyName;
        }

        @Override
        public String toString() {
            return this.propertyName;
        }
    }

    public enum Service {
        BODY("Auto body"),
        GLASS("Glass"),
        AUDIO("Audio equipment");

        private final String propertyName;

        Service(final String propertyName) {
            this.propertyName = propertyName;
        }

        @Override
        public String toString() {
            return this.propertyName;
        }
    }
}
