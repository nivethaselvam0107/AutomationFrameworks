package com.guidewire.data;

/**
 * Created by dfedo on 09/12/2016.
 */
public enum QuoteScheduledPropertyItem {

    SCHEDULED_PERSONAL_PROPERTY(0, 3, "SCHEDULED_PERSONAL_PROPERTY_DESC", "Furs" ),
    SPECIAL_LIMITS_PERSONAL_PROPERTY(1, 3, "SPECIAL_LIMITS_PERSONAL_PROPERTY_DESC" , "Furs" ),
    OTHER_STRUCTURES(2, 2, "OTHER_STRUCTURES_DESC", "10%");

    private int m_blockIndex;
    private int m_numberOfMandatoryFileds;
    private String m_description;
    private String m_dropdowlistValue;

    private QuoteScheduledPropertyItem( int blockIndex, int numberOfMandatoryFileds, String description, String dropdowlistValue )
    {
        m_blockIndex = blockIndex;
        m_numberOfMandatoryFileds = numberOfMandatoryFileds;
        m_description = description;
        m_dropdowlistValue = dropdowlistValue;
    }

    public int getBlockIndex()
    {
        return m_blockIndex;
    }

    public int getNumberOfMandatoryFileds()
    {
        return m_numberOfMandatoryFileds;
    }

    public String getDescriptionIdentifier()
    {
        return m_description;
    }

    public String getDropdowlistValue()
    {
        return m_dropdowlistValue;
    }
    
    public String setDescriptionIdentifier(String desc)
    {
        return m_description = desc;
    }
    
    public String setDropdowlistValue(String value)
    {
        return m_dropdowlistValue = value;
    }
}
