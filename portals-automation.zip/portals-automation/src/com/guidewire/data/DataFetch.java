package com.guidewire.data;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.multhithreading.JsonRpcExecutor;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.thetransactioncompany.jsonrpc2.client.JSONRPC2SessionException;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.apache.log4j.Logger;

import javax.xml.bind.DatatypeConverter;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.Callable;

public class DataFetch {

	private static Logger LOGGER = Logger.getLogger(DataFetch.class);
	private static boolean useSU = false;

	public static void main(String[] args) {
		System.setProperty("host.name", "automation-diamond.digital-portals-test.net");
		//System.setProperty("host.name", "localhost");
		System.setProperty("uid", "su");
		System.setProperty("pwd", "gw");
		//String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
		//System.out.println(createRenewal("7946411353", "Quoted"));
		//System.out.println(getVehicleDriverPercentAssignment("3416282807"));
		//System.out.println(createRenewal("6446936606", "Bound"));
		//System.out.println(cancelPolicyByCarrier("6446936606"));
		//System.out.println(getQuoteAsJsonData("0000379104"));
		//PolicyGenerator.createBasicBoundPAPolicy();
		System.out.println(getOverrideAccountPaymentInstrument("Test-1502189086028"));
		//System.out.println(setAccountBillingLevel("Test-1502189086027"));
		//System.out.println(getAccountPaymentInstrument("Test-1501844983286"));
		//runBCAdminJobs("InvoiceDue");
	   //System.out.println(getQuoteAsJsonData("90210", "0002780737"));
	}

	
	public static String backendCall(List<Object> params, String method, String url) {
		return backendCall(ThreadLocalObject.getData().get("USER"), ThreadLocalObject.getData().get("PWD"), params, method, url);
	}

	public static String backendCallWithSU(List<Object> params, String method, String url) {
		return backendCall("su", "gw", params, method, url);
	}

	public static String backendCallWithiNowAdmin(List<Object> params, String method, String url) {
		return backendCall("","", params, method, url);
	}

	private static String backendCall(final String username, final String pwd, List<Object> params, String method, String url) {
		return handleBackendCall(() -> JsonRpcExecutor.getInstance().jsonRpcCallWithCredentials(params, method, getUrl(url), username, pwd));
	}

	private static String backendCall(final String token, List<Object> params, String method, String url) {
		return handleBackendCall(() -> JsonRpcExecutor.getInstance().jsonRpcCallWithToken(params, method, getUrl(url), token));
	}

	private static String handleBackendCall(Callable<String> backendCaller) {
		for(int i=1; i<=5; i++ )
		{
			try {
				return backendCaller.call();
			} catch (MalformedURLException e) {
				LOGGER.warn("MalformedURLException backendCall", e);
			} catch (JSONRPC2SessionException e) {
				LOGGER.warn("JSONRPC2SessionException backendCall failed. Retry Count ===>> " + i, e);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		return null;
	}

	public static String fetchUaaToken() throws IOException {
		HashMap<String,String> testData = ThreadLocalObject.getData();
		// set request details
		String url = getConfiguredHostname() + ":7777/oauth/token";
		HttpURLConnection httpConnection = (HttpURLConnection) new URL(url).openConnection();
		String uaaUser = testData.get("UAA_USER");
		String uaaPassword = testData.get("UAA_PWD");
		String uaaAuthorization = "Basic " + Base64.getEncoder().encodeToString((uaaUser + ":" + uaaPassword).getBytes()); //qa-account-management
		httpConnection.setRequestMethod("POST");
		httpConnection.setRequestProperty("content-type", "application/x-www-form-urlencoded");
		httpConnection.setRequestProperty("cache-control", "no-cache");
		httpConnection.setRequestProperty("Authorization", uaaAuthorization);

		// send request
		httpConnection.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(httpConnection.getOutputStream());
		String username = testData.get("USER");
		String password = testData.get("PWD");
		String requestBody = "grant_type=password&username=" + username + "&password="+ password +"&response_type=token";
		wr.writeBytes(requestBody);
		wr.flush();
		wr.close();

		// check response validity
		int responseCode = httpConnection.getResponseCode();
		if (responseCode != 200) {
			throw new IllegalStateException("Not authorized by UAA server. Response code: " + responseCode);
		}

		// parse response content
		BufferedReader inputStreamReader = new BufferedReader(new InputStreamReader(httpConnection.getInputStream()));
		String inputLine;
		StringBuilder response = new StringBuilder();
		while ((inputLine = inputStreamReader.readLine()) != null) {
			response.append(inputLine);
		}
		inputStreamReader.close();

		JSONObject jsonResponse = (JSONObject) JSONValue.parse(response.toString());
		return (String) jsonResponse.get("access_token");
	}

	public static String iNowPolicyBackendCallGetRequest(final String username, final String pwd, String policyNumber) throws Exception {
		final List<Object> fParams = null;
		final String fUrl  = "https://insurancenow_api_master:8443/coreapi/v3/quotes/" + policyNumber + "?includeDeleted=true";
		URL obj = new URL(fUrl);


		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("Authorization", "Basic " + toBase64(username+":"+pwd));
		con.setRequestProperty("Accept", "application/json, text/plain, */*");
		con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
		for(int i=1; i<=5; i++ )
		{
			try {
				int responseCode = con.getResponseCode();
				LOGGER.info("Response Code : " + responseCode);
				BufferedReader in = new BufferedReader(
						new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();
				LOGGER.info("Response data : \n\t" + response);
				return response.toString();
			} catch (MalformedURLException e) {
				LOGGER.warn("MalformedURLException backendCall", e);
			}
			catch (Exception e) {
				LOGGER.warn("HTTP GET req Failed. Retry Count ===>> " + i, e);
			}
		}
		return null;
	}

	private static String toBase64(String input) {

		return DatatypeConverter.printBase64Binary(input.getBytes());
	}



	public static String getUrl(String url) {
		String vmType = System.getProperty("vm.type") != null ? System.getProperty("vm.type") : "";
		if (!(vmType.equals("local") || vmType.equals("dev"))) {
			String searchFor = "proxy";
			int searchFoundLocation = url.lastIndexOf(searchFor);
			if ( searchFoundLocation > 0 )
				url = url.substring(searchFoundLocation + searchFor.length());
		}

		if(url.contains("http")) {
			return url;
		}

		return getConfiguredHostname() + url;
	}

	private static String getConfiguredHostname() {
		String hostName = System.getProperty("host.name");
		if(hostName.contains("http")) {
			return hostName;
		}
		return "http://" + hostName;
	}

	public static String getQuoteData(String zipCode, String submissionNumber) {
		String url = ":8180/pc/service/edge/test-quote/quote";
		String method = "retrieve";

		List<Object> params = getQuoteReqParams(zipCode, submissionNumber, url);
		return backendCallWithSU(params, method, url);
	}

	public static String getiNowQuoteData(String zipCode, String submissionNumber) {
		String url = "/quote/quote";
		String method = "retrieve";
		List<Object> params = getQuoteReqParams(zipCode, submissionNumber, url);
		return backendCallWithiNowAdmin(params, method, url);
	}

	public static String getiNowPolicyData(String policyNumber) throws Exception {
		return iNowPolicyBackendCallGetRequest("admin", "9999",  policyNumber);
	}


	public static List<Object> getQuoteReqParams(String zipCode, String submissionNumber, String url) {
		Map<String, Object> reqParams = new HashMap<String, Object>();
		reqParams.put("effectiveDate", new Date().toGMTString());
		reqParams.put("postalCode", zipCode);
		reqParams.put("quoteID", submissionNumber);
		List<Object> params = new ArrayList<>();
		params.add(reqParams);
		return params;
	}

	public static String getQuoteUWIssues(String submissionNumber) {
		String url = ":8180/pc/service/edge/test-quote/quoteverify";
		String method = "getSubmissionUWIssues";

		List<Object> params = new ArrayList<>();
		params.add(submissionNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String createRenewal(String policyNumber, String renewalStatus) {
		String url = ":8180/pc/service/edge/test-policy/datacreation";
		String method = "createRenewal";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);
		params.add(renewalStatus);

		return backendCallWithSU(params, method, url);
	}

	public static String cancelPolicyChange(String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/datacreation";
		String method = "cancelPolicyChange";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getVehicleDriverPercentAssignment(String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/dataverify";
		String method = "getVehicleDriverAssignment";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String cancelPolicyByCarrier(String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/datacreation";
		String method = "cancelPolicyByCarrier";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAccountPolicyData(String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/policy";

		String method = "getAccountPolicyDetails";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	//TODO: With new UAA code this call is not usable
	public static String getAccountPolicySummary() {
		String url = ":8180/pc/service/edge/test-policy/policy";
		String method = "getAccountPolicySummaries";
		List<Object> params = new ArrayList<>();

		return backendCall(params, method, url);
	}

	public static String getClaimData(String claimNum) {
		String url = ":8080/cc/service/edge/test-claim/claim";
		String method = "getClaimDetail";

		List<Object> params = new ArrayList<>();
		params.add(claimNum);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentClaimData(String claimNum) {

		String url = ":8080/cc/service/edge/gatewayclaim/claim";
		String method = "getClaimDetail";

		List<Object> params = new ArrayList<>();
		params.add(claimNum);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentActivitiesData() {

		String url = ":8180/pc/service/edge/gateway/activity";
		String method = "getActivitiesForCurrentUserAndGroups";

		List<Object> params = new ArrayList<>();

		return backendCall(params, method, url);
	}

	//TODO call is failing. Need to check with Dev
	public static String getClaimListorAgent() {

		String url = ":8080/cc/service/edge/gatewayclaim/claim";
		String method = "getClaimsForCurrentUser";

		Map<String, Object> reqParams = new HashMap<String, Object>();
		reqParams.put("offsetEnd", "0");
		reqParams.put("offsetStart", "100");
		reqParams.put("orderBy", "CreateTime");
		reqParams.put("orderByDescending", "true");
		List<Object> params = new ArrayList<>();
		params.add(null);
		params.add(reqParams);
		params.add(new ArrayList<>().add(null));

		return backendCallWithSU(params, method, url);
	}

	public static String getAccountDetails(String accountNum) {

		String url = ":8180/pc/service/edge/gateway/account";
		String method = "getAccountDetails";

		List<Object> params = new ArrayList<>();
		params.add(accountNum);

		return backendCallWithSU(params, method, url);
	}


	public static String getClaimPolicyData(String claimNumber) {
		String url = ":8080/cc/service/edge/test-claim/claim";
		String method = "getClaimPolicyDetail";

		List<Object> params = new ArrayList<>();
		params.add(claimNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String loadEndorsementData(String policyNum) {
		String url = ":8180/pc/service/edge/test-policychange/policychange";
		String method = "load";

		List<Object> params = new ArrayList<>();
		params.add(policyNum);

		return backendCallWithSU(params, method, url);
	}

	public static String getBillingData(String accessToken) {
		String url = ":8580/bc/service/edge/billing/billingData";
		String method = "getAccountBillingSummary";
		return backendCall(accessToken, new ArrayList<>(), method, url);
	}

	public static String getPolicyLastPaymentData(String accountNumber) {

		String url = ":8580/bc/service/edge/test-billing/dataverify";
		String method = "getPolicyLastPaymentDetails";
		List<Object> params = new ArrayList<>();
		params.add(accountNumber);
		return backendCallWithSU(params, method, url);
	}

	//Use job codes
	public static String runBCAdminJobs(String jobName) {

		String url = ":8580/bc/service/edge/test-billing/datacreation";
		String method = "runBCAdminJobs";
		List<Object> params = new ArrayList<>();
		params.add(jobName);
		return backendCallWithSU(params, method, url);
	}

	public static String getOverrideAccountPaymentInstrument(String accountNumber) {

		String url = ":8580/bc/service/edge/test-billing/dataverify";
		String method = "getOverrideInstrumentValue";
		List<Object> params = new ArrayList<>();
		params.add(accountNumber);
		return backendCallWithSU(params, method, url);
	}

	public static String setAccountBillingLevel(String accountNumber) {

		String url = ":8580/bc/service/edge/test-billing/datacreation";
		String method = "setBillingAsAccountLevel";
		List<Object> params = new ArrayList<>();
		params.add(accountNumber);
		return backendCallWithSU(params, method, url);
	}

	public static String setPolicyBillingLevel(String accountNumber) {

		String url = ":8580/bc/service/edge/test-billing/datacreation";
		String method = "setBillingAsPolicyLevel";
		List<Object> params = new ArrayList<>();
		params.add(accountNumber);
		return backendCallWithSU(params, method, url);
	}

	public static String getDefaultPaymentInstrument(String accountNumber) {

		String url = ":8580/bc/service/edge/test-billing/dataverify";
		String method = "getDefaultInstrumentValue";
		List<Object> params = new ArrayList<>();
		params.add(accountNumber);
		return backendCallWithSU(params, method, url);
	}

	public static String getPolicyChangeData(String policyNumber, String user) {

		String url = ":8180/pc/service/edge/test-policychange/policychange";
		String method = "load";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getQuoteAsJsonData() {
		return DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				new QuoteInfoBar().getSubmissionNumber());
	}

	public static String getINowQuoteAsJsonData() {
		return DataFetch.getiNowQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				new QuoteInfoBar().getSubmissionNumber());
	}

	public static String getINowPolicyInfoAsJsonData(String policyNumber) throws Exception{
		return DataFetch.getiNowPolicyData(policyNumber);
	}

	public static String getQuoteAsJsonData(String quoteNumber) {
		return DataFetch.getQuoteData(ThreadLocalObject.getData().get("ZipCode"),
				quoteNumber);
	}

	public static String getQuoteAsJsonData(String zipCode, String quoteNumber) {
		return DataFetch.getQuoteData(zipCode,
				quoteNumber);
	}

	//TODO: With new UAA code this call is not usable
	public static String getUserProfileData() {
		String url = ":8180/pc/service/edge/test-profileinfo/user";
		String method = "getAccountContactSummary";
		List<Object> params = new ArrayList<>();

		return backendCallWithSU(params, method, url);
	}

	public static String getPolicyData(String username, String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/policy";
		String method = "getAccountPolicyDetails";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String createClaimActivity(String activityStatus, String activityPriority, String vendorName) {
		String url = ":8080/cc/service/edge/test-activity/datacreation";
		String method = "createClaimActivity";

		List<Object> params = new ArrayList<>();
		params.add(activityStatus);
		params.add(activityPriority);
		params.add(vendorName);

		return backendCallWithSU(params, method, url);
	}

	public static String getClaimActivityDetails(String activityID) {
		String url = ":8080/cc/service/edge/test-claim/activity";
		String method = "getActivity";

		List<Object> params = new ArrayList<>();
		params.add(activityID);

		return backendCallWithSU(params, method, url);
	}

	public static String getClaimActivityNoteDetails(String activityID) {
		String url = ":8080/cc/service/edge/test-claim/activity";
		String method = "getActivityNotes";

		List<Object> params = new ArrayList<>();
		params.add(activityID);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyData(String policyNumber) {
		String host = System.getProperty("host.name");
		host = host.replaceAll(":[0-9]+", "");
		String url = "http://" + host +":8180/pc/service/edge/gateway/policy";
		String method = "getPolicy";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyDocumentAsSU(String policyNumber) {

		String url = ":8180/pc/service/edge/gateway/policy";
		String method = "getDocumentsForPolicy";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyNotesDataAsSU(String policyNumber) {

		String url = ":8180/pc/service/edge/gateway/policy";
		String method = "getNotesForPolicy";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyBillingDataAsSU(String policyNumber) {

		String url = ":8180/pc/service/edge/gateway/policy";
		String method = "getPolicyBillingSummaryInfo";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyTransactionsForPolicy(String username, String policyNumber) {

		String url = ":8180/pc/service/edge/gateway/policy";
		String method = "getPolicyTransactionsForPolicy";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}

	public static String getAgentPolicyDataAsSU(String policyNumber) {
		useSU = true;
		String policyData = DataFetch.getAgentPolicyData(policyNumber);
		return policyData;
	}

	public static String getServiceRequestDetails(String serviceNum) {
		String url = ":8080/cc/service/edge/test-servicerequest/servicerequest";
		String method = "getServiceRequestDetails";

		List<Object> params = new ArrayList<>();
		params.add(serviceNum);

		return backendCallWithSU(params, method, url);
	}

	public static String getFNOLPolicyList(String username) {
		String todayDate = ZonedDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE);
		String url = ":8080/cc/service/edge/test-fnol/policy";
		String method = "searchPolicies";

		LOGGER.info("todayDate");
		Map<String, Object> reqParams = new HashMap<String, Object>();
		reqParams.put("lossDate", todayDate);
		List<Object> params = new ArrayList<>();
		params.add(reqParams);

		return backendCallWithSU(params, method, url);
	}

	public static String getServiceRequests(String s) {

		String url = ":8080/cc/service/edge/test-servicerequest/servicerequest";
		String method = "getServiceRequestsForVendor";
		List<Object> params = new ArrayList<>();

		return backendCallWithSU(params, method, url);
	}

	public static String getDocUploadClaimSessionId() {
		String url = ":8080/cc/service/edge/test-claim/docs";
		String method = "generateUploadToken";
		List<Object> params = new ArrayList<>();

		return backendCallWithSU(params, method, url);
	}

	public static String getDocUploadPolicySessionId() {
		String url = ":8180/pc/service/edge/test-policy/docs";
		String method = "generateUploadToken";
		List<Object> params = new ArrayList<>();

		return backendCallWithSU(params, method, url);
	}

	public static String getDocUploadAgentClaimSessionId() {
		String url = ":8080/cc/service/edge/gatewayclaim/docs";
		String method = "generateUploadToken";
		List<Object> params = new ArrayList<>();

		return backendCallWithSU(params, method, url);
	}

	public static String searchForVendorsWithGeoCode(Map<String, Object> searchCriteria) {
		Map<String, Object> reqParams = new HashMap<>();
		Map<String, Object> geo = new HashMap<>();
		geo.put("latitude", searchCriteria.get("latitude"));
		geo.put("longitude", searchCriteria.get("longitude"));

		searchCriteria.remove("latitude");
		searchCriteria.remove("longitude");
		reqParams.putAll(searchCriteria);
		reqParams.put("proximitySearchGeocode", geo);

		return searchForVendors(reqParams);
	}

	public static String searchForVendorsWithAddress(Map<String, Object> searchCriteria) {
		Map<String, Object> reqParams = new HashMap<>();
		Map<String, Object> address = new HashMap<>();
		address.put("addressLine1", searchCriteria.get("addressLine1"));
		address.put("city", searchCriteria.get("city"));
		address.put("country", searchCriteria.get("country"));
		address.put("state", searchCriteria.get("state"));

		reqParams.putAll(searchCriteria);
		reqParams.put("proximitySearchAddress", address);

		return searchForVendors(reqParams);
	}

	/*
	searchRadius: range from 1 to 300
	specialistServiceCodes: autoinsprepairbody, autoinsprepairglass, autoinsprepairaudio
	*/
	private static String searchForVendors(Map<String, Object> searchParams) {
		String url = ":8280/ab/service/edge/test-vendor/vendor";
		String method = "proximitySearch";

		Map<String, Object> reqParams = new HashMap<>();
		List<Object> params = new ArrayList<>();

		reqParams.putAll(searchParams);
		reqParams.put("searchRadius", searchParams.get("searchRadius"));
		reqParams.put("maxNumberOfResults", searchParams.get("maxNumberOfResults"));
		reqParams.put("unitOfDistance", searchParams.get("unitOfDistance"));
		String[] serviceArray = searchParams.get("specialistServiceCodes").toString().split(",");
		reqParams.put("specialistServiceCodes", Arrays.asList(serviceArray));

		params.add(reqParams);

		return backendCallWithSU(params, method, url);
	}

	//TODO: With new UAA code this call is not usable
	//states: open, draft, closed (provide in coma separated string)
	public static String getClaimSummaries(List<String> states) {
		String url = ":8080/cc/service/edge/test-claim/claim";
		String method = "getClaimSummaries";
		List<Object> params = new ArrayList<>();

		JSONObject offSetData = new JSONObject();
		offSetData.put("offsetStart", 0);
		offSetData.put("offsetEnd", 24);

		JSONArray stateData = (JSONArray) JSONValue.parse(states.toString());

		JSONObject stateObject = new JSONObject();
		stateObject.put("claimStates", stateData);

		params.add(stateObject);
		params.add(offSetData);

		return backendCallWithSU(params, method, url);
	}


	public static String createPolicyCopy(String policyNumber) {
		String url = ":8180/pc/service/edge/test-policy/datacreation";
		String method = "createPolicyCopy";

		List<Object> params = new ArrayList<>();
		params.add(policyNumber);

		return backendCallWithSU(params, method, url);
	}
}