package com.guidewire.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.guidewire.capabilities.common.dto.PropertyDTO;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.DateUtil;

import io.restassured.path.json.JsonPath;

public class ParseClaimData {

	private static final Logger LOGGER = Logger.getLogger(ParseClaimData.class);

	public static HashMap<String, String> getClaimSummaryDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);

		DataFormatUtil.putData(info, ClaimData.POLICY_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "policy", "policyNumber"));
		DataFormatUtil.putData(info, ClaimData.ACCOUNT_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "policy", "accountNumber"));
		DataFormatUtil.putData(info, ClaimData.CLAIM_STATE.getValue(),
				DataFormatUtil.getNodeValue(path, "claimState", "."));
		DataFormatUtil.putData(info, ClaimData.DATE_OF_LOSS.getValue(),
				DateUtil.getDateFromISODateMMMMMMdYYYY(DataFormatUtil.getNodeValue(path, "lossDate", ".")));
		DataFormatUtil.putData(info, ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "claimReporter", "reportedBy.displayName"));
		DataFormatUtil.putData(info, ClaimData.LOSS_LOCATION_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "lossLocation", "displayName"));
		DataFormatUtil.putData(info, ClaimData.ADJUSTER_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "adjuster", "displayName"));
		DataFormatUtil.putData(info, ClaimData.ADJUSTER_CONTACT_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "adjuster", "phoneNumber"));

		if (ThreadLocalObject.getData().get("ClaimType").equals("WorkersComp")) {
			DataFormatUtil.putData(info, ClaimData.DATE_NOTIFIED.getValue(),
					DateUtil.getDateFromISODateMMMMMMdYYYY(
							DataFormatUtil.getNodeValue(path, "lobs", "workersComp.dateReportedToEmployer")
					));
		}
		
		info.putAll(getPartiesInvolvedDataFromBackEnd(jsonData));

		return info;
	}

	public static List<HashMap<String, String>> getClaimNotesDataFromBackEnd(String jsonData) {
		List<HashMap<String, String>> allNotes = new ArrayList<>();
		JsonPath path = new JsonPath(jsonData);
		int notesCount = path.getList("notes").size();

		for (int i = 0; i < notesCount; i++) {
			HashMap<String, String> singleNote = new HashMap<>();
			DataFormatUtil.putData(singleNote, "USER",
					DataFormatUtil.getNodeValue(path, "notes[" + i + "].author", "firstName"));
			DataFormatUtil.putData(singleNote, "NOTE_CREATION_TIME",
					DataFormatUtil.getNodeValue(path, "notes[" + i + "]", "dateCreated"));
			DataFormatUtil.putData(singleNote, "NoteBody",
					DataFormatUtil.getNodeValue(path, "notes[" + i + "]", "body"));
			DataFormatUtil.putData(singleNote, "NoteSubject",
					DataFormatUtil.getNodeValue(path, "notes[" + i + "]", "subject"));
			allNotes.add(singleNote);
		}

		return allNotes;
	}

	public static List<HashMap<String, String>> getClaimDocumentDataFromBackEnd(String jsonData) {
		List<HashMap<String, String>> allDocs = new ArrayList<>();
		JsonPath path = new JsonPath(jsonData);
		int docCount = path.getList("documents").size();
		for (int i = 0; i < docCount; i++) {
			HashMap<String, String> singleDoc = new HashMap<>();
			String docName = DataFormatUtil.getNodeValue(path, "documents[" + i + "]", "name").toLowerCase();
			int index = docName.lastIndexOf(".");
			docName = docName.contains("jpg") || docName.contains("png") ? docName.substring(0,index) : docName;
			DataFormatUtil.putData(singleDoc, "DOC_NAME",
					DataFormatUtil.getNodeValue(path, "documents[" + i + "]", "name").toLowerCase());
			DataFormatUtil.putData(singleDoc, "DOC_AUTHOR",
					DataFormatUtil.getNodeValue(path, "documents[" + i + "]", "author"));
			DataFormatUtil.putData(singleDoc, "DOC_TYPE",
					DataFormatUtil.getNodeValue(path, "documents[" + i + "]", "documentType"));
			DataFormatUtil.putData(singleDoc, "DOC_SECURITY",
					DataFormatUtil.getNodeValue(path, "documents[" + i + "]", "securityType"));
			allDocs.add(singleDoc);
		}

		return allDocs;
	}

	public static HashMap<String, String> getPAClaimVehicleCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int vehicleCount = path.getList("lobs.personalAuto.vehicles").size();

		for (int i = 0; i < vehicleCount; i++) {
			String vehicleLicensePlate = DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"]", "licensePlate");
			DataFormatUtil.putData(info, "VEHICLE_MAKE_"+ vehicleLicensePlate,
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"]", "make"));
			DataFormatUtil.putData(info, "VEHICLE_LICENSE_PLATE_"+ vehicleLicensePlate,
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"]", "licensePlate"));
			DataFormatUtil.putData(info, "VEHICLE_YEAR_"+ vehicleLicensePlate,
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"]", "year"));
			DataFormatUtil.putData(info, "VEHICLE_MODEL_"+ vehicleLicensePlate,
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"]", "model"));

			for(int j =0; j < 2; j++ ) { //Coverage

				if (DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name").equals("Medical Payments")) {
					DataFormatUtil.putData(info, "MED_PAY_TYPE_TEXT",
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name"));
					DataFormatUtil.putData(info, "MED_PAY_LIMIT_TYPE_PER_ACCIDENT",
							"Per Accident");
					DataFormatUtil.putData(info, "MED_PAY_LIMIT_TYPE_PER_PERSON",
							"Per Accident");
					DataFormatUtil.putData(info, "MED_PAY_LIMIT_VALUE_PER_ACCIDENT_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].incidentLimit", "amount"));
					DataFormatUtil.putData(info, "MED_PAY_LIMIT_VALUE_PER_PERSON_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].exposureLimit", "amount"));

				} else if (DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name").equals("Liability - Bodily Injury and Property Damage")) {
					DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_TEXT",
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name"));
					DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT_"+ vehicleLicensePlate,
							"Per Accident");
					DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_PERSON_"+ vehicleLicensePlate,
							"Per Person");
					DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].incidentLimit", "amount"));
					DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_PERSON_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].exposureLimit", "amount"));

				} else if(DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name").equals("Collision")) {
					DataFormatUtil.putData(info, "COLLISION_TYPE_TEXT",
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name"));
					DataFormatUtil.putData(info, "COLLISION_DEDUCTIBLE_LIMIT_VALUE_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].deductible", "amount"));
					DataFormatUtil.putData(info, "COLLISION_LIMIT_VALUE_PER_ACCIDENT_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].incidentLimit", "amount"));

				} else if(DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name").equals("Comprehensive")) {
					DataFormatUtil.putData(info, "COMPREHENSIVE_TYPE_TEXT",
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"]", "name"));
					DataFormatUtil.putData(info, "COMPREHENSIVE_DEDUCTIBLE_LIMIT_VALUE_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].deductible", "name"));
					DataFormatUtil.putData(info, "COMPREHENSIVE_LIMIT_VALUE_PER_ACCIDENT_"+ vehicleLicensePlate,
							DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicles["+ i +"].coverages["+ j +"].incidentLimit", "amount"));
				}
			}
		}

		return info;
	}

	public static HashMap<String, String> getPAClaimPolicyLevelCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int covCount = path.getList("coverages").size();

		for (int i = 0; i < covCount; i++) {
			if (DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name").equals("Medical Payments")) {
				DataFormatUtil.putData(info, "MED_PAY_TYPE_TEXT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "MED_PAY_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].exposureLimit", "amount"));
				DataFormatUtil.putData(info, "MED_PAY_LIMIT_TYPE_PER_PERSON",
						"Per Person");

			} else if (DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name").equals("Liability - Bodily Injury and Property Damage")) {
				DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_TEXT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_PERSON",
						"Per Person");
				DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT",
						"Per Accident");
				DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "LIB_BI_PROP_DAMAGE_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].exposureLimit", "amount"));

			} else if (DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name").equals("Uninsured Motorist - Bodily Injury")) {
				DataFormatUtil.putData(info, "UI_MOTO_BI_TEXT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "UI_MOTO_BI_LIMIT_TYPE_PER_PERSON",
						"Per Person");
				DataFormatUtil.putData(info, "UI_MOTO_BI_LIMIT_TYPE_PER_ACCIDENT",
						"Per Accident");
				DataFormatUtil.putData(info, "UI_MOTO_BI_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "UI_MOTO_BI_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].exposureLimit", "amount"));

			} else if (DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name").equals("Uninsured Motorist - Property Damage")) {
				DataFormatUtil.putData(info, "UI_MOTO_PROP_DAMAGE_TEXT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "UI_MOTO_PROP_DAMAGE_LIMIT_TYPE_PER_PERSON",
						"Per Person");
				DataFormatUtil.putData(info, "UI_MOTO_PROP_DAMAGE_LIMIT_TYPE_PER_ACCIDENT",
						"Per Accident");
				DataFormatUtil.putData(info, "UI_MOTO_PROP_DAMAGE_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "UI_MOTO_PROP_DAMAGE_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"].exposureLimit", "amount"));

			} else if (DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name").equals("Mexico Coverage - Limited")) {
				DataFormatUtil.putData(info, "MEXICO_COV_TEXT",
						DataFormatUtil.getNodeValue(path, "coverages[" + i +"]", "name"));
			}
		}

		return info;
	}

	public static HashMap<String, String> getHOClaimPolicyLocationCoverageDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);
		int locCount = path.getList("lobs.homeowner.locations[0].coverages").size();

		for (int i = 0; i < locCount; i++) {
			DataFormatUtil.putData(info, "LOCATION",
					DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[" + i +"]", "locationNumber"));
			DataFormatUtil.putData(info, "LOCATION_DESC",
					DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[" + i +"]", "addressType"));
			DataFormatUtil.putData(info, "LOCATION_ADDRESS",
					DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[" + i +"].locationAddress", "displayName"));
			String item = DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[" + i +"]", "hasListedItems");

			item = (item == null || item.equalsIgnoreCase("false")) ? "No" : "Yes";

			DataFormatUtil.putData(info, "LOCATION_LISTED", item);
			if (DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Loss Of Use")) {
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_LOSS_OF_USE_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Dwelling")) {
				DataFormatUtil.putData(info, "HO_DWEL",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_DWEL_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Section I Deductibles")) {
				DataFormatUtil.putData(info, "HO_SEC",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Other Structures")) {
				DataFormatUtil.putData(info, "HO_OTR_STRU",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_OTR_STRU_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_OTR_STRU_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Ordinance Or Law")) {
				DataFormatUtil.putData(info, "HO_ORD_LAW", DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_ORD_LAW_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Personal Property")) {
				DataFormatUtil.putData(info, "HO_PER_PROP",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_PER_PROP_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Medical Payments")) {
				DataFormatUtil.putData(info, "HO_MED_PAY",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_MED_PAY_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").equals("Homeowners Personal Liability")) {
				DataFormatUtil.putData(info, "HO_PER_LIB",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "HO_PER_LIB_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
				DataFormatUtil.putData(info, "HO_PER_LIB_LIMIT_VALUE_PER_PERSON",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].exposureLimit", "amount"));

			} else if(DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name").contains("Limited Fungi")) {
				DataFormatUtil.putData(info, "LMT_FUNGI_WET_BACT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"]", "name"));
				DataFormatUtil.putData(info, "LMT_FUNGI_WET_BACT_LIMIT_VALUE_PER_ACCIDENT",
						DataFormatUtil.getNodeValue(path, "lobs.homeowner.locations[0].coverages[" + i +"].incidentLimit", "amount"));
			}
		}

		return info;
	}

	public static HashMap<String, String> getClaimDetailsDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);

		DataFormatUtil.putData(info, ClaimData.ACCOUNT_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "policy", "accountNumber"));
		DataFormatUtil.putData(info, ClaimData.POLICY_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "policy", "policyNumber"));
		DataFormatUtil.putData(info, ClaimData.CLAIM_STATE.getValue(),
				DataFormatUtil.getNodeValue(path, "claimState", "."));
		DataFormatUtil.putData(info, ClaimData.LOSS_CAUSE.getValue(),
				DataFormatUtil.getNodeValue(path, "lossCause", "."));
		DataFormatUtil.putData(info, ClaimData.LOSS_DESC.getValue(),
				DataFormatUtil.getNodeValue(path, "description", "."));
		DataFormatUtil.putData(info, ClaimData.LOSS_LOCATION_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "lossLocation", "displayName"));
		DataFormatUtil.putData(info, ClaimData.DATE_OF_LOSS.getValue(),
				DateUtil.getDateFromISODateMMMMMMdYYYY(DataFormatUtil.getNodeValue(path, "lossDate", ".")));

		if (ThreadLocalObject.getData().get("ClaimType").equals("WorkersComp")) {
			DataFormatUtil.putData(info, ClaimData.DATE_NOTIFIED.getValue(),
					DateUtil.getDateFromISODateMMMMMMdYYYY(
							DataFormatUtil.getNodeValue(path, "lobs", "workersComp.dateReportedToEmployer")
					));
		}

		DataFormatUtil.putData(info, ClaimData.CLAIM_REPORTER_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "claimReporter.reportedBy", "displayName"));
		DataFormatUtil.putData(info, ClaimData.CLAIM_REPORTER_DISPLAY_ADDRESS.getValue(),
				DataFormatUtil.getNodeValue(path, "claimReporter.reportedBy", "displayName"));
		DataFormatUtil.putData(info, ClaimData.MAIN_CONTACT_DISPLAY_ADDRESS.getValue(),
				DataFormatUtil.getNodeValue(path, "mainContact.primaryAddress", "displayName"));
		DataFormatUtil.putData(info, ClaimData.MAIN_CONTACT_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "mainContact", "displayName"));
		DataFormatUtil.putData(info, ClaimData.ADJUSTER_DISPLAY_NAME.getValue(),
				DataFormatUtil.getNodeValue(path, "adjuster", "displayName"));
		DataFormatUtil.putData(info, ClaimData.ADJUSTER_CONTACT_NUM.getValue(),
				DataFormatUtil.getNodeValue(path, "adjuster", "phoneNumber"));

		if (ThreadLocalObject.getData().get("ClaimType").equals("PersonalAuto")) {
			if(ThreadLocalObject.getData().get("ClaimSubType").equals("Collision")) {
				DataFormatUtil.putData(info, "Model",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].vehicle", "model"));
				DataFormatUtil.putData(info, "Make",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].vehicle", "make"));
				DataFormatUtil.putData(info, "VehicleYear",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].vehicle", "year"));
				DataFormatUtil.putData(info, "SAFE_TO_DRIVE",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "safeToDrive"));
				DataFormatUtil.putData(info, "AIRBAG_DEPLOYED",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "airbagsDeployed"));
				DataFormatUtil.putData(info, "EQUIP_FAIL",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "equipmentFailure"));
				DataFormatUtil.putData(info, "VEH_TOWED",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "vehicleTowed"));
				DataFormatUtil.putData(info, "VEH_RENTAL",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "rentalRequired"));
				DataFormatUtil.putData(info, "VEH_COLLISION_POINT_VALUE",
						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0]", "collisionPoint"));
	
//	TODO : Json RPC is not having this data returned, will enable it when handler will be fixed
//				DataFormatUtil.putData(info, "DRIVER_DISPLAY_NAME",
//						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].driver", "displayName"));
//				DataFormatUtil.putData(info, "DRIVER_CONTACT_NUM",
//						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].driver", "homeNumber"));
//				DataFormatUtil.putData(info, "DRIVER_ADDRESS_DISPLAY_NAME",
//						DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].driver.primaryAddress", "displayName"));
			}
		}
		if(ThreadLocalObject.getData().containsKey("WithPassenger"))
		{
			DataFormatUtil.putData(info, "PASSENGER_DISPLAY_NAME",
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].passengers[0]", "displayName"));
			DataFormatUtil.putData(info, "PASSENGER_CONTACT_NUM",
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].passengers[0]", "homeNumber"));
			DataFormatUtil.putData(info, "PASSENGER_ADDRESS_DISPLAY_NAME",
					DataFormatUtil.getNodeValue(path, "lobs.personalAuto.vehicleIncidents[0].passengers[0].primaryAddress", "displayName"));
		}
		
		int contactInvolvment = (path.setRoot("claimContacts").getList(".").size());

		for (int i = 0; i < contactInvolvment; i++) {
			if (path.setRoot("claimContacts[" + i + "]").getList("contactRoles").contains("witness")) {
				DataFormatUtil.putData(info, ClaimData.WITNESS_DISPLAY_NAME.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "displayName"));
				DataFormatUtil.putData(info, ClaimData.WITNESS_CONTACT_NUM.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "homeNumber"));
			}

			if (path.setRoot("claimContacts[" + i + "]").getList("contactRoles").contains("injured")) {
				DataFormatUtil.putData(info, ClaimData.INJURED_DISPLAY_NAME.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "displayName"));
				DataFormatUtil.putData(info, ClaimData.INJURED_CONTACT_NUM.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "homeNumber"));
			}

			if (path.setRoot("claimContacts[" + i + "]").getList("contactRoles").contains("insured")) {
				DataFormatUtil.putData(info, ClaimData.INSURED_DISPLAY_NAME.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "displayName"));
				DataFormatUtil.putData(info, ClaimData.INSURED_CONTACT_NUM.getValue(),
						DataFormatUtil.getNodeValue(path, "claimContacts[" + i + "].contactDTO", "homeNumber"));
			}
		}
		
		info.putAll(getPartiesInvolvedDataFromBackEnd(jsonData));

		return info;
	}

	public static HashMap<String, String> getPartiesInvolvedDataFromBackEnd(String jsonData) {
		HashMap<String, String> info = new HashMap<>();
		JsonPath path = new JsonPath(jsonData);

		int relatedContactsNum = (path.setRoot("relatedContacts").getList(".").size());
		String accountName = ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString()) + " " + ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString());
		for (int i = 0; i < relatedContactsNum; i++) {
			if(DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "displayName").equals(accountName)){
				DataFormatUtil.putData(info, ClaimData.PARTIES_INVOLVED_DISPLAY_NAME.getValue(),
						DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "displayName"));
				String line3= DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "].primaryAddress", "addressLine3");
				String address = DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "].primaryAddress", "displayName");
				address = address.replace(line3 + " ", "");
				DataFormatUtil.putData(info, ClaimData.PARTIES_INVOLVED_DISPLAY_ADDRESS.getValue(),address);

				DataFormatUtil.putData(info, ClaimData.PARTIES_INVOLVED_PHONE.getValue(),
						DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "cellNumber"));
				DataFormatUtil.putData(info, ClaimData.PARTIES_INVOLVED_EMAIL.getValue(),
						DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "emailAddress1"));
			} else {
				if(DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "contactType").equals("CompanyVendor")){
					DataFormatUtil.putData(info, ClaimData.VENDOR_NAME.getValue(),
							DataFormatUtil.getNodeValue(path, "relatedContacts[" + i + "]", "displayName"));
				}
			}
		}

		return info;
	}

	public static List<PropertyDTO> getCPClaimProperties(String jsonData) {
		try {
			ArrayList<HashMap<String, String>> list = new JsonPath(jsonData).getJsonObject("policy.lobs.commercialProperty.propertyRiskUnits");
			ObjectMapper mapper = new ObjectMapper();
			String jsonNode = mapper.writeValueAsString(list);
			return PropertyDTO.fromJson(jsonNode);
		} catch (JsonProcessingException e) {
			LOGGER.warn("Parse properties json error", e);
			throw new RuntimeException(e);
		}
	}

}