package com.guidewire.data;

import com.thetransactioncompany.jsonrpc2.client.ConnectionConfigurator;

import java.net.HttpURLConnection;


public class BearerAuthenticator implements ConnectionConfigurator {
  private String token;

  public void setToken(String token) {
    this.token = token;
  }

  @Override
  public void configure(HttpURLConnection connection) {
    connection.addRequestProperty("Authorization", "Bearer " + token);
  }
}