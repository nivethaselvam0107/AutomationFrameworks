package com.guidewire.data.StringConstants;

/**
 * Created by mthangavelsamy on 02/06/2017.
 */
public class AMPAssertionLogConstants {
    public static final String PERSONALISED_OFFER_RECTANGLE_AD_LOG="Verified text on Perosnalized Offer - Home Page AD";
    public static final String PERSONALISED_OFFER_CLICK_REDIRECTION_LOG="Verified Perosnalized Offer Redirection to Endorsement Wizard";


}
