package com.guidewire.data.StringConstants;

/**
 * Created by mthangavelsamy on 02/06/2017.
 */
public class AMPAssertionConstants {
    public static final String PERSONALISED_OFFER_RECTANGLE_AD_TEXT="Need more peace of mind? Cover your Commercial Property";
    public static final String PERSONALISED_OFFER_LEADER_BOARD_AD_TEXT= "Car Owner? Add Personal Auto Coverage to your account";

}
