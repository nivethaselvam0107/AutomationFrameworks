
package com.guidewire.data;

import java.util.HashMap;

import com.guidewire.common.util.DateUtil;

public class PolicyData_QnB {
	
	
	public static HashMap<String, String> getHomeOwnerTestData()
	{
		//Your Info
		HashMap<String, String> policyData = new HashMap<>();
		
		policyData.put("ZipCode", "94404");
		policyData.put("FirstName", "Dharmesh");
		policyData.put("LastName", "Gangwar");
		policyData.put("DOB", "02/07/1980");
		policyData.put("AddressLine1", "MounJoy Square");
		policyData.put("AddressLine2", "City Center");
		policyData.put("AddressLine3", "Dublin 1");
		policyData.put("City", "Dublin");
		policyData.put("State", "California");
		policyData.put("StateValue", "CA");
		policyData.put("Email", "dh@gmail.com");
		policyData.put("Email_Address2", "johnsnow@gmail.com");
		policyData.put("Email_Address2_Type", "Work");
		policyData.put("Second_AddressLine1", "MounJoy Square");
		policyData.put("Second_AddressLine2", "City Center");
		policyData.put("Second_AddressLine3", "Dublin 1");
		policyData.put("Second_City", "Dublin");
		policyData.put("Second_State", "California");
		policyData.put("Second_StateValue", "CA");
		policyData.put("Second_Email", "dh@gmail.com");
		policyData.put("Quote_Cov_Date", DateUtil.getCurrentDateMMDDYYYY());
		
		//Qualification
		policyData.put("CoverageDeclineStatus", "true");
		policyData.put("BusinessOnPremiseStatus", "false");
		policyData.put("TypeOfBusiness", "Farming");
		policyData.put("OtherBusinessDesc", "OtherBusinessDesc");
		
		//HOP Qualification
		policyData.put("HasDog", "false");
		policyData.put("DogBreed", "Pit Bull");
		policyData.put("PropertyVacant", "false");
		policyData.put("HasPool", "false");
		policyData.put("PropertyOccupier", "Myself");
		policyData.put("FullTimeOccupier", "true");
		policyData.put("InsurePrimary", "true");
		//iNow
		policyData.put("NumberOfAggressiveDogs", "0");
		policyData.put("DescribeDogs", "they are not Aggressive");
		policyData.put("NumberOfClaims", "2");
		policyData.put("HasEsignature", "Yes");
		policyData.put("InowHasPool", "Yes");
		policyData.put("InowHasPoolFenced", "Yes");

		//Home
		policyData.put("HomeValue", "19000");
		policyData.put("LocType", "In City Limits");
		policyData.put("ResType", "1 Family Residence");
		policyData.put("DistanceToFireHydrant", "WithIn500Ft");
		policyData.put("DistanceToFireStation", "WithIn5Miles");
		policyData.put("FloodFireHazard", "false");
		policyData.put("NearCommerProp", "false");
		policyData.put("HomeUsage", "Primary");
		policyData.put("OccupencyType", "Owner Occupied");
		//Home iNow
		policyData.put("SquareFootage", "2900");
		policyData.put("Inow_OccupancyCode", "Owner");
		policyData.put("ProcetctionClass", "2");
		policyData.put("TerritoryCode", "3");
		
		//Back End Returned value for the above related data
		policyData.put("OccupencyTypeValue", "owner");
		policyData.put("LocTypeValue","city");
		policyData.put("DistanceToFireStationValue", "3");
		if(System.getProperty("platform").equalsIgnoreCase("granite")){
			policyData.put("HomeUsageValue","primary");
			policyData.put("DistanceToFireHydrantValue","400");
		} else {
			policyData.put("HomeUsageValue", "prim");
			policyData.put("DistanceToFireHydrantValue", "500");
		}
		policyData.put("OccupencyTypeValue","owner");
		policyData.put("ResTypeValue","Fam1");
		
		//Construction
		policyData.put("BuildYear", "2010");
		policyData.put("Stories", "2");
		policyData.put("Garage", "NoGarage");
		policyData.put("HasGarage", "false");
		policyData.put("ConstructionType", "Concrete");
		if(System.getProperty("platform").equalsIgnoreCase("granite")){
			policyData.put("ConstructionTypeValue", "Concrete");
		} else {
			policyData.put("ConstructionTypeValue", "C");
		}

		policyData.put("FoundationType", "Slab");
		policyData.put("RoofType", "wood");
		policyData.put("RoofOtherTypeDesc", "RoofOtherTypDesc");
		policyData.put("RoofUpGradeFlag", "false");
		policyData.put("RoofUpgradeYear", "2011");
		policyData.put("PlumbingType", "Copper");
		policyData.put("PlumbingTypeValue", "copper");
		policyData.put("PlumbingUpgradeYear", "2011");
		policyData.put("PlumbingUpGradeFlag", "false");
		policyData.put("HeatingType", "Electricity");
		policyData.put("HeatingTypeValue", "Electric");
		policyData.put("HeatingUpGradeFlag", "false");
		policyData.put("PrimaryHeatingOtherTypeDesc", "RoofOtherTypDesc");
		policyData.put("SecondaryHeating", "true");
		policyData.put("HeatingUpgradeYear", "2011");
		policyData.put("WiringType", "Copper");
		policyData.put("ElectricalSystemType", "Circuit Breaker");
		policyData.put("ElectricalSystemTypeValue", "CircuitBreaker");
		policyData.put("WiringUpgradeYear", "2011");
		policyData.put("WiringUpGradeFlag", "false");
		// iNow
		policyData.put("MaterialHouseMade", "Frame");
		policyData.put("INOW_RoofType", "Shingle");
		policyData.put("NumUnits", "2");

		
		//Discount
		policyData.put("FireExtinguishersAvailability", "true");
		policyData.put("FireExtCount", "1");
		policyData.put("BurgularAlarmAvailability", "true");
		policyData.put("BurgAlarmType", "Local");
		policyData.put("BurgAlarmTypeValue", "local");
		policyData.put("FireAlarmReporting", "true");
		policyData.put("SmokeAlarmAvailability", "true");
		policyData.put("AllFloorAvailability", "true");
		policyData.put("DeadBoltAvailability", "true");
		policyData.put("DeadBoltCount", "1");
		policyData.put("VisibilityToNeighbour", "true");
		policyData.put("SprinklerType", "Full");
		policyData.put("SprinklerTypeValue", "full");
		policyData.put("RoomersOrBoardersAvailability", "true");
		policyData.put("RoomersOrBoardersNumber", "1");
		policyData.put("NoOfUnits", "One");
		policyData.put("FirePlaceOrWoodStoveAvailability", "true");
		policyData.put("FirePlaceOrWoodStoveNumber", "2");
		policyData.put("PoolAvailability", "true");
		policyData.put("FenceAvailability", "true");
		policyData.put("DivingBoardAvailability", "true");
		policyData.put("TrampolineAvailability", "true");
		policyData.put("SafetyNetAvailability", "true");
		policyData.put("WaterLeakage", "true");
		policyData.put("WaterLeakageHistory", "WaterLeakageHistory");
		policyData.put("QuoteReferenceNumber", "12345678");
		policyData.put("INOW_SmokeDetector", "Yes");
		policyData.put("INOW_GuardedGate", "Yes");
		policyData.put("INOW_FireAlaram", "Local");
		policyData.put("INOW_BurglarAlarm", "Central");
		policyData.put("INOW_Deductible", "$500");

		
		//Policy Info
		policyData.put("PhoneNumber", "650-333-3333");
		
		//Payment Details
		policyData.put("PaymentPlan", "Weekly");
		policyData.put("AccountNumber", "123456789");
		policyData.put("RoutingNumber", "123456789");
		policyData.put("BankName", "AIB");
		policyData.put("CreditCardNumber", "123456211212121");
		policyData.put("INOW_CreditCardNumber", "4111111111111111");
		policyData.put("INOW_CreditCardCVV", "321");
		policyData.put("INOW_CreditCardExpiry", "04/23");
		policyData.put("INOW_Billing_FirstName", "John");
		policyData.put("INOW_Billing_LastName", "Snow");
		policyData.put("INOW_Billing_Address", "1001 East Hillsdale Boulevard");
		policyData.put("INOW_Billing_City", "Foster City");
		policyData.put("INOW_Billing_State", "California");
		policyData.put("INOW_Billing_Country", "United States of America");
		policyData.put("INOW_Billing_ZIP", "94404");
		policyData.put("INOW_Billing_Phone", "2222222222");
		policyData.put("ExpMonth", "July");
		policyData.put("ExpYear", "2017");
		policyData.put("INOW_PaymentPlan", "Direct Bill 12 Payments");

		
		policyData.put("SchedulePropertyType", "Silverware");
		policyData.put("SchedulePropertyDesc", "SilverwareDesc");
		policyData.put("SchedulePropertyLimit", "3000");
		policyData.put("SchedulePropertyDeductible", "$2,500");
		policyData.put("SchedulePropertyValuationMethod", "Replacement cost");
		policyData.put("SchedulePropertyLocationNonSpecific", "false");
		
		return policyData;
	}
	
	public static HashMap<String, String> getPersonalAutoTestData()
	{
		
		HashMap<String, String> policyData = new HashMap<>();
		
		//Your Info
		policyData.put("ZipCode", "94404");
		policyData.put("FirstName", "Dharmesh");
		policyData.put("LastName", "Gangwar");
		policyData.put("DOB", "12/11/1980");
		policyData.put("AddressLine1", "MounJoy Square");
		policyData.put("AddressLine2", "City Center");
		policyData.put("AddressLine3", "Dublin 1");
		policyData.put("City", "Dublin");
		policyData.put("State", "California");
		policyData.put("StateValue", "CA");
		policyData.put("Email", "dh@gmail.com");
		policyData.put("QuoteReferenceNumber", "12345678");
		policyData.put("Quote_Cov_Date", DateUtil.getCurrentDateMMDDYYYY());
		
		//Qualification
		policyData.put("InsuranceStatus", "Yes");
		policyData.put("InsuranceStatusValue", "yes");
		policyData.put("CurrentLicencseStatus", "false");
		policyData.put("LicencseCancelledAnyTime", "false");
		policyData.put("TrafficeViolationHistory", "false");
		policyData.put("PolicyDeclinedHistory", "false");
		//policyData.put("TrafficeViolationHistoryDetails", "");
		
		//Driver Details
		policyData.put("DriverLastName", "Gangwar");
		policyData.put("DriverGendor", "Male");
		policyData.put("DriverGendorValue", "M");
		policyData.put("DriverFirstName", "Dharmesh");
		policyData.put("DriverLicenseNum", "123eee");
		policyData.put("DriverLicenseState", "California");
		policyData.put("DriverLicenseStateValue", "CA");
		policyData.put("FirstYearLicensed", "2015");
		policyData.put("AccidentNum", "2");
		policyData.put("ViolationNum", "2");
		policyData.put("DriverDOB", "12/11/1980");
		
		policyData.put("NewDriverLastName", "Driver");
		policyData.put("NewDriverGendor", "Male");
		policyData.put("NewDriverGendorValue", "M");
		policyData.put("NewDriverFirstName", "New");
		policyData.put("NewDriverLicenseNum", "XYZ345");
		policyData.put("NewDriverLicenseState", "California");
		policyData.put("NewDriverLicenseStateValue", "CA");
		policyData.put("NewDriverFirstYearLicensed", "2015");
		policyData.put("NewDriverAccidentNum", "0");
		policyData.put("NewDriverViolationNum", "0");
		policyData.put("NewDriverDOB", "11/11/1981");
	
		//Vehicle Details
		policyData.put("VIN", "12345678");
		policyData.put("Make", "Toyota");
		policyData.put("Model", "Avensis");
		policyData.put("VehicleYear", "2013");
		policyData.put("LicensePlate", "A1A2DGH");
		policyData.put("VehicleState", "California");
		policyData.put("VehicleStateValue", "CA");
		policyData.put("VehicleCost", "23400");
		policyData.put("VehicelDisplayName", "Toyota Avensis 2013");
		
		//Policy Info
		policyData.put("PhoneNumber", "650-333-3333");
		
		//Payment Details
		policyData.put("PaymentPlan", "Weekly");
		policyData.put("AccountNumber", "123445");
		policyData.put("RoutingNumber", "234555");
		policyData.put("BankName", "AIB");
		policyData.put("CreditCardNumber", "123456211212121");
		policyData.put("ExpMonth", "July");
		policyData.put("ExpYear", "2019");

		return policyData;
	}

	public static HashMap<String, String> getCPAndBOPTestData()
	{

		HashMap<String, String> policyData = new HashMap<>();

		//Account Policy Details
		policyData.put("OrganizationType", "Common ownership");
		policyData.put("FirstName", "COMMERCIALPROPERTYLINE");
		policyData.put("LastName", "House");
		policyData.put("AccountNumber", "Oren Hiller 3");
		policyData.put("AddressLine1", "Launch Pad");
		policyData.put("City", "Ksc");
		policyData.put("Zip", "94404");
		policyData.put("State", "California");
		policyData.put("DOB", "12/05/1986");
		policyData.put("PastEffectiveDate", "07/07/2015");
		policyData.put("CoverageDate", "07/07/2017");
		policyData.put("SmallBusinessType", "Apartment");

		policyData.put("NewOrganizationType", "LLC");
		policyData.put("NewSmallBusinessType", "Motel");

		//Your Info for QB BOP

		policyData.put("ZipCode", "94404");
		policyData.put("CompanyName", "SampleCompany");
		policyData.put("DOB", "12/11/1980");
		policyData.put("AddressLine1", "MounJoy Square");
		policyData.put("AddressLine2", "City Center");
		policyData.put("AddressLine3", "Dublin 1");
		policyData.put("City", "Dublin");
		policyData.put("State", "California");
		policyData.put("StateValue", "CA");
		policyData.put("Email", "dh@gmail.com");
		policyData.put("QuoteReferenceNumber", "12345678");
		policyData.put("Quote_Cov_Date", DateUtil.getCurrentDateMMDDYYYY());
		policyData.put("OrganizationTypeQB", "LLC" );
		policyData.put("SmallBusinessTypeQB", "Wholesaler");
		policyData.put("InsuredValueNew", "333.00");

			//Qualifications
		policyData.put("PolicyDeclineStatus", "No");

		//General Coverages
		policyData.put("LimitsOccurence", "1000/2000/2000");
		policyData.put("ContractorToolsDesc", "NewContractorTool");
		policyData.put("InsuredValue", "123.00");
		policyData.put("ContractorToolsDescNew", "AnotherContractorTool");
		policyData.put("InsuredValueNew", "333.00");

		//Locations&Buildings
		policyData.put("BuildingDescription", "New Building");
		policyData.put("CPPropertyClassCode", "0001: Boarding and Lodging Houses, Rooming Houses, Fraternities and Sororities - Up to 10 Units");
		policyData.put("BOPPropertyClassCode", "0001: Restaurant-Fast Food - Cafes");
		policyData.put("BasisAmount", "222222");
		policyData.put("YearBuilt", "2000");
		policyData.put("ConstructionType", "Frame");
		policyData.put("NoOfStories", "2");
		policyData.put("TotalArea", "10000");
		policyData.put("Sprinklered", "20%");
		policyData.put("Exposure", "20");
		policyData.put("HasAlarm", "Yes");
		policyData.put("AlarmType", "Local");
		policyData.put("LocAddressLine1", "12");
		policyData.put("LocAddressLine2", "New Square");
		policyData.put("LocAddressLine3", "New Street");
		policyData.put("LocationCity", "SF");
		policyData.put("LocationState", "California");
		policyData.put("LocationZipcode", "94404");
		policyData.put("LocationCode", "09");
		policyData.put("LocationPhone", "9999999999");
		policyData.put("FireProtection", "Superior");
		policyData.put("AddressHeader", "12, SF, CA");

		policyData.put("NewBuildingDescription", "BuildingABC");
		policyData.put("NewCPPropertyClassCode", "0002: Boarding and Lodging Houses, Rooming Houses, Fraternities and Sororities - 11 to 30 Units");
		policyData.put("NewBOPPropertyClassCode", "0001: Restaurant-Fast Food - Cafes");
		policyData.put("NewBasisAmount", "8888");
		policyData.put("NewYearBuilt", "2014");
		policyData.put("NewConstructionType", "Frame");
		policyData.put("NewNoOfStories", "5");
		policyData.put("NewTotalArea", "8888");
		policyData.put("NewSprinklered", "80%");
		policyData.put("NewExposure", "99");
		policyData.put("NewHasAlarm", "No");
		policyData.put("NewLocAddressLine1", "89");
		policyData.put("NewLocAddressLine2", "Mid Street");
		policyData.put("NewLocAddressLine3", "Mid Square");
		policyData.put("NewLocationCity", "LA");
		policyData.put("NewLocationState", "Colorado");
		policyData.put("NewLocationZipcode", "94404");
		policyData.put("NewLocationCode", "13");
		policyData.put("NewLocationPhone", "8888888888");
		policyData.put("NewFireProtection", "Standard");
		policyData.put("NewAddressHeader", "89, LA, CO");
		policyData.put("AddressHeader", "12, SF, CA");

		//Coverage Details
		policyData.put("LimitCoverage", "555");
		policyData.put("BuildingLimit", "666");
		policyData.put("NewBuildingLimit", "111");
		policyData.put("PersonalPropertyLimit", "777");
		policyData.put("BuildingIncrease", "4%");
		policyData.put("ValuationMethod", "Actual cash value");
		policyData.put("Coinsurance", "100%");
		policyData.put("TenantsLiability", "55555");
		policyData.put("EmployeeDishonestyLimit", "100,000");
		policyData.put("NumberOfCoveredEmployees", "50");
		policyData.put("NumberOfCoveredLocations", "60");
		policyData.put("GuestPropSafeDepositLimit", "250,000");

		//Policy Info
		policyData.put("Phone", "650-333-3333");
		policyData.put("Email", "abc@ab.cd");


		//Payment Details
		policyData.put("PaymentPlan", "Monthly 10");
		policyData.put("RoutingNumber", "234555");
		policyData.put("BankName", "AIB");
		policyData.put("PaymentMethodBank", "Bank Account");
		policyData.put("PaymentMethodCredit", "Credit Card");
		policyData.put("CreditCardNumber", "123456211212121");
		policyData.put("ExpirationMonth", "July");
		policyData.put("ExpirationYear", "2017");

		return policyData;
	}
	
	public static void main(String[] args) {
		
	HashMap<String, String> policyData = new HashMap<>();
		
		//Your Info
		policyData.put("ZipCode", "90211");
		policyData.put("FirstName", "Dharmesh");
		policyData.put("LastName", "Gangwar");
		
		System.out.println(policyData.toString());
		policyData.putAll(getHomeOwnerTestData());
		System.out.println(policyData.toString());
		
	}
	

}
