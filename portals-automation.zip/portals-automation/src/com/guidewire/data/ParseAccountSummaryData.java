package com.guidewire.data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.DateUtil;

import io.restassured.path.json.JsonPath;

public class ParseAccountSummaryData {

    private static HashMap<String, String> data = ThreadLocalObject.getData();

    public static HashMap<String, String> getAccountSummaryDataFromBackEnd(String jsonData) throws Exception {
        HashMap<String, String> info = new HashMap<>();

        JsonPath path = new JsonPath(jsonData);

        String accountHolderName = DataFormatUtil.getNodeValue(path, "account", "accountHolder.displayName");
        String accountHolderNumber = DataFormatUtil.getNodeValue(path, "account", "accountNumber");

        DataFormatUtil.putData(info, AccountData.ACCOUNT_NAME.getValue(), accountHolderName);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_NUMBER.getValue(), accountHolderNumber);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TITLE.getValue(),accountHolderName+" ("+accountHolderNumber +")" );
        String addressLine = DataFormatUtil.getNodeValue(path, "account", "accountHolder.primaryAddress.displayName");
        String phoneNumber = DataFormatUtil.getNodeValue(path, "account", "accountHolder.cellNumber");
        String formattedPhoneNumber = phoneNumber.substring(0,3)+"-"+phoneNumber.substring(3,6)+"-"+phoneNumber.substring(6,10);
        String fullAddress=accountHolderName+" "+addressLine+" "+formattedPhoneNumber;
        DataFormatUtil.putData(info, AccountData.ACCOUNT_ADDRESS.getValue(), fullAddress);
        String accountHolderProducerCodeBackend = DataFormatUtil.getNodeValue(path, "account", "producerCodes.displayValue");
        String producerCode="Producer Code(s) "+accountHolderProducerCodeBackend.replace("[", "").replace("]","");
        DataFormatUtil.putData(info, AccountData.ACCOUNT_PRODUCER_CODE.getValue(), producerCode);
        JsonPath accountDetailsPath = new JsonPath(DataFetch.getAccountDetails(accountHolderNumber));
        String numberOfOpenPolicyRenewals = accountDetailsPath.get("numberOfOpenPolicyRenewals").toString() +" Open Renewals ";
        String numberOfOpenPolicyCancellations = accountDetailsPath.get("numberOfOpenPolicyCancellations").toString()+" Open Cancellations ";
        String numberOfOpenPolicyChanges = accountDetailsPath.get("numberOfOpenPolicyChanges").toString()+ " Open Changes";
        String openChanges = numberOfOpenPolicyRenewals+numberOfOpenPolicyCancellations+numberOfOpenPolicyChanges;
        DataFormatUtil.putData(info, AccountData.ACCOUNT_OPEN_CHANGES.getValue(), openChanges);
        String accountStatusBackend= DataFormatUtil.getNodeValue(path, "account", "accountCreatedDate");
        DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        DateFormat targetFormat = new SimpleDateFormat("MMMM d, yyyy");
        Date date = originalFormat.parse(accountStatusBackend);
        String formattedDateOfCustomerSince = targetFormat.format(date);
        String accountStatus = DataFormatUtil.getNodeValue(path, "account", "statusDisplayName");
        accountStatusBackend = "Customer Since "+formattedDateOfCustomerSince+" Account Status "+accountStatus;
        DataFormatUtil.putData(info, AccountData.ACCOUNT_CUSTOMER_STATUS.getValue(), accountStatusBackend);

        String premiumBackend = DataFormatUtil.getNodeValue(path, "account", "policySummaries.premium.amount");
        float p = Float.parseFloat(premiumBackend.replace("[","").replace("]",""));
        premiumBackend= String.format("%.2f", p);
        premiumBackend = "$"+premiumBackend+" Total Issued Premium";

        DataFormatUtil.putData(info, AccountData.ACCOUNT_TOTAL_ISSUED_PREMIUM.getValue(), premiumBackend);
        String numberOfOpenActivities = "OPEN ACTIVITIES "+ accountDetailsPath.get("numberOfOpenActivities").toString();
        String numberOfOpenQuotes = "OPEN QUOTES "+ accountDetailsPath.get("numberOfOpenQuotes").toString();
        String numberOfOpenClaims = "CLAIMS "+ accountDetailsPath.get("numberOfOpenClaims").toString();
        String billing = "BILLING & PAYMENT";
        String automatic_payment = "AUTOMATIC PAYMENTS";
        String summary = "SUMMARY";
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_OPEN_ACTIVITIES.getValue(), numberOfOpenActivities);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_OPEN_QUOTES.getValue(), numberOfOpenQuotes);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_CLAIMS.getValue(), numberOfOpenClaims);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_SUMMARY.getValue(), summary);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_BILLING.getValue(), billing);
        DataFormatUtil.putData(info, AccountData.ACCOUNT_TILE_AUTOMATIC_PAYMENT.getValue(), automatic_payment);
        return info;
    }


    public static HashMap<String,  List<String>> getAccountSummaryDataFromBackEndList(String jsonData) throws Exception {
        HashMap<String, String> info = new HashMap<>();
        JsonPath path = new JsonPath(jsonData);
        String accountHolderName = DataFormatUtil.getNodeValue(path, "account", "accountHolder.displayName");
        String accountHolderNumber = DataFormatUtil.getNodeValue(path, "account", "accountNumber");
        JsonPath accountDetailsPath = new JsonPath(DataFetch.getAccountDetails(accountHolderNumber));
        List<String> displayStatusList = accountDetailsPath.getList("policySummaries.displayStatus");
        List<String> policyNumbers = accountDetailsPath.getList("policySummaries.policyNumber");
        List<String> primaryInsuredNameList = accountDetailsPath.getList("policySummaries.primaryInsuredName");
        List<String> effectiveDateList = convertDate(accountDetailsPath.getList("policySummaries.effective"));
        List<String> expirationList = convertDate(accountDetailsPath.getList("policySummaries.expiration"));
        HashMap<String, List<String>> infoList = new HashMap<>();
        DataFormatUtil.putData(infoList, AccountData.ACCOUNT_ISSUED_POLICIES_DISPLAY_STATUS.getValue(), displayStatusList);
        DataFormatUtil.putData(infoList, AccountData.ACCOUNT_ISSUED_POLICIES_POLICY_NUMBER.getValue(), policyNumbers);
        DataFormatUtil.putData(infoList, AccountData.ACCOUNT_ISSUED_POLICIES_NAMED_INSURED.getValue(), primaryInsuredNameList);
        DataFormatUtil.putData(infoList, AccountData.ACCOUNT_ISSUED_POLICIES_EFFECTIVE_DATE.getValue(), effectiveDateList);
        DataFormatUtil.putData(infoList, AccountData.ACCOUNT_ISSUED_POLICIES_EXPIRATION_DATE.getValue(), expirationList);
        return infoList;
    }


   private static String convertDateString(String originalDate) throws Exception{
        DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        DateFormat targetFormat = new SimpleDateFormat("M/d/yy");
        Date date = originalFormat.parse(originalDate);
        String newFormattedDate = targetFormat.format(date);
        return newFormattedDate;
    }


   private static List<String>  convertDate(List<String> changeList) throws Exception{
        List<String> newConvertedDateList = new ArrayList<String>();

        for(int i=0;i<changeList.size();i++){
            newConvertedDateList.add(i, convertDateString(changeList.get(i)));
        }

        return newConvertedDateList;
    }




}
