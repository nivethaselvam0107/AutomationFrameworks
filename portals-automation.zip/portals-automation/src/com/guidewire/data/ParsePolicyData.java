package com.guidewire.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;

import io.restassured.path.json.JsonPath;

public class ParsePolicyData {

    public static String getTotalPremiumData(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String totalPremium = Float.toString(path.getFloat("lobs.personalAuto.totalPremium.amount"));
        return totalPremium;
    }

    public static String getContactDetails(String jsonData) {
        JsonPath path = new JsonPath(jsonData);
        String displayName = path.getString("contacts[0].contact.displayName");
        String cellNumber = path.getString("contacts[0].contact.cellNumber");
        return displayName + "," + cellNumber.substring(0, 3) + '-' + cellNumber.substring(3, 6) + '-' + cellNumber.substring(6);
    }

    public static String getInsuredAddressLine1(String jsonData) {
        String addressLine1;
        JsonPath path = new JsonPath(jsonData);
        String filterContact = path.getString("currentPeriod.contacts.contactRole");
        if(filterContact.contains("Named Insured")){
            addressLine1 = path.getString("currentPeriod.contacts[0].contact.primaryAddress.displayName");
        }
        else addressLine1 = path.getString("currentPeriod.contacts[1].contact.primaryAddress.displayName");
        return addressLine1.substring(0,25);
    }

    public static List<HashMap<String, String>> getPolicyDocumentDataFromBackEnd(String jsonData) {
        ArrayList allDocs = new ArrayList();
        JsonPath path = new JsonPath(jsonData);
        int docCount = path.getList("currentPeriod.documentDTOs").size();
        for(int i = 0; i < docCount; ++i) {
            HashMap singleDoc = new HashMap();
            DataFormatUtil.putData(singleDoc, "DOC_NAME", DataFormatUtil.getNodeValue(path, "currentPeriod.documentDTOs[" + i + "]", "name").toLowerCase());
            allDocs.add(singleDoc);
        }
        return allDocs;
    }

    public static HashMap<String,String> getBOPolicyLineCoverages(String jsonData) {
        HashMap<String, String> data = ThreadLocalObject.getData();
        JsonPath path = new JsonPath(jsonData);
        String lineGenCoveIteration = "coverables";
        int baseCovCount = path.getList(lineGenCoveIteration).size();
        HashMap<String, String> lineCoverage = new HashMap();
        for (int i = 0; i < baseCovCount; i++) {

            String covItr = lineGenCoveIteration + "[" + i + "]";

            // BOP General Coverage - For Businessowners Line
            if(DataFormatUtil.getNodeValue(path, covItr , "name").equals("Businessowners Line")) {
                int bopCovCount = new JsonPath(jsonData).getList(covItr +".coverages").size();
                // BOP General Coverage - For Employee Dishonesty within Businessowners Line coverable
                for(int j=0; j<bopCovCount; j++) {
                    String newCovItr = covItr + ".coverages["+j+"]";
                    if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Employee Dishonesty")) {
                        DataFormatUtil.putData(lineCoverage, "Employee_Dishonesty_Selected", "true");
                        DataFormatUtil.putData(lineCoverage, "Employee_Dishonesty_Limit", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[0]", "amount"));
                        DataFormatUtil.putData(lineCoverage, "No_Covered_Employees", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[1]", "amount"));
                        DataFormatUtil.putData(lineCoverage, "No_Covered_Locations", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[2]", "amount"));

                    }
                    else if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Guests Property In Safe Deposit")) {
                        DataFormatUtil.putData(lineCoverage, "Guest_Prop_Safe_deposit_Selected", "true");
                        DataFormatUtil.putData(lineCoverage, "Guest_Prop_Safe_deposit_Limit", DataFormatUtil.getNodeValue(path, newCovItr +".terms[0]", "amount"));
                    }
                    else {
                        DataFormatUtil.putData(lineCoverage, "Employee_Dishonesty_Selected", "false");
                        DataFormatUtil.putData(lineCoverage, "Guest_Prop_Safe_deposit_Selected", "false");
                    }
                 }
            }
            // For new building coverages
            else if (DataFormatUtil.getNodeValue(path, covItr, "name").split(": ")[1].equals(data.get("NewBuildingDescription"))){
                DataFormatUtil.putData(lineCoverage, "Building_Description_Present", "true");
                int buildingCovCount = new JsonPath(jsonData).getList(covItr +".coverages").size();
                // BOP Buildings - For different coverages on Building
                for(int j=0; j<buildingCovCount; j++) {
                    String newCovItr = covItr + ".coverages[" + j + "]";
                    if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Business Personal Property"))
                        DataFormatUtil.putData(lineCoverage, "Business_Personal_Property_Limit", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[0]", "amount"));
                    else if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Building"))
                        DataFormatUtil.putData(lineCoverage, "Building_Limit", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[1]", "amount"));
                }
            }
            else if(DataFormatUtil.getNodeValue(path, covItr, "name").split(": ")[1].equals(data.get("NewAddressHeader").replace(",",""))){
                DataFormatUtil.putData(lineCoverage, "New_Location", DataFormatUtil.getNodeValue(path, covItr, "name").split(": ")[1]);
            }
            else {
                DataFormatUtil.putData(lineCoverage, "Building_Description_Present", "false");
            }
        }
        return lineCoverage;
    }

    public static HashMap<String,String> getCPPolicyLineCoverages(String jsonData) {
        HashMap<String, String> data = ThreadLocalObject.getData();
        JsonPath path = new JsonPath(jsonData);
        String lineGenCoveIteration = "coverables";
        int baseCovCount = path.getList(lineGenCoveIteration).size();
        HashMap<String, String> lineCoverage = new HashMap();

        for (int i = 0; i < baseCovCount; i++) {

            String covItr = lineGenCoveIteration + "[" + i + "]";
            // CP Coverables
            if (DataFormatUtil.getNodeValue(path, covItr, "name").contains(data.get("NewBuildingDescription"))){
                DataFormatUtil.putData(lineCoverage, "Building_Description_Present", "true");
                int buildingCovCount = new JsonPath(jsonData).getList(covItr +".coverages").size();
                // CP Building - Coverages on the building
                for(int j=0; j<buildingCovCount; j++) {
                    String newCovItr = covItr + ".coverages[" + j + "]";
                    if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Business Personal Property Coverage"))
                        DataFormatUtil.putData(lineCoverage, "Business_Personal_Property_Limit", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[0]", "amount"));
                    else if (DataFormatUtil.getNodeValue(path, newCovItr, "name").equals("Building Coverage"))
                        DataFormatUtil.putData(lineCoverage, "Building_Limit", DataFormatUtil.getNodeValue(path, newCovItr + ".terms[2]", "amount"));
                }
            }
            else if(DataFormatUtil.getNodeValue(path, covItr, "name").contains(data.get("NewAddressHeader").replace(",",""))){
                DataFormatUtil.putData(lineCoverage, "New_Location", DataFormatUtil.getNodeValue(path, covItr, "name").split(": ")[1]);
            }
            else if(!lineCoverage.containsKey("Building_Description_Present"))
                    DataFormatUtil.putData(lineCoverage, "Building_Description_Present", "false");
        }
        return lineCoverage;
    }

    public static VendorDto parseVendor(String jsonData) {
        VendorDto dto = new VendorDto();
        JsonPath path = new JsonPath(jsonData);

        dto.PublicID = path.getString("primaryAddress.publicID");
        dto.VendorName = path.getString("vendorName");
        dto.Email = path.getString("email");
        dto.Phone = path.getString("phone");
        dto.Score = Long.valueOf(path.getString("score"));
        dto.Address = path.getString("primaryAddress.displayName");
        dto.Latitude = path.getString("geocode.latitude");
        dto.Longitude = path.getString("geocode.longitude");
        dto.AddressBookID = path.getString("addressBookUID");

        return dto;
    }
}
