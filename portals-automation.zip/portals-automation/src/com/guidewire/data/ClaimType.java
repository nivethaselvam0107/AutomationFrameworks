package com.guidewire.data;

public final class ClaimType {

    public static final String typeName = "ClaimType";


    public enum Lob {
        PA("PersonalAuto"),
        HO("HomeOwner"),
        HOP("HOP"),
        GL("GeneralLiability"),
        IM("InlandMarine"),
        WC("WorkersComp"),
        BO("BusinessOwners"),
        BA("BusinessAuto"),
        CP("CommercialProperty");

        private final String lineOfBusiness;

        Lob (final String lineOfBusiness) {
            this.lineOfBusiness = lineOfBusiness;
        }

        @Override
        public String toString() {
            return this.lineOfBusiness;
        }
    }

    public enum Line {
        PA("PersonalAutoLine"),
        HO("HomeownersLine_HOE"),
        HOP("HOPLine"),
        GL("GeneralLiabilityLine"),
        IM("InlandMarineLine"),
        WC("WorkersCompLine"),
        BO("BusinessOwnersLine"),
        BA("BusinessAutoLine"),
        CP("CommercialPropertyLine");

        private final String policyLine;

        Line (final String policyLine) {
            this.policyLine = policyLine;
        }

        @Override
        public String toString() {
            return this.policyLine;
        }
    }

    public static final class Type {

        final Lob LOB;
        final Line LINE;

        Type (Lob lob, Line line) {
            this.LOB = lob;
            this.LINE = line;
        }

        public String lob() {
            return this.LOB.toString();
        }

        public String line() {
            return this.LINE.toString();
        }

        @Override
        public String toString() {
            return this.LOB.toString();
        }
    }

    public static final Type PA = new Type(Lob.PA, Line.PA);
    public static final Type HOP = new Type(Lob.HOP, Line.HOP);
    public static final Type HO = new Type(Lob.HO, Line.HO);
    public static final Type GL = new Type(Lob.GL, Line.GL);
    public static final Type IM = new Type(Lob.IM, Line.IM);
    public static final Type WC = new Type(Lob.WC, Line.WC);
    public static final Type BO = new Type(Lob.BO, Line.BO);
    public static final Type BA = new Type(Lob.BA, Line.BA);
    public static final Type CP = new Type(Lob.CP, Line.CP);
}
