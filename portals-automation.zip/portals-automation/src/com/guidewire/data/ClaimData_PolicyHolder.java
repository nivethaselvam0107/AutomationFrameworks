package com.guidewire.data;

import java.util.HashMap;
import java.util.UUID;

public class ClaimData_PolicyHolder {
	
	
	public static HashMap<String, String> getPAClaimTestData_Emerald()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<String, String>();
		
		claimData.put("POLICY_NUM", "2163653812");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Alice Jones");
		claimData.put("VehicleDamaged", "Honda Civic 2000");
		claimData.put("DriverInvolved", "Alice Jones");
		claimData.put("VehicleColor", "Green");
		claimData.put("Make", "Honda");
		claimData.put("Model", "Civic");
		claimData.put("VehicleYear", "2000");
		claimData.put("DRIVER_DISPLAY_NAME", "Alice Jones");
		claimData.put("DRIVER_ADDRESS_DISPLAY_NAME", "4 Main Street, Foster City, CA 94404");
		claimData.put("EXISTING_PASSENGER", "Alice Jones");
		claimData.put("EXISTING_CONTACT", "Alice Jones");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "4 Main Street, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Alice Jones");
		claimData.put("GlassDamageVehicle", "Honda Civic 2000");
		claimData.putAll(getPAClaimCommonData());
		return claimData;
	}
	
	public static HashMap<String, String> getPAClaimTestData_Diamond()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<>();
		
		claimData.put("POLICY_NUM", "7807419803");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Mary Murphy");
		claimData.put("VehicleDamaged", "Mazda MPV 2001");
		claimData.put("DriverInvolved", "Mary Murphy");
		claimData.put("VehicleColor", "Green");
		claimData.put("Make", "Acura");
		claimData.put("Model", "RL");
		claimData.put("VehicleYear", "2004");
		claimData.put("DRIVER_DISPLAY_NAME", "Mary Murphy");
		claimData.put("DRIVER_ADDRESS_DISPLAY_NAME", "1 Main Street, 1 Main Street, Foster City, CA 94404");
		claimData.put("EXISTING_PASSENGER", "Mary Murphy");
		claimData.put("EXISTING_CONTACT", "Mary Murphy");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "1 Main Street, 1 Main Street, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Mary Murphy");
		claimData.put("GlassDamageVehicle", "Acura RL 2004");
		claimData.putAll(getPAClaimCommonData());
		return claimData;
	}
	
	public static HashMap<String, String> getPAClaimTestData_Ferrite()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<>();
		
		claimData.put("POLICY_NUM", "4736609295");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Mark Murphy");
		claimData.put("VehicleDamaged", "Acura RSX 2001");
		claimData.put("DriverInvolved", "Mark Murphy");
		claimData.put("VehicleColor", "Red");
		claimData.put("Make", "Acura");
		claimData.put("Model", "RSX");
		claimData.put("VehicleYear", "2001");
		claimData.put("DRIVER_DISPLAY_NAME", "Mark Murphy");
		claimData.put("DRIVER_ADDRESS_DISPLAY_NAME", "1 Dame Street, Ladyswell, Foster City, CA 94404");
		claimData.put("EXISTING_PASSENGER", "Mark Murphy");
		claimData.put("EXISTING_CONTACT", "Mark Murphy");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "1 Dame Street, Ladyswell, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Mark Murphy");
		claimData.put("GlassDamageVehicle", "Acura RSX 2001");
		claimData.putAll(getPAClaimCommonData());
		return claimData;
	}
	
	public static HashMap<String, String> getPAClaimTestData_Ferrite9_1()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<String, String>();
		
		claimData.put("POLICY_NUM", "4176215947");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Mark Murphy");
		claimData.put("DriverInvolved", "Mark Murphy");
		claimData.put("VehicleColor", "Tan");
		claimData.put("Make", "Chevrolet");
		claimData.put("Model", "Impala");
		claimData.put("VehicleYear", "2005");
		claimData.put("DRIVER_DISPLAY_NAME", "Mark Murphy");
		claimData.put("DRIVER_ADDRESS_DISPLAY_NAME", "Route 99, 101 Highway, Palo Alto, Foster City, CA 94404");
		claimData.put("EXISTING_PASSENGER", "Mark Murphy");
		claimData.put("EXISTING_CONTACT", "Mark Murphy");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "Route 99, 101 Highway, Palo Alto, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Mark Murphy");
		claimData.put("GlassDamageVehicle", "Chevrolet Impala 2005");
		claimData.putAll(getPAClaimCommonData());
		return claimData;
	}
	
	public static HashMap<String, String> getHOClaimTestData_Emerald()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<>();
		
		claimData.put("POLICY_NUM", "8994695932");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Robert Fowler");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "4 Main Street, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Robert Fowler");
		claimData.put("INSURED_DISPLAY_NAME", "Robert Fowler");
		claimData.putAll(getHOClaimCommonTestData());
		return claimData;
	}
	
	public static HashMap<String, String> getHOClaimCommonTestData()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<>();
		claimData.put("POLICY_TYPE", "HomeOwner");
		claimData.put("DamageType", "Fire");
		claimData.put("FireCause", "Electric circuit");
		claimData.put("FireDiscovery", "SmokeVisibility");
		claimData.put("HomeHabitable", "true");
		claimData.put("HomeSecure", "true");
		claimData.put("FireDiscovery", "FireOtherDetails");
		
		claimData.put("WaterDamageType", "Mold");
		claimData.put("WaterDamageSource", "Plumbing");
		claimData.put("ROOF_FIXED", "No");
		claimData.put("WaterTurnOff", "No");
		claimData.put("LOSS_DESC", "Claim is needed for damage");
		
		claimData.put("CrimeDamageType", "Burglary");
		claimData.put("CrimeDescription", "Crime is done");
		claimData.put("WaterOtherDetails", "WaterOtherDetails");
		
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Ted Smith");

		claimData.put("FirstNameNewPerson", "FirstNameNewPerson");
		claimData.put("LastNameNewPerson", "LastNameNewPerson");
		claimData.put("NewPersonHomePhone", "234-543-2345");
		claimData.put("NewPersonInvolvementWitness", "Witness");
		claimData.put("NewPersonInvolvementOther", "Other");
		claimData.put("NewPersonInjured", "false");
		claimData.put("NEW_PERSON_DISPLAY_NAME", "FirstNameNewPerson LastNameNewPerson");
		claimData.put("WITNESS_DISPLAY_NAME", "FirstNameNewPerson LastNameNewPerson");
		claimData.put("WITNESS_CONTACT_NUM", "234-543-2345");
		
		claimData.put("FirstNameNewContact", "FirstNameNewContact");
		claimData.put("LastNameNewContact", "LastNameNewContact");
		claimData.put("HomePhoneNewContact", "234-543-2345");
		claimData.put("WorkPhoneNewContact", "334-543-2345");
		claimData.put("CellPhoneNewContact", "434-543-2345");
		claimData.put("AddLine1NewContact", "AddLine1");
		claimData.put("AddLine2NewContact", "AddLine2");
		claimData.put("AddLine3NewContact", "AddLine3");
		claimData.put("CityNewContact", "Foster City");
		claimData.put("StateNewContact", "California");
		claimData.put("StateValueNewContact", "CA");
		
		claimData.put("FirstNameNewPerson", "FirstNameNewPerson");
		claimData.put("LastNameNewPerson", "LastNameNewPerson");
		claimData.put("NewPersonHomePhone", "234-543-2345");
		claimData.put("NewPersonInvolvementWitness", "Witness");
		claimData.put("NewPersonInvolvementOther", "Other");
		claimData.put("NewPersonInjured", "Yes");
		claimData.put("INJURED_DISPLAY_NAME", "FirstNameNewPerson LastNameNewPerson");
		claimData.put("INJURED_CONTACT_NUM", "2345432345");
		
		claimData.put("FirstNameNewContact", "FirstNameNewContact");
		claimData.put("LastNameNewContact", "LastNameNewContact");
		claimData.put("HomePhoneNewContact", "234-543-2345");
		claimData.put("WorkPhoneNewContact", "334-543-2345");
		claimData.put("CellPhoneNewContact", "434-543-2345");
		claimData.put("AddLine1NewContact", "AddLine1");
		claimData.put("AddLine2NewContact", "AddLine2");
		claimData.put("AddLine3NewContact", "AddLine3");
		claimData.put("CityNewContact", "Foster City");
		claimData.put("StateNewContact", "California");
		claimData.put("ZipNewContact", "94404");
		claimData.put("StateValueNewContact", "CA");
		claimData.put("EmailNewContact", "mnp@gmail.com");
		return claimData;
	}

	public static HashMap<String, String> getWCClaimTestData() {
		HashMap<String, String> claimData = new HashMap<>();

		claimData.put("AddressLine1", "911 Catamaran st.");
		claimData.put("City", "Foster City");
		claimData.put("Zip", "94404");
		claimData.put("State", "California");
		claimData.put("InjuryType", "No Physical Injury");
		claimData.put("InjuryDesc", "Injury Description");

		return claimData;
	}
	
	public static HashMap<String, String> getHOClaimTestData_Ferrite()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<>();
		
		claimData.put("POLICY_NUM", "6047736107");
		claimData.put("CLAIM_REPORTER_DISPLAY_NAME", "Mark Murphy");
		claimData.put("MAIN_CONTACT_DISPLAY_ADDRESS", "1 Dame Street, Ladyswell, Foster City, CA 94404");
		claimData.put("MAIN_CONTACT_DISPLAY_NAME", "Mark Murphy");
		claimData.put("INSURED_DISPLAY_NAME", "Mark Murphy");
		claimData.putAll(getHOClaimCommonTestData());
		return claimData;
	}
	
	public static HashMap<String, String> getPAClaimCommonData()
	{
		//Your Info
		HashMap<String, String> claimData = new HashMap<String, String>();
		claimData.put("POLICY_TYPE", "Personal Auto");
		claimData.put("ClaimType", "Collision");
		claimData.put("ClaimSubType", "Collision");
		claimData.put("ClaimTypeCollision", "Collision with motor vehicle");
		claimData.put("CollisionTypeOccured", "Collision");
		claimData.put("ClaimTypeTheft", "Theft");
		claimData.put("ClaimTypeGlass", "Glass");
		claimData.put("ClaimTypeOther", "Other");
		claimData.put("AddLine1", "AddLine1");
		claimData.put("AddLine2", "AddLine2");
		claimData.put("AddLine3", "AddLine3");
		claimData.put("City", "Foster City");
		claimData.put("State", "California");
		claimData.put("StateValue", "CA");
		claimData.put("ZipCode", "94404");
		claimData.put("WithPropDamage", "WithPropDamage");
		claimData.put("LOSS_DESC", "WhatHappened");
		claimData.put("LOSS_LOCATION_DISPLAY_NAME", "AddLine1 AddLine2 AddLine3 Foster City CA 94404");
		claimData.put("LossLocationInput", "Exact");
		
		claimData.put("VehicleColor", "Green");
		claimData.put("VIN", "2");
		claimData.put("LicensePlate", "A1AA1A");
		claimData.put("VehicleState", "California");
		claimData.put("VehicleStateValue", "CA");
		claimData.put("VehicelDisplayName", "deer erewr 2002");
		claimData.put("DRIVER_CONTACT_NUM", "2345432345");
		
		claimData.put("NewDriverFirstName", "NewDriverFirst");
		claimData.put("NewDriverLastName", "NewDriverLast");
		claimData.put("NewDriverHomePhone", "234-543-2345");
		
		claimData.put("SAFE_TO_DRIVE", "true");
		claimData.put("AIRBAG_DEPLOYED", "true");
		claimData.put("EQUIP_FAIL", "true");
		claimData.put("VEH_TOWED", "true");
		claimData.put("VEH_RENTAL", "true");
		claimData.put("COLLISION_POINT_HOOD", "frontLeftDoor");
		claimData.put("VEH_COLLISION_POINT_VALUE", "06");
		
		claimData.put("FirstNamePassenger1", "FirstNamePassenger1");
		claimData.put("LastNamePassenger1", "LastNamePassenger1");
		claimData.put("PassengerHomePhone", "2345432345");
		claimData.put("PASSENGER_DISPLAY_NAME", "FirstNamePassenger1 LastNamePassenger1");
		claimData.put("PASSENGER_CONTACT_NUM", "234-543-2345");
		claimData.put("PASSENGER_ADDRESS_DISPLAY_NAME", "");
		
		//Express Auto
		claimData.put("VendorName", "Express Auto");
		claimData.put("Vendor1Address", "8982 Merrydale Dr, San Francisco, CA 94104");
		claimData.put("Vendor1PhoneNum", "209-234-8728");
		claimData.put("Vendor1FaxNumber", "209-234-8727");
		claimData.put("Vendor1Email", "service@expressauto.com");
		
		claimData.put("FirstNameNewPerson", "FirstNameNewPerson");
		claimData.put("LastNameNewPerson", "LastNameNewPerson");
		claimData.put("NewPersonHomePhone", "234-543-2345");
		claimData.put("NewPersonInvolvementWitness", "Witness");
		claimData.put("NewPersonInvolvementOther", "Other");
		claimData.put("NewPersonInjured", "Yes");
		claimData.put("NEW_PERSON_DISPLAY_NAME", "FirstNameNewPerson LastNameNewPerson");
		claimData.put("WITNESS_DISPLAY_NAME", "FirstNameNewPerson LastNameNewPerson");
		claimData.put("WITNESS_CONTACT_NUM", "234-543-2345");
		
		claimData.put("FirstNameNewContact", "FirstName");
		claimData.put("LastNameNewContact", "LastName");
		claimData.put("HomePhoneNewContact", "234-543-2345");
		claimData.put("WorkPhoneNewContact", "334-543-2345");
		claimData.put("CellPhoneNewContact", "434-543-2345");
		claimData.put("AddLine1NewContact", "AddLine1");
		claimData.put("AddLine2NewContact", "AddLine2");
		claimData.put("AddLine3NewContact", "AddLine3");
		claimData.put("CityNewContact", "Foster City");
		claimData.put("StateNewContact", "California");
		claimData.put("ZipNewContact", "94404");
		claimData.put("StateValueNewContact", "CA");
		claimData.put("NewContactDisplay", "FirstName LastName");
		claimData.put("EmailNewContact", "mnp@gmail.com");    
		
		claimData.put("TheftType", "AudioStolen");
		claimData.put("NoteBody", "NoteBody");
		claimData.put("NoteSubject", UUID.randomUUID().toString());
		claimData.put("DocType", "PNG");
		//VehicleCoverageData for policy 54-123456
		claimData.put("VEHICLE_MAKE1", "NoteSubject");
		
		return claimData;
	}
	
	
	public static void main(String[] args) {
		
	HashMap<String, String> claimData = new HashMap<>();
		System.out.println(claimData.toString());
	}
	

}
