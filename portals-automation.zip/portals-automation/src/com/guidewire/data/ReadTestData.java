package com.guidewire.data;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.capabilities.endorsement.fixtures.data.RandomEndorsementData;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;

public class ReadTestData extends CommonScenario {

	private static final Logger LOGGER = Logger.getLogger(ReadTestData.class);

	private static HashMap<String, String> getTestCaseData(String testName, String suiteName) {
		try {
			String userDirec = System.getProperty("user.dir");
			InputStream is = new FileInputStream(userDirec + "/resources/testData/" + suiteName + ".yml");

			ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
			TypeReference<HashMap<String,HashMap<String, String>>> typeRef = new TypeReference<HashMap<String, HashMap<String, String>>>() {};
			HashMap<String,HashMap<String, String>> data = mapper.readValue(is, typeRef);
			return data.get(testName);
		} catch (IOException e) {
			e.printStackTrace();
			return new HashMap<>();
		}
	}

	public static Map<String, String> getTestData(String testCaseName) {
		String suiteName = ThreadLocalObject.getData().get("Suite");
		String suiteDataFileName = getSuiteDataFileName(suiteName);
		return getTestData(testCaseName, suiteDataFileName);
	}

	public static HashMap<String, String> getTestData(String testCaseName, String suiteName)
	{
		System.out.println(testCaseName + " " + suiteName);
		HashMap<String, String> testDataFromExcel = null;
		HashMap<String, String> testDataFinal = new HashMap<>();

		testDataFromExcel = ReadTestData.getTestCaseData(testCaseName, suiteName );

		if (testDataFromExcel == null && !suiteName.contains("GPA")) {
			LOGGER.info("No test data is found in YML" + suiteName);
			return testDataFinal;
		}
		else if (testDataFromExcel == null && suiteName.contains("GPA"))
		{
			testDataFromExcel = new HashMap<>();
		}

		if(suiteName.equals("QnB"))
		{
			LOGGER.info("Reading QnB common data");
			if (testDataFromExcel.get("PolicyType").equalsIgnoreCase("HomeOwner") || testDataFromExcel.get("PolicyType").equalsIgnoreCase("HOPHomeowners"))
			{
				testDataFinal = PolicyData_QnB.getHomeOwnerTestData();
				testDataFinal.putAll(testDataFromExcel);
			}
			else if(testDataFromExcel.get("PolicyType").equalsIgnoreCase("PersonalAuto"))
			{
			testDataFinal = PolicyData_QnB.getPersonalAutoTestData();
			testDataFinal.putAll(testDataFromExcel);
		}

			else if(testDataFromExcel.get("PolicyType").equalsIgnoreCase("BusinessOwner"))
			{
				testDataFinal = PolicyData_QnB.getCPAndBOPTestData();
				testDataFinal.putAll(testDataFromExcel);
			}

			return testDataFinal;
		}
		else if(testDataFromExcel.containsKey("ClaimType") && (suiteName.contains("CP-PolicyHolder") || suiteName.contains("AMP")))
		{
			LOGGER.info("Reading PolicyHolder common data");

			String platform = System.getProperty("platform");
			if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("HomeOwner"))
			{
				if(platform.equalsIgnoreCase("Emerald"))
				{
					testDataFinal = ClaimData_PolicyHolder.getHOClaimTestData_Emerald();
				}
				else if(platform.equalsIgnoreCase("Ferrite") | platform.equalsIgnoreCase("granite"))
				{
					testDataFinal = ClaimData_PolicyHolder.getHOClaimTestData_Ferrite();
				}
				else if(platform.equalsIgnoreCase("Diamond"))
				{
					testDataFinal = ClaimData_PolicyHolder.getHOClaimTestData_Emerald();
				}
				
				testDataFinal.putAll(testDataFromExcel);
			}
			else if(testDataFromExcel.get("ClaimType").equalsIgnoreCase("PersonalAuto"))
			{
				if(platform.equals("Emerald"))
				{
					testDataFinal = ClaimData_PolicyHolder.getPAClaimTestData_Emerald();
				}
				else if(platform.equalsIgnoreCase("Ferrite") | platform.equalsIgnoreCase("granite"))
				{
					testDataFinal = ClaimData_PolicyHolder.getPAClaimTestData_Ferrite();
				}
				else if(platform.equalsIgnoreCase("Ferrite91"))
				{
					testDataFinal = ClaimData_PolicyHolder.getPAClaimTestData_Ferrite9_1();
				}
				else if(platform.equalsIgnoreCase("Diamond"))
				{
					testDataFinal = ClaimData_PolicyHolder.getPAClaimTestData_Diamond();
				}
				testDataFinal.putAll(testDataFromExcel);
			} else if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("WorkersComp")) {

				testDataFinal = ClaimData_PolicyHolder.getWCClaimTestData();
				testDataFinal.putAll(testDataFromExcel);
			} else {
				testDataFinal.putAll(testDataFromExcel);
			}
			
			testDataFromExcel.putAll(RandomEndorsementData.randomData());
			System.out.println(testDataFinal);
			return testDataFinal;
		}
		else if(testDataFromExcel.containsKey("ClaimType") && suiteName.contains("CP-Producer"))
		{
			LOGGER.info("Reading Producer common data");
			if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("HomeOwner"))
			{
				if(System.getProperty("platform").equalsIgnoreCase("Emerald"))
				{
					testDataFinal = ClaimData_Producer.getHOClaimTestData_Emerald();
				}
				else if(System.getProperty("platform").equalsIgnoreCase("Ferrite"))
				{
					testDataFinal = ClaimData_Producer.getHOClaimTestData_Ferrite();
				}
				testDataFinal.putAll(testDataFromExcel);
			}
			else if(testDataFromExcel.get("ClaimType").equalsIgnoreCase("PersonalAuto"))
			{
				if(System.getProperty("platform").equalsIgnoreCase("Emerald"))
				{
					testDataFinal = ClaimData_Producer.getPAClaimTestData_Emerald();
				}
				else if(System.getProperty("platform").equalsIgnoreCase("Ferrite"))
				{
					testDataFinal = ClaimData_Producer.getPAClaimTestData_Ferrite();
				}
				else if(System.getProperty("platform").equalsIgnoreCase("Ferrite91"))
				{
					testDataFinal = ClaimData_Producer.getPAClaimTestData_Ferrite9_1();
					System.out.println();
				}
				else if(System.getProperty("platform").equalsIgnoreCase("Diamond"))
				{
					testDataFinal = ClaimData_Producer.getPAClaimTestData_Diamond();
				}
				testDataFinal.putAll(testDataFromExcel);
			} else if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("WorkersComp")) {

				testDataFinal = ClaimData_Producer.getWCClaimTestData();
				testDataFinal.putAll(testDataFromExcel);
			} else {
				testDataFinal.putAll(testDataFromExcel);
			}
			
			return testDataFinal;
		} 
		else if(testDataFromExcel.containsKey("ClaimType") && suiteName.contains("GPA"))
		{
			LOGGER.info("Reading GPA claim common data");
			if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("HomeOwner"))
			{
				testDataFinal.putAll(ClaimData_PolicyHolder.getHOClaimCommonTestData());
			}
			else if(testDataFromExcel.get("ClaimType").equalsIgnoreCase("PersonalAuto"))
			{
				testDataFinal.putAll(ClaimData_PolicyHolder.getPAClaimCommonData());
			}
			else if (testDataFromExcel.get("ClaimType").equalsIgnoreCase("WorkersComp")) {

				testDataFinal = ClaimData_Producer.getWCClaimTestData();
				testDataFinal.putAll(testDataFromExcel);
			}

			testDataFinal.putAll(testDataFromExcel);
				
			return testDataFinal;
		} 
		
		else if (suiteName.contains("GPA")) {
			LOGGER.info("Reading GPA quote common data");
			if (testDataFromExcel.get("PolicyType") != null) {
				if (testDataFromExcel.get("PolicyType").equalsIgnoreCase("PersonalAuto")) {
					testDataFinal = PolicyData_QnB.getPersonalAutoTestData();
					testDataFinal.putAll(testDataFromExcel);
					return testDataFinal;
				}

				if(testDataFromExcel.get("PolicyType").equalsIgnoreCase("HomeOwner") || testDataFromExcel.get("PolicyType").equalsIgnoreCase("HomeOwners") || testDataFromExcel.get("PolicyType").equalsIgnoreCase("HOPHomeowners")) {

					testDataFinal = PolicyData_QnB.getHomeOwnerTestData();
					testDataFinal.putAll(testDataFromExcel);
					return testDataFinal;
				}
			}

				testDataFinal = PolicyData_QnB.getCPAndBOPTestData();
				testDataFinal.putAll(testDataFromExcel);
				return testDataFinal;

		}
		else if (suiteName.contains("AMP")) {
			LOGGER.info("Reading AMP common data");
			if (testDataFromExcel.get("PolicyType") != null) {
				if (testDataFromExcel.get("PolicyType").equalsIgnoreCase("PersonalAuto")) {
					testDataFinal = PolicyData_QnB.getPersonalAutoTestData();
					testDataFinal.putAll(testDataFromExcel);
					testDataFinal.putAll(RandomEndorsementData.randomData());
					return testDataFinal;
				}

				if((testDataFromExcel.get("PolicyType").equalsIgnoreCase("HomeOwner"))||(testDataFromExcel.get("PolicyType").equalsIgnoreCase("HomeOwners"))) {

					testDataFinal = PolicyData_QnB.getHomeOwnerTestData();
					testDataFinal.putAll(testDataFromExcel);
					testDataFinal.putAll(RandomEndorsementData.randomData());
					return testDataFinal;
				}
			}

				testDataFinal.putAll(testDataFromExcel);
				testDataFinal.putAll(RandomEndorsementData.randomData());
				return testDataFinal;

		}
		return testDataFromExcel;
	}

	public static String getSuiteDataFileName(String suiteName) {
		if (suiteName.equals("CP-PolicyHolder") ||
				suiteName.equals("CP-Producer") ||
				suiteName.equals("GPA") ||
				suiteName.equals("AMP") ||
				suiteName.equals(SuiteName.CPVENDOR.toString()))
		{
			return suiteName + "-" +  System.getProperty("platform");
		}
		return suiteName;
	}

	public static void main(String[] args) {
	System.out.println(getTestData("validatePolicyLevelCoverageDetailsPage", "CP-Producer-Diamond"));
	}
}
