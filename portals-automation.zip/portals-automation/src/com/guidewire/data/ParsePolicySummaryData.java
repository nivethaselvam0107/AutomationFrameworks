package com.guidewire.data;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.DateUtil;
import io.restassured.path.json.JsonPath;

import java.util.HashMap;

public class ParsePolicySummaryData {
    private static HashMap<String, String> data = ThreadLocalObject.getData();

    public static HashMap<String, String> getPolicySummaryDataFromBackEnd(String jsonData) throws Exception {
        HashMap<String, String> info = new HashMap<>();

        JsonPath path = new JsonPath(jsonData);

        String producerCodeOfSer = DataFormatUtil.getNodeValue(path, "periods[0]", "producerCodeOfService");
        String producerCodeOfRec = DataFormatUtil.getNodeValue(path, "periods[0]", "producerCodeOfRecord");
        String producerOfSerOrg = DataFormatUtil.getNodeValue(path, "periods[0]", "producerCodeOfRecordOrg");
        String producerOfRecOrg = DataFormatUtil.getNodeValue(path, "periods[0]", "producerCodeOfServiceOrg");
        String effectiveDate = DataFormatUtil.getNodeValue(path, "periods[0]", "effectiveDate");
        String formattedEffectiveDate = DateUtil.getDateFromISODateMMMMMMdYYYY(effectiveDate);
        String expirationDate = DataFormatUtil.getNodeValue(path, "periods[0]", "expirationDate");
        String formatttedExpirationDate = DateUtil.getDateFromISODateMMMMMMdYYYY(expirationDate);
        String producerOfService = producerOfSerOrg + " (" + producerCodeOfSer + ")";
        String producerOfRecord = producerOfRecOrg + " (" + producerCodeOfRec + ")";
        DataFormatUtil.putData(info, PolicyData.POLICY_NUM.toString(), DataFormatUtil.getNodeValue(path, "periods[0]", "policyNumber"));
        DataFormatUtil.putData(info, PolicyData.POLICY_INCEPTION.toString(), formattedEffectiveDate);
        DataFormatUtil.putData(info, PolicyData.POLICY_EXPIRATION.toString(), formatttedExpirationDate);
        DataFormatUtil.putData(info, PolicyData.POLICY_STATUS.toString(), DataFormatUtil.getNodeValue(path, "periods[0]", "displayStatus"));
        DataFormatUtil.putData(info, PolicyData.PRODUCER_OF_SERVICE.toString(), producerOfService);
        DataFormatUtil.putData(info, PolicyData.PRODUCER_OF_RECORD.toString(), producerOfRecord);
        DataFormatUtil.putData(info, PolicyData.TOTAL_PREMIUM.toString(), DataFormatUtil.getNodeValue(path, "periods[0]", "totalPremium.amount"));
        DataFormatUtil.putData(info, PolicyData.TAXES_AND_FEES.toString(), DataFormatUtil.getNodeValue(path, "periods[0]", "taxesAndFees.amount"));
        DataFormatUtil.putData(info, PolicyData.TOTAL_COST.toString(), DataFormatUtil.getNodeValue(path, "periods[0]", "totalCost.amount"));
        return info;
    }
}