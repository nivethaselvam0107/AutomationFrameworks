package com.guidewire.data;

import java.util.HashMap;

import com.guidewire.common.util.DataFormatUtil;

import io.restassured.path.json.JsonPath;

public class ParseAccountData {

    public static HashMap<String, String> accountInformationFromBackend(String jsonData) {
        HashMap<String, String> info = new HashMap<>();
        JsonPath path = new JsonPath(jsonData);
        System.out.println(jsonData);
        DataFormatUtil.putData(info, "DISPLAY_NAME", DataFormatUtil.getNodeValue(path, "", "displayName"));
        DataFormatUtil.putData(info, "FIRST_NAME", DataFormatUtil.getNodeValue(path, "", "firstName"));
        DataFormatUtil.putData(info, "LAST_NAME", DataFormatUtil.getNodeValue(path, "", "lastName"));
        DataFormatUtil.putData(info, "ADDRESS_DISPLAY_NAME", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "displayName"));
        DataFormatUtil.putData(info, "ADDRESS_LINE1", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "addressLine1"));
        DataFormatUtil.putData(info, "CITY", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "city"));
        DataFormatUtil.putData(info, "STATE", "California");
        DataFormatUtil.putData(info, "ZIP_CODE", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "postalCode"));
        DataFormatUtil.putData(info, "COUNTRY", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "country"));
        DataFormatUtil.putData(info, "PRIMARY_ADDRESS_DISPLAY_NAME", DataFormatUtil.getNodeValue(path, "accountContact.primaryAddress", "displayName"));
        DataFormatUtil.putData(info, "HOME_PHONE", DataFormatUtil.getNodeValue(path, "accountContact", "homeNumber"));
        DataFormatUtil.putData(info, "WORK_PHONE", DataFormatUtil.getNodeValue(path, "accountContact", "workNumber"));
        DataFormatUtil.putData(info, "CELL", DataFormatUtil.getNodeValue(path, "accountContact", "cellNumber"));
        DataFormatUtil.putData(info, "EMAIL", DataFormatUtil.getNodeValue(path, "accountContact", "emailAddress1"));
        return info;
    }
    public static void main(String[] args) {
        System.out.println(accountInformationFromBackend(DataFetch.getUserProfileData()));
    }
}

