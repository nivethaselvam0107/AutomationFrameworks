package com.guidewire.capabilities.faq.test;

import com.guidewire.capabilities.faq.model.page.FaqPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class FaqTest {

    FaqPage faqPage = new FaqPage();

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void isFaqPageLoadedByClickingLink() {

        faqPage.getFaqPage().isFaqPageOpened().shouldBeTrue("FAQ page is NOT loaded after clicking menu link.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void testIsFaqPageLoadedByClickingLinkOnResponsiveView() {

        faqPage.getFaqPageOnResizedWindow().isFaqPageOpened().shouldBeTrue("FAQ page is NOT loaded after clicking hamburger menu link.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void isFaqPageLoadedByTypingUrl() {

        faqPage.getFaqPageByUrl().isFaqPageOpened().shouldBeTrue("FAQ page is NOT loaded after typing faq url.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void isFaqSelectedSectionVisibleOnScreen() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        faqPage.selectLastSection();
        faqPage.isSelectedElementVisible().shouldBeTrue("FAQ selected section is NOT visible on screen.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void searchTopicQuestion() {

        FaqPage faqPage = this.faqPage.getFaqPage();
        faqPage.checkSearchResultsForTopicQuestionWord().shouldBeEqual("FAQ Search result for topic question DOES NOT contain searched text.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void searchTopicContent() {

        FaqPage faqPage = this.faqPage.getFaqPage();
        faqPage.checkSearchResultsForTopicContentWord().shouldBeEqual("FAQ Search result for topic content DOES NOT contain searched text.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void searchTopicLinkName() {

        FaqPage faqPage = this.faqPage.getFaqPage();
        faqPage.checkSearchResultsForTopicLinkNameWord().shouldBeEqual("FAQ Search result for topic link name DOES NOT contain searched text.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void searchSpecialCharsText() {

        FaqPage faqPage = this.faqPage.getFaqPage();
        String[] specialCharsText = {".", ":", "?", ">", "/", "\\", "%", "#", "@", "!", ",", "!=", "=", "+", "\\d", "\\w", "^", "$", null, "<div>", "<div", "div>"};
        for(String specialChar : specialCharsText) {
            faqPage.checkSearchContains(specialChar).shouldBeEqual("FAQ Search result for random text[" + specialChar + "] DOES NOT contain searched text.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void checkDeepLinksForSections() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        for(String sectionID : faqPage.getSectionIDs() ) {
            faqPage.checkIfDeepLinkForSectionDisplayed(sectionID).shouldBeTrue("FAQ deep link for section[" + sectionID + "] NOT showing section on the screen.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void testDeepLinksFromURLForSections() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        for(String sectionID : faqPage.getSectionIDs() ) {
            faqPage.checkIfDeepLinkInURLForSectionDisplayed(sectionID).shouldBeTrue("FAQ deep link for section[" + sectionID + "] NOT showing section on the screen.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void checkDeepLinksForTopics() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        for(String topicID : faqPage.getTopicIDs() ) {
            faqPage.checkIfDeepLinkForTopicDisplayed(topicID).shouldBeTrue("FAQ deep link for topic[" + topicID + "] NOT showing topic or not expanding topic on the screen.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void checkNoResultsMessage() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        faqPage.checkSearchContainsNoResultsMessage("some fake text here to have no results for sure").shouldBeEqual("FAQ results NOT showing 'no results' message.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void testDisabledSectionOnSearchResults() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        faqPage.checkSearchResultsForContentWordAndDisabledSections().shouldBeTrue("Section links are NOT disabled if they are not containing search results.");
    }

    @Parameters("browserName")
    @Test(groups = {"Faq"})
    public void testJSinjection() {

        FaqPage faqPage = this.faqPage.getFaqPageByUrl();
        faqPage.checkIfJSscriptNotAllowed("QA_TEST").shouldBeEqual("JS script injection IS possible!!!");
    }
}
