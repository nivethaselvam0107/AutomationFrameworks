package com.guidewire.capabilities.faq.model.page;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.PropertiesReader;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;


public class FaqPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    Logger logger = Logger.getLogger(this.getClass().getName());
    public HashMap<String, String> data = ThreadLocalObject.getData();

    private static final String FAQ_HIGHLIGHTED_CSS =  "span[class='gw-highlight-phrase-filter_matched']";
    private static final String FAQ_NO_RESULTS_TEXT = "No matching results found";
    private final String FAQ_MENU_LINK_PARENT_CSS = "[gw-faq-link]:not(li) span[category='faq']";
    private final String FAQ_SECTIONS_CSS = "gw-faq div[ng-repeat*='section in']";
    private final String FAQ_SECTIONS_COLLAPSE_CSS = FAQ_SECTIONS_CSS + " div[class*='gw-is-open']";
    private final String ELEMENT_INACTIVE = "gw-inactive";
    public static final String FAQ_MENU_LINK_CSS = "[gw-faq-link]:not(li) a";
    public static final String FAQ_HAMBURGER_MENU_LINK_CSS = "li[gw-faq-link] a";
    public static final String FAQ_LINK_NAME = "faq/";
    public static final String FAQ_SELECTED_ELEMENT_CSS = "div.ng-scope [id='%']";

    @FindBy(xpath = "//div[@class='gw-header']//a[@href='#/home' or @href='#/']")
    WebElement HOME_BTN_XPATH;

    @FindBy(css = "div[class*='gw-hamburger']")
    WebElement NAV_BAR_HAMBURGER_CSS;

    @FindBy(css = "gw-faq")
    WebElement FAQ_CONTAINER_CSS;

    @FindBy(css = "ul.gw-steps a")
    List<WebElement> FAQ_SECTIONS_MENU_CSS;

    By SECTION_ELEMENT_CSS = By.cssSelector("h2[class*='gwFaqSection']");

    @FindBy(css = "div[ng-repeat*='section in']")
    List<WebElement> FAQ_SECTIONS_OBJ_CSS;

    @FindBy(css = "span[ng-bind-html*='topic.question']")
    List<WebElement> FAQ_TOPICS_QUESTION_CSS;

    By TOPIC_QUESTION = By.cssSelector("span[ng-bind-html*='topic.question']");

    @FindBy(css = "div[ng-bind-html*='topic.long']")
    List<WebElement> FAQ_TOPICS_LONG_CSS;

    By TOPIC_CONTENT = By.cssSelector("div[ng-bind-html*='topic.long']");

    @FindBy(css = "a[ng-bind-html*='topic.link.name']")
    List<WebElement> FAQ_TOPICS_LINK_NAMES_CSS;

    By TOPIC_LINK_LABEL = By.cssSelector("a[ng-bind-html*='topic.link.name']");

    @FindBy(css = "input[ng-model='search.query'")
    WebElement FAQ_SEARCHBOX_CSS;

    @FindBy(css = "gw-faq div[class*='FaqDirective']")
    WebElement FAQ_RESULTS_AREA_CSS;

    @FindBy(css = "gw-faq div[class*='FaqDirective'] div[class*='FaqEmptyInfo']")
    WebElement FAQ_NO_RESULTS_AREA_CSS;

    public FaqPage() {

        seleniumCommands.pageWebElementLoader(this);
    }

    private void setLoginCredentials() {

        String url = ThreadLocalObject.getDriver().getCurrentUrl();
        if(!url.contains("zipCode"))
            new LoginPage().login();

        seleniumCommands.waitForElementToBeClickable(By.cssSelector(FAQ_MENU_LINK_CSS));
    }

    public FaqPage getFaqPage() {
        setLoginCredentials();
        logger.info("Go to FAQ Page by clicking menu link");
        return new FaqPage().openFaqPageByClickingLink();
    }

    public FaqPage getFaqPageOnResizedWindow() {
        setLoginCredentials();
        logger.info("Go to FAQ Page by clicking hamburger menu link");
        seleniumCommands.setWindowDimensions(600, 730);
        seleniumCommands.pageWebElementLoader(this);
        seleniumCommands.click(NAV_BAR_HAMBURGER_CSS);
        return new FaqPage().openFaqPageByClickingLinkOnHamburgerMenu();
    }

    public FaqPage getFaqPageByUrl() {
        setLoginCredentials();
        logger.info("Go to FAQ Page by using url");
        return new FaqPage().openFaqPageByUsingUrlAddress();
    }

    private String getSelectedElementCss(String elementId) {

        return FAQ_SELECTED_ELEMENT_CSS.replace("%", elementId);
    }

    private String getSelectedElementIdFromUrl() {

        String currentUrl = seleniumCommands.getCurrentUrl().toString();
        String selectedElementId = currentUrl.substring(currentUrl.lastIndexOf("#") + 1);
        return this.getSelectedElementCss(selectedElementId);
    }

    public Validation isFaqPageOpened() {

        logger.info( "Checking If FAQ page opened");
        seleniumCommands.refreshPage();
        seleniumCommands.waitForElementToBePresent(FAQ_CONTAINER_CSS);
        return new Validation(seleniumCommands.isElementPresent(FAQ_CONTAINER_CSS));
    }

    public Validation isSelectedElementVisible() {

        logger.info("Checking If selected FAQ element is visible on page");
        String selectedElementCss = this.getSelectedElementIdFromUrl();
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(selectedElementCss));
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(selectedElementCss)));
    }

    public Validation isSelectedElementVisible(String sectionID) {

        logger.info("Checking If selected FAQ element[" + sectionID + "] is visible on page");
        String elementCssSelector = this.getSelectedElementCss(sectionID);
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(elementCssSelector));
        return new Validation(seleniumCommands.isElementVisible(By.cssSelector(elementCssSelector)));
    }

    public FaqPage openFaqPageByClickingLink() {

        logger.info("Opening FAQ page by using menu link");
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(FAQ_MENU_LINK_CSS));
        seleniumCommands.click(By.cssSelector(FAQ_MENU_LINK_CSS));
        seleniumCommands.waitForElementToBePresent(FAQ_CONTAINER_CSS);
        return this;
    }

    public FaqPage openFaqPageByClickingLinkOnHamburgerMenu() {

        logger.info("Opening FAQ page by using menu link on hamburger menu");
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(FAQ_HAMBURGER_MENU_LINK_CSS));
        seleniumCommands.click(By.cssSelector(FAQ_HAMBURGER_MENU_LINK_CSS));
        seleniumCommands.waitForElementToBePresent(FAQ_CONTAINER_CSS);
        return this;
    }

    private String getFaqURL() {
        String currentUrl = seleniumCommands.getCurrentUrl().toString();
        return currentUrl.substring(0, currentUrl.lastIndexOf("#/") + 2) + FAQ_LINK_NAME;
    }

    public FaqPage openFaqPageByUsingUrlAddress() {

        String faqUrl = this.getFaqURL();
        logger.info("Opening FAQ page by using url address[" + faqUrl + "]");
        ThreadLocalObject.getDriver().get(faqUrl);
        seleniumCommands.waitForElementToBePresent(FAQ_CONTAINER_CSS);
        return this;
    }

    public void selectLastSection() {

        int lastIndex = FAQ_SECTIONS_MENU_CSS.size();
        FAQ_SECTIONS_MENU_CSS.get(lastIndex - 1).click();
    }

    public List<String> getSectionIDs() {

        logger.info("Getting FAQ section ids");

        List<String> names = new ArrayList<>();

        for(WebElement el : FAQ_SECTIONS_MENU_CSS) {
            names.add((String) seleniumCommands.getAngularScopeItem(el,"section.id") );
        }

        return names;
    }

    public List<String> getTopicQuestions() {

        logger.info("Getting FAQ topic questions");

        List<String> questions = new ArrayList<>();

        for(WebElement el : FAQ_TOPICS_QUESTION_CSS) {
            questions.add( seleniumCommands.getAttributeValueAtLocator(el, "innerText") );
        }

        return questions;
    }

    private void resetSearch() {
        this.search("");
    }

    private HashMap<String, List<String>> getElementsBySections() {

        logger.info("Getting FAQ [topic questions, topic content, topic link labels] by sections");

        HashMap<String, List<String>> topicsBySections = new HashMap<>();

        this.resetSearch();

        FAQ_SECTIONS_OBJ_CSS.forEach(section -> {
            WebElement sectionWebElementName = seleniumCommands.findElement(section, SECTION_ELEMENT_CSS);
            String sectionName= seleniumCommands.getAttributeValueAtLocator(sectionWebElementName, "innerText");
            List<String> questions = new ArrayList<>();
            seleniumCommands.findElements(section, TOPIC_QUESTION).forEach(topicQuestion -> {
                questions.add( seleniumCommands.getAttributeValueAtLocator(topicQuestion, "innerText") );
            });
            seleniumCommands.findElements(section, TOPIC_CONTENT).forEach(topicContent -> {
                questions.add( seleniumCommands.getAttributeValueAtLocator(topicContent, "innerText") );
            });
            seleniumCommands.findElements(section, TOPIC_LINK_LABEL).forEach(topicLinkLabel -> {
                questions.add( seleniumCommands.getAttributeValueAtLocator(topicLinkLabel, "innerText") );
            });
            topicsBySections.put(sectionName, questions);
        });

        return topicsBySections;
    }

    public List<String> getTopicContents() {

        logger.info("Getting FAQ topic contents");

        List<String> contents = new ArrayList<>();

        for(WebElement el : FAQ_TOPICS_LONG_CSS) {
            contents.add( seleniumCommands.getAttributeValueAtLocator(el, "innerText") );
        }

        return contents;
    }

    public List<String> getTopicLinkNames() {

        logger.info("Getting FAQ topic link names");

        List<String> linkNames = new ArrayList<>();

        for(WebElement el : FAQ_TOPICS_LINK_NAMES_CSS) {
            String linkUrl = (String) seleniumCommands.getAngularScopeItem(el,"topic.link.url");
            String linkName = seleniumCommands.getAttributeValueAtLocator(el, "innerText");
            if ( ! linkName.equals(linkUrl) ) {
                linkNames.add(linkName);
            }
        }
        return linkNames;
    }

    public List<String> getTopicIDs() {

        logger.info("Getting FAQ topic IDs");

        List<String> topicIDs = new ArrayList<>();

        for(WebElement el : FAQ_TOPICS_LINK_NAMES_CSS) {
            String topic = (String) seleniumCommands.getAngularScopeItem(el,"topic.id");
            if ( ! topicIDs.contains(topic) ) {
                topicIDs.add(topic);
            }
        }
        return topicIDs;
    }

    private List<String> getHighlightedElements() {

        List<String> highlightedText = new ArrayList<>();

        for(WebElement el : seleniumCommands.findElements(By.cssSelector(FAQ_HIGHLIGHTED_CSS))) {
            highlightedText.add( el.getAttribute("innerText") );
        }

        return highlightedText;
    }

    public List<String> search(String searchText) {

        seleniumCommands.type(FAQ_SEARCHBOX_CSS, searchText);
        seleniumCommands.waitForElementToBeVisible(FAQ_RESULTS_AREA_CSS);

        List<String> result = this.getHighlightedElements();

        logger.info("Getting search results for [ " + searchText + " ], results: " + result);

        return result;
    }

    private String getSingleWord(List<String> list) {

        logger.debug("Getting single word from list: " + list);
        PropertiesReader pr = new PropertiesReader();
        String singleListItemRandom = pr.getRandomList(list);

        String[] singleWordsArrayRandom = singleListItemRandom.split(" ");
        List<String> singleWordsListRandom = Arrays.asList(singleWordsArrayRandom);

        return pr.getRandomList(singleWordsListRandom);
    }

    private HashMap<String,String> getWordFromContentBelongingToOneSectionOnly() {

        logger.debug("Getting single word belonging to one section only");
        int occurrenceCounter;
        HashMap<String, List<String>> topicsBySection = this.getElementsBySections();
        List<String> topicQuestions = this.getTopicQuestions();
        boolean isBelongingToOneSectionOnly = false;
        String section ="";
        String word;
        HashMap<String, String> result = new HashMap<>();
        while( !isBelongingToOneSectionOnly ) {
            word = getSingleWord(topicQuestions);
            occurrenceCounter = 0;
            for (String sectionName : topicsBySection.keySet()) {
                for (String topic : topicsBySection.get(sectionName)) {
                    if (topic.toLowerCase().contains(word.toLowerCase())) {
                        occurrenceCounter++;
                        section = sectionName;
                        break;
                    }
                }
            }
            if(occurrenceCounter == 0) {
                break;
            }
            else if(occurrenceCounter == 1) {
                isBelongingToOneSectionOnly = true;
                result.put(section, word);
            }
        }
        return result;
    }

    private Validation listContains(List<String> list, String expected) {

        logger.debug("Checking if list: " + list + ", contains: " + expected);

        for(String el : list) {
            if( ! el.toLowerCase().equals(expected.toLowerCase()) ){
                return new Validation(el, expected);
            }
        }

        if(expected != null)
            this.checkIfAllResultsElementsContainsHighlights().shouldBeTrue("Some Sections doesn't contains highlighted results");

        return new Validation(true, true);
    }

    public Validation checkSearchResultsForContentWordAndDisabledSections() {

        HashMap<String, String> sectionWithWord = this.getWordFromContentBelongingToOneSectionOnly();
        String sectionWithResults="";
        for(String key : sectionWithWord.keySet()) {
            sectionWithResults = key;
        }

        String searchedText = sectionWithWord.get(sectionWithResults);
        this.search(searchedText);

        List<String> disabledSections = new ArrayList<>();
        for(WebElement sectionWebElement : FAQ_SECTIONS_MENU_CSS) {
            String sectionName = seleniumCommands.getAttributeValueAtLocator(sectionWebElement, "innerText");

            if( !sectionName.equals(sectionWithResults) ) {
                disabledSections.add(sectionName);
                new Validation(seleniumCommands.getAttributeValueAtLocator(sectionWebElement, "class").contains(ELEMENT_INACTIVE)).
                        shouldBeTrue("Section [" + sectionName + "] is NOT disabled. Search string[" + searchedText + "]");
            }
        }

        logger.info("Checking if after search[" + searchedText +
                "], sections not containing searched text are disabled" + disabledSections + ".");

        return new Validation(true);
    }

    public Validation checkSearchResultsForTopicQuestionWord() {

        String searchedText = this.getSingleWord(this.getTopicQuestions());

        logger.info("Checking if search results contains word from topic question[ " + searchedText + " ]");

        List<String> actualResult = this.search(searchedText);
        return this.listContains(actualResult, searchedText);
    }

    private Validation checkIfAllResultsElementsContainsHighlights() {

        for(WebElement el : FAQ_RESULTS_AREA_CSS.findElements(By.cssSelector(FAQ_SECTIONS_CSS))) {
            if ( ! (el.findElements(By.cssSelector(FAQ_HIGHLIGHTED_CSS)).size() > 0) ) {
                return new Validation(false);
            }
        }
        return new Validation(true);
    }

    public Validation checkSearchResultsForTopicContentWord() {

        String searchedText = this.getSingleWord(this.getTopicContents());

        logger.info("Checking if search results contains word from topic content[ " + searchedText + " ]");

        List<String> actualResult = this.search(searchedText);
        return this.listContains(actualResult, searchedText);
    }

    public Validation checkSearchResultsForTopicLinkNameWord() {

        String searchedText = this.getSingleWord(this.getTopicLinkNames());

        logger.info("Checking if search results contains word from topic link name[ " + searchedText + " ]");

        List<String> actualResult = this.search(searchedText);
        return this.listContains(actualResult, searchedText);
    }

    public Validation checkSearchContains( String searchedText ) {

        logger.info("Checking if search results contains[ " + searchedText + " ]");
        List<String> actualResult = this.search(searchedText);
        return this.listContains(actualResult, searchedText);
    }

    public Validation checkSearchContainsNoResultsMessage( String searchedText ) {

        logger.info("Checking if search results NOT contains results for [ " + searchedText + " ]");

        this.search(searchedText);

        return new Validation(seleniumCommands.getTextAtLocator(FAQ_NO_RESULTS_AREA_CSS), FAQ_NO_RESULTS_TEXT);
    }

    public void setDeepLinkInLandingPageScope(String fragment) {

        logger.debug("Setting deep link in the landing page scope of FAQ link");

        WebElement faqMenuLinkParent = seleniumCommands.findElement(By.cssSelector(FAQ_MENU_LINK_PARENT_CSS));
        seleniumCommands.getAngularScopeItem(faqMenuLinkParent, "fragment='" + fragment +"'");
    }

    public void goToLandingPage() {

        HOME_BTN_XPATH.click();
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(FAQ_MENU_LINK_CSS));
    }

    public Validation checkIfDeepLinkForSectionDisplayed(String fragment) {

        logger.info("Checking if deep link to section id [" + fragment + "] displays the section on user screen.");

        this.setDeepLinkInLandingPageScope(fragment);
        this.goToLandingPage();
        this.openFaqPageByClickingLink();
        return this.isSelectedElementVisible(fragment);
    }

    public Validation checkIfDeepLinkInURLForSectionDisplayed(String fragment) {

        logger.info("Checking if deep link in URL to section id [" + fragment + "] displays the section on user screen.");

        this.goToLandingPage();
        ThreadLocalObject.getDriver().get(this.getFaqURL() + "#" + fragment);
        return this.isSelectedElementVisible(fragment);
    }

    public Validation checkIfDeepLinkForTopicDisplayed(String fragment) {

        logger.info("Checking if deep link to topic id [" + fragment + "] displays and expands the topic on user screen.");

        this.setDeepLinkInLandingPageScope(fragment);
        this.goToLandingPage();
        this.openFaqPageByClickingLink();

        logger.info("Checking if topic[" + fragment + "] is expanded");
        int expandedTopicCount = 0;
        for(WebElement el : seleniumCommands.findElements(By.cssSelector(FAQ_SECTIONS_COLLAPSE_CSS))) {
            if ( ! (el.getCssValue("height").equals("0px")) ) {
                expandedTopicCount++;
                WebElement topic = el.findElement(By.cssSelector("h2"));
                String id = seleniumCommands.getAttributeValueAtLocator(topic, "id");
                if( ! id.equals(fragment) ) {
                    return new Validation(false);
                }
            }
        }

        if ( (expandedTopicCount == 0) || (expandedTopicCount > 1) )
            return new Validation(false);

        return this.isSelectedElementVisible(fragment);
    }

    public Validation checkIfJSscriptNotAllowed(String inputText) {

        logger.info("Checking if JAVA SCRIPT injection is not allowed.");
        seleniumCommands.getAngularScopeItem(this.FAQ_TOPICS_LONG_CSS.get(0),"topic.long='<script>alert(%22alertMESSAGE%22)</script>" + inputText + "'");
        seleniumCommands.getAngularScopeItem(this.FAQ_TOPICS_LONG_CSS.get(0),"$apply()");
        return new Validation(this.FAQ_TOPICS_LONG_CSS.get(0).getAttribute("innerText"), inputText);
    }
}
