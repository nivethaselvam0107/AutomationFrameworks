package com.guidewire.capabilities.agent.scenarios;

import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.common.testNG.Validation;

import com.guidewire.widgetcomponents.Modal;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BindCancellationOnPolicyScenario extends QuoteCancellationOnPolicyScenario implements
        IBindPolicyCancellationPage {

    @FindBy(css = "button[ng-click='bindCancellation(cancellationNumber)'], button[type='submit']")
    WebElement BIND_CANCELLATION_BUTTON_CSS;

    @FindBy(css = "[gw-visuallyhidden-unless='cancellationNumber'] [type='policyperiod-status-Quoted']")
    WebElement CANCELLATION_STATUS_QUOTED_CSS;

    @FindBy(css = "[gw-visuallyhidden-unless='cancellationNumber'] [type='policyperiod-status-Bound']")
    WebElement CANCELLATION_STATUS_BOUND_CSS;

    public BindCancellationOnPolicyScenario(String policyNum) {
        super(policyNum);
    }

    @Override
    public void bindCancellationOnPolicy() {
        seleniumCommands.click(BIND_CANCELLATION_BUTTON_CSS);
        new Modal().confirm();
        seleniumCommands.waitForElementToBePresent(CANCELLATION_STATUS_BOUND_CSS);
    }

    @Override
    public void doNotBindCancellationOnPolicy() {
        seleniumCommands.click(BIND_CANCELLATION_BUTTON_CSS);
        new Modal().dismiss();
        seleniumCommands.waitForElementToBePresent(CANCELLATION_STATUS_QUOTED_CSS);
    }

    @Override
    public void withdrawCancellationOnPolicy(){
    }

    @Override
    public void doNotWithdrawCancellationOnPolicy(){
    }

    public Validation checkIfPolicyCancellationIsBounded() {
        return new Validation(checkIfPolicyCancellationHasCorrectStatus("Bound"));
    }
}
