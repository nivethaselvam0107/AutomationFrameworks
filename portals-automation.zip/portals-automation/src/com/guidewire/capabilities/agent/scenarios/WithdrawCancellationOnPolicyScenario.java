package com.guidewire.capabilities.agent.scenarios;

import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.Modal;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class WithdrawCancellationOnPolicyScenario extends QuoteCancellationOnPolicyScenario implements IBindPolicyCancellationPage{

    @FindBy(css = "button[ng-click='withdrawCancellationByCancellationNumber(cancellationNumber)'], button[type='button'][ng-click='hideForm()']")
    WebElement WITHDRAW_CANCELLATION_BUTTON_CSS;

    @FindBy(css = "[gw-visuallyhidden-unless='cancellationNumber'] [type='policyperiod-status-Withdrawn']")
    WebElement CANCELLATION_STATUS_WITHDRAWN_CSS;

    @FindBy(css = "[gw-visuallyhidden-unless='cancellationNumber'] [type='policyperiod-status-Quoted']")
    WebElement CANCELLATION_STATUS_QUOTED_CSS;

    public WithdrawCancellationOnPolicyScenario(String policyNum) {
        super(policyNum);
    }

    @Override
    public void bindCancellationOnPolicy() {
    }

    @Override
    public void doNotBindCancellationOnPolicy(){
    }

    @Override
    public void withdrawCancellationOnPolicy() {
        seleniumCommands.click(WITHDRAW_CANCELLATION_BUTTON_CSS);
        new Modal().confirm();
        seleniumCommands.waitForElementToBePresent(CANCELLATION_STATUS_WITHDRAWN_CSS);
    }

    @Override
    public void doNotWithdrawCancellationOnPolicy() {
        seleniumCommands.click(WITHDRAW_CANCELLATION_BUTTON_CSS);
        new Modal().dismiss();
        seleniumCommands.waitForElementToBePresent(CANCELLATION_STATUS_QUOTED_CSS);
    }

    public Validation checkIfPolicyCancellationIsWithdrawn() {
        return new Validation(checkIfPolicyCancellationHasCorrectStatus("Withdrawn"));
    }
}
