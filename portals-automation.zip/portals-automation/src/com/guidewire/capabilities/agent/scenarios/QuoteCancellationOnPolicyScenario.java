package com.guidewire.capabilities.agent.scenarios;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.capabilities.common.interfaces.ICancelPolicyDetailsPage;
import com.guidewire.capabilities.common.interfaces.ICommonPage;
import com.guidewire.capabilities.common.interfaces.IDashboardPage;
import com.guidewire.capabilities.common.interfaces.IPolicyDetailsPage;
import com.guidewire.capabilities.common.interfaces.IPolicyLandingPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.Button;

import io.restassured.path.json.JsonPath;

public class QuoteCancellationOnPolicyScenario extends CommonScenario implements
        ICommonPage,
        IDashboardPage,
        IPolicyLandingPage,
        IPolicyDetailsPage,
        ICancelPolicyDetailsPage {

    @FindBy(css = "[gw-pl-select='cancellationView.cancelReasonCode.value']")
    WebElement REASON_CSS;

    @FindBy(css = "[on-click='showCancellationForm()']")
    WebElement POLICY_CANCEL_BUTTON_CSS;

    @FindBy(css = "[gw-pl-select='cancellationView.cancellationRefundMethod.value']")
    WebElement REFUND_METHOD_CSS;

    @FindBy(css = "button[type='submit']")
    WebElement SUBMIT_BUTTON_CSS;

    @FindBy(css = "[name ='cancellationForm'].ng-pristine")
    WebElement SELECTED_REASON_CSS;

    @FindBy(css = "[name ='cancellationForm'].ng-dirty")
    WebElement SELECTED_REFUND_CSS;

    @FindBy(css = "[gw-visuallyhidden-unless='cancellationNumber'] h1")
    WebElement CANCELLATION_NUMBER_CSS;

    By EFFECTIVE_DATE_FIELD = By.cssSelector("input[name='EffectiveDate']");

    @FindBy(css = "input[name='EffectiveDate']")
    WebElement EFFECTIVE_DATE_FIELD_CSS;

    String policyNum;

    public QuoteCancellationOnPolicyScenario(String policyNum) {
        this.policyNum = policyNum;
    }

    @Override
    public IDashboardPage login() {
        new LoginPage().login();
        return this;
    }

    @Override
    public IPolicyLandingPage clickPolicyLinkOnNavBar() {
        new AgentDashboard().goToRecentyIssuedPolicies();
        return this;
    }

    @Override
    public IPolicyDetailsPage searchPolicy() {
        new AgentDashboard().searchUsingSearchBox(ThreadLocalObject.getData().get("POLICY_NUM"))
                .goToPolicy(ThreadLocalObject.getData().get("POLICY_NUM"));
        return this;
    }

    @Override
    public IPolicyDetailsPage clickOnPolicy() {
        seleniumCommands.click(By.xpath("//tr[descendant::a[contains(@href, '" +
                policyNum + "')]]//a[contains(@href, 'policies')]"));
        return this;
    }

    @Override
    public ICancelPolicyDetailsPage clickOnCancelPolicy() {
        seleniumCommands.clickbyJS(POLICY_CANCEL_BUTTON_CSS);
        return this;
    }

    @Override
    public ICancelPolicyDetailsPage fillMandatoryProperties() {
        seleniumCommands.selectFromDropdownByIndex(REASON_CSS, 1);
        seleniumCommands.waitForElementToBeVisible(SELECTED_REASON_CSS);
        seleniumCommands.staticWait(3);
        seleniumCommands.selectFromDropdownByIndex(REFUND_METHOD_CSS, 1);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(SELECTED_REFUND_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(EFFECTIVE_DATE_FIELD_CSS, DateUtil.getFutureDate(1));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    @Override
    public ICancelPolicyDetailsPage setDateNotWithinPolicyPeriod() {
        seleniumCommands.logInfo("Filling Effective Date field with date, next to policy expiration.");
        DateFormat fromFormat = new SimpleDateFormat("yyyy-MM-dd");
        fromFormat.setLenient(false);
        DateFormat toFormat = new SimpleDateFormat("MM/dd/yyyy");
        toFormat.setLenient(false);

        String expirationDate = ThreadLocalObject.getData().get(PolicyData.POLICY_EXPIRATION_DATE.toString()).split("T")[0];
        LocalDate nextToExpidationDate = LocalDate.parse(expirationDate).plusDays(1);

        Date date = null;
        try {
            date = fromFormat.parse(nextToExpidationDate.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        expirationDate= toFormat.format(date);
        seleniumCommands.staticWait(2);
        seleniumCommands.type(EFFECTIVE_DATE_FIELD, DateUtil.getFutureDate(366));
        seleniumCommands.focusOff();
        return this;
    }
    
    @Override
    public ICancelPolicyDetailsPage setDateWithinPolicyPeriod() {
        seleniumCommands.logInfo("Filling Effective Date field with date, next to policy expiration.");
        DateFormat fromFormat = new SimpleDateFormat("yyyy-MM-dd");
        fromFormat.setLenient(false);
        DateFormat toFormat = new SimpleDateFormat("MM/dd/yyyy");
        toFormat.setLenient(false);

        String expirationDate = ThreadLocalObject.getData().get(PolicyData.POLICY_EXPIRATION_DATE.toString()).split("T")[0];
        LocalDate nextToExpidationDate = LocalDate.parse(expirationDate).plusDays(1);

        Date date = null;
        try {
            date = fromFormat.parse(nextToExpidationDate.toString());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        expirationDate= toFormat.format(date);
        seleniumCommands.staticWait(2);
        seleniumCommands.type(EFFECTIVE_DATE_FIELD, DateUtil.getFutureDate(5));
        seleniumCommands.focusOff();
        return this;
    }

    @Override
    public IBindPolicyCancellationPage submitCancellation() {
        seleniumCommands.waitForElementToBeClickable(SUBMIT_BUTTON_CSS);
        new Button(SUBMIT_BUTTON_CSS).click();
        seleniumCommands.waitForLoaderToDisappearFromPage();
       // seleniumCommands.waitForElementToBeVisible(By.cssSelector("button[ng-click='withdrawCancellationByCancellationNumber(cancellationNumber)']"));
        return thisOrNull(IBindPolicyCancellationPage.class);
    }

    public QuoteCancellationOnPolicyScenario clickSubmitCancellationButton() {
        seleniumCommands.waitForElementToBeClickable(SUBMIT_BUTTON_CSS);
        new Button(SUBMIT_BUTTON_CSS).click();
        return this;
    }

    public QuoteCancellationOnPolicyScenario checkStartCancellationButtonIsDisabled() {
        new Validation(SUBMIT_BUTTON_CSS.getAttribute("ng-disabled").equals("!effectiveDateValidation.isValid")).shouldBeTrue("Effective Date is Valid");
        new Validation(SUBMIT_BUTTON_CSS.getAttribute("disabled").equals("true")).shouldBeTrue("Start Cancellation is not disabled");
        return this;
    }

    public Validation checkIfPolicyCancellationIsQuoted() {
        return new Validation(checkIfPolicyCancellationHasCorrectStatus("Quoted"));
    }

    protected boolean checkIfPolicyCancellationHasCorrectStatus(String status) {
        String jobNumber = seleniumCommands.getTextAtLocator(CANCELLATION_NUMBER_CSS).replaceAll("[^0-9]", "");

        String result = DataFetch.getAgentPolicyTransactionsForPolicy("su", policyNum);
        List<HashMap<String, String>> policyTransactions = new JsonPath(result).get();

        return policyTransactions.stream().anyMatch(transaction ->
                transaction.get("jobNumber").equals(jobNumber)
                        && transaction.get("status").equals(status)
                        && transaction.get("type").equals("Cancellation")
        );
    }
}
