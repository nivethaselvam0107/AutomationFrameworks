package com.guidewire.capabilities.agent.data;

import com.guidewire.common.util.EnumHelper;
/**
 * @author dgangwar@guidewire.com
 */
public enum DocumentData {
		DOC_TYPE("DocType"), 
		DOC_MIME_TYPE("DOC_MIME_TYPE"), 
		DOC_AUTHOR("DOC_AUTHOR"), 
		DOC_MODIFIED_DATE("DOC_MODIFIED_DATE"), 
		DOC_SECURITY_TYPE("DOC_SECURITY_TYPE"),
		DOC_NAME("DOC_NAME"),
		DOC_CAN_DELETE("DOC_CAN_DELETE"),
		DOC_STATUS("DOC_STATUS");

	private final String propertyName;

	DocumentData(final String propertyName) {
		this.propertyName = propertyName;
	}

	@Override
	public String toString() {
		return this.propertyName;
	}

	public static DocumentData fromString(String name) {
		return EnumHelper.fromString(DocumentData.class, name);
	}
}
