package com.guidewire.capabilities.agent.data;

import com.guidewire.common.util.EnumHelper;
/**
 * @author dgangwar@guidewire.com
 */
public enum BillingData {

	PERIOD_PERIOD("PERIOD_PERIOD"), 
	STATUS("STATUS"), 
	CURRENT_PAYMENT("CURRENT_PAYMENT"), 
	PAST_DUE("PAST_DUE"), 
	ALREADY_PAID("ALREADY_PAID"), 
	UNBILLED("UNBILLED"), 
	TOTAL_CHARGES("TOTAL_CHARGES"),
	TOTAL_DUE("TOTAL_DUE"), 
	DUE("DUE"),
	BILLING_METHOD("BILLING_METHOD"), 
	PAYMENT_PLAN("PAYMENT_PLAN"), 
	ALT_BILLING_PLAN("ALT_BILLING_PLAN"), 
	INVOICE_COUNT("INVOICE_COUNT"), 
	INVOICING("INVOICING");

	private final String propertyName;

	BillingData(final String propertyName) {
		this.propertyName = propertyName;
	}

	@Override
	public String toString() {
		return this.propertyName;
	}

	public static BillingData fromString(String name) {
		return EnumHelper.fromString(BillingData.class, name);
	}
}
