/**
 * 
 */
package com.guidewire.capabilities.agent.data;

import com.guidewire.common.util.EnumHelper;

/**
 * @author dgangwar@guidewire.com
 *
 */
public enum AgentUserName {

	    BWHITE("Ben White"),
	    CARKLE("Charles Arkle"),
	    AARMSTRONG("Archie Armstrong"),
		BBAKER("bruce baker");

	    private final String agentName;

	    AgentUserName(final String agentName) {
	        this.agentName = agentName;
	    }

	    @Override
	    public String toString() {
	        return this.agentName;
	    }

	    public static AgentUserName fromString(String name) {
	        return EnumHelper.fromString(AgentUserName.class, name);
	    }
	    
	    public static String getValueByUname(String name) {
		for (AgentUserName uname : AgentUserName.values())
		{
		    if(uname.name().equalsIgnoreCase(name))
			    {
				return uname.agentName;
			    }
		}
		return null;
	    }
	    
	    public static void main(String[] args) {
		
	    }
}