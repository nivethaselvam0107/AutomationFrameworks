package com.guidewire.capabilities.agent.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;
/**
 * @author dgangwar@guidewire.com
 */
public class ParseDocumentData {

	static SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	public static List<HashMap<String, String>> getPolicyDocumentDataFromBackEnd(String jsonData) {
		JsonPath jsonpath = new JsonPath(jsonData);
		List<HashMap<String, String>> notesDataList= new ArrayList<>();
		seleniumCommands.logInfo("Parsing notes data from backend");
		int notesCount = jsonpath.getList("subject").size();
		for(int i=0; i<notesCount; i++)
		{
			HashMap<String, String> noteData = new HashMap<>();
			String iteration = "[" +i+ "].";
			noteData.put(DocumentData.DOC_AUTHOR.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "author"));
			noteData.put(DocumentData.DOC_MIME_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "mimeType"));
			noteData.put(DocumentData.DOC_SECURITY_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "securityType"));
			noteData.put(DocumentData.DOC_NAME.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "name"));
			noteData.put(DocumentData.DOC_CAN_DELETE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "canDelete"));
			noteData.put(DocumentData.DOC_STATUS.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "status"));
			noteData.put(DocumentData.DOC_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "documentType"));
			notesDataList.add(noteData);
		}
		return notesDataList;
	}

	public static List<HashMap<String, String>> getClaimDocumentDataFromBackEnd(String jsonData) {
		JsonPath jsonpath = new JsonPath(jsonData);

		List<HashMap<String, String>> documentsDataList= new ArrayList<>();
		seleniumCommands.logInfo("Parsing documents data from backend");
		int docsCount = jsonpath.getList("documents").size();
		for(int i=0; i<docsCount; i++)
		{
			HashMap<String, String> docData = new HashMap<>();
			String iteration = "documents[" +i+ "].";
			docData.put(DocumentData.DOC_AUTHOR.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "author"));
			docData.put(DocumentData.DOC_MIME_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "mimeType"));
			docData.put(DocumentData.DOC_SECURITY_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "securityType"));
			docData.put(DocumentData.DOC_NAME.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "name"));
			docData.put(DocumentData.DOC_CAN_DELETE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "canDelete"));
			docData.put(DocumentData.DOC_STATUS.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "status"));
			docData.put(DocumentData.DOC_TYPE.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + "documentType"));
			documentsDataList.add(docData);
		}
		return documentsDataList;
	}

	public static void main(String[] args) {
		System.out.println(getPolicyDocumentDataFromBackEnd(DataFetch.getAgentPolicyDocumentAsSU("4674312958")));
	}
	
}
