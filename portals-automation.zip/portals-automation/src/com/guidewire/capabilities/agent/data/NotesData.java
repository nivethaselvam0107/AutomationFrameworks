package com.guidewire.capabilities.agent.data;

import com.guidewire.common.util.EnumHelper;
/**
 * @author dgangwar@guidewire.com
 */
public enum NotesData {
		NOTE_AUTHOR("NoteAuthor"), 
		NOTE_TOPIC("NoteTopic"), 
		NOTE_BODY("NoteText"), 
		NOTE_SUBJECT("NoteSubject");

	private final String propertyName;

	NotesData(final String propertyName) {
		this.propertyName = propertyName;
	}

	@Override
	public String toString() {
		return this.propertyName;
	}

	public static NotesData fromString(String name) {
		return EnumHelper.fromString(NotesData.class, name);
	}
}
