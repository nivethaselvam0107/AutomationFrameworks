/**
 * 
 */
package com.guidewire.capabilities.agent.data;

import com.guidewire.common.util.EnumHelper;

/**
 * @author dgangwar@guidewire.com
 *
 */
public enum ActivityData {

	SUBJECT("SUBJECT"), STATUS("STATUS"), COMPLETED_DATE("COMPLETED_DATE"), ACCOUNT_NAME(
			"ACCOUNT_NAME"), ACCOUNT_NUMBER("ACCOUNT_NUMBER"), ASSIGNED_TO("ASSIGNED_TO"), CAN_COMPLETE(
					"CAN_COMPLETE"), CREATED_BY("CREATED_BY"), ASSIGNED_TO_ME("ASSIGNED_TO_ME");

	private final String propertyName;

	ActivityData(final String propertyName) {
		this.propertyName = propertyName;
	}

	@Override
	public String toString() {
		return this.propertyName;
	}

	public static ActivityData fromString(String name) {
		return EnumHelper.fromString(ActivityData.class, name);
	}
}
