package com.guidewire.capabilities.agent.data;

import java.util.HashMap;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;
/**
 * @author dgangwar@guidewire.com
 */
public class ParsePolicyBillingData {

	static SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	public static HashMap<String, String> getPolicyDocumentDataFromBackEnd(String jsonData) {
		JsonPath jsonpath = new JsonPath(jsonData);
		HashMap<String, String> billingData= new HashMap<>();
		seleniumCommands.logInfo("Parsing notes data from backend");
		String billingSummary = "policyPeriodBillingSummaries[0].";
		int invoiceCount = jsonpath.getList("policyPeriodBillingSummaries[0].invoices").size();
		DataFormatUtil.putData(billingData, BillingData.PERIOD_PERIOD.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary, "periodName"));
		DataFormatUtil.putData(billingData, BillingData.CURRENT_PAYMENT.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary+"currentOutstandingAmount", "amount"));
		DataFormatUtil.putData(billingData, BillingData.PAST_DUE.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary+"pastDueAmount" , "amount"));
		DataFormatUtil.putData(billingData, BillingData.ALREADY_PAID.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary+"paidAmount" , "amount"));
		DataFormatUtil.putData(billingData, BillingData.UNBILLED.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary+"unbilledAmount" , "amount"));
		DataFormatUtil.putData(billingData, BillingData.TOTAL_CHARGES.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary+"totalCharges" , "amount"));
		DataFormatUtil.putData(billingData, BillingData.BILLING_METHOD.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary , "billingMethod"));
		DataFormatUtil.putData(billingData, BillingData.PAYMENT_PLAN.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary , "paymentPlan"));
		DataFormatUtil.putData(billingData, BillingData.ALT_BILLING_PLAN.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary , "altpaymentPlan"));
		DataFormatUtil.putData(billingData, BillingData.INVOICING.toString(), DataFormatUtil.getNodeValue(jsonpath, billingSummary ,"invoiceStream"));
		Double dueAmount = Double.parseDouble(billingData.get(BillingData.CURRENT_PAYMENT.toString())) + Double.parseDouble(billingData.get(BillingData.PAST_DUE.toString()));
		DataFormatUtil.putData(billingData, BillingData.DUE.toString(), dueAmount +"");
		DataFormatUtil.putData(billingData, BillingData.TOTAL_DUE.toString(), billingData.get(BillingData.DUE.toString()));
		DataFormatUtil.putData(billingData, BillingData.INVOICE_COUNT.toString(), invoiceCount+"");
		return billingData;
			
	}
	
	public static void main(String[] args) {
		System.out.println(getPolicyDocumentDataFromBackEnd(DataFetch.getAgentPolicyBillingDataAsSU("3841329843")));
	}
	
}
