package com.guidewire.capabilities.agent.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;
/**
 * @author dgangwar@guidewire.com
 */
public class ParseNotesData {

	static SeleniumCommands seleniumCommands = new SeleniumCommands();
	
	public static List<HashMap<String, String>> getPolicyNotesDataFromBackEnd(String jsonData) {
		JsonPath jsonpath = new JsonPath(jsonData);
		List<HashMap<String, String>> notesDataList= new ArrayList<>();
		seleniumCommands.logInfo("Parsing notes data from backend");
		int notesCount = jsonpath.getList("subject").size();
		for(int i=0; i<notesCount; i++)
		{
			HashMap<String, String> noteData = new HashMap<>();
			String iteration = "[" +i+ "]";
			noteData.put(NotesData.NOTE_AUTHOR.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + ".authorName"));
			noteData.put(NotesData.NOTE_SUBJECT.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + ".subject"));
			noteData.put(NotesData.NOTE_TOPIC.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + ".topic"));
			noteData.put(NotesData.NOTE_BODY.toString(),DataFormatUtil.getNodeValue(jsonpath, iteration + ".body"));			
			notesDataList.add(noteData);
		}
		return notesDataList;
	}
	
	public static void main(String[] args) {
		System.out.println(getPolicyNotesDataFromBackEnd(DataFetch.getAgentPolicyNotesDataAsSU("4674312958")));
	}
	
}
