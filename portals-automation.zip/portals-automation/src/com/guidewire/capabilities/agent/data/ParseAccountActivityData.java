/**
 * 
 */
package com.guidewire.capabilities.agent.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;

import io.restassured.path.json.JsonPath;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class ParseAccountActivityData {
    
    private HashMap<String, String> data = ThreadLocalObject.getData();
    private static Logger LOGGER = Logger.getLogger(ParseAccountActivityData.class);

	public static int getTotalActivityCountFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		LOGGER.info("Total actvity count ->>>>>>>>>" +path.getList("status").size());
		return path.getList("status").size();
	}
	
	public static int getMyOpenActivityCountFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return path.getList("createdBy").size();
	}
	
	public static int getMyCompletedActivityCountFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return path.getList("createdBy").size();
	}
	
	public static int getAllActivityCreatedByMeCountFromBackEnd(String jsonData) {
	    JsonPath path = new JsonPath(jsonData);
	    return path.getList("createdBy").size();
	}
	
	public static int getAllOpenActivityCountFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return path.getList("createdBy").size();
	}

	public static int getAllCompletedActivityCountFromBackEnd(String jsonData) {
		JsonPath path = new JsonPath(jsonData);
		return path.getList("createdBy").size();
	}
	
	
	public static List<HashMap<String, String>> getAllOpenActivityDataFromBackEnd(String jsonData)
	{
	    	JsonPath jsonPath = new JsonPath(jsonData);
		String statusPath = "[ITERATION]";
		List<HashMap<String, String>> activityList = new ArrayList<>();
		HashMap<String, String> activityData = null;
		String status = ".status";
		for(int i =0; i< getTotalActivityCountFromBackEnd(jsonData); i++)
		{
		    String iteration = statusPath.replace("ITERATION", i+"");
		    activityData = new HashMap<>();
		    if("open".equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration + status)))
		    {
			activityList.add(setActivityData(activityData, jsonPath, iteration));
		    }
		}
		
		LOGGER.info("All Open activites count ===>>>" + activityList.size());
		return activityList;
	}
	
	public static List<HashMap<String, String>> getAllCompletedActivityDataFromBackEnd(String jsonData)
	{
	    	JsonPath jsonPath = new JsonPath(jsonData);
		String statusPath = "[ITERATION]";
		List<HashMap<String, String>> activityList = new ArrayList<>();
		HashMap<String, String> activityData = null;
		String status = ".status";
		for(int i =0; i< getTotalActivityCountFromBackEnd(jsonData); i++)
		{
		    String iteration = statusPath.replace("ITERATION", i+"");
		    activityData = new HashMap<>();
		    if("complete".equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration + status)))
		    {
			activityList.add(setActivityData(activityData, jsonPath, iteration));
		    }
		}
		LOGGER.info("All Completed activites count ===>>>" + activityList.size());
		return activityList;
	}
	
	
	public static List<HashMap<String, String>> getAllMyOpenActivityDataFromBackEnd(String jsonData)
	{
	    JsonPath jsonPath = new JsonPath(jsonData);
	    String statusPath = "[ITERATION]";
	    List<HashMap<String, String>> activityList = new ArrayList<>();
	    HashMap<String, String> activityData = null;
	    String status = ".status";
	    String createdByMe = ".assignedTo.displayName";
	    for(int i =0; i< getTotalActivityCountFromBackEnd(jsonData); i++)
	    {
		String iteration = statusPath.replace("ITERATION", i+"");
		activityData = new HashMap<>();
		if("open".equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration + status)) && ThreadLocalObject.getData().get("USER_NAME").equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration+createdByMe)))
		{
		    activityList.add(setActivityData(activityData, jsonPath, iteration));
		}
	    }
	    LOGGER.info("My Open activites count ===>>>" + activityList.size());
	    return activityList;
	}
	
	public static List<HashMap<String, String>> getAllCreatedByMeActivityDataFromBackEnd(String jsonData)
	{
	    	JsonPath jsonPath = new JsonPath(jsonData);
		String statusPath = "[ITERATION]";
		List<HashMap<String, String>> activityList = new ArrayList<>();
		HashMap<String, String> activityData = null;
		String createdBy = ".createdBy";
		for(int i =0; i< getTotalActivityCountFromBackEnd(jsonData); i++)
		{
		    String iteration = statusPath.replace("ITERATION", i+"");
		    activityData = new HashMap<>();
		    if(ThreadLocalObject.getData().get("USER_NAME").equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration+ createdBy))) 
		    {
			activityList.add(setActivityData(activityData, jsonPath, iteration));
		    }
		}
		LOGGER.info("All created by me activites count ===>>>" + activityList.size());
		return activityList;
	}
	
	public static List<HashMap<String, String>> getAllMyCompletedActivityDataFromBackEnd(String jsonData)
	{
	    	JsonPath jsonPath = new JsonPath(jsonData);
		String statusPath = "[ITERATION]";
		List<HashMap<String, String>> activityList = new ArrayList<>();
		HashMap<String, String> activityData = null;
		String assignee = ".assignedTo.displayName";
		String status = ".status";
		for(int i =0; i< getTotalActivityCountFromBackEnd(jsonData); i++)
		{
		    String iteration = statusPath.replace("ITERATION", i+"");
		    activityData = new HashMap<>();
		    if("complete".equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath,  iteration + status)) && ThreadLocalObject.getData().get("USER_NAME").equalsIgnoreCase(DataFormatUtil.getNodeValue(jsonPath, iteration+assignee))) 
		    {
			activityList.add(setActivityData(activityData, jsonPath, iteration));
		    }
		}
		LOGGER.info("My Completed activites count ===>>>" + activityList.size());
		return activityList;
	}

	private static HashMap<String, String> setActivityData(HashMap<String, String> activityData, JsonPath jsonPath,
			String iteration) {
		activityData.put(ActivityData.SUBJECT.toString(),
				DataFormatUtil.getNodeValue(jsonPath, iteration + ".subject"));
		activityData.put(ActivityData.ASSIGNED_TO.toString(), "Me");
		activityData.put(ActivityData.STATUS.toString(), DataFormatUtil.getNodeValue(jsonPath, iteration + ".status"));
		activityData.put(ActivityData.CREATED_BY.toString(),
				DataFormatUtil.getNodeValue(jsonPath, iteration + ".createdBy"));
		activityData.put(ActivityData.ACCOUNT_NAME.toString(),
				DataFormatUtil.getNodeValue(jsonPath, iteration + ".accountHolderName"));
		return activityData;
	}
	
}
