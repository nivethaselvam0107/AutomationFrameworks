package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.data.QuoteScheduledPropertyItem;
import com.guidewire.portals.qnb.pages.HOPolicyInfoPage;
import com.guidewire.portals.qnb.pages.HOQuotePage;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.scheduleditemComponant.PropertyLocationModel;

/**
 * Created by dfedo on 07/12/2016.
 */
public class HOScheduledItemsTest {

String platform = System.getProperty("platform");

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR" }, description = "TC4138 : AddScheduledPersonalPropertyItemForHO: Verify user can add Scheduled Personal Property Item for HO")
    public void testAddScheduledPersonalPropertyItemForHO(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
        if(platform.equalsIgnoreCase("granite")){
        hoQuotePage.addPersonalPropertyGranite();
        }else{
        hoQuotePage.addPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
        }
        hoQuotePage.reCalculatePolicyPremium()
        .buyBasePolicyWithMonthlyPremium()
        .goToPolicyInfoPage()
        .setPolicyInfoPageDetails()
        .goToPaymentDetailsPage();
        new PaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        new PolicyConfirmationPage().isPolicyConfirmationPageDisplayed();
        new PolicyConfirmationPage().validatePersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC4139: MissingMandatoryValuesWhileAddingScheduledPersonalProperty : Verify validation message is displayed when user tries to add a scheduled personal property item.")
    public void testMissingMandatoryValuesWhileAddingScheduledPersonalProperty(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO()
                .clickAddScheduleredPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY)
                .submitScheduledPersonalProperty()
                .validateMandatoryFieldsOfScheduledPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = "TC4146 : AddSpecialLimitsPersonalProperty:  Verify user can add Special Limits Personal Property Item for HO")
    public void testAddSpecialLimitsPersonalProperty(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO().addPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY)
                .reCalculatePolicyPremium()
                .buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails().goToPaymentDetailsPage();
        new PaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        new PolicyConfirmationPage().isPolicyConfirmationPageDisplayed();
        new PolicyConfirmationPage().validatePersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4148:EditSpecialLimitsPersonalProperty")
    public void testEditSpecialLimitsPersonalProperty(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
		hoQuotePage.addPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY);
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.editFirstScheduledPersonalProperty()
        			.buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails();
        MapCompare.compareMap(new PolicyConfirmationPage().getScheduledPersonalPropertyData(), ThreadLocalObject.getData());
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =hoPolicyInfoPage.goToPaymentDetailsPage()
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4149:RemoveSpecialLimitsPersonalProperty, TC4175:RemoveSpecialLimitsPersonalProperty")
    public void testDeleteSpecialLimitsPersonalProperty(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
		hoQuotePage.addPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY);
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.deleteFirstProperty()
                .buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		new Validation(ParseQuoteData.getSpecialScheduledPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Special Scehduled property was available in backend");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite" }, description = "TC4143 MissingMandatoryValuesWhileAddingSpecialLimitsPersonalProperty: Verify validation message is displayed when user tries to add a special limits personal property item.")
    public void testMissingMandatoryValuesWhileAddingSpecialLimitsPersonalProperty(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO()
                .clickAddScheduleredPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY)
                .submitScheduledPersonalProperty()
                .validateMandatoryFieldsOfScheduledPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" , "CSR"}, description = "TC4142 AddOtherStructuresOnTheResidencePremises: Verify user can add Other Structures on the Residence Premises for HO")
    public void testAddOtherStructuresOnTheResidencePremises(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO().addPersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES)
                .reCalculatePolicyPremium()
                .buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails().goToPaymentDetailsPage();
        new PaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        new PolicyConfirmationPage().isPolicyConfirmationPageDisplayed();
        new PolicyConfirmationPage().validatePersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4144:EditOtherStructuresOnTheResidencePremises")
    public void testEditOtherStructuresOnTheResidencePremises(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
		hoQuotePage.addOtherStructureOnPremisesProperty();
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.editFirstOtherStructureOnPremisesProperty()
        			.buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails();
        MapCompare.compareMap(new PolicyConfirmationPage().getOtherStructureOnResidencePremisePropertyData(), ThreadLocalObject.getData());
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =hoPolicyInfoPage.goToPaymentDetailsPage()
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOOtherStructuresOnTheResidencePremisesPropertyDataWithBackEnd(jsonQuotePolicydata);
   }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = "TC4145:RemoveOtherStructuresOnTheResidencePremises, CSR -> TC4174:RemoveOtherStructuresOnTheResidencePremises")
    public void testRemoveOtherStructuresOnTheResidencePremises(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
		hoQuotePage.addOtherStructureOnPremisesProperty();
		PaymentDetailsPage paymentDetailsPage = hoQuotePage.deleteFirstProperty()
                .buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		new Validation(ParseQuoteData.getOtherStructuresOnTheResidencePremisesPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("OtherStructuresOnTheResidencePremises property was available in backend");
   }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4147 MissingMandatoryValuesWhileAddingOtherStructuresOnTheResidencePremises:  Verify validation message is displayed when user tries to add Other Structures On The Residence Premises")
    public void testMissingMandatoryValuesWhileAddingOtherStructuresOnTheResidencePremises(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO()
                .clickAddScheduleredPersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES)
                .submitScheduledPersonalProperty()
                .validateMandatoryFieldsOfScheduledPersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4158:VerifyScheduledItemsInPC")
    public void testVerifyScheduledItemsInPC(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO()
                .addPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY)
                .addPersonalProperty(QuoteScheduledPropertyItem.SPECIAL_LIMITS_PERSONAL_PROPERTY)
                .addPersonalProperty(QuoteScheduledPropertyItem.OTHER_STRUCTURES)
                .reCalculatePolicyPremium()
                .buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage().setPolicyInfoPageDetails().goToPaymentDetailsPage();
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        new PaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        PolicyConfirmationPage confirmationPage = new PolicyConfirmationPage();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        confirmationPage.validateHOSpecialScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
        confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
        confirmationPage.validateHOOtherStructuresOnTheResidencePremisesPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
    @Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite", "CSR" }, description = "TC4140:EditScheduledPersonalPropertyItemForHO , CSR -> TC4165:EditScheduledPersonalPropertyItemForHO")
	public void testEditScheduledPersonalPropertyItemForHO(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
		hoQuotePage.addPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.editFirstScheduledPersonalProperty()
        			.buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails();
        MapCompare.compareMap(new PolicyConfirmationPage().getScheduledPersonalPropertyData(), ThreadLocalObject.getData());
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =hoPolicyInfoPage.goToPaymentDetailsPage()
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
	}
    
    @Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" , "CSR" }, description = "TC4141:RemoveScheduledPersonalPropertyItemForHO , CSR -> TC4173:RemoveScheduledPersonalPropertyItemForHO")
	public void testRemoveScheduledPersonalPropertyItemForHO(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundHOPolicy();
		HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .getToQuotePageForHO();
        if(platform.equalsIgnoreCase("granite")){
        hoQuotePage.addPersonalPropertyGranite();
        }else{
        hoQuotePage.addPersonalProperty(QuoteScheduledPropertyItem.SCHEDULED_PERSONAL_PROPERTY);
        }
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.deleteFirstProperty()
                .buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		new Validation(ParseQuoteData.getScheduledPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Scehduled property was available in backend");
	}
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = " TC4150:AddPersonalPropertyAtOtherResidences, CSR-> TC4172: AddPersonalPropertyAtOtherResidences")
    public void testAddPersonalPropertyAtOtherResidences(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","10%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.addPersonalPropertyAOtherResidence()
                .reCalculatePolicyPremium()
                .buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        MapCompare.compareMap(new PolicyConfirmationPage().getPersonalPropertyOnOtherResidenceData(), ThreadLocalObject.getData());
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        confirmationPage.validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = "TC4152:EditPersonalPropertyAtOtherResidences")
    public void testEditPersonalPropertyAtOtherResidences(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","10%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        hoQuotePage.addPersonalPropertyAOtherResidence();
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.editFirstPersonalPropertyOnOtherPremises()
                .buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        MapCompare.compareMap(new PolicyConfirmationPage().getPersonalPropertyOnOtherResidenceData(), ThreadLocalObject.getData());
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPersonalPropertyAtOtherResidencesPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = " TC4153:RemovePersonalPropertyAtOtherResidences, CSR-> TC4176: RemovePersonalPropertyAtOtherResidences")
    public void testRemovePersonalPropertyAtOtherResidences(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","10%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        hoQuotePage.addPersonalPropertyAOtherResidence();
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.deleteFirstProperty().
                buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        new Validation(ParseQuoteData.getPersonalPropertyAtOtherResidencesDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Scehduled property was available in backend");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite"}, description = " TC4151:MandatoryFieldsPersonalPropertyAtOtherResidences")
    public void testMissingMandatoryFieldsPersonalPropertyAtOtherResidences(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        hoQuotePage.clickAddScheduleredPersonalProperty(3);
        new PropertyLocationModel().validateNewLocationPopUpMandatoryFields();
    }
    
    //This test will fail once DE5899 is fixed TODO
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = " TC4154:AddSpecificStructuresAwayFromTheOtherResidencePremises, CSR-> TC4171: AddSpecificStructuresAwayFromTheOtherResidencePremises")
    public void testAddSpecificStructuresAwayFromTheOtherResidencePremises(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","10%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        		hoQuotePage.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty();
                hoQuotePage.reCalculatePolicyPremium();
        MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
      //MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        confirmationPage.validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
  //This test will fail once DE5899 is fixed TODO
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = " TC4156:EditSpecificStructuresAwayFromTheOtherResidencePremises")
    public void testEditSpecificStructuresAwayFromTheOtherResidencePremises(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","5%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        		hoQuotePage.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty();
        		//MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
                hoQuotePage.reCalculatePolicyPremium();
                hoQuotePage.editFirstSpecificStructuresAwayFromTheOtherResidencePremisesProperty();
        MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
      //MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        confirmationPage.validateHOSpecificStructuresAwayFromTheOtherResidencePremisesDataFromBackEndPropertyDataWithBackEnd(jsonQuotePolicydata);
    }
    
  //This test will fail once DE5899 is fixed TODO
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite", "CSR"}, description = " TC4157:RemoveSpecificStructuresAwayFromTheOtherResidencePremises, CSR-> TC4177: RemoveSpecificStructuresAwayFromTheOtherResidencePremises")
    public void testRemoveSpecificStructuresAwayFromTheOtherResidencePremises(String browserName) throws Exception {
    	ThreadLocalObject.getData().put("SchedulePropertyLimit","10%");
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        		hoQuotePage.addSpecificStructuresAwayFromTheOtherResidencePremisesProperty();
        		//MapCompare.compareMap(new PolicyConfirmationPage().getSpecificStructuresAwayFromTheResidencePremisesData(), ThreadLocalObject.getData());
                hoQuotePage.reCalculatePolicyPremium();
                hoQuotePage.deleteFirstProperty();
        HOPolicyInfoPage hoPolicyInfoPage = hoQuotePage.buyBasePolicyWithMonthlyPremium().goToPolicyInfoPage();
        String quoteNum = new QuoteInfoBar().getSubmissionNumber();
        PolicyConfirmationPage confirmationPage = hoPolicyInfoPage.setPolicyInfoPageDetails().goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        confirmationPage.isPolicyConfirmationPageDisplayed();
        String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
        new Validation(ParseQuoteData.getSpecialScheduledPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Scehduled property was available in backend");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite" }, description = " TC4155:MandatoryFieldsSpecificStructuresAwayFromOtherResidencesPremises")
    public void testMissingMandatoryFieldsSpecificStructuresAwayFromTheOtherResidencePremises(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        HOQuotePage hoQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuotePageForHO();
        hoQuotePage.clickAddScheduleredPersonalProperty(4);
        new PropertyLocationModel(4).validateNewLocationPopUpMandatoryFields();
    }

}
