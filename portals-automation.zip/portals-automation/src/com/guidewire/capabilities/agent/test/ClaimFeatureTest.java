package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.ClaimsLanding;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;

/**
 * Created by dfedo on 14/12/2016.
 */
public class ClaimFeatureTest {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3830: AddDocToClaim: Verify user can upload a valid document to a personal auto claim and it gets added in CC.")
    public void testAddDocToClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().uploadDocument(claimNumber)
                .isDocAdded().shouldBeEqual("Document was not uploaded");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3831:ClaimsDetailsPage")
    public void testClaimsDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory()
        			.createCollisionClaim()
        			.withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();
        new NewClaimConfirmationPage().goToAccountSummaryPage();
        ClaimsTileView claimView = new AccountSummary().goToClaimTile();
        claimView.selectClaim(claimNumber)
                .isClaimSummaryDataForAgentMatchingWithBackEnd(claimNumber);
        new ClaimSummaryPage().openNoteTab()
                .addANewNote()
                .validateNotePageElements();
        new ClaimSummaryPage().openDocTab()
                .uploadDocFromSummary()
                .validateDocPageElementsOnClaimSummary();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3832: ViewPolicyFromClaimsPage: Verify user can view policy details page from Claims page")
    public void testViewPolicyFromClaimsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
       new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectPolicy(ThreadLocalObject.getData().get("POLICY_NUM"))
                .isPolicyDetailsPageLoaded();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC3833: ClaimFilterOnAccDetails: Verify Claim Filter field on Account's Active Claims page")
    public void testClaimFilterOnAccDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        new PAQuotePage().buyQuotedPolicy().goToAccountDetailPage()
                .goToClaimTile()
                .createPACollisionClaim();
        new ClaimsTileView().createPACollisionClaimTillConfirmationPage()
        .goToAccountSummary().goToClaimTile()
                .validateLOBDropDown();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3834: ViewPolicyFromClaimsDetailsPage: Verify user can view Policy details page from Claims Details page")
    public void testViewPolicyFromClaimsDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .clickPolicyNumber()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy Details page is not presented");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3835:ViewAccountFromClaimsDetailsPage: Verify user view Account details page from Claims details page")
    public void testViewAccountFromClaimsDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .clickAccountNumber()
                .isAccountPageLoaded().shouldBeTrue("Account page is not presented");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3836:ViewInsuredDetailsOnClaimsDetails: Verify user can view insured details when on Claims details page")
    public void testViewInsuredDetailsOnClaimsDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .clickInvolvedPartiesByAccountName()
                .isPartiesInvolvedDetailsDataMatchingWithBackEnd(claimNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "CSR", "CSR_DIA"} , description = "TC3837: LossDateInFutureWhileFilingAClaim")
    public void testLossDateInFutureWhileFilingAClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_ClaimPagefactory().getNewClaim()
                .withClaimDateOfLoss(DateUtil.getDateIn12HrsFormat(1))
                .isNextButtonDisabledBeforePolicySelection().shouldBeTrue("Data validation Error message is incorrect");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR"} , description = "TC3838:CannotFileAClaimForScheduledPolicyOnAccountDetailsPage")
    public void testCannotFileAClaimForScheduledPolicyOnAccountDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        String policyNumber= new PAQuotePage().buyQuotedPolicy()
                .getPolicyNumber();
        new PolicyConfirmationPage().goToAccountDetailPage()
                .goToClaimTile()
                .goToMakeAClaim()
                .isPolicyListedForSelection(policyNumber).shouldBeFalse("Policy is listed while it shouldn't.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3839: CannotFileAClaimForScheduledPolicyOnPolicyDetailsPage: Verify user can file a claim for scheduled policy on policy details page")
    public void testCannotFileAClaimForScheduledPolicyOnPolicyDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        String policyNumber= new PAQuotePage().buyQuotedPolicy()
                .getPolicyNumber();
        new PolicyConfirmationPage().goToPolicies()
                .showRecentlyIssued()
                .goToPolicySummary(policyNumber)
                .goToClaimTile()
                .isFileClaimButtonPresent().shouldBeFalse("File a claim button is present while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3840: ClaimAndPolicyDetailsinClaimCenter Verify Claim and Policy details in Claim Center.")
    public void testClaimAndPolicyDetailsinClaimCenter(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .isClaimSummaryDataForAgentMatchingWithBackEnd(claimNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3846: DeleteClaimDocument Verify user can delete uploaded document on Claims details page")
    public void testDeleteClaimDocument(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().uploadDocument(claimNumber)
                .deleteDoc()
                .isDocTableEmpty().shouldBeTrue("Document was not deleted");
        new DocumentsTab().validateClaimDocumentDataWithBackEnd(claimNumber).shouldBeFalse("Document data doesn't match with the backend");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3847: ReferenceNumberFormat Verify right format of reference number is created when FNOL is submitted")
    public void testReferenceNumberFormat(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
       new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaimTillConfirmationPage()
               .validateReferenceNumberFormat().shouldBeTrue("Reference number doesn't match format");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3848: PAClaimOnPolicyDetailPage Verify user can file a claim on Policy details page of type Personal Auto")
    public void testPAClaimOnPolicyDetailPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPageTroughPolicies()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .isClaimSummaryDataForAgentMatchingWithBackEnd(claimNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3849: AddNoteToAdjusterOnClaimsDetails Verify user can add a note to adjuster on claims details page")
    public void testAddNoteToAdjusterOnClaimsDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new ClaimsTileView().selectClaim(claimNumber)
                .addNote()
                .addNoteDetails()
                .openNoteTab()
                .isNotesAdded();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3857: ViewAccountDetailsFromLandingClaims: Verify user can view account details page from claims landing page")
    public void testViewAccountDetailsFromLandingClaims(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        String accountName = ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString())+ " " + ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString());
        new NavBar().goToClaimsLanding()
                .clickAccountName(accountName)
                .isAccountSummaryPageLoaded().shouldBeTrue("Accont page is not presented correctly.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3858: ViewPolicyDetailsFromLandingClaims Verify user can view policy details page from claims landing page")
    public void testViewPolicyDetailsFromLandingClaims(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        String policyNumber = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
        new NavBar().goToClaimsLanding().clickPolicyNumber(policyNumber).isPolicyDetailsPageLoaded().shouldBeTrue("Policy Details page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3859: ViewClaimDetailsFromLandingClaims Verify user can view claims details page from claims landing page")
    public void testViewClaimDetailsFromLandingClaims(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new NavBar().goToClaimsLanding().clickClaimNumber(claimNumber).isClaimSummaryPageLoaded().shouldBeTrue("Claim summary page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3860: RecentlyViewedTileOnClaimsLanding Verify recentlly viewed tile on claims landind page")
    public void testRecentlyViewedTileOnClaimsLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new NavBar().goToClaimsLanding()
                .validateClaimIsPresent(claimNumber).shouldBeFalse("Claim is present in viewed claims while it shouldn't");
        new ClaimsLanding().clickClaimNumber(claimNumber)
                .isClaimSummaryPageLoaded().shouldBeTrue("Claim summary page was not loaded");
        new NavBar().goToClaimsLanding()
                .validateClaimIsPresent(claimNumber).shouldBeTrue("Claim is not present in viewed claims while it should");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3861: RecentlyCreatedTileOnClaimsLanding: Verify recenlty created tile on claims landing page")
    public void testRecentlyCreatedTileOnClaimsLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNumber = new GPA_ClaimPagefactory().goToAccountsClaimsPage()
                .createPACollisionClaim();
        new NavBar().goToClaimsLanding()
                .showRecentlyCreated()
                .validateClaimIsPresent(claimNumber).shouldBeTrue("Claim is not present in viewed claims while it should");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3862: OpenClaimsTileOnClaimsLanding: Verify Open claims tile on claims landing page")
    public void testOpenClaimsTileOnClaimsLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToClaimsLanding()
                .showOpenClaims().validateOpenClaims().shouldBeTrue("Not only Draft and Open claims are shown.");
        //TODO: Add simple data (closed claim) and check that it's not presented in Open Claims
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3863: Verify Closed claims tile on claims landing page")
    public void testClosedClaimsTileOnClaimsLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToClaimsLanding()
                .showCloseClaims().validateCloseClaims().shouldBeTrue("Not only Closed claims are shown.");
        //TODO: Add simple data (closed claim) and check that it's presented in Close Claims
    }
}
