package com.guidewire.capabilities.agent.test;

import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.capabilities.agent.model.page.*;
import com.guidewire.capabilities.agent.scenarios.BindCancellationOnPolicyScenario;
import com.guidewire.capabilities.agent.scenarios.QuoteCancellationOnPolicyScenario;
import com.guidewire.capabilities.agent.scenarios.WithdrawCancellationOnPolicyScenario;
import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.capabilities.common.interfaces.ICancelPolicyDetailsPage;
import com.guidewire.capabilities.common.interfaces.ICommonPage;
import com.guidewire.capabilities.common.interfaces.IPolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class PolicyCancellationTest {
    IBindPolicyCancellationPage goToSubmitCancellation(ICommonPage scenario) {
        return goToCancellationForm(scenario)
                .fillMandatoryProperties()
                .setDateWithinPolicyPeriod()
                .submitCancellation();
    }

    IBindPolicyCancellationPage goToSubmitCancellationThroughSearchingPolicy(ICommonPage scenario) {
        return goToCancellationFormThroughSearchingPolicy(scenario)
                .fillMandatoryProperties()
                .setDateWithinPolicyPeriod()
                .submitCancellation();
    }
    ICancelPolicyDetailsPage goToCancellationForm(ICommonPage scenario) {
        return scenario
                .login()
                .clickPolicyLinkOnNavBar()
                .clickOnPolicy()
                .clickOnCancelPolicy();
    }

    ICancelPolicyDetailsPage goToCancellationFormThroughSearchingPolicy(ICommonPage scenario) {
        return scenario
                .login()
                .searchPolicy()
                .clickOnCancelPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond","CSR", "CSR_DIA"} , description = "TC3954, TC4077: BindCancellationOnPolicy")
    public void testBindCancellationOnPolicyCSR(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellationThroughSearchingPolicy(policyCancellation)
                .bindCancellationOnPolicy();
        policyCancellation.checkIfPolicyCancellationIsBounded().shouldBeTrue("Policy cancellation is not bounded");

    }
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4078: QuotedCancelPolicy")
    public void testQuoteCancellationOnPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        QuoteCancellationOnPolicyScenario policyCancellation = new QuoteCancellationOnPolicyScenario(policyNum);

        goToSubmitCancellation(policyCancellation);

        policyCancellation.checkIfPolicyCancellationIsQuoted().shouldBeTrue("Policy cancellation is not quoted");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond","CSR", "CSR_DIA"} , description = "TC4079, TC3955: WithdrawCancelPolicy")
    public void testWithdrawCancellationOnPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellationThroughSearchingPolicy(policyCancellation)
        .withdrawCancellationOnPolicy();
        policyCancellation.checkIfPolicyCancellationIsWithdrawn().shouldBeTrue("Policy cancellation is not withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4080 : Verify ' Renew Policy' button is not displayed if policy is already cancelled")
    public void testCancelledPolicyCannotBeRenewed(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation)
                .bindCancellationOnPolicy();
        new PolicyCancelationSummary()
                .validateCancellationStatus("Bound")
                .clickPolicyLink()
                .validateCanceledPolicyStatus()
                .validateRenewPolicyButton().shouldBeFalse("Renew policy button is present while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4082: Verify for validation message is displayed when user provides effective date not within the policy period for Cancel action, GPA--720")
    public void testCancelPolicyEffectiveDateNotWithinPolicyPeriod(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToCancellationFormThroughSearchingPolicy(policyCancellation)
                .fillMandatoryProperties()
                .setDateNotWithinPolicyPeriod();
        new QuoteCancellationOnPolicyScenario(policyNum)
                .checkStartCancellationButtonIsDisabled();
       }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4083: Verify for validation message is displayed when user does not provide mandatory fields for Cancel action.")
    public void testCancelPolicyMandatoryFieldValidation(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToCancellationForm(policyCancellation);
        new QuoteCancellationOnPolicyScenario(policyNum)
                .checkStartCancellationButtonIsDisabled();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4084: Verify for validation message is displayed when user does not provide mandatory fields for Cancel action.")
    public void testVerifyCancellationDetailsPageQuotedCancellation(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToPoliciesLanding()
                .goToPolicySummary(policyNum)
                .goCancellationSummaryPage(jobNumber)
                .validateQuotedCancellationPageComponents(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4085: Verify for validation message is displayed when user does not provide mandatory fields for Cancel action.")
    public void testVerifyCancellationDetailsPageBoundCancellation(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation)
                .bindCancellationOnPolicy();
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToPoliciesLanding()
                .goToPolicySummary(policyNum)
                .goCancellationSummaryPage(jobNumber)
                .validateBoundCancellationPageComponents(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4086: Verify user can add an activity on Cancellation details page")
    public void testAddActivityOnCancellationDetails(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToOpenActivitiesTile()
                .clickAddActivityBtn();
        GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory();
        activityFactory.addDefaultActivity(new SeleniumCommands().generateUUID())
                .isAddActivityComponentVisible().shouldBeTrue("Activity is not listed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4087: Verify user can cancel the add an activity action on Cancellation details page")
    public void testCancelAddActivityOnCancellationDetails(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToOpenActivitiesTile()
                .clickAddActivityBtn();
        GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory();
        activityFactory.addActivityThanCancelSubmition()
                .isAddActivityComponentVisible().shouldBeFalse("Activity was added while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC4088: Verify user can add a note on Cancellation details page")
    public void testAddNoteOnCancellationDetailsPage(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToNoteTile();
        new AddNoteComponent()
                .addBasicNote()
                .isNoteAdded().shouldBeTrue("Note was not added");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4089: Verify user can cancel the add a note action on Cancellation details page")
    public void testCancelAddNoteOnCancellationDetailsPage(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToNoteTile();
        new AddNoteComponent()
                .addNoteMandatoryFields()
                .cancelAddingNote()
                .isNoteAdded().shouldBeFalse("Note was added while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4090: Verify user can upload document on Cancellation details page")
    public void testUploadDocOnCancellationDetailsPage(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToDocumentsTile();
        new DocumentsTab().uploadDocFromSummary()
                .isDocAdded().shouldBeEqual("Document was not uploaded");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "Test Case GPA--371: Verify user can delete uploaded document on Cancellation details page")
    public void testDeleteDocOnCancellationDetailsPage(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        new PolicyCancelationSummary().goToDocumentsTile();
        new DocumentsTab().uploadDocFromSummary()
                .deleteDoc()
                .isDocTableEmpty().shouldBeTrue("Document was not deleted");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4094: DoNotWithdrawCancelPolicy")
    public void testCancelWithdrawCancellationOnPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation)
                .doNotWithdrawCancellationOnPolicy();
        policyCancellation.checkIfPolicyCancellationIsQuoted().shouldBeTrue("Policy cancellation is not quoted");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4095: DoNotBindCancellationOnPolicy")
    public void testCancelBindCancellationOnPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation)
                .doNotBindCancellationOnPolicy();
        policyCancellation.checkIfPolicyCancellationIsQuoted().shouldBeTrue("Policy cancellation is not quoted");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4096: Verify user can view policy Cancellation details page from policies landing, open cancellations page")
    public void testViewPolicyCancellationDetailPageFromPoliciesOpenCancellations(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToPoliciesLanding()
                .showOpenCancelations()
                .clickCancellationJob(jobNumber)
                .isCancellationPagePresented(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4097: Verify user can view Change Policy details page from Dashboard")
    public void testViewPolicyCancellationDetailPageFromDashboard(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToDashBoard()
                .goToOpenCancellations()
                .clickCancellationJob(jobNumber)
                .isCancellationPagePresented(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4098: Verify user can view Cancellation Policy details page from Activites details section on Dashboard")
    public void testViewPolicyCancellationPageFromActivitiesonDashboard(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new PolicyCancelationSummary().goToOpenActivitiesTile()
                .clickAddActivityBtn();
        new GPA_ActivityPageFactory().addDefaultActivity(new SeleniumCommands().generateUUID());
        new NavBar().goToDashBoard()
                .clickCancellationLineOfBusinessLink(jobNumber)
                .isCancellationPagePresented(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4099: Verify user can view Cancellations details page from Account details page")
    public void testViewCancellationDetailsFromAccDetails(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        WithdrawCancellationOnPolicyScenario policyCancellation = new WithdrawCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation);
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink();
        new Tiles().selectByTitle("Open Transactions");
        new AccountSummary().clickCancellationLineOfBusinessLink(jobNumber)
                .isCancellationPagePresented(jobNumber);
    }

}
