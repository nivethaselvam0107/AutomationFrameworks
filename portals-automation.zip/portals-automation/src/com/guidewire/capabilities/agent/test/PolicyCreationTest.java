package com.guidewire.capabilities.agent.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.AccountSearchResults;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.agent.model.page.QnBEffectiveDate;
import com.guidewire.capabilities.agent.model.page.QuoteStart;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.ConstructionPage;
import com.guidewire.portals.qnb.pages.DiscountPage;
import com.guidewire.portals.qnb.pages.DriverDetailsPage;
import com.guidewire.portals.qnb.pages.HOPolicyInfoPage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.PAPolicyInfoPage;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.portals.qnb.pages.VehicleDetailsPage;
import com.guidewire.portals.qnb.pages.YourHomePage;
import com.guidewire.widgetcomponents.table.Row;
import com.guidewire.widgetcomponents.table.Table;

public class PolicyCreationTest {


	GPA_QuotePageFactory quoteFactory = new GPA_QuotePageFactory();

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" })
    public void testVehiclesValidationOnPersonalAutoQuote(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        String addressLine1 = data.get("AddressLine1");
        String city = data.get("City");
        String zip = data.get("Zip");

        login();

        searchForPersonalAccount(data)
                .createNewAccount()
                .withAddressLine1(addressLine1)
                .withCity(city)
                .withZip(zip)
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .submit();

        new QuoteStart()
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(data.get("ProductCode"))
                .submit();

        VehicleDetailsPage vehicleDetailsPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .setDOBGPA(data.get("DOB"))
                .goToVehicleDetailsPage();
               // .goNext();

        vehicleDetailsPage.areVehiclePageFieldsMarkedWithAsterisk().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" })
    public void testPolicyInfoValidationOnPersonalAutoQuoteOnExistingAccount(String browserName) throws Exception {
        quoteFactory.startPAQuoteWithExistingAcount();

        PAPolicyInfoPage paPolicyInfoPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage()
                .setEmailAddress("")
                .setPhoneNumber("")
                .goNext();

        paPolicyInfoPage.arePolicyInfoPageFieldsMarkedWithMandatoryError().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "debugtest"})
    public void testPaymentDetailsValidationOnPersonalAutoQuoteOnExistingAccount(String browserName) throws Exception {
		   quoteFactory.startPAQuoteWithExistingAcount();

        PaymentDetailsPage paymentDetailsPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage().setPhoneNumber()
                .goToPaymentDetailsPage()
                .setPaymentPlan()
                .goNext();

        paymentDetailsPage.setPaymentMethod("Bank Account");
        paymentDetailsPage.areBankPaymentFieldsMarkedWithMandatoryError().shouldBeTrue();

        paymentDetailsPage.setPaymentMethod("Credit Card");
        paymentDetailsPage.areCreditCardPaymentFieldsMarkedWithMandatoryError().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, enabled =  false)
    public void testNoPaymentPlanSelectedOnPersonalAutoQuoteOnExistingAccount(String browserName) throws Exception {
		   quoteFactory.startPAQuoteWithExistingAcount();

        PaymentDetailsPage paymentDetailsPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage().setPhoneNumber()
                .goToPaymentDetailsPage()
                .goNext();

        paymentDetailsPage.validateChoosePaymentPlanConfirmationText();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3552: CancelPAQuoteOnDriversScreen")
    public void testQuoteIsSavedUpToDriversScreenWhenUserCancelsQuoteOnDriversScreen(String browserName) throws Exception {
		   quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .pressCancelOnVehicleDriverPage()
                .confirmCancel()
                .continueQuote();
        
        DriverDetailsPage detailsPage = new LeftNavigationMenuHandler().gotoDriverPage_GPA();
        detailsPage.areDriverDetailsSaved().shouldBeTrue();

    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3553: CancelPAQuoteOnVehiclesScreen")
    public void testQuoteIsSavedUpToVehiclesScreenWhenUserCancelsQuoteOnVehiclesScreen(String browserName) throws Exception {
		   quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .pressCancelOnVehicleDriverPage()
                .confirmCancel()
                .continueQuote();

        VehicleDetailsPage vehicleDetailsPage = new Pagefactory()
               .getVehicelDetailsPage();

        vehicleDetailsPage.areVehiclesDetailsSaved();

    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3554: CancelPAQuoteOnPolicyInfoScreen")
    public void testQuoteIsSavedUpToQuoteScreenWhenUserCancelsQuoteOnPolicyInfoScreen(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage()
                .setEmailAddress(data.get("Email")).setPhoneNumber()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        PAPolicyInfoPage paPolicyInfoPage = new Pagefactory()
                .getPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage();

        paPolicyInfoPage.isEmailEqualsTo().shouldBeEqual();

    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3555: CancelPAQuoteOnPaymentDetailsScreen")
    public void testQuoteIsSavedUpToPaymentDetailsScreenWhenUserCancelsQuoteOnPaymentDetailsScreen(String browserName) throws Exception {
		   quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage()
                .setEmailAddress().setPhoneNumber("650-333-3333")
                .goToPaymentDetailsPage().setAccountNumber().setABARoutingNumber().setBankName()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        PAPolicyInfoPage paPolicyInfoPage = new Pagefactory()
                .getPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage();

        paPolicyInfoPage.isEmailEqualsTo().shouldBeEqual();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, enabled = false, description = "No Longer valid")
    public void testGPAEmailQuote(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        quoteFactory.startPAQuoteWithExistingAcount();

       PAQuotePage paQuotePage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .emailPolicyQuote();


        paQuotePage.isEmailQuoteModalDisplayed().shouldBeTrue();
    }



	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3551: CancelPAQuoteOnQualificationScreen")
    public void testQuoteIsSavedUpToQualificationScreenWhenUserCancelsQuoteOnQualificationsScreen(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        QualificationPage qualificationPage =  new LeftNavigationMenuHandler().gotoQualificationPage_GPA();
        qualificationPage.arePAQualificationAnswersSaved().shouldBeTrue();
    }

    /**@throws Exception 
     * @formatter:off
     * @param browserName
     *
     * Test Description :- Verify that the policy detail page can be opened from Policy confirmation page.
     *
     *            Step actions:
     *            1. Login to portal
     *            2. Click on New Quote button
     *            3. Search for exisiting account
     *            4. Click on Start a new quote
     *            5. Provide policy details, select Personal Auto product code and click on Next
     *            6. Select the effective date and click on Next
     *            7. Provide all the mandatory details on Qualification screen and click on Next
     *            8. Provide all mandatory details on Drivers screen and click on Next
     *            9. Provide all mandatory details on Vehicles screen and provide vehicle cost value as 1,00,001.00 and click on Next
     *            10. Click on "Click here"
     *            11. Click Yes on the pop up message
     *
     *            Expected Results :-
     *            1. Dashboard page should be displayed
     *            2. New Quote: Search for Existing Account page should be displayed
     *            3. Possible Account Matches page with Start a new quote link should be displayed
     *            4. New Quote: Policy Details for Existing Account page should be displayed
     *            5. Effective date screen should be displayed
     *            6. Qualification screen should be displayed.
     *            7. Drivers screen should be displayed
     *            8. Vehicles screen is displayed
     *            9. Quote page with all offerings displayed. Buy Now buttons are disabled for all offerings to which the UW issues are applied.
     *               We should see " There are underwriting issues assosciated with this offering.
     *               Click here to view more details." message has to be displayed for all offerings
     *            10. Are you sure you want to cancel? The information previously enetered will be stored a quote submission.
     *            11. Quote details page should be displayed with an open UW issues displayed under Underwriting Issues table.
     *                "High value vehicle" Underwriting issue should be displayed in the table with status as "Blocks Bind" for all offerings.
     *                "Underwriting issues have been raised for this quote
     *                 You cannot complete this quote until these issues have been resolved. You can:
     *                 Edit the quote if the customer is willing to accept the changes
     *                 Refer the quote to an underwriter for review
     *                 Withdraw(link) this quote if you do not wish to continue" message should be displayed on quote details page with Edit quote and Refer to Underwriter buttons
     */

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3557: UnderWriterIssueForVehicleCostGreaterThan100000")
    public void UnderWriterIssueForVehicleCostGreaterThan100000() throws Exception {
        quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToDriverDetailsPage().setPrimaryDriverDetails()
                .goToVehicleDetailsPage().setVehicleDetails()
                .withVehicleCost("100001.00")
                .clickNext();

        PAQuotePage quotePage= new Pagefactory().getPAQuotePage();
        quotePage.validateQuoteOptionsAndBuyNowBtnAndInfoMessage();
        quotePage.validationUnderwritingMessage();
    }

	
	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "SMOKE"})
    public void testPurchaseOfHomeownersInsuranceForExistingAccount() throws Exception {
        adaptationForGranite();
        quoteFactory.startPAQuoteWithExistingAcount();

        PolicyConfirmationPage policyConfirmationPage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();

        policyConfirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite"  })
    public void testQualificationValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
        quoteFactory.startPAQuoteWithExistingAcount();

        QualificationPage qualificationPage = new Pagefactory().getQualificationPage().goNext();

        qualificationPage.isCoverageStatusMarkedWithError().shouldBeTrue();
        qualificationPage.isPremisesUsedForBusinessMarkedWithError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testHomeDetailsValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        YourHomePage yourHomePage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().goNext();

        yourHomePage.areYourHomePageFieldsMakedWithMandatoryError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"})
    public void testConstructionValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        ConstructionPage constructionPage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().goNext();

        constructionPage.areConstructionPageFieldsMakedWithMandatoryError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testDiscountValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        DiscountPage discountPage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().goNext();

        discountPage.areHODiscountPageFieldsMakedWithMandatoryError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"})
    public void testPolicyInfoValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        HOPolicyInfoPage hoPolicyInfoPage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setEmailAddress("")
                .setPhoneNumber("")
                .goNext();

        hoPolicyInfoPage.arePolicyInfoPageFieldsMarkedWithMandatoryError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testPaymentDetailsValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        PaymentDetailsPage paymentDetailsPage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().setPaymentPlan().goNext();

        paymentDetailsPage.areBankPaymentFieldsMarkedWithMandatoryError().shouldBeTrue();
    }


	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3614: ValidationforEstimatedValueOfHomeGreaterThan2000000000")
    public void testTooExpansiveHouseValidationsWhenBuyingHomeownersForExistingAccount() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();
		ThreadLocalObject.getData().put("HomeValue", "999999999999999999999999");
        YourHomePage yourHomePage = new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails().goNext();

        yourHomePage.isHomeEstimationFieldMarkedWithMAXValueError().shouldBeEqual();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description ="TC3619: CancelHOQuoteOnQualificationScreen")
    public void CancelHOQuoteOnQualificationScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        QualificationPage qualificationPage =  new LeftNavigationMenuHandler().gotoQualificationPage_GPA();
        	qualificationPage.areHOQualificationAnswersSaved().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "TC3618: CancelHOQuoteOnYourHomeScreen")
    public void CancelHOQuoteOnYourHomeScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        YourHomePage homePage =new LeftNavigationMenuHandler().gotoYourHomePage_GPA();
        homePage.areYourHomePageFieldsValuesAreSaved().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "SMOKE"}, description = "TC3620: CancelHOQuoteOnConstructionScreen")
    public void CancelHOQuoteOnConstructionScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails().withConstructionUpgradeYear()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        ConstructionPage constructionPage = new LeftNavigationMenuHandler().gotoConstructionPage_GPA();
        constructionPage.areConstructionPageDetailsSaved().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "TC3621: CancelHOQuoteOnDiscountScreen")
    public void CancelHOQuoteOnDiscountScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        new Pagefactory().getDiscountPage().areDiscountPageValueSaved().shouldBeTrue();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC3622: CancelHOOnPolicyInfoScreen")
    public void CancelHOOnPolicyInfoScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        HOPolicyInfoPage hoPolicyInfoPage = new Pagefactory()
                .getHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage();

        hoPolicyInfoPage.isEmailSaved().shouldBeEqual();
        hoPolicyInfoPage.isPhoneSaved().shouldBeEqual();
    }

	@Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "TC3623:CancelHOPaymentDetailsScreen")
    public void CancelHOPaymentDetailsScreen() throws Exception {
        adaptationForGranite();
		quoteFactory.startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        new Pagefactory()
                .getHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .goToPaymentDetailsPage()
                .arePaymentFieldsInInitialState().shouldBeTrue();
    }


	@Parameters("browserName")
	 @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, enabled = false, description = "TC5828, TC5804")
	    public void ContinueQuoteWhenEffectiveDateIsInThePast(String browserName) throws Exception {
	        HashMap<String, String> data = ThreadLocalObject.getData();

	        login();

	        SimpleDateFormat dateFormat = new SimpleDateFormat("M/dd/YY");
	        Date today = DateUtils.truncate(Calendar.getInstance().getTime(), Calendar.DATE);

	        Table openQuotes = new AgentDashboard()
	                .goToPolicies()
	                .getOpenQuotes();

	        Row draft = openQuotes
	                .find(row -> {
	                    if (!row.getCellByColumnTitle("JOB STATUS").getText().equals("Draft") || !row.getCellByColumnTitle("PRODUCT").getElement().findElement(By.xpath("./img")).getAttribute("src").contains("personal-auto")) {
	                        return false;
	                    }

	                    try {
	                        //TODO: this search assumes a job started in the past also has an effective date in the past, which may not be true
	                    		System.out.println("Checking Quote date" + today);
	                    		System.out.println(dateFormat.parse(row.getCellByColumnTitle("CREATED").getText()).getDate());
	                    		DateTimeFormatter dtf = DateTimeFormat.forPattern("M/dd/YY");
	                    		DateTime local = new DateTime();
	                    		System.out.println(row.getCellByColumnTitle("CREATED").getText());
	                    		DateTime jodatime = dtf.parseDateTime(row.getCellByColumnTitle("CREATED").getText());
	                    		System.out.println(jodatime.getMillis());
	                    		System.out.println(local.getMillis());
	                    		if((local.getMillis() - jodatime.getMillis() )/ (24 * 60 * 60 * 1000) > 0)
	                    		{
	                    			return true;
	                    		}
	                    		return false;
	                        //return dateFormat.parse(row.getCellByColumnTitle("CREATED").getText()).before(today);
	                    } catch (ParseException ignore) {
	                        return false;
	                    }
	                });

	        	new SeleniumCommands().click(draft.getCellByColumnTitle("JOB NUMBER").getElement().findElement(By.xpath("./*[@ui-sref='quote.detail.summary({submissionNumber:item.jobNumber})']")));
	        new QuoteSummary().continueQuote();

	        new Validation(
	                new QnBEffectiveDate()
	                        .goNext()
	                        .getEffectiveDate()
	                        .isShowingError()
	        ).shouldBeTrue();
	    }


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5815: Verify user can start a new quote on Account details page")
    public void testNewQuoteCreationOnAccountDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new AgentDashboard().goToAccounts()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .clickAddQuoteButton()
                .fillPolicyDetailsFormForExistingAccount().createAndBuyPolicyPA().savePolicyNumber()
                .goToAccountDetailPage()
                .isPolicyDisplayedOnAccountPage(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeTrue("Policy not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5818: Verify user can start a quote on Account details page for different existing account by using global New Quote button on nav bar")
    public void testQuoteCreationUsingGlobalNewQuoteForDifferentAccOnAccDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();
        new AgentDashboard().goToAccounts()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes();
        new GPA_QuotePageFactory().startQuoteForAnyAccount().createAndBuyPolicyPA().savePolicyNumber()
                .goToAccountDetailPage()
                .isPolicyDisplayedOnAccountPage(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeTrue("Policy not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5821: Verify user can start a new quote on Account details page using global New Quote button on nav bar")
    public void testQuoteCreationUsingGlobalNewQuoteForExisitngAccOnAccDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();
        new AgentDashboard().goToAccounts()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes();
        new GPA_QuotePageFactory().startGlobalQuoteForExistingAccount().createAndBuyPolicyPA().savePolicyNumber()
                .goToAccountDetailPage()
                .isPolicyDisplayedOnAccountPage(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeTrue("Policy not displayed");
    }

    private void login(){
        new LoginPage().login();
    }

    private void adaptationForGranite() {
        String platform = System.getProperty("platform");
        if (platform.equalsIgnoreCase("granite") && ThreadLocalObject.getData().get("ProductCode").equals("Homeowners"))
            ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
    }

    private AccountSearchResults searchForPersonalAccount(HashMap<String, String> data){
        return new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(ThreadLocalObject.getData().get("FirstName"))
                .withLastName(ThreadLocalObject.getData().get("LastName"))
                .search();

    }
}
