package com.guidewire.capabilities.agent.test;

import java.util.HashMap;

import com.guidewire.capabilities.agent.model.page.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;

/**
 * Created by skrishnappanavar on 22/06/2016.
 */
public class LandingPageTest {

    public static final String DATA_USER = "USER";
    public static final String DATA_PWD = "PWD";

    // test cases - Shruthi
    /**@formatter:off
     * @param browserName
     *
     * Test Description :- Verify the Account Landing page
     *
     *            Step actions :-
     *            1. Login to agent portal application as aarmstrong/gw
     *            2. Click on Accounts link on nav bar
     *
     *            Expected Results:-
     *            1. Dashboard should be displayed.
     *            2. Account landing page should be displayed with Recently Viewed tile selected by default.
     */
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3296: AccountLanding")
    public void testAccountLanding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        new LoginPage().login();
        AccountsLanding accountsLanding = new NavBar().goToAccountsLanding();
        accountsLanding.checkTitle().shouldBeEqual("Accounts landing page title mismatch");
        accountsLanding.checkDefaultTile().shouldBeEqual("Recently Viewed was not default tile");
        new NavBar().isAccountsLandingSelected().shouldBeTrue("Accounts landing page is not selected");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description :- Verify the Policies Landing page
     *
     *            Step actions :-
     *            1. Login to agent portal application as aarmstrong/gw
     *            2. Click on Policies link on nav bar
     *
     *            Expected Results :-
     *            1. Dashboard should be displayed.
     *            2. Policies landing page should be displayed with Recently Viewed tile selected by default.
     */
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3297: PolicyLanding")
    public void testPoliciesLanding(String browserName) throws Exception{
        HashMap<String, String> data = ThreadLocalObject.getData();
        new LoginPage().login();
        PoliciesLanding policiesLanding= new NavBar().goToPoliciesLanding();
        policiesLanding.checkTitle().shouldBeEqual("Policies landing page title mismatch");
        policiesLanding.checkDefaultTile().shouldBeEqual("Recently Viewed was not default tile");
        new NavBar().isPoliciesLandingSelected().shouldBeTrue("Policies landing page is not selected");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description :- Verify the Claims Landing page
     *
     *            Step actions:
     *            1. Login to agent portal application as aarmstrong/gw
     *            2. Click on Policies link on nav bar
     *
     *            Expected Results :-
     *            1. Dashboard should be displayed.
     *            2. Claims landing page should be displayed with Recently Viewed tile selected by default.
     */
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3298: ClaimsLanding")
    public void testClaimsLanding(String browserName) throws Exception{
        HashMap<String, String> data = ThreadLocalObject.getData();
        new LoginPage().login();
        ClaimsLanding claimsLanding= new NavBar().goToClaimsLanding();
        claimsLanding.checkTitle().shouldBeEqual("Claims landing page title mismatch");
        claimsLanding.checkDefaultTile().shouldBeEqual("Recently Viewed was not default tile");
        new NavBar().isClaimsLandingSelected().shouldBeTrue("Claims landing page is not selected");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description :- Verify the Activities Landing page
     *
     *            Step actions:
     *            1. Login to agent portal application as aarmstrong/gw
     *            2. Click on Activities link on nav bar
     *
     *            Expected Results :-
     *            1. Dashboard should be displayed.
     *            2. Activities landing page should be displayed with My Open tile selected by default.
     */
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3299: ActivitiesLanding")
    public void testActivitiesLanding(String browserName) throws Exception{
        HashMap<String, String> data = ThreadLocalObject.getData();
        new LoginPage().login();
        ActivitiesLanding activitiesLanding= new NavBar().goToActivitiesLanding();
        activitiesLanding.checkTitle().shouldBeEqual("Activities landing page title mismatch");
        activitiesLanding.checkDefaultTile().shouldBeEqual("Recently Viewed was not default tile");
        new NavBar().isActivitiesLandingSelected().shouldBeTrue("Activities landing page is not selected");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description :- Verify the Analytics Landing page
     *
     *            Step actions:
     *            1. Login to agent portal application as aarmstrong/gw
     *            2. Click on Analytics link on nav bar
     *
     *            Expected Results :-
     *            1. Dashboard should be displayed.
     *            2. Analytics page is displayed with Growth tile selected by default. Loss Ratio tile should also be displayed. Note: read only content will be displayed for both the tiles
     */
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3300: AnalyticsLanding", enabled = false)
    public void testAnalyticsLanding(String browserName) throws Exception{
        HashMap<String, String> data = ThreadLocalObject.getData();
        new LoginPage().login();
        AnalyticsLanding analyticsLanding= new NavBar().goToAnalyticsLanding();
        analyticsLanding.checkTitle().shouldBeEqual("Analytics landing page title mismatch");
        analyticsLanding.checkDefaultTile().shouldBeEqual("Recently Viewed was not default tile");
        analyticsLanding.checkTile().shouldBeEqual("Loss Ratios tile is not displayed on Analytics page");
        new NavBar().isAnalyticsLandingSelected().shouldBeTrue("Analytics landing page is not selected");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3306 : Verify user can view activities under Activites list on Dashboard")
    public void testDashboardActivitiesListing(String browserName) throws Exception{
        new LoginPage().login();
        new AgentDashboard().expandFirstActivity()
                .verifyActivitiesForNext7daySections()
                .verifyActivityDetailsExpanded();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3302 : Verify user can view all open policy renewals from dashboard")
    public void testDashboardOpenRenewals(String browserName) throws Exception{
        new LoginPage().login();
        new AgentDashboard().openRenewalsTile()
                .verifyPoliciesTableColumns();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3303 : Verify user can view all open quotes from dashboard")
    public void testDashboardOpenQuotes(String browserName) throws Exception{
        new LoginPage().login();
        new AgentDashboard().openOpenQuotesTile()
                .verifyPoliciesTableColumns();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3304 : Verify user can view all open policy changes from dashboard")
    public void testDashboardOpenChanges(String browserName) throws Exception{
        new LoginPage().login();
        new AgentDashboard().openPolicyChangesTile()
                .verifyPoliciesTableColumns();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3305 : Verify user can view all open policy cancellation from dashboard")
    public void testDashboardOpenCancellations(String browserName) throws Exception{
        new LoginPage().login();
        new AgentDashboard().openCancelationsTile()
                .verifyPoliciesTableColumns();
    }
}