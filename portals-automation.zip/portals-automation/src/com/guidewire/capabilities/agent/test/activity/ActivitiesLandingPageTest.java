package com.guidewire.capabilities.agent.test.activity;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.ActivityComponent;
import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.ReassignActivityComponent;
import com.guidewire.capabilities.agent.model.page.ActivitiesLanding;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.Modal;

import java.util.concurrent.TimeUnit;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class ActivitiesLandingPageTest {

    GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory();

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4127: ViewAccountFromActivities")
	public void testViewAccountFromActivities(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding
				.openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
				.isAccountSummaryPageLoaded().shouldBeTrue("Account summary page is not opened");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA" }, description = "TC4121:ViewOpenActivitiesOwnedByUser")
	public void testViewOpenActivitiesOwnedByUser(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding.validateMyOpenActivitiesData();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR" , "CSR_DIA"}, description = "TC4122:ViewCompletedActivitiesAssignedToUser", dependsOnMethods = {
					"testViewOpenActivitiesOwnedByUser", "testViewAllActivitiesCreatedByUser",
					"testViewAllOpenActivities" })
	public void testViewCompletedActivitiesAssignedToUser(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();

		new ActivitiesScheduleComponent().clickOnFirstActivity().completeActivity().doesActivityShowCompleted()
				.shouldBeTrue();

		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding.validateMyCompletedActivitiesData();
	}

	// Failing as completed activity is not listed with correct status
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4123:ViewAllActivitiesCreatedByUser")
	public void testViewAllActivitiesCreatedByUser(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding.validateCreatedByMeActivitiesData();

	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "CSR", "CSR_DIA"}, description = "TC4124:ViewAllOpenActivities")
	public void testViewAllOpenActivities(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding.validateAllOpenActivitiesData();

	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA"}, description = "TC4125:ViewAllCompletedActivities")
	public void testViewAllCompletedActivities(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		new ActivitiesScheduleComponent().clickOnFirstActivity().completeActivity();
		activitiesLanding.isActivitiesLandingPageOpened().shouldBeTrue("Activities page is not opened");
		activitiesLanding.validateAllCompletedActivitiesData();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA" }, description = "TC4126:Verify the Advanced Filter link Functionality on activities landing page")
	public void testAdvancedFilterOnActivtiesLanding(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		ActivitiesLanding activitiesLanding = new NavBar().goToActivitiesLanding();
		activitiesLanding.clickAdvancedFiltersLink();
		activitiesLanding.validateAllAdvancedFiltersPresented();
		activitiesLanding.isActivityPresentOnAdvancedFiltersPage(ThreadLocalObject.getData().get("ACTIVITY_SUBJECT")).shouldBeTrue("Activity is NOT present while it should");
		activitiesLanding.clickUrgentFilter()
				.isActivityPresentOnAdvancedFiltersPage(ThreadLocalObject.getData().get("ACTIVITY_SUBJECT")).shouldBeFalse("Activity is present while it shouldn't");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA" }, description = "TC4129: CompleteAnActivity")
	public void testCompleteAnActivity(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		new NavBar().goToActivitiesLanding();
		new ActivitiesScheduleComponent().clickOnFirstActivity().completeActivity().doesActivityShowCompleted()
				.shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA" }, description = "TC4130: NoteAdditionToCompletedActivity")
	public void testNoteAdditionToCompletedActivity(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		new NavBar().goToActivitiesLanding();
		ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
		activitiesScheduleComponent.clickOnFirstNonCompleteActivityUserOwns().completeActivity()
				.doesAddNoteButtonExist().shouldBeFalse("Add note button was visible for the completed activity");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA" }, description = "TC4133: AddNoteToTheActivity")
	public void testAddNoteToTheActivity(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		new NavBar().goToActivitiesLanding();
		ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
		activitiesScheduleComponent.clickOnFirstNonCompleteActivityUserOwns().clickAddNoteButton()
				.addNoteToNonCompleteActivity();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4134: MandatoryFieldCheckForAddingANote")
	public void testMandatoryFieldCheckForAddingANote(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		new NavBar().goToActivitiesLanding();
		ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
		activitiesScheduleComponent.clickOnFirstNonCompleteActivityUserOwns().clickAddNoteButton()
				.areNoteFieldsAreMarkedWithMandatoryErrors();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "CSR", "CSR_DIA"}, description = "TC4131 :ReassignActivity")
	public void testReassignActivity(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String UUID = new SeleniumCommands().generateUUID();
		activityFactory.clickAddActivityButtonFromAccountActivityTile();
		activityFactory.addDefaultActivity(UUID);
		ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
				.getActivityBySubject(UUID).toggleSummary().getReassignActivityComponent();

		reassignActivityComponent.openReassignActivityDropdown().setAssigneeByName().clickConfirmButton();

		Modal.waitHidden();

		reassignActivityComponent.isNotAssignedToCurrentUser()
				.shouldBeTrue("Activity is still assigned to current user");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4132: CancelReassignActivityAction")
	public void testCancelReassignActivityAction(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String UUID = new SeleniumCommands().generateUUID();
		activityFactory.clickAddActivityButtonFromAccountActivityTile();
		activityFactory.addDefaultActivity(UUID);

		ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
				.getActivityBySubject(UUID).toggleSummary().getReassignActivityComponent();

		reassignActivityComponent.openReassignActivityDropdown().setAssigneeByName().clickCancelButton();

		Modal.waitHidden();

		reassignActivityComponent.isAssignedToCurrentUser().shouldBeEqual("Activity is not assigned to current user");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "CSR", "CSR_DIA"}, description = "TC4128: ViewActivityDetails")
	public void testViewActivityDetails(String browserName) throws Exception {
		activityFactory.addFutureActivityOnAccountDetailsPage();
		new NavBar().goToActivitiesLanding();
		ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
		ActivityComponent activityComponent = activitiesScheduleComponent.clickOnFirstNonCompleteActivityUserOwns().clickAddNoteButton()
				.addNoteToNonCompleteActivity();
		activityComponent.validatedActivityUIComponant();
		new AddNoteComponent().validatedAddedNoteUIComponant();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4120: ActivityLandingPageVerification")
	public void testActivityLandingPageVerification(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String UUID = new SeleniumCommands().generateUUID();
		activityFactory.clickAddActivityButtonFromAccountActivityTile();
		activityFactory.addDueTomorrowActivity(UUID);
		ActivitiesLanding  activitiesLanding =new NavBar().goToActivitiesLanding();
		activitiesLanding.areActivitiesLandingPageTilesDisplayed();
		new ActivitiesScheduleComponent().clickOnFirstActivity().toggleSummary().validatedActivityRowUIComponant();
	}
	

}
