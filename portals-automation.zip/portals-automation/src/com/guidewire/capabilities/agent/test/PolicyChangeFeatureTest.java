package com.guidewire.capabilities.agent.test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.PolicyChangeSummaryPage;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementPaymentPage;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.PolicyChanges;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementCoverages;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementMortagee;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementValuables;
import com.guidewire.capabilities.endorsement.model.page.pa.*;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementBackEndCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

public class PolicyChangeFeatureTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA"} , description = "TC3983: Verify 'Change Policy' functionality for PA policy- add a driver")
    public void testAddDriverEndorsement(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("GENDER","Male");
        data.put("ACCIDENTS","1");
        data.put("VIOLATIONS","1");
        data.put("STATE","California");
        data.put("YEAR_LICENSED","2014");
        data.put("FIRST_NAME","Lee");
        data.put("LAST_NAME","Carvallo");
        data.put("DOB","10/10/1987");
        data.put("DOB_TO_CHECK","October 10, 1987");
        data.put("LICENSE_NUMBER","321111");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow()
                .addDriverDraftEndorsementStartingFromDateForm(true);
        new EndorsementEditToolBar().check();
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("added");
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("VIN")) ;
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC3980: Verify 'Change Policy' functionality for PA policy- edit a vehicle")
    public void testEditVehicleEndorsement(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("LicensePlate","ABCDE123");
        data.put("VehicleCost","100");
        data.put("COST_DESC","$100.00");
        data.put("STATE_VALUE","CA");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow()
                .editVehicleEndorsementStartingFromDateForm();
        new EndorsementVehiclePage().isVehicleEditTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN")) ;
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA"} , description = "TC3979: Verify 'Change Policy' functionality for PA policy- add a vehicle - change address")
    public void testAddVehicleChangeAddress(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("VIN","ABCDE123");
        data.put("LicensePlate","12345");
        data.put("Make","AAA");
        data.put("Model","A3");
        data.put("VehicleYear","2000");
        data.put("VehicleState","California");
        data.put("VehicleCost","100");
        data.put("COST_DESC","$100.00");
        data.put("STATE_VALUE","CA");
        data.put("NewCity","Khust");
        goToPolicyChangePage("PersonalAuto")
                .checkAddressChanges()
                .checkVehiclesChanges()
                .goNextToChangePolicyForm();
        new EndorsementAddressPage().setCity(ThreadLocalObject.getData().get("NewCity"));
        new EndorsementEditToolBar().check();
        new EndorsementWorkFlow().addVehicleDraftEndorsementFromEditEndosmentForm(true);
        new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyAndRedistributeCoverageChanges();
        new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN")) ;
        new PAEndorsementBackEndCheck().validateAddressChangedInPolicy();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA"} , description = "TC3984: Verify 'Change Policy' functionality for PA policy- edit a driver")
    public void testEditDriverEndorsement(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("STATE","California");
        data.put("DOB","10/10/1987");
        data.put("DOB_TO_CHECK","October 10, 1987");
        data.put("LICENSE_NUMBER","321111");
        data.put("ACCIDENTS","0");
        data.put("VIOLATIONS","0");
        goToPolicyChangePage("PersonalAuto")
                .checkDriversChanges()
                .goNextToChangePolicyForm();
        new EndorsementWorkFlow().editFirstDriver();
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("changed");
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("LICENSE_NUMBER"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA"} , description = "TC3977: Verify 'Change Policy' functionality for PA policy- coverage change only- Pay in Full")
    public void testCoverageChangeOnlyPayInFull(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("STATE","California");
        data.put("COVERAGE_VALUE","15,000");
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().setMedicalLimit();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().validateMedicalLimitValue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC3978: Verify 'Change Policy' functionality for PA policy- coverage change only- Confirm")
    public void testCoverageChangeOnlyConfirm(String browserName) throws Exception {
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().uncheckCheckedCoverage();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new EndorsementCoveragesPage().isLineCoverageSelected().shouldBeFalse("Coverage is selected while shoudn't");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC3989: Verify user can withdraw quoted policy change for PA policy, GPA-709")
    public void testWithdrawQuotedPolicyChangeforPA(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("COVERAGE_VALUE","15,000");
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().setMedicalLimit();
        new EndorsementWorkFlow().quoteEndorsement();
        new PolicyChanges().clickSaveAndExitBtn();
        new PolicyChangeSummaryPage().withdrawPolicyChange().validatePolicyChangeStatus("Withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4001: Verify user can continue quoted policy change for PA policy")
    public void testContinueQuotedPolicyChangeforPA(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("COVERAGE_VALUE","15,000");
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().setMedicalLimit();
        new EndorsementWorkFlow().quoteEndorsement();
        new PolicyChanges().clickSaveAndExitBtn();
        new PolicyChangeSummaryPage().continuePolicyChange();
        new EndorsementPage().isEndorsementWizardDisplayed().shouldBeTrue("User didn't enter endorsement wizard");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA"} , description = "TC3976: Verify 'Change Policy' functionality for PA policy- coverage change only- Redistribute")
    public void testCoverageChangeOnlyRedistribute(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("COVERAGE_VALUE","15,000");
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().setMedicalLimit();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyAndRedistributeCoverageChanges();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().validateMedicalLimitValue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC3998: Verify user can view uploaded document on Policy Change details page")
    public void testViewUploadedDocOnPolicyChangeDetailsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("STATE","California");
        data.put("DOB","10/10/1987");
        data.put("DOB_TO_CHECK","October 10, 1987");
        data.put("LICENSE_NUMBER","321111");
        data.put("ACCIDENTS","0");
        data.put("VIOLATIONS","0");
        goToPolicyChangePage("PersonalAuto")
                .checkDriversChanges()
                .goNextToChangePolicyForm();
        new EndorsementWorkFlow().editFirstDriver();
        new EndorsementEditToolBar().checkCoverage()
                .clickSaveAndExitButton();
        new PolicyChangeSummaryPage().goToDocumentsTile()
                .clickAddDocument();
        new DocumentsTab()
                .uploadDocFromSummary()
                .validateDocPageElementsOnClaimSummary().shouldBeTrue("Document was not uploaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement" } , description = "TC4007: Verify user can view Change Policy details page from Activites details section on Dashboard")
    public void testViewPolicyChangePageFromActivitiesonDashboard(String browserName) throws Exception {
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().uncheckCheckedCoverage();
        new EndorsementEditToolBar().checkCoverage()
                .clickSaveAndExitButton();
        new PolicyChangeSummaryPage().getPolicyChangeJobNumber();
        new PolicyChangeSummaryPage().goToOpenActivitiesTile()
                .clickAddActivityBtn();
        new GPA_ActivityPageFactory().addDefaultActivity();
        new NavBar().goToDashBoard()
                .clickJobLink()
                .validatePolicyChangePageWasLoaded().shouldBeTrue("Policy Change page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement" } , description = "TC4010: Verify change policy functionality for HO policy - Navgation to Endorsement Wizard.")
    public void testPolicyChangeHOPOlicy(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("HomeOwner");
        policySummary
                .clickChangePolicyButton()
                .verifyEndorsmentWizardPageLoaded();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement","CSR" } , description = "TC4011: Verify user can perform change to HO policy by adding Mortgagee")
    public void testHOChangeMortgagee(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("MortGagee_Name","Napoleon");
        data.put("MortGagee_Street","123 Baker street");
        data.put("MortGagee_City","Foster City");
        data.put("MortGagee_State","California");
        data.put("MortGagee_State_Value","CA");
        data.put("MortGagee_Zip","94404");
        data.put("MortGagee_Eff_date","");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addMortageeDraftEndorsementFromChangePage();
        new EndorsementMortagee().isMortgageeAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement","CSR" } , description = "TC4012: Verify user can perform change to HO policy by adding Valuables")
    public void testHOChangeValuables(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("Valuable_Cost","2323");
        data.put("Valuable_Type","Cameras");
        data.put("Valuable_Desc","Description");
        data.put("Valuable_Deductible","$1,000");
        data.put("Valuable_Validation_method","Replacement cost");
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addValuableDraftEndorsementFromChangePage();
        new EndorsementValuables().isValuablesAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables is not added to policy");
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement","CSR" } , description = "TC4013: Verify user can perform change to coverages for a HO policy")
    public void testHOChangeCoverage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        data.put("HO_PER_PROP_VALUATION_METHOD","50%");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().selectCoverages();
        new EndorsementCoverages().setLimitPercentOfDwel();
        new EndorsementWorkFlow().quoteAndBuyCoverageChangeEndorsement();
        new HOEndorsementBackEndCheck().isCoverageChangesAvailableInPolicy().shouldBeTrue("Coverage details are updated for the policy");
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement" } , description = "TC4014: Verify validation messages when no mandatory fields are provided while adding Mortgagee")
    public void testMissingMandatoryValuesWhileAddingMortgagee(String browserName) throws Exception {
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().selectMortgagee().clickAdd();
        new EndorsementMortagee().validateAddMortgageeButtonDisabled();
        new PolicyChanges().cancelWithDrawEndorsement();
        new PolicyChangeSummaryPage().validatePolicyChangeStatus("Withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement" } , description = "TC4015: Verify validation messages when no mandatory fields are provided while adding Valuables")
    public void MissingMandatoryValuesWhileAddingValuables(String browserName) throws Exception {
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().selectValuables()
                .clickAddValuable();
        new EndorsementEditToolBar().saveEndorsement();
        new EndorsementValuables().validateAddButtonDisabled();
        new PolicyChanges().cancelWithDrawEndorsement();
        new PolicyChangeSummaryPage().validatePolicyChangeStatus("Withdrawn");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement","CSR" } , description = "TC4016: Verify user can perform change to HO policy by editing existing Mortgagee")
    public void testHOChangeEditMortgagee(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("MortGagee_Name","Napoleon");
        data.put("MortGagee_Street","123 Baker street");
        data.put("MortGagee_City","Foster City");
        data.put("MortGagee_State","California");
        data.put("MortGagee_State_Value","CA");
        data.put("MortGagee_Zip","94404");
        data.put("MortGagee_Eff_date","");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addMortageeDraftEndorsementFromChangePage();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy();
        data.put("MortGagee_Name","Bonopart");
        new PolicySummary().clickChangePolicyButton()
                .goNext();
        new EndorsementWorkFlow().editMortgageeEndorsementFromChangePageAndBuyIt();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite", "Endorsement","CSR" } , description = "*** BUG - DE7721 - TC4017: Verify user can perform change to HO policy by editing Valuables")
    public void testHOChangeEditValuables(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("Valuable_Cost","2323");
        data.put("Valuable_Type","Cameras");
        data.put("Valuable_Desc","Description");
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addValuableDraftEndorsementFromChangePage();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy();
        data.put("Valuable_Cost","2325");
        new PolicySummary().clickChangePolicyButton()
                .goNext();
        new EndorsementWorkFlow().editValuableEndorsementFromChangePageAndBuyIt();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables edit changes are not applied to policy");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement" } , description = "TC4019: Verify user can perform change to HO policy by removing existing Mortgagee")
    public void testHOChangeRemoveMortgagee(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("MortGagee_Name","Napoleon");
        data.put("MortGagee_Street","123 Baker street");
        data.put("MortGagee_City","Foster City");
        data.put("MortGagee_State","California");
        data.put("MortGagee_State_Value","CA");
        data.put("MortGagee_Zip","94404");
        data.put("MortGagee_Eff_date","");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addMortageeDraftEndorsementFromChangePage();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy();

        new PolicySummary().clickChangePolicyButton()
                .goNext();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(new EndorsementWorkFlow().buyRemoveMortgageeEndorsementFromChangePage()).shouldBeFalse("Mortgagee is not deleted from policy");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Endorsement"  } , description = "***BUG - DE7721 - TC4020: Verify user can perform change to HO policy by removing valuables")
    public void testHOChangeRemoveValuables(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("Valuable_Cost","2323");
        data.put("Valuable_Type","Cameras");
        data.put("Valuable_Desc","Description");
        data.put("Valuable_Deductible","$1,000");
        data.put("Valuable_Validation_method","Replacement cost");
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        goToPolicyChangePage("HomeOwner");
        new EndorsementWorkFlow().addValuableDraftEndorsementFromChangePage();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy();
        new PolicySummary().clickChangePolicyButton()
                .goNext();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(new EndorsementWorkFlow().buyRemoveValuableEndorsementFromChangePage()).shouldBeFalse("Valuables is not deleted from policy");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"  } , description = "TC3982: Verify 'Change Policy' functionality for PA policy- remove a vehicle")
    public void testRemoveVehicleEndorsement(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("VIN","ABCDE123");
        data.put("LicensePlate","12345");
        data.put("Make","AAA");
        data.put("Model","A3");
        data.put("VehicleYear","2000");
        data.put("VehicleState","California");
        data.put("VehicleCost","100");
        data.put("COST_DESC","$100.00");
        data.put("STATE_VALUE","CA");
        data.put("NewCity","Khust");
        goToPolicyChangePage("PersonalAuto").checkVehiclesChanges()
                .goNextToChangePolicyForm();
        new EndorsementWorkFlow().addVehicleDraftEndorsementFromEditEndosmentForm(true);
        new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyAndRedistributeCoverageChanges();
        new EndorsementPaymentPage().clickBackToPolicy();
        new PolicySummary().clickChangePolicyButton()
                .goNext()
                .checkVehiclesChanges()
                .goNextToChangePolicyForm();
        String vin =  new EndorsementWorkFlow().buyRemovedVehicleEndorsementFromEndorsmentChanges();
        new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(vin).shouldBeFalse("Vehicle is was not deleted from policy");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR","CSR_DIA" } , description = "TC3986: Verify 'Change Policy' functionality for PA policy- remove a driver")
    public void testRemoveDriverEndorsement(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("GENDER","Male");
        data.put("ACCIDENTS","1");
        data.put("VIOLATIONS","1");
        data.put("STATE","California");
        data.put("YEAR_LICENSED","2014");
        data.put("FIRST_NAME","Lee");
        data.put("LAST_NAME","Carvallo");
        data.put("DOB","10/10/1987");
        data.put("DOB_TO_CHECK","October 10, 1987");
        data.put("LICENSE_NUMBER","321111");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow()
                .addDriverDraftEndorsementStartingFromDateForm(true);
        new EndorsementEditToolBar().check();
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("added");
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy();
        new PolicySummary()
                .clickChangePolicyButton()
                .goNext()
                .checkDriversChanges()
                .goNextToChangePolicyForm();
        String lisence =  new EndorsementWorkFlow().buyRemovedDriverEndorsementFromEndorsmentChanges();
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(lisence).shouldBeFalse("Vehicle is avaliable in the policy while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR", "CSR_DIA"} , description = "TC3991: Verify for validation message is displayed when user provides effective date not within the policy period for Change action, GPA-859")
    public void testChangePolicyEffectiveDateNotWithinPolicyPeriod(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        String date = policySummary
                .clickChangePolicyButton().getDate();
        new PolicyChanges().setPast();
        new Validation(new PolicyChanges().getDate(), date).shouldBeEqual("Date was successfully sent in past while it shouldn't.");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC3992: Verify for validation message is displayed when user does not provide mandatory fields for Change action")
    public void testChangePolicyMandatoryFieldValidation(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("BusinessOwner");
        policySummary.clickChangePolicyButton()
                .setBODate("")
                .submitBOPolicyChanges()
                .validateBOPolicyChangesIsNextButtonDisabled();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement" } , description = "TC4021: Verify 'Change Policy' functionality for PA policy- add a driver under 25 age")
    public void testPAPolicyChangeAddDriverUnder25(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("GENDER","Male");
        data.put("ACCIDENTS","1");
        data.put("VIOLATIONS","1");
        data.put("STATE","California");
        data.put("YEAR_LICENSED","2017");
        data.put("FIRST_NAME","Lee");
        data.put("LAST_NAME","Carvallo");
        data.put("DOB","10/10/2000");
        data.put("DOB_TO_CHECK","October 10, 2000");
        data.put("LICENSE_NUMBER","321111");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow()
                .addDriverDraftEndorsementStartingFromDateForm(true);
        new EndorsementEditToolBar().check();
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("added");
        new EndorsementWorkFlow().quoteEndorsement()
                .buyWithCheckingBankAccount();
        new EndorsementPaymentPage().clickBackToPolicy()
                .isPolicyDetailsPageLoaded().shouldBeTrue("Policy details page was not loaded");
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("LICENSE_NUMBER")).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement" } , description = "TC4022: Verify 'Change Policy' functionality for PA policy- add a high value vehicle")
    public void testPAPolicyChangeAddHighValueVehicle(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("VIN","ABCDE123");
        data.put("LicensePlate","12345");
        data.put("Make","AAA");
        data.put("Model","A3");
        data.put("VehicleYear","2000");
        data.put("VehicleState","California");
        data.put("VehicleCost","1000000");
        data.put("COST_DESC","$1,000,000.00");
        data.put("STATE_VALUE","CA");
        data.put("NewCity","Khust");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow().selectVehicle().addVehicleDraftEndorsementFromEditEndosmentForm(true);
        new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyAndClickRedistributeCoverageChanges();
        new EndorsementPaymentPage().validateUnderwriterIssueMessage();
        new EndorsementPaymentPage().clickBackToPolicy();
        new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(data.get("VIN")).shouldBeTrue("Vehicle doesn't appear in policy");
        new PolicySummary().openPolicySummaryOfChangedPolicy();
        new PolicyChangeSummaryPage().validateHighValueVehicleUnderwritingIssue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement" } , description = "TC4024: Verify Policy Change details page")
    public void testVerifyPolicyChangeDetailspageWithUWIssue(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("VIN","ABCDE123");
        data.put("LicensePlate","12345");
        data.put("Make","AAA");
        data.put("Model","A3");
        data.put("VehicleYear","2000");
        data.put("VehicleState","California");
        data.put("VehicleCost","1000000");
        data.put("COST_DESC","$1,000,000.00");
        data.put("STATE_VALUE","CA");
        data.put("NewCity","Khust");
        goToPolicyChangePage("PersonalAuto");
        new EndorsementWorkFlow().selectVehicle().addVehicleDraftEndorsementFromEditEndosmentForm(true);
        new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
        new EndorsementWorkFlow().quoteEndorsement()
                .buyAndClickRedistributeCoverageChanges();
        new EndorsementPaymentPage().clickBackToPolicy();
        new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(data.get("VIN")).shouldBeTrue("Vehicle doesn't appear in policy");
        new PolicySummary().openPolicySummaryOfChangedPolicy();
        new PolicyChangeSummaryPage().validateHighValueVehicleUnderwritingIssue();
        new PolicyChangeSummaryPage().validateTilesOnPolicyChangeSummaryPage();
        new PolicyChangeSummaryPage().validatePolicyChangeSummaryPageComponents();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement" } , description = "TC3993: Verify Policy Change details page")
    public void testVerifyPolicyChangeDetailspageWithoutUWIssue(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("STATE","California");
        data.put("COVERAGE_VALUE","15,000");
        data.put("ABANum","12345");
        data.put("BankName","ABCDEF");
        data.put("AccountNum","98765");
        goToPolicyChangePage("PersonalAuto")
                .checkCoveragesChanges()
                .goNextToChangePolicyForm();
        new EndorsementCoveragesPage().setMedicalLimit();
        new EndorsementWorkFlow().quoteEndorsement();
        new PolicyChanges().clickSaveAndExitBtn();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage.validateWithdrawPolicyChangeButton();
        policyChangeSummaryPage.validateContinuePolicyChangeButton();
        policyChangeSummaryPage.validateTilesOnPolicyChangeSummaryPage();
        policyChangeSummaryPage.validatePolicyChangeSummaryPageComponents();
    }


    private void login(){
        new LoginPage().login();
    }

    private PolicySummary goToPolicySummaryPage(String policyType)
    {
        String policyNum;
        if (policyType.equals(DataConstant.PA)){
            policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        }else if(policyType.equals(DataConstant.HO)){
            policyNum = PolicyGenerator.createBasicBoundHOPolicy();
        }else{
            policyNum = PolicyGenerator.createBasicBoundBOPolicy();
        }
        login();
        return new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum);
    }

    private PolicyChanges goToPolicyChangePage(String policyType)
    {
        return  goToPolicySummaryPage(policyType)
                .clickChangePolicyButton()
                .goNext();
    }

}
