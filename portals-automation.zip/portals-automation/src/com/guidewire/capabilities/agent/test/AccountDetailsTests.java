package com.guidewire.capabilities.agent.test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.*;
import com.guidewire.capabilities.agent.scenarios.BindCancellationOnPolicyScenario;
import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.capabilities.common.interfaces.ICancelPolicyDetailsPage;
import com.guidewire.capabilities.common.interfaces.ICommonPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


/**
 * @author Darya Fedo
 */
public class AccountDetailsTests {

String platform = System.getProperty("platform");

    IBindPolicyCancellationPage goToSubmitCancellation(ICommonPage scenario) {
        return goToCancellationForm(scenario)
                .fillMandatoryProperties()
                .submitCancellation();
    }

    ICancelPolicyDetailsPage goToCancellationForm(ICommonPage scenario) {
        return scenario
                .login()
                .clickPolicyLinkOnNavBar()
                .clickOnPolicy()
                .clickOnCancelPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "TC3481 : Verify Open Activities on Account details page")
    public void testOpenActivitiesOnAccountDetails(String browserName) throws Exception {
        GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory();
        PolicyGenerator.createBasicBoundPAPolicy();
        activityFactory.addActivityOnAccountDetailsPage();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToActivitiesTile()
                .isOpenActivitiesTileOpened();
        new ActivitiesScheduleComponent().validateAllActivityScheduleUIComponents();
    }
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3482 : Verify Open Quotes on Account details page")
    public void testOpenQuotesOnAccountDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createDraftQuote();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToOpenQuotes()
                .isQuotePresented().shouldBeTrue("Quote is not presented.");
        new AccountSummary().validateQuoteTileComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC3483: Verify only personal auto claims can be displayed on Claims page by selecting the right filter")
    public void testDisplayOnlyPersonalAutoClaimsOnAccDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        if (platform.equalsIgnoreCase("granite"))
            ThreadLocalObject.getData().put("ProductCode", "PersonalAuto");
        new GPA_QuotePageFactory().createQuotedQuote();
        new PAQuotePage().buyQuotedPolicy().goToAccountDetailPage()
                .goToClaimTile()
                .createPACollisionClaim();
        new ClaimsTileView().createHOFireClaim();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToClaimTile()
                .filterClaimsByLOB("Personal Auto")
                .validateFilteredLOBClimes("Personal Auto");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" } , description = "TC3484: Verify Open Transactions on Account details page.")
    public void testOpenTransactionsOnAccountDetails(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createDraftQuote();
        new QuoteSummary().goToAccountPage()
                .goToFirstPolicyInList()
                .createChangePolicyTransaction()
                .clickPolicyLink(policyNum);
        new BindCancellationOnPolicyScenario(policyNum).clickOnCancelPolicy()
                .fillMandatoryProperties()
                .submitCancellation();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToOpenTransactionsTile();
        new OpenTransactionsTileVew().validateAllOpenTransactionTileComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3485 : Verify Claims on Account details page")
    public void testClaimsOnAccountDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToClaimTile().createPACollisionClaim();
                new ClaimsTileView().validateClaimTileViewUIElements().shouldBeTrue("Quote is not presented.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3486 : Verify Billing information on Account details page. Need to Add SIMPLE DATE - ACCOUNT_FIRST_NAME AND ACCOUNT_SECOND_NAME")
    public void testBillingOnAccountDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToBillingTile();
        new BillingTileView().validateBillingTileUIComponentsGPA().shouldBeTrue("Data doesn't match with Backend");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC3494: Verify only homeowner claims can be displayed on Claims page by selecting the right filter")
    public void testDisplayOnlyHomeownerClaimsOnAccDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        if (platform.equalsIgnoreCase("granite"))
            ThreadLocalObject.getData().put("ProductCode", "PersonalAuto");
        new GPA_QuotePageFactory().createQuotedQuote();
        new PAQuotePage().buyQuotedPolicy().goToAccountDetailPage()
                .goToClaimTile()
                .createPACollisionClaim();
        new ClaimsTileView().createHOFireClaim();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToClaimTile()
                .filterClaimsByLOB("Homeowners")
                .validateFilteredLOBClimes("Homeowners");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" } , description = "TC3508: Verify user can view Quote details from Account details page")
    public void testViewQuoteFromAccountDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createDraftQuote();
        new NavBar().goToAccountsLanding()
                .clickAccountNameLink()
                .goToOpenQuotes()
                .openQuoteByLink()
                .validateQuotePageComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond"} , description = "TC3503: Verify user can view account information from activities")
    public void testAccountLinkOnAcitivitiesDetailsOnAccountDetails(String browserName) throws Exception {
        new GPA_ActivityPageFactory().addActivityOnAccountDetailsPage();
        new NavBar().goToDashBoard()
                .searchUsingSearchBox(ThreadLocalObject.getData().get("POLICY_NUM"))
                .goToAccountFromPolicySearch()
                .goToActivitiesTile()
                .openAccountPageByLink()
                .isAccountSummaryPageLoaded().shouldBeTrue("Account page was not loaded properly");
        new AccountSummary().validateSummaryTileOpened().shouldBeEqual("Account page was not opened on Summary tile");
    }

}
