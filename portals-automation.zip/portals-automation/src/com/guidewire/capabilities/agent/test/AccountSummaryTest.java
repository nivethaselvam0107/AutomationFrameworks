package com.guidewire.capabilities.agent.test;


import com.guidewire.capabilities.agent.model.page.AccountSummary;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AccountSummaryTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3480:SummaryOnAccountDetails")
    public void verifyAccountSummaryHomePage(String browserName) throws Exception {
        AccountSummary.verifyAccountSummaryHomePage(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC348: MissingMandatoryValuesWhileEditingContactInformation")
    public void verifyMissingMandatoryValuesWhileEditingContactInformation(String browserName) throws Exception {
        AccountSummary.verifyMissingMandatoryValuesWhileEditingContactInformation(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC388: InvalidZipCodeWhileEditingContactDetails")
    public void verifyInvalidZipCodeWhileEditingContactDetails(String browserName) throws Exception {
        AccountSummary.verifyInvalidZipCodeWhileEditingContactDetails(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3489: InvalidPhoneNumberWhileEditingContactDetails")
    public void verifyInvalidPhoneNumberWhileEditingContactDetails(String browserName) throws Exception {
        AccountSummary.verifyInvalidPhoneNumberWhileEditingContactDetails(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3490: InvalidEmailIdWhileEditingContactDetails")
    public void verifyInvalidEmailIdWhileEditingContactDetails(String browserName) throws Exception {
        AccountSummary.verifyInvalidEmailIdWhileEditingContactDetails(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3492: MissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails")
    public void verifyMissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails(String browserName) throws Exception {
        AccountSummary.verifyMissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3491: CancelEditContactDetailAction")
    public void verifyCancelEditContactDetailAction(String browserName) throws Exception {
        AccountSummary.verifyCancelEditContactDetailAction(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3495: ViewPolicyFromAccountSummaryPage")
    public void verifyViewPolicyFromAccountSummaryPage(String browserName) throws Exception {
        AccountSummary.verifyViewPolicyFromAccountSummaryPage(browserName);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"} , description = "TC3496: ViewPolicyFromAccountDetailsBilling")
    public void verifyViewPolicyFromAccountDetailsBilling(String browserName) throws Exception {
        AccountSummary.verifyViewPolicyFromAccountDetailsBilling(browserName);
    }


}



