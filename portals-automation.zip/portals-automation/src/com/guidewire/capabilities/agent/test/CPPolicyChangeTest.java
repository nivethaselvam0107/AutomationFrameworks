package com.guidewire.capabilities.agent.test;


import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.PolicyChangeSummaryPage;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

public class CPPolicyChangeTest {


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7025:CPPolicyChangeWithinGP")
    public void testCPPolicyChangeWizardEntryPolicyDetails(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToCPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage().validatePageHeaderForPolicyChange(PolicyType.CP.toString(), data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPPolicyDetailsPage().validatePresenceOfAllFields(PolicyType.CP.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7034:CancelPolicyChangeonPolicyDetailsScreen")
    public void testCPPolicyChangeCancelOnPolicyDetailsPage(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage()
                .setOrgType(true)
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");
        policyChangeSummaryPage
                .continuePolicyChange();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .goPrev();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .validatePolicyDetailsWithBackend(PolicyType.CP.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7026:AddBuildingManuallyChangeOnCP")
    public void testCPPolicyChangeAddBuilding(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .addBuildingToDefaultLocation(true)
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForIncrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickSpreadPayments();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink();
        new PolicySummary()
                .validateBuildingOnPolicy(PolicyType.CP.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7028:DeleteBuildingManuallyChangeOnCP")
    public void testCPPolicyChangeRemoveBuilding(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        String buildingDesc = pagefactory
                .getCPBuildingsAndLocationsPage()
                .getFirstBuildingDesc();
        ThreadLocalObject.getData().put("NewBuildingDescription", buildingDesc);
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .removeBuildingFromListing()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForDecrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isBuildingPresentOnPolicyOnBackend().shouldBeFalse("Building still present in backend.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7027:EditBuildingDetailsManuallyChangeOnCP")
    public void testCPPolicyChangeEditBuildingDetails(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .openFirstBuildingFromListing()
                .expandBuildingSummaryInAddBuildingFlow()
                .clickEditOnBuildingSummary()
                .setBuildingDesc(data.get("NewBuildingDescription"))
                .saveAddedBuilding();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickBackOnViewModes()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForNoChange();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isBuildingPresentOnPolicyOnBackend().shouldBeTrue("Building not present on policy");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7051:AddBuildingToNewLocationManuallyChangeOnCP")
    public void testCPPolicyChangeAddBuildingNewLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        data.put("BuildingDescription", data.get("NewBuildingDescription"));
        data.put("LocAddressLine1", data.get("NewLocAddressLine1"));
        data.put("LocationCity", data.get("NewLocationCity"));
        data.put("LocationState", data.get("NewLocationState"));
        data.put("AddressHeader", data.get("NewAddressHeader"));

        pagefactory
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForIncrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickSpreadPayments();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateNewLocationOnCPBOPolicy();
        new PolicySummary()
                .validateBuildingOnPolicy(PolicyType.CP.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7027:EditCoverageOnBuildingsChangeOnCP")
    public void testCPPolicyChangeEditCoverageOnBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .openFirstBuildingFromListing()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveCoveragesOnBuilding();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .expandBuildingSummaryInAddBuildingFlow()
                .clickEditOnBuildingSummary()
                .setBuildingDesc(data.get("NewBuildingDescription"))
                .saveAddedBuilding();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickBackOnViewModes()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForDecrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();

        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateBuildingOnPolicy(PolicyType.CP.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7035:CancelPolicyChangeonBuildingsAndLocationScreen")
    public void testCPPolicyChangeCancelOnBuildingsAndLocations(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .openFirstBuildingFromListing()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .setPersonalPropertyLimit()
                .saveCoveragesOnBuilding();

        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickBackOnViewModes()
                .pressCancelAndConfirm();

        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");

        policyChangeSummaryPage
                .continuePolicyChange();

        new CPBuildingsAndLocations()
                .openFirstBuildingFromListing()
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("NewBuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7036:CancelPolicyChangeOnQuoteScreen")
    public void testCPPolicyChangeCancelOnQuoteScreen(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .openFirstBuildingFromListing()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .setPersonalPropertyLimit()
                .saveCoveragesOnBuilding();

        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickBackOnViewModes()
                .clickNext();

        pagefactory
                .getCPBOPQuotePage()
                .pressCancelAndConfirm();

        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Quoted");

        policyChangeSummaryPage
                .continuePolicyChange();

        new CPBOPQuotePage()
                .isCPQuotePageLoaded().shouldBeTrue("Quote screen wasn't opened");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7037:CancelPolicyChangeOnPaymentScreen")
    public void testCPPolicyChangeCancelOnPaymentScreen(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .addBuildingToDefaultLocation(true)
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickPay()
                .setABARoutingNumber()
                .setAccountNumber()
                .setBankName()
                .pressCancelAndConfirm();

        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Quoted");

        policyChangeSummaryPage
                .continuePolicyChange();

        new CPBOPQuotePage()
                .isCPQuotePageLoaded().shouldBeTrue("Quote screen wasn't opened");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7038:ViewCPPolicyDetailsFromConfirmationPage")
    public void testCPPolicyChangeOpenPolicyFromConfirmation(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .addBuildingToDefaultLocation(true)
                .clickNext();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForIncrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickSpreadPayments();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyBtn();

        new PolicySummary()
                .validateTileOpened("SUMMARY").shouldBeEqual("Summary tile of policy wasn't selected");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7607,TC7619:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Basic")
    public void testCPPolicyChangeCoverageDependencyBuildingBasic(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Basic", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7623,TC7611:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Broad")
    public void testCPPolicyChangeCoverageDependencyBuildingBroad(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Broad", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7609,TC7621:CommercialPropertyCoverageDependencyPolicyChange-CauseOfLoss-Special")
    public void testCPPolicyChangeCoverageDependencyBuildingSpecial(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Special", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeTrue("Exclude Theft coverage term unavailable for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7620,TC7608:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalPropertyCoverage-CauseOfLoss-Basic")
    public void testCPPolicyChangeCoverageDependencyBusinessPersonalPropertyBasic(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Basic", "Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7612,TC7624:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalProperty-CauseOfLoss-Broad")
    public void testCPPolicyChangeCoverageDependencyBusinessPersonalPropertyBroad(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Broad","Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7622,TC7610:CommercialPropertyCoverageDependencyPolicyChange-BusinessPersonalProperty-CauseOfLoss-Special")
    public void testCPPolicyChangeCoverageDependencyBusinessPersonalPropertySpecial(String browserName) throws Exception {
        goToCPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        this.setCauseOfLossOnNewBuilding("Special", "Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeTrue("Exclude Theft coverage term unavailable for Building Coverage");
    }

    private void setCauseOfLossOnNewBuilding(String cause, String cvgTerm){
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), true)
                .clickNext();
        if(cvgTerm.equals("Building"))
            cpBuildingsAndLocations.selectCauseOfLossForBuildingCoverage(cause);
        else
            cpBuildingsAndLocations.selectCauseOfLossForBusinessPersonalPropertyCoverage(cause);
    }

    private PolicySummary goToCPolicySummaryPage()
    {
        ThreadLocalObject.getData().putIfAbsent("PRODUCT_CODE", "CommercialProperty");
        String policyNum = PolicyGenerator.createBasicBoundCPPolicy(1,2);
        login();
        return new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum);
    }

    private void login(){
        new LoginPage().login();
    }
}
