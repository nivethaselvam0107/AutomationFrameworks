package com.guidewire.capabilities.agent.test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AccountsLanding;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

/**
 * Created by dfedo on 05/01/2017.
 */
public class AccountLandingPageTest {


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3531: Verify the policies count link on Account landing page")
    public void testPoliciesCountLinkOnAccountLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToAccountsLanding()
                .clickPolicyCountLink()
                .isAccountSummaryPageLoaded().shouldBeTrue("Account Page was not loaded correctly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3525 : Verify user can view Account details page from account landing page.")
    public void testViewAccountFromAccountLanding(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new AgentDashboard()
                .searchUsingSearchBox(policyNumber)
                .goToAccountFromPolicySearch()
                .isAccountSummaryPageLoaded().shouldBeTrue("Account Summary page was not loaded");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3527 : Verify the open activites count link on Account landing page")
    public void testOpenActivitiesCountLinkOnAccountLanding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().login();
        new NavBar().goToAccountsLanding()
                .clickOpenpenActivitiesLink()
                .isOpenActivitiesTileOpened().shouldBeTrue("Open Activities tile was not opened.");
    }
}
