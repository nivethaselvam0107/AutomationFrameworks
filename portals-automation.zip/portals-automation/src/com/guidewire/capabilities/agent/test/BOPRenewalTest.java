package com.guidewire.capabilities.agent.test;


import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.PolicyRenewalSummaryPage;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

public class BOPRenewalTest {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6696, TC7358: RenewalDetailsPageWhenQuoted")
    public void testCPPolicyRenewalDetailsPageWhenQuoted(String browserName) throws Exception {
        this.goTillRenewalQuoteScreenAfterChangingAddCoverages()
        .pressCancelAndConfirm();
        new PolicyRenewalSummaryPage().validateMessageOnRenewalDetailPage(DataConstant.BOP_MESSAGE_QUOTED_RENEWAL);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6700:BOPPolicyRenewalWithinGP")
    public void testBOPPolicyRenewalWizardEntryPolicyDetails(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .renewMyPolicy();
        new CPBOPPolicyDetailsPage().validatePageHeaderForPolicyRenewal(PolicyType.BO.toString(), data.get("POLICY_NUM"));
        new CPBOPPolicyDetailsPage().validatePresenceOfAllFields(PolicyType.BO.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC7277: MessageOnPaymentScreenRenewalOnBOP")
    public void testCPRenewalMessageOnPaymentScreen(String browserName) throws Exception {
        this.goTillRenewalQuoteScreenAfterChangingAddCoverages()
                .clickNext();
        new PaymentDetailsPage().validateMessageOnRenewalPaymentForAgent();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6672: CancelRenewalOnGeneralCoverageScreenWithInvalidForm")
    public void testBOPRenewalGoToAccountFromGeneralCoverages(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .clickOnAccountLinkFromWizard()
                .goToOpenTransactionsTile()
                .openFirstJob();
        new PolicyRenewalSummaryPage()
                .continuePolicyRenewal();
        pagefactory
                .getBOPGenCoveragePage()
                .validateEmployeeDishonestyFieldsAreEmpty();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6673: CancelRenewalOnAdditionalCoverageScreenWithInvalidForm")
    public void testBOPRenewalGoToAccountFromAddCoverages(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Terror - Cap on Cert. Acts", false);
        pagefactory
                .clickOnAccountLinkFromWizard()
                .goToOpenTransactionsTile()
                .openFirstJob();
        new PolicyRenewalSummaryPage()
                .continuePolicyRenewal();
        pagefactory
                .getBOPAddCoveragePage()
                .validateTerrorSelectedAndEmpty();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6695, TC7357: RenewalDetailsPageWhenInDraft")
    public void testCPPolicyRenewalDetailsPageWhenInDraft(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .pressCancelAndConfirm();
        new PolicyRenewalSummaryPage().validateMessageOnRenewalDetailPage(DataConstant.BOP_MESSAGE_DRAFT_RENEWAL);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6681, TC7354: DetailsandTilesOnRenewalDetailsPage")
    public void testCPPolicyRenewalPageDetailsAndTiles(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .pressCancelAndConfirm();
        new PolicyRenewalSummaryPage().validateTilesAndHeaderOnPolicyRenewalSummaryPage();
    }

    @Parameters("browserName")
    @Test(groups = {"CSR","CSR_DIA"}, description = "TC7351: RenewalDetailsPageCancelRenewal-CustomerRequest")
    public void testCPRenewalCancelOnCustomerRequest(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .pressCancelAndConfirm();
        new PolicyRenewalSummaryPage()
                .clickCancelRenewal()
                .selectReasonForCancellation("Customer")
                .confirmCancelRenewal();
        new PolicyRenewalSummaryPage().validateMessageOnRenewalDetailPage(DataConstant.BOP_MESSAGE_NOT_TAKEN_RENEWAL);
        new PolicyRenewalSummaryPage().validatePolicyRenewalJobStatus("Not-taking");
    }

    @Parameters("browserName")
    @Test(groups = {"CSR","CSR_DIA"}, description = "TC7353: RenewalDetailsPageCancelRenewal-InsurerRequest")
    public void testCPRenewalCancelOnInsurerRequest(String browserName) throws Exception {
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .pressCancelAndConfirm();
        new PolicyRenewalSummaryPage()
                .clickCancelRenewal()
                .selectReasonForCancellation("Insurer")
                .confirmCancelRenewal();
        new PolicyRenewalSummaryPage().validateMessageOnRenewalDetailPage(DataConstant.BOP_MESSAGE_NOT_RENEWING_RENEWAL);
        new PolicyRenewalSummaryPage().validatePolicyRenewalJobStatus("Non-renewing");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, enabled=false, description = "TC6694: AdditionalCoverageRenewalOnBOP")
    public void testBOPRenewalModifyAddCoverages(String browserName) throws Exception {
        this.goTillRenewalQuoteScreenAfterChangingAddCoverages()
                .clickNext();
        new Pagefactory()
                .getPaymentInfoPage()
                .payAnnualPremiumWithSavingsBankAccount()
                .clickReferRenewalToUW()
                .confirmReferRenewalToUW();
        new PolicyRenewalSummaryPage()
                .validatePolicyRenewalJobStatus("Quoted");

    }

    private CPBOPQuotePage goTillRenewalQuoteScreenAfterChangingAddCoverages(){
        this.goToBOPolicySummaryPage()
                .renewMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        return pagefactory
                .getCPBOPQuotePage();
    }

    private PolicySummary goToBOPolicySummaryPage()
    {
        String policyNum = PolicyGenerator.createBasicBoundBOPolicy();
        ThreadLocalObject.getData().put("POLICY_NUM", policyNum);
        login();
        return new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum);
    }

    private void login(){
        new LoginPage().login();
    }
}
