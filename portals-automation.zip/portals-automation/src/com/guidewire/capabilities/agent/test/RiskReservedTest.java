package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.PAQuotePage;

/**
 * Created by dfedo on 14/06/2017.
 */
public class RiskReservedTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4162 @ Verify risk reserved functionality when policies are bound")
    public void testRiskReservedFunctionalityWhenPoliciesAreBound(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        ThreadLocalObject.getData().put("ProductCode", "PersonalAuto");
        ThreadLocalObject.getData().put("PolicyType", "PersonalAuto");
        new GPA_QuotePageFactory().loginAndStartQuote()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .withState()
                .setProducerCode(2)
                .isProductCodeDisabledWithRiskReservedTag().shouldBeTrue("Product Code is not disabled with *RR tag.");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4160 @ Verify risk reserved functionality when policies are quoted")
    public void testRiskReservedFunctionalityWhenPoliciesAreQuoted(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        new PAQuotePage().goToAccountPage();
        new GPA_QuotePageFactory().clickQuoteBtnAndFindAccount()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .withState()
                .setProducerCode(1)
                .isProductCodeDisabledWithRiskReservedTag().shouldBeFalse("Product Code disabled with *RR tag while shouldn't.");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4161 @ Verify risk reserved functionality when policies are issued")
    public void testRiskReservedFunctionalityWhenPoliciesAreIssued(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount().createAndBuyPolicyPA();
        new GPA_QuotePageFactory().clickQuoteBtnAndFindAccount()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .withState()
                .setProducerCode(2)
                .isProductCodeDisabledWithRiskReservedTag().shouldBeTrue("Product Code is not disabled with *RR tag.");
    }
}
