package com.guidewire.capabilities.agent.test.activity;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.AddActivityComponent;
import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.ReassignActivityComponent;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.Modal;

public class ActivitiesTest {

	GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory(); 
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"} , description = "TC3497: ViewActivityDetailsOnAccountDetails, GPA--733:ViewActivityDetails")
    public void ViewActivityDetailsOnAccountDetails(String browserName) throws Exception {
    	activityFactory.addActivityOnAccountDetailsPage();
        new ActivitiesScheduleComponent()
            .clickOnFirstActivity()
            .canViewActivitySummary()
                .shouldBeTrue();
        
        //TODO for activity Summary
        }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3498: AddActivityOnAccountDetails")
    public void AddActivityOnAccountDetails(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	activityFactory.	clickAddActivityButtonFromAccountActivityTile();
    	String subject = new SeleniumCommands().generateUUID();
    	activityFactory.addDefaultActivity(subject).isAddActivityComponentVisible().shouldBeTrue("Activit is not listed");
        
        //TODO for activity listing
        }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3499: CancelAddActivityOnAccountDetails")
    public void CancelAddActivityOnAccountDetails(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	activityFactory.	clickAddActivityButtonFromAccountActivityTile();
        new AddActivityComponent()
                .withActivityTypeByText("Cancel a split policy")
                .withSubject("Cancel a split policy - cancel activity testcase")
                .clickCancelButton()
                .isAddActivityComponentVisible()
                .shouldBeFalse();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3500: MissingTypeWhileAddingActivityOnAccountDetails")
    public void MissingTypeWhileAddingActivityOnAccountDetails(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	activityFactory.clickAddActivityButtonFromAccountActivityTile();
    	new AddActivityComponent()
                .submit()
                .isChooseActivityTypeErrorModalShown()
                .shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "SMOKE" } ,description = "TC3501: AddNoteToOpenActivityOnAccountDetails")
    public void AddNoteToOpenActivityOnAccountDetails(String browserName) throws Exception {
    	activityFactory.addActivityOnAccountDetailsPage();
    	activityFactory.expandFirstActivity().clickAddNoteButton().addNoteToNonCompleteActivity();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3502: MissingMandatoryValuesWhileAddingNoteToActivityOnAccountDetails")
    public void MissingMandatoryValuesWhileAddingNoteToActivityOnAccountDetails(String browserName) throws Exception {
    	activityFactory.addActivityOnAccountDetailsPage();
        new ActivitiesScheduleComponent()
                .clickOnFirstNonCompleteActivityUserOwns()
                .clickAddNoteButton();

        new AddNoteComponent()
                .submit()
                .areRequiredFieldsMarked();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3504: ReassignActivityOnAccountDetails")
    public void ReassignActivityOnAccountDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
	    	String UUID = new SeleniumCommands().generateUUID();
	    	activityFactory.	clickAddActivityButtonFromAccountActivityTile();
	    	activityFactory.	addDefaultActivity(UUID);
        ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent();

        reassignActivityComponent
                .openReassignActivityDropdown()
                .setAssigneeByName()
                .clickConfirmButton();

        Modal.waitHidden();

        reassignActivityComponent
                .isNotAssignedToCurrentUser().shouldBeTrue("Activity is still assigned to current user");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3505: CancelReassignActivityOnAccountDetails")
    public void CancelReassignActivityOnAccountDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
	    	String UUID = new SeleniumCommands().generateUUID();
	    	activityFactory.clickAddActivityButtonFromAccountActivityTile();
	    	activityFactory.addDefaultActivity(UUID);

        ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent();

        reassignActivityComponent
                .openReassignActivityDropdown()
                .setAssigneeByName()
                .clickCancelButton();

        Modal.waitHidden();

        reassignActivityComponent
                .isAssignedToCurrentUser()
                .shouldBeEqual("Activity is not assigned to current user");
    }

      @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3506: CompleteActivityOnAccountDetails")
    public void CompleteActivityOnAccountDetails(String browserName) throws Exception {
    	    activityFactory.addActivityOnAccountDetailsPage();
        new ActivitiesScheduleComponent().setActivityFilter("Open, Assigned to me")
                .clickOnFirstActivity()
                .completeActivity()
                .doesActivityShowCompleted()
                .shouldBeTrue();

    }
 
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "SMOKE_EMR" }, description = "TC5700: CompleteActivityOnDashboard")
    public void CompleteActivityOnDashboard(String browserName) throws Exception {
    	  activityFactory.addActivityOnAccountDetailsPage();
  	  new NavBar().goToDashBoard();
       new ActivitiesScheduleComponent()
                .clickOnFirstNonCompleteActivityUserOwns()
                .completeActivity()
                .doesActivityShowCompleted()
                .shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "SMOKE" } , description = "TC5939: AddNoteToCompletedActivityOnDashboard")
    public void AddNoteToCompletedActivityOnDashboard(String browserName) throws Exception {
    	  activityFactory.addActivityOnAccountDetailsPage();
  	  new NavBar().goToDashBoard();
       ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
        activitiesScheduleComponent
        .clickOnFirstNonCompleteActivityUserOwns()
        .completeActivity()
        .doesAddNoteButtonExist()
        .shouldBeFalse();

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"  }, description = "TC3507: AddNoteToCompletedActivityOnAccountDetails")
    public void AddNoteToCompletedActivityOnAccountDetails(String browserName) throws Exception {
    	    activityFactory.addActivityOnAccountDetailsPage();
        ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
        activitiesScheduleComponent
                .clickOnFirstNonCompleteActivityUserOwns()
                .completeActivity()
                .doesAddNoteButtonExist()
                .shouldBeFalse();
    }

    /*DASHBOARD*/

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5699: ViewActivityDetailsOnDashboard")
    public void ViewActivityDetailsOnDashboard(String browserName) throws Exception {
  	  activityFactory.addActivityOnAccountDetailsPage();
	  new NavBar().goToDashBoard();
        new ActivitiesScheduleComponent()
                .clickOnFirstActivity()
                .canViewActivitySummary()
                .shouldBeTrue();

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3501: AddNoteToOpenActivityOnDashboard")
    public void AddNoteToOpenActivityOnDashboard(String browserName) throws Exception {
     	activityFactory.addActivityOnAccountDetailsPage();
  	    new NavBar().goToDashBoard();
        new ActivitiesScheduleComponent()
                .clickOnFirstNonCompleteActivityUserOwns()
                .clickAddNoteButton();
        new AddNoteComponent()
                .withTopic()
                .withSubject()
                .withNoteText()
                .submit()
                .isNodeAddedModalDisplayed();

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3307: MissingMandatoryValuesWhileAddingNoteToActivity")
    public void MissingMandatoryValuesWhileAddingNoteToActivity(String browserName) throws Exception {
    		activityFactory.addActivityOnAccountDetailsPage();
    		new NavBar().goToDashBoard();
        new ActivitiesScheduleComponent()
                .clickOnFirstNonCompleteActivityUserOwns()
                .clickAddNoteButton();
        new AddNoteComponent()
                .submit()
                .areRequiredFieldsMarked();

    }

      @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3311 : AccountLinkOnActivitiesOnDashboard")
    public void AccountLinkOnActivitiesOnDashboard(String browserName) throws Exception {
    	  	activityFactory.addActivityOnAccountDetailsPage();
  		new NavBar().goToDashBoard().openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NAME.toString())).isAccountSummaryPageLoaded().shouldBeTrue("Account summary is not opened");
	    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3310: ReassignActivityOnDashboard")
    public void ReassignActivityOnDashboard(String browserName) throws Exception {
	PolicyGenerator.createBasicBoundPAPolicy();
        String UUID = new SeleniumCommands().generateUUID();
        activityFactory.clickAddActivityButtonFromAccountActivityTile();
        activityFactory.addDefaultActivity(UUID);
        new NavBar().goToDashBoard();
        ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent();

        reassignActivityComponent
                .openReassignActivityDropdown()
                .setAssigneeByName()
                .clickConfirmButton();
        Modal.waitHidden();
        new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent()
                 .isNotAssignedToCurrentUser().shouldBeTrue("Activity is still assigned to current user");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3313 : CancelReassignActivityOnDashboard")
    public void CancelReassignActivityOnDashboard(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String UUID = new SeleniumCommands().generateUUID();
        activityFactory.clickAddActivityButtonFromAccountActivityTile();
        activityFactory.addDefaultActivity(UUID);
        ReassignActivityComponent reassignActivityComponent = new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent();

        reassignActivityComponent
                .openReassignActivityDropdown()
                .setAssigneeByName()
                .clickCancelButton();

        Modal.waitHidden();

        new ActivitiesScheduleComponent()
                .getActivityBySubject(UUID)
                .toggleSummary()
                .getReassignActivityComponent()
                .isAssignedToCurrentUser()
                .shouldBeEqual("Activity is not assigned to current user");


    }

    /*Quote Details*/

      @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "CSR" }, description = "TC4063: Verify user can add an activity on policy details page, GPA--801 @ Verify user can add an activity on policy details page ")
    public void AddActivityOnPolicyDetails(String browserName) throws Exception {
    	  	PolicyGenerator.createBasicBoundPAPolicy();
        activityFactory.clickAddActivityButtonFromPolicyActivityTile();
        new AddActivityComponent()
                .withActivityTypeByText("Meet with Insured")
                .withSubject("ADD ACTIVITY TESTCASE")
                .submit()
                .wasActivityCreatedModalDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "SMOKE" }, description = "TC5816:  Verify for validaton message are displayed for missing type field value while adding activity on quote details page")
    public void MissingTypeWhileAddingActivityOnQuoteDetails(String browserName) throws Exception {
	    	PolicyGenerator.createBasicBoundPAPolicy();	
			new GPA_QuotePageFactory().createDraftQuote();
			new NavBar().goToDashBoard()
 	        .searchUsingSearchBox(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
 	        .goToAccount()
	        .goToOpenQuotes()
	        .goToFirstQuoteInList();
		QuoteSummary quoteSummary = new QuoteSummary();
		quoteSummary.clickOpenActivities();
		quoteSummary.clickAddActivityButton();
        new AddActivityComponent()
                .submit()
                .isChooseActivityTypeErrorModalShown()
                .shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3480:  Verify user can cancel adding of an activity on quote details page")
    public void CancelAddActivityOnQuotetDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();	
    		new GPA_QuotePageFactory().createDraftQuote();
    		new NavBar().goToDashBoard()
 	        .searchUsingSearchBox(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
 	        .goToAccount()
            .goToOpenQuotes()
            .goToFirstQuoteInList();
		QuoteSummary quoteSummary = new QuoteSummary();
		quoteSummary.clickOpenActivities();
		quoteSummary.clickAddActivityButton();
        String activitiesNumber= new AddActivityComponent().getActivitiesNumber();
        new Validation(new AddActivityComponent()
                .withActivityTypeByText("Meet with Insured")
                .withSubject("ADD ACTIVITY TESTCASE")
                .clickCancelButton()
                .getActivitiesNumber().equals(activitiesNumber)).shouldBeTrue("Activity was created while it shouldn't");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond",}, description = "TC4064 : CancelAddActivityOnPolicyDetails")
    public void CancelAddActivityOnPolicyDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        activityFactory.clickAddActivityButtonFromPolicyActivityTile();

        new AddActivityComponent()
                .clickCancelButton()
                .isAddActivityComponentVisible()
                .shouldBeFalse();
    }


      @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC4065 :MissingTypeWhileAddingActivityOnPolicyDetails")
    public void MissingTypeWhileAddingActivityOnPolicyDetails(String browserName) throws Exception {
    	  PolicyGenerator.createBasicBoundPAPolicy();
        activityFactory.clickAddActivityButtonFromPolicyActivityTile();
        new AddActivityComponent()
                .submit()
                .isChooseActivityTypeErrorModalShown()
                .shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5829: AddActivityOnQuoteDetails: Verify user can add an activity on quote details page")
    public void testAddActivityOnQuoteDetails(String browserName) throws Exception {
	    	PolicyGenerator.createBasicBoundPAPolicy();	
			new GPA_QuotePageFactory().createDraftQuote();
        
		QuoteSummary quoteSummary = new QuoteSummary();
		quoteSummary.clickOpenActivities();
		AddActivityComponent activityComponent = new AddActivityComponent();
        String activitiesNumber= activityComponent.getActivitiesNumber();
        new SeleniumCommands().logInfo("------------------------"+activitiesNumber);
        activitiesNumber = Integer.toString(Integer.parseInt(activitiesNumber) + 1);
        //quoteSummary.clickAddActivityButton();
        String UUID = new SeleniumCommands().generateUUID();
        activityFactory.addDefaultActivity(UUID);
        activityComponent.isNewlyCreatedActivityPresenedOnPage(UUID).shouldBeTrue("Activity wasn't added");
        new Validation(activityComponent.getActivitiesNumber().equals(activitiesNumber)).shouldBeTrue("Activity number was not correctly encreased.");

    }

}
