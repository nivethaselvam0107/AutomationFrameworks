/**
 * 
 */
package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.pages.ConstructionPage;
import com.guidewire.portals.qnb.pages.HOPolicyInfoPage;
import com.guidewire.portals.qnb.pages.HOQuotePage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;
import com.guidewire.portals.qnb.pages.YourHomePage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HOPQuoteCreationTest {
	
	GPA_QuotePageFactory pagefactory = new GPA_QuotePageFactory();
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3624:CreateHOPQuoteForExisitingAccount", enabled = false)
	public void testHOPQuoteCreationForExisitingAccount(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();
		PaymentDetailsPage paymentDetailsPage= new Pagefactory()
		        .getQualificationPage().setQualificationPageDetails()
		        .goToYourHomePage().setYourHomePageDetails()
		        .goToConstructionPage().setConstructionPageDetails()
		        .goToDiscountPage().setDiscountPageDetails()
				.goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy().validateHOPolicyConfirmationPageDetailsWithBackEnd().shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3625: MissingMandatoryValuesOnYourHomeScreenForHOP	")
	public void testVerifyHOPYourHomePageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.goNext()
				.areYourHomePageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Home page fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3626: MissingFieldsOnQualificationScreenForHOP	")
	public void testVerifyHOPQualificationPageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.goNext()
				.areHOQualificationPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Qualification page fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3627: MissingMandatoryValuesOnContructionForHOP	")
	public void testVerifyHOPConstructionPageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.goNext()
				.setYourHomePageDetails()
				.goToConstructionPage()
				.goNext()
				.areConstructionPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Construction page fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3628: ValidationforEstimatedValueOfHomeGreaterThan2000000000	")
	public void testVerifyHOPMaxHomeValueValidation(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.withHomeEstimationValue("20202020202020")
				.goNext()
				.isHomeEstimationFieldMarkedWithMAXValueError()
				.shouldBeEqual("Home value field is not marked with max value error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3629: MissingMandatoryValuesOnDiscountScreenForHOP	")
	public void testVerifyHOPDiscountPageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.setYourHomePageDetails()
				.goToConstructionPage()
				.setConstructionPageDetails()
				.goToDiscountPage()
				.goNext()
				.areHODiscountPageFieldsMakedWithMandatoryError()
				.shouldBeTrue("Discount page fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3630: MissingMandatoryValuesOnPolicyInfoScreenForHOP	")
	public void testVerifyHOPPolicyInfoPageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.setYourHomePageDetails()
				.goToConstructionPage()
				.setConstructionPageDetails()
				.goToDiscountPage()
				.setDiscountPageDetails()
				.goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium()
				.goToPolicyInfoPage()
				.setEmailAddress("")
				.setPhoneNumber("")
				.goNext()
				.arePolicyInfoPageFieldsMarkedWithMandatoryError()
				.shouldBeTrue("Policy Info page fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC3631: MissingMandatoryValuesOnPaymentDetailsScreenForHOP	")
	public void testVerifyHOPPaymentDetailsPageMandatoryFields(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();
				PaymentDetailsPage detailsPage = new Pagefactory()
				.getQualificationPage()
				.setQualificationPageDetails()
				.goToYourHomePage()
				.setYourHomePageDetails()
				.goToConstructionPage()
				.setConstructionPageDetails()
				.goToDiscountPage()
				.setDiscountPageDetails()
				.goToHOQuotePage()
				.buyBasePolicyWithMonthlyPremium()
				.goToPolicyInfoPage()
				.goToPaymentDetailsPage()
				.goNext();
				detailsPage.areBankPaymentFieldsMarkedWithMandatoryError()
				.shouldBeTrue("Bank form fields are not marked with mandatory error");
				detailsPage.areCreditCardPaymentFieldsMarkedWithMandatoryError()
				.shouldBeTrue("Credit card form fields are not marked with mandatory error");
	}
	
	@Parameters("browserName")
    @Test(groups = { "HOP"}, description ="TC3633:CancelHOQuoteOnQualificationScreen")
    public void CancelHOPQuoteOnQualificationScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		pagefactory.startQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        QualificationPage qualificationPage =  new LeftNavigationMenuHandler().gotoQualificationPage_GPA();
        	qualificationPage.areHOQualificationAnswersSaved().shouldBeTrue();
    }
	@Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC3632: CancelHOPQuoteOnYourHomeScreen")
    public void CancelHOPQuoteOnYourHomeScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        YourHomePage homePage =new LeftNavigationMenuHandler().gotoYourHomePage_GPA();
        homePage.areYourHomePageFieldsValuesAreSaved().shouldBeTrue();
    }
	
	@Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC3634:CancelHOPQuoteOnConstructionScreen")
    public void CancelHOPQuoteOnConstructionScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails().withConstructionUpgradeYear()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        ConstructionPage constructionPage = new LeftNavigationMenuHandler().gotoConstructionPage_GPA();
        constructionPage.areConstructionPageDetailsSaved().shouldBeTrue();
    }
	
	@Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC3635:CancelHOQuoteOnDiscountScreen")
    public void CancelHOPQuoteOnDiscountScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();

        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        new Pagefactory().getDiscountPage().areDiscountPageValueSaved().shouldBeTrue();
    }
	
	@Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC3636:CancelHOOnPolicyInfoScreen")
    public void CancelHOPOnPolicyInfoScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();
        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        HOPolicyInfoPage hoPolicyInfoPage = new Pagefactory()
                .getHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage();

        hoPolicyInfoPage.isEmailSaved().shouldBeEqual();
        hoPolicyInfoPage.isPhoneSaved().shouldBeEqual();
    }
	
	@Parameters("browserName")
    @Test(groups = { "HOP"}, description = "TC3637:CancelHOPaymentDetailsScreen")
    public void CancelHOPPaymentDetailsScreen() throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();
        new Pagefactory()
                .getQualificationPage().setQualificationPageDetails()
                .goToYourHomePage().setYourHomePageDetails()
                .goToConstructionPage().setConstructionPageDetails()
                .goToDiscountPage().setDiscountPageDetails()
                .goToHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage().setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .pressCancelGPA()
                .confirmCancel()
                .continueQuote();

        new Pagefactory()
                .getHOQuotePage().buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .goToPaymentDetailsPage()
                .arePaymentFieldsInInitialState().shouldBeTrue();
    }

	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4462:AddScheduledPersonalPropertyItemForHOP")
	public void testHOPScheduledItemAddition(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		ThreadLocalObject.getData().put("ZipCode", "94404");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();

        PaymentDetailsPage paymentDetailsPage = new Pagefactory()
        .getQualificationPage().setQualificationPageDetails()
        .goToYourHomePage().setYourHomePageDetails()
        .goToConstructionPage().setConstructionPageDetails()
        .goToDiscountPage().setDiscountPageDetails()
					.goToHOQuotePage()
					.addScheduledPersonalProperty()
	                .reCalculatePolicyPremium()
	                .buyBasePolicyWithMonthlyPremium()
	                .goToPolicyInfoPage()
	                .setPolicyInfoPageDetails()
	                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber().replace("(", "").replace(")", "");
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
					.payMonthlyPremiumWithSavingsBankAccount()
	                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4464:EditScheduledPersonalPropertyItemForHOP")
	public void testHOPScheduledItemEdition(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		ThreadLocalObject.getData().put("ZipCode", "94404");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();
		HOQuotePage hoQuotePage = new Pagefactory()
		        .getQualificationPage().setQualificationPageDetails()
		        .goToYourHomePage().setYourHomePageDetails()
		        .goToConstructionPage().setConstructionPageDetails()
		        .goToDiscountPage().setDiscountPageDetails()
				.goToHOQuotePage();
		hoQuotePage.addScheduledPersonalProperty()
                .reCalculatePolicyPremium();
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.editFirstScheduledPersonalProperty()
        			.buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4463:RemoveScheduledPersonalPropertyItemForHOP")
	public void testHOPScheduledItemDeletion(String browserName) throws Exception {
		ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
		ThreadLocalObject.getData().put("PolicyType", "HOPHomeowners");
		ThreadLocalObject.getData().put("RoofType", "composite");
		ThreadLocalObject.getData().put("ZipCode", "94404");
		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().startPAQuoteWithExistingAcount();
		HOQuotePage hoQuotePage = new Pagefactory()
		        .getQualificationPage().setQualificationPageDetails()
		        .goToYourHomePage().setYourHomePageDetails()
		        .goToConstructionPage().setConstructionPageDetails()
		        .goToDiscountPage().setDiscountPageDetails()
				.goToHOQuotePage();
		hoQuotePage.addScheduledPersonalProperty()
                .reCalculatePolicyPremium();
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.deleteFirstProperty()
        			.reCalculatePolicyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber().replace("(", "").replace(")", "");
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		new Validation(ParseQuoteData.getScheduledPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Scehduled property was available in backend");
	}
}
