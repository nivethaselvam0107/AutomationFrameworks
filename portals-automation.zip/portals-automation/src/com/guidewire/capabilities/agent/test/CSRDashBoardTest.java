package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.CSRDashboard;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;

/**
 * Created by dgangwar on 10/04/2017.
 */
public class CSRDashBoardTest {

	    @Parameters("browserName")
	    @Test(groups = { "CSR" }, description = "GPA--734:SearchPolicyFromDashboard")
	    public void testSearchPolicyFromCSRDashboard(String browserName) throws Exception {
	    		PolicyGenerator.createBasicBoundPAPolicy();
	    		String policyNum = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
	        new LoginPage().login();
	        CSRDashboard csrDashboard = new CSRDashboard();
	        csrDashboard.searchFromCSRDashboard(policyNum).goToPolicy(policyNum).validatePolicySummaryPageLoaded(policyNum);
	    }
	    
	    @Parameters("browserName")
	    @Test(groups = { "CSR" }, description = "GPA--734:SearchPolicyFromDashboard")
	    public void testAccountPolicyFromCSRDashboard(String browserName) throws Exception {
	    		PolicyGenerator.createBasicBoundPAPolicy();
	    		String accNum = ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString());
	        new LoginPage().login();
	        CSRDashboard csrDashboard = new CSRDashboard();
	        csrDashboard.searchFromCSRDashboard(accNum).goToAccount().isAccountSummaryPageLoaded().shouldBeTrue("Account summary page is not displayed");
	    }
	    
	    @Parameters("browserName")
	    @Test(groups = { "CSR" }, description = "GPA--739:RecentlyVisitedAccountsOnDashboard")
	    public void testRecentlyVisitedAccountsOnCSRDashboard(String browserName) throws Exception {
	    		PolicyGenerator.createBasicBoundPAPolicy();
	    		String accNum = ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString());
	        new LoginPage().login();
	        new CSRDashboard().searchFromCSRDashboard(accNum).goToAccount().isAccountSummaryPageLoaded().shouldBeTrue("Account summary page is not displayed");
	        new NavBar().goToDashBoard();
	        new CSRDashboard().validateAccountListedInRecentlyVistedTable();
	    }
	    
	    @Parameters("browserName")
	    @Test(groups = { "CSR" }, description = "GPA--739:RecentlyVisitedAccountsOnDashboard")
	    public void testRecentlyVisitedPolicyOnCSRDashboard(String browserName) throws Exception {
	    		PolicyGenerator.createBasicBoundPAPolicy();
	    		String policyNum = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
	        new LoginPage().login();
	        new CSRDashboard().searchFromCSRDashboard(policyNum).goToPolicy(policyNum).validatePolicySummaryPageLoaded(policyNum);
	        new NavBar().goToDashBoard();
	        new CSRDashboard().validatePolicyListedInRecentlyVistedTable();
	    }
}