package com.guidewire.capabilities.agent.test;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AccountCreate;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.QuoteStart;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.form.ViewModelInput;




public class AccountCreationTest {

    public static final String DATA_COMPANY_NAME = "CompanyName";
    public static final String DATA_FIRST_NAME = "FirstName";
    public static final String DATA_LAST_NAME = "LastName";
    public static final String DATA_ADDRESS_LINE_1 = "AddressLine1";
    public static final String DATA_CITY = "City";
    public static final String DATA_ZIP = "Zip";
    public static final String DATA_USER = "USER";
    public static final String DATA_PWD = "PWD";
    public static final String DATA_STATE = "State";
    public static final String DATA_EMAIL = "Email";

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond", "SMOKE" }, description = "TC3515: AddPersonalAccount")
    public void testUserCanAddPersonalAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        String firstName = data.get(DATA_FIRST_NAME);
        String lastName = data.get(DATA_LAST_NAME);
        String addressLine1 = data.get(DATA_ADDRESS_LINE_1);
        String city = data.get(DATA_CITY);
        String zip = data.get(DATA_ZIP);

        new LoginPage().login();

        QuoteStart quoteStart = new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(firstName)
                .withLastName(lastName)
                .search()
                .createNewAccount()
                .withAddressLine1(addressLine1)
                .withCity(city)
                .withZip(zip)
                .withState(data.get(DATA_STATE))
                .withProducerByIndex(1)
                .submit();

        quoteStart.isTextPresent(addressLine1).shouldBeTrue();
        quoteStart.isTextPresent(city).shouldBeTrue();
        quoteStart.isTextPresent(zip).shouldBeTrue();

        AccountSummary accountSummary = quoteStart.cancel();
        accountSummary.titleContains(firstName).shouldBeTrue();
        accountSummary.titleContains(lastName).shouldBeTrue();
    }


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "SMOKE" }, description="TC3516: AddCommercialAccount")
    public void testUserCanAddCommercialAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        String companyName = data.get(DATA_COMPANY_NAME);
        String addressLine1 = data.get(DATA_ADDRESS_LINE_1);
        String city = data.get(DATA_CITY);
        String zip = data.get(DATA_ZIP);

        new LoginPage().login();

        QuoteStart quoteStart = new AgentDashboard()
                .searchQuote()
                .forCommercialAccount()
                .withCompanyName(companyName)
                .search()
                .createNewAccount()
                .withAddressLine1(addressLine1)
                .withCity(city)
                .withZip(zip)
                .withState(data.get(DATA_STATE))
                .withProducerByIndex(1)
                .submit();

        quoteStart.isTextPresent(addressLine1).shouldBeTrue();
        quoteStart.isTextPresent(city).shouldBeTrue();
        quoteStart.isTextPresent(zip).shouldBeTrue();

        AccountSummary accountSummary = quoteStart.cancel();
        accountSummary.titleContains(companyName).shouldBeTrue();
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" })
    public void testValidationMessagesWhileCreatingPersonalAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(DATA_FIRST_NAME))
                .withLastName(data.get(DATA_LAST_NAME))
                .search()
                .createNewAccount();

        accountCreatePage.trySubmit();
        for (ViewModelInput input : accountCreatePage.getRequiredFields()) {
            new Validation(input.isShowingError()).shouldBeTrue();
        }
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" })
    public void testValidationMessagesWhileCreatingCommercialAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forCommercialAccount()
                .withCompanyName(data.get(DATA_COMPANY_NAME))
                .search()
                .createNewAccount();

        accountCreatePage.trySubmit();
        for (ViewModelInput input : accountCreatePage.getRequiredFields()) {
            new Validation(input.isShowingError("This is a required field")).shouldBeTrue();
        }
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3519 : InvalidZipCodeForPersonalAccount")
    public void testInvalidZipcodeValidationMessagesWhileCreatingPersonalAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(DATA_FIRST_NAME))
                .withLastName(data.get(DATA_LAST_NAME))
                .search()
                .createNewAccount();

        accountCreatePage
                .withAddressLine1(data.get(DATA_ADDRESS_LINE_1))
                .withCity(data.get(DATA_CITY))
                .withZip(data.get(DATA_ZIP))
                .withState(data.get(DATA_STATE))
                .withProducerByIndex(1)
                .trySubmit();

        new Validation(accountCreatePage.getZipCodeInput().isShowingError("Please enter a valid ZIP code.")).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3520 : ValidationforInvalidZipCodeForCommercialAccount")
    public void testInvalidZipcodeValidationMessagesWhileCreatingCommercialAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forCommercialAccount()
                .withCompanyName(data.get(DATA_COMPANY_NAME))
                .search()
                .createNewAccount();

        accountCreatePage
                .withAddressLine1(data.get(DATA_ADDRESS_LINE_1))
                .withCity(data.get(DATA_CITY))
                .withZip(data.get(DATA_ZIP))
                .withState(data.get(DATA_STATE))
                .withProducerByIndex(1)
                .trySubmit();

        new Validation(accountCreatePage.getZipCodeInput().isShowingError("Please enter a valid ZIP code.")).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3521 : InvalidEmailIDAccountCreation")
    public void testInvalidEmailValidationMessagesWhileCreatingPersonalAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(DATA_FIRST_NAME))
                .withLastName(data.get(DATA_LAST_NAME))
                .search()
                .createNewAccount();

        accountCreatePage
                .withAddressLine1(data.get(DATA_ADDRESS_LINE_1))
                .withCity(data.get(DATA_CITY))
                .withZip(data.get(DATA_ZIP))
                .withState(data.get(DATA_STATE))
                .withEmail(data.get(DATA_EMAIL))
                .withProducerByIndex(1)
                .trySubmit();

        new Validation(accountCreatePage.getEmailInput().isShowingError("Value must be a valid email address")).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" })
    public void testInvalidEmailValidationMessagesWhileCreatingCommercialAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();
        AccountCreate accountCreatePage = new AgentDashboard()
                .searchQuote()
                .forCommercialAccount()
                .withCompanyName(data.get(DATA_COMPANY_NAME))
                .search()
                .createNewAccount();

        accountCreatePage
                .withAddressLine1(data.get(DATA_ADDRESS_LINE_1))
                .withCity(data.get(DATA_CITY))
                .withZip(data.get(DATA_ZIP))
                .withState(data.get(DATA_STATE))
                .withEmail(data.get(DATA_EMAIL))
                .withProducerByIndex(1)
                .trySubmit();

        new Validation(accountCreatePage.getEmailInput().isShowingError("Value must be a valid email address")).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"} , description = "TC3522: CancelAccountCreation")
    public void testCancelCreatingPersonalAccount(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        new LoginPage().login();

        new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(DATA_FIRST_NAME))
                .withLastName(data.get(DATA_LAST_NAME))
                .search()
                .createNewAccount()
                .withAddressLine1(data.get(DATA_ADDRESS_LINE_1))
                .withCity(data.get(DATA_CITY))
                .withZip(data.get(DATA_ZIP))
                .withState(data.get(DATA_STATE))
                .withProducerByIndex(1)
                .cancel();
        AgentDashboard dashboard = new AgentDashboard() ;
        if(dashboard.isCSRDashboardOpened()) {
        			new Validation(true).shouldBeTrue();
	       }
        else {
        	    new NavBar().isAccountsLandingSelected().shouldBeTrue();
        }
    }


}
