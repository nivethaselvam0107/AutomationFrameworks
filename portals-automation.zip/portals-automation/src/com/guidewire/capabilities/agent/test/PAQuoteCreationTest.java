package com.guidewire.capabilities.agent.test;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.DriverDetailsPage;
import com.guidewire.portals.qnb.pages.LeftNavigationMenuHandler;
import com.guidewire.portals.qnb.pages.PAQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QualificationPage;

/**
 * Created by dfedo on 17/11/2016.
 */
public class PAQuoteCreationTest {

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can start a quote of type Personal Auto for new account
    Actual :-
    1. Login to portal
    2. Click on New Quote and Select the type of account as Personal.
    3. Provide account mandatory details and click on Search.
    4. Click on Continue as a new customer
    5. Provide account details and click on Next
    6. Provide policy details, select Personal auto product code and click on Next
    7. Select the effective date and click on Next
    8. Provide details on Qualification screen and click on Next
    9. Provide driver information and click on Next
    10. Provide vehicles information and click on Next
    11. Select the basic/standardpremium and click on Buy policy button
    12. Provide all mandatory information on policy info screen and click on Next
    13. Provide bank details and select the payment plans and click on Purchase

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page should be displayed with below details : Start New Quote link, Account Number, Account name, Address, Cancel, Search Again and Continue as a New Customer.    4. New Quote: New Account Details page should be displayed with below details : Account type Personal, First name*, Last name*, Address Line 1 *, Address Line 2, City *, State *, ZIP Code *, Email Address, Producer Code *.    5. This is a required field' validation message should be displayed right below each mandatory fields.
    4. New Quote: New Account Details page should be displayed with below details : Account type Personal, First name*, Last name*, Address Line 1 *, Address Line 2, City *, State *, ZIP Code *, Email Address, Producer Code *.
    5. Policy detail form should be displayed.
    6. Effective date screen should be displayed.
    7. Qualification screen should be displayed.
    8. Drivers screen should be displayed
    9. Vehicles screen should be displayed
    10. Quote is generated
    11. Policy infomation page is displayed
    12. Payment Details page is displayed.
    13. Confirmation page is displayed with all details of the policy
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond", "CSR", "CSR_DIA"}, description = "TC3544 :CreatePAQuoteForNewPersonalAccount: Verify user can start a quote of type Personal Auto for new account, GPA--638:CreatePAQuoteForNewPersonalAccount")
    public void testCreatePAQuoteForNewPersonalAccount(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        new GPA_QuotePageFactory().loginAndStartQuote()
                .createNewAccount()
                .withAddressLine1(data.get("AddressLine1"))
                .withCity(data.get("City"))
                .withZip(data.get("Zip"))
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .submit()
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(data.get("ProductCode"))
                .submit();

        PolicyConfirmationPage policyConfirmationPage = new GPA_QuotePageFactory().createAndBuyPolicyPA();
        policyConfirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue();
        // TODO: WRTITE CORRECT BACKEND CALL FOR VERIFICATION ALL THE DATA ON SUMMARY PAGE
        // policyConfirmationPage.validatePAConfirmationPageDetails();

    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can start a quote of type Personal Auto for exisitng account

    Actual :-
    1. Login to portal
    2. Click on New Quote and Select the type of account as Personal.
    3. Provide account mandatory details and click on Search.
    4. Click on existing account number
    5. Provide account details and click on Next
    6. Provide policy details, select Personal auto product code and click on Next
    7. Select the effective date and click on Next
    8. Provide details on Qualification screen and click on Next
    9. Provide driver information and click on Next
    10. Provide vehicles information and click on Next
    11. Select the basic/standardpremium and click on Buy policy button
    12. Provide all mandatory information on policy info screen and click on Next
    13. Provide bank details and select the payment plans and click on Purchase

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page should be displayed with below details : Start New Quote link, Account Number, Account name, Address, Cancel, Search Again and Continue as a New Customer.    4. New Quote: New Account Details page should be displayed with below details : Account type Personal, First name*, Last name*, Address Line 1 *, Address Line 2, City *, State *, ZIP Code *, Email Address, Producer Code *.    5. This is a required field' validation message should be displayed right below each mandatory fields.
    4. Personal account detailed should be saved automatically on the page
    5. Policy detail form should be displayed.
    6. Effective date screen should be displayed.
    7. Qualification screen should be displayed.
    8. Drivers screen should be displayed
    9. Vehicles screen should be displayed
    10. Quote is generated
    11. Policy infomation page is displayed
    12. Payment Details page is displayed.
    13. Confirmation page is displayed with all details of the policy
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond", "CSR", "CSR_DIA"}, description = "TC3545 : CreatePAQuoteForExisitingPersonalAccount Verify user can start a quote of type Personal Auto for exisitng account, GPA--639:CreatePAQuoteForExisitingPersonalAccount")
    public void testCreatePAQuoteForExisitingPersonalAccount(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        PolicyConfirmationPage policyConfirmationPage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().createAndBuyPolicyPA();
        policyConfirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue();
        // TODO: WRTITE CORRECT BACKEND CALL FOR VERIFICATION ALL THE DATA ON SUMMARY PAGE
        // policyConfirmationPage.validatePAConfirmationPageDetails();
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify for validation on Driver screen while creating personal auto quote

    Actual :-
    1. Login to portal
    2. Click on New Quote
    3. Search for exisiting account
    4. Click on Start a new quote
    5. Provide policy details, select Personal auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide details on Qualification screen and click on Next
    8. Do not provide mandatory information on Driver screen and click on No

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed.
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Validation message for missing mandatory fields should be displayed.
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3546 @ Verify for validation on Driver screen while creating personal auto quote")
    public void testMissingMandatoryValuesOnDriverScreenForPA(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount();
        DriverDetailsPage policyConfirmationPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setDOBGPA("")
                .setDriverLicenseNumber(" ");
        policyConfirmationPage.isDriverPageNextButtonDisabled().shouldBeTrue("Next button is not disabled");
    }

     /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify when the drivers age is below 25 years, quote is not generated

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide all mandatory details on Drivers screen and provide driver year of birth later than 1999 and click on Next
    9. Provide all mandatory details on Vehicles screen and click on Next

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen is displayed
    9. "There are underwriting issues associated with this offering. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. Quote details page is displayed. Under Underwriting issues table we should see 2 entries 'Driver under 25' & 'Primary Driver under 25' with Status - Blocks Bind
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3556 @ Verify when the drivers age is below 25 years, quote is not generated")
    public void testUnderwriterIssueForDriversAgeBelow25(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        PAQuotePage paQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToPAQuotePage();
        paQuotePage.validationUnderwritingMessage();
        QuoteSummary quoteSummary = paQuotePage.clickReferToUnderwriterAndConfirm();
        quoteSummary.validationUnderwritingIssues(DataConstant.SD_PRIMARY_DRIVER_UNDER_25_TEXT,true).shouldBeTrue("Primary Driver under 25 short decription or program are incorrect.");
        quoteSummary.validationUnderwritingIssues(DataConstant.SD_DRIVER_UNDER_25_TEXT,false).shouldBeTrue("Driver under 25 short decription or program are incorrect");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can refer the underwriting issues to the underwriter.

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10.Click on Ok.
    11. Click on Refer to Underwriter.
    12. Click on Confirm button

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to quote detail page with underwriter view.
    11. The refer to underwriter form should be displayed. An information should be displayed mentioning that the quote will be locked while under UW review and will not be editable, also that a high priority activity will be created for the underwriter. There should be an optional note field and 2 buttons - Cancel, Confirm.
    12. Quote details page should be displayed. User should also see " This quote has been referred to an underwriter for review".
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3558 @ Verify user can refer the underwriting issues to the underwriter.")
    public void testUnderwritingIssuesReferredToUnderwriter(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        QuoteSummary quoteSummaryPage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuoteSummaryPage();
        quoteSummaryPage.validationReferedToUnderwriteForReviewMessage();

    }


    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify the underwriting issue view on quote detail page.

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10.Click on Ok.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to Quote Detail Summary page. The quote detail page will list the UW issues in a tabular form with columns – Short Description, Long Description, Basic Offering Status, Standard Offering Status, Premium Offering Status and Custom Offering Status and Refer to Underwriter button.
        User should see warning message :
        Underwriting issues have been raised from this quote
        You cannot complete this quote until these issues have been resolved. You can:
        • Edit the quote if the customer is willing to accept the changes
        • Refer the quote to an underwriter for review
        • Withdraw(link) this quote if you do not wish to continue
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3559 @ Verify the underwriting issue view on quote detail page.")
    public void ReferToUnderwriterUnderwritingIssueViewOnQuoteDetailPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        PAQuotePage paQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToPAQuotePage();
        paQuotePage.validationUnderwritingMessage();
        QuoteSummary quoteSummary = paQuotePage.clickReferToUnderwriterAndConfirm();
        quoteSummary.validationUnderwritingIssuesColumns();
    }


    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can refer the underwriting issues to the underwriter.

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10.Click on Ok.
    11. Click on Refer to Underwriter.
    12. Add a note and click on Cancel.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to quote detail page with underwriter view.
    11. The refer to underwriter form should be displayed. An information should be displayed mentioning that the quote will be locked while under UW review and will not be editable, also that a high priority activity will be created for the underwriter. There should be an optional note field and 2 buttons - Cancel, Confirm.
    12. Quote details Summary page is displayed. Refer to underwriter button is not disabled as the UW issues were not referred to underwriter.
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3561 @ Verify user can cancel refer to underwriter action.")
    public void CancelReferToUnderwriter(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        PAQuotePage paQuotePage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToPAQuotePage();
        paQuotePage.clickReferToUnderwriterAndCancel();
        paQuotePage.validationUnderwritingMessage();
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify the activity is created for underwriter when agent refer the UW issues to the underwriter

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10.Click on Ok.
    11. Click on Refer to Underwriter.
    12. Add a note and click on Confirm button.
    13. Click on Open Activities tile on Quote details page.
    14. Login to PC as the underwriter and verify that the activity is present on the home page.
    15. Open the activity.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to quote detail page with underwriter view.
    11. The refer to underwriter form should be displayed. An information should be displayed mentioning that the quote will be locked while under UW review and will not be editable, also that a high priority activity will be created for the underwriter. There should be an optional note field and 2 buttons - Cancel, Confirm.
    12. The issue should be referred to underwriter and quote detail page should be displayed.
    13. High priority activity is created by agent and assigned to the underwriter with subject line Review and Approve. The activity due date should be set to tomorrow. Also the note added by the agent should also be displayed under the activity.
    14. Review and Approve activity should be displayed with high priority and due date set to next day's date
    15. The activity details should be displayed. Note created by agent is displayed as General note with security set as Unrestricted.
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3560 @ Verify the activity is created for underwriter when agent refer the UW issues to the underwriter")
    public void ActivityCreatedWhenUWIssuesReferredToUnderwriter(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        QuoteSummary quoteSummaryPage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuoteSummaryPage();
        quoteSummaryPage.clickOpenActivities();
                new GPA_ActivityPageFactory().addDefaultActivity();
                new ActivitiesScheduleComponent()
                .clickOnFirstActivity().canViewActivitySummary().shouldBeTrue("Activity is not created");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify agent can withdraw quote after an underwriting issues are referred

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10.Click on Ok.
    11. Click on Refer to Underwriter.
    12. Add a note and click on Confirm.
    13. Click on Withdraw quote->Withdraw.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to quote detail page with underwriter view.
    11. The refer to underwriter form should be displayed. An information should be displayed mentioning that the quote will be locked while under UW review and will not be editable, also that a high priority activity will be created for the underwriter. There should be an optional note field and 2 buttons - Cancel, Confirm.
    12. Quote details Summary page should be displayed. Refer to Underwriter button shouldn't be visible.
    13. Quote should be withdrawn and the status should be Withdrawn.
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3564 @ Verify agent can withdraw quote after an underwriting issues are referred")
    public void WithdrawQuoteAfterReferringToUnderwriter(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        QuoteSummary quoteSummaryPage = new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuoteSummaryPage();
        quoteSummaryPage.clickWithdraw()
                .validationQuoteWithdrawn();
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify when the applicant has revoked/suspended license, quote is not generated

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. On Qualification screen, select Yes for "Is the applicant's license  currently suspended, canceled?" Click on Next
    8. Provide all mandatory details on Drivers screen and click on Next
    9. Provide all mandatory details on Vehicles screen and click on Next
    10. Click on View Issues.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen is displayed
    9. 'Underwriting issues have been triggered. Redirecting to underwriting issues for this job' message should be displayed in a dialog box with View Issues button.
    10. Quote details page is displayed. Under Underwriting issues table we should see -'Disqualification: Applicant has a suspended/revoked license' with status - Blocks Quote
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3570 @ Verify when the applicant has revoked/suspended license, quote is not generated")
    public void testUnderwriterIssueForLicenseRevokedSuspended(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount();
        new GPA_QuotePageFactory().getToVehicleDetailsPageAndSetData()
                .proceedToQuoteSummaryThroughtAllert();
        new QuoteSummary().validationDisqualification().shouldBeTrue("Disqualification: Applicant has a suspended/revoked license.");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify when the applicant has revoked/suspended license, quote is not generated

    Actual :-
    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. On Qualification screen, select Yes for "Has any policy or coverage been declined, canceled, or non-renewed during the prior 3 years?" Click on Next
    8. Provide all mandatory details on Drivers screen and click on Next
    9. Provide all mandatory details on Vehicles screen and click on Next
    10. Click on View Issues.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen is displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. Quote details page is displayed. Under Underwriting issues table we should see - 'Policy has been declined , canceled, or non-renewed during the prior 3 years' with status - Blocks Bind
     */
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3571 @ Verify when the person has been declined a policy or coverage, quote is not generated")
    public void testUnderwriterIssueForPolicyDeclinedCanceled(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToQuoteSummaryPage();
        new QuoteSummary().validationUnderwritingIssues(DataConstant.POLICY_DECLINED_HISTOTY_TEXT,true).shouldBeTrue("Policy has been declined , canceled, or non-renewed during the prior 3 years");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : User should be able to resolve UW issues by editing quote

    1. Login to portal
    2. Click on New Quote button.
    3. Search for exisiting account
    4. Click on Start a new quote. Provide policy details, select Personal auto product code and click on Next
    5. Provide policy details, select Personal Auto product code and click on Next
    6. Select the effective date and click on Next
    7. Provide all the mandatory details on Qualification screen and click on Next
    8. Provide driver information and click on Next
    9. Provide vehicles information and provide cost of vehicle 10000000 and click on No.
    10. Click on Ok.
    11. Click on Edit Quote.
    12. Go to Vehicles page.
    13. Change the cost of vehicle to 100000 and click on No
    14. Select offering type and then click on Buy Policy.
    15. Provide email and phone and click on Next.
    16. Provide payment information and click on Next.

    Expected :-
    1. Dashboard page should be displayed
    2. New Quote: Search for Existing Account page should be displayed
    3. Possible Account Matches page with Start a new quote link should be displayed
    4. New Quote: Policy Details for Existing Account page should be displayed
    5. Effective date screen should be displayed
    6. Qualification screen should be displayed.
    7. Drivers screen should be displayed
    8. Vehicles screen should be displayed
    9. "There are underwriting issues associated with this offering. Click here to view more details" message should be displayed. Buy now button should be disabled to the offerings to which the UW issues have been triggered
    10. User is navigated to quote detail page with underwriter view.
    11. User should be navigated to quote and buy wizard.
    12. Vehicles page should be displayed
    13. Quote should be generated
    14. Policy Info page should be displayed.
    15. Payment Details page should be displayed.
    16. Confirmation page should be displayed.

     */

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3576 @ User should be able to resolve UW issues by editing quote")
    public void testEditQuoteAfterUWIssuesTriggered(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().startQuoteWithExistingAcount().getToPAQuotePage();
        new LeftNavigationMenuHandler().gotoVehiclePage().withVehicleCost("100000").goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        new PolicyConfirmationPage().isPolicyConfirmationPageDisplayed().shouldBeTrue();
    }

}
