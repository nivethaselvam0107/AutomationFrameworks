package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.BillingTileView;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.agent.model.page.PolicyCancelationSummary;
import com.guidewire.capabilities.agent.model.page.PolicyChangeSummaryPage;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.agent.scenarios.BindCancellationOnPolicyScenario;
import com.guidewire.capabilities.common.interfaces.IBindPolicyCancellationPage;
import com.guidewire.capabilities.common.interfaces.ICancelPolicyDetailsPage;
import com.guidewire.capabilities.common.interfaces.ICommonPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.portals.qnb.pages.AlertHandler;


public class PolicyDetailsPageTest {
    IBindPolicyCancellationPage goToSubmitCancellation(ICommonPage scenario) {
        return goToCancellationForm(scenario)
                .fillMandatoryProperties()
                .setDateWithinPolicyPeriod()
                .submitCancellation();
    }

    ICancelPolicyDetailsPage goToCancellationForm(ICommonPage scenario) {
        return scenario
                .login()
                .clickPolicyLinkOnNavBar()
                .clickOnPolicy()
                .clickOnCancelPolicy();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4067: Verify for validation message is displayed when user does not provide mandatory fiels which adding note")
    public void testMissingMandatoryValuesWhileAddingNoteOnPolicyDetails(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToNotesTile()
                .clickAddNote()
                .submit().areRequiredFieldsMarked().shouldBeTrue("Fields not marked with mandatory error");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement", "CSR"} , description = "TC4066: Verify user can add notes on policy details page")
    public void testAddingNoteOnPolicyDetails(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToNotesTile()
                .addGeneralNote(SeleniumCommands.generateUUID())
                .isNoteAdded().shouldBeTrue("Note didn't get added");
        policySummary.validatePolicyNotesDataWithBackEnd().shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement", "CSR"} , description = "TC4068: Verify user can add documents on policy details page")
    public void testUploadDocOnPolicyDetails(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToDocumentsTile()
                .uploadDocFromSummary()
                .isDocAdded().shouldBeEqual("Document didn't upload");
        policySummary.validatePolicyDocumentDataWithBackEnd().shouldBeTrue();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4060: DocumentsOnPolicyDetailsPage")
    public void testDocumentsOnPolicyDetailsPage(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
       DocumentsTab documentsTab = policySummary
                .goToDocumentsTile();
       documentsTab.uploadDocFromSummary()
                .isDocAdded().shouldBeEqual("Document didn't upload");
       documentsTab.validateDocTileElements().shouldBeTrue("Document UI componant are not displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4069: Verify for validation message is displayed when user tries to upload a documents with same name")
    public void testUploadSameDocTwiceOnPolicyDetails(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToDocumentsTile()
                .uploadDocFromSummary()
                .uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for same file upload");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4070: Verify user can delete uploaded documents on policy details page")
    public void testDeleteDocumentOnPolicyDetails(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToDocumentsTile()
                .uploadDocFromSummary()
                .isDocAdded().shouldBeEqual("Document didn't upload");
        new DocumentsTab()
                .deleteDoc()
                .isDocTableEmpty().shouldBeTrue("Document didn't get deleted");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement","CSR" } , description = "TC4071: Verify user can view uploaded documents on policy details page")
    public void testViewUploadedDocument(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        new PolicySummary()
                .goToDocumentsTile()
                .uploadDocFromSummary()
                .isDocAdded().shouldBeEqual("Document didn't upload");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature"} , description = "TC4047: Verify user can view policy details page from Policies landing, recently viewed page")
    public void testViewPolicyFromPoliciesLandingRecentlyViewed(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new NavBar().goToPoliciesLanding()
                .showRecentlyIssued()
                .goToPolicySummary(policyNumber);
        new NavBar().goToPoliciesLanding()
                .goToPolicySummary(policyNumber)
                .validatePolicySummaryPageLoaded(policyNumber);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature"} , description = "TC4048: Verify user can view policy details page from Policies landing, recently created page")
    public void testViewPolicyFromPoliciesLandingRecentlyIssued(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new NavBar().goToPoliciesLanding()
                .showRecentlyIssued()
                .goToPolicySummary(policyNumber)
                .validatePolicySummaryPageLoaded(policyNumber);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature"} , description = "TC4049: Verify user can view policy details page from Policies landing, delinquent page")
    public void testViewPolicyFromPoliciesLandingDelinquent(String browserName) throws Exception {
        login();
        new NavBar().goToPoliciesLanding()
                .showDelinquent()
                .openFirstPolicy()
                .validatePolicySummaryPageLoaded(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4050: Verify user can view policy details page from Policies landing, open renewals page")
    public void testViewPolicyFromPoliciesOpenRenewals(String browserName) throws Exception {
        login();
        RenewalGenerator.createBasicDraftPARenewal();
        String policyNumber = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
        new NavBar().goToPoliciesLanding()
                .showOpenRenewals()
                .goToPolicySummary(policyNumber)
                .validatePolicySummaryPageLoaded(policyNumber);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4051: Verify user can view policy details page from Policies landing, open changes page")
    public void testViewPolicyFromPoliciesOpenChanges(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new NavBar().goToPoliciesLanding()
                .showRecentlyIssued()
                .goToPolicySummary(policyNumber)
                .createChangePolicyTransaction();
        new NavBar().goToPoliciesLanding()
                .showOpenChanges()
                .goToPolicySummaryOfJobFilters(policyNumber)
                .validatePolicySummaryPageLoaded(policyNumber);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4052: Verify user can view policy details page from Policies landing, open cancellations page")
    public void testViewPolicyFromPoliciesOpenCancellations(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation).doNotWithdrawCancellationOnPolicy();
        new NavBar().goToPoliciesLanding()
                .showOpenCancelations()
                .goToPolicySummaryOfJobFilters(policyNum)
                .validatePolicySummaryPageLoaded(policyNum);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4053: Verify user can view policy details page from Policies landing, open cancellations page")
    public void testViewQuoteFromPolicyLandingOpenQuotes(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        String jobNumber = new NavBar().goToPoliciesLanding()
                .showOpenQuotes()
                .openFirstJob();
        new QuoteSummary().validateQuotePageWasLoaded(jobNumber).shouldBeTrue("Quote Page is not opened");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4056: Verify user can view policy details page from Policies landing, open changes page")
    public void testViewChangeJobFromPoliciesLanding(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new NavBar().goToPoliciesLanding()
                .showRecentlyIssued()
                .goToPolicySummary(policyNumber)
                .createChangePolicyTransaction();
        new NavBar().goToPoliciesLanding()
                .showOpenChanges()
                .openFirstJob();
        new PolicyChangeSummaryPage().validatePolicyChangePageWasLoaded().shouldBeTrue("Policy Change page is not opened");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PolicyFeature" } , description = "TC4056: Verify user can view the job, related to policy cancellation from policy landing page")
    public void testViewCancellationJobFromPoliciesLanding(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        BindCancellationOnPolicyScenario policyCancellation = new BindCancellationOnPolicyScenario(policyNum);
        goToSubmitCancellation(policyCancellation).doNotWithdrawCancellationOnPolicy();
        String jobNumber = new PolicyCancelationSummary().getCancellationJobNumber();
        new NavBar().goToPoliciesLanding()
                .showOpenCancelations()
                .openJob(jobNumber);
        new PolicyCancelationSummary().isCancellationPagePresented(jobNumber);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4058: OpenActivitiesOnPolicyDetailsPage")
    public void testOpenActivitiesOnPolicyDetailsPage(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        GPA_ActivityPageFactory activityPageFactory = new GPA_ActivityPageFactory();
        activityPageFactory.clickAddActivityButtonFromPolicyActivityTile();
        activityPageFactory.addDefaultActivity();
        ActivitiesScheduleComponent activitiesScheduleComponent = new ActivitiesScheduleComponent();
        activitiesScheduleComponent.validateActivityScheduleUIComponant();
        activitiesScheduleComponent.clickOnFirstActivity().toggleSummary().validatedActivityRowUIComponant();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4059: NotesOnPolicyDetailsPage")
    public void testValidateNotesOnPolicyDetailsPage(String browserName) throws Exception {
    	 	PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        policySummary
                .goToNotesTile();
       AddNoteComponent addNoteComponent = new AddNoteComponent();
       
       String UUID = new SeleniumCommands().generateUUID();
       addNoteComponent
       .addGeneralNote(UUID)
       .isNoteListed(UUID)
       .shouldBeTrue("Note was not listed on page");
       
       addNoteComponent
       .validateNoteUIComponant()
       .shouldBeTrue("Note UI componants are not displayed");
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4061: ActiveClaimsOnPolicyDetailsPage")
    public void testActiveClaimsOnPolicyDetailsPage(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_ClaimPagefactory()
        .createTheftClaimFromPolicy()
        .goToPolicySummaryPage()
        .goToClaimTile()
        .validateClaimTileViewUIElements()
        .shouldBeTrue("Claim tile ui elements are missing");
    }
    
	@Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4062: BillingInfoOnPolicyDetailsPage" , enabled = false)
    public void testBillingInfoOnPolicyDetailsPage(String browserName) throws Exception {
        PolicySummary policySummary = goToPolicySummaryPage("PersonalAuto");
        BillingTileView billingTileView = policySummary.goToBillingTileView();
        billingTileView.validatePolicyInfoUIElements();
        billingTileView.validatePolicyPaymentDataUIElements();
        billingTileView.validatePolicyIncoiceTableUIElements();
        billingTileView.validatePolicyPaymentDataWithBackEnd();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4073: Verify Vehicle, Driver, Policy Transactions section on PA policy details page")
    public void testPolicyDetailsSpecificToPAPolicy(String browserName) throws Exception {
        goToPolicySummaryPage("PersonalAuto")
                .verifyVehiclesSection()
                .verifyCoveredDriversSections()
                .verifyPolicyTransactionsSections();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4074: Verify Home, Construction, Protection, Coverages and Policy transaction sections for HO policy")
    public void testPolicyDetailsSpecificToHOPolicy(String browserName) throws Exception {
        goToPolicySummaryPage("HomeOwner")
                .verifyHomeDetailsSections()
                .verifyConstructionDetailsSections()
                .verifyProtectionDetailsSections()
                .verifyCoveragesDetailsSections()
                .verifyPolicyTransactionsSections();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4075: Verify user can view Coverages and Policy Transactions for BOP")
    public void testPolicyDetailsSpecificToBOPPolicy(String browserName) throws Exception {
        goToPolicySummaryPage("BusinessOwner")
                .verifyCoveragesSections("BusinessOwner")
                .verifyPolicyTransactionsSections();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"} , description = "TC4076:Verify user can view Coverages and Policy Transactions for CP")
    public void testPolicyDetailsSpecificToCPPolicy(String browserName) throws Exception {
        goToPolicySummaryPage("CommercialProperty")
                .verifyCoveragesSections("CommercialProperty")
                .verifyPolicyTransactionsSections();
    }

    private void login(){
        new LoginPage().login();
    }

    private PolicySummary goToPolicySummaryPage(String policyType)
    {
        String policyNum;
        if (policyType.equals(DataConstant.PA)){
            policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        }else if(policyType.equals(DataConstant.HO)){
            policyNum = PolicyGenerator.createBasicBoundHOPolicy();
        }else if(policyType.equals(DataConstant.BOP)){
            policyNum = PolicyGenerator.createBasicBoundBOPolicy();
        }else{
            policyNum = PolicyGenerator.createBasicBoundCPPolicy();
        }
        login();
        return new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum);
    }
}
