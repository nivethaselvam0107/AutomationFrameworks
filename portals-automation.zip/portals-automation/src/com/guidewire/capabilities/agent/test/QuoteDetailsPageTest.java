package com.guidewire.capabilities.agent.test;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;

/**
 * Created by dfedo on 28/11/2016.
 */
public class QuoteDetailsPageTest {
    HashMap<String, String> data = ThreadLocalObject.getData();
    GPA_ActivityPageFactory activityFactory = new GPA_ActivityPageFactory();

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5805: MissingMandatoryValuesWhileAddingNoteOnQuoteDetails Verify validation message is displayed for missing values while add a note to quote")
    public void testMissingMandatoryValuesWhileAddingNoteOnQuoteDetails(String browserName) throws Exception {
    		createPolicyAndDraftQuote();
    		 new NavBar().goToAccountsLanding().showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .goToFirstQuoteInList()
                .clickNotes()
                .clickAddNote()
                .submit()
                .areRequiredFieldsMarked();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5807: QuoteDetailsPage Verify Quote Details page")
    public void testQuoteDetailsPage(String browserName) throws Exception {
    		createPolicyAndDraftQuote();
        new NavBar().goToAccountsLanding().showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .goToFirstQuoteInList()
                .validateQuotePageComponents();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5810: WithdrawDraftQuote:  Verify user can withdraw quote if the quote status is draft .")
    public void testWithdrawDraftQuote(String browserName) throws Exception {
    		createPolicyAndDraftQuote();
    		new NavBar().goToAccountsLanding().showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .goToFirstQuoteInList()
                .clickWithdraw()
                .validationQuoteWithdrawn();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5813: WithdrawQuotedQuote: Verify user can withdraw quote if the quote status is quoted")
    public void testWithdrawQuotedQuote(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        new NavBar().goToAccountsLanding().showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .openQuoteByLink()
                .clickWithdraw()
                .validationQuoteWithdrawn();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC5819: AddNoteOnQuoteDetails: Verify user can add a note on quote details page")
    public void testAddNoteOnQuoteDetails(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
    		System.out.println(ThreadLocalObject.getData());
    		new GPA_QuotePageFactory().createQuotedQuote();
    		new NavBar().goToAccountsLanding().showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .goToFirstQuoteInList()
                .clickNotes()
                .clickAddNote()
                .withTopic()
                .withSubject()
                .withNoteText()
                .saveNoteCounter()
                .submit()
                .isNoteAdded().shouldBeTrue("Note didn't get added");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3512: SearchQuoteByProvidingPartialQuoteNumber Verify user can search for quote by providing partial quote number.")
    public void testSearchQuoteByProvidingPartialQuoteNumber(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        new NavBar().goToAccountsLanding()
                .showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .searchQuoteByPartialNumber()
                .isQuotePresented().shouldBeTrue("Quote is not presented in the field");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3509: SearchQuoteByProvidingFullQuoteNumber Verify user can search for quote by providing full quote number.")
    public void testSearchQuoteByProvidingFullQuoteNumber(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        new GPA_QuotePageFactory().createQuotedQuote();
        new NavBar().goToAccountsLanding()
                .showRecentlyCreated()
                .openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToOpenQuotes()
                .searchQuote()
                .isQuotePresented().shouldBeTrue("Quote is not presented in the field");
    }

    private void createPolicyAndDraftQuote() throws Exception{
    		PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_QuotePageFactory().createDraftQuote();
    }
}
