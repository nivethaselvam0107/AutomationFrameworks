package com.guidewire.capabilities.agent.test;


import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class PolicySummaryTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","PA"} , description = "TC4057: DetailsAndTilesOnPolicyDetailsSummaryPage")
    public void verifyDetialsTilesOnPolicySummaryPage(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        PolicySummary policySummary = new PolicySummary();
        policySummary.openPolicySummary(policyNum);
        policySummary.verifyDetailsOnPolicySummaryPage(policyNum).shouldBeTrue("Policy details on summary page did not match");
        policySummary.verifyTilesOnPolicyPage();
    }

}
