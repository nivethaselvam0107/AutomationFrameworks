package com.guidewire.capabilities.agent.test;


import java.util.HashMap;

import com.guidewire.common.util.DateUtil;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.AccountSearchResults;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.QuoteStart;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.BOPGeneralCoveragesPage;
import com.guidewire.portals.qnb.pages.BuildingsAndLocationsPage;
import com.guidewire.portals.qnb.pages.CPBOPPolicyDetailsPage;
import com.guidewire.portals.qnb.pages.CPBOPPolicyInfoPage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;

public class BOPLineTest {

    //Businessowners

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3640: BusinessownersPolicyDetailsPageValidation")
    public void testBOPPolicyDetailsPageValidation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithNewAccount(data);

        new Pagefactory()
                .getCPBOPPolicyDetailPage()
                .clickNext();

        CPBOPPolicyDetailsPage cpbopPolicyDetailsPage = new CPBOPPolicyDetailsPage();
        cpbopPolicyDetailsPage.isOrgTypeFieldMarkedWithError().shouldBeEqual("Org Type field not marked with error properly");
        cpbopPolicyDetailsPage.isSmallBusinessTypeFieldMarkedWithError().shouldBeEqual("Small Business Type field not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3647: BusinessownersAddBuilding")
    public void testBOPAddBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isBuildingAdded().shouldBeTrue("Building not added");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC3645: BusinessownersRemoveBuilding")
    public void testBOPRemoveBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBasisAmount(data.get("BasisAmount"))
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding()
                .removeBuilding();

        buildingsAndLocationsPage.isNumberOfBuildingsCorrect("0").shouldBeEqual("Number of buildings is a mismatch");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC3646:BusinessownersRemoveLocation")
    public void testBOPRemoveLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewLocationForm()
                .setLocationData(false)
                .saveBOPLocation()
                .removeLocation();

        buildingsAndLocationsPage.isLocationPresent().shouldBeFalse("Location not removed");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC3648:BusinessownersAddLocation, GPA--676:BusinessownersAddLocation")
    public void testBOPAddLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewLocationForm()
                .setLocationData(false)
                .saveBOPLocation();

        buildingsAndLocationsPage.isLocationPresent().shouldBeTrue("Location not added properly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3651: BusinessownersPolicyInfoPageValidation-MandatoryFields")
    public void testBOPPolicyInfoMandatoryFields(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithNewAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPQuotePageAndGoNext();

        pagefactory.getCPBOPPolicyInfoPage()
                .clickNext();

        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.isPhoneFieldMarkedWithError().shouldBeEqual("Phone number field not marked with error properly");
        cpbopPolicyInfoPage.isEmailFieldMarkedWithError().shouldBeEqual("Email field not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3650: BusinessownersConfirmationPage-PolicyDetailPage")
    public void testBOPConfirmationPagePolicyDetailsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);
        String policyNumber = new Pagefactory().setDataTillBOPPaymentDetailPageAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");

        PolicyConfirmationPage policyConfirmationPage = new PolicyConfirmationPage();
        policyConfirmationPage
                .goToPolicyDetailPage();

        policyConfirmationPage.isPolicyDetailPageDisplayed(policyNumber).shouldBeTrue("Correct policy detail page not displayed");

    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3654: Businessowners-ContinueQuoteAfterCancellingOnPolicyDetails")
    public void testBOPCancelOnPolicyDetailsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .getCPBOPPolicyDetailPage()
                .setOrgType(false)
                .setCoverageDate(DateUtil.getFutureDate())
                .setSmallBusinessType(false)
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getBOPQualificationPage()
                .goPrev();

        pagefactory.getCPBOPPolicyDetailPage().arePolicyDetailsSaved(PolicyType.BO.toString()).shouldBeTrue("Policy details didn't save");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3655:Businessowners-ContinueQuoteAfterCancellingOnQualifications")
    public void testBOPCancelOnQualificationPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataOnBOPPolicyDetailsAndGoNext();

        pagefactory
                .getBOPQualificationPage()
                .setPolicyDeclinedQuestion()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getBuildingsAndLocationsPage()
                .goPrev();

        pagefactory
                .getBOPAddCoveragePage()
                .goPrev();

        pagefactory.getBOPGenCoveragePage()
                .goPrev();

        pagefactory.getBOPQualificationPage().isPolicyDeclinedQuesMarkedNo().shouldBeTrue("Answer not saved");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3656:Businessowners-ContinueQuoteAfterCancellingOnGeneralCoverages")
    public void testBOPCancelOnGenCoveragesPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPQualAndGoNext();

        pagefactory
                .getBOPGenCoveragePage()
                .setLimitsOccurenceCoverage()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getBuildingsAndLocationsPage()
                .goPrev();

        pagefactory
                .getBOPAddCoveragePage()
                .goPrev();

        pagefactory.getBOPGenCoveragePage().isLimitsOccurenceCoverageSaved().shouldBeEqual("Liability Limits value wasn't saved");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = " TC3657: Businessowners-ContinueQuoteAfterCancellingOnAdditionalCoverages")
    public void testBOPCancelOnAddCoveragesPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPGenCvgAndGoNext();

        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getBuildingsAndLocationsPage()
                .goPrev();

        pagefactory.getBOPAddCoveragePage().isGuestPropertySafeDepositSelected();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3659: Businessowners-ContinueQuoteAfterCancellingOnLocationsAndBuildings")
    public void testBOPCancelOnLocationsAndBuildingsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPAddCvgAndGoNext();

        pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory.getBuildingsAndLocationsPage().isBuildingAdded().shouldBeTrue("Building didn't save");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3660: Businessowners-ContinueQuoteAfterCancellingOnQuote")
    public void testBOPCancelOnQuotePage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPBuildingPageAndGoNext();

        pagefactory
                .getCPBOPQuotePage()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getCPBOPQuotePage()
                .isBOPQuotePageLoaded().shouldBeTrue("Quote page didn't load");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3661: Businessowners-ContinueQuoteAfterCancellingOnPolicyInfo")
    public void testBOPCancelOnPolicyInfoPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPQuotePageAndGoNext();

        pagefactory
                .getCPBOPPolicyInfoPage()
                .setEmailField()
                .setPhoneField()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getCPBOPQuotePage()
                .clickNext();

        pagefactory.getCPBOPPolicyInfoPage().isPolicyInfoPageSaved().shouldBeTrue("Policy Info page didn't save");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3662: Businessowners-ContinueQuoteAfterCancellingOnPaymentDetails")
    public void testBOPCancelOnPaymentDetailsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPPolicyInfoPageAndGoNext();

        pagefactory
                .getPaymentDetails()
                .setPaymentPlan()
                .setAccountNumber()
                .setABARoutingNumber()
                .setBankName()
                .clickCancel().confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getCPBOPQuotePage()
                .clickNext();

        pagefactory
                .getCPBOPPolicyInfoPage()
                .clickNext();

        pagefactory.getPaymentDetails().isPaymentInformationPageSaved().shouldBeFalse("Payment information was saved");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3667: BusinessownersEditBuilding")
    public void testBOPEditBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPBuildingPageAndGoNext();

        pagefactory
                .getCPBOPQuotePage()
                .goPrev();

       pagefactory.getBuildingsAndLocationsPage()
                .clickOnEditBldng()
                .setBasisAmount(data.get("NewBasisAmount"))
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .setTenantsLiabilityCvg()
                .saveBOPBuilding();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory.getBuildingsAndLocationsPage();
        buildingsAndLocationsPage.isBasisAmountCorrectOnDetails().shouldBeEqual("Basis Amount didn't save on Details");
        buildingsAndLocationsPage.isBuildingLimitDataCorrectOnCoverages().shouldBeTrue("Building limit didn't save on Coverages");
        buildingsAndLocationsPage.isTenantsLiabilityAmountCorrectOnAddCoverages().shouldBeEqual("Tenants Liability Limit didn't save on Additional Coverages");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3668: BusinessownersCancelEditBuilding")
    public void testBOPCancelEditBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPBuildingPageAndGoNext();

        pagefactory
                .getCPBOPQuotePage()
                .goPrev();

        pagefactory.getBuildingsAndLocationsPage()
                .clickOnEditBldng()
                .setBasisAmount(data.get("NewBasisAmount"))
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .setTenantsLiabilityCvg()
                .clickBackAndConfirmOnBuilding();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory.getBuildingsAndLocationsPage();
        buildingsAndLocationsPage.isBasisAmountCorrectOnDetails().shouldNotBeEqual("Basis Amount saved on Details");
        buildingsAndLocationsPage.isBuildingLimitDataCorrectOnCoverages().shouldBeTrue("Building limit saved on Coverages");
        buildingsAndLocationsPage.isNoAddCoveragesMessageDisplayed().shouldBeEqual("Additional Coverages were saved");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3664: BusinessownersBuildingDetailsView")
    public void testBOPBuildingDetailsView(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isBOPBuildingSaved().shouldBeTrue("Building didn't save properly");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3666: BusinessownersBuildingAdditionalCoveragesView")
    public void testBOPBuildingAddCoveragesView(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .setTenantsLiabilityCvg()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isTenantsLiabilityAmountCorrectOnAddCoverages().shouldBeEqual("Additional Coverages didn't save");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3665: BusinessownersBuildingCoveragesView")
    public void testBOPBuildingCoveragesView(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding();

        buildingsAndLocationsPage.isBuildingLimitDataCorrectOnCoverages().shouldBeTrue("Building limit didn't save on Coverages");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3663: BusinessownersCoveragesDisplayOnNewBuildingForm")
    public void testBOPAddBuildingCoveragesClassCodeDependency(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();


        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm();

        buildingsAndLocationsPage.isAddBuildingDetailsMessageDisplayed().shouldBeTrue("Add building details message isn't displayed when details haven't been added");

        buildingsAndLocationsPage
                .setPropClassCode(data.get("BOPPropertyClassCode"))
                .setBasisAmount(data.get("BasisAmount"))
                .setBuildingDesc(data.get("BuildingDescription"))
                .setYearBuilt(data.get("YearBuilt"));

        buildingsAndLocationsPage.isAddBuildingDetailsMessageDisplayed().shouldBeFalse("Add building details message is displayed when details have been added");

        buildingsAndLocationsPage
                .setClassCodeEmpty();

        buildingsAndLocationsPage.isAddBuildingDetailsMessageDisplayed().shouldBeTrue("Add building details message isn't displayed when details haven't been added");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3669:BusinessownersCancelAddBuilding")
    public void testBOPCancelAddBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .clickBackAndConfirmOnBuilding();

        buildingsAndLocationsPage.isNumberOfBuildingsCorrect("0").shouldBeEqual("Building got added");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3670: BusinessownersCancelAddLocation")
    public void testBOPCancelAddLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewLocationForm()
                .setLocationData(false)
                .clickBackAndConfirmOnLocation();

        buildingsAndLocationsPage.isLocationPresent().shouldBeFalse("Location got added");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC3671: BusinessownersAddContractorTools")
    public void testBOPAddContractorToolSI(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPQualAndGoNext();

        BOPGeneralCoveragesPage bopGeneralCoveragesPage = pagefactory
                .getBOPGenCoveragePage()
                .clickOnAddContractorTools()
                .setDataOnContractorTools()
                .clickOnAdd();

        bopGeneralCoveragesPage.isContractorToolAdded().shouldBeTrue("Contractor Tool didn't add");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3672: BusinessownersCancelAddContractorTools")
    public void testBOPCancelAddContractorToolSI(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPQualAndGoNext();

        BOPGeneralCoveragesPage bopGeneralCoveragesPage = pagefactory
                .getBOPGenCoveragePage()
                .clickOnAddContractorTools()
                .setDataOnContractorTools()
                .clickOnCancelForSI();

        bopGeneralCoveragesPage.isContractorToolAdded().shouldBeFalse("Contractor Tool was added");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3673: BusinessownersEditContractorTools")
    public void testBOPEditContractorToolSI(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPQualAndGoNext();

        BOPGeneralCoveragesPage bopGeneralCoveragesPage = pagefactory
                .getBOPGenCoveragePage()
                .clickOnAddContractorTools()
                .setDataOnContractorTools()
                .clickOnAdd();

        bopGeneralCoveragesPage.isContractorToolAdded().shouldBeTrue("Contractor Tool didn't added");

        bopGeneralCoveragesPage
                .clickOnEdit()
                .setNewDataOnContractorTools()
                .clickOnSave();

        bopGeneralCoveragesPage.isContractorToolEdited().shouldBeTrue("Contractor Tool didn't update");
    }


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3674: BusinessownersRemoveContractorTools")
    public void testBOPRemoveContractorToolSI(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPQualAndGoNext();

        BOPGeneralCoveragesPage bopGeneralCoveragesPage = pagefactory
                .getBOPGenCoveragePage()
                .clickOnAddContractorTools()
                .setDataOnContractorTools()
                .clickOnAdd();
        bopGeneralCoveragesPage.isContractorToolAdded().shouldBeTrue("Contractor Tool didn't add");

        bopGeneralCoveragesPage
                .removeContractorToolsSI();

        bopGeneralCoveragesPage.isContractorToolAdded().shouldBeFalse("Contractor tool wasn't removed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3649: Businessowners-EditCoveragesOnQuote")
    public void testBOPEditCoveragesOnQuotePage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .setDataTillBOPBuildingPageAndGoNext();

        pagefactory
                .getCPBOPQuotePage()
                .clickOnEditCoveragesForBOP();

        new BOPGeneralCoveragesPage().isGeneralCoveragesPageLoaded().shouldBeTrue("User wasn't redirected to General Coverages page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3701: PatrialClassCode-10MatchesOfClassCodeDisplayedBOP")
    public void testBOPPropClassCodeMatches(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setPropClassCode(data.get("BOPPropertyClassCode"));

        buildingsAndLocationsPage.areTenResultsDisplayedForClassCode().shouldBeTrue("The number of property class codes displayed wasn't 10");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3703:IncorrectPropertyClassCodeForBOP")
    public void testBOPIncorrectPropClassCode(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        startBOPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory.setDataTillBOPAddCvgAndGoNext();

        BuildingsAndLocationsPage buildingsAndLocationsPage = pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setPropClassCode(data.get("BOPPropertyClassCode"));

        buildingsAndLocationsPage.areResultsDisplayedForClassCode().shouldBeFalse("Property class codes still display for incorrect value");
    }

    private void login(){
        new LoginPage().login();
    }

    public void startBOPQuoteWithExistingAccount(HashMap<String, String> data){
        PolicyGenerator.createBasicBoundPAPolicy();
        data.put("POLICY_NUM", null);
        login();
        searchForPersonalAccount(data)
                .useExistingAccountWithAccountNumber(data.get(PolicyData.ACCOUNT_NUMBER.toString()))
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(PolicyType.BO.getPolicyType())
                .submit();
    }

    public void startBOPQuoteWithNewAccount(HashMap<String, String> data) {
        login();
        PolicyGenerator.createBasicBoundPAPolicy();
        data.put("POLICY_NUM", null);
        String addressLine1 = data.get("AddressLine1");
        String city = data.get("City");
        String zip = data.get("Zip");

        searchForPersonalAccount(data)
                .createNewAccount()
                .withAddressLine1(addressLine1)
                .withCity(city)
                .withZip(zip)
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .submit();

        new QuoteStart()
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(PolicyType.BO.getPolicyType())
                .submit();
    }

    public AccountSearchResults searchForPersonalAccount(HashMap<String, String> data){
        return new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
                .withLastName(data.get(PolicyData.ACCOUNT_LAST_NAME.toString()))
                .search();

    }
}
