package com.guidewire.capabilities.agent.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.GPA_QuotePageFactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;

/**
 * @author Darya Fedo
 */
public class HOQuoteCreationTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "CSR"}, description = "TC3610 @ Verify user can start a quote of type Homeowners for existing account, TC3610:CreateHomeownerQuoteForExisitingAccount")
    public void testCreateHomeownerQuoteForExisitingAccount(String browserName) throws Exception {
        ThreadLocalObject.getData().put("ProductCode", "Homeowners");
        ThreadLocalObject.getData().put("PolicyType", "Homeowners");
        PolicyGenerator.createBasicBoundHOPolicy();
        PolicyConfirmationPage policyConfirmationPage = new GPA_QuotePageFactory().startQuoteWithExistingAcount()
                .createAndBuyPolicyHO();
        policyConfirmationPage.isPolicyConfirmationPageDisplayed().shouldBeTrue("Confirmation page was not opened properly.");
        // TODO: Create a validation with Back End function
    }


}
