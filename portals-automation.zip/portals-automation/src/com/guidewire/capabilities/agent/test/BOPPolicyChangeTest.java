package com.guidewire.capabilities.agent.test;

import com.guidewire.capabilities.agent.model.page.*;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

public class BOPPolicyChangeTest {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6303:BOPPolicyChangeWithinGP, TC6615:BOPPolicyChangeWithinGP")
    public void testBOPPolicyChangeWizardEntryPolicyDetails(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage().validatePageHeaderForPolicyChange(PolicyType.BO.toString(), data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPPolicyDetailsPage().validatePresenceOfAllFields(PolicyType.BO.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6394:CancelPolicyChangeonPolicyDetailScreen")
    public void testBOPPolicyChangeCancelOnPolicyDetailsPage(String browserName) throws Exception {
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage()
                .setSmallBusinessType(true)
                .setOrgType(true)
                .pressCancelAndConfirm();

        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");
        policyChangeSummaryPage
                .continuePolicyChange();
        new CPBOPQuotePage()
                .goPrev();
        new BOPAdditionalCoveragesPage()
                .goPrev();
        new BOPGeneralCoveragesPage()
                .goPrev();
        new CPBOPPolicyDetailsPage()
                .validatePolicyDetailsWithBackend(PolicyType.BO.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6395:CancelPolicyChangeonGeneralCoverageScreen")
    public void testBOPPolicyChangeCancelOnGeneralCoverages(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage()
                .clickNext();
        new Pagefactory()
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        BOPGeneralCoveragesPage bopGeneralCoveragesPage = new BOPGeneralCoveragesPage();
        bopGeneralCoveragesPage
                .setEmployeeDishonestyCoverageTerms()
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");
        policyChangeSummaryPage
                .continuePolicyChange();
        new CPBOPQuotePage()
                .goPrev();
        new BOPAdditionalCoveragesPage()
                .goPrev();
        bopGeneralCoveragesPage.isEmployeeDishonestySelectedInBackend();
        bopGeneralCoveragesPage.validateEmployeeDishonestyTermsInBackend();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6400:CancelPolicyChangeonAdditionalCoverageScreen")
    public void testBOPPolicyChangeCancelOnAdditionalCoverages(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage()
                .clickNext();
        new BOPGeneralCoveragesPage()
                .clickNext();
        BOPAdditionalCoveragesPage bopAdditionalCoveragesPage = new BOPAdditionalCoveragesPage();
        bopAdditionalCoveragesPage
                .setGuestPropertyInSafeDepositCoverage()
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");
        policyChangeSummaryPage
                .continuePolicyChange();
        new CPBOPQuotePage()
                .goPrev();

        bopAdditionalCoveragesPage.isGuestPropertySafeDepositSelected();
        bopAdditionalCoveragesPage.validateGuestPropSafeDepositLimitInBackend();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6401:CancelPolicyChangeonLocationsAndBuildingsScreen")
    public void testBOPPolicyChangeCancelOnBuildingsAndLocations(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        new CPBOPPolicyDetailsPage()
                .clickNext();
        new BOPGeneralCoveragesPage()
                .clickNext();
        new BOPAdditionalCoveragesPage()
                .clickNext();
        BuildingsAndLocationsPage buildingsAndLocationsPage = new BuildingsAndLocationsPage();
        buildingsAndLocationsPage
                .clickOnEditBldng()
                .setBuildingDesc(data.get("NewBuildingDescription"))
                .setBasisAmount(data.get("NewBasisAmount"))
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .saveBOPBuilding()
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Draft");
        policyChangeSummaryPage
                .continuePolicyChange();
        buildingsAndLocationsPage.isBasisAmountCorrectOnDetails().shouldBeEqual("Basis Amount didn't match");
        buildingsAndLocationsPage.isBuildingLimitDataCorrectOnCoverages().shouldBeTrue("Building limit didn't save on Coverages");
        buildingsAndLocationsPage.validateBOPBuildingDetailsInBackend();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6402:CancelPolicyChangeonQuoteScreen")
    public void testBOPPolicyChangeCancelOnBOPQuoteScreen(String browserName) throws Exception {
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
        .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Quoted");
        policyChangeSummaryPage
                .continuePolicyChange();
        pagefactory
                .getCPBOPQuotePage()
                .isBOPQuotePageLoaded().shouldBeTrue("Quote page didn't load");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6404:CancelPolicyChangeonPaymentScreen")
    public void testBOPPolicyChangeCancelOnBOPPaymentScreen(String browserName) throws Exception {
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .getBOPGenCoveragePage()
                .setEmployeeDishonestyCoverageTerms()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .pressCancelAndConfirm();
        PolicyChangeSummaryPage policyChangeSummaryPage = new PolicyChangeSummaryPage();
        policyChangeSummaryPage
                .validatePolicyChangeJobStatus("Quoted");
        policyChangeSummaryPage
                .continuePolicyChange();
        pagefactory
                .getCPBOPQuotePage()
                .isBOPQuotePageLoaded().shouldBeTrue("Quote page didn't load");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6677:GoToAccountFromPolicyChangeOnGeneralCoverageScreenWithInvalidForm")
    public void testBOPPolicyChangeClickAccountOnInvalidGeneralCoverages(String browserName) throws Exception {
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .clickOnAccountLinkFromWizard();
        new AccountSummary()
                .goToOpenTransactionsTile()
                .openFirstJob();
        new PolicyChangeSummaryPage()
                .continuePolicyChange();
        pagefactory
                .getBOPGenCoveragePage()
                .validateEmployeeDishonestyFieldsAreEmpty();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6678:GoToAccountFromPolicyChangeOnAdditionalCoverageScreenWithInvalidForm")
    public void testBOPPolicyChangeClickAccountOnInvalidAddtnlCoverages(String browserName) throws Exception {
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Terror - Cap on Cert. Acts", false);
        pagefactory
                .clickOnAccountLinkFromWizard();
        new AccountSummary()
                .goToOpenTransactionsTile()
                .openFirstJob();
        new PolicyChangeSummaryPage()
                .continuePolicyChange();
        pagefactory
                .getBOPAddCoveragePage()
                .validateTerrorSelectedAndEmpty();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6411:ViewPolicyDetailsOnConfirmationPage")
    public void testBOPPolicyChangeViewPolicyFromConfirmation(String browserName) throws Exception {
        this.makeBOPChangesAndConfirm();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .clickViewPolicyBtn();
        new PolicySummary()
                .validateTileOpened("SUMMARY").shouldBeEqual("Summary tile of policy wasn't selected");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6947:ViewPolicyChangeDetailsOnConfirmationPage")
    public void testBOPPolicyChangeViewPolicyChangePageFromConfirmation(String browserName) throws Exception {
        String jobNumber = this.makeBOPChangesAndConfirm();
        ThreadLocalObject.getData().put("JobNumber", jobNumber);
        new Pagefactory()
                .getTransactionConfirmationPage()
                .clickViewPolicyChangeBtn();
        new PolicyChangeSummaryPage()
                .validatePolicyChangePageWasLoaded().shouldBeTrue("Policy Change detail page wasn't opened");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6410:ViewPolicyBillingOnConfirmationPage")
    public void testBOPPolicyChangeViewPolicyBillingFromConfirmation(String browserName) throws Exception {
        this.makeBOPChangesAndConfirm();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .clickPolicyBillingPageLink();
        new PolicySummary()
                .validateTileOpened("BILLING").shouldBeEqual("Billing tile wasn't selected");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6305:GeneralCoverageChangeOnBOP, TC6616:GeneralCoverageChangeOnBOP")
    public void testBOPPolicyChangeGeneralCoverageChange(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        String jobNum = this.makeBOPChangesAndConfirm();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .validateTransactionConfirmationPage(jobNum, data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateGeneralCoverageChangesOnBOPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6306:AdditionalCoverageChangeOnBOP, TC6617:AdditionalCoverageChangeOnBOP")
    public void testBOPPolicyChangeAddtnlCoverageChange(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        String jobNum = this.makeBOPChangesAndConfirm();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .validateTransactionConfirmationPage(jobNum, data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateAddtnlCoverageChangesOnBOPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6381:AddBuildlingChangeOnBOP, TC6618:AddBuildlingChangeOnBOP")
    public void testBOPPolicyChangeAddBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        String jobNum = this.makeBOPChangesAndConfirm();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .validateTransactionConfirmationPage(jobNum, data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateBuildingOnPolicy(PolicyType.BO.toString());
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC6382:EditExistingBuildlingChangeOnBOP, TC6620:EditExistingBuildlingChangeOnBOP")
    public void testBOPPolicyChangeEditBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        String jobNumber = pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickOnEditBldng()
                .setBuildingDesc(data.get("NewBuildingDescription"))
                .saveBOPBuilding();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForNoChange();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        new Pagefactory()
                .getTransactionConfirmationPage()
                .validateTransactionConfirmationPage(jobNumber, data.get(PolicyData.POLICY_NUM.toString()));
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isBuildingPresentOnPolicyOnBackend().shouldBeTrue("Building not present on policy");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6390:SpreadPaymentForChangeOnBOP")
    public void testBOPPolicyChangeSpreadPayments(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        String jobNumber = pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        pagefactory
        .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .getBOPGenCoveragePage()
                .setEmployeeDishonestyCoverageTerms()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickSpreadPayments();
        pagefactory
                .getTransactionConfirmationPage()
                .validateTransactionConfirmationPage(jobNumber, data.get(PolicyData.POLICY_NUM.toString()));
        pagefactory
                .getTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateGeneralCoverageChangesOnBOPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6388:RemoveGeneralCoveragesChangeOnBOP")
    public void testBOPPolicyChangeRemoveGeneralCoverage(String browserName) throws Exception {
        Pagefactory pagefactory = new Pagefactory();
        String policyNum = this.createBOPolicyWithExtraDetails();
        ThreadLocalObject.getData().put("POLICY_NUM", policyNum);
        new PolicySummary()
                .changeMyPolicy();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", true);
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForDecrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isEmployeeDishonestySelectedInBackend().shouldBeFalse("Employee Dishonesty selected in backend");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6389:RemoveAdditionalCoveragesChangeOnBOP")
    public void testBOPPolicyChangeRemoveAdditionalCoverage(String browserName) throws Exception {
        Pagefactory pagefactory = new Pagefactory();
        String policyNum = this.createBOPolicyWithExtraDetails();
        ThreadLocalObject.getData().put("POLICY_NUM", policyNum);
        new PolicySummary()
                .changeMyPolicy();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Guests Property In Safe Deposit", true);
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForNoChange();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isGuestPropSafeDepositSelectedInBackend().shouldBeFalse("Guests Property In Safe Deposit selected in backend");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6383:RemoveBuildingChangeOnBOP")
    public void testBOPPolicyChangeRemoveBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        Pagefactory pagefactory = new Pagefactory();
        String policyNum = this.createBOPolicyWithExtraDetails();
        ThreadLocalObject.getData().put("POLICY_NUM", policyNum);
        new PolicySummary()
                .changeMyPolicy();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .clickNext();
        pagefactory
                .getBOPGenCoveragePage()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .removeBuilding(data.get("NewBuildingDescription"))
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForDecrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .isBuildingPresentOnPolicyOnBackend().shouldBeFalse("Building still present on policy in backend");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC6392:AddNewLocationandBuildingChangeOnBOP")
    public void testBOPPolicyChangeAddBuildingOnNewLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        new CPBOPPolicyDetailsPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .getBOPGenCoveragePage()
                .setEmployeeDishonestyCoverageTerms()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .getNewLocationForm()
                .setLocationData(true)
                .saveBOPLocation()
                .getNewBuildingForm(data.get("NewAddressHeader"))
                .setBuildingData(PolicyType.BO.toString(), true)
                .setPersonalPropertyLimit()
                .setBuildingLimit(data.get("BuildingLimit"))
                .saveBOPBuilding()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickSpreadPayments();
        new CPBOPTransactionConfirmationPage()
                .clickViewPolicyChangeBtn()
                .validatePolicyChangeJobStatus("Bound");
        new PolicyChangeSummaryPage()
                .clickPolicyLink()
                .validateNewLocationOnCPBOPolicy();
        new PolicySummary()
                .validateBuildingOnPolicy(PolicyType.BO.toString());

    }

    private String makeBOPChangesAndConfirm(){
        HashMap<String, String> data = ThreadLocalObject.getData();
        goToBOPolicySummaryPage()
                .changeMyPolicy();
        Pagefactory pagefactory = new Pagefactory();
        String jobNumber = pagefactory
                .getCPBOPPolicyDetailPage()
                .getJobNumber();
        new CPBOPPolicyDetailsPage()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .getBOPGenCoveragePage()
                .setEmployeeDishonestyCoverageTerms()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), true)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding();
        pagefactory
                .getBuildingsAndLocationsPage()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .validateTransactionQuotePageForIncrease();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .clickPay()
                .setAccountNumber()
                .setABARoutingNumber()
                .setBankName()
                .clickPayAndFinish();

        return jobNumber;
    }

    private String createBOPolicyWithExtraDetails(){
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();
        ThreadLocalObject.getData().put("QuoteEffectiveDate", DateUtil.getFutureDate(0));
        new AgentDashboard().startBOPQuoteWithNewAccount(data);
        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .setDataOnBOPPolicyDetailsAndGoNext();
        pagefactory
                .getBOPQualificationPage()
                .setPolicyDeclinedQuestion()
                .clickNext();
        pagefactory
                .clickOnCoverageCheckbox("Employee Dishonesty", false);
        pagefactory
                .getBOPGenCoveragePage()
                .setEmployeeDishonestyCoverageTerms()
                .clickNext();
        pagefactory
                .getBOPAddCoveragePage()
                .setGuestPropertyInSafeDepositCoverage()
                .clickNext();
        pagefactory
                .getBuildingsAndLocationsPage()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), false)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding()
                .getNewBuildingForm()
                .setBuildingData(PolicyType.BO.toString(), true)
                .setBuildingLimit(data.get("BuildingLimit"))
                .setPersonalPropertyLimit()
                .saveBOPBuilding()
                .clickNext();
        pagefactory
                .getCPBOPQuotePage()
                .clickNext();
        pagefactory
                .getCPBOPPolicyInfoPage()
                .setEmailField()
                .setPhoneField()
                .clickNext();
        pagefactory
                .getPaymentInfoPage()
                .setAccountNumber()
                .setABARoutingNumber()
                .setBankName()
                .clickNext();
        String policyNum =  pagefactory
                .getConfirmationPage()
                .getPolicyNumber();
        pagefactory
                .getConfirmationPage()
                .goToPolicyDetailPage();
        return policyNum;
    }

    private void login(){
        new LoginPage().login();
    }

    private PolicySummary goToBOPolicySummaryPage()
    {
        String policyNum = PolicyGenerator.createBasicBoundBOPolicy();
        login();
        new SeleniumCommands().waitForLoaderToDisappearFromPage();
        return new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum);
    }
}
