package com.guidewire.capabilities.agent.test;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import com.guidewire.common.util.DateUtil;
import com.guidewire.portals.qnb.pages.*;
import com.guidewire.widgetcomponents.Modal;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.guidewire.capabilities.agent.model.page.AccountSearchResults;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.QuoteStart;
import com.guidewire.capabilities.agent.model.page.QuoteSummary;
import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;

public class CPLineTest {

    //Commercial Property

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond" }, description = "TC5767: CommercialPropertyPolicyDetailsPageValidation")
    public void testCPPolicyDetailsPageValidation(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithNewAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBOPPolicyDetailPage()
                .clickNext();
        new CPBOPPolicyDetailsPage().isOrgTypeFieldMarkedWithError().shouldBeEqual("Org Type field not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond", "CSR", "CSR_DIA"}, description = "TC3586:CommercialPropertyBuildings&LocationsPageValidation-NoBuildingAdded")
    public void testCPBuildingsLocationsPageValidationNoBuilding(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .isNextButtonDisabled().shouldBeTrue("Next button enabled with no buildings");

        new CPBuildingsAndLocations().validateTooltipDisplayedForNoBuildings();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3596:CommercialPropertyAddBuildingFromEmptyStateView")
    public void testCPAddBuilding(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());

        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.validateBuildingWithoutChangesSavedMessage();

        cpBuildingsAndLocations.clickNext();
        cpBuildingsAndLocations.validateNewBadgeOnBuilding();

    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3587:CommercialPropertyBuildings&LocationsPageValidation-MandatoryFieldsAddBuilding")
    public void testCPAddBuildingMandatoryFields(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().clickNext();
        cpBuildingsAndLocations.clickNext();

        cpBuildingsAndLocations.isPropClassCodeFieldMarkedWithError().shouldBeEqual("Error message is not marked correctly");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR", "CSR_DIA"}, description = "TC4429 : CommercialPropertyRemoveLastBuildingFromListing, TC4455 : CommercialPropertyRemoveLastBuildingFromListing")
    public void testCPRemoveLastBuildingFromListing(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation().clickNext();

        new CPBuildingsAndLocations().removeBuildingFromListing();

        new CPBuildingsAndLocations().isEmptyStateViewDisplayed();

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR", "CSR_DIA"}, description = "TC3594 : CommercialPropertyRemoveLastBuildingFromViewMode")
    public void testCPRemoveLastBuildingFromViewMode(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation().clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.openFirstBuildingFromListing().removeBuildingFromViewMode();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR", "CSR_DIA"}, description = "TC3597:CommercialPropertyAddLocation, TC4453:CommercialPropertyAddLocation")
    public void testCPAddLocation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation().clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.openLocationOfFirstBuilding();
        cpBuildingsAndLocations.validateLocationDetailsInViewMode(false);

    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3588:CommercialPropertyBuildings&LocationsPageValidation-MandatoryFieldsAddLocation")
    public void testCPAddLocationMandatoryFields(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().selectNewLocation().clickNext();

        cpBuildingsAndLocations.isAddressLine1MarkedWithError().shouldBeEqual("Address Line1 not marked with error properly");
        cpBuildingsAndLocations.isCityMarkedWithError().shouldBeEqual("City not marked with error properly");
        cpBuildingsAndLocations.isZipcodeMarkedWithError().shouldBeEqual("ZIP Code not marked with error properly");
        cpBuildingsAndLocations.isStateMarkedWithError().shouldBeEqual("State not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3584:CommercialPropertyPolicyInfoPageValidation-MandatoryFields")
    public void testCPPolicyInfoMandatoryFields(String browserName) throws Exception {
   		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithNewAccount(ThreadLocalObject.getData());
        new Pagefactory().setDataTillCPQuoteAndGoNext()
                .getCPBOPPolicyInfoPage()
                .clickNext();

        CPBOPPolicyInfoPage cpbopPolicyInfoPage = new CPBOPPolicyInfoPage();
        cpbopPolicyInfoPage.isEmailFieldMarkedWithError().shouldBeEqual("Email not marked with error properly");
        cpbopPolicyInfoPage.isPhoneFieldMarkedWithError().shouldBeEqual("Phone not marked with error properly");
    }

    @Parameters("browserName")
    @Test(enabled = false, groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3589 : CommercialPropertyPaymentDetailsPageValidation-NoPaymentPlan")
    public void testCPPaymentDetailsNoPaymentPlan(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory().setDataTillCPPolicyInfoAndGoNext()
                .getPaymentDetails()
                .clickNext();
        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isNoPaymentPlanPopUpDisplayed().shouldBeEqual("No payment plan selected error pop up not displayed");
        alertHandler.isNoPaymentPlanSelectedErrorEqualsTo().shouldBeEqual("Alert message did not match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3590 : CommercialPropertyPaymentDetailsPageValidation-BankAccountMandatoryFields")
    public void testCPPaymentDetailsMandatoryFieldsBankAccount(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory().setDataTillCPPolicyInfoAndGoNext()
                .getPaymentDetails()
                .setPaymentPlan()
                .setPaymentMethod(ThreadLocalObject.getData().get("PaymentMethod"))
                .clickNext();

        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.isAccountNumberMarkedWithError().shouldBeEqual("Account number field not marked with error properly");
        paymentDetailsPage.isRoutingNumberMarkedWithError().shouldBeEqual("Routing number field not marked with error properly");
        paymentDetailsPage.isBankNameMarkedWithError().shouldBeEqual("Bank Name field not marked with error properly");

    }



    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3591 : CommercialPropertyPaymentDetailsPageValidation-CreditCardMandatoryFields")
    public void testCPPaymentDetailsMandatoryFieldsCreditCard(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory().setDataTillCPPolicyInfoAndGoNext()
                .getPaymentDetails()
                .setPaymentPlan()
                .setPaymentMethod(ThreadLocalObject.getData().get("PaymentMethod"))
                .clickNext();

        PaymentDetailsPage paymentDetailsPage = new PaymentDetailsPage();
        paymentDetailsPage.isCreditCardNumberMarkedWithMandatoryError().shouldBeEqual("Credit card number field not marked with error properly");
        paymentDetailsPage.isExpirationDateMarkedWithError().shouldBeEqual("Expiration date field not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3592:CommercialPropertyPaymentDetails-CreditCardNumberCheck")
    public void testCPPaymentDetailsInvalidCreditCardNumber(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ExpirationYear", "2030");

        login();

        startCPQuoteWithExistingAccount(data);

        new Pagefactory().setDataTillCPPolicyInfoAndGoNext()
                .getPaymentDetails()
                .setPaymentPlan()
                .setPaymentMethod(data.get("PaymentMethod"))
                .setCardNumber(data.get("CreditCardNumber"))
                .setExpirationDate(data.get("ExpirationMonth"), data.get("ExpirationYear"))
                .clickNext();

        new PaymentDetailsPage().isCreditCardNumberMarkedWithInvalidError().shouldBeEqual("Credit card number field not marked with error properly");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3593:CommercialPropertyPaymentDetails-CreditCardExpirationDateCheck")
    public void testCPPaymentDetailsInvalidExpirationDate(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundCPPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("ExpirationYear", Integer.toString(Calendar.getInstance().get(Calendar.YEAR)));
        login();

        startCPQuoteWithExistingAccount(data);

        new Pagefactory().setDataTillCPPolicyInfoAndGoNext()
                   .getPaymentDetails()
                   .setPaymentPlan()
                   .setPaymentMethod(data.get("PaymentMethod"))
                   .setExpirationDate(data.get("ExpirationMonth"), data.get("ExpirationYear"))
                   .setCardNumber(data.get("CreditCardNumber"))
                   .clickNext();



        new PaymentDetailsPage().isExpirationDateMarkedWithInvalidError().shouldBeEqual("Expiration date field not marked with error properly");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC35 : CommercialPropertyConfirmationPage-AccountDetailPage")
    public void testCPConfirmationPageAccountDetailsPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();

        login();

        startCPQuoteWithExistingAccount(data);

        String policyNumber = new Pagefactory().setDataTillCPPaymentAndGoNext()
                .getPolicyNumber();

        PolicyConfirmationPage policyConfirmationPage = new PolicyConfirmationPage();
        policyConfirmationPage.goToAccountDetailPage();

        policyConfirmationPage.isAccountDetailPageDisplayed().shouldBeTrue("Correct account detail page not displayed");
        new AccountSummary().isPolicyDisplayedOnAccountPage(policyNumber).shouldBeTrue("Policy not displayed");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3581 : CommercialPropertyConfirmationPage-PolicyDetailPage")
    public void testCPConfirmationPagePolicyDetailsPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();

        login();

        startCPQuoteWithExistingAccount(data);

        String policyNumber = new Pagefactory().setDataTillCPPaymentAndGoNext()
                .getPolicySummary()
                .get("POLICY_NUMBER");

        PolicyConfirmationPage policyConfirmationPage = new PolicyConfirmationPage();
        policyConfirmationPage
                .goToPolicyDetailPage();

        policyConfirmationPage.isPolicyDetailPageDisplayed(policyNumber).shouldBeTrue("Correct policy detail page not displayed");

    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3600:CommercialProperty-PastDateUnavailableForEffectiveDate")
    public void testCPPolicyDetailsForPastEffectiveDate(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();

        login();

        startCPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .goPrev();

        pagefactory
                .getCPBOPPolicyDetailPage()
                .setCoverageDate(data.get("EffectiveDate"))
                .setOrgType(true)
                .clickNext();

        new CPBOPPolicyDetailsPage().isCoverageStartFieldMarkedWithInvalidError().shouldBeEqual("Coverage Start date not marked with error properly");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3604:CommercialProperty-ContinueQuoteAfterCancellingOnPolicyDetails")
    public void testCPCancelOnPolicyDetailsPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        data.put("CoverageDate", DateUtil.getCurrentDateMMDDYYYY());
        startCPQuoteWithExistingAccount(data);
        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .getCPBuildingsAndLocationsPage()
                .goPrev();
        pagefactory
                .getCPBOPPolicyDetailPage()
                .setOrgType(false)
                .setCoverageDate(DateUtil.getFutureDate())
                .clickCancel().confirmCancel();
        new QuoteSummary()
                .continueQuote();
        pagefactory
                .getCPBuildingsAndLocationsPage()
                .goPrev();

        pagefactory.getCPBOPPolicyDetailPage().arePolicyDetailsSaved(PolicyType.CP.toString()).shouldBeTrue("Policy details didn't save");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3606:CommercialProperty-ContinueQuoteAfterCancellingOnLocations&Buildings")
    public void testCPCancelOnBuildingsPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.validateFirstBuilding();
        cpBuildingsAndLocations
                .clickCancel()
                .confirmCancel();
        new QuoteSummary()
                .continueQuote();

        cpBuildingsAndLocations.validateFirstBuilding();
        cpBuildingsAndLocations.openFirstBuildingFromListing().expandBuildingSummary().validateCPBuildingData(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3607:CommercialProperty-ContinueQuoteAfterCancellingOnQuote")
    public void testCPCancelOnQuotePage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        new Pagefactory().setDataTillCPBuildingPageAndGoNext()
                .getCPBOPQuotePage()
                .clickCancel()
                .confirmCancel();

        new QuoteSummary()
                .continueQuote();

        new CPBOPQuotePage().isCPQuotePageLoaded().shouldBeTrue("Quote page not displayed");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3608:CommercialProperty-ContinueQuoteAfterCancellingOnPolicyInfo")
    public void testCPCancelOnPolicyInfoPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setDataTillCPQuoteAndGoNext()
                .getCPBOPPolicyInfoPage()
                .setEmailField()
                .setPhoneField()
                .clickCancel()
                .confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getCPBOPQuotePage()
                .clickNext();

        new CPBOPPolicyInfoPage().isPolicyInfoPageSaved().shouldBeTrue("Policy Info page didn't save");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC3609 : CommercialProperty-ContinueQuoteAfterCancellingOnPaymentDetails")
    public void testCPCancelOnPaymentDetailsPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        Pagefactory pagefactory = new Pagefactory();

        pagefactory.setDataTillCPPolicyInfoAndGoNext()
                .getPaymentDetails()
                .setPaymentPlan()
                .setAccountNumber()
                .setABARoutingNumber()
                .setBankName()
                .clickCancel()
                .confirmCancel();

        new QuoteSummary()
                .continueQuote();

        pagefactory
                .getCPBOPQuotePage()
                .clickNext();

        pagefactory
                .getCPBOPPolicyInfoPage()
                .clickNext();

        new PaymentDetailsPage().isPaymentInformationPageSaved().shouldBeFalse("Payment information was saved");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = "TC3700: PatrialClassCode-10MatchesOfClassCodeDisplayedCP")
    public void testCPPropClassCodeMatches(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding().clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.setPropClassCode(data.get("CPPropertyClassCode"));

        cpBuildingsAndLocations.areTenResultsDisplayedForClassCode().shouldBeTrue("The number of property class codes displayed wasn't 10");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite","Diamond"}, description = " TC3702: IncorrectPropertyClassCodeForCP")
    public void testCPIncorrectPropClassCode(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();
        login();

        startCPQuoteWithExistingAccount(data);

        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding().clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.setPropClassCode(data.get("CPPropertyClassCode"));

        cpBuildingsAndLocations.areResultsDisplayedForClassCode().shouldBeFalse("Property class codes still display for incorrect value");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4370:CommercialPropertyCancelAddingBuilding-LocationsPage")
    public void testCPCancelAddBuildingOnLocationPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickCancel();
        new Modal().confirm();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
        cpBuildingsAndLocations.clickOnAddBuilding().isLocationAvailableInExistingLocations(data.get("LocAddressLine1")+", "+data.get("LocAddressLine2")+", "+data.get("LocationCity"+", "+data.get("LocationState").substring(0,2).toUpperCase()+", "+data.get("LocationZipcode"))).shouldBeFalse("Location still available in existing locations");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4371:CommercialPropertyCancelAddingBuilding-BuildingsPage")
    public void testCPCancelAddBuildingOnBuildingDetailPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.getPolicyType(), false).clickCancel();
        new Modal().confirm();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
        cpBuildingsAndLocations.clickOnAddBuilding().isLocationAvailableInExistingLocations(data.get("LocAddressLine1")+", "+data.get("LocAddressLine2")+", "+data.get("LocationCity"+", "+data.get("LocationState").substring(0,2).toUpperCase()+", "+data.get("LocationZipcode"))).shouldBeFalse("Location still available in existing locations");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4372:CommercialPropertyCancelAddingBuilding-CoveragesPage")
    public void testCPCancelAddBuildingOnCoveragesPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        cpBuildingsAndLocations.setBuildingLimit(data.get("BuildingLimit")).clickCancel();
        new Modal().confirm();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
        cpBuildingsAndLocations.clickOnAddBuilding().isLocationAvailableInExistingLocations(data.get("LocAddressLine1")+", "+data.get("LocAddressLine2")+", "+data.get("LocationCity"+", "+data.get("LocationState").substring(0,2).toUpperCase()+", "+data.get("LocationZipcode"))).shouldBeFalse("Location still available in existing locations");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4373:CommercialPropertyAddBuilding-LocationSummaryOnBuildingDetails")
    public void testCPAddBuildingCheckLocationSummaryOnBuildingDetails(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().validateLocationDetailsInViewMode(false);

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4374:CommercialPropertyAddBuilding-LocationSummaryOnCoveragesForm")
    public void testCPAddBuildingCheckLocationSummaryOnCoverages(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickNext();

        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().validateLocationDetailsInViewMode(false);

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4375:CommercialPropertyAddBuilding-BuildingSummaryOnCoveragesForm")
    public void testCPAddBuildingCheckBuildingSummaryOnCoverages(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().addNewLocationDetails().clickNext();

        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow().validateCPBuildingData(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4434:CommercialPropertyViewBuildingFromLocationViewMode")
    public void testCPBuildingLinkOnLocationView(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.addBuildingOnNewLocation().clickNext();
        cpBuildingsAndLocations.openLocationOfFirstBuilding().openFirstBuildingFromLocationView().expandBuildingSummary().validateCPBuildingData(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4435:CommercialPropertyAddBuildingFromLocationViewMode")
    public void testCPAddBuildingFromOnLocationView(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.addBuildingOnNewLocation().clickNext();
        cpBuildingsAndLocations.openLocationOfFirstBuilding().clickOnAddBuilding().clickNext();
        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).setBuildingDesc(data.get("NewBuildingDescription")).clickNext();
        cpBuildingsAndLocations.setBuildingLimit(data.get("BuildingLimit")).clickNext();

        cpBuildingsAndLocations.validateBuildingonLocationSavedMessage();
        cpBuildingsAndLocations.clickNext();

        cpBuildingsAndLocations.isBuildingAvailableOnLocation(data.get("NewBuildingDescription")).shouldBeTrue("Building wasn't added");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4436:CommercialPropertyAddAnotherBuilding")
    public void testCPAddAnotherBuilding(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.addBuildingOnNewLocation().clickAddAnotherBuilding();

        cpBuildingsAndLocations.isLocationPageDisplayedOnAddBuilding().shouldBeTrue("Add Building wizard didn't open");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4439:CommercialPropertyBackButtonOnBuildingViewMode")
    public void testCPBackButtonOnBuildingView(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.addBuildingOnNewLocation().clickNext();

        cpBuildingsAndLocations.openFirstBuildingFromListing().clickBackOnViewModes().isBuildingListingPageDisplayed().shouldBeTrue("User not taken back to Building Listing page");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4438:CommercialPropertyBackButtonOnLocationViewMode")
    public void testCPBackButtonOnLocationView(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.addBuildingOnNewLocation().clickNext();

        cpBuildingsAndLocations.openLocationOfFirstBuilding().clickBackOnViewModes().isBuildingListingPageDisplayed().shouldBeTrue("User not taken back to Building Listing page");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4378:CommercialPropertyAddBuilding-EditLocationFromBuildingDetails")
    public void testCPAddBuildingEditLocationFromBuildingDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().selectNewLocation().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().clickEditOnLocationSummary();

        cpBuildingsAndLocations.setLocationData(true).clickNext();
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().validateLocationDetailsInViewMode(true);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4379:CommercialPropertyAddBuilding-EditLocationFromCoverages")
    public void testCPAddBuildingEditLocationFromCoverages(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().selectNewLocation().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        cpBuildingsAndLocations.setBuildingLimit(data.get("BuildingLimit"));
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().clickEditOnLocationSummary();

        cpBuildingsAndLocations.setLocationData(true).clickNext();
        cpBuildingsAndLocations.clickNext();
        cpBuildingsAndLocations.expandLocationSummaryInAddBuildingFlow().validateLocationDetailsInViewMode(true);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4380:CommercialPropertyAddBuilding-EditBuildingFromCoverages")
    public void testCPAddBuildingEditBuildingDetailsFromCoverages(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.clickOnAddBuilding().selectNewLocation().addNewLocationDetails().clickNext();
        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), false).clickNext();
        cpBuildingsAndLocations.setBuildingLimit(data.get("BuildingLimit"));
        cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow().clickEditOnBuildingSummary();

        cpBuildingsAndLocations.setBuildingData(PolicyType.CP.toString(), true).clickNext();
        cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow().validateCPBuildingData(true);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4383:CommercialPropertyEditLocation-1Building")
    public void testCPAddBuildingEditLocationOneBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundCPPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation().clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.openLocationOfFirstBuilding().clickEditOnLocationSummary().setLocationData(true).saveAddedLocation();

        cpBuildingsAndLocations.validateLocationDetailsInViewMode(true);

        cpBuildingsAndLocations.openFirstBuildingFromLocationView().expandLocationSummaryInAddBuildingFlow().validateLocationDetailsInViewMode(true);

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC4384:CommercialPropertyEditLocation-2Buildings,TC4454:CommercialPropertyEditLocation-2Buildings")
    public void testCPAddBuildingEditLocationTwoBuilding(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();

        cpBuildingsAndLocations
                .addBuildingOnExistingLocation(data.get("LocAddressLine1")+", "+data.get("LocAddressLine2")+", "+data.get("LocAddressLine3")+", "+data.get("LocationCity")+", "+data.get("LocationState").substring(0,2).toUpperCase()+", "+data.get("LocationZipcode"), false)
                .clickNext();

        cpBuildingsAndLocations.openLocationOfFirstBuilding().clickEditOnLocationSummary().setLocationData(true);
        cpBuildingsAndLocations.validateMessageOnEditLocForMultipleBuildings();
        cpBuildingsAndLocations.saveAddedLocation();

        cpBuildingsAndLocations.validateLocationDetailsInViewMode(true);
        cpBuildingsAndLocations.clickBackOnViewModes().validateLocationsOnListing(data.get("NewAddressHeader"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4387:CommercialPropertyEditLocation-ViewBuildingsLink")
    public void testCPAddBuildingEditLocationTwoBuildingViewBuildingLink(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();

        cpBuildingsAndLocations
                .addBuildingOnExistingLocation(data.get("LocAddressLine1") + ", " + data.get("LocAddressLine2") + ", " + data.get("LocAddressLine3") + ", " + data.get("LocationCity") + ", " + data.get("LocationState").substring(0, 2).toUpperCase() + ", " + data.get("LocationZipcode"), false)
                .clickNext();

        cpBuildingsAndLocations.openLocationOfFirstBuilding().clickEditOnLocationSummary();
        cpBuildingsAndLocations.clickOnViewBuildingsLinkOnEditLocation().validateNumberOfBuildingsOnLocationViewMode(2);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4388:CommercialPropertyEditBuildingDetailsFromConfirmationPage")
    public void testCPAddBuildingEditBuildingDetailsFromConfirmationPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandBuildingSummary()
                .clickEditOnBuildingSummary()
                .setBuildingData(PolicyType.CP.toString(), true)
                .saveAddedBuilding();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations.validateBuildingSavedMessage();
        cpBuildingsAndLocations.expandBuildingSummary().validateCPBuildingData(true);

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4389:CommercialPropertyEditBuildingDetailsFromListingsPage")
    public void testCPEditBuildingDetailsFromListingsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openFirstBuildingFromListing()
                .expandBuildingSummary()
                .clickEditOnBuildingSummary()
                .setBuildingData(PolicyType.CP.toString(), true)
                .saveAddedBuilding();

        cpBuildingsAndLocations.validateBuildingSavedMessage();
        cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow().validateCPBuildingData(true);

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4430:CommercialPropertyEditLocationFromConfirmationPage")
    public void testCPAddBuildingEditLocationFromConfirmationPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandLocationSummaryInAddBuildingFlow()
                .clickEditOnLocationSummary()
                .setLocationData(true)
                .saveAddedLocation();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .validateLocationDetailsInViewMode(true);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4432:CommercialPropertyEditBuildingCoveragesFromConfirmationPage")
    public void testCPAddBuildingEditCoveragesFromConfirmationPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandCoveragesSummaryInAddBuildingFlow()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .saveCoveragesOnBuilding();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("NewBuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC4433:CommercialPropertyEditBuildingCoveragesFromListingsPage,TC4457:CommercialPropertyEditBuildingCoveragesFromListingsPage")
    public void testCPAddBuildingEditCoveragesFromListingsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openFirstBuildingFromListing()
                .expandCoveragesSummaryInAddBuildingFlow_ExcludesFirefox()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"))
                .saveCoveragesOnBuilding();

        cpBuildingsAndLocations
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("NewBuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4431:CommercialPropertyEditLocationFromBuildingViewMode")
    public void testCPAddBuildingEditLocationFromBuildingViewMode(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openFirstBuildingFromListing()
                .expandLocationSummaryInAddBuildingFlow()
                .clickEditOnLocationSummary()
                .setLocationData(true)
                .saveAddedLocation();

        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .validateLocationDetailsInViewMode(true);
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4437:CommercialPropertyRemovingLastBuildingRemovesItsLocation")
    public void testCPRemovingLastBuildingRemovesLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        List<String> location = new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .getExistingLocations();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .clickNext();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), false)
                .clickNext();
        cpBuildingsAndLocations
                .setBuildingLimit(data.get("BuildingLimit"))
                .clickNext();
        cpBuildingsAndLocations
                .clickNext();
        cpBuildingsAndLocations
                .addBuildingOnNewLocation()
                .clickNext();
        String[] smallLocationHeader = location.toString().split(", ");
        cpBuildingsAndLocations
                .removeBuildingForLocation(smallLocationHeader[1]+", "+smallLocationHeader[4]+", "+smallLocationHeader[5]);
        cpBuildingsAndLocations
                .clickNext();
        cpBuildingsAndLocations
                .goPrev();
        cpBuildingsAndLocations
                .clickOnAddBuilding()
                .isLocationAvailableInExistingLocations(location.toString()).shouldBeFalse("Location still available");


    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4440:CommercialPropertyCancelEditLocation")
    public void testCPCancelEditLocationFromConfirmationPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openLocationOfFirstBuilding()
                .clickEditOnLocationSummary()
                .setLocationData(true);

        cpBuildingsAndLocations
                .clickCancelAndConfirmOnForm();
        cpBuildingsAndLocations
                .validateLocationDetailsInViewMode(false);
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4441:CommercialPropertyCancelEditBuildingDetails")
    public void testCPCancelEditBuildingDetailsFromListingsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();

        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openFirstBuildingFromListing()
                .expandBuildingSummary()
                .clickEditOnBuildingSummary()
                .setBuildingData(PolicyType.CP.toString(), true);
        cpBuildingsAndLocations
                .clickCancelAndConfirmOnForm();

        cpBuildingsAndLocations.expandBuildingSummaryInAddBuildingFlow().validateCPBuildingData(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4442:CommercialPropertyCancelEditBuildingCoverages")
    public void testCPCancelEditCoveragesFromListingsPage(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .openFirstBuildingFromListing()
                .expandCoveragesSummaryInAddBuildingFlow_ExcludesFirefox()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"));
         cpBuildingsAndLocations
                 .clickCancelAndConfirmOnForm();
        cpBuildingsAndLocations
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("BuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4446:CommercialPropertyAddBuildingToThisLocation")
    public void testCPAddBuildingToThisLocation(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingToDefaultLocation(false)
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .addBuildingOnNewLocation()
                .clickNext();
        cpBuildingsAndLocations
                .clickOnAddBuildingToThisLocation()
                .validateSelectedLocation(data.get("LocAddressLine1") + ", " + data.get("LocAddressLine2") + ", " + data.get("LocAddressLine3") + ", " + data.get("LocationCity") + ", " + data.get("LocationState").substring(0, 2).toUpperCase() + ", " + data.get("LocationZipcode"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4443:CommercialPropertySearchByBuildingNameOnListings")
    public void testCPSearchByBuildingDescription(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), true)
                .clickNext();
        cpBuildingsAndLocations
                .setBuildingLimit(data.get("BuildingLimit"))
                .clickNext();
        cpBuildingsAndLocations
                .clickNext();
        cpBuildingsAndLocations
                .addBuildingToDefaultLocation(false)
                .clickNext();

        cpBuildingsAndLocations
                .searchForString("Corporate")
                .validateIfTextHighlighted("Corporate");
        cpBuildingsAndLocations
                .validateFirstBuilding();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4444:CommercialPropertySearchByClassCodeOnListings")
    public void testCPSearchByPropertyClassCode(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), true)
                .clickNext();
        cpBuildingsAndLocations
                .setBuildingLimit(data.get("BuildingLimit"))
                .clickNext();
        cpBuildingsAndLocations
                .clickNext();
        cpBuildingsAndLocations
                .addBuildingToDefaultLocation(false)
                .clickNext();

        cpBuildingsAndLocations
                .searchForString("0001")
                .validateIfTextHighlighted("0001");
        cpBuildingsAndLocations
                .validateClassCodeOnFirstBuilding();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4445:CommercialPropertySearchByLocationNameOnListings")
    public void testCPSearchByLocationName(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();

        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingToDefaultLocation(false)
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .addBuildingOnNewLocation()
                .clickNext();

        cpBuildingsAndLocations
                .searchForString("12, SF")
                .validateIfTextHighlighted("12, SF");
        cpBuildingsAndLocations
                .validateLocationOnFirstBuilding();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC4447:CommercialPropertySwitchEditModes-BuildingToCoverage-SaveChanges, TC4458:CommercialPropertySwitchEditModes-BuildingToCoverage-SaveChanges")
    public void testCPSwitchEdit_BuildingToCoverage_SaveChanges(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandBuildingSummary()
                .clickEditOnBuildingSummary()
                .setBuildingData(PolicyType.CP.toString(), true);
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandCoveragesSummaryInAddBuildingFlow()
                .clickEditOnCoveragesSummary();
        new Modal().confirm();
        cpBuildingsAndLocations
                .expandBuildingSummary()
                .validateCPBuildingData(true);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4448:CommercialPropertySwitchEditModes-CoverageToLocation-SaveChanges")
    public void testCPSwitchEdit_CoverageToLocation_SaveChanges(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandCoveragesSummaryInAddBuildingFlow()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"));
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .clickEditOnLocationSummary();
        new Modal().confirm();
        cpBuildingsAndLocations
                .setLocationData(true);
        cpBuildingsAndLocations
                .clickCancelAndConfirmOnForm()
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("NewBuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4449:CommercialPropertySwitchEditModes-BuildingToCoverage-DoNotSaveChanges")
    public void testCPSwitchEdit_BuildingToCoverage_DoNotSaveChanges(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandBuildingSummary()
                .clickEditOnBuildingSummary()
                .setBuildingData(PolicyType.CP.toString(), true);
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandCoveragesSummaryInAddBuildingFlow()
                .clickEditOnCoveragesSummary();
        new Modal().dismiss();
        cpBuildingsAndLocations
                .expandBuildingSummary()
                .validateCPBuildingData(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4450:CommercialPropertySwitchEditModes-CoverageToLocation-DoNotSaveChanges")
    public void testCPSwitchEdit_CoverageToLocation_DoNotSaveChanges(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .addBuildingOnNewLocation()
                .expandCoveragesSummaryInAddBuildingFlow()
                .clickEditOnCoveragesSummary()
                .setBuildingLimit(data.get("NewBuildingLimit"));
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .clickEditOnLocationSummary();
        new Modal().dismiss();
        cpBuildingsAndLocations
                .setLocationData(true);
        cpBuildingsAndLocations
                .clickCancelAndConfirmOnForm()
                .expandCoveragesSummaryInAddBuildingFlow()
                .validateCoverageChange(data.get("BuildingLimit"));
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4466:CommercialPropertyEditLocation-DefaultToNew")
    public void testCPEditLocation_DefaultToNew(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .clickEditOnLocationSummary()
                .addNewLocationDetails()
                .clickNext();
        cpBuildingsAndLocations
                .expandLocationSummaryInAddBuildingFlow()
                .validateLocationDetailsInViewMode(false);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4467:CommercialPropertyNavigatingToPolicyDetails-BuildingsPageOnAddBuilding")
    public void testCPPolicyDetailsFromAddBuilding_BuildingDetails(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .addNewLocationDetails()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), false);
        new LeftNavigationMenuHandler().goToPolicyDetailsPage();
        new CPBOPPolicyDetailsPage()
                .clickNext();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4468:CommercialPropertyNavigatingToPolicyDetails-CoveragesPageOnAddBuilding")
    public void testCPPolicyDetailsFromAddBuilding_Coverages(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .addNewLocationDetails()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), false)
                .clickNext();
        cpBuildingsAndLocations
                .setBuildingLimit(data.get("BuildingLimit"));
        new LeftNavigationMenuHandler().goToPolicyDetailsPage();
        new CPBOPPolicyDetailsPage()
                .clickNext();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond"}, description = "TC4469:CommercialPropertyNavigatingToPolicyDetails-LocationPageOnAddBuilding")
    public void testCPPolicyDetailsFromAddBuilding_Location(String browserName) throws Exception {
        HashMap<String, String> data = ThreadLocalObject.getData();
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .addNewLocationDetails();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        new LeftNavigationMenuHandler().goToPolicyDetailsPage();
        new CPBOPPolicyDetailsPage()
                .clickNext();

        cpBuildingsAndLocations.isEmptyStateViewDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7542,TC7601:CommercialPropertyCoverageDependency-CauseOfLoss-Basic")
    public void testCPPolicyCoverageDependencyBuildingBasic(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Basic", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7543,TC7605:CommercialPropertyCoverageDependency-CauseOfLoss-Broad")
    public void testCPPolicyCoverageDependencyBuildingBroad(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Broad", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7552,TC7603:CommercialPropertyCoverageDependency-CauseOfLoss-Special")
    public void testCPPolicyCoverageDependencyBuildingSpecial(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Special", "Building");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeTrue("Exclude Theft coverage term unavailable for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7553,TC7602:CommercialPropertyCoverageDependency-BusinessPersonalPropertyCoverage-CauseOfLoss-Basic")
    public void testCPPolicyCoverageDependencyBusinessPersonalPropertyBasic(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Basic", "Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7555,TC7606:CommercialPropertyCoverageDependency-BusinessPersonalProperty-CauseOfLoss-Broad")
    public void testCPPolicyCoverageDependencyBusinessPersonalPropertyBroad(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Broad", "Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeFalse("Exclude Theft coverage term available for Building Coverage");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","CSR","CSR_DIA"}, description = "TC7554,TC7604:CommercialPropertyCoverageDependency-BusinessPersonalProperty-CauseOfLoss-Special")
    public void testCPPolicyCoverageDependencyBusinessPersonalPropertySpecial(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        login();
        startCPQuoteWithExistingAccount(ThreadLocalObject.getData());
        this.setCauseOfLossOnNewBuilding("Special", "Business Personal Property");

        new CPBuildingsAndLocations()
                .isCoverageTermExcludeTheftAvailable().shouldBeTrue("Exclude Theft coverage term unavailable for Building Coverage");
    }

    private void setCauseOfLossOnNewBuilding(String cause, String cvgTerm){
        new Pagefactory()
                .getCPBuildingsAndLocationsPage()
                .clickOnAddBuilding()
                .clickNext();
        CPBuildingsAndLocations cpBuildingsAndLocations = new CPBuildingsAndLocations();
        cpBuildingsAndLocations
                .setBuildingData(PolicyType.CP.toString(), true)
                .clickNext();
        if(cvgTerm.equals("Building"))
            cpBuildingsAndLocations.selectCauseOfLossForBuildingCoverage(cause);
        else
            cpBuildingsAndLocations.selectCauseOfLossForBusinessPersonalPropertyCoverage(cause);
    }

    private void login(){
        new LoginPage().login();
    }

    private void startCPQuoteWithExistingAccount(HashMap<String, String> data){
        searchForPersonalAccount(data)
                .useExistingAccountWithAccountNumber(data.get(PolicyData.ACCOUNT_NUMBER.toString()))
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(PolicyType.CP.getPolicyType())
                .submit();
    }

    private void startCPQuoteWithNewAccount(HashMap<String, String> data) {
        String addressLine1 = data.get("AddressLine1");
        String city = data.get("City");
        String zip = data.get("Zip");

        searchForPersonalAccount(data)
            .createNewAccount()
            .withAddressLine1(addressLine1)
            .withCity(city)
            .withZip(zip)
            .withState(data.get("State"))
            .withProducerByIndex(1)
            .submit();

        new QuoteStart()
            .withState(data.get("State"))
            .withProducerByIndex(1)
            .withProductCode(PolicyType.CP.getPolicyType())
            .submit();
    }

    public AccountSearchResults searchForPersonalAccount(HashMap<String, String> data){
        return new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
                .withLastName(data.get(PolicyData.ACCOUNT_LAST_NAME.toString()))
                .search();

    }
}
