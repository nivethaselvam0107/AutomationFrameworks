package com.guidewire.capabilities.agent.model.page;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.Modal;
/**
 * Created by dfedo on 22/11/2016.
 */
public class QuoteOpenActivities {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    public HashMap<String, String> data = ThreadLocalObject.getData();

    String FIRST_ACTIVITY = "div[class='gw-priority-icon']";

    String ACTIVITY_TITLE = "div[ng-show*='activitiesTomorrow'] div[class='gw-banner ng-binding']";

    String NOTE_TEXT = "div[class='gw-note-details'] div[class='gw-description ng-binding']";

    String TYPE_VALUE = "//*[contains(text(), 'TYPE')]/following-sibling::div";


    public QuoteOpenActivities openFirstActivity() {
        seleniumCommands.waitForElementToBePresent(By.cssSelector(FIRST_ACTIVITY));
        seleniumCommands.clickbyJS(By.cssSelector(FIRST_ACTIVITY));
        return this;
    }

    public Validation validationActivityDetails() {
        seleniumCommands.waitForElementToBePresent(By.cssSelector(ACTIVITY_TITLE));
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(ACTIVITY_TITLE)), DataConstant.ACTIVITY_TITLE).shouldBeEqual("Activity title is incorrect");
        String type= seleniumCommands.findElement(By.xpath(TYPE_VALUE)).getText();
        new Validation(type, DataConstant.ACTIVITY_TYPE).shouldBeEqual("Activity type is incorrect");
        new Validation(seleniumCommands.getTextAtLocator(By.cssSelector(NOTE_TEXT)), DataConstant.NOTE_TEXT).shouldBeEqual("Note text is incorrect is incorrect");
        return new Validation(true);
    }

}
