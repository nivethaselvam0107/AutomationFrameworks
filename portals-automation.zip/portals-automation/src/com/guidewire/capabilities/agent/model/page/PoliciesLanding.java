package com.guidewire.capabilities.agent.model.page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.ProducerCodeSelector;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.table.Table;

public class PoliciesLanding {

    private final Tiles tiles;
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    
    @FindBy(css = "h1[class*='gw-titles-title']")
    static WebElement TITLE;

    @FindBy(css = "table[list='filteredJobs']")
    static WebElement OPEN_QUOTES;

    private static final By POLICIES_TABLE = By.cssSelector("table[list='gwPolicySummary']");

    private static final By RECENTLY_ISSUED_TILE_CSS = By.cssSelector("[tile-title='Recently Issued'][class*='active']");

    @FindBy(css = "a[ng-click='switchFilterType(!showAdvancedFilter)']")
    WebElement FILTERS_TOGGLE;

    @FindBy(css = "label[for='CanceledPolicies']")
    WebElement ADVANCED_FILTERS_CANCELLED;

    @FindBy(css = "label[for='ExpiredPolicies']")
    WebElement ADVANCED_FILTERS_EXPIRED;

    @FindBy(css = "label[for='ExpiredPolicies']")
    WebElement ADVANCED_LOB_SECTION;

    @FindBy(css = "[ng-click*='recentlyViewedFilter'][class*='active']")
    WebElement DEFAULT_TILE;

    @FindBy(css = "div[ng-hide][aria-hidden='false'] table[list='filteredJobs'] tr:nth-of-type(1) td[title='Job Number'] a")
    WebElement FIRST_JOB_NUM_XPATH;
    
    @FindBy(css = "table tr:nth-of-type(1) td[title='Policy Number'] a")
    WebElement FIRST_POLICY_NUM_XPATH;

    private final static String POLICY_NUMBER_LINK_XPATH = "//a[contains(@href, '%s')]";
    
    private final static String JOB_NUMBER_LINK_XPATH = "//a[contains(@href, '#/cancellation/%s/summary')]";

    private static final String JOB_NUMBER_LIST_CSS = "div[ng-hide][aria-hidden='false'] table[list='filteredJobs'] td[title='Job Number'] a";

    public PoliciesLanding() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);
        this.tiles = new Tiles();
        seleniumCommands.waitForElementSelectToHaveMoreValuesThan(seleniumCommands.findElement(By.cssSelector("[name=\"selectedProducerCode\"]")), 1);
    }

    public PoliciesLanding showOpenQuotes() {
        this.tiles.selectByTitle("Open Quotes");
        seleniumCommands.waitForElementToBeVisible(OPEN_QUOTES);
        return this;
    }

    public Table getOpenQuotes() {
        this.showOpenQuotes();
        return new Table(OPEN_QUOTES);
    }

    public PoliciesLanding showRecentlyIssued() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.tiles.selectByTitle("Recently Issued");
        seleniumCommands.waitForElementToBeVisible(POLICIES_TABLE);
        return this;
    }

    public PoliciesLanding showOpenChanges() {
        seleniumCommands.logInfo("Clicking Open Changes tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.tiles.selectByTitle("Open Changes");
        return this;
    }

    public PoliciesLanding showDelinquent() {
        seleniumCommands.logInfo("Clicking Delinquen tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.tiles.selectByTitle("Delinquent");
        return this;
    }

    public PoliciesLanding showOpenRenewals() {
        seleniumCommands.logInfo("Clicking Renewals tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.tiles.selectByTitle("Open Renewals");
        return this;
    }

    public PoliciesLanding showOpenCancelations() {
        seleniumCommands.logInfo("Clicking Open Cancellations tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.tiles.selectByTitle("Open Cancellations");
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("table[list='filteredJobs']"));
        return this;
    }

    public String openFirstJob(){
    	seleniumCommands.waitForLoaderToDisappearFromPage();
        String jobNumber = seleniumCommands.getTextAtLocator(FIRST_JOB_NUM_XPATH);
        seleniumCommands.click(FIRST_JOB_NUM_XPATH);
        return jobNumber;
    }
  

    public PolicySummary openFirstPolicy(){
    	seleniumCommands.waitForLoaderToDisappearFromPage();
        String policyNum = seleniumCommands.getTextAtLocator(FIRST_POLICY_NUM_XPATH);
        ThreadLocalObject.getData().put(PolicyData.POLICY_NUM.toString(), policyNum);
        seleniumCommands.click(FIRST_POLICY_NUM_XPATH);
        return new PolicySummary();
    }
    
    public void openJob(String jobNumber) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<WebElement> elementList = seleniumCommands.findElements(By.cssSelector(JOB_NUMBER_LIST_CSS));
        for (WebElement element : elementList) {
            if (seleniumCommands.getTextAtLocator(element).equals(jobNumber)) {
                seleniumCommands.clickbyJS(element);
                seleniumCommands.waitForLoaderToDisappearFromPage();
                break;
            }
        }
    }

    public Table getRecentlyIssued() {
        this.showRecentlyIssued();
        return this.getPolicies();
    }

    public PolicySummary goToPolicySummary(String policyNumber) {
        seleniumCommands.logInfo("Clicking policy link "+ policyNumber);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(By.xpath(String.format(POLICY_NUMBER_LINK_XPATH, policyNumber)));
        return new PolicySummary(policyNumber);
    }

    public PolicySummary goToPolicySummaryOfJobFilters(String policyNumber) {
        seleniumCommands.logInfo("Clicking policy link from Open Changes tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click( By.xpath("//table[contains(@list,'filteredJobs')]" + String.format(POLICY_NUMBER_LINK_XPATH,policyNumber)));
        return new PolicySummary(policyNumber);
    }

    public Table getPolicies() {
        seleniumCommands.waitForElementToBeVisible(POLICIES_TABLE);
        return new Table(seleniumCommands.findElement(POLICIES_TABLE));
    }

    public PoliciesLanding toggleQuickAdvancedFilters() {
        seleniumCommands.waitForElementToBeVisible(FILTERS_TOGGLE);
        FILTERS_TOGGLE.click();
        return this;
    }

    public PoliciesLanding advancedToggleCancelled() {
        seleniumCommands.waitForElementToBeVisible(ADVANCED_FILTERS_CANCELLED);
        seleniumCommands.click(ADVANCED_FILTERS_CANCELLED);
        return this;
    }

    public PoliciesLanding advancedToggleExpired() {
        seleniumCommands.waitForElementToBeVisible(ADVANCED_FILTERS_EXPIRED);
        seleniumCommands.click(ADVANCED_FILTERS_EXPIRED);
        return this;
    }

    public PoliciesLanding advancedToggleLOBByName(String lob) {
        seleniumCommands.waitForElementToBeVisible(ADVANCED_LOB_SECTION);
        ADVANCED_LOB_SECTION.findElement(By.xpath(String.format("//label[contains(text(), '%s')]", lob))).click();
        return this;
    }

    public PolicyCancelationSummary clickCancellationJob(String linkName) {
        seleniumCommands.logInfo("Clicking Cancellation job number");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.partialLinkText(linkName)).click();
        return new PolicyCancelationSummary();
    }

    public ProducerCodeSelector getProducerCodeSelector() {
        return new ProducerCodeSelector();
    }

    public Validation checkTitle(){
        return new Validation(this.TITLE.getText(), "Policies");
    }

    public Validation checkDefaultTile(){
        String tileName = seleniumCommands.getTextAtLocator(this.DEFAULT_TILE.findElement(By.cssSelector("div[class*='title']")));
        return new Validation(tileName,"RECENTLY VIEWED");
    }

}
