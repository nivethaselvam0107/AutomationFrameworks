package com.guidewire.capabilities.agent.model.page;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.data.BillingData;
import com.guidewire.capabilities.agent.data.ParsePolicyBillingData;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.table.*;

public class BillingTileView {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    private HashMap<String, String> data = ThreadLocalObject.getData();

    @FindBy(css = "[policy-billing-summary] select")
    WebElement POLICY_PERIOD_DROP_CSS;
    
    @FindBy(css = "[class*='info'] div label")
    WebElement POLICY_PERIOD_LABEL_CSS;
    
    @FindBy(css = "[policy-billing-summary] [class*='ng-binding'] label")
    WebElement POLICY_STATUS_LABEL_CSS;
    
    @FindBy(css = "[class*='info'] [class*='ng-binding']:nth-of-type(2)")
    WebElement POLICY_STATUS_VALUEL_CSS;
    
    @FindBy(css = "[policy-billing-summary] [href*='account']")
    WebElement VIEW_ACCT_BILL_LINK_CSS;
    
    @FindBy(css = "[class*='costings'] [class*='binding']:nth-of-type(1)")
    List<WebElement> COSTING_ELEMENTS_LABEL_CSS;
    
    @FindBy(css = "[class*='costings'] [class*='binding']:nth-of-type(2)")
    List<WebElement> COSTING_ELEMENTS_VALUE_CSS;
    
    @FindBy(css = "[list*='currentPolicyPeriodBillingSummary.invoices'] th")
    List<WebElement> INVOICE_TABLE_HEADER_CSS;
    
    @FindBy(css = "[list*='currentPolicyPeriodBillingSummary.invoices'] tbody tr")
    List<WebElement> INVOICE_ROW_CSS;

    @FindBy(xpath = "//div[@class='gw-billing-info-owned-policies']//h2")
    WebElement  POLICIES_TABLE_HEADERS_LABEL;

    @FindBy(css = "h1[class*='gw-titles-title']")
    WebElement BILLING_ACCOUNT_NUMBER;

    @FindBy(xpath = "//div[@class='gw-col-desktop-6 gw-col-tablet-6 gw-account-billing-column-left']//label")
    List<WebElement> CUSTOMER_PAYMENT_VALUES_LEFT;

    @FindBy(xpath = "//div[@class='gw-col-desktop-6 gw-col-tablet-6 gw-account-billing-column-right']//label")
    List<WebElement> CUSTOMER_PAYMENT_VALUES_RIGHT;

    @FindBy(xpath = "//div[@class='gw-billing-info-owned-policies']//table")
    WebElement POLICIES_OWNED_TABLE;

    By BILLING_STATUS_VALUE = By.cssSelector("h4 span[ng-hide='accountBillingData.isDelinquent']");

    @FindBy(css = "label[class='ng-binding']")
    List<WebElement>  BILLING_HEADER_LABELS;

    @FindBy(css = "[ng-show*='.ownedPolicies'] th")
    List<WebElement>  POLICIES_OWNED_COLUMN_LABELS;

    @FindBy(css = "[ng-show*='.unownedPolicies'] th")
    List<WebElement>  OTHER_POLICIES_COLUMN_LABELS;

    private static final String POLICIES_OWENED_LABEL_TEXT = "Policies Owned by this Account";
    private static final String OTHER_POLICIES_LABEL_TEXT = "Other Policies Billed to this Account";
    private static final String POLICY_PERIOD_LABEL_TEXT = "Policy Period";
    private static final String POLICY_STATUS_LABEL_TEXT = "Status:";
    private static final String CURRENT_PAYMENT_LABEL_TEXT = "Current Payment";
    private static final String PAST_DUE_LABEL_TEXT = "Past Due";
    private static final String TOTAL_DUE_LABEL_TEXT = "Total Due";
    private static final String ALREADY_PAID_LABEL_TEXT = "Already Paid";
    private static final String UNBILLED_LABEL_TEXT = "Unbilled";
    private static final String DUE_LABEL_TEXT = "Due";
    private static final String TOTAL_CHARGES_LABEL_TEXT = "Total Charges";
    private static final String BILLING_METHOD_LABEL_TEXT = "Billing Method";
    private static final String PAYMENT_PLAN_LABEL_TEXT = "Payment Plan";
    private static final String ALT_BILLING_ACC_LABEL_TEXT = "Alt Billing Account";
    private static final String INVOICING_LABEL_TEXT = "Invoicing";
    private static final String DUEDATE_HEADER_TEXT = "DUE DATE";
    private static final String PAIDSTATUS_HEADER_TEXT = "PAID STATUS";
    private static final String PAID_HEADER_TEXT = "PAID";
    private static final String OUTSTANDING_HEADER_TEXT = "OUTSTANDING";
    private static final String STMT_AMOUNT_HEADER_TEXT = "STATEMENT AMOUNT";
    private static final String COLLATERAL_REQUIREMENT_LABEL_TEXT = "Collateral Requirement:";
    private static final String COLLATERAL_HELD_LABEL_TEXT = "Collateral Held:";
    private static final String UNAPPLIED_FUNDS_LABEL_TEXT = "Unapplied Funds:";
    private static final String PRIMARY_PAYER_LABEL_TEXT = "Primary Payer";
    private static final String BILLING_ACCOUNT_LABEL_TEXT = "Billing Account:";
    private static final String POLICY_NUMBER_COLUMN = "POLICY #";
    private static final String PRODUCT_COLUMN = "PRODUCT";
    private static final String EFF_DATE_COLUMN = "EFF DATE";
    private static final String EXP_DATE_COLUMN = "EXP DATE";
    private static final String BILLED_AMOUNT_COLUMN = "BILLED AMOUNT";
    private static final String PAST_DUE_COLUMN = "PAST DUE";
    private static final String ALT_BILLING_ACCOUNT_COLUMN = "ALT BILLING ACCOUNT";
    private static final String STATUS_COLUMN = "STATUS";
    private static final String UNBILLED_COLUMN = "UNBILLED";
    private static final String OWNING_ACCOUNT_COLUMN = "OWNING ACCOUNT";


    public BillingTileView() {
        seleniumCommands.pageWebElementLoader(this);
    }
  
    //Get methods
    public HashMap<String, String> getPolicyPaymentDataUIElements() {
	    	seleniumCommands.logInfo("Getting billing payment  data from UI");
	    	seleniumCommands.waitForLoaderToDisappearFromPage();
	    	HashMap<String, String> info = new HashMap<>();
	    	info.put(BillingData.PERIOD_PERIOD.toString(), seleniumCommands.getSelectedOptionFromDropDown(POLICY_PERIOD_DROP_CSS).split(":")[1].trim());
	    	info.put(BillingData.STATUS.toString(), seleniumCommands.getTextAtLocator(POLICY_STATUS_VALUEL_CSS));
	    	info.put(BillingData.CURRENT_PAYMENT.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(0)));
	    	info.put(BillingData.PAST_DUE.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(1)));
	    	info.put(BillingData.TOTAL_DUE.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(2)));
	    	info.put(BillingData.ALREADY_PAID.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(3)));
	    	info.put(BillingData.UNBILLED.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(4)));
	    	info.put(BillingData.DUE.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(5)));
	    	info.put(BillingData.TOTAL_CHARGES.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(6)));
	    	info.put(BillingData.BILLING_METHOD.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(7)).replace(" ", ""));
	    	info.put(BillingData.PAYMENT_PLAN.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(8)));
	    	info.put(BillingData.ALT_BILLING_PLAN.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(9)));
	    	info.put(BillingData.INVOICING.toString(), seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_VALUE_CSS.get(10)));
	    info.put(BillingData.INVOICE_COUNT.toString(), INVOICE_ROW_CSS.size()+"");
	    	return info;
    }
    
    //Validation
    public Validation validatePolicyInfoUIElements() {
		seleniumCommands.logInfo("Validating billing period info UI elements");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(seleniumCommands.getTextAtLocator(POLICY_PERIOD_LABEL_CSS), POLICY_PERIOD_LABEL_TEXT).shouldBeEqual("Policy period label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(POLICY_STATUS_LABEL_CSS), POLICY_STATUS_LABEL_TEXT).shouldBeEqual("Policy status label is not matched");
		new Validation(seleniumCommands.isElementPresent(VIEW_ACCT_BILL_LINK_CSS)).shouldBeTrue("View Account billing link is not present");
		return new Validation(true);
    }
    
    public Validation validatePolicyPaymentDataUIElements() {
		seleniumCommands.logInfo("Validating billing payment UI elements");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(0)), CURRENT_PAYMENT_LABEL_TEXT).shouldBeEqual("Current payment label text is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(1)), PAST_DUE_LABEL_TEXT).shouldBeEqual("Past due label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(2)), TOTAL_DUE_LABEL_TEXT ).shouldBeEqual("Total due label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(3)), ALREADY_PAID_LABEL_TEXT ).shouldBeEqual("Already paid label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(4)), UNBILLED_LABEL_TEXT ).shouldBeEqual("Unbilled label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(5)), DUE_LABEL_TEXT ).shouldBeEqual("Due label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(6)), TOTAL_CHARGES_LABEL_TEXT ).shouldBeEqual("Total charges label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(7)), BILLING_METHOD_LABEL_TEXT ).shouldBeEqual("Billing method label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(8)), PAYMENT_PLAN_LABEL_TEXT ).shouldBeEqual("Payment plan label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(9)), ALT_BILLING_ACC_LABEL_TEXT ).shouldBeEqual("ALT billing acct label is not matched");
		new Validation(seleniumCommands.getTextAtLocator(COSTING_ELEMENTS_LABEL_CSS.get(10)), INVOICING_LABEL_TEXT ).shouldBeEqual("Invoicing label is not matched");
		return new Validation(true);
    }
    
    public Validation validatePolicyIncoiceTableUIElements() {
		seleniumCommands.logInfo("Validating invoice table header UI elements");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(seleniumCommands.getTextAtLocator(INVOICE_TABLE_HEADER_CSS.get(0)), DUEDATE_HEADER_TEXT).shouldBeEqual("Due date header text is not matched");
		new Validation(seleniumCommands.getTextAtLocator(INVOICE_TABLE_HEADER_CSS.get(1)), PAIDSTATUS_HEADER_TEXT).shouldBeEqual("Paid status header text is not matched");
		new Validation(seleniumCommands.getTextAtLocator(INVOICE_TABLE_HEADER_CSS.get(2)), PAID_HEADER_TEXT ).shouldBeEqual("Paid header text is not matched");
		new Validation(seleniumCommands.getTextAtLocator(INVOICE_TABLE_HEADER_CSS.get(3)), OUTSTANDING_HEADER_TEXT ).shouldBeEqual("Outstanding header text is not matched");
		new Validation(seleniumCommands.getTextAtLocator(INVOICE_TABLE_HEADER_CSS.get(4)), STMT_AMOUNT_HEADER_TEXT ).shouldBeEqual("Stmt amount header text is not matched");
		return new Validation(true);
    }
    
    public Validation validatePolicyPaymentDataWithBackEnd() throws ParseException {
  		seleniumCommands.logInfo("Validating invoice table header UI elements");
  		seleniumCommands.waitForLoaderToDisappearFromPage();
  		MapCompare.compareMap(getPolicyPaymentDataUIElements(), ParsePolicyBillingData.getPolicyDocumentDataFromBackEnd(DataFetch.getAgentPolicyBillingDataAsSU(data.get(PolicyData.POLICY_NUM.toString()))));
  		return new Validation(true);
      }

    public Validation validateBillingTileUIComponentsGPA() throws ParseException {
        seleniumCommands.logInfo("Validating billing tile UI elements");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(BILLING_ACCOUNT_NUMBER).contains("Test-")).shouldBeTrue("Billing Account number is not present");

        new Validation(seleniumCommands.getTextAtLocator(CUSTOMER_PAYMENT_VALUES_LEFT.get(0)), "Past Due" ).shouldBeEqual("Past Due is not present");
        new Validation(seleniumCommands.getTextAtLocator(CUSTOMER_PAYMENT_VALUES_LEFT.get(1)), "Current Payment" ).shouldBeEqual("Current Payment is not present");
        new Validation(seleniumCommands.getTextAtLocator(CUSTOMER_PAYMENT_VALUES_LEFT.get(2)), "Total Due" ).shouldBeEqual("Total Due is not present");
        new Validation(seleniumCommands.getTextAtLocator(CUSTOMER_PAYMENT_VALUES_RIGHT.get(0)), "Collateral Requirement" ).shouldBeEqual("Collateral Requirement is not present");
        new Validation(seleniumCommands.getTextAtLocator(CUSTOMER_PAYMENT_VALUES_RIGHT.get(1)), "Collateral Held" ).shouldBeEqual("Collateral Held is not present");
        new Validation(seleniumCommands.getTextAtLocator(POLICIES_TABLE_HEADERS_LABEL), "Policies Owned by this Account" ).shouldBeEqual("Mismatch in Header: Policies Owned by this Account");

        Table table = new Table (POLICIES_OWNED_TABLE);
        new Validation(table.getHeader().getCellByIndex(0).getText(), "POLICY NUMBER" ).shouldBeEqual("Mismatch in POLICY Header");
        new Validation(table.getHeader().getCellByIndex(1).getText(), "PRODUCT" ).shouldBeEqual("Mismatch in PRODUCT Header");
        new Validation(table.getHeader().getCellByIndex(2).getText(), "EFF DATE" ).shouldBeEqual("Mismatch in EFF DATE Header");
        new Validation(table.getHeader().getCellByIndex(3).getText(), "EXP DATE" ).shouldBeEqual("Mismatch in EXP DATE Header");
        new Validation(table.getHeader().getCellByIndex(4).getText(), "BILLED AMOUNT" ).shouldBeEqual("Mismatch in BILLED AMOUNT Header");
        new Validation(table.getHeader().getCellByIndex(5).getText(), "PAST DUE" ).shouldBeEqual("Mismatch in PAST DUE Header");
        new Validation(table.getHeader().getCellByIndex(6).getText(), "UNBILLED" ).shouldBeEqual("Mismatch in UNBILLED Header");
        new Validation(table.getHeader().getCellByIndex(7).getText(), "ALT BILLING ACCOUNT" ).shouldBeEqual("Mismatch in ALT BILLING ACCOUNT Header");
        new Validation(table.getHeader().getCellByIndex(8).getText(), "STATUS" ).shouldBeEqual("Mismatch in STATUS Header");

        //TODO : PolicyGen will not create an account with other policy linked to it for billing. Need Sample Data.
        /*new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(0)), POLICY_NUMBER_COLUMN).shouldBeEqual("Policy Number column text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(1)), PRODUCT_COLUMN).shouldBeEqual("Product column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(2)), EFF_DATE_COLUMN ).shouldBeEqual("Effective Date column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(3)), EXP_DATE_COLUMN ).shouldBeEqual("Expiration Date column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(4)), BILLED_AMOUNT_COLUMN ).shouldBeEqual("Billed amount column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(5)), PAST_DUE_COLUMN ).shouldBeEqual("Past due column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(6)), UNBILLED_COLUMN ).shouldBeEqual("Unbilled column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(7)), OWNING_ACCOUNT_COLUMN ).shouldBeEqual("Owning Account column is not matched");
        new Validation(seleniumCommands.getTextAtLocator(OTHER_POLICIES_COLUMN_LABELS.get(8)), STATUS_COLUMN ).shouldBeEqual("Status column is not matched");*/

        return new Validation(true);
    }
    

}

