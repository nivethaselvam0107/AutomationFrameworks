package com.guidewire.capabilities.agent.model.page;


import java.text.ParseException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.data.DocumentData;
import com.guidewire.capabilities.agent.data.NotesData;
import com.guidewire.capabilities.agent.data.ParseDocumentData;
import com.guidewire.capabilities.agent.data.ParseNotesData;
import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.endorsement.model.page.common.PolicyChanges;
import com.guidewire.capabilities.endorsement.model.page.common.componant.PolicyChangesSummary;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.data.ParsePolicySummaryData;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;


public class PolicySummary {
    private String number;

    private static final SeleniumCommands seleniumCommands = new SeleniumCommands();

    private  HashMap<String, String> data = ThreadLocalObject.getData();

    private static final String POLICY_NUMBER = ".gw-titles-title";

    private static final String POLICY_INCEPTION = "(//*[@class='gw-policy-summary-item']//*[@class='ng-binding'])[1]";

    private static final String POLICY_EXPIRATION = "(//*[@class='gw-policy-summary-item']//*[@class='ng-binding'])[2]";

    private static final String POLICY_STATUS_ON_DETAILS = "(//*[@class='gw-policy-summary-item']//*[@class='ng-binding'])[3]";

    private static final String PRODUCER_OF_REC = "(//*[@class='gw-summary-container']//*[@class='ng-binding'])[1]";

    private static final String PRODUCER_OF_SER = "(//*[@class='gw-summary-container']//*[@class='ng-binding'])[2]";

    private static final String TOTAL_PREMIUM = "(//*[@class='gw-monetary-amount ng-binding'])[1]";

    private static final String TAXES_AND_FEES = "(//*[@class='gw-monetary-amount ng-binding'])[2]";

    private static final String TOTAL_COST = "(//*[@class='gw-monetary-amount ng-binding'])[3]";

    private static final String TITLE = "[gw-visuallyhidden-unless='accountInfo.contactName'] span,[gw-visuallyhidden-unless='policy.product.productName'] span";

    private static final String CLAIMS_CSS = "div[ui-sref='policies.detail.claims']";

    private static final String NOTE_TILE_CSS = "div[tile-title='Notes']";

    private static final String DOC_TILE_CSS = "div[tile-title='Documents']";

    private static final String OPEN_ACTIVITIES_TILE_CSS = "div[tile-title='Open Activities']";

    private static final String BILLING_TILE_CSS = "div[tile-title='Billing']";


    @FindBy(css = "[gw-visuallyhidden-unless='policy.product.productName'] h1")
    WebElement POLICY_PAGE_TITLE;

    @FindBy(css = "[gw-visuallyhidden-unless='policyChangeNumber'] h1")
    WebElement CHANGE_POLICY_PAGE_TITLE;


    By RENEW_POLICY_BTN = By.cssSelector("[on-click='createPolicyRenewalTransaction()']");

    By POLICY_STATUS_HEADER = By.cssSelector("[type='policyperiod-status-Bound']");

    By REASON_ERROR = By.cssSelector("[model='cancellationView.cancelReasonCode'] div[class='ng-scope'] span");
    By REFUND_ERROR = By.cssSelector("[model='cancellationView.cancellationRefundMethod'] div[class='ng-scope'] span");
    By EFFECTIVE_DATE_ERROR = By.cssSelector("[model='cancellationView.effectiveDate'] div[class='ng-scope'] span");
    By CHANGE_POLICY_BTN = By.cssSelector("button[on-click='showChangeForm()']");
    By CANCEL_POLICY_BTN = By.cssSelector("button[on-click='showCancellationForm()']");
    By SUMMARY_TILE = By.cssSelector("[tile-title='Summary']");
    By JOB_LINK = By.xpath("//td[contains(text(), 'Policy Change')]/preceding-sibling::td[@gw-test-gateway-policytransactiondirective-policy-transaction-job-number]");

    By MAKE_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-make]");
    By MODEL_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-model]");
    By YEAR_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-year]");
    By LICENSE_PLATE_SECTION = By.cssSelector("[ gw-test-policy-pa-directives-templates-policy-vehicle-info-license]");
    By SHOW_VEHICLE_COVERAGES_LINK = By.cssSelector("[ gw-test-policy-pa-directives-templates-policy-vehicle-info-show-vehicle-coverages-link]");
    By COVERAGES_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-coverage]");
    By TYPE_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-type]");
    By LIMITS_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-limits]");
    By DEDUCTIBLE_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-deductible]");
    By PREMIUM_BREAKDOWN_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-premium-breakdown]");
    By OPEN_COVERED_DRIVERS_LINK = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-driver-info-expand-covered-drivers-section-link]");
    By OPEN_VEHICLES_LINK = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-vehicle-info-expand-vehicles-section-link]");
    By NAME_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-driver-info-name]");
    By LICENSE_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-driver-info-license]");
    By DOB_SECTION = By.cssSelector("[gw-test-policy-pa-directives-templates-policy-driver-info-date-of-birth]");
    By POLICY_TRANSACTIONS_JOB_NUMBER_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-job-number]");
    By POLICY_TRANSACTIONS_TYPE_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-type]");
    By POLICY_TRANSACTIONS_STATUS_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-status]");
    By POLICY_TRANSACTIONS_PERIOD_STATUS_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-period-status]");
    By POLICY_TRANSACTIONS_PREMIUM_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-premium]");
    By POLICY_TRANSACTIONS_EFFECTIVE_DATE_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-effective-date]");

    By EXPAND_HOME_DETAILS_LINK = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-expand-home-details-section-link]");
    By ADDRESS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-address]");
    By DISTANCE_TO_FIRE_HYDRANT_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-distance-to-fire-hydrant]");
    By DISTANCE_TO_FIRE_STATION_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-distance-to-fire-station]");
    By FLOODING_OR_FIRE_HAZARD_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-flood-or-fire-hazard]");
    By WITHIN_300FT_OF_COMMERCIAL_PROPERTY_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-within-300ft-of-commercial-property]");
    By LOCATION_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-location-type]");
    By RESIDENCE_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-residence-type]");
    By HOME_IS_USED_AS_SECTION = By.cssSelector("[gw-test-gateway-policytransactiondirective-policy-transaction-premium]");
    By DWELLING_OCCUPIED_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-dwelling-occupied]");

    By EXPAND_CONSTRUCTION_DETAILS_LINK = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-expand-construction-details-section-link]");
    By YEAR_BUILD_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-year-build]");
    By FOUNDATION_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-foundation-type]");
    By PLUMBING_UPGRADED_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-plumbing-upgraded]");
    By ELECTRICAL_SYSTEM_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-electrical-system]");
    By NUMBER_OF_STORIES_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-number-of-stories]");
    By ROOF_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-roof-type]");
    By PRIMARY_HEATING_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-primary-heating-type]");
    By WIRING_UPGRADED_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-wiring-upgraded]");
    By GARAGE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-garage]");
    By ROOF_UPGRADED_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-roof-upgraded]");
    By HEATING_UPGRADED_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-heating-upgraded]");
    By CONSTRUCTION_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-construction-type]");
    By PLUMBING_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-plumbing-type]");
    By WIRING_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-wiring-type]");

    By EXPAND_PROTECTION_DETAILS_LINK = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-expand-protection-details-section-link]");
    By FIRE_EXTINGUISHER_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-fire-extinguisher]");
    By DEAD_BOLTS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-dead-bolts]");
    By NUMBER_OF_UNITS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-no-of-units]");
    By FLOODING_OR_LEAK_WITHIN_5YEARS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-flooding-or-leak-within-5years]");
    By BULGAR_ALARM_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-burglar-alarm]");
    By RESIDENCE_VISIBLE_TO_NEIGHBOURS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-residence-visible-to-neighbours]");
    By FIREPLACE_OR_WOODSTOVE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-fireplace-or-woodstove]");
    By MONITORING_CENTER_FIRE_ALARM_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-monitoring-center-fire-alarm]");
    By SPRINKLER_SYSTEM_TYPE_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-sprinkler-system-type]");
    By SWIMMING_POOL_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-swimming-pool]");
    By SMOKE_ALARMS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-smoke-alarm]");
    By ROOMERS_OR_BORDERS_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-roomers-or-borders]");
    By TRAMPOLINA_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-trampoline]");
    By ADDITIONAL_LIABILITY_COVERAGES_SECTION = By.cssSelector("div[ng-if*='additionalLiabilityCoverages']");

    By EXPAND_COVERAGES_DETAILS_LINK = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-expand-coverages-section-link]");
    By SECTION_I_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-section-i-coverages]");
    By SECTION_II_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-section-ii-coverages]");
    By ADITIONAL_PROPERTY_COVERAGES_SECTION = By.cssSelector("[gw-test-policy-ho-directives-templates-policy-dwelling-info-additional-property-coverages]");

    By EXPAND_COVERAGES_LINK = By.cssSelector("[gw-test-policy-common-directives-templates-policy-common-coverables-expand-coverages-section-link]");
    By BUSINESSOWNERS_COVERAGES = By.cssSelector("[gw-test-policy-common-directives-templates-policy-common-coverables-coverages-sections]");


    private static final String JOB_NUMBER_LIST_XPATH = "//*[@gw-policy-transactions-summary]//td[@title='Job Number']//a[@aria-hidden='false']";

    final static private String POLICY_STATUS_CANCELED = "Canceled";

    @FindBy(css = "button[on-click='showChangeForm()']")
    WebElement CHANGE_MY_POLICY_LINK;

    public PolicySummary(String number) {
        this.number = number;
        seleniumCommands.pageWebElementLoader(this);
    }

    public PolicySummary() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public GPA_ClaimListPage goToClaims() {
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(CLAIMS_CSS));
        seleniumCommands.clickbyJS(By.cssSelector(CLAIMS_CSS));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new GPA_ClaimListPage();
    }

    public ClaimsTileView goToClaimTile() {
        new Tiles().selectByTitle("Claims");
        return new ClaimsTileView();
    }

    public AddNoteComponent goToNotesTile() {
        new Tiles().selectByTitle("Notes");
        return new AddNoteComponent();
    }

    public DocumentsTab goToDocumentsTile() {
        new Tiles().selectByTitle("Documents");
        return new DocumentsTab();
    }

    public GPA_ClaimListPage goToActivitiesTile() {
        new Tiles().selectByTitle("Open Activities");
        return new GPA_ClaimListPage();
    }

    public BillingTileView goToBillingTileView() {
        new Tiles().selectByTitle("Billing");
        return new BillingTileView();
    }

    public void changeMyPolicy() {
        seleniumCommands.clickbyJS(CHANGE_MY_POLICY_LINK);
    }

    public void renewMyPolicy() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(RENEW_POLICY_BTN);
        seleniumCommands.clickbyJS(RENEW_POLICY_BTN);
    }

    public PolicyChangesSummary createChangePolicyTransaction(){
        seleniumCommands.logInfo("Changing policy Address line 2 for creating policy change transaction");
        this.clickChangePolicyButton()
                .goNext()
                .checkAddressChanges()
                .goNextToChangePolicyForm()
                .setAddressLine2()
                .clickSaveAndExitBtn();
        String jobNumber = (CHANGE_POLICY_PAGE_TITLE.getText().split(" "))[2].replace(")","").replace("(","");
        ThreadLocalObject.getData().put("JobNumber", jobNumber );
        return new PolicyChangesSummary();
    }

    public PolicyCancelationSummary goCancellationSummaryPage(String jobNumber) {
        seleniumCommands.logInfo("Clicking job number link");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.xpath("//a[@href='#/cancellation/" + jobNumber +"/summary']")).click();
        return new PolicyCancelationSummary();
    }

    public PolicyChanges clickChangePolicyButton() {
        seleniumCommands.logInfo("Clicking change policy button");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(CHANGE_POLICY_BTN);
        seleniumCommands.clickbyJS(CHANGE_POLICY_BTN);
        return new PolicyChanges();
    }

    public void openPolicyChangeDetailPage(String jobNumber) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
            String locator = "a[href*='" + jobNumber + "']";
            By LINK = By.cssSelector(locator);
            seleniumCommands.clickbyJS(LINK);
        }else {
            for (WebElement element : seleniumCommands.findElements(By.xpath(JOB_NUMBER_LIST_XPATH))
                    ) {
                if (seleniumCommands.getTextAtLocator(element).equals(jobNumber)) {
                    seleniumCommands.clickbyJS(element);
                    seleniumCommands.waitForLoaderToDisappearFromPage();
                    break;
                }
            }
        }
    }

    //Validation

    public void validatePolicySummaryPageLoaded(String policyNumber) throws ParseException
    {
        seleniumCommands.logInfo("Validating Policy Summary Page was loaded");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(POLICY_PAGE_TITLE).contains(policyNumber)).shouldBeTrue("Header of Policy Page doesn't contain policy number");
        validateTileOpened("SUMMARY").shouldBeEqual("Summary tile is not activated");
    }

    public Validation validateTileOpened(String expectedTileName) {
        seleniumCommands.logInfo("Validating Summary tile is opened");
        return new  Validation(new Tiles().getSelectedTileName(), expectedTileName);
    }

    public Validation verifyDetailsOnPolicySummaryPage(String policyNum) throws Exception {
        seleniumCommands.logInfo("Comparing backend and frontend data on Policy details page: GPA--260:DetailsAndTilesOnPolicySummaryPage");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParsePolicySummaryData.getPolicySummaryDataFromBackEnd(policyData);
        seleniumCommands.waitForElementToBePresent(By.cssSelector(POLICY_NUMBER));
        HashMap<String, String> frontEndData = new HashMap<>();
        String policyNumber = seleniumCommands.getTextAtLocator(By.cssSelector(POLICY_NUMBER)).split(" ")[2];
        DataFormatUtil.putData(frontEndData, PolicyData.POLICY_NUM.toString(), policyNumber);
        DataFormatUtil.putData(frontEndData, PolicyData.POLICY_INCEPTION.toString(), seleniumCommands.getTextAtLocator(By.xpath(POLICY_INCEPTION)));
        DataFormatUtil.putData(frontEndData, PolicyData.POLICY_EXPIRATION.toString(), seleniumCommands.getTextAtLocator(By.xpath(POLICY_EXPIRATION)));
        DataFormatUtil.putData(frontEndData, PolicyData.POLICY_STATUS.toString(), seleniumCommands.getTextAtLocator(By.xpath(POLICY_STATUS_ON_DETAILS)));
        DataFormatUtil.putData(frontEndData, PolicyData.PRODUCER_OF_SERVICE.toString(), seleniumCommands.getTextAtLocator(By.xpath(PRODUCER_OF_SER)));
        DataFormatUtil.putData(frontEndData, PolicyData.PRODUCER_OF_RECORD.toString(), seleniumCommands.getTextAtLocator(By.xpath(PRODUCER_OF_REC)));
        DataFormatUtil.putData(frontEndData, PolicyData.TOTAL_PREMIUM.toString(), seleniumCommands.getTextAtLocator(By.xpath(TOTAL_PREMIUM)));
        DataFormatUtil.putData(frontEndData, PolicyData.TAXES_AND_FEES.toString(), seleniumCommands.getTextAtLocator(By.xpath(TAXES_AND_FEES)));
        DataFormatUtil.putData(frontEndData, PolicyData.TOTAL_COST.toString(), seleniumCommands.getTextAtLocator(By.xpath(TOTAL_COST)));
        return MapCompare.compareMap(frontEndData, backEndData);
    }

    public PolicySummary openPolicySummary(String policyNumber) {
        new LoginPage().login();
        AgentDashboard agentDashboard = new AgentDashboard();
        return agentDashboard.searchUsingSearchBox(policyNumber).goToPolicy(policyNumber);
    }

    public PolicyChangeSummaryPage openPolicySummaryOfChangedPolicy() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(JOB_LINK).click();
        return new PolicyChangeSummaryPage();
    }

    //Validation
    public Validation validatePolicyNotesDataWithBackEnd() throws ParseException {
        List<HashMap<String, String>> notesDataList = ParseNotesData.getPolicyNotesDataFromBackEnd(DataFetch.getAgentPolicyNotesDataAsSU(data.get(PolicyData.POLICY_NUM.toString())));
        HashMap<String, String> noteRow = notesDataList.stream().filter(map -> map.get(NotesData.NOTE_SUBJECT.toString()).equals(data.get(NotesData.NOTE_SUBJECT.toString()))).findFirst().get();
        return MapCompare.compareMap(noteRow, data);

    }

    public Validation validatePolicyDocumentDataWithBackEnd() throws ParseException {
        List<HashMap<String, String>> notesDataList = ParseDocumentData.getPolicyDocumentDataFromBackEnd(DataFetch.getAgentPolicyDocumentAsSU(data.get(PolicyData.POLICY_NUM.toString())));
        HashMap<String, String> noteRow = notesDataList.stream().filter(map -> map.get(DocumentData.DOC_NAME.toString()).equals(data.get(DocumentData.DOC_NAME.toString()))).findFirst().get();
        return MapCompare.compareMap(noteRow, data);
    }

    public Validation validateRenewPolicyButton() throws ParseException
    {
        seleniumCommands.logInfo("Validating renew policy button presence.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementPresent(RENEW_POLICY_BTN));
    }

    public PolicySummary validateCanceledPolicyStatus() throws ParseException
    {
        seleniumCommands.logInfo("Validating policy status is 'Canceled'.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.findElement(POLICY_STATUS_HEADER).getText(), POLICY_STATUS_CANCELED).shouldBeEqual("Policy status is incorrect");
        return this;
    }

    public void validateCancellationMandatoryFields() throws ParseException
    {
        seleniumCommands.logInfo("Validating policy cancellation mandatory fields.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.findElement(REASON_ERROR).getText(), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Reason mandatory field error message is incorrect or missing.");
        new Validation(seleniumCommands.findElement(REFUND_ERROR).getText(), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Refund mandatory field error message is incorrect or missing.");
        new Validation(seleniumCommands.findElement(EFFECTIVE_DATE_ERROR).getText(), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Effective Date mandatory field error message is incorrect or missing.");
    }

    public void verifyTilesOnPolicyPage() throws Exception {
        seleniumCommands.logInfo("Verifying tiles on policy details page: GPA--260:DetailsAndTilesOnPolicySummaryPage");
        Tiles tiles = new Tiles();
        tiles.isTilePresent("Open Activities").shouldBeTrue("Open Activities tile is not present");
        tiles.isTilePresent("Notes").shouldBeTrue("Notes tile is not present");
        tiles.isTilePresent("Documents").shouldBeTrue("Document tile is not present");
        tiles.isTilePresent("Claims").shouldBeTrue("Claims tile is not present");
        tiles.isTilePresent("Billing").shouldBeTrue("Billing tile is not present");
    }

    public PolicySummary verifyVehiclesSection() throws Exception {
        seleniumCommands.logInfo("Verifying Vehicles sections on Policy Details page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(OPEN_VEHICLES_LINK).click();
        new Validation(seleniumCommands.isElementPresent(MAKE_SECTION)).shouldBeTrue("Make section is missing.");
        new Validation(seleniumCommands.isElementPresent(MODEL_SECTION)).shouldBeTrue("Model section is missing.");
        new Validation(seleniumCommands.isElementPresent(YEAR_SECTION)).shouldBeTrue("Year section is missing.");
        new Validation(seleniumCommands.isElementPresent(LICENSE_PLATE_SECTION)).shouldBeTrue("License Plate section is missing.");
        seleniumCommands.findElement(SHOW_VEHICLE_COVERAGES_LINK).click();
        new Validation(seleniumCommands.isElementPresent(COVERAGES_SECTION)).shouldBeTrue("Coverages section is missing.");
        new Validation(seleniumCommands.isElementPresent(TYPE_SECTION)).shouldBeTrue("Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(LIMITS_SECTION)).shouldBeTrue("Limits section is missing.");
        new Validation(seleniumCommands.isElementPresent(DEDUCTIBLE_SECTION)).shouldBeTrue("Duductible section is missing.");
        new Validation(seleniumCommands.isElementPresent(PREMIUM_BREAKDOWN_SECTION)).shouldBeTrue("Premium Breakdown section is missing.");
        return this;
    }

    public PolicySummary verifyCoveredDriversSections() throws Exception {
        seleniumCommands.logInfo("Verifying Covered Drivers sections on Policy Details page");
        seleniumCommands.findElement(OPEN_COVERED_DRIVERS_LINK).click();
        new Validation(seleniumCommands.isElementPresent(NAME_SECTION)).shouldBeTrue("Name section is missing.");
        new Validation(seleniumCommands.isElementPresent(LICENSE_SECTION)).shouldBeTrue("License section is missing.");
        new Validation(seleniumCommands.isElementPresent(DOB_SECTION)).shouldBeTrue("Date of birth section is missing.");
          return this;
    }

    public PolicySummary verifyPolicyTransactionsSections() throws Exception {
        seleniumCommands.logInfo("Verifying Policy transactions sections on Policy Details page");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_JOB_NUMBER_SECTION)).shouldBeTrue("Job number section is missing.");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_STATUS_SECTION)).shouldBeTrue("Status section is missing.");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_TYPE_SECTION)).shouldBeTrue("Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_PERIOD_STATUS_SECTION)).shouldBeTrue("Period status section is missing.");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_PREMIUM_SECTION)).shouldBeTrue("premium section is missing.");
        new Validation(seleniumCommands.isElementPresent(POLICY_TRANSACTIONS_EFFECTIVE_DATE_SECTION)).shouldBeTrue("Effective date section is missing.");
        return this;
    }

    public PolicySummary verifyHomeDetailsSections() throws Exception {
        seleniumCommands.logInfo("Verifying home details sections on Policy Details page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(EXPAND_HOME_DETAILS_LINK).click();
        new Validation(seleniumCommands.isElementPresent(ADDRESS_SECTION)).shouldBeTrue("Address section is missing.");
        new Validation(seleniumCommands.isElementPresent(DISTANCE_TO_FIRE_HYDRANT_SECTION)).shouldBeTrue("Distance to Fire Hydrant section is missing.");
        new Validation(seleniumCommands.isElementPresent(DISTANCE_TO_FIRE_STATION_SECTION)).shouldBeTrue("Distance to Fire Station section is missing.");
        new Validation(seleniumCommands.isElementPresent(FLOODING_OR_FIRE_HAZARD_SECTION)).shouldBeTrue("Flooding or Fire Hazard section is missing.");
        new Validation(seleniumCommands.isElementPresent(WITHIN_300FT_OF_COMMERCIAL_PROPERTY_SECTION)).shouldBeTrue("Within 300ft of Commercial Property section is missing.");
        new Validation(seleniumCommands.isElementPresent(LOCATION_TYPE_SECTION)).shouldBeTrue("Location Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(RESIDENCE_TYPE_SECTION)).shouldBeTrue("Residence Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(HOME_IS_USED_AS_SECTION)).shouldBeTrue("Home is used as section is missing.");
        new Validation(seleniumCommands.isElementPresent(DWELLING_OCCUPIED_SECTION)).shouldBeTrue("Dwelling Occupied section is missing.");
        return this;
    }

    public PolicySummary verifyConstructionDetailsSections() throws Exception {
        seleniumCommands.logInfo("Verifying Construction Details sections on Policy Details page");
        seleniumCommands.findElement(EXPAND_CONSTRUCTION_DETAILS_LINK).click();
        new Validation(seleniumCommands.isElementPresent(YEAR_BUILD_SECTION)).shouldBeTrue("Year Build section is missing.");
        new Validation(seleniumCommands.isElementPresent(FOUNDATION_TYPE_SECTION)).shouldBeTrue("Foundation Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(PLUMBING_UPGRADED_SECTION)).shouldBeTrue("Plumbing Upgraded section is missing.");
        new Validation(seleniumCommands.isElementPresent(ELECTRICAL_SYSTEM_SECTION)).shouldBeTrue("Electrical System section is missing.");
        new Validation(seleniumCommands.isElementPresent(NUMBER_OF_STORIES_SECTION)).shouldBeTrue("No. of Stories section is missing.");
        new Validation(seleniumCommands.isElementPresent(ROOF_TYPE_SECTION)).shouldBeTrue("Roof Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(PRIMARY_HEATING_TYPE_SECTION)).shouldBeTrue("Primary Heating Type section is missing.");
        new Validation(seleniumCommands.isElementPresent(WIRING_UPGRADED_SECTION)).shouldBeTrue("Wiring Upgraded section is missing.");
        new Validation(seleniumCommands.isElementPresent(GARAGE_SECTION)).shouldBeTrue("Garage section is missing.");
        new Validation(seleniumCommands.isElementPresent(ROOF_UPGRADED_SECTION)).shouldBeTrue("Roof Upgraded section is missing.");
        new Validation(seleniumCommands.isElementPresent(HEATING_UPGRADED_SECTION)).shouldBeTrue("Heating Upgraded section is missing.");
        new Validation(seleniumCommands.isElementPresent(CONSTRUCTION_TYPE_SECTION)).shouldBeTrue("Construction type section is missing.");
        new Validation(seleniumCommands.isElementPresent(PLUMBING_TYPE_SECTION)).shouldBeTrue("Plumbing type section is missing.");
        new Validation(seleniumCommands.isElementPresent(WIRING_TYPE_SECTION)).shouldBeTrue("Wiring type section is missing.");
        return this;
    }

    public PolicySummary verifyProtectionDetailsSections() throws Exception {
        seleniumCommands.logInfo("Verifying Protection Details sections on Policy Details page");
        seleniumCommands.findElement(EXPAND_PROTECTION_DETAILS_LINK).click();
        new Validation(seleniumCommands.isElementPresent(FIRE_EXTINGUISHER_SECTION)).shouldBeTrue("Fire extinguisher section is missing.");
        new Validation(seleniumCommands.isElementPresent(DEAD_BOLTS_SECTION)).shouldBeTrue("Dead bolts section is missing.");
        new Validation(seleniumCommands.isElementPresent(NUMBER_OF_UNITS_SECTION)).shouldBeTrue("Number of units section is missing.");
        new Validation(seleniumCommands.isElementPresent(FLOODING_OR_LEAK_WITHIN_5YEARS_SECTION)).shouldBeTrue("Flooding or leak within 5years section is missing.");
        new Validation(seleniumCommands.isElementPresent(BULGAR_ALARM_SECTION)).shouldBeTrue("Burglar alarm section is missing.");
        new Validation(seleniumCommands.isElementPresent(RESIDENCE_VISIBLE_TO_NEIGHBOURS_SECTION)).shouldBeTrue("Residence visible to neighbours section is missing.");
        new Validation(seleniumCommands.isElementPresent(FIREPLACE_OR_WOODSTOVE_SECTION)).shouldBeTrue("Fireplace or woodstove section is missing.");
        new Validation(seleniumCommands.isElementPresent(MONITORING_CENTER_FIRE_ALARM_SECTION)).shouldBeTrue("Monitoring center fire alarm section is missing.");
        new Validation(seleniumCommands.isElementPresent(SPRINKLER_SYSTEM_TYPE_SECTION)).shouldBeTrue("Sprinkler system type section is missing.");
        new Validation(seleniumCommands.isElementPresent(SWIMMING_POOL_SECTION)).shouldBeTrue("Swimming pool section is missing.");
        new Validation(seleniumCommands.isElementPresent(SMOKE_ALARMS_SECTION)).shouldBeTrue("Smoke alarm section is missing.");
        new Validation(seleniumCommands.isElementPresent(ROOMERS_OR_BORDERS_SECTION)).shouldBeTrue("Roomers or borders section is missing.");
        new Validation(seleniumCommands.isElementPresent(TRAMPOLINA_SECTION)).shouldBeTrue("Trampolina section is missing.");
        return this;
    }

    public PolicySummary verifyCoveragesDetailsSections() throws Exception {
        seleniumCommands.logInfo("Verifying Coverages Details sections on Policy Details page");
        seleniumCommands.findElement(EXPAND_COVERAGES_DETAILS_LINK).click();
        new Validation(seleniumCommands.isElementPresent(SECTION_I_SECTION)).shouldBeTrue("Section I is missing.");
        new Validation(seleniumCommands.isElementPresent(SECTION_II_SECTION)).shouldBeTrue("Section II is missing.");
        if(System.getProperty("platform").equalsIgnoreCase("granite")){
            new Validation(seleniumCommands.isElementPresent(ADDITIONAL_LIABILITY_COVERAGES_SECTION)).shouldBeTrue("Additional Liability coverages section is missing.");
        }else{
            new Validation(seleniumCommands.isElementPresent(ADITIONAL_PROPERTY_COVERAGES_SECTION)).shouldBeTrue("Additional property coverages section is missing.");
        }
        return this;
    }

    public PolicySummary verifyCoveragesSections(String policyType) throws Exception {
        seleniumCommands.logInfo("Verifying Coverages sections for business owner on Policy Details page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(EXPAND_COVERAGES_LINK).click();
        int coverages_blocks_number;
        if(policyType.equals(DataConstant.BOP)){
            coverages_blocks_number = 2;
        }else{
            coverages_blocks_number = 4;
        }
        new Validation(seleniumCommands.findElements(BUSINESSOWNERS_COVERAGES).size(),coverages_blocks_number).shouldBeEqual("Some of coverages blocks is missing.");
        return this;
    }

    public Validation isEmployeeDishonestySelectedInBackend(){
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        return new Validation(lineCoverages.get("Employee_Dishonesty_Selected").equals("true"));
    }

    public Validation isGuestPropSafeDepositSelectedInBackend(){
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        return new Validation(lineCoverages.get("Guest_Prop_Safe_deposit_Selected").equals("true"));
    }

    public void validateGeneralCoverageChangesOnBOPolicy(){
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        new Validation(lineCoverages.get("Employee_Dishonesty_Limit"),(data.get("EmployeeDishonestyLimit").replace(",",""))).shouldBeEqual("Employee Dishonesty Limit wasn't saved");
        new Validation(lineCoverages.get("No_Covered_Employees"),(data.get("NumberOfCoveredEmployees"))).shouldBeEqual("Number of covered employees wasn't saved");
        new Validation(lineCoverages.get("No_Covered_Locations"),(data.get("NumberOfCoveredLocations"))).shouldBeEqual("Number of covered locations wasn't saved");
    }

    public void validateAddtnlCoverageChangesOnBOPolicy(){
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        new Validation(lineCoverages.get("Guest_Prop_Safe_deposit_Limit"), data.get("GuestPropSafeDepositLimit").replace(",","")).shouldBeEqual("Guests Property In Safe Deposit Limit didn't match");
    }

    public void validateBuildingOnPolicy(String policyType){
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        HashMap<String, String> lineCoverages;
        if(policyType.equals("BO"))
            lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        else
            lineCoverages = ParsePolicyData.getCPPolicyLineCoverages(jsonData);
        new Validation(lineCoverages.get("Business_Personal_Property_Limit"), data.get("PersonalPropertyLimit")).shouldBeEqual("Business Personal Property Limit didn't match");
        new Validation(lineCoverages.get("Building_Limit"), data.get("BuildingLimit")).shouldBeEqual("Building Limit didn't match");
    }

    public void validateNewLocationOnCPBOPolicy() {
        HashMap<String, String> lineCoverages;
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        if ((ThreadLocalObject.getData().get("PRODUCT_CODE")!=null) && (ThreadLocalObject.getData().get("PRODUCT_CODE").equals("CommercialProperty")))
            lineCoverages = ParsePolicyData.getCPPolicyLineCoverages(jsonData);
        else
            lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        new Validation(lineCoverages.containsKey("New_Location")).shouldBeTrue("New Location not present on policy");
    }

    public Validation isBuildingPresentOnPolicyOnBackend(){
        HashMap<String, String> lineCoverages;
        String jsonData = getPolicyDataFromBackend(data.get("POLICY_NUM"));
        if ((ThreadLocalObject.getData().get("PRODUCT_CODE")!=null) && (ThreadLocalObject.getData().get("PRODUCT_CODE").equals("CommercialProperty")))
            lineCoverages = ParsePolicyData.getCPPolicyLineCoverages(jsonData);
        else
            lineCoverages = ParsePolicyData.getBOPolicyLineCoverages(jsonData);
        return new Validation(lineCoverages.get("Building_Description_Present").equals("true"));
    }

    public String getPolicyDataFromBackend(String policyNumber){
        return DataFetch.getAgentPolicyData(policyNumber);
    }


}
