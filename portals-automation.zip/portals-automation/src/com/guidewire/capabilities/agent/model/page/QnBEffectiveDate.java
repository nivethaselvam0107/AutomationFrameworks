package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.locators.CommonPageLocators;
import com.guidewire.portals.qnb.pages.CommonPage;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class QnBEffectiveDate extends CommonPage {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "ng-form")
    WebElement FORM;

    public QnBEffectiveDate() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public ViewModelInput getEffectiveDate() {
        return this.getForm().getInputByModel("periodStartDate");
    }

    public QnBEffectiveDate goNext() {
        seleniumCommands.click(By.cssSelector(CommonPageLocators.NEXT_BTN_CSS));
        return this;
    }
}
