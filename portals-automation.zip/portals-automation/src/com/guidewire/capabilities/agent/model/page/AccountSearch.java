package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.form.BinaryToggler;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class AccountSearch {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public static String ACCOUNT_TYPE_COMMERCIAL = "company";
    public static String ACCOUNT_TYPE_PERSONAL = "person";
    public static String FIELD_PERSONAL_FIRSTNAME = "contact.firstName";
    public static String FIELD_PERSONAL_LASTNAME = "contact.lastName";
    public static String FIELD_COMMERCIAL_COMPANYNAME = "contactName";

    By COMPANY_LABEL_CSS = By.cssSelector("label[for*='company'][class='gw-first']");

    By PERSON_LABEL_CSS = By.cssSelector("label[for*='person'][class='gw-second']");

    @FindBy(css = "#existing-account-search .gw-page-title")
    WebElement TITLE;

    @FindBy(css = "ng-form")
    WebElement FORM;

    @FindBy(css = "[gw-pl-radios-binary]")
    WebElement TYPE_TOGGLER;

    boolean isCommmericalSelected = false;
    boolean isPersonalSelected = false;
    

    public AccountSearch() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);
    }

    public BinaryToggler getTypeToggler() {
        return new BinaryToggler(TYPE_TOGGLER);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public AccountSearch forPersonalAccount() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(PERSON_LABEL_CSS);
        isPersonalSelected = true;
        return this;
    }

    public AccountSearch forCommercialAccount() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(COMPANY_LABEL_CSS);
        isCommmericalSelected = true;
        return this;
    }

    private void checkPersonal(String fieldName) {
     //   if (!this.getTypeToggler().getSelectedValue().equals(ACCOUNT_TYPE_PERSONAL)) {
            if(!isPersonalSelected)    {
            throw new Error(fieldName + " is only available in personal account form");
        }
    }
    private void checkCommercial(String fieldName) {
    //    if (!this.getTypeToggler().getSelectedValue().equals(ACCOUNT_TYPE_COMMERCIAL)) {
          if(!isCommmericalSelected)    {
            throw new Error(fieldName + " is only available in commercial account form");
        }
    }

    public AccountSearch withFirstName(String text) {
        checkPersonal("First name");

        this.getForm().getInputByModel(FIELD_PERSONAL_FIRSTNAME).setValue(text);
        return this;
    }

    public AccountSearch withLastName(String text) {
        checkPersonal("Last name");

        this.getForm().getInputByModel(FIELD_PERSONAL_LASTNAME).setValue(text);
        return this;
    }

    public AccountSearch withCompanyName(String text) {
        checkCommercial("Company name");
        this.getForm().getInputByModel(FIELD_COMMERCIAL_COMPANYNAME).setValue(text);
        return this;
    }

    public AccountSearchResults submit() {
        this.getForm().submit();
        return new AccountSearchResults();
    }

    public AccountSearchResults search() {
        this.getForm().search();
        return new AccountSearchResults();
    }
}
