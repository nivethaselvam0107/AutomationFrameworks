package com.guidewire.capabilities.agent.model.page;


import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.Modal;
import org.openqa.selenium.By;

import java.util.HashMap;

public class PolicyRenewalSummaryPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();

    By POLICY_RENEWAL_HEADER_CSS = By.cssSelector("[class*=gw-titles-title]");

    By POLICY_LINK_CSS = By.cssSelector("div[gw-partial='Item'] a[ui-sref*='policies']");

    By RENEWAL_DETAIL_PAGE_MESSAGE_LINE1_CSS = By.cssSelector("gw-action-message gw-displaykey-format, gw-action-message [class*='gw-titles-heading']");

    By RENEWAL_DETAIL_PAGE_MESSAGE_LINE2_CSS = By.cssSelector("gw-action-message p[ng-if]:nth-of-type(1)");

    By RENEWAL_DETAIL_PAGE_MESSAGE_LINE3_CSS = By.cssSelector("gw-action-message p[ng-if]:nth-of-type(2)");

    By CONFIRM_CANCEL_RENEWAL_BTN_CSS = By.cssSelector("[ng-click*='close(optionsModel)'].gw-btn-primary");

    By CANCEL_CUSTOMER_REQ_RADIO_XPATH = By.xpath("//*[@id='customerRequestOption']/..");

    By CANCEL_INSURER_REQ_RADIO_XPATH = By.xpath("//*[@id='insurerRequestOption']/..");

    private static final String OPEN_ACTIVITIE_TILE_CSS = "[tile-title='Open Activities']";

    private static final String SUMMARY_TILE_CSS = "[tile-title='Summary']";

    private static final String NOTES_TILE_CSS = "[tile-title='Notes']";

    private static final String DOCUMENTS_TILE_CSS = "[tile-title='Documents']";

    private static final String WITHDRAW_RENEWAL_BTN_XPATH = "(//*[@ng-if='canWithdraw()'])[1]";

    private static final String CONT_RENEWAL_BTN_CSS = "[on-click='continueRenewal()']";

    private static final String EDIT_RENEWAL_BTN_CSS = "[on-click='edit()']";

    private static final String POLICY_RENEWAL_TITLE_TEXT = "Renewal (%s)";

    public String getPolicyRenewalJobNumber() {
        seleniumCommands.logInfo("Getting Policy Renewal job number.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String jobNumber = seleniumCommands.findElement(POLICY_RENEWAL_HEADER_CSS).getText().replaceAll("\\D+","");
        data.put("JobNumber",jobNumber);
        return jobNumber;
    }

    public PolicySummary clickPolicyLink() {
        seleniumCommands.logInfo("Clicking policy link.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(POLICY_LINK_CSS).click();
        return new PolicySummary();
    }

    public PolicyRenewalSummaryPage withdrawPolicyRenewal(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        try {
            seleniumCommands.click(seleniumCommands.findElement(By.xpath(WITHDRAW_RENEWAL_BTN_XPATH)).findElement(By.xpath(".//a")));
        }catch (Exception e){
            seleniumCommands.click(By.xpath(WITHDRAW_RENEWAL_BTN_XPATH));
        }
        new Modal().confirm();
        return this;
    }

    public PolicyRenewalSummaryPage continuePolicyRenewal(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(2);
        if(seleniumCommands.isElementPresent(By.cssSelector(CONT_RENEWAL_BTN_CSS))) {
            seleniumCommands.click(By.cssSelector(CONT_RENEWAL_BTN_CSS));
        }
        else {
            seleniumCommands.click(By.cssSelector(EDIT_RENEWAL_BTN_CSS));
        }
        return this;
    }

    public PolicyRenewalSummaryPage clickCancelRenewal(){
        seleniumCommands.waitForElementToBeVisible(By.xpath(WITHDRAW_RENEWAL_BTN_XPATH));
        seleniumCommands.click(By.xpath(WITHDRAW_RENEWAL_BTN_XPATH));
        return this;
    }

    public PolicyRenewalSummaryPage selectReasonForCancellation(String reason){
        if(reason.equals("Insurer"))
            seleniumCommands.click(CANCEL_INSURER_REQ_RADIO_XPATH);
        else
            seleniumCommands.click(CANCEL_CUSTOMER_REQ_RADIO_XPATH);
        return this;
    }

    public PolicyRenewalSummaryPage confirmCancelRenewal(){
        seleniumCommands.waitForElementToBeVisible(CONFIRM_CANCEL_RENEWAL_BTN_CSS);
        seleniumCommands.click(CONFIRM_CANCEL_RENEWAL_BTN_CSS);
        return this;
    }

    // Validations

    public Validation isRenewalPageDisplayed(String jobNumber) {
        seleniumCommands.logInfo("Validating if policy renewal detail page is displayed");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.findElement(POLICY_RENEWAL_HEADER_CSS).getText().contains(jobNumber));
    }

    public Validation validatePolicyRenewalJobStatus(String expectedStatus) {
        seleniumCommands.logInfo("Verifying policy renewal status");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector("[type='policyperiod-status-" + expectedStatus + "']")));
    }

    public void validateMessageOnRenewalDetailPage(String[] expectedMessage){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(3);
        new Validation(seleniumCommands.getTextAtLocator(RENEWAL_DETAIL_PAGE_MESSAGE_LINE1_CSS).contains(expectedMessage[0].replace("$policyNum", ThreadLocalObject.getData().get("POLICY_NUM")))).shouldBeTrue("The message on first line didn't match on renewal detail page");
        new Validation(seleniumCommands.getTextAtLocator(RENEWAL_DETAIL_PAGE_MESSAGE_LINE2_CSS),expectedMessage[1]).shouldBeEqual("The message on second line didn't match on renewal detail page");
        new Validation(seleniumCommands.getTextAtLocator(RENEWAL_DETAIL_PAGE_MESSAGE_LINE3_CSS),expectedMessage[2]).shouldBeEqual("The message on third line didn't match on renewal detail page");
    }

    public void validateTilesAndHeaderOnPolicyRenewalSummaryPage() {
        seleniumCommands.logInfo("Verifying tiles presence on the page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(OPEN_ACTIVITIE_TILE_CSS))).shouldBeTrue("No Open Activities tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(NOTES_TILE_CSS))).shouldBeTrue("No Notes tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(DOCUMENTS_TILE_CSS))).shouldBeTrue("No Documents tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(SUMMARY_TILE_CSS))).shouldBeTrue("No Summary tile was found");
        seleniumCommands.logInfo("Verifying policy renewal page header is correct");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(POLICY_RENEWAL_HEADER_CSS).equals(String.format(POLICY_RENEWAL_TITLE_TEXT,this.getPolicyRenewalJobNumber()))).shouldBeTrue("The page header didn't match");
    }
}
