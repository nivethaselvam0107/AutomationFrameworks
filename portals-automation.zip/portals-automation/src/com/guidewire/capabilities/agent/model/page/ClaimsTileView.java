package com.guidewire.capabilities.agent.model.page;

import java.util.*;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.PolicyDetailPage;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;

public class ClaimsTileView {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "[ng-model='tableConfig.search']")
    WebElement SEARCH_CLAIM_TXT_CSS;
    
    @FindBy(css = "[ng-if='canFileClaimAccount()'] a, [ng-if='canFileClaimPolicy()'] a")
    WebElement FILE_CLAIM_BTN_CSS;

    @FindBy(id = "LOBSelect")
    protected WebElement LOB_SELECT_CSS;

    @FindBy(css = "[list='getFilteredClaimSummaries()'], [list='paginatedClaims'] ")
    WebElement CLAIM_LIST_TABLE;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='product']")
    WebElement CLAIM_PRODUCT_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='claimNumber']")
    WebElement CLAIM_NUMBER_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='lossDate']")
    WebElement CLAIM_LOSSDATE_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='status']")
    WebElement CLAIM_STATUS_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='totalPayments.amount']")
    WebElement CLAIM_PAID_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='totalIncurredNet.amount']")
    WebElement CLAIM_NETINCURRED_HEADER;
    
    @FindBy(css = "[list='getFilteredClaimSummaries()'] [attribute='policyNumber']")
    WebElement CLAIM_POLICY_HEADER;

    private static final String CLAIM_NUMBER_LINK_CSS = "div[gw-claim-summary] a[href='#/claims/%s']";

    private static final String POLICY_NUMBER_LINK_CSS = "div[gw-claim-summary] a[href='#/policies/%s/summary']";

    private static final String FILE_CLAIM_BUTTON = "[ng-if='canFileClaimAccount()'] a, [ng-if='canFileClaimPolicy()'] a";

    private static final By PRODUCT_TYPE = By.cssSelector("td[attribute='product']");

    public ClaimsTileView() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_TABLE);
    }

    public DocumentsTab uploadDocument(String claimNumber){
        return this.selectClaim(claimNumber)
                .openDocTab()
                .uploadDocFromSummary();
    }
    public NewClaimDOLPage goToMakeAClaim() {
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(FILE_CLAIM_BUTTON));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(By.cssSelector(FILE_CLAIM_BUTTON));
        return new NewClaimDOLPage();
    }



    public ClaimsTileView waitForClaimButtonToAppearOnPage() {
        if (!seleniumCommands.isElementPresent(By.cssSelector(FILE_CLAIM_BUTTON))) {
            try {
                BillingTileView billingTileView = new PolicySummary().goToBillingTileView();
                seleniumCommands.waitForLoaderToDisappearFromPage();
                new PolicySummary().goToClaimTile();
                seleniumCommands.waitForElementToBeVisible(By.cssSelector(FILE_CLAIM_BUTTON), 30);
            } catch (Exception e) {
            }
        }
        return this;
    }

    public Validation isFileClaimButtonPresent(){
        seleniumCommands.staticWait(2);
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(FILE_CLAIM_BUTTON)));
    }

    public ClaimsTileView filterClaims(String claimNumber) {
        seleniumCommands.type(SEARCH_CLAIM_TXT_CSS, claimNumber);
        return this;
    }

    public ClaimsTileView filterClaimsByLOB(String lob) {
        seleniumCommands.logInfo("Filtering claims by selected lob");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(LOB_SELECT_CSS, lob);
        return this;
    }

    public boolean isClaimPresent(String claimNumber) {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_TABLE);
        String claimLink = generateClaimLink(claimNumber);
        seleniumCommands.waitForElementToBePresent(By.cssSelector(claimLink));
        return seleniumCommands.isElementPresent(By.cssSelector(claimLink));
    }

    public ClaimSummaryPage selectClaim(String claimNumber) {
    		seleniumCommands.waitForLoaderToDisappearFromPage();
        String claimLinkSelector;
        filterClaims(claimNumber);
        if(isClaimPresent(claimNumber)) {
            claimLinkSelector = generateClaimLink(claimNumber);
            seleniumCommands.clickbyJS(By.cssSelector(claimLinkSelector));
            seleniumCommands.waitForLoaderToDisappearFromPage();
            return new ClaimSummaryPage();
        }
        return null;
    }

    public PolicyDetailPage selectPolicy(String policyNumber) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String policyLinkSelector;
        policyLinkSelector = generatePolicyLink(policyNumber);
        seleniumCommands.clickbyJS(By.cssSelector(policyLinkSelector));
        return new PolicyDetailPage();
    }

    private String generateClaimLink(String claimNumber) {
        return String.format(CLAIM_NUMBER_LINK_CSS, claimNumber);
    }

    private String generatePolicyLink(String claimNumber) { return String.format(POLICY_NUMBER_LINK_CSS, claimNumber); }

    public Validation validateClaimListed(String claimNumber) {
        return new Validation(isClaimPresent(claimNumber));

    }

    public String createPACollisionClaim(){
        String claimNumber = createPACollisionClaimTillConfirmationPage()
               .getClaimNumber();
        new NewClaimConfirmationPage().goToAccountSummary().goToClaimTile();
        return claimNumber;
    }


    public NewClaimConfirmationPage createPACollisionClaimTillConfirmationPage(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.goToMakeAClaim()
                .selectPolicyByPolicyType("Personal Auto")
                .goNext()
                .goNext()
                .withOnlyCity()
                .goToVehicleDriverPage()
                .selectVehicle()
                .selectDriver()
                .setAirBagDeployStatus()
                .setVehicleRentalStatus()
                .setVehicleTowStatus()
                .setEquiFailureStatus()
                .setVehicleSafetyToDrive()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext()
                .goToSummary()
                .submitClaim();
        return new NewClaimConfirmationPage();
    }

    public NewClaimConfirmationPage createHOFireClaim(){
       return  this.goToMakeAClaim()
                .selectPolicyByPolicyType("Homeowners")
                .goNext()
                .goToFireDamageDetailsPage()
                .setFireDetails()
                .goNext()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }
    
    public NewClaimConfirmationPage createPATheftClaim(){
        return  new GPA_ClaimPagefactory().createTheftClaimFromPolicy();
     }

    public Validation validateLOBDropDown() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<String> actualProductList = initLOBDropDownListValues();
        List<String> dropDownlistProducts = seleniumCommands.getAllOptionsFromDropDown(LOB_SELECT_CSS);
        Collections.sort(dropDownlistProducts);
        new Validation(seleniumCommands.getSelectedOptionFromDropDown(LOB_SELECT_CSS), actualProductList.get(0)).shouldBeEqual("LOD default option is not correct.");
        new Validation(dropDownlistProducts, actualProductList).shouldBeEqual("LOB options are not listed correctly");
        return new Validation(true);
    }

    private List<String> initLOBDropDownListValues(){
        List<WebElement> products = seleniumCommands.findElements(PRODUCT_TYPE);
        SortedSet<String> productTypes=new TreeSet<String>();
        productTypes.add("Filters");
        for (int i=0; i<products.size();i++){
            productTypes.add(products.get(i).getText());
        }
        List<String> list=new ArrayList<String>(productTypes);
        return list;
    }

    public void validateFilteredLOBClimes(String lob){
        seleniumCommands.logInfo("Validating that climes were filtered correctly");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<WebElement> products = seleniumCommands.findElements(PRODUCT_TYPE);
        WebElement filtered=  products.stream()
                .filter(prod -> !prod.getText().equals(lob))
                .findFirst().orElse(null);
        new Validation(filtered==null).shouldBeTrue("Climes were not filtered properly");
    }

    public Validation validateClaimTileViewUIElements() {
    		seleniumCommands.logInfo("Validating Claim view tile's UI elements");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(new Boolean(new NavBar().isAccountsLandingSelected().actualResult.toString())) {
            new Validation(seleniumCommands.isElementPresent(LOB_SELECT_CSS)).shouldBeTrue("LOB dropdownlist is not present");
            new Validation(seleniumCommands.getAllOptionsFromDropDown(LOB_SELECT_CSS).get(0).equals("Filters")).shouldBeTrue("Default value at LOB dropdownlist is incorrect");
        }
        new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_CSS)).shouldBeTrue("File a claim button is not present");
        new Validation(seleniumCommands.isElementPresent(SEARCH_CLAIM_TXT_CSS)).shouldBeTrue("Search claim textbox is not present");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_NUMBER_HEADER), "CLAIM NUMBER").shouldBeEqual("Claim number header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_LOSSDATE_HEADER), "DATE OF LOSS").shouldBeEqual("Claim loss date header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_STATUS_HEADER), "STATUS").shouldBeEqual("Claim status header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_PAID_HEADER), "PAID").shouldBeEqual("Claim paid header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_NETINCURRED_HEADER), "NET INCURRED").shouldBeEqual("Claim net incurred header text is not matched");
        return new Validation(true);
    }

}
