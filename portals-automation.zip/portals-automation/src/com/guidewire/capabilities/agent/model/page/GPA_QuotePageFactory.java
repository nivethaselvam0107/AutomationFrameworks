package com.guidewire.capabilities.agent.model.page;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.*;

/**
 * Created by dfedo on 22/11/2016.
 */
public class GPA_QuotePageFactory {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public AccountSearchResults loginAndStartQuote() throws Exception {
         new LoginPage().login();
         return this.clickQuoteBtnAndFindAccount();
    }

    public AccountSearchResults clickQuoteBtnAndFindAccount() throws Exception {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new NavBar().startQuoteForAnyAccount()
                .forPersonalAccount()
                .withFirstName(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
                .withLastName(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString()))
                .search();
    }

    public GPA_QuotePageFactory startQuoteForAnyAccount() throws Exception {
        this.clickQuoteBtnAndFindAccount()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .fillPolicyDetailsFormForExistingAccount();
        return this;
    }

    public GPA_QuotePageFactory startGlobalQuoteForExistingAccount() throws Exception {
        new NavBar().startQuoteForThisAccount();
        new QuoteStart().fillPolicyDetailsFormForExistingAccount();
        return this;
    }

    public GPA_QuotePageFactory startQuoteWithExistingAcount() throws Exception {
        this.loginAndStartQuote()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .fillPolicyDetailsFormForExistingAccount();
        return this;
    }
    public AccountSearchResults startingQuote() throws Exception {

        new LoginPage().login();
         return new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
                .withLastName(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString()))
                .search();
    }

    public GPA_QuotePageFactory startPAQuoteWithExistingAcount() throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        this.startingQuote()
                .useExistingAccountWithAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .fillPolicyDetailsFormForExistingAccount();
        return this;
    }

    public QuoteSummary getToQuoteSummaryPage() throws Exception {
        QuoteSummary quoteSummaryPage = new GPA_QuotePageFactory()
                .getToVehicleDetailsPageAndSetData()
                .goToPAQuotePage()
                .clickReferToUnderwriterAndConfirm();
        return quoteSummaryPage;
    }

    public PAQuotePage getToPAQuotePage() throws Exception {
        PAQuotePage paQuotePage = new GPA_QuotePageFactory()
                .getToVehicleDetailsPageAndSetData()
                .goToPAQuotePage();
        return paQuotePage;
    }


    public void createQuotedQuote()throws Exception{
        String quoteNumber= new GPA_QuotePageFactory()
                .startQuoteWithExistingAcount()
                .getToVehicleDetailsPageAndSetData()
                .goToPAQuotePage().getQuoteNumber();
        ThreadLocalObject.getData().put("QuoteNumber",quoteNumber);
    }
    
    public void createDraftQuote()throws Exception{
        new GPA_QuotePageFactory()
                .startQuoteWithExistingAcount()
                .getToPAQuotePage();
                new LeftNavigationMenuHandler().gotoVehiclePage();
                new VehicleDetailsPage().clickCancel();
                new AlertHandler().closeAlert();
         new SeleniumCommands().waitForLoaderToDisappearFromPage();

    }


    public VehicleDetailsPage getToVehicleDetailsPageAndSetData() throws Exception {
        VehicleDetailsPage vehicleDetailsPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .setDOBGPA()
                .goToVehicleDetailsPage()
                .setVehicleDetails();
        String quoteNumber=   new QuoteInfoBar().getSubmissionNumber();
        ThreadLocalObject.getData().put("QuoteNumber",quoteNumber.replace("(","").replace(")",""));

        return vehicleDetailsPage;
    }

    public HOQuotePage getToQuotePageForHO() throws Exception {
        return new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToYourHomePage()
                .setYourHomePageDetails()
                .goToConstructionPage()
                .setConstructionPageDetails()
                .goToDiscountPage()
                .setDiscountPageDetails()
                .goToHOQuotePage();
    }

    public PolicyConfirmationPage createAndBuyPolicyPA() throws Exception {
        PolicyConfirmationPage policyConfirmationPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToDriverDetailsPage()
                .setPrimaryDriverDetails()
                .setDOBGPA()
                .goToVehicleDetailsPage()
                .setVehicleDetails()
                .goToPAQuotePage()
                .buyBasePolicyWithMonthlyPayment()
                .goToPAPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage().payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
        return policyConfirmationPage;
    }

    public PolicyConfirmationPage createAndBuyPolicyHO() throws Exception {
        seleniumCommands.logInfo("Creating anf buying HO policy");
        PolicyConfirmationPage policyConfirmationPage = new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToYourHomePage()
                .setYourHomePageDetails()
                .goToConstructionPage()
                .setConstructionPageDetails()
                .goToDiscountPage()
                .setDiscountPageDetails()
                .goToHOQuotePage()
                .buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .goToPaymentDetailsPage()
                .payMonthlyPremiumWithCreditCard()
                .goNext()
                .goToConfirmationPage();
        return policyConfirmationPage;
    }

    public AccountSummaryPage createQuotedHOpolicy() throws Exception {
        seleniumCommands.logInfo("Creating anf buying HO policy");
        return new Pagefactory()
                .getQualificationPage()
                .setQualificationPageDetails()
                .goToYourHomePage()
                .setYourHomePageDetails()
                .goToConstructionPage()
                .setConstructionPageDetails()
                .goToDiscountPage()
                .setDiscountPageDetails()
                .goToHOQuotePage()
                .goToAccountPage();
    }

}
