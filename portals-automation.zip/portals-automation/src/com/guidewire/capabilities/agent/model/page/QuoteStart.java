package com.guidewire.capabilities.agent.model.page;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.CancelWithModalConfirmation;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class QuoteStart {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    private HashMap<String, String> data = ThreadLocalObject.getData();

    @FindBy(css = ".gw-container-form")
    WebElement CONTAINER;

    @FindBy(css = ".gw-container-form .gw-page-title[ng-hide='!isAnExistingAccount']") //TODO: this selector is crap
    WebElement TITLE;

    @FindBy(css = "button[on-click='setCancelState()']") //TODO: this selector is crap
    WebElement CANCEL;

    @FindBy(css = "ng-form[name='newSubmissionForm']")
    WebElement FORM;
    
    @FindBy(css = "[ng-model='newSubmissionView.producerCode.value']")
    WebElement PRODUCER_CODE_DROP;

    private static final By PRODUCT_CODE_DROP_VALUES = By.cssSelector("[model='newSubmissionView.productCode'] option");

    private static final By ORG_CSS = By.cssSelector("[result='selectedOrganizationSubmissionVM.value'] textarea");
    
    private static final By ORG_VALUES = By.cssSelector("[result='selectedOrganizationSubmissionVM.value'] ul[aria-hidden='false'] li");
    
    private static final By PROD_CODE_DROP_CSS = By.cssSelector("[ng-model='newSubmissionView.producerCode.value']");

    public QuoteStart() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);
    }

    public AccountSummary cancel() {
        new CancelWithModalConfirmation(CANCEL).cancel();
        return new AccountSummary();
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public Validation isTextPresent(String text) {
        return new Validation(seleniumCommands.isTextPresent(CONTAINER, text));
    }

    public GPA_QuotePageFactory fillPolicyDetailsFormForExistingAccount() throws Exception {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.withState()
                .withProducerByIndex(1)
                .withProductCode(ThreadLocalObject.getData().get("ProductCode"))
                .submit();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new GPA_QuotePageFactory();
    }

    public QuoteStart withState(String text) {
        this.getForm().getInputByModel("newSubmissionView.state").setValue(text);
    //    this.withEffectiveDate();
        return this;
    }

    public QuoteStart withState() {
        this.getForm().getInputByModel("newSubmissionView.state").setValue(ThreadLocalObject.getData().get("State"));
        if (ThreadLocalObject.getData().get("Scheduled") != null){
            this.withEffectiveDate();
        }
        return this;
    }

    private QuoteStart withEffectiveDate() {
        String futureDate = DateUtil.getFutureDate();
        ThreadLocalObject.getData().putIfAbsent("QuoteEffectiveDate", futureDate);
        this.getForm().getInputByModel("newSubmissionView.effectiveDate").setValue(ThreadLocalObject.getData().get("QuoteEffectiveDate"));
        return this;
    }

    public QuoteStart withProductCode(String value){
        WebElement element = this.getForm().getInputByModel("newSubmissionView.productCode")
                .getControl().getElement();

        Select productSelect = new Select(element);
        seleniumCommands.waitForElementToBeEnabled(element);
        productSelect.selectByValue(value);
        ThreadLocalObject.getData().put("PRODUCT_CODE",value);
        return this;
    }

    public QuoteStart withProducerByIndex(int index) {
        WebElement select = seleniumCommands.findElement(PROD_CODE_DROP_CSS);
//        if(System.getProperty("vm.type").equalsIgnoreCase("aws") && System.getProperty("platform").equalsIgnoreCase("emerald"))	{
//                    index = 1;
//        			withOrganization("Enigma Fire & Casualty");
//        			if(seleniumCommands.isElementPresent(ORG_CSS)) {
//        				index = 5;
//        			}
//        		}
//        else {
        withOrganization("ACV Property Insurance");
//        }
        seleniumCommands.staticWait(2);
        seleniumCommands.waitForElementSelectToHaveMoreValuesThan(select, 1); //Let it load producer codes
        seleniumCommands.selectFromDropdownByIndex(select, index);
        return this;
    }

    public QuoteStart setProducerCode(int index) {
        WebElement select = seleniumCommands.findElement(PROD_CODE_DROP_CSS);
        seleniumCommands.staticWait(2);
        seleniumCommands.waitForElementSelectToHaveMoreValuesThan(select, 1); //Let it load producer codes
        seleniumCommands.selectFromDropdownByIndex(select, index);
        return this;
    }

    public QuoteStart withOrganization(final String orgName) {
        if(seleniumCommands.isElementPresent(ORG_CSS)) {
        	        seleniumCommands.type(seleniumCommands.findElement(ORG_CSS), orgName);
        	 }
        return this;
    }
    
    public void submit() {
        this.getForm().submit();
    }

    public Validation isProductCodeDisabledWithRiskReservedTag() {
        seleniumCommands.logInfo("Validating if Product Code is disabled with tag *RR");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        for (WebElement element: seleniumCommands.findElements(PRODUCT_CODE_DROP_VALUES)){
            if (element.getText().replace(" ","").contains(data.get("ProductCode")+"*RR")){
                new Validation(element.getAttribute("aria-disabled"),"true").shouldBeEqual("Risk reserved vaue is not disabled.");
                return new Validation(true);
            }
        }
        return new Validation(false);
    }

}
