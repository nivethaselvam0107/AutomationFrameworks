package com.guidewire.capabilities.agent.model.page;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import com.guidewire.widgetcomponents.Modal;

public class PolicyChangeSummaryPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();

    By ADD_ACTIVITIE_BTN_CSS = By.cssSelector("[ng-click='showAddActivity()']");

    By ADD_NOTE_BTN_CSS = By.cssSelector("[data-ng-click='showAddNoteForm()']");

    By ADD_DOCUMENT_BTN_CSS = By.cssSelector("[id='uploadButton']");

    By POLICY_CHANGE_HEADER_CSS = By.cssSelector("[class*=gw-titles-title]");

    By POLICY_LINK_CSS = By.cssSelector("div[gw-partial='Item'] a[ui-sref*='policies']");

    By UNDERWRITING_MESSAGE_TITLE_TEXT = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-header]");

    By UNDERWRITING_MESSAGE_LINE1_TEXT = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-line1]");

    By UNDERWRITING_MESSAGE_LINE2_TEXT = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-line2]");

    By UNDERWRITING_MESSAGE_LINE3_TEXT = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-line3]");

    By UNDERWRITING_MESSAGE_LINE4_TEXT = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-line4]");

    By EDIT_POLICY_CHANGE_BUTTON = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-edit-button]");

    By REFER_TO_UNDERWRITER_BUTTON = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-refer-to-underwriter-button]");

    By UNDERWRITING_ISSUE_SHORT_DESCRIPTION = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-short-description]");

    By UNDERWRITING_ISSUE_LONG_DESCRIPTION = By.cssSelector("[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-long-description]");

    By CREATED_DATE = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-created-date]");
    By STATUS = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-status]");
    By POLICY_INCEPTION = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-policy-inception]");
    By POLICY_NUMBER = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-policy-number]");
    By PRODUCER_OF_RECORD = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-produser-of-record]");
    By PRODUCER_OF_SERVICE = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-producer-of-service]");
    By TOTAL_PREMIUM = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-total-premium]");
    By TAXES_AND_FEES = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-taxes-and-fees]");
    By TOTAL_COST = By.cssSelector("[gw-test-gateway-views-endorsment-endorsment-summary-total-cost]");
    By WITHDRAW_BUTTON = By.cssSelector("span[ng-click='withdraw()'], button[on-click*='withdraw']");
    By CONTINUE_POLICY_CHANGE_BUTTON = By.cssSelector("button[on-click*='edit()']");


    private static final String OPEN_ACTIVITIE_TILE_CSS = "[tile-title='Open Activities']";

    private static final String SUMMARY_TILE_CSS = "[tile-title='Summary']";

    private static final String NOTES_TILE_CSS = "[tile-title='Notes']";

    private static final String DOCUMENTS_TILE_CSS = "[tile-title='Documents']";

    private static final String WITHDRAW_CHANGE_BTN_XPATH = "(//*[@ng-if='canWithdraw()'])[1]";

    private static final String CONT_CHANGE_BTN_CSS = "[on-click='continuePolicyChange()']";

    private static final String EDIT_CHANGE_BTN_CSS = "[on-click='edit()']";

    private static final String CREATED_DATE_XPATH = "(//*[@class='gw-policy-summary-item']//div[@class='ng-binding'])[1]";

    private static final String INCEPTION_DATE_XPATH = "(//*[@class='gw-policy-summary-item']//div[@class='ng-binding'])[2]";

    private static final String POLICY_CHANGE_STATUS_XPATH = "(//*[@class='gw-policy-summary-item']//div[@class='ng-binding'])[3]";

    private static final String PROD_RECORD_XPATH = "(//*[@class='gw-summary-container']//div[@class='ng-binding'])[1]";

    private static final String PROD_SERVICE_XPATH = "(//*[@class='gw-summary-container']//div[@class='ng-binding'])[2]";

    private static final String POLICY_CHANGE_TITLE_TEXT = "Policy Change (%s)";

    public PolicyChangeSummaryPage goToOpenActivitiesTile() {
        seleniumCommands.logInfo("Clicking OpenActivities tile.");
        Tiles tiles = new Tiles();
        tiles.isTilePresent("Open Activities");
        tiles.selectByTitle("Open Activities");
        return new PolicyChangeSummaryPage();
    }
    public PolicyChangeSummaryPage goToNoteTile() {
        seleniumCommands.logInfo("Clicking Note tile.");
        new Tiles().selectByTitle("Notes");
        return new PolicyChangeSummaryPage();
    }
    public PolicyChangeSummaryPage goToDocumentsTile() {
        seleniumCommands.logInfo("Clicking Document tile");
        Tiles tiles = new Tiles();
        tiles.isTilePresent("Documents");
        tiles.selectByTitle("Documents");
        return new PolicyChangeSummaryPage();
    }

    public PolicyChangeSummaryPage clickAddActivityBtn() {
        seleniumCommands.logInfo("Clicking add activity button");
        seleniumCommands.waitForElement(ADD_ACTIVITIE_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_ACTIVITIE_BTN_CSS);
        return new PolicyChangeSummaryPage();
    }

    public PolicyChangeSummaryPage clickAddNote() {
        seleniumCommands.logInfo("Clicking add note button");
        seleniumCommands.waitForElement(ADD_NOTE_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_NOTE_BTN_CSS);
        return new PolicyChangeSummaryPage();
    }

    public PolicyChangeSummaryPage clickAddDocument() {
        seleniumCommands.logInfo("Clicking add document button");
        seleniumCommands.waitForElementToBeVisible(ADD_DOCUMENT_BTN_CSS);
        seleniumCommands.clickbyJS(ADD_DOCUMENT_BTN_CSS);
        return new PolicyChangeSummaryPage();
    }

    public String getPolicyChangeJobNumber() {
        seleniumCommands.logInfo("Getting Policy Change job number.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String jobNumber = seleniumCommands.findElement(POLICY_CHANGE_HEADER_CSS).getText().replaceAll("\\D+","");
        data.put("JobNumber",jobNumber);
        return jobNumber;
    }

    public PolicySummary clickPolicyLink() {
        seleniumCommands.logInfo("Clicking policy link.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(POLICY_LINK_CSS).click();
        return new PolicySummary();
    }

    public PolicyChangeSummaryPage withdrawPolicyChange(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        try {
            seleniumCommands.click(seleniumCommands.findElement(By.xpath(WITHDRAW_CHANGE_BTN_XPATH)).findElement(By.xpath(".//a")));
        }catch (Exception e){
            seleniumCommands.click(By.xpath(WITHDRAW_CHANGE_BTN_XPATH));
        }
        new Modal().confirm();
        return this;
    }

    public PolicyChangeSummaryPage continuePolicyChange(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(seleniumCommands.isElementPresent(By.cssSelector(CONT_CHANGE_BTN_CSS))) {
            seleniumCommands.click(By.cssSelector(CONT_CHANGE_BTN_CSS));
        }
        else {
            seleniumCommands.click(By.cssSelector(EDIT_CHANGE_BTN_CSS));
        }
        return this;
    }

    // Validations

    public Validation isEndorsementPageDisplayed(String jobNumber) {
        seleniumCommands.logInfo("Validating if policy change detail page is displayed");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.findElement(POLICY_CHANGE_HEADER_CSS).getText().contains(jobNumber));
    }

    public Validation validatePolicyChangeStatus(String expectedStatus) {
        seleniumCommands.logInfo("Verifying policy change status");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector("[type='policyperiod-status-" + expectedStatus + "']")));
    }
    

    public Validation validatePolicyChangePageWasLoaded() {
        seleniumCommands.logInfo("Verifying policy change page was opened correctly");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.getTextAtLocator(POLICY_CHANGE_HEADER_CSS).equals(String.format(POLICY_CHANGE_TITLE_TEXT,ThreadLocalObject.getData().get("JobNumber"))));
    }

    public void validateHighValueVehicleUnderwritingIssue() {
        seleniumCommands.logInfo("Verifying Underwriting issue components for high value vehicle");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TITLE_TEXT), DataConstant.UNDERWRITING_MESSAGE_POLICY_CHANGE_TITLE_TEXT).shouldBeEqual("Underwriting issue header is incorrect or missing");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE1_TEXT), DataConstant.UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE1_TEXT).shouldBeEqual("Underwriting issue line 1 is incorrect or missing");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE2_TEXT), DataConstant.UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE2_TEXT).shouldBeEqual("Underwriting issue line 2 is incorrect or missing");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE3_TEXT), DataConstant.UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE3_TEXT).shouldBeEqual("Underwriting issue line 3 is incorrect or missing");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE4_TEXT), DataConstant.UNDERWRITING_MESSAGE_POLICY_CHANGE_LINE4_TEXT).shouldBeEqual("Underwriting issue line 4 is incorrect or missing");
        new Validation(seleniumCommands.isElementPresent(EDIT_POLICY_CHANGE_BUTTON)).shouldBeTrue("Edit policy button is missing");
        new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_BUTTON)).shouldBeTrue("Refer to underwriter button is missing");
        new Validation(seleniumCommands.isElementVisible(WITHDRAW_BUTTON)).shouldBeTrue("Withdraw change button is missing");
        String longDescription = "Vehicle " + data.get("VehicleYear") + " " + data.get("Make") + " " + data.get("Model") + " in " + data.get("VehicleState") + " (12345/CA) has a stated value of " + data.get("COST_DESC");
        List<String> uwIssues = new ArrayList<String>();
        		seleniumCommands.findElements(UNDERWRITING_ISSUE_SHORT_DESCRIPTION).stream().forEach( uwissue -> uwIssues.add(uwissue.getText()));
        List<String> uwDesc = new ArrayList<String>();
        	seleniumCommands.findElements(UNDERWRITING_ISSUE_LONG_DESCRIPTION).stream().forEach( desc -> uwDesc.add(desc.getText()));
        new Validation(uwIssues.contains(DataConstant.SD_HIGH_VALUE_VEHICLE_TEXT)).shouldBeTrue("UW issue is missing from " + uwIssues.toString());
        new Validation(uwDesc.contains(longDescription)).shouldBeTrue("UW issue description is missing from " + uwDesc.toString());
    }


    public void validateTilesOnPolicyChangeSummaryPage() {
        seleniumCommands.logInfo("Verifying tiles presense on the page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(OPEN_ACTIVITIE_TILE_CSS))).shouldBeTrue("No Open Activities tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(NOTES_TILE_CSS))).shouldBeTrue("No Notes tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(DOCUMENTS_TILE_CSS))).shouldBeTrue("No Documents tile was found");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(SUMMARY_TILE_CSS))).shouldBeTrue("No Summary tile was found");
    }

    public void validatePolicyChangeSummaryPageComponents() {
        seleniumCommands.logInfo("Verifying presense of policy change summary page elements on the page");
        new Validation(seleniumCommands.isElementPresent(CREATED_DATE)).shouldBeTrue("No created date was found");
        new Validation(seleniumCommands.isElementPresent(STATUS)).shouldBeTrue("No status was found");
        new Validation(seleniumCommands.isElementPresent(POLICY_INCEPTION)).shouldBeTrue("No policy iception was found");
        new Validation(seleniumCommands.isElementPresent(POLICY_NUMBER)).shouldBeTrue("No policy number was found");
        new Validation(seleniumCommands.isElementPresent(PRODUCER_OF_RECORD)).shouldBeTrue("No producer of record was found");
        new Validation(seleniumCommands.isElementPresent(PRODUCER_OF_SERVICE)).shouldBeTrue("No producer of service was found");
        new Validation(seleniumCommands.isElementPresent(TOTAL_PREMIUM)).shouldBeTrue("No total premium was found");
        new Validation(seleniumCommands.isElementPresent(TAXES_AND_FEES)).shouldBeTrue("No taxes and fees was found");
        new Validation(seleniumCommands.isElementPresent(TOTAL_COST)).shouldBeTrue("No total cost was found");
    }

    public void validateWithdrawPolicyChangeButton() {
        seleniumCommands.logInfo("Verifying Withdraw Policy Change Button presence on the page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementVisible(WITHDRAW_BUTTON)).shouldBeTrue("Withdraw change button is missing");
    }

    public void validateContinuePolicyChangeButton() {
        seleniumCommands.logInfo("Verifying Continue Policy Change Button presence on the page");
        new Validation(seleniumCommands.isElementVisible(CONTINUE_POLICY_CHANGE_BUTTON)).shouldBeTrue("Continue Policy Change Button is missing");
    }

    public void validatePolicyChangeJobStatus(String expectedStatus){
        String jsonData = DataFetch.getPolicyChangeData(data.get("POLICY_NUM"),"");
        new Validation(ParseEndorsementData.getJobStatus(jsonData), expectedStatus).shouldBeEqual("The status didn't match backend");
    }
}
