package com.guidewire.capabilities.agent.model.component;

import java.util.List;
import java.util.UUID;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.data.NotesData;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class AddNoteComponent extends CommonScenario
{
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "ng-form[name='newNoteForm']")
    WebElement FORM;

    @FindBy(css = "[model='noteView.topic'] select")
    WebElement NOTE_TOPIC;

    @FindBy(css = "textarea[ng-model='noteView.body.value']")
    WebElement NOTE_BODY;

    @FindBy(css = "div[ui-sref*='.detail.notes']")
    WebElement NOTE_TAB;

    @FindBy(css = "div[class='gw-subject ng-binding']")
    WebElement NOTE_SEARCH_CSS;
    
    @FindBy(css = "[ng-model='notesQuery']")
    WebElement NOTE_SUBJECT;

    @FindBy(css = "button[ng-click='saveNote(activity, newNoteForm)'], button[ng-click='saveNote(newNoteForm)']")
    WebElement SUBMIT;

    @FindBy(css = "button[ng-click='hideAddNoteForm()']")
    WebElement CANCEL;

    @FindBy(xpath = "//div[contains(@class,'gw-modal')]//span")
    static WebElement MODAL;

    @FindBy(css="div.gw-heading.ng-binding")
    WebElement noteCreatedText;

    private static final String ADD_NOTE_BUTTON_CSS = "button[data-ng-click='showAddNoteForm()']";

    private static final String ERROR_MESSAGE_XPATH = "../following-sibling::div";

    private static final String NOTE_SUBJECT_XPATH = "//div[@class='gw-subject ng-binding']";
    
    private static final By NOTE_AUTHOR_CSS = By.cssSelector("[class*='note-data'] [class*='author']");
    
    private static final By NOTE_CREATION_DATE_CSS = By.cssSelector("[class*='note-data'] [class*='create-date']:nth-of-type(2)");
    
    private static final By NOTE_CREATION_TIME_CSS = By.cssSelector("[class*='note-data'] [class*='create-date']:nth-of-type(3)");
    
    private static final By NOTE_SUBJECT_CSS = By.cssSelector("[class*='note'] [class*='subject']");
    
    private static final By NOTE_DESC_CSS = By.cssSelector("[class*='note-data'] [class*='description']");
    
    public AddNoteComponent(){
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    private ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public AddNoteComponent clickAddNote() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.cssSelector(ADD_NOTE_BUTTON_CSS)).click();
        return new AddNoteComponent();
    }

    public AddNoteComponent withTopic() {
        seleniumCommands.selectFromDropdownByIndex(NOTE_TOPIC, Integer.valueOf(data.get("TopicIndex")));
        data.put(NotesData.NOTE_TOPIC.toString(), seleniumCommands.getSelectedOptionFromDropDown(NOTE_TOPIC));
        return this;
    }
    
    public AddNoteComponent withTopic(String topic) {
        seleniumCommands.selectDropDownValueByText(NOTE_TOPIC, topic);
        data.put(NotesData.NOTE_TOPIC.toString(), topic);

        return this;
    }

    public AddNoteComponent withSubject(){
        String uuid = UUID.randomUUID().toString();
        data.put("NoteSubject", uuid);
        this.getForm().getInputByModel("noteView.subject").setValue(uuid);
        return this;
    }
    
    public AddNoteComponent withSubject(String subject){
    		data.put(NotesData.NOTE_SUBJECT.toString(), subject);
        this.getForm().getInputByModel("noteView.subject").setValue(subject);
        return this;
    }

    public AddNoteComponent withNoteText() {
        NOTE_BODY.sendKeys(data.get("NoteText"));
        return this;
    }
    
    public AddNoteComponent addGeneralNote(String subject) {
       this.clickAddNote()
       .withTopic("General")
       .withSubject(subject)
       .withNoteText(subject)
       .submit();
        return this;
    }

    public AddNoteComponent addNoteMandatoryFields() {
        seleniumCommands.logInfo("Filling the required fields of adding note form.");
        String text = "General";
        this.clickAddNote()
                .withTopic(text)
                .withSubject(text)
                .withNoteText(text);
        return this;
    }

    public AddNoteComponent addBasicNote() {
        seleniumCommands.logInfo("Adding a note.");
        this.addNoteMandatoryFields()
                .submit();
        return this;
    }

    public AddNoteComponent withNoteText(String text) {
    		data.put(NotesData.NOTE_BODY.toString(), text);
        NOTE_BODY.sendKeys(text);
        return this;
    }

    public AddNoteComponent submit() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        SUBMIT.click();
        return this;
    }

    public AddNoteComponent cancelAddingNote() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        CANCEL.click();
        return this;
    }

    public AddNoteComponent saveNoteCounter(){
        data.put("NoteCounter", seleniumCommands.getAttributeValueAtLocator(NOTE_TAB,"tile-value"));
        return this;
    }

    public Validation isNodeAddedModalDisplayed() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(noteCreatedText.getText(), DataConstant.NOTE_CREATED_MSG);
    }


    public Validation isNoteAdded() {
        return this.isNoteListed();
    }
    
    public Validation isNoteListed(String subject) {
    		seleniumCommands.logInfo("Validating if note is listed on page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<WebElement> subjectList = seleniumCommands.findElements(NOTE_SUBJECT_CSS);
        seleniumCommands.logInfo("Size" + subjectList.size());
        return new Validation(subjectList.stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).equals(subject)).findFirst().get().isDisplayed());
    }
    
    public Validation isNoteListed() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<WebElement> subjectList = seleniumCommands.findElements(NOTE_SUBJECT_CSS);
        return new Validation(subjectList.stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).equals(data.get("NoteSubject"))).findFirst().isPresent());
    }

    public Validation areRequiredFieldsMarked() {
    	seleniumCommands.click(NOTE_TOPIC);
    	seleniumCommands.click(NOTE_TOPIC);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(NOTE_TOPIC), DataConstant.MANDATORY_ERROR_MSG);
        new Validation(seleniumCommands.getErrorMessageForTxtBox( this.getForm().getInputByModel("noteView.subject").getControl().getElement()), DataConstant.MANDATORY_ERROR_MSG);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(NOTE_BODY), DataConstant.MANDATORY_ERROR_MSG);
        return new Validation(true);
    }
    
    public Validation validatedAddedNoteUIComponant() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(NOTE_AUTHOR_CSS)).shouldBeTrue("Note author is not present");
        new Validation(seleniumCommands.isElementPresent(NOTE_CREATION_DATE_CSS)).shouldBeTrue("Note creation date is not present");
        new Validation(seleniumCommands.isElementPresent(NOTE_CREATION_TIME_CSS)).shouldBeTrue("Note creation time is not present");
        new Validation(seleniumCommands.isElementPresent(NOTE_SUBJECT_CSS)).shouldBeTrue("Note subject is not present");
        new Validation(seleniumCommands.isElementPresent(NOTE_DESC_CSS)).shouldBeTrue("Note description is not present");
        return new Validation(true);
    }

    public Validation validateNoteUIComponant() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(ADD_NOTE_BUTTON_CSS))).shouldBeTrue("Add note button is not displayed");
        new Validation(seleniumCommands.isElementPresent(NOTE_SEARCH_CSS)).shouldBeTrue("Note search textbox is not displayed");
        return new Validation(true);
    }
}
