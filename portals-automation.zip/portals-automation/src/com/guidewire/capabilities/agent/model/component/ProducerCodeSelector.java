package com.guidewire.capabilities.agent.model.component;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.portals.qnb.pages.CommonPage;
import com.guidewire.widgetcomponents.Select;

public class ProducerCodeSelector extends CommonPage{
    
    @FindBy(css = "select[name='selectedProducerCode']")
    WebElement PROD_CODE_CSS;
    
    public ProducerCodeSelector select(String producerCode) {
        seleniumCommands.waitForElementToBeVisible(PROD_CODE_CSS);
        seleniumCommands.selectDropDownValueByText(PROD_CODE_CSS, producerCode);
        return this;
    }

    public ProducerCodeSelector selectEverything() {
         new Select(PROD_CODE_CSS).setValue("Everything");
         return this;
    }
}
