package com.guidewire.capabilities.agent.model.page;

import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.CancelWithModalConfirmation;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class AccountCreate {
    public static final String ADDRESS_ADDRESS_LINE1 = "address.addressLine1";
    public static final String ADDRESS_CITY = "address.city";
    public static final String ADDRESS_POSTAL_CODE = "address.postalCode";
    public static final String ADDRESS_STATE = "address.state";
    public static final String PRODUCER_CODE = "producerCode";
    public static final String EMAIL = "emailAddress1";

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = ".gw-container-form .gw-page-title[ng-hide='isAnExistingAccount']") //TODO: this selector is crap
    WebElement TITLE;

    @FindBy(css = "ng-form[name='newAccountForm']")
    WebElement FORM;

    @FindBy(css = "button[ng-click='setCancelState()']")
    static WebElement CANCEL_BUTTON;

    @FindBy(xpath = "//select[@name='ProducerCode'][@aria-disabled='false'] | //select[@name='ProducerCode']")
    static WebElement SELECT_PRODUCER_CODE;
    
    private static final By ORG_CSS = By.cssSelector("[result='selectedOrganizationAccountVM.value'] textarea");
    
    private static final By ORG_VALUES = By.cssSelector("[result='selectedOrganizationAccountVM.value'] ul[aria-hidden='false'] li");

    public AccountCreate() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(seleniumCommands.findElement(By.cssSelector("ng-form")));
    }

    public AccountCreate withAddressLine1(String text) {
        getAddresLine1Input().setValue(text);
        return this;
    }

    public AccountCreate withCity(String text) {
        getCityInput().setValue(text);
        return this;
    }

    public AccountCreate withZip(String text) {
        getZipCodeInput().setValue(text);
        return this;
    }

    public AccountCreate withState(String text) {
        getStateInput().setValue(text);
        return this;
    }

    public AccountCreate withEmail(String email) {
        getEmailInput().setValue(email);
        return this;
    }

    public AccountCreate withProducerByIndex(int index) {
  //      WebElement select = getProducerCodeInput().getControl().getElement();
        WebElement select = SELECT_PRODUCER_CODE;
        if(System.getProperty("vm.type").equalsIgnoreCase("aws") && System.getProperty("platform").equalsIgnoreCase("emerald"))	{
        	//		index = 3;
                    index = 1;
        			withOrganization("Enigma Fire & Casualty");
        	} else {
        		withOrganization("ACV Property Insurance");
        }
     /*   seleniumCommands.waitForElementSelectToHaveMoreValuesThan(select, 1); //Let it load producer codes
        seleniumCommands.selectFromDropdownByIndex(select, index);
     */

     String selectValue="";

     if(index==1){
         selectValue = "301-008578";
     }
        seleniumCommands.selectFromDropdownByIndex(select, index);
        return this;
    }
    
    public AccountCreate withOrganization(final String orgName) {
        if(seleniumCommands.isElementPresent(ORG_CSS)) {
        		seleniumCommands.type(seleniumCommands.findElement(ORG_CSS), orgName);
        	 }
        return this;
    }

    public List<ViewModelInput> getRequiredFields() {
        return Arrays.asList(
                getAddresLine1Input(),
                getCityInput(),
                getZipCodeInput(),
                getStateInput(),
                getProducerCodeInput()
        );
    }

    public ViewModelInput getProducerCodeInput() {
        return this.getForm().getInputByModel(PRODUCER_CODE);
    }

    public ViewModelInput getStateInput() {
        return this.getForm().getInputByModel(ADDRESS_STATE);
    }

    public ViewModelInput getAddresLine1Input() {
        return this.getForm().getInputByModel(ADDRESS_ADDRESS_LINE1);
    }

    public ViewModelInput getZipCodeInput() {
        return this.getForm().getInputByModel(ADDRESS_POSTAL_CODE);
    }

    public ViewModelInput getEmailInput() {
        return this.getForm().getInputByModel(EMAIL);
    }

    public ViewModelInput getCityInput() {
        return this.getForm().getInputByModel(ADDRESS_CITY);
    }

    public AccountCreate trySubmit() {
        this.getForm().submit();
        return this;
    }

    public QuoteStart submit() {
        this.getForm().submit();
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("[name='newAccountForm']"));
        return new QuoteStart();
    }

    public void cancel() {
        new CancelWithModalConfirmation(seleniumCommands.findElement(By.cssSelector("button[ng-click='setCancelState()']"))).cancel();
    }
}
