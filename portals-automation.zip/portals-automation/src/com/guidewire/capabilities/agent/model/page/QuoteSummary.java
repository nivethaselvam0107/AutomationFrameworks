package com.guidewire.capabilities.agent.model.page;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.guidewire.data.PolicyData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Modal;

public class QuoteSummary {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    public HashMap<String, String> data = ThreadLocalObject.getData();

    @FindBy(css = "h1[class='gw-titles-title ng-scope ng-isolate-scope']")
    WebElement PAGE_TITLE;

    @FindBy(css = "button[primary]")
    WebElement CONTINUE_QUOTE;

    @FindBy(css = ".gw-agent-page")
    WebElement PAGE_CONTAINER;

    @FindBy(css = "div[tile-title='Open Activities']")
    WebElement OPEN_ACTIVITIES_VALUE;

    @FindBy(css = "h2[class='gw-titles-heading ng-scope ng-isolate-scope']")
    WebElement UNDERWRITING_MESSAGE_TITLE;

    @FindBy(css = "h2[class='gw-titles-heading ng-scope ng-isolate-scope']")
    WebElement QUOTE_WITHDRAWN_MESSAGE_TITLE;

    @FindBy(css = "div[gw-test-gateway-jobunderwritingissuesdirective-job-underwriting-issues-line1]")
    WebElement UNDERWRITING_MESSAGE_LINE1;

    @FindBy(css = "ul[class='ng-scope'] li:nth-of-type(1)")
    WebElement UNDERWRITING_MESSAGE_LINE2;

    @FindBy(css = "ul[class='ng-scope'] li:nth-of-type(2)")
    WebElement UNDERWRITING_MESSAGE_LINE3;

    @FindBy(css = "div[class='gw-referral-info'] p[class='ng-binding']")
    WebElement REFER_TO_UNDERWRITER_MESSAGE;

    @FindBy(css = "button[ng-click='referQuoteToUnderWriter()']")
    WebElement REFER_TO_UNDERWRITER_CONFIRMATION_BUTTON;

    @FindBy(css = "button[ng-click='closeReferToUWForm()']")
    WebElement REFER_TO_UNDERWRITER_CANCELATION_BUTTON;

    @FindBy(css = "textarea[ng-model='noteForUW.note']")
    WebElement REFER_TO_UNDERWRITER_NOTE;

    @FindBy(css = "ul[class='ng-scope'] li:nth-of-type(3)")
    WebElement UNDERWRITING_MESSAGE_LINE4;

    @FindBy(css = "button[on-click='edit()']")
    WebElement EDIT_QUOTE_BUTTON;

    @FindBy(css = "button[class='ng-scope ng-isolate-scope gw-btn-primary'] span[class='ng-binding ng-scope']")
    WebElement REFER_TO_UNDERWRITER_BUTTON;

    @FindBy(css = "div[class='gw-tile ng-isolate-scope']")
    WebElement OPEN_ACTIVITIES;

    @FindBy(css = "div[tile-title='Notes']")
    WebElement NOTE_BUTTON;

    @FindBy(css = "div[tile-title='Summary']")
    WebElement SUMMARY_BUTTON;

    @FindBy(css = "div[tile-title='Documents']")
    WebElement DOCUMENTS_BUTTON;

    @FindBy(css = "div:not([aria-hidden=true])[type=warning] button[on-click='edit()'], button[on-click='continueSubmission()']")
    WebElement EDIT_BUTTON;

    @FindBy(css = "button[on-click='withdrawSubmission()'], button[on-click='withdraw()']")
    WebElement WITHDRAW_QUOTE_BUTTON;

    final String ACTIVITIES_TILE_SELECTOR = ".gw-tile[tile-title='Open Activities']";

    @FindBy(css = ACTIVITIES_TILE_SELECTOR)
    WebElement ACTIVITIES_TILE;
    
    @FindBy(css = "button[ng-click='showAddActivity()']")
    WebElement ADD_ACTIVITY_BUTTON;

    String TABLE_ROWS ="//table[@class='gw-table']/tbody/tr";
    
    By editButton = By.cssSelector("div:not([aria-hidden=true])[type=warning] button[on-click='edit()']");

    String TABLE_HEADERS = "//table[@class='gw-table']/thead/tr[1]";

    By QUOTE_DATA = By.xpath("//div[@class='gw-emphasis ng-binding']/following-sibling::div");

    By UNDERWRITING_ISSUES_TITLE = By.xpath("//span[contains(text(),'Underwriting Issues')])");
    
    List<String> PLAN_LIST = Arrays.asList("CUSTOM", "PREMIUM PROGRAM", "STANDARD PROGRAM", "BASIC PROGRAM");

    private static final String PAGE_TITLE_TEXT = "Quote (%s)";

    public void validateQuotePageComponents(){
        Tiles tiles = new Tiles();
        tiles.isTilePresent("Open Activities").shouldBeTrue("Open Activities button is not presented");
        tiles.isTilePresent("Notes").shouldBeTrue("Notes button is not presented");
        tiles.isTilePresent("Summary").shouldBeTrue("Summary is not presented");
        tiles.isTilePresent("Documents").shouldBeTrue("Documents is not presented");

        new Validation(seleniumCommands.isElementPresent(WITHDRAW_QUOTE_BUTTON)).shouldBeTrue("Withdraw quote link is not presented");
        new Validation(seleniumCommands.isElementPresent(EDIT_BUTTON)).shouldBeTrue("Documents is not presented");

        this.validateQuoteDataExistance().shouldBeTrue("Some quote data is missing");

        new Validation(seleniumCommands.isElementPresent(By.xpath(TABLE_HEADERS))).shouldBeTrue("Underwriting issues table is not presented");
    }

    public Validation validateQuoteDataExistance(){
        List<WebElement> quoteDataElements= seleniumCommands.findElements(QUOTE_DATA);
        if (quoteDataElements.size()!=5)
            return new Validation(false);
        for(WebElement el:quoteDataElements){
            if (el.getText().isEmpty())
                return new Validation(false);
        }
        return new Validation(true);
    }

    public QuoteSummary() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(PAGE_TITLE);

        //Only consider page loaded when data inside it is loaded.
        //When data is loaded, there's account id in the title, so wait for that.
        seleniumCommands.waitForElementToContainText(PAGE_TITLE, this.getQuoteIDFromURL());

        Modal.waitHidden(); //Wait for loader to hide
    }

    public String getQuoteIDFromURL() {
        Matcher matcher = Pattern.compile("/quotes/(.+)/summary").matcher(seleniumCommands.getCurrentUrl().getRef());
        if (!matcher.find()) {
            throw new Error("URL didn't match quote page");
        }

        return matcher.group(1);
    }

    public QuoteSummary goToActivitiesTile(){
        new Tiles().selectByTitle("Open Activities");
        Modal.waitHidden();
        return this;
    }

    public AccountSummary goToAccountPage(){
        seleniumCommands.logInfo("Closing alert");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        By accountNameLink = By.linkText(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NAME.toString()));
        seleniumCommands.waitForElementToBePresent(accountNameLink);
        seleniumCommands.click(accountNameLink);
        return new AccountSummary();
    }

    public void continueQuote() {
		seleniumCommands.waitForElementToBeVisible(CONTINUE_QUOTE);
		if(seleniumCommands.isElementPresent(editButton))
		{
			seleniumCommands.clickbyJS(editButton);
		}
		else
		{
			seleniumCommands.clickbyJS(CONTINUE_QUOTE);
		}
}

    public AddNoteComponent clickNotes() {
        new Tiles().selectByTitle("Notes");
        return new AddNoteComponent();
    }

    public QuoteSummary showUnderwritingIssues() {
        new Tiles().selectByTitle("Open UW Issues");
        Modal.waitHidden(); //Wait for loader to hide
        return this;
    }

    public QuoteSummary clickConfirm() {
        seleniumCommands.clickbyJS(REFER_TO_UNDERWRITER_CONFIRMATION_BUTTON);
        return this;

    }

    public QuoteSummary clickWithdraw() {
        seleniumCommands.waitForElementToBePresent(WITHDRAW_QUOTE_BUTTON);
        seleniumCommands.clickbyJS(WITHDRAW_QUOTE_BUTTON);
        new AlertHandler().closeAlertOnly();
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
     //   return new QuoteSummary();
        return this;
    }

    public QuoteOpenActivities clickOpenActivities() {
        int i=0;
//        while((!seleniumCommands.getAttributeValueAtLocator(OPEN_ACTIVITIES_VALUE, "tile-value").contains("1")) || (i<50)){
//            i++;
//        }
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Tiles().selectByTitle("Open Activities");
        return new QuoteOpenActivities();
    }

    public QuoteSummary clickCancel() {
        seleniumCommands.clickbyJS(REFER_TO_UNDERWRITER_CANCELATION_BUTTON);
        return this;
    }

    public QuoteSummary addNote() {
        seleniumCommands.waitForElementToBePresent(REFER_TO_UNDERWRITER_NOTE);
        seleniumCommands.getElements(REFER_TO_UNDERWRITER_NOTE).get(0).sendKeys(DataConstant.NOTE_TEXT);
        return this;
    }
    
    public QuoteSummary clickAddActivityButton() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(ADD_ACTIVITY_BUTTON);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
    }
   
    //Validation

    public Validation isUWIssueShown(String uwIssueShortDescription) {
        return new Validation(seleniumCommands.isTextPresent(PAGE_CONTAINER, uwIssueShortDescription));
    }

    public Validation validateQuotePageWasLoaded(String jobNumber) {
        return new Validation(seleniumCommands.getTextAtLocator(PAGE_TITLE).equals(String.format(PAGE_TITLE_TEXT,jobNumber)));
    }

    public Validation validationUnderwritingMessage() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TITLE), DataConstant.UNDERWRITING_MESSAGE_TITLE_TEXT).shouldBeEqual("Underwriting message is incorrect");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE1), DataConstant.UNDERWRITING_MESSAGE_LINE1_TEXT).shouldBeEqual("Underwriting message line 1 is incorrect");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE2), DataConstant.UNDERWRITING_MESSAGE_LINE2_TEXT).shouldBeEqual("Underwriting message line 2 is incorrect");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE3), DataConstant.UNDERWRITING_MESSAGE_LINE3_TEXT).shouldBeEqual("Underwriting message line 3 is incorrect");
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_LINE4), DataConstant.UNDERWRITING_MESSAGE_LINE4_TEXT).shouldBeEqual("Underwriting message line 4 is incorrect");

        new Validation(seleniumCommands.isElementPresent(EDIT_QUOTE_BUTTON)).shouldBeTrue("Edit quote button is not presented");
        new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_BUTTON)).shouldBeTrue("Refer to Underwriter button is not presented");

        return new Validation(true);
    }

    public Validation validationReferToUnderwriteForm() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(REFER_TO_UNDERWRITER_MESSAGE), DataConstant.REFER_TO_UNDERWRITER_TEXT).shouldBeEqual("Refer to Underwriter is incorrect");
        new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_CONFIRMATION_BUTTON)).shouldBeTrue("Confirm button is not presented");
        new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_CANCELATION_BUTTON)).shouldBeTrue("Cancel button is not presented");
        new Validation(seleniumCommands.isElementPresent(REFER_TO_UNDERWRITER_NOTE)).shouldBeTrue("Note area is not presented");
        return new Validation(true);
    }

    public Validation validationReferedToUnderwriteForReviewMessage() {
        new Validation(seleniumCommands.getTextAtLocator(UNDERWRITING_MESSAGE_TITLE), DataConstant.REFERED_TO_UNDERWRITER_FOR_REVIEW_TEXT).shouldBeEqual("Refered to Underwriter for review message is incorrect");
        new Validation(seleniumCommands.isElementPresent(WITHDRAW_QUOTE_BUTTON)).shouldBeTrue("Withdrawn button is not present");
        return new Validation(true);
    }

    public QuoteSummary clickReferToUnderwriter() {
        seleniumCommands.clickbyJS(REFER_TO_UNDERWRITER_BUTTON);
        return this;
    }

    public Validation validationUnderwritingIssues(String shortDescription, Boolean bindBlocked) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        int table_size= seleniumCommands.findElements(By.xpath(TABLE_ROWS)).size();
        for (int i=1; i<=table_size; i++){
            String final_xpath_short_description= TABLE_ROWS + "[" + i + "]/td[1]";
            String shortDescriptionText=seleniumCommands.findElement( By.xpath(final_xpath_short_description)).getText();
            if(shortDescriptionText.equals(shortDescription)){
                if(bindBlocked) {
                    String final_xpath_basic_prog = TABLE_ROWS + "[" + i + "]/td[5]";
                    new Validation(seleniumCommands.findElement(By.xpath(final_xpath_basic_prog)).getText(), DataConstant.BASIC_PROGRAM_TEXT).shouldBeEqual("Basic Program status is incorrect");
                }
                return new Validation(true);
            }
        }
        return new Validation(false);
    }

    public Validation validationDisqualification() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        int table_size= seleniumCommands.findElements(By.xpath(TABLE_ROWS)).size();
        for (int i=1; i<=table_size; i++){
            String final_xpath_short_description= TABLE_ROWS + "[" + i + "]/td[1]";
            String shortDescriptionText=seleniumCommands.findElement( By.xpath(final_xpath_short_description)).getText();
            if(shortDescriptionText.equals(DataConstant.DISQUALIFICATION)){
                    String final_xpath_basic_prog = TABLE_ROWS + "[" + i + "]/td[3]";
                    new Validation(seleniumCommands.findElement(By.xpath(final_xpath_basic_prog)).getText(),DataConstant.CUSTOM_STATUS_TEXT).shouldBeEqual("Basic Program status is incorrect");
                return new Validation(true);
            }
        }
        return new Validation(false);
    }

    public Validation validationUnderwritingIssuesColumns() {
        new Validation(seleniumCommands.findElement(By.xpath(TABLE_HEADERS + "/th[1]") ).getText(), "SHORT DESCRIPTION" ).shouldBeEqual("Column name is incorrect");
        new Validation(seleniumCommands.findElement(By.xpath(TABLE_HEADERS + "/th[2]") ).getText(), "LONG DESCRIPTION" ).shouldBeEqual("Column name is incorrect");
        for(int i=3; i<=6; i++)
        {
        		String planNameFromUI = seleniumCommands.getTextAtLocator(By.xpath(TABLE_HEADERS + "/th[COL]".replaceAll("COL", i+"")));
        		new Validation(PLAN_LIST.contains(planNameFromUI)).shouldBeTrue("Plan name is not matched for - " + planNameFromUI );
        }
        
        return new Validation(false);
    }

    public Validation validationQuoteWithdrawn() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(QUOTE_WITHDRAWN_MESSAGE_TITLE), DataConstant.QUOTE_WITHDRAWN_TITLE_TEXT).shouldBeEqual("Underwriting message is incorrect");
        String status= seleniumCommands.findElement(By.xpath("//*[contains(text(), 'Status')]/following-sibling::div")).getText();
        new Validation(status, "Withdrawn" ).shouldBeEqual("Status of quote is incorrect");
         return new Validation(false);
    }
    
}
