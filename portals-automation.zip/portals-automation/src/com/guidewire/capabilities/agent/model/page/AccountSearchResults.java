package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;

public class AccountSearchResults {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "#possible-account-matches .gw-page-title")
    WebElement TITLE;

    @FindBy(css = "button[type='submit']") //TODO: brittle selector
    WebElement CREATE_NEW_ACCOUNT;

    @FindBy(css = ".gw-table")
    WebElement SEARCH_RESULTS_TABLE;

    public AccountSearchResults() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);
    }

    public AccountCreate createNewAccount() {
        seleniumCommands.click(CREATE_NEW_ACCOUNT);
        return new AccountCreate();
    }

    public QuoteStart useExistingAccountWithAccountNumber(String accountNumber){
        if (accountNumber.contains("'"))
            accountNumber=accountNumber.split("'")[0];
        SEARCH_RESULTS_TABLE.findElement(By.xpath("//td[contains(., '" + accountNumber + "')]/..//a['ng-click']")).click();
        return new QuoteStart();
    }
}