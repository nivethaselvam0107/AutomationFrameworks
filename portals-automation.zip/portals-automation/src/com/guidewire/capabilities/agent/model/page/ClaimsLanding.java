package com.guidewire.capabilities.agent.model.page;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.PolicyDetailPage;
import com.guidewire.widgetcomponents.table.Table;


/**
 * @author Darya Fedo
 */
public class ClaimsLanding {
    private final NavBar navBar;
    private final Tiles tiles;
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "div.gw-row-layout__item")
     WebElement TITLE;

    @FindBy(css = "table[list='pageListData.items']")
    WebElement PAGINATED_TABLE;

    @FindBy(css = "div[tile-title='Recently Viewed'][class*=active]")
    WebElement DEFAULT_TILE;

    @FindBy(css = "div[tile-title='Recently Created']")
    WebElement RECENTLY_CREATED;

    @FindBy(css = "div[tile-title='Recently Viewed']")
    WebElement RECENTLY_VIEWED;

    @FindBy(css = "div[tile-title='Open Claims']")
    WebElement OPEN_CLAIMS;

    @FindBy(css = "div[tile-title='Closed Claims']")
    WebElement CLOSE_CLAIMS;

    @FindBy(css = "table[class='gw-table ng-scope']")
    WebElement RECENTLY_VIEWED_TABLE;

    By CLAIM_STATUS = By.cssSelector("[title='Status']");

    private static Set<String> STATUS_VALUES = new HashSet(Arrays.asList("Open", "Draft" ));

    public ClaimsLanding() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);

        this.navBar = new NavBar();
        this.navBar.isClaimsLandingSelected().shouldBeTrue();

        this.tiles = new Tiles();
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("[name='selectedProducerCode']"));
        seleniumCommands.waitForElementSelectToHaveMoreValuesThan(seleniumCommands.findElement(By.cssSelector("[name=\"selectedProducerCode\"]")), 1);
    }

    public Table getTable() {
        return new Table(PAGINATED_TABLE);
    }

    public Validation checkTitle(){
        return new Validation(this.TITLE.getText(), "Claims");
    }

    public AccountSummary clickAccountName(String accountName){
        this.showRecentlyCreated();
        seleniumCommands.waitForElementToBeVisible(By.linkText(accountName));
        seleniumCommands.clickbyJS(By.linkText(accountName));
        return new AccountSummary();
    }

    public PolicyDetailPage clickPolicyNumber(String policyNumber){
        this.showRecentlyCreated();
        seleniumCommands.waitForElementToBeVisible(By.linkText(policyNumber));
        seleniumCommands.clickbyJS(By.linkText(policyNumber));
        return new PolicyDetailPage();
    }

    public ClaimSummaryPage clickClaimNumber(String claimNumber){
        this.showRecentlyCreated();
        seleniumCommands.waitForElementToBeVisible(By.linkText(claimNumber));
        seleniumCommands.clickbyJS(By.linkText(claimNumber));
        return new ClaimSummaryPage();
    }

    public ClaimsLanding showRecentlyCreated() {
        new Tiles().selectByTitle("Recently Created");
        return this;
    }

    public ClaimsLanding showOpenClaims() {
        new Tiles().selectByTitle("Open Claims");
        return this;
    }

    public ClaimsLanding showCloseClaims() {
        new Tiles().selectByTitle("Closed Claims");
        return this;
    }

    public ClaimsLanding showRecentlyViewed() {
        new Tiles().selectByTitle("Recently Viewed");
        return this;
    }
    public Validation checkDefaultTile(){
        String tileName = seleniumCommands.getTextAtLocator(this.DEFAULT_TILE.findElement(By.cssSelector("div[class*='title']")));
        return new Validation(tileName,"RECENTLY VIEWED");
    }

    public Validation validateClaimIsPresent(String claimNum){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(RECENTLY_VIEWED_TABLE);
        return new Validation(seleniumCommands.isElementPresent(By.linkText(claimNum)));
    }

    public Validation validateOpenClaims(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        Optional<WebElement> result = seleniumCommands.findElements(CLAIM_STATUS)
                .stream()
                .filter(s -> !STATUS_VALUES.contains(s.getText()))
                .findFirst();
        return new Validation(!result.isPresent());
    }

    public Validation validateCloseClaims(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        Optional<WebElement> result = seleniumCommands.findElements(CLAIM_STATUS)
                .stream()
                .filter(s -> STATUS_VALUES.contains(s.getText()))
                .findFirst();
        return new Validation(!result.isPresent());
    }
}