package com.guidewire.capabilities.agent.model.component;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.guidewire.capabilities.agent.data.AgentUserName;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class ActivitiesScheduleComponent {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    Logger LOGGER = Logger.getLogger(this.getClass().getName());

    @FindBy(css = ".gw-activities-schedule")
    WebElement ACTIVITIES_SCHEDULE_COMPONENT;

    @FindBy(css = ".gw-activity-summary")
    WebElement FIRST_ACTIVITY_IN_SCHEDULE;
    
    String activityRow = "[class='gw-activity-summary']:nth-of-type(COUNT)";

    @FindBy(css = ".gw-activity-detail-wrapper")
    WebElement FIRST_ACTIVITY_SUMMARY;

    @FindBy(css = "[ng-model = 'activityTableConfig.actStatus']")
    WebElement ACTIVITY_FILTER_CSS;
    
    @FindBy(css = "[ng-model = 'activityTableConfig.search']")
    WebElement ACTIVITY_SEARCH_CSS;
    
    @FindBy(css = "[ng-model = 'activityTableConfig.search']")
    WebElement ADD_ACTIVITY_BUTTON_CSS;

 //   By ACTVITY_LISTED_CSS = By.cssSelector("div[ng-repeat*='activity']");

    @FindBy(css = "[ng-repeat*='activity']")
    WebElement ACTVITY_LISTED_CSS;

    By DUE_TODAY_SECTION = By.cssSelector("div[ng-show*='activitiesToday']");


    public ActivitiesScheduleComponent(){
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBePresent(this.ACTIVITIES_SCHEDULE_COMPONENT);
    }

    public ActivityComponent clickOnFirstActivity(){
    		seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(this.FIRST_ACTIVITY_IN_SCHEDULE);
        FIRST_ACTIVITY_IN_SCHEDULE.click();
        return new ActivityComponent(FIRST_ACTIVITY_IN_SCHEDULE);
    }
    
    public ActivityComponent clickOnFirstNonCompleteActivityUserOwns(){
        seleniumCommands.waitForElementToBeVisible(this.FIRST_ACTIVITY_IN_SCHEDULE);
        for(WebElement element : seleniumCommands.findElements(By.cssSelector("[class='gw-completed']")))
        {
        	String assignee = element.findElement(By.xpath("./preceding-sibling::div[@class='gw-assignee']//div[@class='gw-assigned-to-text ng-binding']")).getText();
        	System.out.println(assignee);
        	if(assignee.equalsIgnoreCase(AgentUserName.getValueByUname(ThreadLocalObject.getData().get("USER"))))
        	{
        		if(element.findElement(By.xpath("./span")).getAttribute("aria-hidden").equals("true"))
        		{
        			WebElement activityRow = element.findElement(By.xpath("./.."));
        			seleniumCommands.clickbyJS(activityRow);      		   
        			System.out.println(activityRow.getText());
        			return new ActivityComponent(activityRow);
        		}
        }
        }
       return null;
    }

    public int getListedActivityCount() {
	return this.getAllListedActivities().size();
    }
    
	public List<WebElement> getAllListedActivities() {
		LOGGER.info("Finding all the activity componants");
		seleniumCommands.waitForElementToBeVisible(ACTVITY_LISTED_CSS);
		LOGGER.info("Activity count on the page :" + seleniumCommands.getElements(ACTVITY_LISTED_CSS));
		return seleniumCommands.getElements(ACTVITY_LISTED_CSS);
	}

    public void reassignFirstActivity() {}

    public ActivityComponent getActivityBySubject(String uuid) {
       seleniumCommands.waitForLoaderToDisappearFromPage();
        WebElement activity = ACTIVITIES_SCHEDULE_COMPONENT.findElement(By.xpath("//div[@class='gw-activity-summary' and child::div[@class='gw-subject' and contains(.,'"+ uuid +"')]]"));
       return new ActivityComponent(activity);
    }
    
    public ActivitiesScheduleComponent setActivityFilter(String filterOption) 
    {
    		seleniumCommands.selectDropDownValueByText(ACTIVITY_FILTER_CSS, filterOption);
    		//seleniumCommands.waitForElementToBeVisible(By.cssSelector(".gw-activities-schedule"));
    		return this;
    }
    
    //Validation
    public void validateActivityScheduleUIComponant() 
    {
    		new Validation(seleniumCommands.isElementPresent(ACTIVITY_FILTER_CSS)).shouldBeTrue("Activity filter is not present on UI");
    		new Validation(seleniumCommands.isElementPresent(ACTIVITY_SEARCH_CSS)).shouldBeTrue("Activity search is not present on UI");
    		new Validation(seleniumCommands.isElementPresent(ADD_ACTIVITY_BUTTON_CSS)).shouldBeTrue("Add Activity button is not present on UI");
            validateActivityFilterValues();
    }
    
    public void validateAllActivityScheduleUIComponents()
    {
        seleniumCommands.logInfo("Validating activities schedule ui components");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        validateActivityScheduleUIComponant();
        validateActivityFilterValues();
        seleniumCommands.waitForElement(DUE_TODAY_SECTION);
        clickOnFirstActivity().validatedActivityRowUIComponant().shouldBeTrue("Some of activity row components are not presented properly/");
    }

    public void validateActivityFilterValues()
    {
        seleniumCommands.logInfo("Validating Activity filter values");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<String> actualProductList = Arrays.asList("All Completed", "All Open", "Open, Assigned to me", "Overdue Only" );
        List<String> dropDownlistOptions = seleniumCommands.getAllOptionsFromDropDown(ACTIVITY_FILTER_CSS);
        Collections.sort(dropDownlistOptions);
        new Validation(dropDownlistOptions, actualProductList).shouldBeEqual("Filter options are not listed correctly");
    }

}
