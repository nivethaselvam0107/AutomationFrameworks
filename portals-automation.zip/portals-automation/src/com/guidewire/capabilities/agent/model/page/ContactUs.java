package com.guidewire.capabilities.agent.model.page;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;

public class ContactUs {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = ".gw-page-title")
    WebElement TITLE;

    @FindBy(css = ".gw-error-contact")
    WebElement ERROR_SECTION;

    public ContactUs() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);

        seleniumCommands.waitForElementToBeVisible(TITLE);
        seleniumCommands.waitForElementToBeVisible(ERROR_SECTION);
    }

    public QuoteSummary clickQuoteReference() {
        //When data is loaded, there's a quote id in the text, so wait for that.
//        String quoteID = this.quoteIdFromUrl();
        String quoteID = seleniumCommands.getTextAtLocator(By.cssSelector("[class='gw-control-group gw-reference-number'] a"));
        seleniumCommands.waitForElementToContainText(ERROR_SECTION, quoteID);
        seleniumCommands.click(By.linkText(quoteID));
       // ERROR_SECTION.findElement(By.xpath(String.format("//a[contains(text(), '%s')]", quoteID))).click();

        return new QuoteSummary();
    }

    public String quoteIdFromUrl() {
        Matcher matcher = Pattern.compile("\\d+").matcher(seleniumCommands.getCurrentUrl().getRef());
        if (matcher.find()) {
            return matcher.group();
        }

        throw new Error("Quote id not found in url");
    }
}
