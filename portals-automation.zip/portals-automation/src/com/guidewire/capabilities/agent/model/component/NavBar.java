package com.guidewire.capabilities.agent.model.component;

import com.guidewire.portals.qnb.pages.AlertHandler;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import com.guidewire.capabilities.agent.model.page.AccountSearch;
import com.guidewire.capabilities.agent.model.page.AccountsLanding;
import com.guidewire.capabilities.agent.model.page.ActivitiesLanding;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.AnalyticsLanding;
import com.guidewire.capabilities.agent.model.page.ClaimsLanding;
import com.guidewire.capabilities.agent.model.page.PoliciesLanding;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class NavBar {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    private final static String ACTIVE_CLASS = "active";

    By NAV_BAR = By.cssSelector("[class*='header-nav-wrapper']");

    static By START_QUOTE_BTN_CSS = By.cssSelector("div[class*='startNewQuote'][style]");
    static By QUOTE_BTN_THIS_ACCOUNT_CSS = By.cssSelector("gw-start-new-quote div[class*='startNewQuote'] a[ui-sref*='newQuote(']");
    static By QUOTE_BTN_ANY_ACCOUNT_CSS = By.cssSelector("gw-start-new-quote div[class*='startNewQuote'] a[ui-sref='newQuoteSearch']");
    static By THIS_ACCOUNT_QUOTE_SELECTOR = By.cssSelector("[ui-sref='newQuote({accountNumber: getAccountNumberFromStateParams()})']");
    static By NEW_QUOTE_SELECTOR = By.cssSelector("[ui-sref='newQuoteSearch']");
    static By POLICIES_LANDING_SELECTOR = By.xpath(".//*[@ui-sref='policies.index']");
    static By ACCOUNTS_LANDING_SELECTOR = By.cssSelector("[ui-sref='accounts.index']");
    static By CLAIMS_LANDING_SELECTOR = By.cssSelector("a[ui-sref*='claims']");
    static By ACTIVITIES_LANDING_SELECTOR = By.cssSelector("[ui-sref='activities.index']");
    static By ANALYTICS_LANDING_SELECTOR = By.cssSelector("[ui-sref='reports']");
    static By DASHBOARD_SELECTOR = By.cssSelector("[href='#/home']");
    static By ALERT_POPUP = By.cssSelector("[class*='gw-fade']");

    public NavBar() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(NAV_BAR);
    }

    private WebElement getDashboardTab() {
        return this.seleniumCommands.findElement(NAV_BAR).findElement(DASHBOARD_SELECTOR);
    }

    private WebElement getAccountsLandingTab() {return this.seleniumCommands.findElement(NAV_BAR).findElement(ACCOUNTS_LANDING_SELECTOR); }

    private WebElement getPoliciesLandingTab() {
        return this.seleniumCommands.findElement(NAV_BAR).findElement(POLICIES_LANDING_SELECTOR);
    }

    private WebElement getClaimsLandingTab() { return this.seleniumCommands.findElement(NAV_BAR).findElement(CLAIMS_LANDING_SELECTOR);}

    private WebElement getActivitiesLandingTab() { return this.seleniumCommands.findElement(NAV_BAR).findElement(ACTIVITIES_LANDING_SELECTOR);}

    private WebElement getAnalyticsLandingTab() { return this.seleniumCommands.findElement(NAV_BAR).findElement(ANALYTICS_LANDING_SELECTOR);}

    private WebElement getNewQuoteButton() {
        return this.seleniumCommands.findElement(NAV_BAR).findElement(NEW_QUOTE_SELECTOR);
    }

    public AccountSearch startQuoteForAnyAccount() {
        seleniumCommands.waitForElementToBePresent(START_QUOTE_BTN_CSS);
        seleniumCommands.click(START_QUOTE_BTN_CSS);
        seleniumCommands.waitForElementToBePresent(QUOTE_BTN_ANY_ACCOUNT_CSS);
        seleniumCommands.click(QUOTE_BTN_ANY_ACCOUNT_CSS);
        if ( seleniumCommands.isElementPresent(THIS_ACCOUNT_QUOTE_SELECTOR)) {
            seleniumCommands.click(this.getNewQuoteButton());
        }
        return new AccountSearch();
    }

    public void startQuoteForThisAccount() {
        seleniumCommands.waitForElementToBePresent(START_QUOTE_BTN_CSS);
        seleniumCommands.click(START_QUOTE_BTN_CSS);
        seleniumCommands.waitForElementToBePresent(QUOTE_BTN_THIS_ACCOUNT_CSS);
        seleniumCommands.click(QUOTE_BTN_THIS_ACCOUNT_CSS);
    }

    public PoliciesLanding goToPoliciesLanding() {
        seleniumCommands.click(this.getPoliciesLandingTab());
        if (seleniumCommands.isElementPresent(ALERT_POPUP)){
            new AlertHandler().closeAlert();
        }
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new PoliciesLanding();
    }

    public AccountsLanding goToAccountsLanding() {
        seleniumCommands.click(this.getAccountsLandingTab());
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if (seleniumCommands.isElementPresent(ALERT_POPUP)){
            new AlertHandler().closeAlert();
        }
        return new AccountsLanding();
    }


    public ClaimsLanding goToClaimsLanding(){
        seleniumCommands.click(this.getClaimsLandingTab());
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new ClaimsLanding();
    }

    public ActivitiesLanding goToActivitiesLanding(){
        seleniumCommands.click(this.getActivitiesLandingTab());
        return new ActivitiesLanding();
    }

    public AnalyticsLanding goToAnalyticsLanding(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(this.getAnalyticsLandingTab());
        return new AnalyticsLanding();
    }

    public Validation isDashboardSelected() {
        return new Validation(seleniumCommands.hasClass(this.getDashboardTab(), ACTIVE_CLASS));
    }

    public Validation isAccountsLandingSelected() {
        return new Validation(seleniumCommands.hasClass(this.getAccountsLandingTab(), ACTIVE_CLASS));
    }

    public Validation isPoliciesLandingSelected() {
        return new Validation(seleniumCommands.hasClass(this.getPoliciesLandingTab(), ACTIVE_CLASS));
    }

    public Validation isClaimsLandingSelected(){
        return new Validation(seleniumCommands.hasClass(this.getClaimsLandingTab(), ACTIVE_CLASS));
    }

    public Validation isActivitiesLandingSelected(){
        return new Validation(seleniumCommands.hasClass(this.getActivitiesLandingTab(),ACTIVE_CLASS));
    }

    public Validation isAnalyticsLandingSelected(){
        return new Validation(seleniumCommands.hasClass(this.getAnalyticsLandingTab(),ACTIVE_CLASS));
    }

    public AgentDashboard goToDashBoard() {
        getDashboardTab().click();
        return new AgentDashboard();
    }

}
