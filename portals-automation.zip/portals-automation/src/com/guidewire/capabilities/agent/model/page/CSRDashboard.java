package com.guidewire.capabilities.agent.model.page;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;

public class CSRDashboard extends CommonScenario{
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[gw-test-policy-account-search] [gw-test-input-field]")
    WebElement SEARCH_INPUT_FIELD_CSS;

    @FindBy(css = "[gw-test-policy-account-search] [gw-test-input-field]")
    WebElement SEARCH_BUTTON_CSS;
    
    @FindBy(css = "[gw-test-account-table] tbody td[gw-test-account-holder-name] [aria-hidden='false']")
    WebElement RECENTLY_VISITED_ACCOUNTS_TABLE_CSS;
    
    By RECENTLY_VISITED_ACCOUNTS_NAME_CSS = By.cssSelector("[gw-test-account-table] tbody td[gw-test-account-holder-name] a");
    
    @FindBy(css = "[gw-test-recently-visited-policies] tbody td[gw-test-policy-number] [aria-hidden='false']")
    WebElement RECENTLY_VISITED_POLICY_TABLE_CSS;
    
    By RECENTLY_VISITED_POLICY_NUM_CSS = By.cssSelector("[gw-test-recently-visited-policies] tbody td[gw-test-policy-number] a");

    public CSRDashboard() {
    }

    public NavbarSearchResultPage searchFromCSRDashboard(String searchText){
        seleniumCommands.type(SEARCH_INPUT_FIELD_CSS, searchText);
        SEARCH_INPUT_FIELD_CSS.submit();
        return new NavbarSearchResultPage();
    }
    
    public NavbarSearchResultPage validatePolicyListingInRecentlyVistedTable(){
        return new NavbarSearchResultPage();
    }
    
    public void validateAccountListedInRecentlyVistedTable(){
    		seleniumCommands.waitForElementToBeVisible(RECENTLY_VISITED_ACCOUNTS_TABLE_CSS);
    		List<WebElement> accountsNameList = seleniumCommands.findElements(RECENTLY_VISITED_ACCOUNTS_NAME_CSS);
    		new Validation(accountsNameList.stream()
    				.filter(
    				subjectElement -> subjectElement.getText()
    				.equals(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NAME.toString())))
    				.findFirst()
    				.get()
    				.isDisplayed())
    				.shouldBeTrue("Account is not listed on the dashboard under recently visted table");
    }
    
    public void validatePolicyListedInRecentlyVistedTable(){
		seleniumCommands.waitForElementToBeVisible(RECENTLY_VISITED_POLICY_TABLE_CSS);
		List<WebElement> accountsNameList = seleniumCommands.findElements(RECENTLY_VISITED_POLICY_NUM_CSS);
		new Validation(accountsNameList.stream()
				.filter(
				subjectElement -> subjectElement.getText()
				.equals(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())))
				.findFirst()
				.get()
				.isDisplayed())
				.shouldBeTrue("Policy is not listed on the dashboard under recently visted table");
    }
    
   
}
