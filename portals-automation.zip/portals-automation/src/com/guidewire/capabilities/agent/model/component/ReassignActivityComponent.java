package com.guidewire.capabilities.agent.model.component;


import com.guidewire.capabilities.agent.data.AgentUserName;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class ReassignActivityComponent extends CommonScenario
{
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    
    WebElement REASSIGN_ACTIVITY;
    
    final String REASSIGN_ACTIVITY_EDIT_BUTTON_SELECTOR = "div[ng-show='activity.canReassign']";
    
    final String CANCEL_EDIT_BUTTON_SELECTOR = "div[ng-click='disableEditing()']";

    final String CONFIRM_EDIT_BUTTON_SELECTOR = "div[ng-click='assignToSelectedUser()']";

    final String ASSIGNEE_DROPDOWN_SELECTOR = "select[ng-model='assignedUser']";
    
    final String DISABLED_ASSIGNEE_DROPDOWN_SELECTOR = "select[ng-model='assignedUser'][aria-hidden='true']";

    final String ASSIGNED_TO_TEXT_SELECTOR = ".gw-assigned-to-text";



    public ReassignActivityComponent(WebElement reassignActivity){
        REASSIGN_ACTIVITY = reassignActivity;
    }

	public ReassignActivityComponent openReassignActivityDropdown() {
        WebElement reassignEditButton = REASSIGN_ACTIVITY.findElement(By.xpath("..")).findElement(By.cssSelector(REASSIGN_ACTIVITY_EDIT_BUTTON_SELECTOR));
		seleniumCommands.makeElementVisibleByJS(reassignEditButton);
		seleniumCommands.clickbyJS(reassignEditButton);
		return this;
	}

    public ReassignActivityComponent setAssigneeByName(){
        WebElement dropdown = REASSIGN_ACTIVITY.findElement(By.xpath("..")).findElement(By.cssSelector(ASSIGNEE_DROPDOWN_SELECTOR));
        seleniumCommands.click(dropdown);
        seleniumCommands.selectFromDropdownByIndex(dropdown, 2);
        ThreadLocalObject.getData().put("Assignee", seleniumCommands.getSelectedOptionFromDropDown(dropdown));
        return this;
    }

    public ReassignActivityComponent clickCancelButton(){
        REASSIGN_ACTIVITY.findElement(By.xpath("..")).findElement(By.cssSelector(CANCEL_EDIT_BUTTON_SELECTOR)).click();
        seleniumCommands.staticWait(2);
        return this;
    }

	public ReassignActivityComponent clickConfirmButton() {
		seleniumCommands.click(By.xpath(
				"//*[contains(@class,'expanded')]//div[contains(@class,'-assignee')]//div[@class='gw-activity-container']//div[@ng-click='assignToSelectedUser()']"));
		seleniumCommands.staticWait(2);
		return this;
	}

    public Validation isNotAssignedToCurrentUser() {
	return new Validation(ThreadLocalObject.getData().get("Assignee").contains(REASSIGN_ACTIVITY.findElement(By.cssSelector(ASSIGNED_TO_TEXT_SELECTOR)).getText()));
    }

    public Validation isAssignedToCurrentUser()
    {
        return new Validation(REASSIGN_ACTIVITY.findElement(By.cssSelector(ASSIGNED_TO_TEXT_SELECTOR)).getText(), AgentUserName.getValueByUname(ThreadLocalObject.getData().get("USER")));

    }
}
