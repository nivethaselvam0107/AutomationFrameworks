package com.guidewire.capabilities.agent.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ClaimsList {
    private final SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "table[list='getFilteredClaimSummaries()']")
    WebElement CLAIM_LIST_CSS;

    @FindBy(css = "a[href='#/fnol']")
    WebElement FILE_CLAIM_BTN_CSS;

    @FindBy(css = "[ng-model='tableConfig.search']")
    WebElement SEARCH_TXT_CSS;

    @FindBy(xpath = "//th[@attribute='claimNumber']")
    WebElement CLAIMNUM_COL_XPATH;

    @FindBy(xpath = "//th[@attribute='lossDate']")
    WebElement DOL_COL_XPATH;

    @FindBy(xpath = "//th[@attribute='status']")
    WebElement STATUS_COL_XPATH;

    public ClaimsList() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public Validation isClaimListPageLoaded() {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_CSS);
        new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_CSS)).shouldBeTrue("File a Claim button not visible");
        new Validation(seleniumCommands.isElementPresent(CLAIM_LIST_CSS)).shouldBeTrue("Claims list is not displayed");
        new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
        new Validation(seleniumCommands.isElementPresent(CLAIMNUM_COL_XPATH)).shouldBeTrue("Claim List ClaimNum Column is not visible");
        new Validation(seleniumCommands.isElementPresent(DOL_COL_XPATH)).shouldBeTrue("Claim List Date of Loss Column is not visible");
        new Validation(seleniumCommands.isElementPresent(STATUS_COL_XPATH)).shouldBeTrue("Claim List Status Column is not visible");
        return new Validation(true);
    }

    public ClaimsList filterClaimByTextSearch(String claimNumber) {
        seleniumCommands.waitForElementToBeVisible(SEARCH_TXT_CSS);
        seleniumCommands.type(SEARCH_TXT_CSS, claimNumber);
        return this;
    }

    public Validation validateContainsClaim(String claimNumber) {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_CSS);
        boolean result = CLAIM_LIST_CSS.findElements(By.xpath("tbody//a"))
                .stream()
                .filter(e -> e.getText().equals(claimNumber))
                .findAny()
                .isPresent();

        return new Validation(result);
    }
}
