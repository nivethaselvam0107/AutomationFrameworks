package com.guidewire.capabilities.agent.model.page;

import com.guidewire.capabilities.common.data.PolicyType;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;

import java.util.HashMap;

public class AgentDashboard {
    Logger logger = Logger.getLogger(this.getClass().getName());
    private final NavBar navBar;
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(xpath = "//div[contains(@class,'*')]")
    WebElement DASHBOARD_TITLE;

    @FindBy(css = "[id='SearchParam']")
    WebElement SEARCH_BOX;
    
    By CSR_SEARCH_BOX_CSS = By.cssSelector("[model='search.searchParam']");

    By OPEN_QUOTES_TILE = By.cssSelector("[gw-test-directives-gatewaydashboarddirective-gateway-dashboard-open-quotes]");
    By OPEN_POLICY_CHANGES_TILE = By.cssSelector("[gw-test-directives-gatewaydashboarddirective-gateway-dashboard-open-policy-changes]");
    By OPEN_CANCELLATIONS_TILE = By.cssSelector("[gw-test-directives-gatewaydashboarddirective-gateway-dashboard-open-cancellations]");
    By OPEN_RENEWALS_TILE = By.cssSelector("[gw-test-directives-gatewaydashboarddirective-gateway-dashboard-open-renewals]");


    By ACTIVITIES_FOR_NEXT_7_DAYS_BLOCK = By.cssSelector("[gw-test-gateway-activityscheduledirective-activity-schedule-open-activities-for-next-7-days]");
    By ACTIVITY_PRIORITY = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-priority]");
    By ACTIVITY_DUE_DATE = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-due-to-date]");
    By ACTIVITY_SUBJECT = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-subject]");
    By ACTIVITY_ASSIGNED_TO = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-assigned-to]");
    By ACTIVITY_NOTES = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-notes]");
    By ACTIVITY_STATUS = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-status]");
    By EXPAND_ACTIVITY_BUTTON = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-expand-activity]");
    By ACTIVITY_DETAILS = By.cssSelector("[gw-test-gateway-refreshactivitiesviewdirective-activities-view-details]");


    By COLUMN_CREATED_TIME = By.cssSelector("[gw-test-gateway-views-policy-landing-created-time]");
    By COLUMN_PRODUCT = By.cssSelector("[gw-test-gateway-views-policy-landing-product]");
    By COLUMN_JOB_NUMBER = By.cssSelector("[gw-test-gateway-views-policy-landing-job-number]");
    By COLUMN_POLICY_NUMBER = By.cssSelector("[gw-test-gateway-views-policy-landing-policy-number]");
    By COLUMN_ACCOUNT_NUMBER = By.cssSelector("[gw-test-gateway-views-policy-landing-account-number]");
    By COLUMN_TOTAL_PREMIUM = By.cssSelector("[gw-test-gateway-views-policy-landing-total-premium]");
    By COLUMN_STATUS = By.cssSelector("[gw-test-gateway-views-policy-landing-status]");

    private static String JOB_LINK = "[gw-test-gateway-activities-view-job-link='%s']";


    public AgentDashboard() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("[ng-model='selectedProducerCode'], [model='search.searchParam']"));
        this.navBar = new NavBar();
        if(!seleniumCommands.isElementPresent(CSR_SEARCH_BOX_CSS)) {
        		seleniumCommands.waitForElementSelectToHaveMoreValuesThan(seleniumCommands.findElement(By.cssSelector("[name=\"selectedProducerCode\"]")), 1);
        }
    }

    public AccountSearch searchQuote() {
        return this.navBar.startQuoteForAnyAccount();
    }

    public NavbarSearchResultPage searchUsingSearchBox(String searchText){
    	seleniumCommands.staticWait(3);
        seleniumCommands.clickbyJS(By.cssSelector("[for='SearchParam']"));
        seleniumCommands.waitForElementToBeVisible(SEARCH_BOX);
        SEARCH_BOX.clear();
        SEARCH_BOX.sendKeys(searchText);
        SEARCH_BOX.submit();

        return new NavbarSearchResultPage();
    }

    public PoliciesLanding goToPolicies() {
        return this.navBar.goToPoliciesLanding();
    }

    public AgentDashboard goToHome() {
        return this.navBar.goToDashBoard();
    }

    public AccountsLanding goToAccounts() {
        return this.navBar.goToAccountsLanding();
    }

    public ClaimsLanding goToClaims() {
        return this.navBar.goToClaimsLanding();
    }

    public AccountSummary openAccountUsingAccountNumber(String accountNumber) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
    	seleniumCommands.click(By.linkText(accountNumber));
        return new AccountSummary();
    }

    public PolicyChangeSummaryPage clickJobLink(String jobNumber) {
        seleniumCommands.click(By.cssSelector(String.format(JOB_LINK,jobNumber)));
        return new PolicyChangeSummaryPage();
    }

    public PolicyChangeSummaryPage clickJobLink() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(By.cssSelector(String.format(JOB_LINK,ThreadLocalObject.getData().get("JobNumber"))));
        return new PolicyChangeSummaryPage();
    }

    public boolean isCSRDashboardOpened() {
    		return seleniumCommands.isElementPresent(CSR_SEARCH_BOX_CSS);
    }

    public void goToRecentyIssuedPolicies() {
        PoliciesLanding policies = this.goToPolicies();
        policies.getProducerCodeSelector().selectEverything();
        policies.showRecentlyIssued();
    }

    public PoliciesLanding goToOpenCancellations() {
        seleniumCommands.logInfo("Clicking Open Cancellations tile.");
        new Tiles().selectByText("Open Cancellations");
        return new PoliciesLanding();
    }

    public PoliciesLanding goToOpenPolicyChanges() {
        seleniumCommands.logInfo("Clicking Open Policy Changes tile.");
        new Tiles().selectByText("Open Policy Changes");
        return new PoliciesLanding();
    }

    public PolicyCancelationSummary clickCancellationLineOfBusinessLink(String cancellationJobNum) {
        seleniumCommands.logInfo("Clicking on Line of Bussiness link on Activity that belongs to policy cancellation transaction.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.cssSelector("[href='#/cancellation/"+ cancellationJobNum + "/summary']") ).click();
        return new PolicyCancelationSummary();
    }

    public PolicySummary goToPolicySummary(String policyNumber) {
        logger.info("Going to Policy summary: " + policyNumber);
        goToRecentyIssuedPolicies();
        seleniumCommands.waitForElementToBeClickable(By.xpath("//tr[descendant::a[contains(@href, '" + policyNumber + "')]]//a[contains(@href, 'policies')]"));
        seleniumCommands.click(By.xpath("//tr[descendant::a[contains(@href, '" + policyNumber + "')]]//a[contains(@href, 'policies')]"));
        return new PolicySummary(policyNumber);
    }

    public AgentDashboard expandFirstActivity() {
        logger.info("Expanding first activity" );
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(seleniumCommands.findElements(EXPAND_ACTIVITY_BUTTON).get(1));
        return this;
    }

    public AgentDashboard openRenewalsTile() {
        logger.info("Opening renewals tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(OPEN_RENEWALS_TILE);
        return this;
    }

    public AgentDashboard openOpenQuotesTile() {
        logger.info("Opening renewals tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(OPEN_QUOTES_TILE);
        return this;
    }

    public AgentDashboard openCancelationsTile() {
        logger.info("Opening renewals tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(OPEN_CANCELLATIONS_TILE);
        return this;
    }

    public AgentDashboard openPolicyChangesTile() {
        logger.info("Opening renewals tile");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(OPEN_POLICY_CHANGES_TILE);
        return this;
    }

    public void startBOPQuoteWithNewAccount(HashMap<String, String> data) {
        PolicyGenerator.createBasicBoundPAPolicy();
        String addressLine1 = data.get("AddressLine1");
        String city = data.get("City");
        String zip = data.get("Zip");

        searchForPersonalAccount(data)
                .createNewAccount()
                .withAddressLine1(addressLine1)
                .withCity(city)
                .withZip(zip)
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .submit();

        new QuoteStart()
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(PolicyType.BO.getPolicyType())
                .submit();
    }

    public AccountSearchResults searchForPersonalAccount(HashMap<String, String> data){
        return new AgentDashboard()
                .searchQuote()
                .forPersonalAccount()
                .withFirstName(data.get(PolicyData.ACCOUNT_FIRST_NAME.toString()))
                .withLastName(data.get(PolicyData.ACCOUNT_LAST_NAME.toString()))
                .search();

    }

    // Verifications
    public AgentDashboard verifyActivitiesForNext7daySections() {
        logger.info("Verifying ativities for next 7 day sections.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(ACTIVITIES_FOR_NEXT_7_DAYS_BLOCK)).shouldBeTrue("Activities for the next 7 days section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_PRIORITY).size()>0).shouldBeTrue("Activities priority section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_DUE_DATE).size()>0).shouldBeTrue("Activities due to date section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_STATUS).size()>0).shouldBeTrue("Activities status section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_ASSIGNED_TO).size()>0).shouldBeTrue("Activities assigned to section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_NOTES).size()>0).shouldBeTrue("Activities notes section was not found");
        new Validation(seleniumCommands.findElements(ACTIVITY_SUBJECT).size()>0).shouldBeTrue("Activities subject section was not found");
        return this;
    }

    public AgentDashboard verifyActivityDetailsExpanded() {
        logger.info("Verifying first activity details are expanded" );
        new Validation(seleniumCommands.getAttributeValueAtLocator(seleniumCommands.findElements(ACTIVITY_DETAILS).get(1), "aria-hidden"),"false").shouldBeEqual("Activity details were not expanded");
        return this;
    }

    public AgentDashboard verifyPoliciesTableColumns() {
        logger.info("Verifying policies table columns.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(COLUMN_CREATED_TIME)).shouldBeTrue("Renewals created time was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_PRODUCT)).shouldBeTrue("Renewals product was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_JOB_NUMBER)).shouldBeTrue("Renewals job number was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_POLICY_NUMBER)).shouldBeTrue("Renewals policy number was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_ACCOUNT_NUMBER)).shouldBeTrue("Renewals account number was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_TOTAL_PREMIUM)).shouldBeTrue("Renewals total premium was not found");
        new Validation(seleniumCommands.isElementPresent(COLUMN_STATUS)).shouldBeTrue("Renewals status was not found");
     return this;
    }

}
