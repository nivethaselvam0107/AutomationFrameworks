package com.guidewire.capabilities.agent.model.page;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.ActivityComponent;
import com.guidewire.capabilities.agent.model.component.AddActivityComponent;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class GPA_ActivityPageFactory 
{
    	String DIARY_30DAY = "30 day diary";
		String INTERVIEW = "Meet with Insured";
    
	public AccountSummary openAccountActivityTile()
	{
	        login();
	        return searchUsingSearchBox()
	            .goToAccount().goToActivitiesTile();
	}
	
	public PolicyDetailsPage openPolicyActivityTile()
	{
	        login();
	        searchUsingSearchBox()
	            .goToAccount().goToFirstPolicyInList();
	       return new PolicyDetailsPage()
	         .goToActivitiesTile();
	        
	}
	
	public QuoteSummary openQuoteActivityTile()
	{
	        login();
	        return searchUsingSearchBox()
	            .goToAccount().goToOpenQuotes().goToFirstQuoteInList().goToActivitiesTile();
	}
	
	public AccountSummary clickAddActivityButtonFromAccountActivityTile()
	{
		return this.openAccountActivityTile().clickAddActivityButton();
	}
	
	public PolicyDetailsPage clickAddActivityButtonFromPolicyActivityTile()
	{
		return  openPolicyActivityTile()
         .clickAddActivityButton();
	}
	
	public QuoteSummary clickAddActivityButtonFromQuoteActivityTile()
	{
		return  openQuoteActivityTile()
         .clickAddActivityButton();
	}

	public void goToQouteActivitiesComponentThroughAccounts(){
		new AgentDashboard().goToAccounts()
				.openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
				.goToOpenQuotes()
				.goToFirstQuoteInList()
				.goToActivitiesTile();
	}
	public AddActivityComponent addActivityFromActivityTile(String type, String subject)
	{
		return new AddActivityComponent()
        .withActivityTypeByText(type)
        .withSubject(subject)
        .submit();
	}

	public AddActivityComponent addActivityThanCancelSubmition()
	{
		new SeleniumCommands().logInfo("Filling all the mandatory fields on adding activity form, than cancelling submission.");
		return new AddActivityComponent()
				.withActivityTypeByText("Meet with Insured")
				.withSubject(new SeleniumCommands().generateUUID())
				.clickCancelButton();
	}

	private AddActivityComponent addOverDueActivityFromActivityTile(String type, String subject)
	{
		return new AddActivityComponent()
        .withActivityTypeByText(type)
        .withOverDueDate()
        .withSubject(subject)
        .withDescription()
        .submit();
	}
	
	private AddActivityComponent addDueTomorrowActivityFromActivityTile(String type, String subject)
	{
		return new AddActivityComponent()
        .withActivityTypeByText(type)
		.withDueTomorrowDate()
        .withSubject(subject)
        .withDescription()
        .submit();
	}
	
	public ActivityComponent expandFirstActivity()
	{
		  return new ActivitiesScheduleComponent()
           .clickOnFirstActivity();
	}
	
	public AddActivityComponent addDefaultActivity()
	{
		this.addActivityFromActivityTile("Meet with Insured", new SeleniumCommands().generateUUID());
		new AlertHandler().closeAlert();
		return new AddActivityComponent();
	}
	
	public AddActivityComponent addDefaultActivity(String subject)
	{
		this.addActivityFromActivityTile("Meet with Insured", subject);
		new AlertHandler().closeAlert();
		return new AddActivityComponent();
	}
	
	public AddActivityComponent addDueTomorrowActivity(String subject)
	{
		this.addDueTomorrowActivityFromActivityTile("Meet with Insured", subject);
		new AlertHandler().closeAlert();
		return new AddActivityComponent();
	}
	
	public AddActivityComponent addOverDueActivity(String subject)
	{
		this.addOverDueActivityFromActivityTile("Meet with Insured", subject);
		new AlertHandler().closeAlert();
		return new AddActivityComponent();
	}
	
	public AddActivityComponent addDefaultFutureActivity()
	{
		String activitySubject = new SeleniumCommands().generateUUID();
		ThreadLocalObject.getData().put("ACTIVITY_SUBJECT",activitySubject);
		this.addActivityFromActivityTile(DIARY_30DAY, activitySubject);
		new AlertHandler().closeAlert();
		return new AddActivityComponent();
	}
	
	public void addActivityOnAccountDetailsPage()
	{
		PolicyGenerator.createBasicBoundPAPolicy();
		openAccountActivityTile();
		addDefaultActivity();
	}

	public void addFutureActivityOnAccountDetailsPage()
	{
		PolicyGenerator.createBasicBoundPAPolicy();
		openAccountActivityTile();
		addDefaultFutureActivity();
	}
	
	public void addActivityOnPolicyDetailsPage()
	{
	    openPolicyActivityTile();
	    addDefaultActivity();
	}
	
	private void login(){
        new LoginPage().login();
    }
	
	private NavbarSearchResultPage searchUsingSearchBox(){
	       if(ThreadLocalObject.getBrowserName().equals("iPAD"))
	       {
	       		new AgentDashboard().goToAccounts();
	       		return new NavbarSearchResultPage();
	       }
	       else
	       {
	    	   		return new AgentDashboard()
	    	            .searchUsingSearchBox(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()));
	       }

	    }
}
