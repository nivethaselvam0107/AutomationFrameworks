package com.guidewire.capabilities.agent.model.page;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * @author Darya Fedo
 * */
public class PolicyCancelationSummary {

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    By ADD_ACTIVITIE_BTN = By.cssSelector("[ng-click='showAddActivity()']");

    By OPEN_ACTIVITIE_TILE = By.cssSelector("[tile-title='Open Activities']");

    By SUMMARY_TILE = By.cssSelector("[tile-title='Summary']");

    By NOTES_TILE = By.cssSelector("[tile-title='Notes']");

    By DOCUMENTS_TILE = By.cssSelector("[tile-title='Documents']");

    By ADD_NOTE_BTN = By.cssSelector("[data-ng-click='showAddNoteForm()']");

    By ADD_DOCUMENT_BTN = By.cssSelector("[id='uploadButton']");

    By CANCELLATION_TITLE = By.cssSelector("h1[class*=gw-titles-title]");

    By POLICY_LINK = By.cssSelector("div[gw-partial='Item'] a[ui-sref*='policies']");

    By CANCELLATION_MESSAGE_HEADER = By.cssSelector("div[gw-partial='Content'] h2");

    By CANCELLATION_MESSAGE_BODY = By.cssSelector("div[gw-partial='Content'] p");

    By WITHDRAW_CANCELLATION_BTN = By.cssSelector("button[ng-show='cancellation.canWithdraw']");

    By BIND_CANCELLATION_BTN = By.cssSelector("button[ng-show='cancellation.canBind']");

    By CANCELLATION_DETAILS = By.cssSelector("[class='gw-emphasis ng-binding']");

    By EXPIRATION_DATE_ERROR_MESSAGE = By.cssSelector("div[ng-hide='effectiveDateValidation.isValid']");

    final static String TITLE_TEMPLATE = "Cancellation (%s)";

    public PolicyCancelationSummary goToOpenActivitiesTile() {
        seleniumCommands.logInfo("Clicking OpenActivities tile.");
        new Tiles().selectByTitle("Open Activities");
        return new PolicyCancelationSummary();
    }
    public PolicyCancelationSummary goToNoteTile() {
        seleniumCommands.logInfo("Clicking Note tile.");
        new Tiles().selectByTitle("Notes");
        return new PolicyCancelationSummary();
    }
    public PolicyCancelationSummary goToDocumentsTile() {
        seleniumCommands.logInfo("Clicking Document tile.");
        new Tiles().selectByTitle("Documents");
        return new PolicyCancelationSummary();
    }

    public PolicyCancelationSummary clickAddActivityBtn() {
        seleniumCommands.logInfo("Clicking add activity button.");
        seleniumCommands.waitForElement(ADD_ACTIVITIE_BTN);
        seleniumCommands.clickbyJS(ADD_ACTIVITIE_BTN);
        return new PolicyCancelationSummary();
    }

    public PolicyCancelationSummary clickAddNoteBtn() {
        seleniumCommands.logInfo("Clicking add note button.");
        seleniumCommands.waitForElement(ADD_NOTE_BTN);
        seleniumCommands.clickbyJS(ADD_NOTE_BTN);
        return new PolicyCancelationSummary();
    }

    public PolicyCancelationSummary clickAddDocumentBtn() {
        seleniumCommands.logInfo("Clicking add document button.");
        seleniumCommands.waitForElement(ADD_DOCUMENT_BTN);
        seleniumCommands.clickbyJS(ADD_DOCUMENT_BTN);
        return new PolicyCancelationSummary();
    }

    public String getTileValue(WebElement tile) {
        seleniumCommands.logInfo("Getting tile value.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return tile.getCssValue("tile-value");
    }

    public String getCancellationJobNumber() {
        seleniumCommands.logInfo("Getting Cancellation job number.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String jobNumber = seleniumCommands.findElement(CANCELLATION_TITLE).getText().replaceAll("\\D+","");
        return jobNumber;
    }

    public PolicySummary clickPolicyLink() {
        seleniumCommands.logInfo("Clicking policy link.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(POLICY_LINK).click();
        return new PolicySummary();
    }

    // Validations

    public void isCancellationPagePresented(String jobNumber) {
        seleniumCommands.logInfo("Validating Cancellation page title contains Cancellation job number.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.findElement(CANCELLATION_TITLE).getText().contains(jobNumber)).shouldBeTrue("Cancellation page opened incorrectly");
    }

    public void validateNoPeriodErrorPopup() {
        seleniumCommands.logInfo("Validating error is displayed when user provides effective date not within the policy period for Cancel action.");
        new Validation( seleniumCommands.getTextAtLocator(EXPIRATION_DATE_ERROR_MESSAGE), DataConstant.EXPIRED_DATE_ERROR_MESSAGE).shouldBeEqual("Error message is incorrect.");
    }

    public PolicyCancelationSummary validateCancellationStatus(String expectedStatus) {
        seleniumCommands.logInfo("Validating cancellation status equals to expected");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(By.cssSelector("[type='policyperiod-status-" + expectedStatus + "']"))).shouldBeTrue("Status of cancellation is incorrect");
        return this;
    }
    public PolicyCancelationSummary validateQuotedCancellationPageComponents(String jobNumber) {
        seleniumCommands.logInfo("Validating cancellation page components");
        Tiles tiles = new Tiles();
        seleniumCommands.waitForLoaderToDisappearFromPage();

        validateCancellationStatus("Quoted");
        new Validation(seleniumCommands.findElement(CANCELLATION_TITLE).getText(), String.format(TITLE_TEMPLATE, jobNumber)).shouldBeEqual("Cancellation title is incorrect or missing");

        tiles.isTilePresent("Summary").shouldBeTrue("Summary tile is missing");
        tiles.isTilePresent("Notes").shouldBeTrue("Note tile is missing");
        tiles.isTilePresent("Open Activities").shouldBeTrue("Open activities tile is missing");
        tiles.isTilePresent("Documents").shouldBeTrue("Documents tile is missing");

        new Validation(seleniumCommands.findElement(CANCELLATION_MESSAGE_HEADER).getText(), DataConstant.QUOTED_CANCELLATION_MESSAGE_HEADER).shouldBeEqual("Cancellation message header is incorrect or missing");
        new Validation(seleniumCommands.findElement(CANCELLATION_MESSAGE_BODY).getText().contains(DataConstant.QUOTED_CANCELLATION_MESSAGE_BODY)).shouldBeTrue("Cancellation message body  is incorrect or missing");
        new Validation(seleniumCommands.isElementClickable(WITHDRAW_CANCELLATION_BTN)).shouldBeTrue("Withdraw cancellation button is missing");
        new Validation(seleniumCommands.isElementClickable(BIND_CANCELLATION_BTN)).shouldBeTrue("Bind cancellation button is missing");

        new Validation(seleniumCommands.findElements(CANCELLATION_DETAILS).size(), 6).shouldBeEqual("Some od Cancellation details is missing");
        return this;
    }


    public PolicyCancelationSummary validateBoundCancellationPageComponents(String jobNumber) {
        seleniumCommands.logInfo("Validating cancellation page components");
        Tiles tiles = new Tiles();
        seleniumCommands.waitForLoaderToDisappearFromPage();

        validateCancellationStatus("Bound");
        new Validation(seleniumCommands.findElement(CANCELLATION_TITLE).getText(), String.format(TITLE_TEMPLATE, jobNumber)).shouldBeEqual("Cancellation title is incorrect or missing");

        tiles.isTilePresent("Summary").shouldBeTrue("Summary tile is missing");
        tiles.isTilePresent("Notes").shouldBeTrue("Note tile is missing");
        tiles.isTilePresent("Open Activities").shouldBeTrue("Open activities tile is missing");
        tiles.isTilePresent("Documents").shouldBeTrue("Documents tile is missing");

        new Validation(seleniumCommands.findElement(CANCELLATION_MESSAGE_HEADER).getText(), DataConstant.BOUND_CANCELLATION_MESSAGE_HEADER).shouldBeEqual("Cancellation message header is incorrect or missing");
        new Validation(seleniumCommands.findElement(CANCELLATION_MESSAGE_BODY).getText(), DataConstant.BOUND_CANCELLATION_MESSAGE_BODY).shouldBeEqual("Cancellation message body  is incorrect or missing");

        new Validation(seleniumCommands.isElementClickable(WITHDRAW_CANCELLATION_BTN)).shouldBeFalse("Withdraw cancellation button is is present while it shouldn't.");
        new Validation(seleniumCommands.isElementClickable(BIND_CANCELLATION_BTN)).shouldBeFalse("Bind cancellation button is present while it shouldn't.");

        new Validation(seleniumCommands.findElements(CANCELLATION_DETAILS).size(), 6).shouldBeEqual("Some od Cancellation details is missing");
        return this;
    }





}
