package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.table.Table;

/**
 * Created by skrishnappanavar on 22/06/2016.
 */
public class AnalyticsLanding {

    private final NavBar navBar;
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "div.gw-row__item.ng-scope,  div.gw-row-layout__item span")//div.gw-producer-page-title - alternative
    WebElement TITLE;

    @FindBy(css = "table[list='pageListData.items']")
    WebElement PAGINATED_TABLE;

    @FindBy(css = "div.gw-tile.ng-scope.ng-isolate-scope.gw-active")
    WebElement DEFAULT_TILE;

    @FindBy(css = "div[tile-title='Loss Ratios']" )
    WebElement TILE;

    public AnalyticsLanding() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);

        this.navBar = new NavBar();
        this.navBar.isAnalyticsLandingSelected().shouldBeTrue();
    }

    public Table getTable() {
        return new Table(PAGINATED_TABLE);
    }

    public Validation checkTitle(){
        return new Validation(this.TITLE.getText(), "Analytics");
    }

    public Validation checkDefaultTile(){
        String tileName = this.DEFAULT_TILE.getAttribute("tile-title");
        return new Validation(tileName,"Growth");
    }

    public Validation checkTile(){
        String tileName = this.TILE.getText();
        return new Validation(tileName,"LOSS RATIOS");
    }

}
