package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;

public class NavbarSearchResultPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = ".gw-search-result")
    WebElement TITLE;

    By SEARCH_RESULTS_CSS = By.cssSelector(".gw-page-section-header[aria-hidden='false'] .gw-search-result");

    private static final String ACCOUNT_FROM_SEARCH_RESULTS_XPATH = "[href*= '#/accounts/']";

    private static final String POLICY_LINK = "[href = '#/policies/POLICY_NUM/summary']";

    public NavbarSearchResultPage() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public AccountSummary goToAccount(){
        if(ThreadLocalObject.getBrowserName().equals("iPAD"))
        {
        		seleniumCommands.click(By.linkText(PolicyData.ACCOUNT_NAME.toString()));
        }
        else
        {
            seleniumCommands.staticWait(5);
        		seleniumCommands.waitForElementToBeVisible(SEARCH_RESULTS_CSS);
            seleniumCommands.findElement(SEARCH_RESULTS_CSS).findElement(By.xpath("//ul/li/a[contains(., '# " + ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()) + "')]")).click();
        }
        
        return new AccountSummary();
    }

    public PolicySummary goToPolicy(String policyNum){
        seleniumCommands.staticWait(5);
        seleniumCommands.waitForElementToBeVisible(this.SEARCH_RESULTS_CSS);
        seleniumCommands.findElement(SEARCH_RESULTS_CSS).findElement(By.cssSelector(POLICY_LINK.replace("POLICY_NUM", policyNum))).click();
        return new PolicySummary(policyNum);
    }

    public AccountSummary goToAccountFromPolicySearch(){
        seleniumCommands.waitForElementToBeVisible(this.SEARCH_RESULTS_CSS);
        seleniumCommands.findElement(SEARCH_RESULTS_CSS).findElement(By.cssSelector(ACCOUNT_FROM_SEARCH_RESULTS_XPATH)).click();
        return new AccountSummary();
    }

}
