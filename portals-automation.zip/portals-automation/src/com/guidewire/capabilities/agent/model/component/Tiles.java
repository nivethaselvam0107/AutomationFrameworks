package com.guidewire.capabilities.agent.model.component;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.CommonPage;

public class Tiles extends CommonPage {
    Logger logger = Logger.getLogger(this.getClass().getName());
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(xpath = "//*[contains(@class,'gw-tile-title')]")
    WebElement tiles;

    @FindBy(css = "[class*='active'][tile-title]")
    WebElement ACTIVE_TILE_TXT_CSS;

    WebElement selectedTile;
    
    String selectedTileTitle;

    String tileTitleTemplate = " 	//div[contains(@tile-title,'%s')]";
    
    String tileTitleText = "//div[text()='%s']";

    public Tiles selectByTitle(String tileTitle) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        WebElement tile =seleniumCommands.findElement(By.xpath(String.format(tileTitleTemplate, tileTitle)));
        seleniumCommands.waitForElementToBePresent(tile);
        logger.info("Tile clicked: " + tileTitle);
        seleniumCommands.click(tile);
        selectedTile = tile;
        return this;
    }
    
    public Tiles selectByText(String tileText) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        WebElement tile =seleniumCommands.findElement(By.xpath(String.format(tileTitleText, tileText)));
        seleniumCommands.waitForElementToBePresent(tile);
        logger.info("Tile clicked: " + tileTitleText);
        seleniumCommands.click(tile);
        selectedTile = tile;
        return this;
    }


    public String getSelectedTileName(){
        return seleniumCommands.getTextAtLocator(ACTIVE_TILE_TXT_CSS);
    }

    public String getCountOnActiveTile(){
        return seleniumCommands.getAttributeValueAtLocator(ACTIVE_TILE_TXT_CSS, "tile-value");
    }

    public Validation isTilePresent(String tileName){
        WebElement tile =seleniumCommands.findElement(tiles, By.xpath(String.format(tileTitleTemplate, tileName)));
        seleniumCommands.waitForElementToBeVisible(tile);
        return new Validation(seleniumCommands.isElementPresent(tile));
    }

    public WebElement getElement() {
        return this.tiles;
    }
}
