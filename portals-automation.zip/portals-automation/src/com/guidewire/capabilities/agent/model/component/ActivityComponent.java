package com.guidewire.capabilities.agent.model.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.data.ActivityData;
import com.guidewire.capabilities.agent.data.AgentUserName;
import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class ActivityComponent
{
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    Logger LOGGER = Logger.getLogger(this.getClass().getName());
    private  HashMap<String, String> data = ThreadLocalObject.getData();

    WebElement ACTIVITY_COMPONENT;

    final String COMPLETE_ACTIVITY_BUTTON_SELECTOR = "button[ng-click='competeActivity(activity)']";
    final String COMPLETE_ACTIVITY_LABEL_SELECTOR = "[class='gw-completed'] .gw-compelete-status";
    final String ADD_NOTE_BUTTON_SELECTOR = "[class='gw-note-data'] button";
    final String ADD_NOTE_SECTION_SELECTOR = "div[ng-hide='activity.notes.length === 0 && activity.closeDate']";
    final String NOTE_SUBJECT_SELECTOR = "[class*='note-details'] [class*='subject']";

    @FindBy(css = COMPLETE_ACTIVITY_LABEL_SELECTOR)
    WebElement ACTIVITY_COMPLETE_LABEL;

    @FindBy(css = ADD_NOTE_BUTTON_SELECTOR)
    WebElement ADD_NOTE_BUTTON;
    
	By SUBJECT_CSS = By.cssSelector("[class*='subject']  [gw-displaykey-format-replaces='action']");
	By ACCOUNT_NAME_CSS = By.cssSelector("[class*='subject']  [ui-sref*='accounts']");
	By ASSIGNEE_CSS = By.cssSelector("[class*='assignee'] select option[selected]");
	By STATUS_CSS = By.cssSelector("[class*='completed'] [class*='status'][aria-hidden='false']");
	By CREATED_BY_CSS = By.cssSelector(
			"[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(2) [class*='gw-activity-detail']:nth-of-type(1)  [class*='gw-activity-detail-value']");
	By CREATED_BY_LABEL_CSS = By.cssSelector(
			"[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(2) [class*='gw-activity-detail']:nth-of-type(1)  [class*='gw-activity-detail-label']");
	By ASSIGNEE_DATA = By.cssSelector(".gw-activity-assignee");
	By ESCALATION_DATE_LABEL_SELECTOR = By.cssSelector("[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(1) [class*='gw-activity-detail']:nth-of-type(1)  [class*='gw-activity-detail-label']");
	By CREATED_DATE_LABEL_CSS = By.cssSelector(
			"[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(2) [class*='gw-activity-detail']:nth-of-type(2)  [class*='gw-activity-detail-label']");
	By TYPE_LABEL_CSS = By.cssSelector(
			"[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(1) [class*='gw-activity-detail']:nth-of-type(2)  [class*='gw-activity-detail-label']");
	By DESC_LABEL_CSS = By.cssSelector(
			"[ng-show*='expanded'] [class*='gw-activity-detail-block']:nth-of-type(1) [class*='gw-activity-detail']:nth-of-type(3)  [class*='gw-activity-detail-label']");
	
	private static final String ESCALATION_DATE_LABEL = "ESCALATION DATE";
	private static final String TYPE_LABEL = "TYPE";
	private static final String CREATED_BY_LABEL = "CREATED BY";
	private static final String CREATED_LABEL ="CREATED";
	private static final String DESCRIPTION_LABEL ="DESCRIPTION";
	 
	By PRIORITY_CSS = By.cssSelector("[class*='subject']  [gw-displaykey-format-replaces='action']");
	By DUE_DATE_CSS = By.cssSelector("[class*='subject']  [ui-sref*='accounts']");
	By NOTES_CSS = By.cssSelector("[class*='notes']");
	By COMPLETE_CSS   = By.cssSelector("[class*='completed']");
	
		
    public ActivityComponent(WebElement activity){
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(activity);
        ACTIVITY_COMPONENT = activity;
    }
    
    public ActivityComponent(){
        seleniumCommands.waitForPageLoadingToComplete();
    }

    public ActivityComponent completeActivity(){
    	seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(By.cssSelector("div[class='gw-activity-view-wrapper ng-scope gw-activity-border gw-expanded'] button[ng-click='competeActivity(activity)']"));
        ACTIVITY_COMPONENT.findElement(By.cssSelector(COMPLETE_ACTIVITY_BUTTON_SELECTOR)).click();
        seleniumCommands.waitForElementToBeEnabled(ACTIVITY_COMPONENT.findElement(By.cssSelector("[class='gw-completed'] .gw-compelete-status")));
        seleniumCommands.waitForElementToBeEnabled(ACTIVITY_COMPONENT.findElement(By.cssSelector("[class='gw-completed'] i[class='fa fa-check completed-check']")));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public Validation canViewActivitySummary(){
        WebElement firstActivityParent = ACTIVITY_COMPONENT.findElement(By.xpath(".."));
        WebElement activitySummary = firstActivityParent.findElement(By.cssSelector("[ng-show='activity.expanded']"));
        return new Validation(!activitySummary.getAttribute("class").equals("ng-hide"));
    }

	public ActivityComponent clickAddNoteButton() {
		WebElement AddNoteButton = ACTIVITY_COMPONENT.findElement(By.xpath(".."))
				.findElement(By.cssSelector(ADD_NOTE_BUTTON_SELECTOR));
		seleniumCommands.waitForElementToBeVisible(AddNoteButton);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		AddNoteButton.click();
		return this;
	}

    public Validation doesActivityShowCompleted(){
    	seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(ACTIVITY_COMPLETE_LABEL);
       return new Validation(ACTIVITY_COMPONENT.findElement(By.cssSelector(COMPLETE_ACTIVITY_LABEL_SELECTOR))
               .getText()
               .equals(DataConstant.ACTIVITY_COMPLETE_TEXT));
    }

	public Validation doesAddNoteButtonExist() {
		seleniumCommands.waitForElementToDisappear(
				ACTIVITY_COMPONENT.findElement(By.cssSelector(COMPLETE_ACTIVITY_BUTTON_SELECTOR)));
		seleniumCommands.staticWait(1);
		return new Validation(ACTIVITY_COMPONENT.findElement(By.xpath(".."))
				.findElements(By.cssSelector(ADD_NOTE_BUTTON_SELECTOR)).size() > 0);
	}

	public ActivityComponent toggleSummary() {
		seleniumCommands.click(ACTIVITY_COMPONENT);
		return this;
	}

	public ReassignActivityComponent getReassignActivityComponent() {
		WebElement reassignActivityComponent = ACTIVITY_COMPONENT.findElement(ASSIGNEE_DATA);
		return new ReassignActivityComponent(reassignActivityComponent);
	}

	public AccountSummary clickAccountLink() {
		ACTIVITY_COMPONENT
				.findElement(By
						.cssSelector("a[ui-sref='accounts.detail.summary({accountNumber : activity.accountNumber})']"))
				.click();
		return new AccountSummary();
	}

	public ActivityComponent addNoteToNonCompleteActivity() {
		String UUID = seleniumCommands.generateUUID();
		new AddNoteComponent().withTopic("General").withSubject(UUID).withNoteText("UUID").submit()
				.isNodeAddedModalDisplayed().shouldBeEqual("Note added model pop up is not displayed");
		new AlertHandler().closeAlert();
		isNoteAddedToActivity(UUID).shouldBeEqual("Note is not added to activity");
		return this;
	}

	public List<HashMap<String, String>> getActivitiesDataFromUI(List<WebElement> activityElementList) {
		LOGGER.info("Getting activities data from UI");
		List<HashMap<String, String>> activityList = new ArrayList<>();
		HashMap<String, String> activityData;
		for (WebElement ele : activityElementList) {
			activityData = new HashMap<>();
			String userFromUI = this.getTextValueForTheActivityComponant(ele, ASSIGNEE_CSS);
			String loggedInUser = AgentUserName.getValueByUname(data.get("USER"));
			String assignedTo = userFromUI.equalsIgnoreCase(loggedInUser) ? userFromUI : "Me";
			activityData.put(ActivityData.SUBJECT.toString(),
					this.getTextValueForTheActivityComponant(ele, SUBJECT_CSS));
			activityData.put(ActivityData.ASSIGNED_TO.toString(), assignedTo);
			activityData.put(ActivityData.STATUS.toString(), getStatusValue(ele, STATUS_CSS) ? "complete" : "open");
			activityData.put(ActivityData.CREATED_BY.toString(),
					this.getTextValueForTheActivityComponant(ele, CREATED_BY_CSS));
			activityData.put(ActivityData.ACCOUNT_NAME.toString(),
					this.getTextValueForTheActivityComponant(ele, ACCOUNT_NAME_CSS));
			activityList.add(activityData);
		}
		LOGGER.info("Data received from Activities page \n" + activityList);
		return activityList;
	}

	private String getTextValueForTheActivityComponant(WebElement element, By locator) {
		return seleniumCommands.getTextOfTheLocatorByJS(element.findElement(locator));
	}

	private boolean getStatusValue(WebElement element, By locator) {
		boolean status = true;
		try {
			status = seleniumCommands.isElementPresent(element.findElement(STATUS_CSS));
		} catch (NoSuchElementException e) {
			return false;
		}
		return status;
	}

	// Validation

	public Validation isNoteAddedToActivity(String subject) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new Validation(ACTIVITY_COMPONENT.findElement(By.xpath(".."))
				.findElement(By.cssSelector(NOTE_SUBJECT_SELECTOR)).getText(), subject);
	}

	public Validation areNoteFieldsAreMarkedWithMandatoryErrors() {
		return new AddNoteComponent().submit().areRequiredFieldsMarked();
	}
    
	public Validation validatedActivityUIComponant() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(ESCALATION_DATE_LABEL_SELECTOR), ESCALATION_DATE_LABEL).shouldBeEqual("Escalation date label is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CREATED_BY_LABEL_CSS), CREATED_BY_LABEL).shouldBeEqual("Created By label is not matched");
        new Validation(seleniumCommands.getTextAtLocator(DESC_LABEL_CSS), DESCRIPTION_LABEL).shouldBeEqual("Description label is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CREATED_DATE_LABEL_CSS), CREATED_LABEL).shouldBeEqual("Creation date label is not matched");
        new Validation(seleniumCommands.getTextAtLocator(TYPE_LABEL_CSS), TYPE_LABEL).shouldBeEqual("Type label is not matched");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(COMPLETE_ACTIVITY_BUTTON_SELECTOR))).shouldBeTrue("Complete activity button is not present");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(ADD_NOTE_BUTTON_SELECTOR))).shouldBeTrue("Add note button is not present");
        return new Validation(true);
    }
	
	public Validation validatedActivityRowUIComponant() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(PRIORITY_CSS)).shouldBeTrue("Priority date element is not present");
        new Validation(seleniumCommands.isElementPresent(DUE_DATE_CSS)).shouldBeTrue("Due date element is not present");
        new Validation(seleniumCommands.isElementPresent(SUBJECT_CSS)).shouldBeTrue("Subject  element is not present");
        new Validation(seleniumCommands.isElementPresent(ASSIGNEE_CSS)).shouldBeTrue("Assignee  element is not present");
        new Validation(seleniumCommands.isElementPresent(NOTES_CSS)).shouldBeTrue("Notes element is not present");
        new Validation(seleniumCommands.isElementPresent(COMPLETE_CSS)).shouldBeTrue("Complete element is not present");
        return new Validation(true);
    }
}
