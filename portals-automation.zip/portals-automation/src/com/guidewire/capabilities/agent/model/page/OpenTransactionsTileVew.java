package com.guidewire.capabilities.agent.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;

/**
 * @author Darya Fedo
 */
public class OpenTransactionsTileVew {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    private static final By SEARCH_FIELD = By.cssSelector("[ng-model='policyTransactionTableConfig.search']");
    private static final By FILTER_DROPDOWN_LIST = By.cssSelector("[ng-model='policyTransactionTableConfig.transactionStatus']");
    private static final By JOB_NUMBER_COLUMN = By.cssSelector("th[attribute='jobNumber']");
    private static final By STATUS_COLUMN = By.cssSelector("th[attribute='status']");
    private static final By POLICY_NUMBER_COLUMN = By.cssSelector("th[attribute='policyNumber']");
    private static final By TYPE_COLUMN = By.cssSelector("th[attribute='displayType']");
    private static final By PERIOD_STATUS_COLUMN = By.cssSelector("th[attribute='policyDisplayStatus']");
    private static final By EFFECTIVE_DATE_COLUMN = By.cssSelector("th[attribute='policyEffectiveDate']");
    private static final By POLICY_NUMBER_VALES = By.cssSelector("td[title='Policy Number'] span");




    //validations
    public void validateSearchField(){
        seleniumCommands.logInfo("Validating Search field");
        new Validation(seleniumCommands.isElementPresent(SEARCH_FIELD)).shouldBeTrue("Search field is not present on the page");
    }

    public void validateFilter(){
        seleniumCommands.logInfo("Validating Filter field");
        new Validation(seleniumCommands.isElementPresent(FILTER_DROPDOWN_LIST)).shouldBeTrue("Filter field is not present on the page");
        new Validation(seleniumCommands.getAllOptionsFromDropDown(seleniumCommands.findElement(FILTER_DROPDOWN_LIST)).get(0).equals("All")).shouldBeTrue("Default value at filter dropdown list is incorrect");
    }

    public void validateTransactionTableColums(){
        seleniumCommands.logInfo("Validating transaction table columns");
        new Validation(seleniumCommands.isElementPresent(JOB_NUMBER_COLUMN)).shouldBeTrue("Job number columt is not present on the page");
        new Validation(seleniumCommands.isElementPresent(STATUS_COLUMN)).shouldBeTrue("Transaction status column is not present on the page");
        new Validation(seleniumCommands.isElementPresent(POLICY_NUMBER_COLUMN)).shouldBeTrue("Policy number column is not present on the page");
        new Validation(seleniumCommands.isElementPresent(TYPE_COLUMN)).shouldBeTrue("Type column is not present on the page");
        new Validation(seleniumCommands.isElementPresent(PERIOD_STATUS_COLUMN)).shouldBeTrue("Period status column is not present on the page");
        new Validation(seleniumCommands.isElementPresent(EFFECTIVE_DATE_COLUMN)).shouldBeTrue("Effective date column is not present on the page");
    }

    public void validatePolicyNumbersForThreeTypesOfTransactions(){
        seleniumCommands.logInfo("Validating policy numbers for three types of transactions");
        seleniumCommands.clickbyJS(JOB_NUMBER_COLUMN);
        List<WebElement> policyNumberValues = seleniumCommands.findElements(POLICY_NUMBER_VALES);
        new Validation(policyNumberValues.get(0).getText().equals("-")).shouldBeTrue("Submission transactions has policy number while it shouldn't");
        new Validation(policyNumberValues.get(1).findElement(By.cssSelector("a")).getText().matches("\\d*")).shouldBeTrue("Policy Changes transactions has policy number while it shouldn't");
        new Validation(policyNumberValues.get(2).findElement(By.cssSelector("a")).getText().matches("\\d*")).shouldBeTrue("Cancellation transactions has policy number while it shouldn't");
    }

    public void validateAllOpenTransactionTileComponents(){
        seleniumCommands.logInfo("Validating all the components od Transaction tile page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.validateSearchField();
        this.validateFilter();
        this.validateTransactionTableColums();
        this.validatePolicyNumbersForThreeTypesOfTransactions();
    }



}
