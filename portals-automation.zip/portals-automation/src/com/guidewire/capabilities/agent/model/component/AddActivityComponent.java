package com.guidewire.capabilities.agent.model.component;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;

public class AddActivityComponent {

    SeleniumCommands seleniumCommands = new SeleniumCommands();


    final String ADD_ACTIVITY_SELECTOR = "div[ng-if='activityTableConfig.showAddActivity']";
    @FindBy(css = ADD_ACTIVITY_SELECTOR)
    WebElement ADD_ACTIVITY_COMPONENT;

    @FindBy(id = "Type")
    WebElement ADD_ACTIVITY_TYPE_INPUT;

    @FindBy(id = "Subject")
    WebElement ADD_ACTIVITY_SUBJECT_INPUT;
    
    By ADD_ACTIVITY_DUE_DATE_INPUT = By.cssSelector("[ng-model='activityInfoView.dueDate.value'] input");

    @FindBy(css = "[model='activityInfoView.description'] textarea")
    WebElement ADD_ACTIVITY_DESC_INPUT;

    @FindBy(css = "[ng-repeat='tile in tiles']")
    WebElement OPEN_ACTIVITIES;
    
    @FindBy(xpath = "//body")
    WebElement BODY;

    @FindBy(css = "button[ng-click='createNewActivity(newActivityForm, newNoteForm)']")
    static WebElement SUBMIT;

    @FindBy(css = "button[ng-click='cancel()']")
    static WebElement CANCEL;

    @FindBy(css = "[class*='gw-modal']")
    static WebElement MODAL;

    String NO_ACTIVITIES_WARNING =  "div[activities='activities'] span[class='ng-binding']";

    String MODEL_ICON_XPATH = "//*[contains(@class,'gw-fade')]//span[@ng-class='iconClass']";

    @FindBy(css="div.gw-heading.ng-binding")
    WebElement MODLE_HEADER_CSS;
    
    String MODLE_CLASS ="gw-modal-backdrop gw-fade ng-scope gw-in";
    
    String ADD_ACTIVITY_COMP = "[ng-click='showAddActivity()']";

    String OPEN_ACTIVITIES_TABLE_ROWS = "//span[@gw-displaykey-format-replaces='action']";

    public AddActivityComponent(){
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToNotHaveClass(BODY, MODLE_CLASS);
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_ACTIVITY_COMP));
        seleniumCommands.clickbyJS(By.cssSelector(ADD_ACTIVITY_COMP));
        seleniumCommands.waitForElementToNotHaveClass(BODY, MODLE_CLASS);
        seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_ACTIVITY_SELECTOR));
    }

    public AddActivityComponent withActivityTypeByText(String text) {
    		seleniumCommands.waitForLoaderToDisappearFromPage();
            seleniumCommands.waitForElementToBeVisible(By.id("Type"));
    		seleniumCommands.waitForElementToBeClickable(By.id("Type"));
        Select activityType = new Select(seleniumCommands.findElement(By.id("Type")));
        activityType.selectByVisibleText(text);
        return this;
    }

    public AddActivityComponent withSubject(String text) {
    		seleniumCommands.findElement(By.id("Subject")).clear();
    		seleniumCommands.findElement(By.id("Subject")).sendKeys(text);
//        ADD_ACTIVITY_SUBJECT_INPUT.clear();
//        ADD_ACTIVITY_SUBJECT_INPUT.sendKeys(text);
        return this;
    }
    
	public AddActivityComponent withOverDueDate() {
		String date = seleniumCommands.getTextAtLocator(ADD_ACTIVITY_DUE_DATE_INPUT);
		String dueDate = DateUtil.getFutureDate(-2);
		seleniumCommands.type(ADD_ACTIVITY_DUE_DATE_INPUT, dueDate);
		return this;
	}
	
	public AddActivityComponent withDueTomorrowDate() {
		String date = seleniumCommands.getTextAtLocator(ADD_ACTIVITY_DUE_DATE_INPUT);
		String dueDate = DateUtil.getFutureDate(1);
        seleniumCommands.type(ADD_ACTIVITY_DUE_DATE_INPUT, dueDate);
		return this;
	}
	
	public AddActivityComponent withDescription() {
		seleniumCommands.type(ADD_ACTIVITY_DESC_INPUT, seleniumCommands.generateUUID());
		return this;
	}

    public AddActivityComponent submit(){
    		seleniumCommands.waitForElementToBeClickable(By.cssSelector("button[ng-click='createNewActivity(newActivityForm, newNoteForm)']"));
       seleniumCommands.findElement(By.cssSelector("button[ng-click='createNewActivity(newActivityForm, newNoteForm)']")).click();
        return this;
    }

    public AddActivityComponent clickCancelButton(){
    		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[name='newActivityForm']"));
    		seleniumCommands.waitForElementToBeClickable(By.cssSelector("button[ng-click='cancel()']"));
        seleniumCommands.findElement(By.cssSelector("button[ng-click='cancel()']")).click();
        return this;
    }

    public void wasActivityCreatedModalDisplayed(){
        seleniumCommands.waitForElementToBeVisible(MODAL);
        new Validation(MODLE_HEADER_CSS.getText().equals(DataConstant.ACTIVITY_CREATED_MODAL_TEXT)).shouldBeTrue("Alert message incorrect or missing");

    }

    public void validateNoActivityWarning(){
        seleniumCommands.waitForElementToBeVisible(By.xpath(NO_ACTIVITIES_WARNING));
        new Validation(seleniumCommands.findElement(By.cssSelector(NO_ACTIVITIES_WARNING)).getText().equals(DataConstant.NO_ACTIVITIES_WARNING_TEXT)).shouldBeTrue("Activity was created while it shouldn't");
    }

    public String getActivitiesNumber(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Tiles().getCountOnActiveTile();
    }
    public Validation isAddActivityComponentVisible() {
        return new Validation(ThreadLocalObject.getDriver().findElements(By.cssSelector(ADD_ACTIVITY_SELECTOR)).size() > 0);
    }

    public Validation isChooseActivityTypeErrorModalShown() {
    	seleniumCommands.waitForElementToBeVisible(MODAL);
        return new Validation(MODLE_HEADER_CSS.getText().equals(DataConstant.YOU_MUST_CHOOSE_AN_ACTIVITY_TYPE_ERROR_TEXT));
    }

    public Validation isNewlyCreatedActivityPresenedOnPage(String expectedSubject) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBePresent(By.xpath(OPEN_ACTIVITIES_TABLE_ROWS));
        List<WebElement> rows = seleniumCommands.findElements(By.xpath(OPEN_ACTIVITIES_TABLE_ROWS));
        for (WebElement row:rows){
            String subject=row.getText();
            if(subject.equals(expectedSubject)){
                return new Validation(true);
            }
        }
        return new Validation(false);
    }

}
