package com.guidewire.capabilities.agent.model.page;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.AccountData;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseAccountSummaryData;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.portals.qnb.pages.QualificationPage;
import com.guidewire.widgetcomponents.Modal;
import com.guidewire.widgetcomponents.table.Row;
import com.guidewire.widgetcomponents.table.Table;

public class AccountSummary {
    private static Logger LOGGER = Logger.getLogger(AccountSummary.class);
    private final NavBar navBar;
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();

    private static final String ACTIVITIES_TILE_SELECTOR = ".gw-tile[tile-title='Open Activities']";
    private static final String OPEN_QUOTES_TABLE_ROWS = "//table[@class='gw-table ng-scope']/tbody/tr";
    private static final String FIRST_QUOTE = "a[ui-sref='quote.detail.summary({submissionNumber: item.jobNumber})']";
    private static final String POLICY_LINK_CSS = "a[href='#/policies/POLICY-NUM/summary']";
    private static final String OPEN_ACTIVITIES_TILE = ".gw-tile[tile-title='Open Activities']";
    private static final String SUMMARY_TILE = ".gw-tile[tile-title='Summary']";
    private static final String OPEN_QUOTES_TILE = ".gw-tile[tile-title='Open Quotes']";
    private static final String OPEN_TRANSACTION_TILE = ".gw-tile[tile-title='Open Transactions']";
    private static final String OPEN_CLAIMS_TILE = ".gw-tile[tile-title='Claims']";
    private static final String BILLING_TILE = ".gw-tile[tile-title='Billing & Payment']";
    private static final String AUTOMATIC_PAYMENT_TILE = ".gw-tile[tile-title='Automatic Payments']";

    @FindBy(css = "[gw-visuallyhidden-unless='accountInfo.contactName'],[gw-visuallyhidden-unless='policy.product.productName']")
    WebElement TITLE;
    
    @FindBy(css = "gw-account-detail gw-agent-page ng-scope")
    WebElement ACC_SUMMARY;

    @FindBy(className = "gw-summary-container")
    WebElement ACC_SUMMARY_CONTAINER_DETAILS;

    @FindBy(xpath = "//div[contains(@class, 'gw-summary-container')]")
    List<WebElement> ACC_SUMMERY_ALL_DETAILS;

    @FindBy(css = "i.fa.fa-pencil")
    WebElement EDIT_PENCIL_BTN;

    @FindBy(css = "button.gw-btn-primary.ng-binding")
    WebElement ACC_SAVE_CHANGES_BTN;

    @FindBy(css = "button.gw-btn.ng-binding")
    WebElement ACC_CANCEL_CHANGES_BTN;

    @FindBy(xpath = "//*[@id='WorkNumber']")
    WebElement ACC_EDIT_WORK_PHONE_NUMBER;

    @FindBy(xpath = "//*[@id='CellNumber']")
    WebElement ACC_EDIT_CELL_PHONE_NUMBER;

    @FindBy(xpath = "//*[@id='HomeNumber']")
    WebElement ACC_EDIT_HOME_PHONE_NUMBER;

    @FindBy(css = "[model='phone.homeNumber'] label[for*='HomeNumber']")
    WebElement ACC_EDIT_HOME_PHONE_NUMBER_CHECKBOX;

    @FindBy(css = "[model='phone.homeNumber'] label[for*='WorkNumber']")
    WebElement ACC_EDIT_WORK_PHONE_NUMBER_CHECKBOX;

    @FindBy(css = "[model='phone.homeNumber'] label[for*='CellNumber']")
    WebElement ACC_EDIT_CELL_PHONE_NUMBER_CHECKBOX;

    @FindBy(css = "[model='address.addressLine1'] input")
    WebElement ACC_EDIT_ADDRESS_LINE_1;

    @FindBy(css = "[model='address.city'] input")
    WebElement ACC_EDIT_CITY;

    @FindBy(css = "[model='address.postalCode'] input")
    WebElement ACC_EDIT_ZIP_CODE;

    @FindBy(css = "[model='accountInfoCopyView.emailAddress1'] input")
    WebElement ACC_EDIT_EMAIL_ADDRESS;

    @FindBy(css = ACTIVITIES_TILE_SELECTOR)
    WebElement ACTIVITIES_TILE;

    @FindBy(css = "div[gw-activity-schedule]")
    WebElement ACTIVITIES_COMPONENT;

    @FindBy(css = "button[ng-click='showAddActivity()']")
    WebElement ADD_ACTIVITY_BUTTON;

    @FindBy(css = "button[ng-click='newQuote()']")
    WebElement ADD_QUOTE_BUTTON;

    @FindBy(css = "[ui-sref='accounts.detail.claims'],[ui-sref='policies.detail.claims']")
    WebElement CLAIM_TILE;

    @FindBy(css = "[tile-title='Open Transactions']")
    WebElement OPEN_TRANSACTIONS_TILE;

    @FindBy(css = "table[list='gwPolicySummary']")
    WebElement POLICIES;

    @FindBy(css = "table[class='gw-table']")
    WebElement BILL_POLICIES;

    @FindBy(css = "div[tile-title='Open Quotes']")
    WebElement OPEN_QUOTES;

    @FindBy(css = "input[ng-model='quoteTableConfig.search']")
    WebElement SEARCH_FIELD;

    @FindBy(css = "select[ng-model='quoteTableConfig.jobStatus']")
    WebElement QUOTE_JOB_STATUS_DROPDOWNLIST;

    @FindBy(xpath = "//ng-transclude/span")
    WebElement POLICY_PAGE_HOLDER_TITLE;

    private static final String POLICY_PAGE_CHANGE_POLICY = "button[on-click='showChangeForm()']";

    private static final String POLICY_PAGE_RENEW_POLICY = "button[on-click='createPolicyRenewalTransaction()']";

    private static final String POLICY_PAGE_CANCEL_POLICY = "button[on-click='showCancellationForm()']";

    @FindBy(css = "td[title='Job Number'] a[aria-hidden='false']")
    WebElement FIRST_JOB_NUM_CSS;

    private static final By QUOTE_CREATED_TIME = By.cssSelector("th[attribute='createTime']");

    private static final By QUOTE_JOB_NUMBER = By.cssSelector("th[attribute='jobNumber']");

    private static final By QUOTE_TABLE_HEADERS = By.cssSelector("th[style='cursor: pointer;']");

    private static final By QUOTE_JOB_PREMIUM = By.cssSelector("th[attribute='totalPremium']");

    private static final By QUOTE_JOB_STATUS = By.cssSelector("th[attribute='status']");

    private static final By POLICY_LINK = By.cssSelector("a[ui-sref*='policies.detail.summary']");

    public AccountSummary()  {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBePresent(TITLE);
        this.navBar = new NavBar();
    }

    public ClaimsTileView goToClaimTile() {
       new Tiles().selectByTitle("Claims");
        return new ClaimsTileView();
    }

    public BillingTileView goToBillingTile() {
        seleniumCommands.logInfo("Clicking Billing tile button");
        new Tiles().selectByTitle("Billing");
        return new BillingTileView();
    }

    public AccountSummary goToOpenTransactionsTile(){
        new Tiles().selectByTitle("Open Transactions");
        Modal.waitHidden();
        return this;
    }

    public Validation titleContains(String text) {
        return new Validation(seleniumCommands.isTextPresent(TITLE, text));
    }

    public String accountIdFromUrl() {
        String url = null;
        try {
            url = URLDecoder.decode(seleniumCommands.getCurrentUrl().getRef(), "UTF-8");
        } catch(Exception e) {
            throw new Error("Wrong URL encoding provided", e);
        }

        Matcher matcher = Pattern.compile("[\\s\\w-]+\\d+").matcher(url);
        if (matcher.find()) {
            return matcher.group();
        }

        throw new Error("Account id not found in url");
    }

    public AccountSummary goToActivitiesTile(){
       new Tiles().selectByTitle("Open Activities");
       Modal.waitHidden();
       return this;
    }

    public String openFirstJob(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String jobNumber = seleniumCommands.getTextAtLocator(FIRST_JOB_NUM_CSS);
        seleniumCommands.click(FIRST_JOB_NUM_CSS);
        return jobNumber;
    }

    public AccountSummary goToOpenQuotes(){
        new Tiles().selectByTitle("Open Quotes");
        return this;
    }

    public AccountSummary clickAddActivityButton() {
        Modal.waitHidden();
        ADD_ACTIVITY_BUTTON.click();
        return this;
    }

    public QuoteStart clickAddQuoteButton() {
        ADD_QUOTE_BUTTON.click();
        return new QuoteStart();
    }
    public PolicySummary goToFirstPolicyInList() {
        seleniumCommands
                .findElement(By.cssSelector("a[ui-sref='policies.detail.summary({policyNumber:item.policyNumber})']"))
                .click();
        return new PolicySummary();
    }

    public PolicySummary goToPolicyInList() {
        seleniumCommands
                .findElement(By.cssSelector("a[href='#/policies/"+ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())+"/summary']"))
                .click();
        return new PolicySummary();
    }
    
    public PolicyCancelationSummary clickCancellationLineOfBusinessLink(String cancellationJobNum) {
        seleniumCommands.logInfo("Clicking on Line of Bussiness link on Activity that belongs to policy cancellation transaction.");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.cssSelector("[href='#/cancellation/"+ cancellationJobNum + "/summary']") ).click();
        return new PolicyCancelationSummary();
    }

    public void createDraftQuote(){
        new AccountSummary().clickAddQuoteButton()
                .withState(data.get("State"))
                .withProducerByIndex(1)
                .withProductCode(data.get("PolicyType"))
                .submit();
        new QualificationPage().clickCancel();
        new AlertHandler().closeAlert();
    }

    public QuoteSummary goToFirstQuoteInList() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        int table_size= seleniumCommands.findElements(By.xpath(OPEN_QUOTES_TABLE_ROWS)).size();
        if (table_size>0){
            seleniumCommands
                    .findElement(By.cssSelector(FIRST_QUOTE))
                    .click();
        }else{
            new AccountSummary().createDraftQuote();
        }
        return new QuoteSummary();
    }

    public QuoteSummary openQuoteByLink() {
        seleniumCommands.click(By.linkText(data.get("QuoteNumber")));
        return new QuoteSummary();
    }

    public AccountSummary openAccountPageByLink() {
        seleniumCommands.logInfo("Clicking account name link");
        seleniumCommands.click(By.linkText(data.get(PolicyData.ACCOUNT_NAME.toString())));
        return new AccountSummary();
    }

    public Validation isQuotePresented() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation( seleniumCommands.isElementPresent(By.linkText(ThreadLocalObject.getData().get("QuoteNumber").replace("(","").replace(")","") )));
    }

    public AccountSummary searchQuote() {
        SEARCH_FIELD.sendKeys(ThreadLocalObject.getData().get("QuoteNumber"));
        return new AccountSummary();
    }

    public AccountSummary searchQuoteByPartialNumber() {
        String partialNumber = ThreadLocalObject.getData().get("QuoteNumber");
        partialNumber = partialNumber.substring(partialNumber.length()/2);
        SEARCH_FIELD.sendKeys(partialNumber);
        return new AccountSummary();
    }

    public String getSummaryContainerDetails(){
       return ACC_SUMMARY_CONTAINER_DETAILS.getText();
    }

    public  HashMap<String, String> getSummaryAllContainerDetailsHM(String fullName){
        HashMap<String, String > hmSummerDetails = new HashMap<String, String>();
        hmSummerDetails.put(AccountData.ACCOUNT_TITLE.getValue(),TITLE.getText());
        for(WebElement element:ACC_SUMMERY_ALL_DETAILS) {
            String elementName = seleniumCommands.getTextAtLocator(element);

            if(elementName.contains(fullName)){
                hmSummerDetails.put(AccountData.ACCOUNT_ADDRESS.getValue(),elementName.replaceAll("[\n]", " "));
            }else if(elementName.contains("Producer")){
                hmSummerDetails.put(AccountData.ACCOUNT_PRODUCER_CODE.getValue(), elementName.replaceAll("[\n]", " "));
            }else if(elementName.contains("Open")){
                hmSummerDetails.put(AccountData.ACCOUNT_OPEN_CHANGES.getValue(),elementName.replaceAll("[\n]", " "));
            }else if(elementName.contains("Customer")){
                hmSummerDetails.put(AccountData.ACCOUNT_CUSTOMER_STATUS.getValue(),elementName.replaceAll("[\n]", " "));
            }else if(elementName.contains("Total Issued Premium")){
                hmSummerDetails.put(AccountData.ACCOUNT_TOTAL_ISSUED_PREMIUM.getValue(), elementName.replaceAll("[\n]", " "));
            }
        }
        return hmSummerDetails;
    }

    public String getAccountHolderName() {
        return TITLE.getText().split("\\s+\\(")[0];
    }

    public Table getIssuedPolicies() {
        return new Table(POLICIES);
    }


    public Table getIssuedBillPolicies() {
        return new Table(BILL_POLICIES);
    }

    public AccountsLanding goToAccountsLanding() {
        return this.navBar.goToAccountsLanding();
    }

    //Validation

    public Validation isAccountSummaryPageLoaded() {
    	return new  Validation(seleniumCommands.getTextAtLocator(By.xpath("//*[@ng-if='accountInfo.isPerson']/..")).contains(data.get(PolicyData.ACCOUNT_NUMBER.toString())));
    }

    public Validation validateSummaryTileOpened() {
        seleniumCommands.logInfo("Validating Summary tile is opened");
        return new  Validation(new Tiles().getSelectedTileName(), "SUMMARY");
    }

    public Validation isPolicyDisplayedOnAccountPage(String policy){
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_LINK_CSS.replace("POLICY-NUM", policy))));
    }

    public static String jsonData(){
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        return policyData;
    }

    public void validateQuoteTileComponents(){
        seleniumCommands.logInfo("Validating Quote tile ui components");
        new Validation(seleniumCommands.isElementPresent(ADD_QUOTE_BUTTON)).shouldBeTrue("Add quote button is not presented");
        new Validation(seleniumCommands.isElementPresent(SEARCH_FIELD)).shouldBeTrue("Search field is not presented");
        new Validation(seleniumCommands.isElementPresent(QUOTE_JOB_STATUS_DROPDOWNLIST)).shouldBeTrue("Job filter is not presented");
        new Validation(seleniumCommands.getAllOptionsFromDropDown(QUOTE_JOB_STATUS_DROPDOWNLIST).get(1).equals("Open - Not Bound")).shouldBeTrue("Job filter default value is incorrect.");
        new Validation(seleniumCommands.findElements(QUOTE_TABLE_HEADERS).size()==6).shouldBeTrue("Some of the Quote table headers is missing.");
        new Validation(seleniumCommands.isElementPresent(QUOTE_CREATED_TIME)).shouldBeTrue("Created column is missing");
        new Validation(seleniumCommands.isElementPresent(QUOTE_JOB_NUMBER)).shouldBeTrue("Quote column is missing");
        new Validation(seleniumCommands.isElementPresent(QUOTE_JOB_PREMIUM)).shouldBeTrue("Premium column is missing");
        new Validation(seleniumCommands.isElementPresent(QUOTE_JOB_STATUS)).shouldBeTrue("Status column is missing");
    }

    public static void verifyAccountSummaryHomePage(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--116: Verify Summary On Account Details Page");
        Tiles tiles = new Tiles();
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData= ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        HashMap<String, List<String>> backEndDataList= ParseAccountSummaryData.getAccountSummaryDataFromBackEndList(policyData);
        String accountHolderName = backEndData.get(AccountData.ACCOUNT_NAME.getValue());
        AccountSummary as = openAccountSummary(backEndData);
        HashMap<String, String> hm = as.getSummaryAllContainerDetailsHM(accountHolderName);
        List<String> policyNumberList = new ArrayList<String>();
        List<String>displayStatusList= new ArrayList<String>();
        List<String> effectiveDateList= new ArrayList<String>();
        List<String> primaryInsuredNameList= new ArrayList<String>();
        List<String>expirationDateList= new ArrayList<String>();

        for (Row r : as.getIssuedPolicies().getRows()) {
            displayStatusList.add(r.getCellByColumnTitle("STATUS").getText());
            policyNumberList.add(r.getCellByColumnTitle("POLICY NUMBER").getText());
            primaryInsuredNameList.add(r.getCellByColumnTitle("NAMED INSURED").getText());
            effectiveDateList.add(r.getCellByColumnTitle("EFFECTIVE DATE").getText());
            expirationDateList.add(r.getCellByColumnTitle("EXPIRATION DATE").getText());
        }

        // User MapCompare

        new Validation(hm.get(AccountData.ACCOUNT_TITLE.getValue()), backEndData.get(AccountData.ACCOUNT_TITLE.getValue())).shouldBeEqual( "Account Holder Title Did Not Match" );
        if(!System.getProperty("platform").equalsIgnoreCase("diamond")){
            new Validation(hm.get(AccountData.ACCOUNT_ADDRESS.getValue()), backEndData.get(AccountData.ACCOUNT_ADDRESS.getValue())).shouldBeEqual( "Account Holder Address Did Not Match" );
        }
        new Validation(hm.get(AccountData.ACCOUNT_PRODUCER_CODE.getValue()), backEndData.get(AccountData.ACCOUNT_PRODUCER_CODE.getValue())).shouldBeEqual( "Account Holder Producer Code Did Not Match" );
        new Validation(hm.get(AccountData.ACCOUNT_OPEN_CHANGES.getValue()), backEndData.get(AccountData.ACCOUNT_OPEN_CHANGES.getValue())).shouldBeEqual( "Account Holder Open Changes Did Not Match" );
        new Validation(hm.get(AccountData.ACCOUNT_CUSTOMER_STATUS.getValue()), backEndData.get(AccountData.ACCOUNT_CUSTOMER_STATUS.getValue())).shouldBeEqual( "Account Holder Customer Status Did Not Match" );
        new Validation( hm.get(AccountData.ACCOUNT_TOTAL_ISSUED_PREMIUM.getValue()), backEndData.get(AccountData.ACCOUNT_TOTAL_ISSUED_PREMIUM.getValue())).shouldBeEqual( "Account Holder Premium Did Not Match" );
        new Validation(displayStatusList,backEndDataList.get(AccountData.ACCOUNT_ISSUED_POLICIES_DISPLAY_STATUS.getValue())).shouldBeEqual("Policy Values are not equal");
        new Validation(policyNumberList,backEndDataList.get(AccountData.ACCOUNT_ISSUED_POLICIES_POLICY_NUMBER.getValue())).shouldBeEqual("Display Status Values are not equal");
        new Validation(primaryInsuredNameList,backEndDataList.get(AccountData.ACCOUNT_ISSUED_POLICIES_NAMED_INSURED.getValue())).shouldBeEqual("Primary Insured Names are not equal");
        new Validation(seleniumCommands.findElement(By.cssSelector(as.SUMMARY_TILE)).getText().replaceAll("[\n]", " "),backEndData.get(AccountData.ACCOUNT_TILE_SUMMARY.getValue())).shouldBeEqual( "Summary Tile did not match" );
        new Validation(seleniumCommands.findElement(By.cssSelector(as.OPEN_ACTIVITIES_TILE)).getText().replaceAll("[\n]", " "),backEndData.get(AccountData.ACCOUNT_TILE_OPEN_ACTIVITIES.getValue())).shouldBeEqual( "Tile value for Open Activities did not match" );
        new Validation(seleniumCommands.findElement(By.cssSelector(as.OPEN_QUOTES_TILE)).getText().replaceAll("[\n]", " "),backEndData.get(AccountData.ACCOUNT_TILE_OPEN_QUOTES.getValue())).shouldBeEqual( "Tile value for Open Quotes did not match" );
        new Validation(as.EDIT_PENCIL_BTN.isDisplayed()).shouldBeTrue("Edit button is not displayed");
        tiles.isTilePresent("Open Transactions").shouldBeTrue("Open Transactions tile not present");
        new Validation(seleniumCommands.findElement(By.cssSelector(as.OPEN_CLAIMS_TILE)).getText().replaceAll("[\n]", " "),backEndData.get(AccountData.ACCOUNT_TILE_CLAIMS.getValue())).shouldBeEqual( "Tile value for Claims did not match" );
        new Validation(seleniumCommands.findElement(By.cssSelector(as.BILLING_TILE)).getText().replaceAll("[\n]", " "),backEndData.get(AccountData.ACCOUNT_TILE_BILLING.getValue())).shouldBeEqual( "Tile value for Billing did not match" );
        /*
          Validation failing due to time difference between data generator and selenium driver systems

          new Validation(effectiveDateList,backEndDataList.get(AccountData.ACCOUNT_ISSUED_POLICIES_EFFECTIVE_DATE.getValue())).shouldBeEqual("Effective Date are not equal");
          new Validation(expirationDateList,backEndDataList.get(AccountData.ACCOUNT_ISSUED_POLICIES_EXPIRATION_DATE.getValue())).shouldBeEqual("Expiration Date Values are not equal");
        */
    }


    public static void verifyMissingMandatoryValuesWhileEditingContactInformation(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--124: Verify Missing Mandatory Values While Editing Contact Information");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);
        if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
            as.ACC_EDIT_ADDRESS_LINE_1.clear();
            as.ACC_EDIT_CITY.clear();
            as.ACC_EDIT_ZIP_CODE.clear();
        }else {
            seleniumCommands.type(as.ACC_EDIT_ADDRESS_LINE_1, "");
            seleniumCommands.type(as.ACC_EDIT_CITY, " ");
            seleniumCommands.type(as.ACC_EDIT_ZIP_CODE, "");
            seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        }
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_ADDRESS_LINE_1), "This is a required field").shouldBeEqual("Error message not shown");
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_CITY), "This is a required field").shouldBeEqual("Error message not shown");
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_ZIP_CODE), "This is a required field").shouldBeEqual("Error message not shown");
    }

    public static void verifyInvalidZipCodeWhileEditingContactDetails(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--125: Verify Invalid Zip Code While Editing Contact Details");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);

        seleniumCommands.type(as.ACC_EDIT_ZIP_CODE, "ABCD");
        seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_ZIP_CODE), "Please enter a valid ZIP code.").shouldBeEqual("Error message not shown");
    }

    public static void verifyInvalidPhoneNumberWhileEditingContactDetails(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--126: Verify Invalid Phone Number While Editing Contact Details");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);
        seleniumCommands.type(as.ACC_EDIT_HOME_PHONE_NUMBER,"234" );
        seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_HOME_PHONE_NUMBER), "Value entered must be a valid phone number").shouldBeEqual("Error message not shown");
        seleniumCommands.type(as.ACC_EDIT_WORK_PHONE_NUMBER,"234" );
        seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_WORK_PHONE_NUMBER), "Value entered must be a valid phone number").shouldBeEqual("Error message not shown");
        seleniumCommands.type(as.ACC_EDIT_CELL_PHONE_NUMBER,"234" );
        as.ACC_SAVE_CHANGES_BTN.click();
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_CELL_PHONE_NUMBER), "Value entered must be a valid phone number").shouldBeEqual("Error message not shown");
    }

    public static void verifyInvalidEmailIdWhileEditingContactDetails(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--116:Verify Invalid EmailId While Editing Contact Details");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);
        seleniumCommands.type(as.ACC_EDIT_EMAIL_ADDRESS,"ABC" );
        seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        as.ACC_SAVE_CHANGES_BTN.click();
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_EMAIL_ADDRESS), "Value must be a valid email address").shouldBeEqual("Error message not shown");
    }

    public static void verifyMissingHomePhoneWhenSetAsPrimaryNumberWhileEditingContactDetails(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--129:Verify Missing Home Phone When Set As Primary Number While Editing Contact Details");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);
        as.ACC_EDIT_HOME_PHONE_NUMBER.clear();
        seleniumCommands.click(as.ACC_EDIT_HOME_PHONE_NUMBER_CHECKBOX);
        seleniumCommands.click(as.ACC_SAVE_CHANGES_BTN);
        new Validation(seleniumCommands.getErrorMessageForDatePicker(as.ACC_EDIT_HOME_PHONE_NUMBER), "This is a required field").shouldBeEqual("Error message not shown");
    }

    public static void verifyCancelEditContactDetailAction(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--128:Verify Cancel Edit Contact Detail Action");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        String accountHolderName = backEndData.get(AccountData.ACCOUNT_NAME.getValue());
        AccountSummary as = openAccountSummary(backEndData);
        HashMap<String, String> hm = as.getSummaryAllContainerDetailsHM(accountHolderName);
        seleniumCommands.click(as.EDIT_PENCIL_BTN);
        seleniumCommands.type(as.ACC_EDIT_ADDRESS_LINE_1,"Changed Address" );
        seleniumCommands.type(as.ACC_EDIT_CITY,"Changed City" );
        seleniumCommands.type(as.ACC_EDIT_ZIP_CODE,"99501" );
        seleniumCommands.type(as.ACC_EDIT_CELL_PHONE_NUMBER,"333-333-3333" );
        seleniumCommands.type(as.ACC_EDIT_EMAIL_ADDRESS,"change@guidewire.com" );
        seleniumCommands.click(as.ACC_CANCEL_CHANGES_BTN);
        if(!System.getProperty("platform").equalsIgnoreCase("diamond")){
            new Validation(hm.get(AccountData.ACCOUNT_ADDRESS.getValue()), backEndData.get(AccountData.ACCOUNT_ADDRESS.getValue())).shouldBeEqual( "Account Holder Address Did Not Match" );
        }
    }


    public static void verifyViewPolicyFromAccountSummaryPage(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--131:Verify View Policy From Account Summary Page");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        String accountHolderName = backEndData.get(AccountData.ACCOUNT_NAME.getValue());
        AccountSummary as = openAccountSummary(backEndData);
        seleniumCommands.waitForLoaderToDisappearFromPage(3);

        HashMap<String, String> hm = as.getSummaryAllContainerDetailsHM(accountHolderName);
        WebElement firstPolicyNumber = as.getIssuedPolicies().getRows().get(0).getCellByColumnTitle("POLICY NUMBER").getElement();
        if(ThreadLocalObject.getBrowserName().equals("internet explorer")) {
            seleniumCommands.clickbyJS(POLICY_LINK);
        }else
            seleniumCommands.click(firstPolicyNumber);
        seleniumCommands.waitForElementToBePresent(By.linkText(accountHolderName));
        new Validation(seleniumCommands.isElementPresent(By.linkText(accountHolderName))).shouldBeTrue( "Account Holder Not displayed on Policy page" );
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_CHANGE_POLICY))).shouldBeTrue("CHANGE POLICY button is missing, Policy page did not open");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_RENEW_POLICY))).shouldBeTrue("RENEW POLICY button is missing, Policy page did not open");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_CANCEL_POLICY))).shouldBeTrue("CANCEL POLICY button is missing, Policy page did not open");
    }

    public static void verifyViewPolicyFromAccountDetailsBilling(String browserName) throws Exception {
        LOGGER.info("Running Test: GPA--132: View Policy From Account Details Billing");
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        HashMap<String, String> backEndData = ParseAccountSummaryData.getAccountSummaryDataFromBackEnd(policyData);
        String accountHolderName = backEndData.get(AccountData.ACCOUNT_NAME.getValue());
        AccountSummary as = openAccountSummary(backEndData);
        new Tiles().selectByTitle("Billing");
        seleniumCommands.click( as.getIssuedBillPolicies().getRows().get(0).getCells().get(0).getElement());
        seleniumCommands.waitForElementToBePresent(By.linkText(accountHolderName));
        new Validation(seleniumCommands.isElementPresent(By.linkText(accountHolderName))).shouldBeTrue( "Account Holder Not displayed on Policy page" );
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_CHANGE_POLICY))).shouldBeTrue("CHANGE POLICY button is missing, Policy page did not open");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_RENEW_POLICY))).shouldBeTrue("RENEW POLICY button is missing, Policy page did not open");
        new Validation(seleniumCommands.isElementPresent(By.cssSelector(POLICY_PAGE_CANCEL_POLICY))).shouldBeTrue("CANCEL POLICY button is missing, Policy page did not open");
    }

    private static AccountSummary openAccountSummary(HashMap<String, String> dataMap)
    {
        String accountNumber = dataMap.get(AccountData.ACCOUNT_NUMBER.getValue());
        new LoginPage().login();
        AgentDashboard ad = new AgentDashboard();
        return ad.goToAccounts().openAccountUsingAccountNumber(accountNumber);
    }

    public Validation isOpenActivitiesTileOpened(){
        return new Validation(seleniumCommands.isElementPresent(ACTIVITIES_COMPONENT));
    }
}

