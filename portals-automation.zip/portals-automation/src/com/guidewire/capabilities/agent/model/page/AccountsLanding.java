package com.guidewire.capabilities.agent.model.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;
import com.guidewire.widgetcomponents.table.Table;

public class AccountsLanding {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "h1")
    WebElement TITLE;

    @FindBy(css = "[accounts='pageListData.items']")
    WebElement PAGINATED_TABLE;

    @FindBy(css = "[ng-click='setCurrentFilter(recentlyViewedFilter)'][class*='active']")
    WebElement DEFAULT_TILE;

    @FindBy(css = "[ng-click='setCurrentFilter(recentlyViewedFilter)']")
    WebElement RECENTLY_VIEWED_CSS;

    @FindBy(css = "[ng-click='setCurrentFilter(personalAccountsFilter)']")
    WebElement PERSONAL_ACCOUNTS_CSS;

    @FindBy(xpath = "(//td[@title='Account'])[1]//a")
    WebElement FIRST_ACCOUNT_LINK_XPATH;

    @FindBy(css = "[ng-click='setCurrentFilter(recentlyCreatedFilter)']")
    WebElement RECENTLY_CREATED_CSS;

    private String POLICIES_COUNT_LINK = "td[attribute='policies'] a[href*='ACC-NUM']";

    private String OPEN_ACTIVITIES_LINK = "[href*='#/accounts/ACC-NUM/activities']";

    private String ACC_LINK_CSS = "[href*='#/accounts/ACC-NUM/summary']";

    public AccountsLanding() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(PAGINATED_TABLE);
    }

    public AccountsLanding showPersonalAccounts() {
        seleniumCommands.click(PERSONAL_ACCOUNTS_CSS);
        seleniumCommands.waitForElementToBeVisible(PAGINATED_TABLE);
        return this;
    }

    public AccountsLanding showRecentlyCreated() {
        new Tiles().selectByTitle("Recently Created");
        seleniumCommands.waitForElementToBeVisible(PAGINATED_TABLE);
        return this;
    }

    public Table getTable() {
        return new Table(PAGINATED_TABLE);
    }

    public AccountSummary clickPolicyCountLink() {
        this.showRecentlyCreated();
        seleniumCommands.clickbyJS(By.cssSelector(POLICIES_COUNT_LINK.replace("ACC-NUM", ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))));
        return new AccountSummary();
    }

    public AccountSummary clickOpenpenActivitiesLink() {
        this.showRecentlyCreated();
        seleniumCommands.clickbyJS(By.cssSelector(OPEN_ACTIVITIES_LINK.replace("ACC-NUM", ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))));
        return new AccountSummary();
    }

    public AccountSummary openAccountUsingAccountNumber(String accountNumber) {
    		if(accountNumber.contains(" ") || accountNumber.contains("'") )
    		{
    			accountNumber = accountNumber.replaceAll(" ", "%20").replaceAll("'", "\\");
    		}
        this.showRecentlyCreated();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(By.cssSelector(ACC_LINK_CSS.replace("ACC-NUM", accountNumber)));
        return new AccountSummary();
    }

    public AccountSummary clickAccountNameLink() {
        this.showRecentlyCreated();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String accountName = ThreadLocalObject.getData().get(PolicyData.ACCOUNT_FIRST_NAME.toString()) + " " + ThreadLocalObject.getData().get(PolicyData.ACCOUNT_LAST_NAME.toString());
        seleniumCommands.waitForElementToBeClickable(By.linkText(accountName));
        seleniumCommands.clickbyJS(By.linkText(accountName));
        return new AccountSummary();
    }

    public AccountSummary openFirstAccount() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(FIRST_ACCOUNT_LINK_XPATH);
        return new AccountSummary();
    }

    public Validation checkTitle(){
        return new Validation(this.TITLE.getText(), "Accounts");
    }

    public Validation checkDefaultTile(){
        String tileName = seleniumCommands.getTextAtLocator(this.DEFAULT_TILE.findElement(By.cssSelector("div[class*='gw-tile-title']")));
        return new Validation(tileName,"RECENTLY VIEWED");
    }
}
