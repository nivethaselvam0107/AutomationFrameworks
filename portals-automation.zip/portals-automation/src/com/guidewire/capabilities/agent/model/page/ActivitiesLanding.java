package com.guidewire.capabilities.agent.model.page;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.data.ActivityData;
import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.ActivityComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.table.Table;
import com.guidewire.widgetcomponents.tile.Tile;

/**
 * Created by skrishnappanavar on 22/06/2016.
 */
public class ActivitiesLanding {
    private final NavBar navBar;
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    Logger LOGGER = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "h1")
	WebElement TITLE;

	@FindBy(css = "gw-accounts-table.ng-isolate-scope")
	WebElement PAGINATED_TABLE;

    @FindBy(css = "div[tile-title*='Your Open'][class*=active]")
    WebElement DEFAULT_TILE;
    
    @FindBy(css = "div[tile-title*='Your Open']")
    WebElement OPEN_BY_ME_TILE_CSS;
    
    @FindBy(css = "div[tile-title*='Your Completed']")
    WebElement COMPLETED_BY_ME_TILE_CSS;
    
    @FindBy(css = "div[tile-title*='Created By You']")
    WebElement CREATED_BY_ME_TILE_CSS;
    
    @FindBy(css = "div[tile-title*='All Open']")
    WebElement ALL_OPEN_TILE_CSS;
    
    @FindBy(css = "div[tile-title*='All Completed']")
    WebElement ALL_COMPLETED_TILE_CSS;
    
    @FindBy(css = "[ng-show*='Overdue']")
    WebElement OVERDUE_SECTION_CSS;
    
    @FindBy(css = "[ng-show*='activitiesToday']")
    WebElement DUE_TODAY_SECTION_CSS;
    
    @FindBy(css = "[ng-show*='activitiesTomorrow']")
    WebElement DUE_TOMORROW_SECTION_CSS;
    
    @FindBy(css = "[ng-show*='activitiesFuture']")
    WebElement DUE_FUTURE_SECTION_CSS;
    
    @FindBy(css = "[ng-show*='activitiesThisWeek']")
    WebElement DUE_THISWEEK_SECTION_CSS;
    
    String ACC_LINK_CSS = "[href*='#/accounts/ACC-NUM/summary']";

	By ADVANCED_FILTER_LINK = By.cssSelector("[ng-hide='showAdvancedFilter']");

	By STATUS_FILTERS_SECTION = By.cssSelector("[advanced-filter='activityStatusFilter']");
	By STATUS_OPEN_FILTER = By.cssSelector("label[for='openStatus-checkbox']");
	By STATUS_COMPLETE_FILTER = By.cssSelector("label[for='completeStatus-checkbox']");
	By STATUS_CANCELED_FILTER = By.cssSelector("label[for='canceledStatus-checkbox']");
	By STATUS_SKIPPED_FILTER = By.cssSelector("label[for='skippedStatus-checkbox']");

	By ASSIGNMENT_FILTERS_SECTION = By.cssSelector("[advanced-filter='activityAssignmentFilter']");
	By ASSIGNMENT_TO_ME_FILTER = By.cssSelector("label[for='assignedToMeAssignment-checkbox']");
	By ASSIGNMENT_TO_OTHERS_FILTER = By.cssSelector("label[for='assignedToOthersAssignment-checkbox']");

	By PRIORITY_FILTERS_SECTION = By.cssSelector("[advanced-filter='activityPriorityFilter']");
	By PRIORITY_URGENT_FILTER = By.cssSelector("label[for='urgentPriority-checkbox']");
	By PRIORITY_HIGH_FILTER = By.cssSelector("label[for='highPriority-checkbox']");
	By PRIORITY_NORMAL_FILTER = By.cssSelector("label[for='normalPriority-checkbox']");
	By PRIORITY_LOW_FILTER = By.cssSelector("label[for='lowPriority-checkbox']");

	By CREATED_BY_FILTERS_SECTION = By.cssSelector("[advanced-filter='activityCreatedByFilter']");
	By CREATED_BY_ME_FILTER = By.cssSelector("label[for='createdByMeCreated By-checkbox']");
	By CREATED_BY_OTHERS_FILTER = By.cssSelector("label[for='createdByOthersCreated By-checkbox']");

	By TYPE_FILTERS_SECTION = By.cssSelector("[advanced-filter='activityTypeFilter']");
	By TYPE_REMINDER_FILTER = By.cssSelector("label[for='reminderType-checkbox']");
	By TYPE_INTERVIEW_FILTER = By.cssSelector("label[for='interviewType-checkbox']");

	By ACTIVITY_SUBJECT = By.cssSelector("[class='gw-subject'] span");

	public ActivitiesLanding() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        seleniumCommands.waitForElementToBeVisible(TITLE);

        this.navBar = new NavBar();
        this.navBar.isActivitiesLandingSelected().shouldBeTrue();
    }

    public Table getTable() {
        return new Table(PAGINATED_TABLE);
    }

    public Validation checkTitle(){
        return new Validation(this.TITLE.getText(), "Activities");
    }

    public Validation checkDefaultTile(){
        String tileName = seleniumCommands.getTextAtLocator(this.DEFAULT_TILE.findElement(By.cssSelector("div[class*='title']")));
        return new Validation(tileName,"YOUR OPEN");
    }
    
    public AccountSummary openAccountUsingAccountNumber(String accountNumber) {
    		seleniumCommands.click(By.cssSelector(ACC_LINK_CSS.replace("ACC-NUM", accountNumber)));
        return new AccountSummary();
    }
    
    public ActivitiesLanding openMyOpenTile() {
    	new Tiles().selectByTitle("Your Open");
        return this;
    }
    
    public ActivitiesLanding openMyCompletedTile() {
		new Tiles().selectByTitle("Your Completed");
        return this;
    }
    
    public ActivitiesLanding openCreatedByMeTile() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Tiles().selectByTitle("Created By You");
        return this;
    }
    
    public ActivitiesLanding openAllOpenTile() {
		new Tiles().selectByTitle("All Open");
        return this;
    }
    
    public ActivitiesLanding openAllCompletedTile() {
		new Tiles().selectByTitle("All Completed");
        return this;
    }
    
	private void selectTile(WebElement tileElement) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.staticWait(2);
		Tile tile = new Tile(tileElement);
		tile.click();
		tile.waitForTileToBeSelected();
	}

	public ActivitiesLanding clickAdvancedFiltersLink() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.findElement(ADVANCED_FILTER_LINK).click();
		return this;
	}

	public ActivitiesLanding clickUrgentFilter(){
		seleniumCommands.logInfo("Clicking Urgent filter");
		seleniumCommands.clickbyJS(PRIORITY_URGENT_FILTER);
		return this;
	}

    //Validation

	public void validateAllAdvancedFiltersPresented(){
		seleniumCommands.logInfo("Validating all the advanced filters are presented.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(STATUS_FILTERS_SECTION).findElement(STATUS_OPEN_FILTER))).shouldBeTrue("Open filter is not present under Status section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(STATUS_FILTERS_SECTION).findElement(STATUS_CANCELED_FILTER))).shouldBeTrue("Canceled filter is not present under Status section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(STATUS_FILTERS_SECTION).findElement(STATUS_COMPLETE_FILTER))).shouldBeTrue("Complete filter is not present under Status section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(STATUS_FILTERS_SECTION).findElement(STATUS_SKIPPED_FILTER))).shouldBeTrue("Skipped filter is not present under Status section");

		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(ASSIGNMENT_FILTERS_SECTION).findElement(ASSIGNMENT_TO_ME_FILTER))).shouldBeTrue("Assignment to me filter is not present under Assignment section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(ASSIGNMENT_FILTERS_SECTION).findElement(ASSIGNMENT_TO_OTHERS_FILTER))).shouldBeTrue("Assignment to others filter is not present under Assignment section");

		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(PRIORITY_FILTERS_SECTION).findElement(PRIORITY_URGENT_FILTER))).shouldBeTrue("Urgent filter is not present under Priority section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(PRIORITY_FILTERS_SECTION).findElement(PRIORITY_HIGH_FILTER))).shouldBeTrue("High filter is not present under Priority section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(PRIORITY_FILTERS_SECTION).findElement(PRIORITY_NORMAL_FILTER))).shouldBeTrue("Normal filter is not present under Priority section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(PRIORITY_FILTERS_SECTION).findElement(PRIORITY_LOW_FILTER))).shouldBeTrue("Low filter is not present under Priority section");

		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(CREATED_BY_FILTERS_SECTION).findElement(CREATED_BY_ME_FILTER))).shouldBeTrue("Created by me filter is not present under Created by section");
		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(CREATED_BY_FILTERS_SECTION).findElement(CREATED_BY_OTHERS_FILTER))).shouldBeTrue("Created by others filter is not present under Created by section");

		new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(TYPE_FILTERS_SECTION))).shouldBeTrue("Type section is missing");
		try {
			new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(TYPE_FILTERS_SECTION).findElement(TYPE_INTERVIEW_FILTER))).shouldBeTrue("Interview filter is not present under Type section");
			new Validation(seleniumCommands.isElementPresent(seleniumCommands.findElement(TYPE_FILTERS_SECTION).findElement(TYPE_REMINDER_FILTER))).shouldBeTrue("Reminder filter is not present under Type section");
		}catch (Exception e){}
	}

	public Validation isActivityPresentOnAdvancedFiltersPage(String activitySubject){
		seleniumCommands.logInfo("Checking if activity is present on advanced filters page.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		for (WebElement element : seleniumCommands.findElements(ACTIVITY_SUBJECT)){
			if (element.getText().equals(activitySubject))
				return new Validation(true);
		}
		return new Validation(false);
	}
    
    public Validation isActivitiesLandingPageOpened(){
    		LOGGER.info("Checking if activity landing page is opened");
        return new Tiles().isTilePresent("Your Open");
    }
    
	public Validation areActivitiesLandingPageTilesDisplayed()
	{
		seleniumCommands.logInfo("Checking if activity landing page is opened");
		Tiles tiles = new Tiles();
		tiles.isTilePresent("Your Open").shouldBeTrue("My Open tile is not present");
		tiles.isTilePresent("Your Completed").shouldBeTrue("Completed By Me tile is not present");
		tiles.isTilePresent("Created By You").shouldBeTrue("Created By Me tile is not present");
		tiles.isTilePresent("All Completed").shouldBeTrue("All Completed tile is not present");
		tiles.isTilePresent("All Open").shouldBeTrue("All Open tile is not present");
		return new Validation(true);
	}
	
	public Validation areActivityScheduleSectionsListed()
	{
		seleniumCommands.logInfo("Checking if activity landing page is opened");
		new Validation(seleniumCommands.isElementPresent(OVERDUE_SECTION_CSS)).shouldBeTrue("OverDue section is not present");
		new Validation(seleniumCommands.isElementPresent(DUE_TODAY_SECTION_CSS)).shouldBeTrue("Due Today section is not present");
		new Validation(seleniumCommands.isElementPresent(DUE_TOMORROW_SECTION_CSS)).shouldBeTrue("Due tomorrow section is not present");
		new Validation(seleniumCommands.isElementPresent(DUE_FUTURE_SECTION_CSS)).shouldBeTrue("Due future section is not present");
		return new Validation(true);
	}
	
    public void validateMyOpenActivitiesData(){
        	LOGGER.info("Validating My open activity data");
        	openMyOpenTile();
        	List<HashMap<String, String>> activityUIData = new ActivityComponent().getActivitiesDataFromUI(new ActivitiesScheduleComponent().getAllListedActivities());
        	this.compareActivityStatusData(activityUIData, "open");
        	this.compareActivityAssigneeData(activityUIData, DataConstant.ME);
    }
    
	public void validateMyCompletedActivitiesData() {
		LOGGER.info("Validating My completed activity data");
		openMyCompletedTile();
		List<HashMap<String, String>> activityUIData = new ActivityComponent()
				.getActivitiesDataFromUI(new ActivitiesScheduleComponent().getAllListedActivities());
		this.compareActivityStatusData(activityUIData, "complete");
		this.compareActivityAssigneeData(activityUIData, DataConstant.ME);
	}
    
	public void validateCreatedByMeActivitiesData() {
		LOGGER.info("Validating My created activity data");
		openCreatedByMeTile();
		List<HashMap<String, String>> activityUIData = new ActivityComponent()
				.getActivitiesDataFromUI(new ActivitiesScheduleComponent().getAllListedActivities());
		this.compareActivityCreatedByData(activityUIData, ThreadLocalObject.getData().get("USER_NAME"));
	}

	public void validateAllOpenActivitiesData() {
		LOGGER.info("Validating All open activity data");
		openAllOpenTile();
		List<HashMap<String, String>> activityUIData = new ActivityComponent()
				.getActivitiesDataFromUI(new ActivitiesScheduleComponent().getAllListedActivities());
		this.compareActivityStatusData(activityUIData, "open");
	}
    
	public void validateAllCompletedActivitiesData() {
		LOGGER.info("Validating All completed activity data");
		openAllCompletedTile();
		List<HashMap<String, String>> activityUIData = new ActivityComponent()
				.getActivitiesDataFromUI(new ActivitiesScheduleComponent().getAllListedActivities());
		this.compareActivityStatusData(activityUIData, "complete");
	}
    
	private void compareActivityStatusData(List<HashMap<String, String>> uiData, String status) {
		for (int i = 0; i < uiData.size(); i++) {
			HashMap<String, String> map = uiData.get(i);
			if (!map.get(ActivityData.STATUS.toString()).equalsIgnoreCase(status)) {
				new Validation(map.get(ActivityData.STATUS.toString()), status)
						.shouldBeEqual("\n==============>>>>>>>THIS ACTIVITY DATA==============>>>>>>>\n" + map
								+ " does not have correct status");
			}
		}
	}

	private void compareActivityAssigneeData(List<HashMap<String, String>> uiData, String assignee) {
		for (int i = 0; i < uiData.size(); i++) {
			HashMap<String, String> map = uiData.get(i);
			if (!!map.get(ActivityData.ASSIGNED_TO.toString()).equalsIgnoreCase(assignee)) {
				new Validation(map.get(ActivityData.ASSIGNED_TO.toString()), assignee)
						.shouldBeEqual("\n==============>>>>>>>THIS ACTIVITY DATA==============>>>>>>>\n" + map
								+ " does not have correct asignee");
			}
		}
	}

	private void compareActivityCreatedByData(List<HashMap<String, String>> uiData, String createdBy) {
		for (int i = 0; i < uiData.size(); i++) {
			HashMap<String, String> map = uiData.get(i);
			if (!map.get(ActivityData.CREATED_BY.toString()).equalsIgnoreCase(createdBy)) {
				new Validation(map.get(ActivityData.CREATED_BY.toString()), createdBy)
						.shouldBeEqual("\n==============>>>>>>>THIS ACTIVITY DATA==============>>>>>>>\n" + map
								+ " does not have correct Creator");
			}
		}
    }
}
