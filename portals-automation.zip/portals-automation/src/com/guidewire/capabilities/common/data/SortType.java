package com.guidewire.capabilities.common.data;

import com.guidewire.common.util.EnumHelper;

public enum SortType {

    ASC("asc"),
    DESC("desc");

    private final String sortType;

    SortType(final String sortType) {
        this.sortType = sortType;
    }

    @Override
    public String toString() {
        return this.sortType;
    }

    public static SortType fromString(String name) {
        return EnumHelper.fromString(SortType.class, name);
    }
}