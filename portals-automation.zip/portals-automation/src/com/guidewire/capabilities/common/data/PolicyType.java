package com.guidewire.capabilities.common.data;

public enum PolicyType {

    ALL("All Lines of Business"),
    BO("BusinessOwners"),
    GL("General Liability"),
    HO("Homeowners"),
    IM("Inland Marine"),
    PA("Personal Auto"),
    WC( "Workers' Compensation"),
    CP( "CommercialProperty");

    private final String policyType;

    private PolicyType(String policyType) {
        this.policyType = policyType;
    }

    public String getPolicyType() {
        return policyType;
    }

    public String getIconType() {
        if(!forId(this.policyType).equals(ALL)) {
            if ( forId(this.policyType).equals(WC) ) {
                return "workers-comp";
            }
            else if( forId(this.policyType).equals(HO) ) {
                return "home-owners";
            }
            else if( forId(this.policyType).equals(BO) ) {
                return "business-owners";
            }
            else {
                return this.policyType.toLowerCase().replace(" ","-");
            }
        }
        return null;
    }

    public static PolicyType forId(String name) {
        for (PolicyType policyName : values()) {
            if (policyName.getPolicyType().equals(name)) {
                return policyName;
            }
        }
        throw new IllegalArgumentException(name);
    }
}
