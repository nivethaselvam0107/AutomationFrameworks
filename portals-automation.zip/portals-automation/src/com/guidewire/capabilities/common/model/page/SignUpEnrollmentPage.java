package com.guidewire.capabilities.common.model.page;

import static com.guidewire.data.PolicyData.POLICY_NUM;

import java.util.HashMap;

import com.guidewire.capabilities.agent.model.page.ClaimsLanding;
import com.guidewire.capabilities.claims.model.component.ClaimListPage;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.common.testNG.SuiteName;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.data.PolicyData;


public class SignUpEnrollmentPage extends CommonScenario {


    Logger logger = Logger.getLogger(this.getClass().getName());

    HashMap<String, String> data = ThreadLocalObject.getData();

    private String policyNumber = data.get(POLICY_NUM.toString());
    private String accountAddline1 = data.get(PolicyData.ACCOUNT_ADDLINE1.toString());

    @FindBy(css = "[gw-test-enrollment-components-signupenrollment-policynumber-field]")
    WebElement POLICY_NUMBER;

    @FindBy(css = "[gw-test-enrollment-components-signupenrollment-addressline1-field]")
    WebElement ADDRESS_LINE_1;

    @FindBy(css = "[gw-test-enrollment-components-signupenrollment-addpolicy-button]")
    WebElement ADD_POLICY_BUTTON;
    
    By FIELDS_ERROR_CSS = By.cssSelector("[ng-switch] div");

    public Validation isSignUpEnrollmentPageDisplayed() {
        logger.info( "Checking for Policy number field");
        return new Validation(seleniumCommands.isElementPresent(POLICY_NUMBER));
    }

    public SignUpEnrollmentPage setEnrollmentData() {
        logger.info("Entering enrollment data");
        seleniumCommands.type(POLICY_NUMBER, this.policyNumber);
        String addressLine = ParsePolicyData.getInsuredAddressLine1(DataFetch.getAccountPolicyData(policyNumber));
        logger.info("Policy number: " + policyNumber + " Address Line 1: " + addressLine);
        seleniumCommands.type(ADDRESS_LINE_1, addressLine);
        return this;
    }
    
    public SignUpEnrollmentPage setAccountEnrollmentData() {
        logger.info("Entering enrollment data");
        seleniumCommands.type(POLICY_NUMBER, this.policyNumber);
        logger.info("Policy number: " + policyNumber + " Address Line 1: " + accountAddline1);
        seleniumCommands.type(ADDRESS_LINE_1, accountAddline1);
        return this;
    }

    public SignUpEnrollmentPage clickAddPolicy() {
        logger.info("Click Add Policy");
        seleniumCommands.click(ADD_POLICY_BUTTON);
        return this;
    }

    public void isEnrollmentSuccessful() {
        logger.info( "Verifying enrollment by confirming user has Policy");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(  ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.AMP.toString() ))
        {
            new Validation(new AccountSummaryPage().getFirstPolicyNumber()
                    .contains(policyNumber)).shouldBeTrue(
                    "Policy number used in Enrollment is not listed");
        }
        else {
            new CP_ClaimListPage().validateFileAClaimButton().shouldBeTrue("File a claim button is not present");
        }
    }

    public void validateSignUpEnrollmentPageMandatoryField() {
        logger.info( "Verifying enrollment by confirming user has Policy");
        seleniumCommands.waitForElementToBeVisible(FIELDS_ERROR_CSS);
        	new Validation(seleniumCommands.getTextAtLocator(FIELDS_ERROR_CSS), DataConstant.POLICY_REGISTRATION_DATA_ERROR).shouldBeEqual();
    }
}
