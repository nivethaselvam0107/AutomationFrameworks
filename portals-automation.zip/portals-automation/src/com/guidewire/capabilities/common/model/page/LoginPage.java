package com.guidewire.capabilities.common.model.page;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.data.AgentUserName;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.data.PolicyData;

public class LoginPage extends CommonScenario {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "div[class*='gw-current-user']")
    WebElement LINK_PORTAL_USER_CSS;
    @FindBy(css = "[ng-click='$ctrl.signUp()']")
    WebElement BTN_SIGN_UP;

    WebElement USERNAME_FIELD;
    WebElement PASSWORD_FIELD;
    WebElement SUBMIT_BUTTON;
    List<WebElement> QUICKSTART_DATA_ROWS_COLLECTION;

    public final String user = data.get("USER");
    public final String password = data.get("PWD");

    By AGENT_USER_SELECTOR = By.xpath("//*[@id = 'samlusername' or @name = 'samlusername']");
    By AGENT_PASSWORD_SELECTOR = By.xpath("//*[@id = 'samlpassword' or @name = 'samlpassword']");
    By AGENT_LOGIN_SELECTOR = By.xpath("//*[@id='samlSubmit' or @id='samlsubmit']");

    By OPENAM_USER_SELECTOR = By.cssSelector("input[type='text']");
    By OPENAM_PASSWORD_SELECTOR = By.cssSelector("input[type='password']");
    By OPENAM_LOGIN_SELECTOR = By.xpath("//input[@value][@class='button' or @type='button']");

    By QUICKSTART_DATA_SELECTOR = By.xpath("//table//tr");

    By QUICKSTART_LOGIN_SELECTOR = By.xpath(".//input[@type='submit']");

    By USERNAME = By.cssSelector("[ng-model='$ctrl.username']");

    By PASSWORD = By.cssSelector("[ng-model='$ctrl.password']");

    By SIGNIN_BTN = By.xpath("//div[3]/button");

    By DISPLAYED_USER_NAME = By.xpath("//div/span/span");

    public LoginPage() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public void login() {
        List<By> loginScreenLocators = new ArrayList<>();
        boolean isQuickStartLogin = false;
        String url = ThreadLocalObject.getDriver().getCurrentUrl();
        loginScreenLocators.add(USERNAME);
        loginScreenLocators.add(PASSWORD);
        loginScreenLocators.add(SIGNIN_BTN);

        this.setLoginObjects(loginScreenLocators);

        //For local dev setup there will be no login
        if(System.getProperty("vm.type") == null || !System.getProperty("vm.type").equals("dev"))
        {
	        if (isQuickStartLogin) {
	            this.fillCredentialsForQuickStart();
	        } else {
	            this.fillCredentials();
	        }
        }
    }

    private void setLoginObjects(List<By>locators) {
        seleniumCommands.waitForElementToBePresent(USERNAME);
        if (locators.size() == 3) {
            USERNAME_FIELD = seleniumCommands.findElement(locators.get(0));
            PASSWORD_FIELD = seleniumCommands.findElement(locators.get(1));
            SUBMIT_BUTTON = seleniumCommands.findElement(locators.get(2));
        } else {
            QUICKSTART_DATA_ROWS_COLLECTION = seleniumCommands.findElements(locators.get(0));
            SUBMIT_BUTTON = seleniumCommands.findElement(locators.get(1));
        }
    }

    private void fillCredentials() {
    	setUserForGPA();
    	logger.info("USER NAME: "+data.get("USER"));
        seleniumCommands.type(USERNAME, data.get("USER"));
        seleniumCommands.type(PASSWORD, data.get("PWD"));
        seleniumCommands.clickbyJS(SIGNIN_BTN);
    }

    public SignUpPage goToSignUpPage() {
        seleniumCommands.clickbyJS(BTN_SIGN_UP);
        return new SignUpPage();
    }

    public LoginPage setUserForGPA() {
        if(ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.GPA.toString()) && ThreadLocalObject.getData().get(PolicyData.PRODUCER_OF_SERVICE.toString())!= null) {
            if(ThreadLocalObject.getData().get(PolicyData.PRODUCER_OF_SERVICE.toString()).equalsIgnoreCase("100-002541"))
            {
                ThreadLocalObject.getData().put("USER", "aarmstrong");
                if(System.getProperty("group.name").contains("CSR"))
                	ThreadLocalObject.getData().put("USER", "bbaker");
                ThreadLocalObject.getData().put("USER_NAME",AgentUserName.getValueByUname(ThreadLocalObject.getData().get("USER")));
                return this;
            } else if(ThreadLocalObject.getData().get(PolicyData.PRODUCER_OF_SERVICE.toString()).equalsIgnoreCase("301-008578") || ThreadLocalObject.getData().get(PolicyData.PRODUCER_OF_SERVICE.toString()).equalsIgnoreCase("201-343434")  )
            {
                ThreadLocalObject.getData().put("USER", "carkle");
                if(System.getProperty("group.name").contains("CSR"))
                	ThreadLocalObject.getData().put("USER", "bbaker");
                ThreadLocalObject.getData().put("USER_NAME",AgentUserName.getValueByUname(ThreadLocalObject.getData().get("USER")) );
                return this;
            }
        }

        if(ThreadLocalObject.getSuitenName().equalsIgnoreCase(SuiteName.GPA.toString())){
            if((!(ThreadLocalObject.getData().get("PRODUCT_CODE")==null))&& (ThreadLocalObject.getData().get("PRODUCT_CODE").equals("CommercialProperty")))
                ThreadLocalObject.getData().put("USER", "aarmstrong");
            else {
                ThreadLocalObject.getData().put("USER", "carkle");
            }
            ThreadLocalObject.getData().put("USER_NAME",AgentUserName.getValueByUname(ThreadLocalObject.getData().get("USER")) );
        }

        return this;

    }

    private void fillCredentialsForQuickStart() {
        boolean userFound = false;
        for (WebElement el: QUICKSTART_DATA_ROWS_COLLECTION) {
            if (seleniumCommands.getAttributeValueAtLocator(el, "innerText").contains(this.user)) {
                seleniumCommands.clickbyJS(seleniumCommands.findElement(el, QUICKSTART_LOGIN_SELECTOR));
                seleniumCommands.waitForElementToBeClickable(LINK_PORTAL_USER_CSS);
                userFound = true;
                break;
            }
        }

        if(!userFound) {
            throw new Error(String.format("QuickStart User [%s] not found.", this.user));
        }
    }
}
