package com.guidewire.capabilities.common.model.page;

import static com.guidewire.data.DataConstant.EMAIL_ALREADY_EXISTS_MESSAGE;
import static com.guidewire.data.DataConstant.SIGN_UP_EMAIL_VALIDATION_MESSAGE;
import static com.guidewire.data.DataConstant.SIGN_UP_FIELDS_VALIDATION_MESSAGE;
import static com.guidewire.data.DataConstant.SIGN_UP_PASSWORD_MATCH_VALIDATION_MESSAGE;

import java.util.UUID;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;


public class SignUpPage extends CommonScenario {

    Logger logger = Logger.getLogger(this.getClass().getName());

    private final String firstName = "FirstName";
    private final String lastName = "LastName";
    private final String password = data.get("PWD");
    private final String email = randomEmail();


    @FindBy(css = "[gw-test-platform-auth-components-firstname-field]")
    WebElement FIRST_NAME;

    @FindBy(css = "[gw-test-platform-auth-components-lastname-field]")
    WebElement LAST_NAME;

    @FindBy(css = "[gw-test-platform-auth-components-email-field]")
    WebElement EMAIL;

    @FindBy(css = "[gw-test-platform-auth-components-password-field]")
    WebElement PASSWORD;

    @FindBy(css = "[gw-test-platform-auth-components-confirm-password-field]")
    WebElement CONFIRM_PASSWORD;

    @FindBy(css = "[gw-test-platform-auth-components-signup-signup-button]")
    WebElement BTN_SIGN_UP;

    @FindBy(css = "[gw-test-platform-auth-components-signup-error-message-text]")
    WebElement VALIDATION_MESSAGE;

    @FindBy(css = "[gw-test-platform-auth-components-signup-email-exists-message]")
    WebElement EMAIL_EXISTS_MESSAGE;


    public SignUpPage setSignUpData() {
        logger.info("Entering sign up data");
        seleniumCommands.type(FIRST_NAME, this.firstName);
        seleniumCommands.type(LAST_NAME, this.lastName);
        seleniumCommands.type(EMAIL, this.email);
        seleniumCommands.type(PASSWORD, this.password);
        seleniumCommands.type(CONFIRM_PASSWORD, this.password);
        return this;
    }

    public SignUpPage removeLastName() {
        logger.info("Remove text in last name field");
        seleniumCommands.type(LAST_NAME, "");
        return this;
    }

    public SignUpPage inputIncorrectEmailFormat() {
        logger.info("Entering email with incomplete format");
        seleniumCommands.type(EMAIL, "fail@email.c");
        return this;
    }

    public SignUpPage changeConfirmPassword() {
        logger.info("Changing confirm password text");
        seleniumCommands.type(CONFIRM_PASSWORD, "fail");
        return this;
    }

    public SignUpPage clickSignUpButton() {
        logger.info("Clicking sign up button");
        seleniumCommands.clickbyJS(BTN_SIGN_UP);
        return this;
    }

    public SignUpPage inputPreviouslyRegisteredEmail() {
        logger.info("Entering email that has been already registered");
        seleniumCommands.type(EMAIL, ThreadLocalObject.getData().get("USER"));
        return this;
    }


    public void isMissingDataValidationMessageDisplayed() {
        logger.info( "Verifying sign up page missing data validation");
        String validationMessage = seleniumCommands.getTextAtLocator(VALIDATION_MESSAGE);
        new Validation(validationMessage, SIGN_UP_FIELDS_VALIDATION_MESSAGE)
                .shouldBeEqual("Expected Validation message mismatch");
    }

    public void isIncorrectEmailValidationMessageDisplayed() {
        logger.info( "Verifying email format message validation");
        String validationMessage = seleniumCommands.getTextAtLocator(VALIDATION_MESSAGE);
        new Validation(validationMessage, SIGN_UP_EMAIL_VALIDATION_MESSAGE)
                .shouldBeEqual("Expected Validation message mismatch");
    }

    public void isPasswordValidationMessageDisplayed() {
        logger.info( "Verifying message displayed where password and confirm password do not match");
        String validationMessage = seleniumCommands.getTextAtLocator(VALIDATION_MESSAGE);
        new Validation(validationMessage, SIGN_UP_PASSWORD_MATCH_VALIDATION_MESSAGE)
                .shouldBeEqual("Expected Validation message mismatch");
    }

    public void isEmailAlreadyExistsMessageDisplayed() {
        logger.info( "Verifying message displayed where email is already registered");
        new Validation(seleniumCommands.getTextAtLocator(EMAIL_EXISTS_MESSAGE)
                .contains(EMAIL_ALREADY_EXISTS_MESSAGE)).shouldBeTrue("Expected Email already exists message");
    }

    public void isSignUpSuccessful() {
        logger.info( "Verifying enrollment page has loaded");
        new SignUpEnrollmentPage().isSignUpEnrollmentPageDisplayed().shouldBeTrue("Enrollment Page did not open");
    }

    private static String randomEmail() {
        return "randomEmail-" + UUID.randomUUID().toString() + "@autotest.com";
    }

}
