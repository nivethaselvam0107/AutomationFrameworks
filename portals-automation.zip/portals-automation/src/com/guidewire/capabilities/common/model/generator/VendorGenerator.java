package com.guidewire.capabilities.common.model.generator;

import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import org.apache.log4j.Logger;

import java.util.*;
import io.restassured.path.json.JsonPath;

/**
 * This class give us possibility to create vendor with auto services
 * Auto Body, Glass, Audio Equipment
 * on ContactManager side
 *
 * @author askorokhod@guidewire.com
 * @see DataFetch
 * @see VendorDto
 * @see ParsePolicyData
 *
 */
public class VendorGenerator {

    private static final Logger LOGGER = Logger.getLogger(VendorGenerator.class);

    private static final String[] FULL_SERVICES = { "body", "glass", "audio" };
    private static final String[] BODY_SERVICE =  { "body" };
    private static final String[] GLASS_SERVICE = { "glass" };
    private static final String[] AUDIO_SERVICE = { "audio" };

    public static VendorDto generateVendor() {
        LOGGER.info("Generate Vendor with : body , glass, audio");
        return generateVendorWithServices(FULL_SERVICES);
    }

    public static VendorDto generateVendorWithBodyService() {
        LOGGER.info("Generate Vendor with : body");
        return generateVendorWithServices(BODY_SERVICE);
    }

    public static VendorDto generateVendorWithGlassService() {
        LOGGER.info("Generate Vendor with : glass");
        return generateVendorWithServices(GLASS_SERVICE);
    }

    public static VendorDto generateVendorWithAudioService() {
        LOGGER.info("Generate Vendor with : audio");
        return generateVendorWithServices(AUDIO_SERVICE);
    }
    
    public static String getVendorAddressBookID(String jsonData) {
        LOGGER.info("Fetching Vendor address bookk id");
        JsonPath path = new JsonPath(jsonData);
        return DataFormatUtil.getNodeValue(path, "result.addressBookUID");
    }

    private static VendorDto generateVendorWithServices(String[] serviceList) {
        String host = System.getProperty("host.name");
        host = host.replaceAll(":[0-9]+", "");
        String url = "http://" + host + ":8280/ab/service/edge/vendorgen/vendorgen";
        String method = "generateVendor";

        Map<String, Object> reqParams = new HashMap<>();

        List<String> listServices = new ArrayList<>();
        Arrays.stream(serviceList).forEach(el -> listServices.add(el));

        reqParams.put("serviceTypes", listServices);
        List<Object> params = new ArrayList<>();
        params.add(reqParams);

        String data =  DataFetch.backendCallWithSU(params, method, url);

        return ParsePolicyData.parseVendor(data);
    }
}
