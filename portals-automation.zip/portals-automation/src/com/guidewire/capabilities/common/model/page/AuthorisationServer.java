package com.guidewire.capabilities.common.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import io.restassured.path.json.JsonPath;
import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.JSONValue;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;

import java.util.*;

import static com.guidewire.capabilities.common.model.generator.PolicyGenerator.*;

public class AuthorisationServer {

    private static Logger LOGGER = Logger.getLogger(AuthorisationServer.class);

    public static void main(String[] args) throws Exception {
        final String version = args.length > 0 ? args[0] : "ferrite";
        final String host = args.length > 1 ? args[1] : "localhost";

        LOGGER.info(String.format("Running against '%s' on host '%s'", version, host));

        addInitialSetup(version, host + ":1238");

        //this is for testing AuthorisationServer matching user with policy calls
        //addInitialSetup("ferrite", "baggins-ferrite.dev-dex.guidewire.net:1238");
        //addInitialSetup("ferrite", "ferrite-qa.dev-dex.guidewire.net:1238");
        //addInitialSetup("emerald", "baggins-emerald.dev-dex.guidewire.net:1238");
        //addInitialSetup("diamond", "baggins-diamond.dev-dex.guidewire.net:1238");
    }

    public static void addInitialSetup(String env, String hostUrl) {
        //this function is purely and only for initial setup on AWS environment where there is no data initially
        System.setProperty("host.name", hostUrl);
        String domainName = "@" + env.toLowerCase() + ".com";
        HashMap<String, String> data = new HashMap<>();
        ThreadLocalObject.setData(data);

        List<String> listPolicies = new ArrayList<>();
        switch (env) {
            case "ferrite":
                listPolicies = new ArrayList<>(Arrays.asList("4723192364", "0457877264", "3751463496", "2064286786", "7163098154", "5626804497", "7946411353", "7163098154", "4992730196", "8867861657"));
                assignAccountCodeToUser("mmurphy" + domainName, "6331206268");
                break;
            case "ferrite91":
                listPolicies = new ArrayList<>(Arrays.asList("7501656114", "6426890858"));
                break;
            case "emerald":
                listPolicies = new ArrayList<>(Arrays.asList("2163653812", "6108423559", "4172574827", "1231643594", "8994695932", "4473100101"));
                assignAccountCodeToUser("mmurphy" + domainName, "7916151802");
                assignAccountCodeToUser("rfowler" + domainName, "1491353583");
                assignAccountCodeToUser("ajones" + domainName, "7342120782");
                break;
            case "diamond":
                listPolicies = new ArrayList<>(Arrays.asList("4565122575", "2891977343", "7873008575", "4500694825", "4702431040", "4408833618", "8029998568", "5628117542", "7807419803"));
                assignAccountCodeToUser("mmurphy" + domainName, "9642991650");
            default:
                break;
        }

        data.put("USER", "rnewton" + domainName);
        data.put("Suite", "CP-PolicyHolder");

        listPolicies.addAll(Arrays.asList(createBasicBoundBAPolicy(), createBasicBoundBOPolicy(), createBasicBoundCPPolicy(),
                createBasicBoundGLPolicy(), createBasicBoundIMPolicy(), createBasicBoundWCPolicy(), createBasicBoundPAPolicy()
        ));

        assignPolicy("rnewton" + domainName, listPolicies);

        data.put("Suite", "CP-Producer");
        assignPolicy("aproducer" + domainName, listPolicies);

        data.put("Suite", "CP-Vendor");
        assignPolicy("sdunn" + domainName, "ab:74");
    }

    private static String getUserID(String username) {
        return getUserData(username, "id").toString();
    }

    private static Object getUserGrantedAuthorities(String userName) {
        return callUAAHandler("listGrantedAuthoritiesForUser", new ArrayList<Object>() {{
            add(userName);
        }});
    }

    public static void assignPolicy(String policyNum) {
        assignPolicy(ThreadLocalObject.getData().get("USER"), policyNum);
    }

    public static void assignPolicy(String username, List<String> policiesNum) {
        policiesNum.forEach(policyNum ->
                assignPolicy(username, policyNum)
        );
    }

    public static void assignPolicy(String username, String policyNum) {
        HashMap<String, String> data = ThreadLocalObject.getData();
        String suiteName = data.get("Suite");
        String policyData = DataFetch.getAgentPolicyDataAsSU(policyNum);
        JsonPath path = new JsonPath(policyData);
        if (suiteName.equals("CP-PolicyHolder")) {
            ThreadLocalObject.getData().put("CreateUser", "true");
            assignPolicyToUser(username, policyNum);
        } else if (suiteName.equals("CP-Vendor")) {
            assignVendorCodeToUser(username, policyNum);
        } else if (suiteName.equals("CP-Producer")) {
            String producerCode = DataFormatUtil.getNodeValue(path, "account", "producerCodes[0].code");
            assignProducerCodeToUser(username, producerCode);
        } else {
            switch (suiteName) {
                case "AMP":
                    if(ThreadLocalObject.getData().get("CreateUser") == null) {
                        ThreadLocalObject.getData().put("CreateUser", "true");
                    }
                    String accountNumber = DataFormatUtil.getNodeValue(path, "account", "policySummaries[0].accountNumber");
                    assignAccountCodeToUser(username, accountNumber);
                    break;
                case "GPA":
                    String producerCode = DataFormatUtil.getNodeValue(path, "latestPeriod", "producerCodeOfServiceOrg");
                    data.put(PolicyData.ACCOUNT_NAME.toString(), DataFormatUtil.getNodeValue(path, "account", "policySummaries[0].accountHolderName"));
                    data.put(PolicyData.ACCOUNT_NUMBER.toString(), DataFormatUtil.getNodeValue(path, "account", "accountNumber"));
                    data.put(PolicyData.ACCOUNT_FIRST_NAME.toString(), DataFormatUtil.getNodeValue(path, "account", "accountHolder.firstName"));
                    data.put(PolicyData.ACCOUNT_LAST_NAME.toString(), DataFormatUtil.getNodeValue(path, "account", "accountHolder.lastName"));
                    data.put(PolicyData.POLICY_NUM.toString(), DataFormatUtil.getNodeValue(path, "", "policyNumber"));
                    data.put(PolicyData.POLICY_EXPIRATION_DATE.toString(), DataFormatUtil.getNodeValue(path, "account.policySummaries[0]", "expiration"));
                    data.put("ZipCode", DataFormatUtil.getNodeValue(path, "account.accountHolder.primaryAddress", "postalCode"));
                    data.put(PolicyData.ACCOUNT_ADDLINE1.toString(), DataFormatUtil.getNodeValue(path, "account.accountHolder.primaryAddress", "addressLine1"));
                    data.put(PolicyData.PRODUCER_OF_SERVICE.toString(), producerCode);
                    break;
                default:
                    LOGGER.error("Not supported suite type");
            }
        }
    }

    private static void assignProducerCodeToUser(String username, String producerCode) {
        LOGGER.info(String.format("Authorisation Server - Assigning producer code[%s] to user[%s]", producerCode, username));
        String userID = getUserID(username);
        if (userID != null && !userID.equals(""))
            assignProducerCodeToExistingUser(username, producerCode);
        else
            assignProducerCodeToNewUser(username, producerCode);
    }

    private static void assignAccountCodeToUser(String username, String accountCode) {
        LOGGER.info(String.format("Authorisation Server - Assigning account code[%s] to user[%s]", accountCode, username));
        String userID = getUserID(username);
        if (userID != null && !userID.equals("") &&
                (ThreadLocalObject.getData().containsKey("CreateUser") && ThreadLocalObject.getData().get("CreateUser").equals("false")))
            assignAccountCodeToExistingUser(username, accountCode);
        else
            assignAccountCodeToNewUser(generateUserName(), accountCode);
    }

    private static void assignVendorCodeToUser(String username, String vendorCode) {
        LOGGER.info(String.format("Authorisation Server - Assigning vendor code[%s] to user[%s]", vendorCode, username));
        String userID = getUserID(username);
        if (userID != null && !userID.equals(""))
            assignVendorCodeToExistingUser(username, vendorCode);
        else
            assignVendorCodeToNewUser(username, vendorCode);
    }

    public static void assignPolicyToUser(String username, String policyNum) {
        ThreadLocalObject.getData().put("PolicyAssignedToUser", "true");
        LOGGER.info(String.format("Authorisation Server - Assigning policy[%s] to user[%s]", policyNum, username));
        String userID = getUserID(username);
        if (userID != null && !userID.equals("") && !ThreadLocalObject.getData().containsKey("CreateUser"))
            assignPolicyToExistingUser(username, policyNum);
        else {
            assignPolicyToNewUser(generateUserName(), policyNum);
        }
        new SeleniumCommands().staticWait(3);
    }

    public static Map<String, String> getPoliciesForMultiAccountUser() {
        // Find all accounts mapped to this user
        List<String> accounts = AuthorisationServer.getExistingAccountNumbers(ThreadLocalObject.getData().get("USER"));

        // For each account list all policies and put them into a map of policy id -> account id
        Map<String, String> policiesToAccountMap = new HashMap<>();
        accounts.forEach(account -> {
            new JsonPath(DataFetch.getAccountDetails(account))
              .getList("policySummaries.policyNumber")
              .forEach(policyNumber -> policiesToAccountMap.put(policyNumber.toString(), account));
        });

        return policiesToAccountMap;
    }

    private static String generateUserName() {
        String testName = ThreadLocalObject.getTestName();
        testName = (testName.length() > 45) ? testName.substring(0, 20) : testName;
        String newUserName = testName + RandomStringUtils.randomAlphanumeric(3).toUpperCase()+ "@" + System.getProperty("platform").toLowerCase() + ".com";
        ThreadLocalObject.getData().put("USER", newUserName);
        ThreadLocalObject.getData().put("USER_NAME", newUserName);
        return newUserName;
    }

    private static List<String> getExistingAuthorityType(String username, String authorityType) {
        List<String> listAuthorities = new ArrayList<>();
        JSONArray existingAuthorities = (JSONArray) getUserGrantedAuthorities(username);

        existingAuthorities.forEach(el -> {
            JSONObject jsonObj = (JSONObject) el;
            if (jsonObj.get("authorityType").equals(authorityType))
                listAuthorities.add(jsonObj.get("target").toString());
        });
        return listAuthorities;
    }

    public static List<String> getExistingPolicies(String username) {
        return getExistingAuthorityType(username, "POLICY");
    }

    private static List<String> getExistingProducerCodes(String username) {
        return getExistingAuthorityType(username, "PRODUCER");
    }

    private static List<String> getExistingVendorCodes(String username) {
        return getExistingAuthorityType(username, "VENDOR");
    }


    private static List<String> getExistingAccountNumbers(String username) {
        return getExistingAuthorityType(username, "ACCOUNT");
    }

    private static JSONObject setPolicies(String username, List<String> policyNum) {
        String[] arrayPolicyNum = policyNum.toArray(new String[policyNum.size()]);
        return setPolicies(username, arrayPolicyNum);
    }

    private static JSONObject setPolicies(String username, String... policyNum) {
        return setParams(username, "POLICY", policyNum);
    }

    private static JSONObject setProducer(String username, List<String> producerCode) {
        String[] arrayProducerCodes = producerCode.toArray(new String[producerCode.size()]);
        return setProducer(username, arrayProducerCodes);
    }

    private static JSONObject setProducer(String username, String... producerCode) {
        return setParams(username, "PRODUCER", producerCode);
    }

    private static JSONObject setAccount(String username, List<String> accountCode) {
        String[] arrayAccountCodes = accountCode.toArray(new String[accountCode.size()]);
        return setAccount(username, arrayAccountCodes);
    }

    private static JSONObject setAccount(String username, String... accountCode) {
        return setParams(username, "ACCOUNT", accountCode);
    }

    private static JSONObject setVendor(String username, List<String> vendorCode) {
        String[] arrayVendorCodes = vendorCode.toArray(new String[vendorCode.size()]);
        return setVendor(username, arrayVendorCodes);
    }

    private static JSONObject setVendor(String username, String... vendorCode) {
        return setParams(username, "VENDOR", vendorCode);
    }

    private static JSONObject setParams(String username, String authorityType, String... accountCode) {
        JSONObject requestParams = new JSONObject();
        List<Object> listAccountCodeParams = new ArrayList<>();

        for (String aCode : accountCode) {
            JSONObject policyParams = new JSONObject();
            policyParams.put("authorityType", authorityType);
            policyParams.put("target", aCode);
            policyParams.put("accessLevel", "ALL");
            listAccountCodeParams.add(policyParams);
        }

        requestParams.put("grantedAuthorities", listAccountCodeParams);
        requestParams.put("userName", username);

        return requestParams;
    }

    private static void assignPolicyToNewUser(String username, String... policyNum) {
        createUser(username);
        JSONObject requestParams = setPolicies(username, policyNum);
        addGrantedAuthoritiesForUser(requestParams);

    }

    private static void assignProducerCodeToNewUser(String username, String... producerCode) {
        createUser(username);
        JSONObject requestParams = setProducer(username, producerCode);
        addGrantedAuthoritiesForUser(requestParams);
    }

    private static void assignAccountCodeToNewUser(String username, String... accountCode) {
        createUser(username);
        JSONObject requestParams = setAccount(username, accountCode);
        addGrantedAuthoritiesForUser(requestParams);
    }

    private static void assignVendorCodeToNewUser(String username, String... vendorCode) {
        createUser(username);
        JSONObject requestParams = setVendor(username, vendorCode);
        addGrantedAuthoritiesForUser(requestParams);
    }

    private static void assignPolicyToExistingUser(String username, String... policyNum) {
        ThreadLocalObject.getData().put("PolicyAssignedToUser", "true");
        List<String> listPolicyNum = getExistingPolicies(username);
        listPolicyNum.addAll(Arrays.asList(policyNum));
        JSONObject requestParams = setPolicies(username, listPolicyNum);
        addGrantedAuthoritiesForUser(requestParams);
    }

    public static void removePolicyFromExistingUser(String username, String policyNum) {
        JSONObject requestParams = new JSONObject();
        requestParams = setPolicies(username, policyNum);
        removeGrantedAuthoritiesForUser(requestParams);
    }

    private static void assignProducerCodeToExistingUser(String username, String... producerCode) {
        List<String> listProducerCodes = getExistingProducerCodes(username);
        listProducerCodes.addAll(Arrays.asList(producerCode));
        JSONObject requestParams = setProducer(username, listProducerCodes);
        addGrantedAuthoritiesForUser(requestParams);
    }

    public static void assignAccountCodeToExistingUser(String username, String accountCode) {
        List<String> listAccountCodes = new ArrayList<>();
        listAccountCodes.addAll(Arrays.asList(accountCode));
        JSONObject requestParams = setAccount(username, listAccountCodes);
        addGrantedAuthoritiesForUser(requestParams);
    }

    private static void assignVendorCodeToExistingUser(String username, String... vendorCode) {
        List<String> listVendorCodes = getExistingVendorCodes(username);
        listVendorCodes.addAll(Arrays.asList(vendorCode));
        JSONObject requestParams = setVendor(username, listVendorCodes);
        addGrantedAuthoritiesForUser(requestParams);
    }

    private static void addGrantedAuthoritiesForUser(JSONObject requestParams) {
        List<Object> params = new ArrayList<Object>();
        params.add(requestParams.get("userName"));
        params.add(requestParams.get("grantedAuthorities"));

        try {
            callUAAHandler("addAuthoritiesForUser", params);
        } catch (Exception e) {
            LOGGER.error(e);
        }
    }

    private static void removeGrantedAuthoritiesForUser(JSONObject requestParams) {
        List<Object> params = new ArrayList<>();
        params.add(requestParams.get("userName"));
        params.add(requestParams.get("grantedAuthorities"));
        try {
            callUAAHandler("removeAuthoritiesForUser", params);
        } catch (Exception e) {
            LOGGER.error(e);
        }
    }

    private static JSONObject getUserByName(String name) {
        List<Object> params = new ArrayList<>();
        params.add(name);
        return (JSONObject) callUAAHandler("getUser", params);
    }

    private static boolean isUserPresent(String username) {
        List<Object> params = new ArrayList<>();
        JSONObject jsondata;

        try {
            jsondata = (JSONObject) callUAAHandler("getUsers", params);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
        JSONArray arrayUsers = (JSONArray) jsondata.get("resources");

        for (Object jsonObject : arrayUsers) {
            JSONObject element = (JSONObject) jsonObject;
            if (element.get("userName").equals(username)) {
                return true;
            }
        }
        return false;
    }

    private static Object getUserData(String username, String dataName) {
        List<Object> params = new ArrayList<>();
        JSONObject jsondata;
        try {
            jsondata = (JSONObject) callUAAHandler("getUsers", params);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        JSONArray arrayUsers = (JSONArray) jsondata.get("resources");

        for (Object jsonObject : arrayUsers) {
            JSONObject element = (JSONObject) jsonObject;

            if (element.get("userName").equals(username)) {
                return element.get(dataName);
            }
        }
        return "";
    }

    public static void createUser(String username) {
        if (!isUserPresent(username)) {
            List<Object> emails = new ArrayList<>();
            HashMap<String, Object> email = new HashMap<String, Object>() {{
                put("value", "sampledata@guidewire.com");
                put("primary", true);
            }};
            emails.add(email);

            JSONObject newUser = new JSONObject(new HashMap<String, Object>() {{
                put("userName", username);
                put("password", "password");
                put("name", new HashMap<String, String>() {{
                    put("familyName", "sample");
                    put("givenName", "data");
                }});
                put("emails", emails);
            }});

            List<Object> params = new ArrayList<>();
            params.add(newUser);
            callUAAHandler("createUser", params);
        }
    }

    public static Object deleteUser(String username) {
        List<Object> params = new ArrayList<>();
        params.add(username);
        return callUAAHandler("deleteUser", params);
    }

    private static Object callUAAHandler(String method, List<Object> params) {
        String host = System.getProperty("host.name");
        host = host.replaceAll(":[0-9]+", "");
        String url = "http://" + host + ":8180/pc/service/edge/extusermgmt/uaaadministration";
        String data = DataFetch.backendCallWithSU(params, method, url);
        try {
            return new JSONValue().parse(data);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
