package com.guidewire.capabilities.common.model.page;

import javax.xml.bind.DatatypeConverter;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.apache.log4j.Logger;

public class HttpRequest {

    private static Logger logger = Logger.getLogger(HttpRequest.class);

    private static final String USER_AGENT = "Mozilla/5.0";

    public static void main(String[] args) throws Exception {

        //this is for testing http calls
        //HttpRequest http = new HttpRequest();
        //String url = "http://localhost:9090/admin/enrolleduser";
    }

    // HTTP GET request
    public static String sendGet(String url) throws Exception {

        logger.info("Sending GET request. Params:" +
                "\n\turl: " + url);

        HttpURLConnection conn = setHeader(url, "GET");

        int responseCode = conn.getResponseCode();
        logger.info("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        logger.info("Response data : \n\t" + response);
        return response.toString();
    }

    // HTTP POST request
    public static String sendPost(String url, String username, String requestParams) throws Exception {

        return sendRequest(url, username, requestParams, "POST");
    }

    // HTTP PUT request
    public static String sendPut(String url, String username, String requestParams) throws Exception {

        return sendRequest(url, username, requestParams, "PUT");
    }

    private static String sendRequest(String url, String username, String requestParams, String requestType) throws Exception {

        logger.info("Sending " + requestType + " request. Params:\n\tusername: " + username +
                "\n\tparameters: " + requestParams +
                "\n\turl: " + url);

        HttpURLConnection conn = setHeader(url, username, requestType);

        // Send post request
        conn.setDoOutput(true);
        DataOutputStream wr = new DataOutputStream(conn.getOutputStream());
        wr.writeBytes(requestParams);
        wr.flush();
        wr.close();

        int responseCode = conn.getResponseCode();
        logger.info("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        logger.info("Response data : \n\t" + response);
        return response.toString();
    }

    private static String toBase64(String input) {

        return DatatypeConverter.printBase64Binary(input.getBytes());
    }

    private static String fromBase64(String input) {

        return new String(DatatypeConverter.parseBase64Binary(input));
    }

    private static HttpURLConnection setHeader(String url, String requestMethod) throws Exception {

        return setHeader(url, "", requestMethod);
    }

    private static HttpURLConnection setHeader(String url, String username, String requestMethod) throws Exception {

        URL urlObj = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();

        //add request header
        conn.setRequestMethod(requestMethod);
        conn.setRequestProperty("User-Agent", USER_AGENT);
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        conn.setRequestProperty("Authorization", "Basic " + toBase64("upstream:password"));
        conn.setRequestProperty("Accept", "application/json, text/plain, */*");
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

        if(!username.equals(""))
            conn.setRequestProperty("Cookie", "GW-P-QS-User-Name=" + username);

        return conn;
    }
}
