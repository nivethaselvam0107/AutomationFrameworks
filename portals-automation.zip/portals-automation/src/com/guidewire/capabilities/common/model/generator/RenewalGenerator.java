package com.guidewire.capabilities.common.model.generator;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

public class RenewalGenerator {

	private static final Logger LOGGER = Logger.getLogger(RenewalGenerator.class);

	// Personal Auto policies renewal
	public static void createBasicDraftPARenewal() {
		PolicyGenerator.createBasicBoundPAPolicy();
		createRenewal("Draft");
	}

	public static void createBasicQuotedPARenewal() {
		PolicyGenerator.createBasicBoundPAPolicy();
		createRenewal("Quoted");
	}

	public static void createBasicBoundPARenewal() {
		PolicyGenerator.createBasicBoundPAPolicy();
		createRenewal("Bound");
	}

	// Homeowners policies
	public static void createBasicDraftHORenewal() {
		PolicyGenerator.createBasicBoundHOPolicy();
		createRenewal("Draft");
	}

	public static void createBasicQuotedHORenewal() {
		PolicyGenerator.createBasicBoundHOPolicy();
		createRenewal("Quoted");
	}

	public static void createBasicBoundHORenewal() {
		PolicyGenerator.createBasicBoundHOPolicy();
		createRenewal("Bound");
	}

	// Inland Marine Policy
	public static void createBasicBoundIMRenewal() {
		PolicyGenerator.createBasicBoundIMPolicy();
		createRenewal("Bound");
	}

	// Inland Marine Policy
	public static void createBasicBoundGLRenewal() {
		PolicyGenerator.createBasicBoundGLPolicy();
		createRenewal("Bound");
	}

	public static String createRenewal(String renewalStatus) {
		String url = ":8180/pc/service/edge/test-policy/datacreation";
		String method = "createRenewal";

		List<Object> params = new ArrayList<>();
		params.add(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
		params.add(renewalStatus);

		return DataFetch.backendCallWithSU(params, method, url);
	}

}
