package com.guidewire.capabilities.common.model.generator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.ClaimType;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

public class PolicyGenerator {

    private static final Logger LOGGER = Logger.getLogger(PolicyGenerator.class);

    //Workers Comp policies
    public static String createBasicDraftWCPolicy() {
        return createBasicWCPolicy("Draft");
    }
    public static String createBasicQuotedWCPolicy() {
        return createBasicWCPolicy("Quoted");
    }
    public static String createBasicBoundWCPolicy() {
        return createBasicWCPolicy("Bound");
    }
    private static String createBasicWCPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.WC.line());
    }

    //General Liability policies
    public static String createBasicDraftGLPolicy() {
        return createBasicGLPolicy("Draft");
    }
    public static String createBasicQuotedGLPolicy() {
        return createBasicGLPolicy("Quoted");
    }
    public static String createBasicBoundGLPolicy() {
        return createBasicGLPolicy("Bound");
    }
    private static String createBasicGLPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.GL.line());
    }

    //Inland Marine policies
    public static String createBasicDraftIMPolicy() {
        return createBasicIMPolicy("Draft");
    }
    public static String createBasicQuotedIMPolicy() {
        return createBasicIMPolicy("Quoted");
    }
    public static String createBasicBoundIMPolicy() {
        return createBasicIMPolicy("Bound");
    }
    private static String createBasicIMPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.IM.line());
    }

    //Commercial Property policies
    public static String createBasicDraftCPPolicy() {
        return createBasicCPPolicy("Draft");
    }
    public static String createBasicQuotedCPPolicy() {
        return createBasicCPPolicy("Quoted");
    }
    public static String createBasicBoundCPPolicy() {
        return createBasicCPPolicy("Bound");
    }
    public static String createBasicBoundCPPolicy(int locations, int buildings) {
        return createBasicCPPolicy("Bound", locations, buildings);
    }
    private static String createBasicCPPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.CP.line());
    }
    private static String createBasicCPPolicy(String policyStatus, int locations, int buildings) {
        Map<String, Object> propertyConfig = new HashMap();
        Map<String, Object> propertyConfigDetails = new HashMap();

        if (locations != 0) {
            propertyConfigDetails.put("numOfLocations", locations);
        }
        if (buildings != 0) {
            propertyConfigDetails.put("numOfBuildingsPerLocation", buildings);
        }

        propertyConfig.put("commercialPropertyConfig", propertyConfigDetails);
        propertyConfig.put("method", "generateCustomPolicy");

        return createBasicPolicy(policyStatus, ClaimType.CP.line(), propertyConfig);
    }

    //Business Owners policies
    public static String createBasicDraftBOPolicy() {
        return createBasicBOPolicy("Draft");
    }
    public static String createBasicQuotedBOPolicy() {
        return createBasicBOPolicy("Quoted");
    }
    public static String createBasicBoundBOPolicy() {
        return createBasicBOPolicy("Bound");
    }
    private static String createBasicBOPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.BO.line());
    }

    //Business Auto policies
    public static String createBasicDraftBAPolicy() {
        return createBasicBAPolicy("Draft");
    }
    public static String createBasicQuotedBAPolicy() {
        return createBasicBAPolicy("Quoted");
    }
    public static String createBasicBoundBAPolicy() {
        return createBasicBAPolicy("Bound");
    }
    private static String createBasicBAPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.BA.line());
    }

    //Personal Auto policies
    public static String createBasicDraftPAPolicy() {
        return createBasicPAPolicy("Draft");
    }
    public static String createBasicQuotedPAPolicy() {
        return createBasicPAPolicy("Quoted");
    }
    public static String createBasicBoundPAPolicy() {
        return createBasicPAPolicy("Bound");
    }
    private static String createBasicPAPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.PA.line());
    }

    // Homeowners policies
    public static String createBasicBoundHOPolicy() {
        return createBasicHOPolicy("Bound");
    }
    public static String createBasicDraftHOPolicy() {
        return createBasicHOPolicy("Draft");
    }
    public static String createBasicQuotedHOPolicy() {
        return createBasicHOPolicy("Quoted");
    }
    private static String createBasicHOPolicy(String policyStatus) {
        String platform = System.getProperty("platform");
        String policyLine = (platform.equalsIgnoreCase("granite")) ? ClaimType.HOP.line() : ClaimType.HO.line();
        if (platform.equalsIgnoreCase("granite"))
            ThreadLocalObject.getData().put("ProductCode", "HOPHomeowners");
        return createBasicPolicy(policyStatus, policyLine);
    }
    
    public static String createBasicBoundHOPPolicy() {
        return createBasicHOPPolicy("Bound");
    }
    public static String createBasicDraftHOPPolicy() {
        return createBasicHOPPolicy("Draft");
    }
    public static String createBasicQuotedHOPPolicy() {
        return createBasicHOPPolicy("Quoted");
    }
    private static String createBasicHOPPolicy(String policyStatus) {
        return createBasicPolicy(policyStatus, ClaimType.HOP.line());
    }

    private static synchronized String createBasicPolicy(String policyStatus, String policyLine, String...username) {
        return createBasicPolicy(policyStatus, policyLine, null, username);
    }

    private static synchronized String createBasicPolicy(String policyStatus, String policyLine, Map<String, Object> extraParams, String...username) {
        String host = System.getProperty("host.name");
        host = host.replaceAll(":[0-9]+", "");
        String url = "http://" + host + ":8180/pc/service/edge/policygen/policygen";
        String method = "generateBasicPolicy";

        Map<String, Object> reqParams = new HashMap<>();
        reqParams.put("policyStatus", policyStatus);
        reqParams.put("policyLine", policyLine);

        if (extraParams != null) {
            if (extraParams.get("method") != null) {
                method = (String) extraParams.get("method");
            }
            reqParams.putAll(extraParams);
        }

        List<Object> params = new ArrayList<>();
        params.add(reqParams);

        String policyNum =  DataFetch.backendCallWithSU(params, method, url);
        LOGGER.info("Policy created: \n\tnumber: " + policyNum + "\n\tpolicyLine: " + policyLine + "\n\tpolicyStatus: " + policyStatus);
        ThreadLocalObject.getData().put(PolicyData.POLICY_NUM.toString(), policyNum);

        if(username.length > 0) {
            AuthorisationServer.assignPolicy(username[0], policyNum);
        } else {
            AuthorisationServer.assignPolicy(policyNum);
        }

        return policyNum;
    }
}
