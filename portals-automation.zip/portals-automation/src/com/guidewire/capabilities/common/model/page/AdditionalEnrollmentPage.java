package com.guidewire.capabilities.common.model.page;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.data.PolicyData;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.HashMap;

import static com.guidewire.data.PolicyData.POLICY_NUM;


public class AdditionalEnrollmentPage extends CommonScenario {

    Logger logger = Logger.getLogger(this.getClass().getName());

    HashMap<String, String> data = ThreadLocalObject.getData();

    private String policyNumber = data.get(POLICY_NUM.toString());
    private String accountAddline1 = data.get(PolicyData.ACCOUNT_ADDLINE1.toString());

    @FindBy(css = "#additionalEnrollmentPolicy")
    WebElement POLICY_NUMBER;

    @FindBy(css = "#additionalEnrollmentAddress")
    WebElement ADDRESS_LINE_1;

    @FindBy(css = "#additionalEnrollmentButton")
    WebElement ENROL;

    @FindBy(css = "#additionalEnrollmentHomeLink")
    WebElement RETURN_TO_HOMEPAGE;

    @FindBy(css = "#additionalEnrollmentSuccessful")
    WebElement SUCCESS_MESSAGE;

    public AdditionalEnrollmentPage setAccountEnrollmentData() {
        logger.info("Entering additional enrollment data");
        seleniumCommands.type(POLICY_NUMBER, this.policyNumber);
        logger.info("Policy number: " + policyNumber + " Address Line 1: " + accountAddline1);
        seleniumCommands.type(ADDRESS_LINE_1, accountAddline1);
        return this;
    }

    public AdditionalEnrollmentPage clickEnrol() {
        logger.info("Click Enrol");
        seleniumCommands.click(ENROL);
        return this;
    }

    public AdditionalEnrollmentPage clickReturn() {
        logger.info("Click Return to Homepage");
        seleniumCommands.click(RETURN_TO_HOMEPAGE);
        return this;
    }

    public AdditionalEnrollmentPage isEnrollmentSuccessful() {
        logger.info( "Verifying enrollment success message is present");
        seleniumCommands.waitForElementToBeVisible(SUCCESS_MESSAGE);
        new Validation(seleniumCommands.isElementPresent(SUCCESS_MESSAGE))
                .shouldBeTrue("Enrollment message should be visible");
        return this;
    }
}
