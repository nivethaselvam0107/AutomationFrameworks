package com.guidewire.capabilities.common.interfaces;

public interface IPolicyLandingPage {
    IPolicyDetailsPage clickOnPolicy();
}
