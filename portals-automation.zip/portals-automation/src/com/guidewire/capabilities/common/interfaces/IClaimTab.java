package com.guidewire.capabilities.common.interfaces;

import org.openqa.selenium.By;

public interface IClaimTab {
    IClaimTab openTab();
    IClaimTab waitTabContent();
    boolean isTabActive();
    boolean isTabAvailable();
    By getTab();
    By getTabButton();
    By getTabContent();
}
