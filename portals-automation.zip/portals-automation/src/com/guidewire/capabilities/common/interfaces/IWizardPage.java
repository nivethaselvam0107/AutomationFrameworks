package com.guidewire.capabilities.common.interfaces;

import com.guidewire.common.testNG.Validation;

public interface IWizardPage {
    Validation isPageLoaded();
}
