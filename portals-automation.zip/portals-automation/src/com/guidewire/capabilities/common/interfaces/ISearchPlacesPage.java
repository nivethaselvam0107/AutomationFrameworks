package com.guidewire.capabilities.common.interfaces;

import com.guidewire.common.testNG.Validation;

/**
 * Support search places on map component
 *
 * @author askorokhod@guidewire.com
 */
public interface ISearchPlacesPage {

    ISearchPlacesPage searchPlaceByText(String text);
    ISearchPlacesPage selectFirstPlace();
    ISearchPlacesPage selectPolicyLocation();
    ISearchPlacesPage selectLossLocation();
    ISearchPlacesPage clearSearchInput();
    Validation validateStaticLocations();
    Validation validateSearchResult();
    Validation validateSearchInputAfterSelection();
    Validation validatePolicyLocation();
    Validation validateLossLocation();
}
