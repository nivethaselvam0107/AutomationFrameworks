package com.guidewire.capabilities.common.interfaces;

import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.common.testNG.Validation;

public interface IVendorListPage {
    NewClaimRecommendedRepairFacilityPage selectVendor();
    NewClaimRecommendedRepairFacilityPage selectFirstAvailableVendor();
    Validation validateSelectedVendor();
}
