package com.guidewire.capabilities.common.interfaces;

public interface IBindPolicyCancellationPage {
    void bindCancellationOnPolicy();
    void withdrawCancellationOnPolicy();
    void doNotWithdrawCancellationOnPolicy();
    void doNotBindCancellationOnPolicy();
}
