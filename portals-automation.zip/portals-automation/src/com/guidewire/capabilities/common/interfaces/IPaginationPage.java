package com.guidewire.capabilities.common.interfaces;

import org.openqa.selenium.By;

public interface IPaginationPage {
    By PREVIOUS_BUTTON = By.cssSelector("[class*='PaginationNavigation-hashed__previous'], [class*='gw-previous-button'][ng-click='previousPage()']");
    By NEXT_BUTTON = By.cssSelector("[class*='PaginationNavigation-hashed__next'], [class*='gw-next-button'][ng-click='nextPage()']");

    IPaginationPage previousPage();
    IPaginationPage nextPage();
    boolean previousButtonEnabled();
    boolean nextButtonEnabled();
}
