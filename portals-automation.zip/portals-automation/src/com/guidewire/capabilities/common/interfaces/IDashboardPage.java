package com.guidewire.capabilities.common.interfaces;

public interface IDashboardPage {
    IPolicyLandingPage clickPolicyLinkOnNavBar();
    IPolicyDetailsPage searchPolicy();
}
