package com.guidewire.capabilities.common.interfaces;

public interface ICancelPolicyDetailsPage {
    ICancelPolicyDetailsPage fillMandatoryProperties();
    IBindPolicyCancellationPage submitCancellation();
    ICancelPolicyDetailsPage setDateNotWithinPolicyPeriod();
    ICancelPolicyDetailsPage setDateWithinPolicyPeriod();
}
