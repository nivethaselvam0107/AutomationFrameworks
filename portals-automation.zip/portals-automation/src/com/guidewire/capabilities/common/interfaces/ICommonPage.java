package com.guidewire.capabilities.common.interfaces;

public interface ICommonPage {
    IDashboardPage login();
}
