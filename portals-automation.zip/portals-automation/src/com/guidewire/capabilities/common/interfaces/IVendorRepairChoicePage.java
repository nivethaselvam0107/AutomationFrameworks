package com.guidewire.capabilities.common.interfaces;

import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairFacilityPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;

public interface IVendorRepairChoicePage {
    NewClaimRecommendedRepairFacilityPage selectRecommendedFacility();
    NewClaimRepairChoicePage selectValueRecommendedFacility();
    NewClaimRepairFacilityPage selectNewFacility();
    NewClaimRepairChoicePage selectValueNewFacility();
    NewClaimDocumentPage selectNoFacility();
    NewClaimRepairChoicePage selectValueNoFacility();
    NewClaimRepairChoicePage selectVehicle(String vehicleName);
    String getSelectedVehicle();
    String getSelectedRepairChoice();
    Validation validateRepairChoiceErrorMessage();
    Validation validateRepairChoiceVehiclesErrorMessage();
    Validation isVehiclesSelectorPresent();
}
