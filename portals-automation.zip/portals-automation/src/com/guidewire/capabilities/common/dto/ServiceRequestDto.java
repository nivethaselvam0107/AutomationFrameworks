package com.guidewire.capabilities.common.dto;

public class ServiceRequestDto {
    public String Status;
    public String ServiceNumber;
    public String ServiceType;
    public String Vendor;
    public String NextAction;
    public String CompletionDate;
    public String PrimaryContact;
}
