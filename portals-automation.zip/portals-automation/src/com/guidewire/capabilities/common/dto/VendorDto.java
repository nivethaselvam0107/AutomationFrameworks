package com.guidewire.capabilities.common.dto;

public class VendorDto {
    public String PublicID;
    public String VendorName;
    public String Email;
    public String Phone;
    public String Address;
    public String Latitude;
    public String Longitude;
    public Long Score;
    public String AddressBookID;

    public VendorDto(){
    }
}
