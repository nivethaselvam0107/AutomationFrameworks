package com.guidewire.capabilities.common.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.log4j.Logger;
import java.util.Arrays;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PropertyDTO {

    private static final Logger LOGGER = Logger.getLogger(PropertyDTO.class);

    private String address;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String locationNumber;
    private String buildingNumber;

    private String policySystemId;
    private String description;
    private String addressLine1Kanji;
    private String addressLine2Kanji;
    private String cityKanji;


    public static List<PropertyDTO> fromJson(String json) {
        if (json.startsWith("{") && json.endsWith("}")) {
            json = "[" + json + "]";
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            return Arrays.asList(mapper.readValue(json, PropertyDTO[].class));
        } catch (Exception e) {
            LOGGER.warn("Read json error", e);
            return null;
        }
    }

    private String getCombinedAddress() {
        if (address == null) {
            return addressLine1 + ", " + city;
        } else {
            String[] props = this.address.split(",");
            return props[0].trim() + ", " + props[1].trim();
        }
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof PropertyDTO) {
            PropertyDTO dto = (PropertyDTO) o;
            return new EqualsBuilder()
                    .append(this.getCombinedAddress(), dto.getCombinedAddress())
                    .append(this.description, dto.getDescription())
                    .append(this.locationNumber, dto.getLocationNumber())
                    .append(this.buildingNumber, dto.getBuildingNumber())
                    .isEquals();
        }
        return false;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(this.getCombinedAddress())
                .append(this.description)
                .append(this.locationNumber)
                .append(this.buildingNumber)
                .toHashCode();
    }

    @Override
    public String toString() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            LOGGER.warn("Write json error",e);
            throw new RuntimeException(e);
        }
    }

    // Required for jackson processor
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getAddressLine1() {
        return addressLine1;
    }
    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    public String getAddressLine2() {
        return addressLine2;
    }
    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getLocationNumber() {
        return locationNumber;
    }
    public void setLocationNumber(String locationNumber) {
        this.locationNumber = locationNumber;
    }
    public String getBuildingNumber() {
        return buildingNumber;
    }
    public void setBuildingNumber(String buildingNumber) {
        this.buildingNumber = buildingNumber;
    }

    // extra fields
    public String getPolicySystemId() {
        return policySystemId;
    }
    public void setPolicySystemId(String policySystemId) {
        this.policySystemId = policySystemId;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getAddressLine1Kanji() {
        return addressLine1Kanji;
    }
    public void setAddressLine1Kanji(String addressLine1Kanji) {
        this.addressLine1Kanji = addressLine1Kanji;
    }
    public String getAddressLine2Kanji() {
        return addressLine2Kanji;
    }
    public void setAddressLine2Kanji(String addressLine2Kanji) {
        this.addressLine2Kanji = addressLine2Kanji;
    }
    public String getCityKanji() {
        return cityKanji;
    }
    public void setCityKanji(String cityKanji) {
        this.cityKanji = cityKanji;
    }
}