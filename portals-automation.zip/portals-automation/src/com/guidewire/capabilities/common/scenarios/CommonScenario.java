package com.guidewire.capabilities.common.scenarios;

import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.data.DataConstant;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.HashMap;

public abstract class CommonScenario {
    protected SeleniumCommands seleniumCommands = new SeleniumCommands();
    protected HashMap<String, String> data = ThreadLocalObject.getData();

    protected BrowserType browserType = BrowserType.fromString(ThreadLocalObject.getBrowserName());
    protected SuiteName suiteName = SuiteName.fromString(ThreadLocalObject.getSuitenName());

    protected CommonScenario() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    protected <T> T thisOrNull(Class<T> type) {
        return type.isInstance(this) ? type.cast(this) : null;
    }
}
