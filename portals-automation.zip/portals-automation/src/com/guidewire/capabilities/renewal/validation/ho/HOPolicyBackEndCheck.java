package com.guidewire.capabilities.renewal.validation.ho;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;

public class HOPolicyBackEndCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	public Validation isValuableAvailableInCurrentPolicy() {
		logger.info("Backend check for Valuable in current policy");
		return checkValuablesInPolicy("currentPeriod.lobs.homeOwners.dwellingDTO.coverageDTOs");
	}
	
	public Validation isValuableAvailableInRenewalPolicy() {
		logger.info("Backend check for Valuable in renewal policy");
		return checkValuablesInPolicy("renewedPeriod.lobs.homeOwners.dwellingDTO.coverageDTOs");
	}
	
	public Validation isMortgageeAvailableInCurrentPolicy() {
		logger.info("Backend check for Mortgagee in current policy");
		return checkMogtgageeInPolicy("currentPeriod.lobs.homeOwners.dwellingDTO.mortgageeDetailsDTO");
	}
	
	public Validation isMortgageeAvailableInRenewalPolicy() {
		logger.info("Backend check for Mortgagee in renewal policy");
		return checkMogtgageeInPolicy("renewedPeriod.lobs.homeOwners.dwellingDTO.mortgageeDetailsDTO");
	}
	
	public Validation checkValuablesInPolicy(String schPropPath) {
		JsonPath path = getPolicyData();
		int count = path.getList(schPropPath).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String schPropType = schPropPath + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, schPropType, "name").equals("Scheduled Personal Property")) {
				String schPropItem = schPropType + ".scheduledProperty";
				String[] schPropList = DataFormatUtil.getNodeValue(path, schPropItem, "name").replace("[", "").replace("]", "").split(" ");
				int countSchProp = schPropList.length;
				for (int j = 0; j< countSchProp; j++) {
					String schPropItemPath = schPropItem + "[" + j + "]";
					if (DataFormatUtil.getNodeValue(path, schPropItemPath, "description").equals(data.get("Valuable_Description"))) {
						new Validation(data.get("Valuable_Type"), DataFormatUtil.getNodeValue(path, schPropItemPath, "name")).shouldBeEqual();
						new Validation(data.get("Valuable_Cost"), DataFormatUtil.getNodeValue(path, schPropItemPath, "value")).shouldBeEqual();
						covFlag = true;
						break;
					}
				}
				break;
			}
		}
		return new Validation(covFlag);
	}

	public static Validation checkMogtgageeInPolicy(String mortGageePath) {
		JsonPath path = getPolicyData();
		int count = path.getList(mortGageePath).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String mortPropType = mortGageePath + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, mortPropType, "name").equals(ThreadLocalObject.getData().get("MortGagee_Name"))) {
				new Validation(ThreadLocalObject.getData().get("MortGagee_City"), DataFormatUtil.getNodeValue(path, mortPropType, "city")).shouldBeEqual();
				new Validation(ThreadLocalObject.getData().get("MortGagee_Street"), DataFormatUtil.getNodeValue(path, mortPropType, "street")).shouldBeEqual();
				new Validation(ThreadLocalObject.getData().get("MortGagee_State"), DataFormatUtil.getNodeValue(path, mortPropType, "state")).shouldBeEqual();
				covFlag = true;
				break;
			}
		}
		return new Validation(covFlag);
	}

	public static JsonPath getPolicyData() {
		return new JsonPath(DataFetch.getAccountPolicyData(ThreadLocalObject.getData().get("POLICY_NUM")));
	}

public static void main(String[] args) {
	ThreadLocalObject.getData().put("MortGagee_City", "Foster City");
	ThreadLocalObject.getData().put("MortGagee_Street", "1 Bank Road");
	ThreadLocalObject.getData().put("MortGagee_State", "California");
	ThreadLocalObject.getData().put("MortGagee_Name", "Bank of Mortgage");
	ThreadLocalObject.getData().put("Valuable_Description", "Nikon");
	ThreadLocalObject.getData().put("Valuable_Type", "Cameras");
	ThreadLocalObject.getData().put("Valuable_Cost", "4000");
	//DataFetch.createRenewal("0457877264", "bound");
	HOPolicyBackEndCheck backEndCheck = new HOPolicyBackEndCheck();
	backEndCheck.isMortgageeAvailableInRenewalPolicy();
	backEndCheck.isMortgageeAvailableInCurrentPolicy();
	backEndCheck.isValuableAvailableInCurrentPolicy();
	backEndCheck.isValuableAvailableInRenewalPolicy();
}	
	

}
