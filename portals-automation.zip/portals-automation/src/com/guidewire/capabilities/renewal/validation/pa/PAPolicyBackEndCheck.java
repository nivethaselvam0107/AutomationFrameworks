package com.guidewire.capabilities.renewal.validation.pa;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;

public class PAPolicyBackEndCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	public Validation isDriverAvailableInCurrentPolicy() {
		logger.info("Backend check for Driver in current policy");
		return checkDriverInPolicy("currentPeriod.lobs.personalAuto.driverDTOs");
	}
	
	public Validation isDriverAvailableInRenewalPolicy() {
		logger.info("Backend check for Driver in renewal policy");
		return checkDriverInPolicy("renewedPeriod.lobs.personalAuto.driverDTOs");
	}
	
	public Validation isVehicleAvailableInCurrentPolicy() {
		logger.info("Backend check for vehicle in current policy");
		return checkVehicleInPolicy("currentPeriod.lobs.personalAuto.vehicleDTOs");
	}
	
	public Validation isVehicleAvailableInRenewalPolicy() {
		logger.info("Backend check for vehicle in renewal policy");
		return checkVehicleInPolicy("renewedPeriod.lobs.personalAuto.vehicleDTOs");
	}
	
	private Validation checkDriverInPolicy(String driverPath) {
		logger.info("Backend check for Driver");
		JsonPath path = getPolicyData();
		int count = path.getList(driverPath).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String driverDto = driverPath + "[" + i + "]";
			System.out.println(DataFormatUtil.getNodeValue(path, driverDto, "licenseNumber"));
			if (DataFormatUtil.getNodeValue(path, driverDto, "licenseNumber").equals(data.get("LICENSE_NUMBER"))) {
				logger.info("Driver is available in policy");
				new Validation(DataFormatUtil.getNodeValue(path, driverDto, "firstName"), data.get("FIRST_NAME")).shouldBeEqual("First name is not matched");
				new Validation(DataFormatUtil.getNodeValue(path, driverDto, "lastName"), data.get("LAST_NAME")).shouldBeEqual("Last name is not matched");
				String dob = (Integer.parseInt(DataFormatUtil.getNodeValue(path, driverDto +".dateOfBirth", "month"))+1) + "/" + DataFormatUtil.getNodeValue(path, driverDto +".dateOfBirth", "day")
									+ "/" +DataFormatUtil.getNodeValue(path, driverDto +".dateOfBirth", "year").substring(2);
				new Validation(dob, data.get("DOB_TO_CHECK")).shouldBeEqual("DOB is not matched");
				covFlag = true;
				break;
			}
		}
		return new Validation(covFlag);
	}

	public Validation checkVehicleInPolicy(String vehiclePath) {
		logger.info("Backend check for Vehicle");
		JsonPath path = getPolicyData();
		int count = path.getList(vehiclePath).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String vehicleDto = vehiclePath + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, vehicleDto, "make").equals(data.get("MAKE")) && DataFormatUtil.getNodeValue(path, vehicleDto, "model").equals(data.get("MODEL")) && DataFormatUtil.getNodeValue(path, vehicleDto, "year").equals(data.get("YEAR"))) {
				logger.info("Vehicle is available in policy");
				covFlag = true;
			}
		}
		return new Validation(covFlag);
	}

	public static JsonPath getPolicyData() {
		return new JsonPath(DataFetch.getAccountPolicyData(ThreadLocalObject.getData().get("POLICY_NUM")));
		//return new JsonPath(DataFetch.getAccountPolicyData("2799345392"));
	}

public static void main(String[] args) {
	PAPolicyBackEndCheck backEndCheck = new PAPolicyBackEndCheck();
	backEndCheck.isVehicleAvailableInCurrentPolicy().shouldBeTrue();
	backEndCheck.isVehicleAvailableInRenewalPolicy().shouldBeTrue();
	backEndCheck.isDriverAvailableInCurrentPolicy().shouldBeTrue();
	backEndCheck.isDriverAvailableInRenewalPolicy().shouldBeTrue();
}	
	

}
