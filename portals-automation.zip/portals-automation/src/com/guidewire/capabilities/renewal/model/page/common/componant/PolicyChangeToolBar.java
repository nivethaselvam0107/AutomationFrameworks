package com.guidewire.capabilities.renewal.model.page.common.componant;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class PolicyChangeToolBar extends CommonPage{

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	Logger logger = Logger.getLogger(this.getClass().getName());

	// Toolbar buttons
	@FindBy(css = "li[heading='Current'] a")
	WebElement CURRENT_POLICY_TAB_BTN;
	
	@FindBy(css = "[ng-repeat='tab in tabs'][class*=active]:nth-of-type(1) [ng-if='canChangePolicy(policy)'] a")
	WebElement CURRENT_POLICY_CHANGE_BTN;

	@FindBy(css = "[ng-repeat='tab in tabs'][class*=active]:nth-of-type(2) [ng-if='canChangePolicy(policy)'] a")
	WebElement RENEWAL_POLICY_CHANGE_BTN;

	By RENEWING_POLICY_TAB = By.cssSelector("li[heading='Renewing'] a");
	By CURRENT_POLICY_TAB = By.cssSelector("li[heading='Current'] a");
	By ACTIVE_RENEWING_POLICY_TAB = By.cssSelector("li[heading='Renewing'][class*='active'] a");
	By ACTIVE_CURRENT_POLICY_TAB = By.cssSelector("li[heading='Current'][class*='active'] a");
	By RENEWAL_POLICY_CHANGE_BTN_CSS = By.cssSelector("[ng-repeat='tab in tabs'][class*=active]:nth-of-type(2) [ng-if='canChangePolicy(policy)'] a");
	By CURRENT_POLICY_CHANGE_BTN_CSS = By.cssSelector("[ng-repeat='tab in tabs'][class*=active]:nth-of-type(1) [ng-if='canChangePolicy(policy)'] a");
	
	public PolicyChangeToolBar openRenewalPolicyTab(){
		seleniumCommands.waitForElementToBeVisible(CURRENT_POLICY_TAB_BTN);
		seleniumCommands.clickbyJS(RENEWING_POLICY_TAB);
		seleniumCommands.waitForElementToBeVisible(ACTIVE_RENEWING_POLICY_TAB);
		return this;
    }
	
	public PolicyChangeToolBar openCurrentPolicyTab(){
		seleniumCommands.clickbyJS(CURRENT_POLICY_TAB);
		seleniumCommands.waitForElementToBeVisible(ACTIVE_CURRENT_POLICY_TAB);
		return this;
    }
	
	public EndorsementWorkFlow startRenewalPolicyChange(){
		seleniumCommands.waitForElementToBeVisible(CURRENT_POLICY_TAB_BTN);
		seleniumCommands.clickbyJS(RENEWAL_POLICY_CHANGE_BTN);
		return new EndorsementWorkFlow();
    }
	
	public EndorsementWorkFlow startCurrentPolicyChange(){
		seleniumCommands.waitForElementToBeVisible(CURRENT_POLICY_TAB_BTN);
		seleniumCommands.clickbyJS(CURRENT_POLICY_CHANGE_BTN);
		return new EndorsementWorkFlow();
    }
	
	//Validation
	public Validation isPolicyRenewalPageIsAvailable(){
		seleniumCommands.waitForElementToBeVisible(CURRENT_POLICY_TAB_BTN);
		return new Validation(seleniumCommands.isElementPresent(RENEWING_POLICY_TAB));
    }
	
	public Validation isPolicyCurrentPageIsAvailable(){
		seleniumCommands.waitForElementToBeVisible(CURRENT_POLICY_TAB_BTN);
		return new Validation(seleniumCommands.isElementPresent(CURRENT_POLICY_TAB_BTN));
    }
	
	
	public Validation isRenewalPolicyChangeButtonIsAvailable(){
		seleniumCommands.waitForElementToBeVisible(ACTIVE_RENEWING_POLICY_TAB);
		return new Validation(seleniumCommands.isElementPresent(RENEWAL_POLICY_CHANGE_BTN_CSS));
    }
	
	public Validation isCurrentPolicyChangeButtonIsAvailable(){
		seleniumCommands.waitForElementToBeVisible(ACTIVE_CURRENT_POLICY_TAB);
		return new Validation(seleniumCommands.isElementPresent(CURRENT_POLICY_CHANGE_BTN_CSS));
    }

}
