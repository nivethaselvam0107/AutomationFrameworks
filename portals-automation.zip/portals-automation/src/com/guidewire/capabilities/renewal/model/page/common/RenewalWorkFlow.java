/**
 * 
 */
package com.guidewire.capabilities.renewal.model.page.common;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.renewal.model.page.common.componant.PolicyChangeToolBar;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class RenewalWorkFlow extends CommonPage{
	
	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

	@FindBy(css = ".gw-summary-and-links")
	WebElement ACCOUNT_PAGE;

	private String POLICY_LINK_XPATH = "//table[contains(@class,'gw-table gw-policy-summaries')]//a[contains(@href,'POLICY_NUM')]";

	private String POLICY_STATUS_PATH = "/../preceding-sibling::td[@title='Status']/span[@aria-hidden='false']";
	
	public void openPolicyDetailsPage() {
		seleniumCommands.waitForElementToBeVisible(ACCOUNT_PAGE);
		seleniumCommands.staticWait(4);
		seleniumCommands.clickbyJS(By.xpath(POLICY_LINK_XPATH.replace("POLICY_NUM", data.get(PolicyData.POLICY_NUM.toString()))));
	}
	
	
	//Get methods
	public String getPolicyStatus() {
		seleniumCommands.waitForElementToBeVisible(ACCOUNT_PAGE);
		seleniumCommands.staticWait(4);
		seleniumCommands.waitForElementToBeVisible(By.xpath(POLICY_LINK_XPATH.replace("POLICY_NUM", data.get(PolicyData.POLICY_NUM.toString()))));
		WebElement policyLink = seleniumCommands.findElement(By.xpath(POLICY_LINK_XPATH.replace("POLICY_NUM", data.get(PolicyData.POLICY_NUM.toString()))));
		String statusClass = policyLink.findElement(By.xpath("./../preceding-sibling::td[@title='Status']/span[@aria-hidden='false']")).getAttribute("class");
		return (statusClass.contains("clock") ? "Renewal" : "Active");
	}
	
	public RenewalWorkFlow login() throws TestFrameworkException {
		new Pagefactory().getAccountSummaryPage();
		return this;
	}
	
	public RenewalWorkFlow checkPolicyRenewalStatus() throws TestFrameworkException {
		seleniumCommands.logInfo("Validating Policy Renewal status");
		this.login().validatePolicyRenewalStatus();
		this.openPolicyDetailsPage();
		new PolicyChangeToolBar().isPolicyRenewalPageIsAvailable().shouldBeTrue("Policy renewal page is not available");
		return this;
	}
	
	public RenewalWorkFlow checkPolicyNonRenewalStatus() throws TestFrameworkException {
		seleniumCommands.logInfo("Validating Policy Non Renewal status");
		this.login().validatePolicyNonRenewalStatus();
		this.openPolicyDetailsPage();
		new PolicyChangeToolBar().isPolicyRenewalPageIsAvailable().shouldBeFalse("Policy renewal page is available");
		return this;
	}
	
	//Validation
	public Validation isPolicyNotListedUnderSummarySection() {
		seleniumCommands.waitForElementToBeVisible(ACCOUNT_PAGE);
		return new Validation(seleniumCommands.isElementPresent(By.xpath(POLICY_LINK_XPATH.replace("POLICY_NUM", data.get(PolicyData.POLICY_NUM.toString())))));
	}
	
	public void validatePolicyRenewalStatus() {
		new Validation(getPolicyStatus(), "Renewal").shouldBeEqual("Policy status is not set as renewal");
	}
	
	public void validatePolicyNonRenewalStatus() {
		new Validation(getPolicyStatus(), "Active").shouldBeEqual("Policy status is set as renewal");
	}
}
