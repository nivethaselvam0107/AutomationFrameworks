/**
 * 
 */
package com.guidewire.capabilities.renewal.model.page;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.qnb.pages.CommonPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HOPolicyDetailsPage extends CommonPage {

	Logger logger = Logger.getLogger(this.getClass().getName());

	By SCHEDULED_ITEMS_ROW = By.cssSelector(
			"[ng-repeat*='tab in tabs'][class*='active'] [ng-repeat='scheduledItem in allCoverages.scheduledItems']");

	By COVERAGES_SECTION_EXPAND_BUTTON = By.cssSelector(
			"[ng-repeat*='tab in tabs'][class*='active'] [gw-policy-dwelling-info] [gw-pl-accordion-group]:nth-of-type(4) [ng-click='toggleOpen()']");

	By MORTGAGEE_ROW = By.cssSelector("[ng-repeat*='tab in tabs'][class*='active'] [ng-repeat*='mortgageeDetail']");

	By HOME_SECTION_EXPAND_BUTTON = By.cssSelector(
			"[ng-repeat*='tab in tabs'][class*='active'] [gw-policy-dwelling-info] [gw-pl-accordion-group]:nth-of-type(1) [ng-click='toggleOpen()']");

	public HOPolicyDetailsPage() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
	}

	public HashMap<String, List<String>> getMortgageeDataFromPolicyDetailsPage() {
		HashMap<String, List<String>> mortGageeDataList = new HashMap<>();
		seleniumCommands.clickbyJS(HOME_SECTION_EXPAND_BUTTON);
		seleniumCommands.waitForElementToBeVisible(seleniumCommands.findElement(HOME_SECTION_EXPAND_BUTTON)
				.findElement(By.cssSelector("span[class*='chevron_open']")));
		List<WebElement> mortGageeList = seleniumCommands.findElements(MORTGAGEE_ROW);
		mortGageeList.forEach(el -> {
			List<WebElement> mortGageeData = seleniumCommands.findElements(el,
					By.cssSelector(".gw-one-quarter-size p"));
			List<String> cellData = new ArrayList<>();
			mortGageeData.forEach(td -> {
				cellData.add(td.getText());
			});
			mortGageeDataList.put(cellData.get(0), cellData);
		});
		return mortGageeDataList;
	}

	public HashMap<String, List<String>> getValuableDataFromPolicyDetailsPage() {
		HashMap<String, List<String>> valuableDataList = new HashMap<>();
		seleniumCommands.clickbyJS(COVERAGES_SECTION_EXPAND_BUTTON);
		seleniumCommands.waitForElementToBeVisible(seleniumCommands.findElement(COVERAGES_SECTION_EXPAND_BUTTON)
				.findElement(By.cssSelector("span[class*='chevron_open']")));
		List<WebElement> mortGageeList = seleniumCommands.findElements(SCHEDULED_ITEMS_ROW);
		mortGageeList.forEach(el -> {
			List<String> cellData = new ArrayList<>();
			seleniumCommands.staticWait(2);
			cellData.add(
					seleniumCommands.getTextAtLocator(el.findElement(By.cssSelector("[class*='coverage-item-name']"))));
			cellData.add(seleniumCommands
					.getTextAtLocator(el.findElement(By.cssSelector("[class*='gw-aTerm-name'] label"))));
			cellData.add(
					seleniumCommands.getTextAtLocator(el.findElement(By.cssSelector("[class*='gw-aTerm-amount']"))));
			valuableDataList.put(cellData.get(1), cellData);
		});
		return valuableDataList;
	}

	// Validation
	public Validation isValuableAvailableOnPolicyDetailsPage() throws Exception {
		seleniumCommands.logInfo("Validating Valuable on Policy page");
		HashMap<String, List<String>> driverMap = this.getValuableDataFromPolicyDetailsPage();
		if (!driverMap.containsKey(data.get("Valuable_Description"))) {
			return new Validation(false);
		}
		List<String> driverData = driverMap.get(data.get("Valuable_Description"));
		new Validation(driverData.get(0), data.get("Valuable_Type")).shouldBeEqual("Valuable Type is not matched");
		new Validation(driverData.get(2), data.get("Valuable_Cost")).shouldBeEqual("Valuable cost is not matched");
		return new Validation(true);
	}

	public Validation isMortgageeAvailableOnPolicyDetailsPage() throws Exception {
		HashMap<String, List<String>> driverMap = this.getValuableDataFromPolicyDetailsPage();
		if (!driverMap.containsKey(data.get("MortGagee_Name"))) {
			return new Validation(false);
		}
		List<String> driverData = driverMap.get(data.get("MortGagee_Name"));
		new Validation(driverData.get(1), data.get("MortGagee_Street"))
				.shouldBeEqual("Mortgagee street is not matched");
		new Validation(driverData.get(2), data.get("MortGagee_City")).shouldBeEqual("Mortgagee city is not matched");
		new Validation(driverData.get(3), data.get("MortGagee_State")).shouldBeEqual("Mortgagee state is not matched");
		return new Validation(true);
	}
}
