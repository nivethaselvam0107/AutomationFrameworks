package com.guidewire.capabilities.renewal.test.ho;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import com.guidewire.capabilities.endorsement.fixtures.data.RandomEndorsementData;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementTypeBox;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementValuables;
import com.guidewire.capabilities.renewal.model.page.common.RenewalWorkFlow;
import com.guidewire.capabilities.renewal.model.page.common.componant.PolicyChangeToolBar;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HORenewalTest {
	Pagefactory pagePactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2839 : Bound Renewal")
    public void testHOBoundRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundHORenewal();
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2846 : Draft Renewal")
    public void testHODraftRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicDraftHORenewal();
    		new RenewalWorkFlow().checkPolicyNonRenewalStatus();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2847 : Quoted Renewal")
    public void testHOQuotedRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicQuotedHORenewal();
    		new RenewalWorkFlow().checkPolicyNonRenewalStatus();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2851: Renewal for Cancelled HO Policy")
    public void testHOCancelledPolicyRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundPARenewal();
    		DataFetch.cancelPolicyByCarrier(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
    		new RenewalWorkFlow().login().isPolicyNotListedUnderSummarySection().shouldBeFalse("Cancelled HO policy is listed on the summary page");
    }
    
    @Parameters("browserName")
    @Test(groups = {"REG_EMR1"} , description = "TC2850 : Add Valuable for current policy", enabled=false)
    public void testAddValuableFromCurrentPolicy(String browserName) throws Exception {
    		RenewalGenerator.createBasicBoundHORenewal();
    		HashMap<String, String> data = ThreadLocalObject.getData();
    		data.put("Valuable_Cost", "2323");
    		data.put("Valuable_Type", "Cameras");
    		data.putAll(RandomEndorsementData.randomData());
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar().startCurrentPolicyChange();
    		endorsementWorkFlow.selectDate();
			EndorsementTypeBox endorsementTypeBox = new EndorsementTypeBox();
			endorsementTypeBox.selectValuables().goNext();
			new EndorsementEditToolBar().addValuable();
			EndorsementValuables endorsementValuables = new EndorsementValuables();
			endorsementValuables.fillValuableFormData();
			new EndorsementEditToolBar().saveEndorsement().check();
    }
}
