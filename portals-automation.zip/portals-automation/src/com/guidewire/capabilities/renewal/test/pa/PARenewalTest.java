package com.guidewire.capabilities.renewal.test.pa;

import java.util.HashMap;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import com.guidewire.capabilities.endorsement.fixtures.data.RandomEndorsementData;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementPaymentPage;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.PolicyChanges;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementTypeBox;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementAddressPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementCoveragesPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementDriverPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementVehiclePage;
import com.guidewire.capabilities.renewal.model.page.common.RenewalWorkFlow;
import com.guidewire.capabilities.renewal.model.page.common.componant.PolicyChangeToolBar;
import com.guidewire.capabilities.renewal.validation.pa.PAPolicyBackEndCheck;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class PARenewalTest {
	Pagefactory pagePactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2806 : Bound Renewal")
    public void testPABoundRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundPARenewal();
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2811 : Draft Renewal")
    public void testPADraftRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicDraftPARenewal();
    		new RenewalWorkFlow().checkPolicyNonRenewalStatus();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2812 : Quoted Renewal")
    public void testPAQuotedRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicQuotedPARenewal();
    		new RenewalWorkFlow().checkPolicyNonRenewalStatus();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2814 : Renewal for Cancelled Policy")
    public void testPACancelledPolicyRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundPARenewal();
    		DataFetch.cancelPolicyByCarrier(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
    		new RenewalWorkFlow().login().isPolicyNotListedUnderSummarySection().shouldBeFalse("Cancelled PA policy is listed on the summary page");
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2827 : Add driver for current PA policy")
    public void testAddDriverToCurrentPolicy(String browserName) throws Exception {
    		RenewalGenerator.createBasicBoundPARenewal();
    		ThreadLocalObject.getData().putAll(getDriverData());
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar().startCurrentPolicyChange();
    		endorsementWorkFlow.selectDate();
    		endorsementWorkFlow.addDriverDraftEndorsementStartingFromDateForm(true);
    		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
    		editToolBar.check();
    		new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
    		new EndorsementPaymentPage().goToHomePage();
    		new RenewalWorkFlow().openPolicyDetailsPage();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeTrue();
    		new PAPolicyBackEndCheck().isDriverAvailableInCurrentPolicy().shouldBeTrue();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    		PolicyDetailsPage detailsPage = new PolicyDetailsPage();
    		detailsPage.isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
     		detailsPage.isPolicyTransactionPresent();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC4776 : Multiple changes for renewing PA Policy History Display")
    public void testHistoryForMultiplePARenewalChanges(String browserName) throws Exception {
	    	RenewalGenerator.createBasicBoundPARenewal();
	    	HashMap<String, String> data = ThreadLocalObject.getData();
			data.putAll(getDriverData());
			data.putAll(getVehicleData());
			data.put("NewCity","Cali");
			new RenewalWorkFlow().checkPolicyRenewalStatus();
			EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar().startCurrentPolicyChange();
			endorsementWorkFlow.selectDate();
			EndorsementTypeBox endorsementTypeBox = new EndorsementTypeBox();
			endorsementTypeBox.selectAddress().selectDriver().selectVehicle().selectCovareges().goNext();
			endorsementWorkFlow.editAddress();
			new EndorsementEditToolBar().saveEndorsement();
			new EndorsementAddressPage().validateAddressDetailsInCart();

			new EndorsementEditToolBar().add();
			EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
			vehiclePage.assignDriverByIndex(0);
			vehiclePage.fillFormData();
			new EndorsementEditToolBar().saveEndorsement();
			new EndorsementEditToolBar().check();
			vehiclePage.isVehicleAddTranscationPresentInCart();
			
			new EndorsementEditToolBar().replace();
			EndorsementDriverPage driver= new EndorsementDriverPage();
			driver.selectExistingDriverForEdition("1");
			driver.assignVehicleByIndex(0);
			driver.assignVehicleByIndex(1);
			driver.fillFormData();
			new EndorsementEditToolBar().replaceEndorsement();
			driver.isDriverAddTranscationPresentInCart("added");
			new EndorsementEditToolBar().check();
			
			EndorsementCoveragesPage coveragesPage = new EndorsementCoveragesPage();
			coveragesPage.selectFirstUncheckedCoverage();
			coveragesPage.validateCoverageDataInCart("added");

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2868 : Replace vehicle for renewing policy")
    public void testReplaceVehicleToRenewalPolicy(String browserName) throws Exception {
	    	RenewalGenerator.createBasicBoundPARenewal();
	    	HashMap<String, String> data = ThreadLocalObject.getData();
			data.putAll(getVehicleData());
			new RenewalWorkFlow().checkPolicyRenewalStatus();
			EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar().openRenewalPolicyTab().startRenewalPolicyChange();
			endorsementWorkFlow.selectDate();
			EndorsementTypeBox endorsementTypeBox = new EndorsementTypeBox();
			endorsementTypeBox.selectVehicle().goNext();

			new EndorsementEditToolBar().replace();
			EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
			String vehicleSelected= vehiclePage.selectVehicleByIndex(1).trim();
			HashMap<String, String> replacedVehicleData =  new HashMap<>();
			String[] vehData = vehicleSelected.split(" ");
			replacedVehicleData.put("Make", vehData[1]);
			replacedVehicleData.put("Model", vehData[2]);
			replacedVehicleData.put("VehicleYear", vehData[0]);
			vehiclePage.assignDriverByIndex(0);
			vehiclePage.fillFormData();
			new EndorsementEditToolBar().replaceEndorsement();
			new EndorsementEditToolBar().check();
			new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
    		new EndorsementPaymentPage().goToHomePage();
    		new RenewalWorkFlow().openPolicyDetailsPage();
    		PolicyDetailsPage detailsPage = new PolicyDetailsPage();
    		detailsPage.isVehicleAvailableOnPolicyDetailsPage(detailsPage.getVehicleDataFromPolicyDetailsPage().get(0), replacedVehicleData).shouldBeTrue();
    		detailsPage.isVehicleAvailableOnPolicyDetailsPage(detailsPage.getVehicleDataFromPolicyDetailsPage().get(0), data).shouldBeFalse();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    		PolicyDetailsPage renewalDetailsPage = new PolicyDetailsPage();
    		renewalDetailsPage.isVehicleAvailableOnPolicyDetailsPage(detailsPage.getVehicleDataFromPolicyDetailsPage().get(0), data).shouldBeTrue();
    		renewalDetailsPage.isVehicleAvailableOnPolicyDetailsPage(detailsPage.getVehicleDataFromPolicyDetailsPage().get(0), replacedVehicleData).shouldBeFalse();
			
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC4778 : Cancel changes for renewing PA Policy")
    public void testCancelChangesToPARenewalPolicy(String browserName) throws Exception {
    		RenewalGenerator.createBasicBoundPARenewal();
    		ThreadLocalObject.getData().putAll(getDriverData());
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar()
    				.openRenewalPolicyTab().startRenewalPolicyChange();
    		endorsementWorkFlow.selectDate();
    		endorsementWorkFlow.addDriverDraftEndorsementStartingFromDateForm(true);
    		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
    		editToolBar.check();
    		new PolicyChanges().cancelWithDrawEndorsement();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    		PolicyDetailsPage detailsPage = new PolicyDetailsPage();
    		detailsPage.isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
    		detailsPage.isPolicyTransactionPresent();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC4779 : Cancel changes for current PA Policy")
    public void testCancelChangesToPACurrentPolicy(String browserName) throws Exception {
    		RenewalGenerator.createBasicBoundPARenewal();
    		ThreadLocalObject.getData().putAll(getDriverData());
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar()
    				.startCurrentPolicyChange();
    		endorsementWorkFlow.selectDate();
    		endorsementWorkFlow.addDriverDraftEndorsementStartingFromDateForm(true);
    		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
    		editToolBar.check();
    		new PolicyChanges().cancelWithDrawEndorsement();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2837 : Remove driver for renewing policy" , enabled = false)
    public void testRemoveDriverToCurrentPolicy(String browserName) throws Exception {
    		HashMap<String, String> data = ThreadLocalObject.getData();
    		data.put("POLICY_NUM", "9367856936");
 			DataFetch.createRenewal(data.get("POLICY_NUM"), "Bound");
 			new RenewalWorkFlow().checkPolicyRenewalStatus();
 			EndorsementWorkFlow endorsementWorkFlow = new PolicyChangeToolBar().openRenewalPolicyTab().startRenewalPolicyChange();
    		endorsementWorkFlow.selectDate();
    		endorsementWorkFlow.selectDriver().clickRemove();
    		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
    		String driverName = editToolBar.selectEndorsementandAndGetCellvalue(1,2);
    		String lisence = editToolBar.selectEndorsementandAndGetCellvalue(1,4);
    		String dob = editToolBar.selectEndorsementandAndGetCellvalue(1,3);
    		data.put("LICENSE_NUMBER", lisence);
    		data.put("FIRST_NAME", driverName.split(" ")[0]);
    		data.put("LAST_NAME", driverName.split(" ")[1]);
    		data.put("DOB_TO_CHECK", dob);
    		endorsementWorkFlow.deleteAndCheck();
    		new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
    		new EndorsementPaymentPage().goToHomePage();
    		new RenewalWorkFlow().openPolicyDetailsPage();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeTrue();
    		new PAPolicyBackEndCheck().isDriverAvailableInCurrentPolicy().shouldBeTrue();
    		new PolicyChangeToolBar().openRenewalPolicyTab();
    		new PAPolicyBackEndCheck().isDriverAvailableInRenewalPolicy().shouldBeFalse();
    		new PolicyDetailsPage().isDriverAvailableOnPolicyDetailsPage().shouldBeFalse();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2827 : Add driver for current PA policy" , enabled = false)
    public void testAddVehicleToCurrentPolicy(String browserName) throws Exception {
    		RenewalGenerator.createBasicBoundPARenewal();
    		ThreadLocalObject.getData().putAll(getVehicleData());
    		new RenewalWorkFlow().login().openPolicyDetailsPage();
    		System.out.println(new PolicyDetailsPage().getVehicleDataFromPolicyDetailsPage());
    }
    
    private HashMap<String, String> getDriverData() {
    	HashMap<String, String> driverData = new HashMap<>();
    	driverData.put("GENDER", "Male");
    	driverData.put("ACCIDENTS", "1");
    	driverData.put("VIOLATIONS", "1");
    	driverData.put("STATE", "California");
    	driverData.put("LICENSE_STATE_VALUE", "CA");
    	driverData.put("YEAR_LICENSED", "2014");
    	driverData.put("LICENSE_NUMBER", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
    	driverData.put("FIRST_NAME", "Lee");
    	driverData.put("LAST_NAME", "Carvallo");
    	driverData.put("DOB", "10/10/1987");
    	driverData.put("DOB_TO_CHECK", "10/10/87");
		return driverData;
    }
    
    private HashMap<String, String> getVehicleData() {
    	HashMap<String, String> vehicleData = new HashMap<>();
    	vehicleData.put("VehicleCost", "10000.0");
    	vehicleData.put("VIN", "XYZ");
    	vehicleData.put("Model", "Cooper");
    	vehicleData.put("Make", "Mini");
    	vehicleData.put("VehicleYear", "2014");
    	vehicleData.put("LicensePlate", "XVXVXV");
    	vehicleData.put("VehicleState", "California");
    	vehicleData.put("VehicleCost", "10000.00");
		vehicleData.put("COST_NEW", "$10,000.00");
		vehicleData.put("COST_DESC", "$10,000.00");
		vehicleData.put("STATE_VALUE", "CA");
		vehicleData.put("LICENSE_STATE_VALUE", "CA");
		vehicleData.put("YEAR_LICENSED", "2014");
		vehicleData.put("LICENSE_NUMBER", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		vehicleData.put("DOB_TO_CHECK", "October 10, 1987");
		vehicleData.putAll(RandomEndorsementData.randomData());
		return vehicleData;
    }
}
