package com.guidewire.capabilities.renewal.test.others;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import com.guidewire.capabilities.renewal.model.page.common.RenewalWorkFlow;
import com.guidewire.capabilities.renewal.model.page.common.componant.PolicyChangeToolBar;
import com.guidewire.common.selenium.TestFrameworkException;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class OtherRenewalTest {
	Pagefactory pagePactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2838 : Renewal for Inland Marine")
    public void testIMBoundRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundIMRenewal();
    		new RenewalWorkFlow().checkPolicyRenewalStatus();
    		PolicyChangeToolBar changeToolBar = new PolicyChangeToolBar();
    		changeToolBar.isCurrentPolicyChangeButtonIsAvailable().shouldBeFalse("Change current policy button is present");
    		changeToolBar.openRenewalPolicyTab().isRenewalPolicyChangeButtonIsAvailable().shouldBeFalse("Change renwal policy button is present");
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"} , description = "TC2834 : Renewal for General Liability")
    public void testGLBoundRenewal(String browserName) throws TestFrameworkException {
    		RenewalGenerator.createBasicBoundGLRenewal();
		new RenewalWorkFlow().checkPolicyRenewalStatus();
		PolicyChangeToolBar changeToolBar = new PolicyChangeToolBar();
		changeToolBar.isCurrentPolicyChangeButtonIsAvailable().shouldBeFalse("Change current policy button is present");
		changeToolBar.openRenewalPolicyTab().isRenewalPolicyChangeButtonIsAvailable().shouldBeFalse("Change renwal policy button is present");
    }
    
}
