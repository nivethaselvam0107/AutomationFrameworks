package com.guidewire.capabilities.endorsement.test.pa.agent;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.component.ActivitiesScheduleComponent;
import com.guidewire.capabilities.agent.model.component.AddActivityComponent;
import com.guidewire.capabilities.agent.model.component.AddNoteComponent;
import com.guidewire.capabilities.agent.model.component.NavBar;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.GPA_ActivityPageFactory;
import com.guidewire.capabilities.agent.model.page.PolicyChangeSummaryPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementAddressPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementDriverPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementVehiclePage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.widgetcomponents.tile.DateTimeTile;

public class PAEndorsementTest {

    EndorsementWorkFlow endorsementWorkFlow = new EndorsementWorkFlow();

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3974:PolicyChange-PAPolicy")
    public void testPAPolicyChangeWizardEntry(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        new EndorsementPage().isEndorsementWizardDisplayed().shouldBeTrue("User didn't enter endorsement wizard");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3972: MissingMandatoryValuesWhileAddingNewDriverInPolicyChange")
    public void testPAAddDriverMandatoryFields(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectDriver().clickAdd();
        EndorsementDriverPage endorsementDriverPage = new EndorsementDriverPage();
        endorsementDriverPage.addewDriverButton();
        endorsementDriverPage.isAddEnabledForNewDriver().shouldBeFalse("Add button enabled");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3972: MissingMandatoryValuesWhileAddingNewVehicleInPolicyChange")
    public void testPAAddVehicleMandatoryFields(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle().clickAdd();

        new EndorsementVehiclePage().isAddEnabledForNewVehicle().shouldBeFalse("Add button enabled");
    }

    @Parameters("browserName")
    @Test(groups ={"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3973: MissingMandatoryValuesWhileUpdatingAddressInPolicyChange")
    public void testPAChangeAddressMandatoryFields(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();

        EndorsementAddressPage endorsementAddressPage = new EndorsementAddressPage();
        endorsementAddressPage.setAddressLine1("");
        endorsementAddressPage.isNextEnabledForAddress().shouldBeFalse("Next button enabled");
        endorsementAddressPage.setAddressLine1("Palo Alto 77");
        endorsementAddressPage.setCity("");
        endorsementAddressPage.isNextEnabledForAddress().shouldBeFalse("Next button enabled");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3975: UnableToSelectDateInPastEffectiveDateForPolicyChange")
    public void testPAPastDateEndorsement(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        DateTimeTile dateTile = new DateTimeTile();
        String effectiveDate = dateTile.getSelectedDate();
        String newDate = dateTile.setPastDate();
        dateTile.isDateSetToPastDate(effectiveDate, newDate).shouldBeEqual("Date was set to past date");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3994: AddActivityOnPolicyChangeDetails")
    public void testPAAddActivityOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToOpenActivitiesTile()
                .clickAddActivityBtn();

        new GPA_ActivityPageFactory().addDefaultActivity();
        new ActivitiesScheduleComponent()
                .clickOnFirstActivity().canViewActivitySummary().shouldBeTrue("Activity is not created");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3995:CancelAddActivityOnPolicyChangeDetails")
    public void testPACancelAddActivityOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToOpenActivitiesTile()
                .clickAddActivityBtn();
        new AddActivityComponent()
                .withActivityTypeByText("Cancel a split policy")
                .withSubject("Cancel a split policy - cancel activity testcase")
                .clickCancelButton()
                .isAddActivityComponentVisible()
                .shouldBeFalse();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3996: AddNoteOnPolicyChangeDetailsPage")
    public void testPAAddNoteOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToNoteTile();
        new AddNoteComponent()
                .addGeneralNote(SeleniumCommands.generateUUID())
                .isNoteAdded().shouldBeTrue("Note didn't get added");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3997: CancelAddNoteOnPolicyChangeDetailsPage")
    public void testPACancelAddNoteOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToNoteTile();
        new AddNoteComponent()
                .addNoteMandatoryFields()
                .cancelAddingNote()
                .isNoteAdded().shouldBeFalse("Note got added");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC3998: UploadDocOnPolicyChangeDetailsPage")
    public void testPAUploadDocOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToDocumentsTile();
        new DocumentsTab().uploadDocFromSummary();
        new DocumentsTab().isDocAdded().shouldBeEqual("Document didn't upload");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4003:DeleteDocOnPolicyChangeDetailsPage")
    public void testPADeleteDocOnPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectAddress();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage()
                .goToDocumentsTile();
        DocumentsTab documentsTab = new DocumentsTab();
        documentsTab.uploadDocFromSummary();
        documentsTab.isDocAdded().shouldBeEqual("Document didn't upload");
        documentsTab.deleteDoc().isDocTableEmpty().shouldBeTrue("Document was not deleted");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4000: WithdrawDraftPolicyChangeforPA")
    public void testPAWithdrawDraftPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage().withdrawPolicyChange().validatePolicyChangeStatus("Withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4002: ContinueDraftPolicyChangeforPA")
    public void testPAContinueDraftPolicyChange(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickSaveAndExit();
        new PolicyChangeSummaryPage().continuePolicyChange();
        new EndorsementPage().isEndorsementWizardDisplayed().shouldBeTrue("User didn't enter endorsement wizard");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4006: ViewPolicyChangeDetailPageFromDashboard")
    public void testPAOpenChangesFromDashboard(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickSaveAndExit();
        String jobNumber = new NavBar().goToDashBoard().goToOpenPolicyChanges().openFirstJob();
        new PolicyChangeSummaryPage().isEndorsementPageDisplayed(jobNumber).shouldBeTrue("Policy Change detail page wasn't displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4008: ViewPolicyChangePageFromAccDetails")
    public void testPAOpenChangesFromAccount(String browserName)throws TestFrameworkException {
    	 HashMap<String, String> data = ThreadLocalObject.getData();
         data.put("GENDER","Male");
         data.put("ACCIDENTS","1");
         data.put("VIOLATIONS","1");
         data.put("STATE","California");
         data.put("YEAR_LICENSED","2014");
         data.put("FIRST_NAME","Lee");
         data.put("LAST_NAME","Carvallo");
         data.put("DOB","10/10/1987");
         data.put("DOB_TO_CHECK","October 10, 1987");
         data.put("LICENSE_NUMBER","321111");
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.addDriverDraftEndorsementStartingFromDateForm(true);
        new EndorsementPage().clickSaveAndExit();
        String jobNumber = new PolicyChangeSummaryPage().getPolicyChangeJobNumber();
        new NavBar().goToDashBoard();
        new AgentDashboard()
                .goToAccounts()
                .showPersonalAccounts()
                .showRecentlyCreated()
                .openFirstAccount()
                .goToOpenTransactionsTile().goToActivitiesTile()
                .goToOpenTransactionsTile().openFirstJob();
        new PolicyChangeSummaryPage().isEndorsementPageDisplayed(jobNumber).shouldBeTrue("Policy Change detail page wasn't displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4026: ViewPolicyChangeDetailFromPoliciesOpenTransactions")
    public void testPAOpenChangesFromPolicyDetailPage(String browserName)throws TestFrameworkException {
        String policyNum = this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickSaveAndExit();
        String jobNumber = new PolicyChangeSummaryPage().getPolicyChangeJobNumber();
        new NavBar().goToDashBoard();
        new AgentDashboard()
                .goToPolicies()
                .showOpenChanges()
                .openJob(jobNumber);

        new PolicyChangeSummaryPage().isEndorsementPageDisplayed(jobNumber).shouldBeTrue("Policy Change detail page wasn't displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4005: ViewPolicyChangeDetailFromPoliciesOpenChanges")
    public void testPAOpenChangesFromPoliciesLanding(String browserName)throws TestFrameworkException {
        String policyNum = this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickSaveAndExit();
        String jobNumber = new PolicyChangeSummaryPage().getPolicyChangeJobNumber();
        new PolicyChangeSummaryPage().clickPolicyLink().openPolicyChangeDetailPage(jobNumber);

        new PolicyChangeSummaryPage().isEndorsementPageDisplayed(jobNumber).shouldBeTrue("Policy Change detail page wasn't displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4023: PolicyChange-WithdrawChangeWithinWizard")
    public void testPAWithdrawDraftPolicyChangeInWizard(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementPage().clickWithdraw();
        new PolicyChangeSummaryPage().validatePolicyChangeStatus("Withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4009:RemoveDriverWhenOnlyOneDriverAvaliable")
    public void testPARemoveOnlyDriver(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectDriver();
        new EndorsementEditToolBar().isRemoveButtonDisabled();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite","Diamond","Endorsement"}, description = "TC4025:RemoveVehicleWhenOnlyOneVehicleAvaliable")
    public void testPARemoveOnlyVehicle(String browserName)throws TestFrameworkException {
        this.startPolicyChange();
        endorsementWorkFlow.selectDate();
        endorsementWorkFlow.selectVehicle();
        new EndorsementEditToolBar().isRemoveButtonDisabled();
    }

    private void login(){
        new LoginPage().login();
    }

    private String startPolicyChange()
    {
        String policyNum = PolicyGenerator.createBasicBoundPAPolicy();
        login();
        new AgentDashboard()
                .searchUsingSearchBox(policyNum)
                .goToPolicy(policyNum)
                .changeMyPolicy();

        return policyNum;
    }
}


