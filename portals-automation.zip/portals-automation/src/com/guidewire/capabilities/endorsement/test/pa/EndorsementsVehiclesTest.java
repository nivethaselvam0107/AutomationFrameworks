package com.guidewire.capabilities.endorsement.test.pa;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.PolicyChanges;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementVehiclePage;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementBackEndCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;



public class EndorsementsVehiclesTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC4200 : Add a Vehicle")
	public void testAddAVehicle(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(true);
		new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
		new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN"));
	}

	@Parameters("browserName")
	@Test(groups = { "Regression" }, enabled = false)
	public void testReplaceAVehicle(String browserName) {
		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        String vehicleSelected = accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectOptions(false).
                selectOptions(false).
                selectVehicle().
                selectAction("Replace").
                selectVehicleByIndex(1);
               new EndorsementVehiclePage().fillFormData().
                getMakeYearModelAndPutInTestData().
                submit();
		EndorsementPage endorsementPage = new EndorsementPage();
		endorsementPage.hasHistoryItem("2010 Chevrolet Suburban").shouldBeTrue();
		endorsementPage.hasHistoryAction("2010 Chevrolet Suburban", "added").shouldBeEqual("Vehicle's status is added");
		endorsementPage.hasHistoryItem(vehicleSelected).shouldBeTrue();
        endorsementPage.hasHistoryAction(vehicleSelected, "removed").shouldBeEqual("Replaced vehicle's status is removed");
		endorsementPage.complete().quote().buy().confirm();
		EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
		vehiclePage.doesVehicleExistOnPolicyChangeFromBackend().shouldBeTrue();
		vehiclePage.isVehicleRemovedFromBackend("3").shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "Regression" }, enabled = false)
	public void testReplaceAVehicleOnPolicyWithOneVehicle(String browserName) {
		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectVehicle().
                selectAction("Replace").
                fillFormData().
                submit();
		EndorsementPage endorsementPage = new EndorsementPage();
		endorsementPage.hasHistoryItem("2010 Chevrolet Suburban").shouldBeTrue();
		endorsementPage.hasHistoryAction("added").shouldBeTrue();
		endorsementPage.hasHistoryItem("2003 Chevrolet Suburban").shouldBeTrue();
		endorsementPage.hasHistoryAction("removed").shouldBeTrue();
		endorsementPage.complete().quote().buy().confirm();
		EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
		vehiclePage.doesVehicleExistOnPolicyChangeFromBackend().shouldBeTrue();
		vehiclePage.isVehicleRemovedFromBackend("3").shouldBeTrue();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4203 : Remove a Vehicle")
	public void testRemoveVehicle(String browserName) throws TestFrameworkException {
		String vin = new EndorsementWorkFlow().buyRemovedVehicleEndorsement();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(vin).shouldBeFalse("Vehicle is not added to policy");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3179 : Attempt remove the only Vehicle")
	public void testTryRemoveOnlyVehicle(String browserName) throws TestFrameworkException {
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().goToSelectChanges().selectVehicle();
		new EndorsementEditToolBar().isRemoveButtonDisabled();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3180 : Edit a Vehicle")
	public void testEditVehicle(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().editVehicleEndorsement();
		new EndorsementVehiclePage().isVehicleEditTranscationPresentInCart();
		new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN"));
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite",	"Diamond" }, description = "AMP-153:AMP-111 : Endorsement - Pay in Full - Bank Account - Checking")
	public void testPayFullByCheckingBankAccount(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("PolicyType", "PersonalAuto");
		data.put("VehicleCost", "10000.0");
		data.put("COST_NEW", "$10,000.00");
		data.put("COST_DESC", "$10,000.00");
		data.put("STATE_VALUE", "CA");
		data.put("COMPREHENSIVE_DEDUC", "Comprehensive Deductible (500)");
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(true);
		new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
		new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN"));
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "AMP-153:AMP-112 : Endorsement - Pay in Full - Bank Account - Savings")
	public void testPayFullBySavingBankAccount(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();

		data.put("PolicyType", "PersonalAuto");
		data.put("VehicleCost", "10000.0");
		data.put("STATE_VALUE", "CA");
		data.put("VehicleState", "California");
		data.put("VehicleYear", "2014");
		data.put("COST_NEW", "$10,000.00");
		data.put("COST_DESC", "$10,000.00");
		data.put("STATE_VALUE", "CA");
		data.put("COMPREHENSIVE_DEDUC", "Comprehensive Deductible (500)");

		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(true);
		new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
		new EndorsementWorkFlow().quoteEndorsement().buyWithSavingBankAccount();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN"));
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "AMP-153:AMP-110 : Endorsement - Pay in Full - Credit Card")
	public void testPayFullByCreditCard(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("PolicyType", "PersonalAuto");
		data.put("VehicleCost", "10000.0");
		data.put("COST_NEW", "$10,000.00");
		data.put("COST_DESC", "$10,000.00");
		data.put("STATE_VALUE", "CA");
		data.put("COMPREHENSIVE_DEDUC", "Comprehensive Deductible (500)");
		data.put("VehicleState", "California");
		data.put("VehicleYear", "2014");
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(true);
		new EndorsementVehiclePage().isVehicleAddTranscationPresentInCart();
		new EndorsementWorkFlow().quoteEndorsement().buyWithCreditCard();
		new PAEndorsementBackEndCheck().isVehicleAvailableInPolicy(ThreadLocalObject.getData().get("VIN"));
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4204 : Validaton when no driver assigned to vehicle.")
	public void testValidationWhenNoDriverAssigned(String browserName) throws TestFrameworkException {
		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(false);
		new EndorsementVehiclePage().validateErrorMessageWhileNoDriverAssigned();
	}

	// No Edit button in Err msg
	@Parameters("browserName")
	@Test(groups = { "Regression" }, enabled = false)
	public void testValidationWhenNoDriverAssignedThenEdit(String browserName) {
		SeleniumCommands seleniumCommands = new SeleniumCommands();
		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        EndorsementPage endorsementPage = accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectVehicle().
                selectAction("Add").
                fillFormData().
                getMakeYearModelAndPutInTestData().
                submit();
		new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No driver assigned to Chevrolet Suburban 2010 (321/CA)')]"))
        ).shouldBeTrue();
		EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
		vehiclePage.clickChangeVehicleWarningButton().assignDriverByIndex(0).submit();
		new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No driver assigned to Chevrolet Suburban 2010 (321/CA)')]"))
        ).shouldBeFalse();
		endorsementPage.complete().quote().buy().confirm();
		vehiclePage.doesVehicleExistOnPolicyChangeFromBackend().shouldBeTrue();
	}

	// No Edit button in Err msg
	@Parameters("browserName")
	@Test(groups = { "Regression" }, enabled = false)
	public void testValidationWhenNoDriverAssignedThenRemove(String browserName) {
		SeleniumCommands seleniumCommands = new SeleniumCommands();
		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
		accountSummaryPage.
				changeMyPolicy().
				selectPolicy().
				selectEffectiveDate().
				selectVehicle().
				selectAction("Add").
				fillFormData().
				submit();
		new Validation(seleniumCommands.isElementPresent(
				By.xpath("//span[contains(text(),'No driver assigned to Chevrolet Suburban 2010 (321/CA)')]"))
		).shouldBeTrue();
		EndorsementVehiclePage vehiclePage = new EndorsementVehiclePage();
		vehiclePage.clickRemoveVehicleWarningButton().confirmRemoveVehicle();
		new Validation(seleniumCommands.isElementPresent(
				By.xpath("//span[contains(text(),'No driver assigned to Chevrolet Suburban 2010 (321/CA)')]"))
		).shouldBeFalse();

	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"}, description = "TC3206 : Withdraw a quoted PA endorsement")
	public void testWithdrawAQuotedPAEndorsement(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("PolicyType", "PersonalAuto");
		data.put("VIN", "123456");
		data.put("VehicleCost", "10000.0");
		data.put("STATE_VALUE", "CA");
		data.put("VehicleState", "California");
		data.put("VehicleYear", "2014");
		data.put("LicensePlate", "XJDJHJD23");
		data.put("Make", "Mini");
		data.put("Model", "Cooper");

		PolicyGenerator.createBasicBoundPAPolicy();
		new EndorsementWorkFlow().addVehicleDraftEndorsement(true);
		new EndorsementWorkFlow().quoteEndorsement();

		new PolicyChanges().withDrawEndorsement();
		PolicyDetailsPage detailsPage = new PolicyDetailsPage();
		detailsPage.isPolicyTransactionPresent();
		}
	}

