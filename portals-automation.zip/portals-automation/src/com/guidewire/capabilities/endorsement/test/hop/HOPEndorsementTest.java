package com.guidewire.capabilities.endorsement.test.hop;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import org.apache.http.auth.AUTH;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created by dfedo on 26/10/2017.
 */
public class HOPEndorsementTest {

    @Parameters("browserName")
    @Test(groups = { "HOP" } , description = "TC4222 @ Edit a Mortgagee - Policy with exisiting Mortgagee" )
    public void testHOPEditMortgagee(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);

        new EndorsementWorkFlow().buyEditedMortgageeEndorsement();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" } , description = "TC4223 @ Change Coverage")
    public void testHOPEditCoverages(String browserName) throws Exception {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        new EndorsementWorkFlow().buyCoverageChageEndorsement();
        ThreadLocalObject.getData().put("ALL_OTHER_PERILS", "1000");
        new HOEndorsementBackEndCheck().isCoverageChangesAvailableInPolicy().shouldBeTrue("Coverage details are updated for the policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC4225 @ Add a Mortgagee")
    public void testHOPAddMortgagee(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        new EndorsementWorkFlow().buyAddMortageeEndorsement();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" } , description = "TC4224 @ DEFECT**DE7722** Delete a Mortgagee - Policy with exisiting Mortgagee")
    public void testHOPDeleteMortgagee(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(new EndorsementWorkFlow().buyRemoveMortgageeEndorsement()).shouldBeFalse("Mortgagee is not deleted from policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" } , description = "TC4229 @ Add a Valuable")
    public void testHOPAddValuable(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        ThreadLocalObject.getData().put("Valuable_Desc","Scheduled Personal Property");
        new EndorsementWorkFlow().buyAddValuableEndorsement();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables is not added to policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC4228 @ DEFECT**DE7721** Edit a Valuable - Policy with exisiting Valuable")
    public void testHOPEditValuable(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        new EndorsementWorkFlow().buyEditedValuableEndorsement();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables edit changes are not applied to policy");
    }


    @Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC4227 @ DEFECT**DE7719** Delete a Valuable - Policy with exisiting Valuable")
    public void testHOPDeleteValuable(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        DataFetch.cancelPolicyChange(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(new EndorsementWorkFlow().buyRemoveValuableEndorsement()).shouldBeFalse("Valuables is not deleted from policy");
    }

    @Parameters("browserName")
    @Test(groups = { "HOP" }, description = "TC4226 @ DEFECT**DE7717** Replace a Mortgagee - Policy with exisiting Mortgagee" )
    public void testHOPReplaceMortgageeEndorsement(String browserName) throws TestFrameworkException {
        String newPolicy = DataFetch.createPolicyCopy(ThreadLocalObject.getData().get("POLICY_NUM"));
        new AuthorisationServer().assignPolicy(newPolicy);
        new EndorsementWorkFlow().buyReplacedMortgageeEndorsement();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
    }
}
