package com.guidewire.capabilities.endorsement.test.ho;

import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementMortagee;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementDriverPage;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementBackEndCheck;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementHistoryCheck;
import com.guidewire.data.DataFetch;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.tile.DateTimeTile;

import java.util.HashMap;

public class EndorsementMortageeTest {
    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "SMOKE"}, description = "TC3230 @ Add a Mortgagee")
    public void testAddMortgagee(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().buyAddMortageeEndorsement();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3237 @ Edit a Mortgagee - Policy with exisiting Mortgagee")
    public void testEditMortgagee(String browserName) throws TestFrameworkException {
        if (DataFetch.getPolicyData("user", ThreadLocalObject.getData().get("POLICY_NUM")) == null) {
            RenewalGenerator.createRenewal("Bound");
        }
        new EndorsementWorkFlow().buyEditedMortgageeEndorsement();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3241 @ Withdraw quoted policy transaction")
    public void testWithdrawQuotedEndorsement(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().withDrawQuotedMortgageeEndorsement().shouldBeFalse("Quoted endorsement is not withdrawn");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3236 @ Delete a Mortgagee - Policy with exisiting Mortgagee")
    public void testDeleteMortgagee(String browserName) throws TestFrameworkException {
        if (DataFetch.getPolicyData("user", ThreadLocalObject.getData().get("POLICY_NUM")) == null) {
            RenewalGenerator.createRenewal("Bound");
        }
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(new EndorsementWorkFlow().buyRemoveMortgageeEndorsement()).shouldBeFalse("Mortgagee is not deleted from policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3242 @ Withdraw quoted policy transaction - Selecting No")
    public void testCancelWithdrawQuotedEndorsementAction(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().cancelWithDrawQuotedMortgageeEndorsement().shouldBeTrue("Quoted endorsement is not withdrawn");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "AMP-137 @ Withdraw quoted policy transaction - Selecting No")
    public void testFutureBoundEndorsement(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        EndorsementWorkFlow workFlow = new EndorsementWorkFlow();
        String effectiveDate = workFlow.addMortageeEndorsementWithFutureDate();
        new AccountSummaryPage().goToHome();
        workFlow.selectPolicy();
        DateTimeTile dateTile = new DateTimeTile();
        String date = dateTile.getSelectedDate();
        new Validation(date, effectiveDate).shouldBeEqual("Endorsement date is not set to future date");
        String newDate = dateTile.setPastDate();
        new Validation(newDate, effectiveDate).shouldBeEqual("Endorsement date is set to past date");
    }

    @Parameters("browserName")
    //Policy needs to be changed for policy containing only one Mortgagee. Sample data needs to be updated for ferrite and ferrite 9.1
    //DE7554
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC4211 : Replace Existing Mortgagee", enabled = false)
    public void testReplaceExisitingMortgagee(String browserName) throws Exception {

        HashMap<String, String> data = ThreadLocalObject.getData();

        data.put("MortGagee_Street", "123 Baker street_Edited");
        data.put("MortGagee_City", "Foster City");
        data.put("MortGagee_State", "California");
        data.put("MortGagee_State_Value", "CA");
        data.put("MortGagee_Zip", "90210");
        data.put("MortGagee_Eff_date:", "");

        String replacedMortagee = new EndorsementWorkFlow().goToSelectChanges().selectMortgagee().replaceMortgagee();
        new EndorsementMortagee().isMortgageeReplacedTranscationPresentInCart(replacedMortagee);
        new HOEndorsementHistoryCheck().isMogtgageeAddedToCart("added", "Draft");
        new EndorsementWorkFlow().quoteEndorsement();
        new HOEndorsementHistoryCheck().isMogtgageeAddedToCart("added", "Quoted");
        new EndorsementWorkFlow().buyWithCheckingBankAccount();
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not applied to policy");
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(replacedMortagee).shouldBeFalse("MortGagee is still present");
    }
}
