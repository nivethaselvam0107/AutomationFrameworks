package com.guidewire.capabilities.endorsement.test.pa;

import java.util.HashMap;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.PolicyChanges;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementDriverPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementBackEndCheck;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;

public class EndorsementsDriversTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3183 : Add a New Driver")
    public void testAddADriver(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new EndorsementWorkFlow().addDriverDraftEndorsement(true);
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("added");
        new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("VIN")) ;
    }

    //Has to modify the test as per new flow
	   @Parameters("browserName")
	    @Test(groups = {"Regression"}, enabled = false)
	    public void testAddExistingDriver(String browserName) {
	        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
	      String driverName =  accountSummaryPage.
	                changeMyPolicy().
	                selectPolicy().
	                selectEffectiveDate().
	                selectDriver().
	                selectAction("Edit").
	                selectExistingDriverForEdition("1");
	      new EndorsementDriverPage().fillFormData().
	                getFirstNameAndPutInTestData().
	                getLastNameAndPutInTestData().
	                updateChange();
	        EndorsementPage endorsementPage = new EndorsementPage();
	        endorsementPage.hasHistoryItem(ThreadLocalObject.getData().get("NAME_TO_CHECK")).shouldBeTrue();
	        endorsementPage.hasHistoryAction("added").shouldBeTrue();
	        endorsementPage.complete().quote().buy().confirm();
	        EndorsementDriverPage page = new EndorsementDriverPage();
	        page.doesDriverExistOnPolicyChangeFromBackend().shouldBeTrue();
}
           @Parameters("browserName")
           @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"} , description = "TC4208 : Replace Only Driver On Policy")
           public void testReplaceOnlyDriver(String browserName) throws Exception {

               PolicyGenerator.createBasicBoundPAPolicy();
               HashMap<String, String> data = ThreadLocalObject.getData();
               data.put("GENDER", "Male");
               data.put("ACCIDENTS", "0");
               data.put("VIOLATIONS", "0");
               data.put("STATE", "California");
               data.put("LICENSE_STATE_VALUE", "CA");
               data.put("YEAR_LICENSED", "2014");
               data.put("FIRST_NAME", "Lee");
               data.put("LAST_NAME", "Carvallo");
               data.put("DOB", "10/10/1987");
               data.put("DOB_TO_CHECK", "10/10/87");
               new EndorsementWorkFlow().goToSelectChanges().selectDriver().replaceFirstDriver();
               new PAEndorsementHistoryCheck().isDriverAddedToCart("added", "Draft").shouldBeTrue("Driver is not added to history");
               new EndorsementWorkFlow().quoteEndorsement();
               new PAEndorsementHistoryCheck().isDriverAddedToCart("added", "Quoted").shouldBeTrue("Driver is not added to history");
               new EndorsementWorkFlow().buyWithCheckingBankAccount();

               new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("LICENSE_NUMBER")) ;


           }


	//Has to modify the test as per new flow but replace is not working
    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testReplaceDriver(String browserName) {
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        String driverName =  accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectDriver().
                selectAction("Replace").
                selectExistingDriverForEdition("1");
                new EndorsementDriverPage().fillFormData().
                submit();
        EndorsementPage endorsementPage = new EndorsementPage();
        endorsementPage.hasHistoryItem(ThreadLocalObject.getData().get("NAME_TO_CHECK_1")).shouldBeTrue();
        endorsementPage.hasHistoryAction("added").shouldBeTrue();
        endorsementPage.hasHistoryItem(ThreadLocalObject.getData().get("NAME_TO_CHECK_2")).shouldBeTrue();
        endorsementPage.hasHistoryAction("removed").shouldBeTrue();
        endorsementPage.complete().quote().buy().confirm();
        EndorsementDriverPage page = new EndorsementDriverPage();
        page.doesDriverExistOnPolicyChangeFromBackend().shouldBeTrue();
        page.isDriverRemovedFromBackend("333331").shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond", "SMOKE"}, description = "TC3184 : Remove a Driver")
    public void testRemoveDriver(String browserName) throws Exception {
        String lisence =  new EndorsementWorkFlow().buyRemovedDriverEndorsement();
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(lisence).shouldBeFalse("Vehicle is avaliable in the policy while it shouldn't");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" }, description = "TC3185 : Attempt to remove only Driver from policy")
    public void testRemoveOnlyDriver(String browserName)throws TestFrameworkException {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new EndorsementWorkFlow().goToSelectChanges().selectDriver();
        new EndorsementEditToolBar().isRemoveButtonDisabled();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3186 : Edit a Driver")
    public void testEditDriver(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new EndorsementWorkFlow().editDriverEndorsement();
        new EndorsementDriverPage().isDriverAddTranscationPresentInCart("changed");
        new EndorsementWorkFlow().quoteEndorsement().buyWithCheckingBankAccount();
        new PAEndorsementBackEndCheck().isDriverAvailableInPolicy(ThreadLocalObject.getData().get("LICENSE_NUMBER")) ;

    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3181 : Validaton when no vehicle assigned to driver.")
    public void testValidationWhenNoVehicleAssigned(String browserName)throws TestFrameworkException {
    		PolicyGenerator.createBasicBoundPAPolicy();
        new EndorsementWorkFlow().addDriverDraftEndorsementWithoutCoverages(false);
        new EndorsementDriverPage().validateErrorWhileAddingDriverWithNoVehicle();
    }

    //No Edit button in Err msg
    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testValidationWhenNoVehicleAssignedThenEdit(String browserName) {
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        EndorsementPage page = accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectDriver().
                selectAction("Add").
                fillFormData().
                submit();
        new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No vehicle assigned to Lee2 Carvallo2')]"))
        ).shouldBeTrue();
        EndorsementDriverPage driverPage = new EndorsementDriverPage();
        driverPage.selectAction("Edit").selectDriverByName("Lee2 Carvallo2"). assignVehicleByIndex(0).updateChange();
        new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No vehicle assigned to Lee2 Carvallo2')]"))
        ).shouldBeFalse();
        page.completeCoverage().complete().quote().buy().confirm();
        driverPage.doesDriverExistOnPolicyChangeFromBackend().shouldBeTrue();
    }

    //No Edit button in Err msg
    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testValidationWhenNoVehicleAssignedThenRemove(String browserName) {
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        EndorsementPage page = accountSummaryPage.
                changeMyPolicy().
                selectPolicy().
                selectEffectiveDate().
                selectOptions(false).
                selectOptions(false).
                selectDriver().
                selectAction("Add").
                addewDriverButton().
                fillFormData().
                submit();
        new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No vehicle assigned to Lee2 Carvallo2')]"))
        ).shouldBeTrue();
        EndorsementDriverPage driverPage = new EndorsementDriverPage();
        driverPage.clickRemoveDriverWarningButton().confirmRemoveDriver();
        new Validation(seleniumCommands.isElementPresent(
                By.xpath("//span[contains(text(),'No vehicle assigned to Lee2 Carvallo2')]"))
        ).shouldBeFalse();
    }
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"} , description = "TC3205 : Withdraw a draft PA endorsement")
    public void testWithdrawADraftPAEndorsement(String browserName) throws Exception {

        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put("GENDER", "Male");
        data.put("ACCIDENTS", "0");
        data.put("VIOLATIONS", "0");
        data.put("STATE", "California");
        data.put("LICENSE_STATE_VALUE", "CA");
        data.put("YEAR_LICENSED", "2014");
        data.put("LICENSE_NUMBER", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
        data.put("FIRST_NAME", "Lee");
        data.put("LAST_NAME", "Carvallo");
        data.put("DOB", "10/10/1987");
        data.put("DOB_TO_CHECK", "10/10/87");

        PolicyGenerator.createBasicBoundPAPolicy();

        new EndorsementWorkFlow().goToSelectChanges().addDriverDraftEndorsementStartingFromDateForm(true);
        new EndorsementEditToolBar().check();
        new PolicyChanges().withDrawEndorsement();
        PolicyDetailsPage detailsPage = new PolicyDetailsPage();

        detailsPage.isPolicyTransactionPresent();


    }


}

