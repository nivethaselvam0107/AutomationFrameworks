package com.guidewire.capabilities.endorsement.test.pa;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;

/**
 * Created by skushekbayev on 08/03/2016.
 */
public class EndorsementDatePicker {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testDateInPastIsUnavailable(String browserName) {
        EndorsementPage endorsementPage = pagefactory.getAccountSummaryPage()
                .changeMyPolicy()
                .selectFirstPolicy()
                .selectDatePicker();
        endorsementPage.verifyCorrectYearAndMonthDisplayed().shouldBeEqual("Wrong year and month displayed");
        endorsementPage.verifyCorrectDayHighlighted().shouldBeEqual("Wrong day highlighted");
        endorsementPage.clickOnPreviousDate();
        endorsementPage.verifyCorrectDayHighlighted().shouldBeEqual("Previous day highlighted");
    }

    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testDirectInputOfYesterdaysDateDisplaysErrorMessage(String browserName) {
        EndorsementPage endorsementPage = pagefactory.getAccountSummaryPage().changeMyPolicy();
        endorsementPage
                .selectFirstPolicy()
                .inputDate(endorsementPage.getYesterdaysDate())
                .verifyErrorMessageDisplayed().shouldBeTrue("Error message isn't displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testDateAfterPeriodEndNotPickable(String browserName) {
        EndorsementPage endorsementPage = pagefactory.getAccountSummaryPage().changeMyPolicy();
        endorsementPage
                .selectFirstPolicy()
                .inputDate(endorsementPage.getPeriodEndDate())
                .clickOnNextDate()
                .verifyPeriodEndHighlighted();
    }

    @Parameters("browserName")
    @Test(groups = {"Regression"}, enabled = false)
    public void testDirectInputOfDateAfterPeriodEnds(String browserName) {
        EndorsementPage endorsementPage = pagefactory.getAccountSummaryPage().changeMyPolicy();
        endorsementPage
                .selectFirstPolicy()
                .inputDate(endorsementPage.getMonthDayAndYearAfterPeriodEnds())
                .verifyErrorMessageDisplayed().shouldBeTrue("Error message isn't displayed");
    }
}
