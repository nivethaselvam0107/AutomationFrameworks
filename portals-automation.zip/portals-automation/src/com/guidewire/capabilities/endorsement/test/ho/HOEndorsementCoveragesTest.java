package com.guidewire.capabilities.endorsement.test.ho;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.model.page.common.PolicySelection;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.common.selenium.TestFrameworkException;

public class HOEndorsementCoveragesTest {
	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Withdraw draft policy transaction
	  
	             Step actions :- 
	             	1. Login to AMP as bfz user.
					2. Click on Change my policy.
					3.Verify Address for the Policy against PC
						  
	             Expected Results :- 
	            		1. AMP landing page loads.
					2. Policy Changes page opens.
					3. Displayed Address os the policy Address
					
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC3244 @ Verify that displayed Address is the policy Address")
	public void testHOPolicyAddress(String browserName) throws TestFrameworkException {
		PolicyGenerator.createBasicBoundHOPolicy();
		EndorsementWorkFlow workFlow = new EndorsementWorkFlow();
		workFlow.login();
		workFlow.clickChangePolicyLink();
		new PolicySelection().validateHOPolicyAddressMatching();
	}

	/**@formatter:off
	 * @param browserName
	 * 
	 * Test Description :- Change Coverage
	  
	             Step actions :- 
	             	1. Login to AMP as bfz user.
					2. Click on Change my policy.
					3. Select HO Policy
					4. Set Effective date as today. Select the arrow.
					5. Select Coverages. Select arrow icon
					6. Deselect Personal Injuries. Change All Other peril to 100 in Section 1 Deductibles. Change Limit - % of Dwelling Coverage to 55%. Select confirmation icon.
					7. Select quote tile
					8. Click on Buy
					9. Select Redestribute
					10. Provide the payment details - payment by credit card and click on Purchase.
					11. Login to PC and verify the policy details are updated correctly.
					
	  
	             Expected Results :- 
	            		1. AMP landing page loads.
					2. Policy Changes page opens.
					3. Effective date is exposed.
					4. Select changes options are exposed for Valuables, Mortgagee, Coverages.
					5. Coverages are displayed.
					6. All Coverages changes are populated in shopping cart. Policy Change is Saved in PC. Change Coverages are displayed. Quote tile is populated.
					7. Policy Change is updated to quoted in PC
					8. New premium details are displayed with purchase options.
					9. Payment details form is exposed.
					10. Policy is Bound pop up message appears.
					11. There should be a transaction present with all the details of your change.
	 */
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" } , description = "TC3232 @ Change Coverage")
	public void testCoverages(String browserName) throws Exception {
		new EndorsementWorkFlow().buyCoverageChageEndorsement();
		new HOEndorsementBackEndCheck().isCoverageChangesAvailableInPolicy().shouldBeTrue("Coverage details are updated for the policy");
	}
	
}
