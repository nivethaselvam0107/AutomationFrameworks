package com.guidewire.capabilities.endorsement.test.ho;

import com.guidewire.capabilities.common.model.generator.RenewalGenerator;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.endorsement.model.page.common.EndorsementWorkFlow;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

public class EndorsementValuablesTest {
    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3230 @ Add a Valuable")
    public void testAddValuable(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().buyAddValuableEndorsement();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Type")).shouldBeTrue("Valuables is not added to policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC6766 @ Edit a Valuable - Policy with exisiting Valuable")
    public void testEditValuable(String browserName) throws TestFrameworkException {
        if (DataFetch.getPolicyData("user", ThreadLocalObject.getData().get("POLICY_NUM")) == null) {
            RenewalGenerator.createRenewal("Bound");
        }
        new EndorsementWorkFlow().buyEditedValuableEndorsement();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Type")).shouldBeTrue("Valuables edit changes are not applied to policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3239 @ Withdraw draft policy transaction")
    public void testWithdrawDraftEndorsement(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().withDrawDraftValuableEndorsement().shouldBeFalse("Draft endorsement is not withdrawn");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3240 @ Cancel withdraw draft HO policy transaction")
    public void testCancelWithdrawDraftEndorsementAction(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().cancelWithDrawDraftValuableEndorsement().shouldBeTrue("Draft endorsement is not withdrawn");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "SMOKE"}, description = "TC3235 @ Delete a Valuable - Policy with exisiting Valuable")
    public void testRemoveValuable(String browserName) throws TestFrameworkException {
        if (DataFetch.getPolicyData("user", ThreadLocalObject.getData().get("POLICY_NUM")) == null) {
            RenewalGenerator.createRenewal("Bound");
        }
        DataFetch.cancelPolicyChange(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()));
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(new EndorsementWorkFlow().buyRemoveValuableEndorsement()).shouldBeFalse("Valuables is not deleted from policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3233 @ Policy Change with multiple changes for today")
    public void testAddMultipleChange(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().buyValuableAndMortgageeEndorsementTogather();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables is not added to policy");
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not added to policy");
    }


    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"}, description = "TC3234 @ Policy Change with multiple changes in the future")
    public void testAddMultipleChangeFutureDate(String browserName) throws TestFrameworkException {
        PolicyGenerator.createBasicBoundHOPolicy();
        new EndorsementWorkFlow().buyValuableAndMortgageeEndorsementTogatherForFutureDate();
        new HOEndorsementBackEndCheck().isValuablesAvailableInPolicy(ThreadLocalObject.getData().get("Valuable_Desc")).shouldBeTrue("Valuables is not added to policy");
        new HOEndorsementBackEndCheck().isMogtgageeAvailableInPolicy(ThreadLocalObject.getData().get("MortGagee_Name")).shouldBeTrue("MortGagee is not added to policy");
    }

}
