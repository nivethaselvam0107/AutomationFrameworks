package com.guidewire.capabilities.endorsement.validation.pa;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;

public class PAEndorsementHistoryCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	public Validation isDriverAddedToCart( String action, String... transactionStatus) throws Exception
	{
		JsonPath path = this.getPolicyChangeJsonData();
		int count = -1;
		try{
			count = path.getList("history").size();
		}
		catch(Exception e)
		{
			throw new Exception("No history data is present for endorsement"); 
		}
		if(transactionStatus.length>0) {
			new Validation(transactionStatus[0], DataFormatUtil.getNodeValue(path, "status")).shouldBeEqual("Transaction status is not correct");
		}
		String addedDriverFixId = getFixIdOfDriver(path);
		for(int i=0; i< count; i++)
		{
			String fixIDDriver = DataFormatUtil.getNodeValue(path,"history[" + i + "]", "fixedId");
			String actionBackEnd = DataFormatUtil.getNodeValue(path,"history[" + i + "]", "action");
			if(fixIDDriver.equalsIgnoreCase(addedDriverFixId) && actionBackEnd.equalsIgnoreCase(action))
				{
					return new Validation(true);
				}
		}
		return new Validation(false);
	}
	
	public Validation isVehicleAddedToCart(String action) throws Exception
	{
		JsonPath path = this.getPolicyChangeJsonData();
		int count = -1;
		try{
			count = path.getList("history").size();
		}
		catch(Exception e)
		{
			throw new Exception("No history data is present for endorsement"); 
		}
		String addedVehicleFixId = getFixIdOfVehicle(path);
		for(int i=0; i< count; i++)
		{
			String fixIDDriver = DataFormatUtil.getNodeValue(path,"history[" + i + "]", "fixedId");
			String actionBackEnd = DataFormatUtil.getNodeValue(path,"history[" + i + "]", "action");
			if(fixIDDriver.equalsIgnoreCase(addedVehicleFixId) && actionBackEnd.equalsIgnoreCase(action))
				{
					return new Validation(true);
				}
		}
		return new Validation(false);
	}
	
	public JsonPath getPolicyChangeJsonData()
	{
		return new JsonPath(DataFetch.getPolicyChangeData(data.get("POLICY_NUM"), data.get("USER")));
	}
	
	public String getFixIdOfDriver(JsonPath path) throws TestFrameworkException
	{
		String schProp = "lobData.personalAuto.coverables.drivers";
		int count = path.getList(schProp).size();
		logger.info("history count======>>" + count);
		for(int i=0; i< count; i++)
		{
			if(DataFormatUtil.getNodeValue(path,schProp+ "[" + i + "]", "licenseNumber").equals(data.get("LICENSE_NUMBER")))
			{
				return DataFormatUtil.getNodeValue(path, schProp+ "[" + i + "]", "fixedId");
			}
		}
		return null;
	}
	
	public String getFixIdOfVehicle(JsonPath path) throws TestFrameworkException
	{
		String schProp = "lobData.personalAuto.coverables.vehicles";
		int count = path.getList(schProp).size();
		logger.info("history count======>>" + count);
		for(int i=0; i< count; i++)
		{
			if(DataFormatUtil.getNodeValue(path,schProp+ "[" + i + "]", "vin").equals(data.get("VIN")))
			{
				String fixID =  DataFormatUtil.getNodeValue(path, schProp+ "[" + i + "]", "fixedId");
				logger.info("FixID found ======>>" + fixID);
				return fixID;
			}
		}
		return null;
	}
	
	public static void main(String[] args) throws Exception {
		new PAEndorsementHistoryCheck().isVehicleAddedToCart("added").shouldBeFalse();
	}

}
