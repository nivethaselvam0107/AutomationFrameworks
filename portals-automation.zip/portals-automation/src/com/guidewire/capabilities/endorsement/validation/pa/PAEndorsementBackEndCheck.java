package com.guidewire.capabilities.endorsement.validation.pa;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;

public class PAEndorsementBackEndCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	public Validation isDriverAvailableInPolicy(String licenseOrFixId) {
		logger.info("Backend check for Driver started");
		JsonPath path = getPolicyChangeJsonData();
		String schProp = "lobData.personalAuto.coverables.drivers";
		int count = path.getList(schProp).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String schPropType = schProp + "[" + i + "]";
			String schPropTypeName = schPropType +".person";
			if (DataFormatUtil.getNodeValue(path, schPropType, "licenseNumber").equals(licenseOrFixId) || DataFormatUtil.getNodeValue(path, schPropType, "fixedId").equals(licenseOrFixId)) {
				logger.info("Checking Driver data Driver with backend");
				new Validation(data.get("FIRST_NAME"), DataFormatUtil.getNodeValue(path, schPropTypeName, "firstName")).shouldBeEqual("First name is not matched");
				new Validation(data.get("LAST_NAME"), DataFormatUtil.getNodeValue(path, schPropTypeName, "lastName")).shouldBeEqual("Last name is not matched");
				new Validation(data.get("VIOLATIONS"), DataFormatUtil.getNodeValue(path, schPropType, "violations")).shouldBeEqual("Violation value is not matched");
				new Validation(data.get("ACCIDENTS"), DataFormatUtil.getNodeValue(path, schPropType, "accidents")).shouldBeEqual("Accidents value is not matched");
				new Validation(data.get("YEAR_LICENSED"), DataFormatUtil.getNodeValue(path, schPropType, "yearLicensed")).shouldBeEqual("License year is not matched");
				String dob = (Integer.parseInt(DataFormatUtil.getNodeValue(path, schPropType +".dateOfBirth", "month"))+1) + "/" + DataFormatUtil.getNodeValue(path, schPropType +".dateOfBirth", "day")
									+ "/" +DataFormatUtil.getNodeValue(path, schPropType +".dateOfBirth", "year");
				new Validation(data.get("DOB"), dob).shouldBeEqual();
				covFlag = true;
			}
		}
		return new Validation(covFlag);
	}
	
	public void validateMedicalLimitValue() {
		logger.info("Validating medical limit value.");
		JsonPath path = getPolicyChangeJsonData();
		String lineCoverage = "lobData.personalAuto.offerings[0].coverages.lineCoverages";
		int baseCovCount = path.getList(lineCoverage).size();
		boolean covfound = false;
		for (int i = 0; i < baseCovCount; i++) {
			String covItr = lineCoverage + "[" + i + "]";
			// Homeowners Personal Property
			if (DataFormatUtil.getNodeValue(path, covItr , "name").equals("Medical Payments")) {
				covfound= true;
				new Validation(data.get("COVERAGE_VALUE").replace(",",""), DataFormatUtil.getNodeValue(path, covItr + ".terms[0]", "chosenTermValue")).shouldBeEqual("Medical Limit was not updated");
			} 
		}
		new Validation(covfound).shouldBeTrue("Coverage was not found in the backend");
	}

	public Validation isVehicleAvailableInPolicy(String vinOrFixId) {
		logger.info("Backend check for Vehicle started");
		JsonPath path = getPolicyChangeJsonData();
		String schProp = "lobData.personalAuto.coverables.vehicles";
		int count = path.getList(schProp).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String schPropType = schProp + "[" + i + "]";
			if (DataFormatUtil.getNodeValue(path, schPropType, "vin").equals(vinOrFixId) || DataFormatUtil.getNodeValue(path, schPropType, "fixedId").equals(vinOrFixId)) {
				logger.info("Checking Vehicle data Driver with backend");
				new Validation(data.get("LicensePlate"), DataFormatUtil.getNodeValue(path, schPropType, "license")).shouldBeEqual("License no is not matched");
				new Validation(data.get("STATE_VALUE"), DataFormatUtil.getNodeValue(path, schPropType, "licenseState")).shouldBeEqual("State license value is not matched");
				new Validation(data.get("VehicleYear"), DataFormatUtil.getNodeValue(path, schPropType, "year")).shouldBeEqual("Vehicle year is not matched");
				new Validation(data.get("Model"), DataFormatUtil.getNodeValue(path, schPropType, "model")).shouldBeEqual("Vehicle model is not matched");
				new Validation(data.get("VIN"), DataFormatUtil.getNodeValue(path, schPropType, "vin")).shouldBeEqual("Vehicle vin is not matched");
				new Validation(data.get("Make"), DataFormatUtil.getNodeValue(path, schPropType, "make")).shouldBeEqual("Vehicle make is not matched");
				new Validation(new Double(data.get("VehicleCost")), new Double(DataFormatUtil.getNodeValue(path, schPropType + ".costNew", "amount"))).shouldBeEqual("Vehicle cost is not matched");
				covFlag = true;
			}
		}
		return new Validation(covFlag);
	}

	public void validateAddressChangedInPolicy() {
		logger.info("Backend check for policy City Address started");
		JsonPath path = getPolicyChangeJsonData();
		String schProp = "baseData.policyAddress";
		new Validation(data.get("NewCity"), DataFormatUtil.getNodeValue(path,schProp, "city")).shouldBeEqual("City value is not matched");
	}

	public JsonPath getPolicyChangeJsonData() {
		return new JsonPath(DataFetch.getPolicyChangeData(data.get("POLICY_NUM"), data.get("USER")));
	}

	public String replaceJsonPathWithCounter(String path, int counter) {
		return path.replace("COUNTER", counter + "");
	}

}
