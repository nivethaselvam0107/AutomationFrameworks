package com.guidewire.capabilities.endorsement.validation.ho;

import java.text.ParseException;
import java.util.HashMap;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;

import io.restassured.path.json.JsonPath;
import org.openqa.selenium.By;

public class HOEndorsementBackEndCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();

	public Validation isValuablesAvailableInPolicy(String itemName) {
		JsonPath path = getPolicyChangeJsonData();
		String schProp = "lobData.homeowners.offerings[0].coverages.schedules[0].scheduleItems";
		int count = path.getList(schProp).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String schPropType = schProp + "[" + i + "]";
			if (!(System.getProperty("platform").equalsIgnoreCase("Ferrite91") | System.getProperty("platform").equalsIgnoreCase("Granite"))) {
				if (DataFormatUtil.getNodeValue(path, schPropType + ".itemData.SchedItemDescriptionId", "stringValue").equals(itemName)) {
					new Validation(data.get("Valuable_Type"), DataFormatUtil.getNodeValue(path, schPropType + ".itemData.ArticleType", "typeCodeValue")).shouldBeEqual();
					new Validation(data.get("Valuable_Cost"), DataFormatUtil.getNodeValue(path, schPropType + ".itemData.SchedItemValueId", "integerValue")).shouldBeEqual();
					covFlag = true;
				}
			} else {
				new SeleniumCommands().click(By.cssSelector("button[gw-test-endorsement-change-bound-back-to-policy-button]"));
				if(DataFormatUtil.getNodeValue(path, schPropType + ".itemData.ArticleType", "typeCodeValue").equalsIgnoreCase(itemName)){
					new Validation(data.get("Valuable_Cost"), DataFormatUtil.getNodeValue(path, schPropType + ".itemData.ArticleLimit", "integerValue")).shouldBeEqual();
					if (DataFormatUtil.getNodeValue(path, schPropType + ".itemData.ArticleType", "typeCodeValue").equalsIgnoreCase(data.get("Valuable_Type"))) {
						return new Validation(true);
					}
				}
			}
		}
		return new Validation(covFlag);
	}

	public Validation isMogtgageeAvailableInPolicy(String itemName) {
		JsonPath path = getPolicyChangeJsonData();
		String mortProp = "lobData.homeowners.coverables.additionalInterests";
		int count = path.getList(mortProp).size();
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String mortPropType = mortProp + "[" + i + "].policyAdditionalInterest";
			if (DataFormatUtil.getNodeValue(path, mortPropType, "displayName").equals(itemName)) {
				String mortPropTypeAdd = mortPropType + ".primaryAddress";
				new Validation(data.get("MortGagee_City"), DataFormatUtil.getNodeValue(path, mortPropTypeAdd, "city")).shouldBeEqual();
				new Validation(data.get("MortGagee_Zip"), DataFormatUtil.getNodeValue(path, mortPropTypeAdd, "postalCode")).shouldBeEqual();
				new Validation(data.get("MortGagee_Street"), DataFormatUtil.getNodeValue(path, mortPropTypeAdd, "addressLine1")).shouldBeEqual();
				new Validation(data.get("MortGagee_State_Value"), DataFormatUtil.getNodeValue(path, mortPropTypeAdd, "state")).shouldBeEqual();
				covFlag = true;
			}
		}
		return new Validation(covFlag);
	}
	
	public static HashMap<String, String> getPolicyPremiumDataChanges() {
		JsonPath path = new HOEndorsementBackEndCheck().getPolicyChangeJsonData();
		HashMap<String, String> premiumData = new HashMap<>();
		premiumData.put("CURRENT_PREMIUM", DataFormatUtil.getNodeValue(path, "previousTotalCost", "amount"));
		premiumData.put("ADJUSTED_PREMIUM", DataFormatUtil.getNodeValue(path, "totalCost", "amount"));
		premiumData.put("PREMIUM_DIFF", DataFormatUtil.getNodeValue(path, "transactionCost", "amount"));
		return premiumData;
	}

	public Validation isCoverageChangesAvailableInPolicy() throws ParseException, Exception {
		MapCompare.compareMap(data, HOEndorsementBackEndCheck.getHOBaseCoverageDataFromBackEnd());
		return new Validation(true);
	}

	public static void main(String[] args) throws Exception {
		HOEndorsementBackEndCheck backEndCheck = new HOEndorsementBackEndCheck();
	}

	public static HashMap<String, String> getHOBaseCoverageDataFromBackEnd() throws Exception {
		JsonPath path = new HOEndorsementBackEndCheck().getPolicyChangeJsonData();
		HashMap<String, String> info = new HashMap<>();
		String baseCov = "lobData.homeowners.offerings[0].coverages.baseCoverages";
		String adddCov = "lobData.homeowners.offerings[0].coverages.additionalCoverages";
		int baseCovCount = path.getList(baseCov).size();
		int addCovCount = path.getList(adddCov).size();
		for (int i = 0; i < baseCovCount; i++) {

			String baseCovProp = baseCov + "[" + i + "]";
			String baseCovPropTerm_0 = baseCovProp + ".terms[0]";
			String baseCovPropTerm_1 = baseCovProp + ".terms[1]";
			String baseCovPropTerm_2 = baseCovProp + ".terms[2]";
			// Homeowners Personal Property
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Personal Property")) {
				info.put("HO_PER_PROP_VALUATION_METHOD", DataFormatUtil.getNodeValue(path,baseCovPropTerm_0, "chosenTermValue"));
				info.put("HO_PER_PROP_LIMIT%_DWEL_COVG", DataFormatUtil.getNodeValue(path, baseCovPropTerm_1, "chosenTermValue"));
			}

			// Section I Deductibles
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Section I Deductibles")) {
				info.put("ALL_OTHER_PERILS", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
				info.put("HURRICANE_PERCENTAGE", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
				info.put("WIND_HAIL_PERCENTAGE", DataFormatUtil.getNodeValue(path, baseCovPropTerm_2, "chosenTermValue"));
			}

			// Homeowners Personal Property
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Other Structures")) {
				info.put("HO_OTR_STR_LIMIT%_DWEL_COVG", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
			}

			// Homeowners Dwelling
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Dwelling")) {
				info.put("HO_DWEL_LIMIT", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
				info.put("HO_DWEL_DWEL_VALUATION_METHOD", DataFormatUtil.getNodeValue(path, baseCovPropTerm_1, "chosenTermValue"));
			}

			// Homeowners Loss Of Use
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Loss Of Use")) {
				info.put("HO_LOSS_OF_USE_LIMIT%_DWEL_LIMIT", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
			}

			// Homeowners Personal Liability
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Personal Liability")) {
				info.put("HO_PER_LIABILITY_LIMIT", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
			}

			// Homeowners Medical Payments
			if (DataFormatUtil.getNodeValue(path, baseCovProp, "name").equals("Homeowners Medical Payments")) {
				info.put("HO_MED_PAY_LIMIT", DataFormatUtil.getNodeValue(path, baseCovPropTerm_0, "chosenTermValue"));
			}
		}

		// Additional Coverage
		for (int i = 0; i < addCovCount; i++) {
			String addCovProp = adddCov + "[" + i + "]";
			String addCovPropTerm_0 = addCovProp+ ".terms[0]";
			String addCovPropTerm_1 = addCovProp+ ".terms[1]";
			// personal injury
			if (DataFormatUtil.getNodeValue(path, addCovProp, "name").equals("Personal Injury")) {
				info.put("PER_INJURY_LIMIT", DataFormatUtil.getNodeValue(path, addCovProp, "selected"));
			}

			// Limited Fungi, Wet or Dry Rot or Bacteria
			if (DataFormatUtil.getNodeValue(path, addCovProp, "name").equals("Limited Fungi, Wet or Dry Rot or Bacteria")) {
				info.put("FUNGI_SEC1_LIMIT", DataFormatUtil.getNodeValue(path, addCovPropTerm_0, "chosenTermValue"));
				info.put("FUNGI_SEC2_AGG_LIMIT", DataFormatUtil.getNodeValue(path, "coverageLobs.homeowners.additionalCoverages[" + i + "].terms[1]", "chosenTermValue"));
			}

			// Homeowners Ordinance Or Law
			if (DataFormatUtil.getNodeValue(path, addCovProp, "name").equals("Homeowners Ordinance Or Law")) {
				info.put("HO_ORD_LAW_VALUE", DataFormatUtil.getNodeValue(path, addCovProp+".amount", "amount"));
				info.put("HO_ORD_LAW_LIMIT", DataFormatUtil.getNodeValue(path, "coverageLobs.homeowners.additionalCoverages[" + i + "].terms[0]", "chosenTermValue"));
			}

		}
		return info;
	}

	public JsonPath getPolicyChangeJsonData() {
		return new JsonPath(DataFetch.getPolicyChangeData(ThreadLocalObject.getData().get("POLICY_NUM"), ThreadLocalObject.getData().get("USER")));
	}

	public static String replaceJsonPathWithCounter(String path, int counter) {
		return path.replace("COUNTER", counter + "");
	}

}
