package com.guidewire.capabilities.endorsement.validation.ho;

import java.util.HashMap;
import java.util.List;

import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;

import io.restassured.path.json.JsonPath;

public class HOEndorsementHistoryCheck {
	HashMap<String, String> data = ThreadLocalObject.getData();

	public Validation isValuablesAddedToCart(String itemName, String action) throws TestFrameworkException {
		JsonPath path = new HOEndorsementBackEndCheck().getPolicyChangeJsonData();
		int count = this.getHistoryCartSize(path);
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			String itemNameHistory = DataFormatUtil.getNodeValue(path, "history[" + i + "]", "itemName");
			if (itemNameHistory.equals(itemName)) {
				if(action.equalsIgnoreCase(DataFormatUtil.getNodeValue(path, "history[" + i + "]", "action")))
					if("scheduledProperty".equalsIgnoreCase(DataFormatUtil.getNodeValue(path, "history[" + i + "]", "entityType")))
						covFlag = true;
				if((i+1)==count && covFlag==false){
					new Validation(false).shouldBeTrue("Either action or entity type are not correct. Expected item name : " + itemName + ", but found : " + DataFormatUtil.getNodeValue(path, "history[" + i + "]", "itemName")
					+ ". Expected action : " + action + ", but found : " + DataFormatUtil.getNodeValue(path, "history[" + i + "]", "action")
					+ ". Expected entity type : scheduledProperty , but found : " + DataFormatUtil.getNodeValue(path, "history[" + i + "]", "entityType"));
				}
			}
		}
		return new Validation(covFlag);
	}

	public void isMogtgageeAddedToCart(String itemName, String action, Object... transactionStatus) throws TestFrameworkException {
		JsonPath path = new HOEndorsementBackEndCheck().getPolicyChangeJsonData();
		int count = this.getHistoryCartSize(path);

		if(transactionStatus.length>0) {
			new Validation(transactionStatus[0], DataFormatUtil.getNodeValue(path, "status")).shouldBeEqual("Transaction status is not correct");
		}

		for (int i = 0; i < count; i++) {
			if (DataFormatUtil.getNodeValue(path, "history[" + i + "]", "itemName").equals(itemName)) {
				new Validation(action, DataFormatUtil.getNodeValue(path, "history[" + i + "]", "action")).shouldBeEqual();
				new Validation("mortgagee", DataFormatUtil.getNodeValue(path, "history[" + i + "]", "entityType")).shouldBeEqual();
			}
		}
	}

	public boolean isCoverageAddedToCart(List<String> covList, String covChangeType) throws TestFrameworkException {
		JsonPath path = new HOEndorsementBackEndCheck().getPolicyChangeJsonData();
		int count = this.getHistoryCartSize(path);
		boolean covFlag = false;
		for (int i = 0; i < count; i++) {
			if (DataFormatUtil.getNodeValue(path, "history[" + i + "]", "entityType").equals("coverage") & DataFormatUtil.getNodeValue(path, "history[" + i + "]", "action").equals(covChangeType)) {
				String covName = DataFormatUtil.getNodeValue(path, "history[" + i + "]", "itemName");
				new Validation(covList.contains(covName)).shouldBeTrue(covName + "coverage is not listed");
				covFlag = true;
			}
		}
		return covFlag;

	}

	private int getHistoryCartSize(JsonPath path) throws TestFrameworkException {
		int count = -1;
		try {
			count = path.getList("history").size();
		} catch (NullPointerException e) {
			throw new TestFrameworkException("There is no history present for the policy");
		}
		return count;
	}

}
