package com.guidewire.capabilities.endorsement.fixtures.data;

import java.util.HashMap;

import org.apache.commons.lang3.RandomStringUtils;

public class RandomEndorsementData 
{
	public static HashMap<String, String> randomData()
	{
		//Your Info
		HashMap<String, String> policyData = new HashMap<>();
		policyData.put("LICENSE_NUMBER", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("MortGagee_Name", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("Make", RandomStringUtils.randomAlphanumeric(5).toUpperCase());
		policyData.put("Model", RandomStringUtils.randomAlphanumeric(5).toUpperCase());
		policyData.put("Valuable_Desc", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("VIN", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("AccountNum", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("ABANum", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("BankName", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("LicensePlate", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("FIRST_NAME", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("LAST_NAME", RandomStringUtils.randomAlphanumeric(8).toUpperCase());
		policyData.put("Valuable_Validation_method", "Actual cash value");
		policyData.put("Valuable_Deductible", "$500");
		return policyData;
	}
	
}
