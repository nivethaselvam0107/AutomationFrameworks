package com.guidewire.capabilities.endorsement.model.page.common.componant;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.form.CheckBox;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class EndorsementTypeBox {

	@FindBy(css = "[for='c_valuables']")
	WebElement VALUABLES_CSS;
	
	@FindBy(css = "[for='c_mortgagee']")
	WebElement MORTGAGEE_CSS;
	
	@FindBy(css = "[for='c_coverages']")
	WebElement COVERAGES_CSS;
	
	@FindBy(css = "[for='c_address']")
	WebElement ADDRESS_CSS;
	
	@FindBy(css = "[for='c_vehicles']")
	WebElement VEHICLES_CSS;
	
	@FindBy(css = "[for='c_drivers']")
	WebElement DRIVERS_CSS;
	
	@FindBy(css = "[ng-click='next()']")
	WebElement NEXT_NG_CLICK;

	@FindBy(css = "section[class='gw-endorsements-subsection']")
	WebElement ENDORSEMENT_TYPE_BOX;

	@FindBy(css = "[class*='gw-endorsement-icon-horizontal'], button[ng-click='next()']")
	WebElement NEXT_TILE;

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	Logger logger = Logger.getLogger(this.getClass().getName());

	public EndorsementTypeBox() {
		seleniumCommands.pageWebElementLoader(this);
	}
	
	public ViewModelForm getForm() {
		return new ViewModelForm(ENDORSEMENT_TYPE_BOX);
	}

	public EndorsementTypeBox selectCovareges() {
		logger.info("Selecting Coverage option");
		new CheckBox(COVERAGES_CSS).select();
		return this;
	}

	public EndorsementTypeBox selectMortgagee() {
		logger.info("Selecting Mortgagee option");
		new CheckBox(MORTGAGEE_CSS).select();
		return this;
	}

	public EndorsementTypeBox selectValuables() {
		logger.info("Selecting Valuables option");
		new CheckBox(VALUABLES_CSS).select();
		//this.getForm().getInputByModel("model.valuables").getElement().click();
		return this;
	}

	public EndorsementTypeBox selectDriver() {
		logger.info("Selecting Driver option");
		new CheckBox(DRIVERS_CSS).select();
		return this;
	}

	public EndorsementTypeBox selectVehicle() {
		logger.info("Selecting Vehicle option");
		new CheckBox(VEHICLES_CSS).select();
		return this;
	}

	public EndorsementTypeBox selectAddress() {
		logger.info("Selecting Address option");
		new CheckBox(ADDRESS_CSS).select();
		return this;
	}

	public void goNext() {
		logger.info("Go Next");
		seleniumCommands.pageWebElementLoader(this);
		new Button(NEXT_TILE).click();
	}

}
