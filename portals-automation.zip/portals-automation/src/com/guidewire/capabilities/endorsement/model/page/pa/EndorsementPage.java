package com.guidewire.capabilities.endorsement.model.page.pa;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;

import com.guidewire.widgetcomponents.Modal;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.endorsement.model.page.common.EndorsementPaymentPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;


public class EndorsementPage {

    private String yearMonthFormatString = "yyyy-MMM";
    private String dayFormatString = "d";
    private String dateInputFormat = "MM/dd/yyyy";
    private String specificDateXpath = "//td[contains(text(),'DATE')]";

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());
    String POLICY_XPATH = "//div[@data-gw-test-policy-no='POLICYNUM']";

    @FindBy(css = "[ng-click='onNext()']")
    WebElement EFFECTIVE_DATE_NEXT_CSS;
    
    @FindBy(css = "[ng-click='next()']")
    WebElement ENDORSEMENT_NEXT_CSS;

    @FindBy(id = "EffectiveDate")
    WebElement EFFECTIVE_DATE_INPUT;

    @FindBy(css = "[ng-click='!isActiveState() || select(true)']:not(.gw-read-only)")
    WebElement SELECT_CSS_YES;

    @FindBy(css = "[ng-click='!isActiveState() || select(false)']:not(.gw-read-only)")
    WebElement SELECT_CSS_NO;

    @FindBy(css = "[for='c_vehicles']")
    WebElement VEHICLE_BUTTON_CSS;

    @FindBy(css = "[for='c_drivers']")
    WebElement DRIVER_BUTTON_CSS;
    
    @FindBy(css = "[for='c_coverages']")
    WebElement COVERAGE_BUTTON_CSS;

    @FindBy(css = "[ng-click='quote()']")
    WebElement QUOTE_BUTTON;

    @FindBy(css = "div[msg='Saving policy change...']")
    WebElement SAVING_POLICY_CHANGE_MSG;

    @FindBy(css = "[ng-click='onNext()']")
    WebElement COMPLETE_BUTTON;

    @FindBy(linkText = "Buy")
    WebElement BUY_BUTTON;
    
    @FindBy(css = ".gw-policies")
    WebElement POLICIES_DIV;

    @FindBy(css = "button[ng-click='confirm()']")
    WebElement CONFIRM_BUTTON;
    
    @FindBy(css = "[class='gw-policy ng-scope']")
    List<WebElement> POLICY_DIV;

    @FindBy(css = "button[ng-click='$close()']")
    WebElement CONFIRM_MODAL_BUTTON;
    
    @FindBy(css = ".datetimepicker-icon")
    WebElement DATE_PICKER_ICON;

    @FindBy(css = "button[ng-click='gotBackToHomeState()']")
    WebElement GO_BACK_TO_HOME_BUTTON;
    
    @FindBy(css = "[class='day ng-binding ng-scope active']")
    WebElement HIGHLIGHTED_DATE_TD;

    @FindBy(css = "button[ng-click='showPaymentDetails()']")
    WebElement PAY_BUTTON;
    
    @FindBy(css = "[class='switch ng-binding']")
    WebElement YEAR_MONTH_TH;

    @FindBy(css = "table[class='gw-table gw-qnb-coverages ng-scope']")
    WebElement COVERAGES_LIST;
    
    @FindBy(id = "EffectiveDate")
    WebElement DATE_INPUT;

    @FindBy(css = "[class='gw-error-inline ng-binding']")
    WebElement ERROR_MSG;

    @FindBy(css = "[class='gw-policy-prop gw-policy-num ng-binding']")
    WebElement POLICY_NUM;

    @FindBy(css = "[on-click='cancel()']")
    WebElement CANCEL_BTN_CSS;

    @FindBy(css = "[on-click='withdraw()']")
    WebElement WITHDRAW_BTN_CSS;

    @FindBy(css = "[on-click='exitWizard()']")
    WebElement SAVE_N_EXIT_BTN_CSS;

  private static final String ENDORSEMENT_WIZARD_AUTO_TILE = ".gw-endorsement-common-selection";

    public EndorsementPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public EndorsementPage selectPolicy() {
    	seleniumCommands
        .waitForElementToBeVisible(By.cssSelector("div[class*='gw-endorsement-policy-list ng-scope']"));
            seleniumCommands
                    .waitForElementToBeVisible(By.xpath(POLICY_XPATH.replace("POLICYNUM", data.get("POLICY_NUM"))));
            seleniumCommands.clickbyJS(ThreadLocalObject.getDriver()
                    .findElement(By.xpath(POLICY_XPATH.replace("POLICYNUM", data.get("POLICY_NUM")))));
            seleniumCommands.waitForElementToExist(By.cssSelector("div[class='gw-endorsement-actions']"));
        return this;
    }

    public EndorsementPage selectFirstPolicy() {
     	seleniumCommands
        .waitForElementToBeVisible(By.cssSelector("div[class='gw-endorsement-policy-list ng-scope']"));
        seleniumCommands.clickbyJS(seleniumCommands.findElements(By.cssSelector("[ng-if='policies'] [ng-repeat]")).get(0));
        waitforModelPopUpToDisappear();
        return this;
    }

    public EndorsementPage selectEffectiveDate() {
        seleniumCommands.clickbyJS(EFFECTIVE_DATE_NEXT_CSS);
        return this;
    }

    public EndorsementPage selectEffectiveDate(int day) {
    	System.out.println(ThreadLocalObject.getDriver().findElement(By.cssSelector("[model='model.value'] div[class='gw-date-tile-day-of-month ng-binding'] i[ng-click='decreaseDay()']")).isEnabled());
        for (int i = 0; i < day; i++)
        {
        		seleniumCommands.clickbyJS(By.cssSelector("[model='model.value'] div[class='gw-date-tile-day-of-month ng-binding'] [ng-click='increaseDay()']"));
		}
        seleniumCommands.clickbyJS(EFFECTIVE_DATE_NEXT_CSS);
        return this;
    }

    public Validation isEffectiveDateEnabled(){
        return new Validation(ThreadLocalObject.getDriver().findElement(By.cssSelector("[model='model.value'] div[class='gw-date-tile-day-of-month ng-binding'] i[ng-click='decreaseDay()']")).isEnabled());
    }

    public EndorsementDriverPage selectDriver() {
        seleniumCommands.clickbyJS(DRIVER_BUTTON_CSS);
        seleniumCommands.clickbyJS(ENDORSEMENT_NEXT_CSS);
        return new EndorsementDriverPage();
    }

    public EndorsementVehiclePage selectVehicle() {
        seleniumCommands.clickbyJS(VEHICLE_BUTTON_CSS);
        seleniumCommands.clickbyJS(ENDORSEMENT_NEXT_CSS);
        return new EndorsementVehiclePage();
    }
    
    public EndorsementCoveragesPage selectCoverage() {
        seleniumCommands.clickbyJS(COVERAGE_BUTTON_CSS);
        seleniumCommands.clickbyJS(ENDORSEMENT_NEXT_CSS);
        return new EndorsementCoveragesPage();
    }

    public EndorsementPage selectOptions(boolean option) {
//        if (option == true) {
//            seleniumCommands.clickbyJS(SELECT_CSS_YES);
//        } else {
//            seleniumCommands.clickbyJS(SELECT_CSS_NO);
//        }
        return this;
    }

    public EndorsementPage selectDatePicker() {
        seleniumCommands.clickbyJS(DATE_PICKER_ICON);
        return this;
    }

    public EndorsementPage clickOnPreviousDate() {
        WebDriver driver = ThreadLocalObject.getDriver();
        seleniumCommands.clickbyJS(driver.findElement(By.xpath(specificDateXpath.replace("DATE", getYesterday()))));
        return this;
    }

    public EndorsementPage clickOnNextDate() {
        WebDriver driver = ThreadLocalObject.getDriver();
        seleniumCommands.clickbyJS(driver.findElement(By.xpath(specificDateXpath.replace("DATE", getDayAfterPeriodEnds()))));
        return this;
    }

    public EndorsementPage inputDate(String date) {
        if(date != null) {
            seleniumCommands.type(DATE_INPUT, date);
            return this;
        }
        logger.error("The date you are trying to input is null");
        return null;
    }

    public EndorsementPage quote(){
    		seleniumCommands.waitForElementToBeVisible(QUOTE_BUTTON);
        seleniumCommands.click(QUOTE_BUTTON);
        return this;
    }

    public EndorsementPage complete() {
        seleniumCommands.clickbyJS(COMPLETE_BUTTON);
        return this;
    }
    
    public EndorsementPage completeCoverage() {
        this.complete();
        seleniumCommands.waitForElementToBeVisible(COVERAGES_LIST);
        return this;
    }
    

    public EndorsementPage buy(){
        seleniumCommands.clickbyJS(BUY_BUTTON);
        return this;
    }

    public EndorsementPage confirm(){
        if (seleniumCommands.isElementPresent(CONFIRM_BUTTON)){
            seleniumCommands.clickbyJS(CONFIRM_BUTTON);
            closeModal();
        } else {
            seleniumCommands.clickbyJS(PAY_BUTTON);
            EndorsementPaymentPage paymentPage = new EndorsementPaymentPage();
            paymentPage.payWithBankDetails();
            closeModal();
        }
        return this;
    }

    public EndorsementPage closeModal(){
        seleniumCommands.clickbyJS(CONFIRM_MODAL_BUTTON);
        return this;
    }

    public EndorsementPage clickBackToHomeButton(){
        seleniumCommands.clickbyJS(GO_BACK_TO_HOME_BUTTON);
        return this;
    }


    public Validation hasHistoryItem(String item){
    		seleniumCommands.waitForElementToExist(By.xpath("//div[@ng-if='policyChange']//endorsement-change-box[@action]"));
    		seleniumCommands.waitForElementToBeVisible(By.xpath("//div[@ng-if='policyChange']//endorsement-change-box[contains(@title,'"+item+"')]"));
        return new Validation(seleniumCommands.isElementPresent(By.xpath("//endorsement-change-box[contains(@title,'"+item+"')]")));
    }

    public Validation hasHistoryAction(String item){
        switch(item){ 
            case "added":
                return new Validation(seleniumCommands.isElementPresent(By.cssSelector("i.fa.fa-plus")));
            case "removed":
                return new Validation(seleniumCommands.isElementPresent(By.cssSelector("i.fa.fa-minus")));
            case "changed":
                return new Validation(seleniumCommands.isElementPresent(By.cssSelector("i.fa.fa-pencil")));
            default:
                return new Validation(false);
        }
    }
    
    public Validation hasHistoryAction(String item, String action){
                return new Validation(seleniumCommands.findElement(By.xpath("//endorsement-change-box[contains(@title,'"+item+"')]")).getAttribute("action"), action);
    }

    public Validation verifyCorrectYearAndMonthDisplayed() { return getDateValidation(yearMonthFormatString, YEAR_MONTH_TH); }

    public Validation verifyCorrectDayHighlighted() { return getDateValidation(dayFormatString, HIGHLIGHTED_DATE_TD); }

    private Validation getDateValidation(String formatString, WebElement element) {
        LocalDate now = LocalDate.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern(formatString);
        String date = now.format(format);
        String comparedDate = seleniumCommands.getTextAtLocator(element);

        return new Validation(date, comparedDate);
    }

    public Validation verifyPeriodEndHighlighted() {
        String periodEndDay = getPeriodEndDay();
        String highlightedDay = seleniumCommands.getTextAtLocator(HIGHLIGHTED_DATE_TD);

        return new Validation(periodEndDay, highlightedDay);
    }

    public Validation verifyErrorMessageDisplayed() {
        seleniumCommands.focusOff();
        return new Validation(seleniumCommands.isElementPresent(ERROR_MSG));
    }

    public Validation isEndorsementWizardDisplayed(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementPresent(By.cssSelector(ENDORSEMENT_WIZARD_AUTO_TILE)));
    }
    private String getPeriodEnd() {
        seleniumCommands.waitForElementToBeVisible(POLICY_NUM);
        String policyNum = seleniumCommands.getTextAtLocator(POLICY_NUM);
        String periodEnd = ParseEndorsementData.getPeriodEndDate(DataFetch.getPolicyChangeData(policyNum, data.get("USER")));
        System.out.println(periodEnd);

        return periodEnd;
    }

    public String getMonthDayAndYearAfterPeriodEnds() {
        Instant instant = Instant.parse(getPeriodEnd());
        LocalDate dayAfterPeriodEnd = instant.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateInputFormat);

        return dayAfterPeriodEnd.format(format);
    }

    public String getDayAfterPeriodEnds() {
        Instant instant = Instant.parse(getPeriodEnd());
        LocalDate dayAfterPeriodEnd = instant.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dayFormatString);

        return dayAfterPeriodEnd.format(format);
    }

    public String getPeriodEndDate() {
        Instant instant = Instant.parse(getPeriodEnd());
        LocalDate dayAfterPeriodEnd = instant.atZone(ZoneId.systemDefault()).toLocalDate();
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateInputFormat);

        return dayAfterPeriodEnd.format(format);
    }

    public String getPeriodEndDay() {
        Instant instant = Instant.parse(getPeriodEnd());
        LocalDate dayAfterPeriodEnd = instant.atZone(ZoneId.systemDefault()).toLocalDate();
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dayFormatString);

        return dayAfterPeriodEnd.format(format);
    }

    public String getYesterdaysDate() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dateInputFormat);
        LocalDate date = LocalDate.now().minusDays(1);

        return date.format(format);
    }

    public String getYesterday() {
        DateTimeFormatter format = DateTimeFormatter.ofPattern(dayFormatString);
        LocalDate date = LocalDate.now().minusDays(1);

        return date.format(format);
    }
    
    private EndorsementPage waitforModelPopUpToDisappear()
    {
    	 	seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class='gw-modal-body ng-scope']"));
         seleniumCommands.waitForElementToDisappear(By.cssSelector("[class='gw-modal-body ng-scope']"));
         return this;
    }

    public EndorsementPage clickSaveAndExit(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(SAVE_N_EXIT_BTN_CSS);
        seleniumCommands.click(SAVE_N_EXIT_BTN_CSS);
        return this;
    }

    public EndorsementPage clickWithdraw(){
        seleniumCommands.waitForElementToBeVisible(WITHDRAW_BTN_CSS);
        seleniumCommands.click(WITHDRAW_BTN_CSS);
        new Modal().confirm();
        return this;
    }
}
