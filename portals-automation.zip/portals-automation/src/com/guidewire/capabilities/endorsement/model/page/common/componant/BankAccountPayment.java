package com.guidewire.capabilities.endorsement.model.page.common.componant;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.PaymentTypeEnum.BankType;
import com.guidewire.capabilities.endorsement.model.page.common.PaymentTypeEnum.PaymentMethodEnum;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.widgetcomponents.form.BinaryToggler;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class BankAccountPayment {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	String PAYMENT_METHOD_MODEL = "paymentDetails.paymentMethod";
	String ACCOUNT_TYPE_MODEL = "bankAccountDetails.bankaccountType";
	String ACCOUNT_NUM_MODEL = "bankAccountDetails.bankAccountNumber";
	String ABA_NUM_MODEL = "bankAccountDetails.bankABANumber";
	String BANK_NAME_MODEL = "bankAccountDetails.bankName";

	@FindBy(css = "ng-form[ng-show='paymentDetailsEnabled']")
	WebElement FORM;

	@FindBy(css = "[gw-pl-radios-binary]")
	WebElement TYPE_TOGGLER;
	
	@FindBy(css = "[ng-model='paymentDetails.paymentMethod']")
	WebElement PAYMENT_METHOD_CSS;

	public BankAccountPayment() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}

	public BinaryToggler getTypeToggler() {
		return new BinaryToggler(TYPE_TOGGLER);
	}

	public BankAccountPayment selectBankPaymentMethod() {
		logger.info("Selecting bank payment method");
		seleniumCommands.selectDropDownValueByText(PAYMENT_METHOD_CSS,PaymentMethodEnum.BANKACCOUNT.toString());
		return this;
	}

	public BankAccountPayment selectCheckingAccountType() {
		logger.info("Selecting checking bank ");
		this.getTypeToggler().toggleById(BankType.Checking.toString());
		return this;
	}

	public BankAccountPayment selectSavingAccountType() {
		logger.info("Selecting saving bank ");
		this.getTypeToggler().toggleById(BankType.Savings.toString());
		return this;
	}

	public BankAccountPayment withAccountNum() {
		logger.info("Filling account number ");
		this.getForm().getInputByModel(ACCOUNT_NUM_MODEL).setValue(data.get("AccountNum"));
		return this;
	}

	public BankAccountPayment withABANum() {
		logger.info("Filling ABA number ");
		this.getForm().getInputByModel(ABA_NUM_MODEL).setValue(data.get("ABANum"));
		return this;
}
	
	public BankAccountPayment withBankName() {
		logger.info("Filling bank name");
		this.getForm().getInputByModel(BANK_NAME_MODEL).setValue(data.get("BankName"));
		return this;
	}
	
	public BankAccountPayment payWithCheckingBankAccount() {
		logger.info("Paying with checking bank");
		this.selectBankPaymentMethod().setBankDetails().selectCheckingAccountType();
		return this;
	}
	
	public BankAccountPayment payWithSavingBankAccount() {
		logger.info("Paying with saving bank");
		this.selectSavingAccountType().selectBankPaymentMethod().setBankDetails();
		return this;
	}
	
	private BankAccountPayment setBankDetails() {
		logger.info("Setting bank details");
		this.selectBankPaymentMethod().withABANum().withAccountNum().withBankName();
		return this;
	}
	
}
