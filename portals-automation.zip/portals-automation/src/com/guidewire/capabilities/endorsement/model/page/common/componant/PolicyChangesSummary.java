package com.guidewire.capabilities.endorsement.model.page.common.componant;

import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.common.selenium.SeleniumCommands;
import org.openqa.selenium.By;

/**
 * Created by darya fedo
 */
public class PolicyChangesSummary {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public PolicySummary clickPolicyLink(String policyNumber) {
        seleniumCommands.logInfo("Clicking policy link");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.findElement(By.linkText(policyNumber)).click();
        return new PolicySummary();
    }
}
