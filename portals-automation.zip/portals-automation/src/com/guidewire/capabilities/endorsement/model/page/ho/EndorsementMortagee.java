package com.guidewire.capabilities.endorsement.model.page.ho;

import java.util.HashMap;
import java.util.List;

import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class EndorsementMortagee {
	
	Logger logger = Logger.getLogger(this.getClass().getName());
	
	String NAME_MODEL = "Mortgagee.policyAdditionalInterest.contactName";
	String STREET_MODEL = "Mortgagee.policyAdditionalInterest.primaryAddress.addressLine1";
	String CITY_MODEL = "Mortgagee.policyAdditionalInterest.primaryAddress.city";
	String STATE_MODEL = "Mortgagee.policyAdditionalInterest.primaryAddress.state";
	String ZIP_MODEL = "Mortgagee.policyAdditionalInterest.primaryAddress.postalCode";
	String EFF_DATE_MODEL = "Mortgagee.effectiveDate";

	@FindBy(css = "[name*='additional_interest_form']")
	WebElement FORM;
	
	@FindBy(css = "endorsement-change-box[ng-repeat*='in mortgageeChanges']")
	WebElement MORTGAGEE_DATA;

	By ADD_MORTGAGEE_BUTTON = By.cssSelector("[gw-test-endorsment-ho-additional-interests-edit-submit-new-mortgagee-button]");

	@FindBy(css = "button[ng-click='replaceEntry()'][aria-disabled='false']")
	WebElement REPLACE_CHANGE_BTN_CSS;

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();

	public EndorsementMortagee() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}

	public EndorsementMortagee setNameValue() {
		this.getForm().getInputByModel(NAME_MODEL).setValue(data.get("MortGagee_Name"));
		return this;
	}
	
	public EndorsementMortagee setNameValue(String name) {
		this.getForm().getInputByModel(NAME_MODEL).setValue(name);
		return this;
	}

	public String getNameValue() {
		return this.getForm().getInputByModel(NAME_MODEL).getValue();
	}

	public EndorsementMortagee setStreetValue() {
		this.getForm().getInputByModel(STREET_MODEL).setValue(data.get("MortGagee_Street"));
		return this;
	}

	public String getStreetValue() {
		return this.getForm().getInputByModel(STREET_MODEL).getValue();
	}

	public EndorsementMortagee setCityValue() {
		this.getForm().getInputByModel(CITY_MODEL).setValue(data.get("MortGagee_City"));
		return this;
	}

	public String getCityValue() {
		return this.getForm().getInputByModel(CITY_MODEL).getValue();
	}

	public EndorsementMortagee setStateValue() {
		this.getForm().getInputByModel(STATE_MODEL).setValue(data.get("MortGagee_State"));
		return this;
	}

	public String getStateValue() {
		return this.getForm().getInputByModel(STATE_MODEL).getValue();
	}

	public EndorsementMortagee setZipValue() {
		this.getForm().getInputByModel(ZIP_MODEL).setValue(data.get("MortGagee_Zip"));
		return this;
	}

	public String getZipValue() {
		return this.getForm().getInputByModel(ZIP_MODEL).getValue();
	}

	public EndorsementMortagee setEffDateValue() {
		this.getForm().getInputByModel(EFF_DATE_MODEL).setValue(data.get("MortGagee_Eff_date"));
		return this;
	}

	public String getEffDateValue() {
		return this.getForm().getInputByModel(EFF_DATE_MODEL).getValue();
	}
	
	public EndorsementMortagee fillMortageeFormData() {
		this.setNameValue().setStateValue().setStreetValue().setCityValue().setZipValue();
		return this;
	}

	// Validation
	public Validation isMortgageeTranscationPresentInCart()throws TestFrameworkException {
		logger.info("Checking if  endorsemnt present in cart");
		return new Validation(seleniumCommands.isElementPresent(By.cssSelector("endorsement-change-box:not([aria-hidden])")));
	}

	public void isMortgageeAddTranscationPresentInCart() throws TestFrameworkException {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEnorsementItemFromCart(data.get("MortGagee_Name")));
		String effDate = null;
		if(!data.get("MortGagee_Eff_date").equals(""))
		{
			effDate =  data.get("MortGagee_Eff_date");
		}
		else
		{
			effDate = DateUtil.getCurrentDate();
		}
		seleniumCommands.waitForLoaderToDisappearFromPage();
		section.isEndorsementPresentInCart("Mortgagee endorsement is not present in cart");
		section.isAdditionAction();
		new Validation(section.getEndorsementTitle(), data.get("MortGagee_Name"));
		new Validation(section.getEndorsementDetails().get(0), "Effective Date: " + effDate).shouldBeEqual("Mortgagee details are not correct");
		new HOEndorsementHistoryCheck().isMogtgageeAddedToCart(data.get("MortGagee_Name"), "added");
	}
	
	public void isMortgageeEditTranscationPresentInCart() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEnorsementItemFromCart(data.get("MortGagee_Name")));
		String effDate = "Effective Date: " + DateUtil.getCurrentDate();
		section.isEndorsementPresentInCart("Mortgagee endorsement is not present in cart");
		section.isEditAction();
		new Validation(section.getEndorsementTitle(), data.get("MortGagee_Name"));
		new Validation(section.getEndorsementDetails().get(0), effDate).shouldBeEqual("Mortgagee details are not correct");
	}

	public void isMortgageeDeleteTranscationPresentInCart(String item) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEnorsementItemFromCart(item));
		String effDate = "Effective Date: " + DateUtil.getCurrentDate();
		section.isEndorsementPresentInCart("Mortgagee endorsement is not present in cart");
		section.isRemoveAction();
		new Validation(section.getEndorsementTitle(), data.get("MortGagee_Name"));
	}

	public Validation isMortgageeRemovedFromList() {
		return null;
	}
	
	public void isMortgageeReplacedTranscationPresentInCart(Object... replacedMortagee) {

		List<WebElement> cartItem = seleniumCommands.findElements(By.cssSelector("endorsement-change-box[ng-repeat*='in mortgageeChanges']"));
		DraftEndorsementSection section  = new DraftEndorsementSection(cartItem.get(0));
		String effDate = "Effective Date: " + DateUtil.getCurrentDate();
		section.isEndorsementPresentInCart("Mortgagee endorsement is not present in cart");
		section.isAdditionAction();
		new Validation(section.getEndorsementTitle(), data.get("MortGagee_Name"));
		new Validation(section.getEndorsementDetails().get(0), effDate).shouldBeEqual("Mortgagee details are not correct");

		section  = new DraftEndorsementSection(cartItem.get(1));
		effDate = "Effective Date: " + DateUtil.getCurrentDate();
		section.isEndorsementPresentInCart("Mortgagee endorsement is not present in cart");
		section.isRemoveAction();
		new Validation(section.getEndorsementTitle(), replacedMortagee);
		new Validation(section.getEndorsementDetails().get(0), effDate).shouldBeEqual("Mortgagee details are not correct");
	}
	
	 private WebElement getEnorsementItemFromCart(String valuableTitle)
	 {
		 List<WebElement> cartItem = seleniumCommands.findElements(By.cssSelector("endorsement-change-box[ng-repeat='c in mortgageeChanges']"));
		 logger.info("Endorsement item available in no : " + cartItem.size());
		 for (WebElement e : cartItem) {
			if(seleniumCommands.getAttributeValueAtLocator(e, "title").contains(valuableTitle))
			{
				logger.info("Endorsement was found with title -===========> " + seleniumCommands.getAttributeValueAtLocator(e, "title"));
				return e;
			}
		}
		 return null;
	 }
	
	public void validateAddMortgageeButtonDisabled()throws TestFrameworkException {
		logger.info("Checking if Add mortgagee button enabled");
		new Validation(seleniumCommands.isElementClickable(ADD_MORTGAGEE_BUTTON)).shouldBeFalse("Add button is clickable while shouldn't");
	}

	public EndorsementPage replaceChange() {
		seleniumCommands.click(REPLACE_CHANGE_BTN_CSS);
		return new EndorsementPage();
	}
}
