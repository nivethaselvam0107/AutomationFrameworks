package com.guidewire.capabilities.endorsement.model.page.pa;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class EndorsementDriverPage {
	private static final String LICENSE_NUMBER = "driver.licenseNumber";
	private static final String LICENSE_STATE = "driver.licenseState";
	private static final String YEAR_LICENSED = "driver.yearLicensed";
	private static final String GENDER = "driver.gender";
	private static final String DOB = "driver.dateOfBirth";
	private static final String FIRST_NAME = "contact.firstName";
	private static final String LAST_NAME = "contact.lastName";
	private static final String ACTION_ADD_CSS = ".gw-icon-button-add";
	private static final String ACTION_REPLACE_CSS = ".gw-icon-button-replace";
	private static final String ACTION_EDIT_CSS = ".gw-icon-button-edit";
	private static final String ACTION_REMOVE_CSS = ".gw-icon-button-remove";
	private static final String ADD_DRIVER_ROW = "[ng-if='isChoosingExisting']";
	private static final String ERROR_MESSAGE_XPATH = "//*[contains(@class,'warning')]//div[contains(text(),'DRIVER')]";

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	//	@FindBy(css = "ng-form[name='driverForm']")
	@FindBy(css = "div[class= 'gw-driver-vehicle-form'],div[class= 'gw-endorsement-change-area'], div[class='gw-endorsement-control-group-section'], ng-form[name='driverForm'] ")
	WebElement FORM;

	@FindBy(css = "ng-form[name='driverForm']")
	WebElement FORM_FILL;

	// @FindBy(css = "div[model='contact.firstName'] div>input")
	// WebElement FIRST_NAME;
	//
	// @FindBy(css = "div[model='contact.lastName'] div>input")
	// WebElement LAST_NAME;

	@FindBy(id = "DateOfBirth")
	WebElement DOB_TXT_ID;

	@FindBy(css = "[model='driver.gender'] select")
	WebElement GENDER_DROP_CSS;

	@FindBy(css = "[model='driver.licenseNumber'] div>input")
	WebElement LICENSE_NO_TXT_CSS;

	@FindBy(css = "[model='driver.licenseState'] select")
	WebElement LICENSE_STATE_DROP_CSS;

	@FindBy(css = "[model='driver.yearLicensed'] select")
	WebElement LICENSE_YEAR_DROP_CSS;

	@FindBy(css = "button[ng-click='submitNewEntry()'][aria-disabled='false']")
	WebElement SUBMIT_BTN_CSS;

	@FindBy(css = "button[ng-click='updateEntry()'][aria-disabled='false']")
	WebElement UPDATE_CHANGE_BTN_CSS;

	@FindBy(css = "button[ng-click='updateEntry()']")
	WebElement EDIT_CHANGE_BTN_CSS;

	@FindBy(css = "button[ng-click='replaceEntry()']")
	WebElement REPLACE_CHANGE_BTN_CSS;

	@FindBy(css = "button[class='gw-btn gw-btn-primary gw-mb10 ng-binding']")
	WebElement NEW_DRIVER_BUTTON;

	@FindBy(css = "button[ng-click='onAddNew(-1)']")
	WebElement ADD_NEW_DRIVER_BTN_CSS;

	@FindBy(css = ".gw-endorsement-button-edit")
	WebElement EXISTING_DRIVER_BUTTON;

	@FindBy(css = "div[label='Accidents'] input")
	WebElement ACCIDENT_LBL_CSS;

	@FindBy(css = "[model='driver.violations'] div[ng-click='selectNextValue()']")
	WebElement ACCIDENT_INCREMENT_BTN_CSS;

	@FindBy(css = "div[label='Violations'] input")
	WebElement VIOLATION_LBL_CSS;

	@FindBy(css = "[model='driver.accidents'] div[ng-click='selectNextValue()']")
	WebElement VIOLATION_INCREMENT_BTN_CSS;

	@FindBy(css = "[ng-repeat='vehicle in policyChange.lobs.personalAuto.vehicles']")
	WebElement VEHICLE_ASSIGNMENT_FIELDS;

	@FindBy(css = "select[ng-model='selection.item']")
	WebElement DRIVER_SELECTION_INPUT;

	@FindBy(css = "button[ng-click='deleteEntry($index)']")
	WebElement CONFIRM_BUTTON;

	@FindBy(css = "a[ng-click='changeDriver(d)']")
	WebElement CHANGE_DRIVER_WARNING_BUTTON;

	@FindBy(css = "a[ng-click='removeDriver(d)']")
	WebElement REMOVE_DRIVER_WARNING_BUTTON;

	@FindBy(css = "[class='gw-endorsement-change-area']")
	WebElement DRIVER_ENRORSMENT_CHANGE_AREA;

	@FindBy(css = "endorsement-change-box[ng-repeat='c in driverChanges']")
	WebElement DRIVERS_DATA;

	@FindBy(css = "label[for='driver-vehicle-0']")
	WebElement VEHICLE_NAME;
	
	@FindBy(css = "endorsement-change-box[ng-repeat='change in driverChanges']")
	List<WebElement> DRIVER_CART_SECTION;

	By DRIVER_LICENSE_YEAR = By.cssSelector("[model='driver.yearLicensed'] span[ng-if='!yearLicensedEditable']");
	By DOB_DATAPICKER = By.cssSelector("div[class='gw-dropdown-toggle']");
	By LEFT_DP_ARROW = By.cssSelector("th[class='left']");
	By DBO_YEAR = By.cssSelector("span[class='year']");
	By DBO_MONTH = By.cssSelector("span[class='month']");
	By DBO_DAY = By.cssSelector("td[class='day ng-binding ng-scope']");


	private static final String ADD_DRIVER_AFTER_DETAILS_CSS = "[ng-click='submitNewEntry()']";

	public EndorsementDriverPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
		seleniumCommands.pageWebElementLoader(this);
	}

	public EndorsementDriverPage selectAction(String action) {
		seleniumCommands.waitForElementToBeVisible(DRIVER_ENRORSMENT_CHANGE_AREA);
		switch (action) {
			case "Add":
				seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_ADD_CSS))));
				seleniumCommands.waitForElementToBeVisible(By.cssSelector(ADD_DRIVER_ROW));
				seleniumCommands.clickbyJS(ADD_NEW_DRIVER_BTN_CSS);
				break;
			case "Edit":
				seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_EDIT_CSS))));
				break;
			case "Replace":
				seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_REPLACE_CSS))));
				break;
			case "Remove":
				seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_REMOVE_CSS))));
				break;
			default:
				break;
		}
		return this;
	}

	public Validation canPerformAction(String action) {
		seleniumCommands.waitForElementToBeVisible(DRIVER_ENRORSMENT_CHANGE_AREA);
		switch (action) {
			case "Add":
				return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_ADD_CSS)).getAttribute("aria-disabled")), false);
			case "Edit":
				return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_EDIT_CSS)).getAttribute("aria-disabled")), false);
			case "Replace":
				return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_REPLACE_CSS)).getAttribute("aria-disabled")), false);
			case "Remove":
				return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_REMOVE_CSS)).getAttribute("aria-disabled")), false);
			default:
				return new Validation(false);
		}
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM_FILL);
	}

	public ViewModelInput getInput(String input) {
		return this.getForm().getInputByModel(input);
	}

	public EndorsementDriverPage withFirstName() {
		this.getForm().getInputByModel(FIRST_NAME).setValue(data.get("FIRST_NAME"));
		return this;
	}

	public EndorsementDriverPage getFirstNameAndPutInTestData() {
		data.put("FIRST_NAME", this.getForm().getInputByModel(FIRST_NAME).getValue());
		return this;
	}

	public EndorsementDriverPage getLastNameAndPutInTestData() {
		data.put("LAST_NAME", this.getForm().getInputByModel(LAST_NAME).getValue());
		return this;
	}

	public EndorsementDriverPage withLastName() {
		this.getForm().getInputByModel(LAST_NAME).setValue(data.get("LAST_NAME"));
		return this;
	}

	public EndorsementDriverPage withLicenseNumber() {
		this.getForm().getInputByModel(LICENSE_NUMBER).setValue(data.get("LICENSE_NUMBER"));
		this.getForm().getInputByModel(LICENSE_STATE).getControl().getElement().click();
		return this;
	}

	public EndorsementDriverPage withLicenseNumber(String licenseNumber) {
		this.getForm().getInputByModel(LICENSE_NUMBER).setValue(licenseNumber);
		data.put("LICENSE_NUMBER", licenseNumber);
		return this;
	}

	public EndorsementDriverPage withLicenseState() {
		this.getForm().getInputByModel(LICENSE_STATE).setValue(data.get("STATE"));
		return this;
	}

	public EndorsementDriverPage withGender() {
		this.getForm().getInputByModel(GENDER).setValue(data.get("GENDER"));
		return this;
	}

	public EndorsementDriverPage withYearLicensed() {
		this.getForm().getInputByModel(YEAR_LICENSED).setValue(data.get("YEAR_LICENSED"));
		return this;
	}

	public EndorsementDriverPage withDOB() {
		if(ThreadLocalObject.getBrowserName().equals("internet explorer")){
		    seleniumCommands.findElement(DOB_DATAPICKER).click();
			seleniumCommands.findElement(LEFT_DP_ARROW).click();
			seleniumCommands.findElement(LEFT_DP_ARROW).click();
			seleniumCommands.getElements(DBO_YEAR).get(7).click();
			seleniumCommands.getElements(DBO_MONTH).get(9).click();
			seleniumCommands.getElements(DBO_DAY).get(9).click();
		}else
			this.getForm().getInputByModel(DOB).setValue(data.get("DOB"));
		return this;
	}

	public String getNoOfAccidents() {
		return seleniumCommands.getValueAttributeFromLocator(ACCIDENT_LBL_CSS);
	}

	private String getNoOfViolations() {
		return seleniumCommands.getValueAttributeFromLocator(VIOLATION_LBL_CSS);
	}

	public EndorsementDriverPage setNoOfAccidents() {
		int no = Integer.parseInt(data.get("ACCIDENTS"));
		Button btn = new Button(ACCIDENT_INCREMENT_BTN_CSS);
		while (no != 0) {
			btn.click();
			no--;
		}
		return this;
	}

	public EndorsementDriverPage setNoOfViolations() {
		int no = Integer.parseInt(data.get("VIOLATIONS"));
		while (no != 0) {
			VIOLATION_INCREMENT_BTN_CSS.click();
			no--;
		}
		return this;
	}

	public EndorsementDriverPage fillFormData() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this.withFirstName().withLastName().withGender().setNoOfViolations().setNoOfAccidents().withYearLicensed().editFormData();
	}

	public EndorsementDriverPage editFormData() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		String vehicleName = seleniumCommands.getTextAtLocator(VEHICLE_NAME);
		String[] vehicledata = vehicleName.split(" ");
		data.put("VEHICLE_TO_CHECK", vehicledata[0].trim() + " " + vehicledata[1].trim() + " " +vehicledata[2].trim());
		data.put("FIRST_NAME", this.getForm().getInputByModel(FIRST_NAME).getValue());
		data.put("LAST_NAME", this.getForm().getInputByModel(LAST_NAME).getValue());
		if(seleniumCommands.isElementPresent(DRIVER_LICENSE_YEAR)) {
			data.put("YEAR_LICENSED", seleniumCommands.getTextAtLocator(DRIVER_LICENSE_YEAR));
		} else {
			data.put("YEAR_LICENSED", seleniumCommands.getSelectedOptionFromDropDown(LICENSE_YEAR_DROP_CSS));
		}
		return withDOB().withLicenseNumber().withLicenseState();
	}

	public EndorsementPage submit() {
		// ViewModelForm form = this.getForm();
		seleniumCommands.clickbyJS(SUBMIT_BTN_CSS);
		// if (!form.isShowingAnyErrors()) {
		//waitforModelPopUpToDisappear();
		return new EndorsementPage();
		// }

		// return null;
	}

	private EndorsementDriverPage waitforModelPopUpToDisappear() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class='gw-modal-body ng-scope']"));
		seleniumCommands.waitForElementToDisappear(By.cssSelector("[class='gw-modal-body ng-scope']"));
		return this;
	}

	public EndorsementPage updateChange() {
		seleniumCommands.clickbyJS(UPDATE_CHANGE_BTN_CSS);
		waitforModelPopUpToDisappear();
		return new EndorsementPage();
	}

	public EndorsementPage replaceChange() {
		seleniumCommands.click(REPLACE_CHANGE_BTN_CSS);
		return new EndorsementPage();
	}

	public EndorsementPage submitEditChange() {
		seleniumCommands.clickbyJS(EDIT_CHANGE_BTN_CSS);
		return new EndorsementPage();
	}

	public EndorsementDriverPage clickExistingDriverButton() {
		seleniumCommands.clickbyJS(EXISTING_DRIVER_BUTTON);
		return this;
	}

	public String selectExistingDriverForEdition(String index) {
		String driver = "//table/tbody//tr[" + index + "]/td/input".replace("index", index);
		String driverName = seleniumCommands.getTextAtLocator(By.xpath(driver + "/../following-sibling::td"));
		seleniumCommands.waitForElementToBeVisible(By.xpath(driver));
		seleniumCommands.clickbyJS(By.xpath(driver));
		return driverName;
	}

	public EndorsementDriverPage addewDriverButton() {
		seleniumCommands.clickbyJS(NEW_DRIVER_BUTTON);
		return this;
	}

	public EndorsementDriverPage assignDriverByIndex(int index) {
		seleniumCommands.findElement(By.id("vehicle-driver-" + index)).click();
		return this;
	}

	public EndorsementDriverPage assignVehicleByIndex(int index) {
		seleniumCommands.findElement(By.id("driver-vehicle-" + index)).click();
		seleniumCommands.staticWait(3);
		return this;
	}

	public String selectDriverByIndex(int index) {
		return selectExistingDriverEdition(index + "");
	}


	public EndorsementPage confirmRemoveDriver() {
		seleniumCommands.waitForElementToBeVisible(CONFIRM_BUTTON);
		seleniumCommands.clickbyJS(CONFIRM_BUTTON);
		return new EndorsementPage();
	}

	;

	public EndorsementDriverPage clickChangeDriverWarningButton() {
		seleniumCommands.clickbyJS(CHANGE_DRIVER_WARNING_BUTTON);
		return this;
	}

	public EndorsementDriverPage selectDriverByName(String text) {
		seleniumCommands.waitForElementToBeVisible(By.xpath("//table"));
		seleniumCommands.clickbyJS(seleniumCommands.findElement(By.xpath("//td[contains(text(),'" + text + "')]/..//input")));
		return this;
	}

	public EndorsementDriverPage clickRemoveDriverWarningButton() {
		seleniumCommands.clickbyJS(REMOVE_DRIVER_WARNING_BUTTON);
		return this;
	}

	public Validation doesDriverExistOnPolicyChangeFromBackend() {
		List<HashMap<String, String>> drivers = ParseEndorsementData.getDrivers(fetchDataFromBackend(data.get("POLICY_NUM")));
		return new Validation(drivers.stream().filter(driver -> validateDataAgainstBackend(driver.get("firstName"), data.get("FIRST_NAME")) && validateDataAgainstBackend(driver.get("lastName"), data.get("LAST_NAME")) && validateDataAgainstBackend(DateUtil.FormatDateTo(driver.get("dateOfBirth")), data.get("DOB")) && validateDataAgainstBackend(driver.get("yearLicensed"), data.get("YEAR_LICENSED"))
				&& validateDataAgainstBackend(driver.get("licenseNumber"), data.get("LICENSE_NUMBER"))).findFirst().isPresent());
	}

	public Validation isDriverRemovedFromBackend() {
		return isDriverRemovedFromBackend(data.get("LICENSE_NUMBER"));
	}

	public Validation isDriverRemovedFromBackend(String licenseNumber) {
		List<HashMap<String, String>> drivers = ParseEndorsementData.getDrivers(fetchDataFromBackend(data.get("POLICY_NUM")));
		return new Validation(drivers.stream().filter(driver -> !driver.get("licenseNumber").equals(licenseNumber)).findFirst().isPresent());
	}

	public Validation isAddEnabledForNewDriver(){
		return new Validation(seleniumCommands.isElementClickable(By.cssSelector(ADD_DRIVER_AFTER_DETAILS_CSS)));
	}

	public String fetchDataFromBackend(String policyNumber) {
		return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
	}

	public boolean validateDataAgainstBackend(String backendData, String testData) {
		if (testData != null) {
			return testData.equals(backendData);
		}
		return true;
	}

	public void isDriverAddTranscationPresentInCart(String action) throws Exception {
		DraftEndorsementSection section = new DraftEndorsementSection(getDriverCartSection());
		String[] title = this.parsetitle(section.getEndorsementTitle());
		section.isEndorsementPresentInCart("Vehicle endorsement is not present in cart");
		if (action.equals("added")) {
			section.isAdditionAction();
		} else if(action.equals("edit")) {
			section.isEditAction();
		}
		//validating title data
		new Validation(title[0], data.get("FIRST_NAME")).shouldBeEqual("First name is not correct");
		new Validation(title[1], data.get("LAST_NAME")).shouldBeEqual("Last name is not correct");
		//validating details inside of the card
		String cardDetails = section.getEndorsementDriversDetails();
		logger.info("========CART DATA=========\n" + cardDetails);
		String vehicleAssigned = data.get("VEHICLE_TO_CHECK") + " " + data.get("Model") + " " + data.get("VehicleYear");
		new Validation(cardDetails.contains("Date of Birth: " + data.get("DOB_TO_CHECK"))).shouldBeTrue("DOB " +data.get("DOB_TO_CHECK")+ " is missing or incorrect inside "+ cardDetails);
		new Validation(cardDetails.contains("Drives:")).shouldBeTrue("Drives is missing or incorrect inside"+ cardDetails);
		new Validation(cardDetails.contains(data.get("VEHICLE_TO_CHECK"))).shouldBeTrue("Vehicle assigned ->" +data.get("VEHICLE_TO_CHECK") + " is missing or incorrect in-> "+ cardDetails);
		new Validation(cardDetails.contains("License: " + data.get("LICENSE_NUMBER"))).shouldBeTrue("License is missing or incorrect. Should be =" + data.get("LICENSE_NUMBER") + " inside " + cardDetails);
		//validating that data was added to Backend
		new PAEndorsementHistoryCheck().isDriverAddedToCart(action).shouldBeTrue("Driver is not " + action + " to history");
	}

	public void isDriverRemoveTranscationPresentInCart(String name) throws Exception {
		String[] nameArray = name.split(" ");
		data.put("FIRST_NAME", nameArray[0]);
		data.put("LAST_NAME", nameArray[1]);
		DraftEndorsementSection section = new DraftEndorsementSection(getDriverCartSection());
		String title = section.getEndorsementTitle();
		section.isEndorsementPresentInCart("Driver endorsement is not present in cart");
		section.isRemoveAction();
		//validating title data
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(title, name).shouldBeEqual("Name doesn't match the removed one. Existing =" + title + " . But removed one was =" + name);
		//validating that data was added to Backend
		new PAEndorsementHistoryCheck().isDriverAddedToCart("removed").shouldBeFalse("Driver is still in the policy");
	}

	public void validateErrorWhileAddingDriverWithNoVehicle() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		String msg = DataConstant.NO_VEHICLE_ASSIGNED_MSG + " "+ data.get("FIRST_NAME") + " " +data.get("LAST_NAME") + ".";
		new Validation(new SeleniumCommands().getTextAtLocator(By.xpath(ERROR_MESSAGE_XPATH.replace("DRIVER",  data.get("FIRST_NAME") + " " +data.get("LAST_NAME")))), msg).shouldBeEqual("Error message is not correct");
}

	public String selectExistingDriverEdition(String index) {
		String driver = "//table/tbody//tr["+ index +"]/td/input".replace("index", index);
		String driversName= "//table/tbody//tr["+ index +"]/td[2]".replace("index", index);
		String driversLicenseNumber= "//table/tbody//tr["+ index +"]/td[4]".replace("index", index);
		ThreadLocalObject.getData().put("LICENSE_NUMBER", seleniumCommands.getTextAtLocator(By.xpath(driversLicenseNumber)));
		String name = seleniumCommands.getTextAtLocator(By.xpath(driversName));
		seleniumCommands.waitForElementToBeVisible(By.xpath(driver));
		seleniumCommands.clickbyJS(By.xpath(driver));
		return name;
	}

	private String[] parsetitle(String title)
	{
		return title.replaceAll("[$,()]", "").split(" ");
	}
	
	private WebElement getDriverCartSection()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		logger.info("Driver available in Cart UI =========>> " + DRIVER_CART_SECTION.size());
		return DRIVER_CART_SECTION.stream().filter(element -> seleniumCommands.getAttributeValueAtLocator(element, "title").equalsIgnoreCase(data.get("FIRST_NAME") + " " + data.get("LAST_NAME"))).findFirst().get();
	}

}
