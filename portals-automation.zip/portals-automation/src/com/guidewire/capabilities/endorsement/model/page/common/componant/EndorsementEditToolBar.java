package com.guidewire.capabilities.endorsement.model.page.common.componant;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.tile.Tile;

public class EndorsementEditToolBar 
{

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	Logger logger = Logger.getLogger(this.getClass().getName());

    private static final String ACTION_ADD_CSS = ".gw-endorsement-button-add";
    private static final String ACTION_REPLACE_CSS = ".gw-endorsement-button-replace";
    private static final String ACTION_EDIT_CSS = ".gw-endorsement-button-edit";
    private static final String ACTION_REMOVE_CSS = ".gw-endorsement-button-remove";

	//Edit Toolbar buttons
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click*='onAddNew()'],[ng-click='onChooseExisting()'],[ng-if*= 'showOnState'] [ng-click='onAddNew()']")
  	WebElement ADD_BTN;
    
    @FindBy(css = "div[ng-repeat*='schedule in schedules']:nth-of-type(1) [on-click='createNew()']")
  	WebElement VAL_ADD_BTN;
    
    @FindBy(css = "td [ng-click*='onAddNew(-1)']")
  	WebElement ADD_NEW_DRIVER_BTN;
    
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='onRemove()'],[ng-if*= 'showOnState'] [ng-click='onRemove()'] ")
  	WebElement REMOVE_BTN;
    
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='onEdit()'], [ng-if*= 'showOnState'] [ng-click='onEdit()']")
  	WebElement EDIT_BTN;
    
    @FindBy(css = "table[class*='gw-schedule-table_actual'] tr[ng-repeat]")
  	List<WebElement> PROPERTY_ROW_CSS;
    
    @FindBy(css = "[ng-click='onReplace()']")
  	WebElement REPLACE_BTN;

    @FindBy(css = "[class='gw-endorsement-change-area']")
    WebElement DRIVER_ENRORSMENT_CHANGE_AREA;

    @FindBy(css = "[aria-hidden='false'] button[ng-click='onNext()']")
    WebElement PA_CHECK_BTN ;
    
    @FindBy(css = "div[class='gw-pull-right'] button")
    WebElement HO_CHECK_BTN ;
    
    String HO_SECTION =  "//gw-tiled-endorsement-ho-select-changes";
    
    By PA_SECTION =   By.cssSelector("div[gw-endorsement-pa-flow]");
    
    @FindBy(css = "[ng-show] div[aria-hidden='false'] [ng-click='onNext()'], [ng-if] div[aria-hidden='false'] [ng-click='onNext()'], button[ng-click='onNext()']")
    WebElement COV_CHECK_BTN_CLASS ;

    By COV_CHECK_BTN_CLASS_XPATH = By.xpath("//button[@ng-click = 'onNext(coverageForm)' and not(@aria-disabled = 'false')]");

    //Add Endorsement change
   @FindBy(css = "button[ng-click='submitNewEntry()']")
  	WebElement SUBMIT_ENDORSEMENT_BTN;
   
   @FindBy(css = "gw-endorsement-ho-additional-interests-edit [ng-click='submitNewEntry()'], [ng-if*= 'newItem'] [on-click='add()']")
 	WebElement HO_SUBMIT_ENDORSEMENT_BTN;
    
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='cancelNewEntry()']")
  	WebElement CANCEL_ENDORSEMENT_BTN;

    //Delete Endorsement
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='deleteEntry($index)'], [ng-if*= 'showOnState'] [ng-click='deleteEntry($index)'], table[class*='actual'] [on-click='remove(scheduledItem)']")
  	WebElement DELETE_ENDORSEMENT_BTN;
    
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='cancelRemove()']")
  	WebElement CANCEL_ENDORSEMENT_DELETE_BTN;

    //Edit endorsement 
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='updateEntry()'], table[class*='actual'] [on-click='doneEditing(scheduledItem)'], [ng-click='updateEntry()']")
  	WebElement UPDATE_ENDORSEMENT_BTN;

    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='cancelEdit()']")
  	WebElement CANCEL_ENDORSEMENT_UPDATE_BTN;

    //Replace endorsement 
    @FindBy(css = "[ng-click='replaceEntry()']")
  	WebElement REPLACE_ENDORSEMENT_BTN;

    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [ng-click='cancelReplace()']")
  	WebElement CANCEL_ENDORSEMENT_REPLACE_BTN;
    
    @FindBy(css = "[ng-show*= 'showOnState'][aria-hidden='false'] [class='gw-pull-left']")
	WebElement EDIT_TOOL_BAR;
    
    @FindBy(css = "[ng-click='quote()'], [ng-click='goNext()']")
	WebElement QUOTE_TILE;

    @FindBy(css = "[ng-click='onNext()']")
    WebElement CONTINUE_BTN;

    @FindBy(css = "[ng-click='submitNewEntry()']")
    WebElement ADD_NEW_ENTRY_BTN;

    @FindBy(css = "[gw-test-endorsement-endorsment-entry-save-and-exit-button]")
    WebElement SAVE_AND_EXIT_BTN;

    private static final String EDIT_RDBTN_XPATH = "(//*[contains(@ng-show, 'showOnState')][@aria-hidden='false'] | //*[contains(@ng-if, 'showOnState')])//table/tbody//tr[ROWINDEX]/td/input";
    
    private static final String EDIT_CELL_ITEM_XPATH = "(//*[contains(@ng-show, 'showOnState')][@aria-hidden='false'] | //*[contains(@ng-if, 'showOnState')])//table/tbody//tr[ROWINDEX]/td[ITEMINDEX]";
    
    private static final String VAL_EDIT_BTN= "[on-click='edit(scheduledItem)'] div";
    
    private static final String VAL_DEL_BTN= "[on-click='initRemove(scheduledItem)'] div";
    
    private static final String VAL_DESC_LABEL= "td:nth-of-type(2) div";
    
    public EndorsementEditToolBar(){
    		seleniumCommands.waitForLoaderToDisappearFromPage();
    		seleniumCommands.pageWebElementLoader(this);
    	}
    
    public EndorsementEditToolBar add()
    {
    		logger.info("Clicking on add toolbar button");
    		new Button(ADD_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar addValuable()
    {
    		logger.info("Clicking on add toolbar button");
    		new Button(VAL_ADD_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar addNewDriver()
    {
    		logger.info("Clicking on add toolbar button");
    		seleniumCommands.pageWebElementLoader(this);
    		new Button(ADD_NEW_DRIVER_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar remove()
    {
    		logger.info("Clicking on remove toolbar button");
    		new Button(REMOVE_BTN).click();
    		return this;
    }
    
    public String removeValuable()
    {
    		logger.info("Clicking on remove valuable button");
    		String val_Label = seleniumCommands.getTextAtLocator(PROPERTY_ROW_CSS.get(0).findElement(By.cssSelector(VAL_DESC_LABEL)));
    		ThreadLocalObject.getData().put("Valuable_Desc", val_Label);
    		logger.info("Fetching deletedValuable description ===========" + ThreadLocalObject.getData().get("Valuable_Desc"));
    		new Button(PROPERTY_ROW_CSS.get(0).findElement(By.cssSelector(VAL_DEL_BTN))).click();
    		return val_Label;
    }
    
    public EndorsementEditToolBar edit()
    {
		logger.info("Clicking on edit toolbar button");
    		new Button(EDIT_BTN).click();
    		return this;
    }

    public EndorsementEditToolBar clickSaveAndExitButton()
    {
        logger.info("Clicking Save and Exit button");
        new Button(SAVE_AND_EXIT_BTN).click();
        return this;
    }
    
    public EndorsementEditToolBar editValuable()
    {
		logger.info("Clicking on edit valuable button");
    		new Button(PROPERTY_ROW_CSS.get(0).findElement(By.cssSelector(VAL_EDIT_BTN))).click();
    		return this;
    }
    
    public EndorsementEditToolBar replace()
    {
		logger.info("Clicking on replace toolbar button");
    		new Button(REPLACE_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar check()
    {
        seleniumCommands.waitForLoaderToDisappearFromPage();
		logger.info("Clicking on check toolbar button");
		if(seleniumCommands.isElementPresent(PA_SECTION))
		{
			new Button(PA_CHECK_BTN).click();
		}
		else
		{
			new Button(HO_CHECK_BTN).click();
		}
    		seleniumCommands.waitForLoaderToDisappearFromPage();
    		return this;
    }

    //Add Endorsement
    public EndorsementEditToolBar saveEndorsement()
    {
		logger.info("Saving on endorsement data");
		if(seleniumCommands.isElementPresent(PA_SECTION))
		{
			new Button(ADD_NEW_ENTRY_BTN).click();
		}
		else
		{
			new Button(HO_SUBMIT_ENDORSEMENT_BTN).click();
		}
    		return this;
    }
    
    public EndorsementEditToolBar cancelEndorsementAddition()
    {
		logger.info("Cancelling endorsement data addition");
    		new Button(CANCEL_ENDORSEMENT_BTN).click();
    		return this;
    }
    
    //Delete Endorsement
    public EndorsementEditToolBar deleteEndorsement()
    {
		logger.info("Deleting on endorsement data from list");
    		new Button(DELETE_ENDORSEMENT_BTN).click();
           return this;
    }
    
    public EndorsementEditToolBar cancelEndorsementDeletion()
    {
		logger.info("Cancelling endorsement data deletion");
    		new Button(CANCEL_ENDORSEMENT_DELETE_BTN).click();
    		return this;
    }
    
    //Edit Endorsement
    public EndorsementEditToolBar updateEndorsement()
    {
    		logger.info("Update endorsement data ");
    		new Button(UPDATE_ENDORSEMENT_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar cancelEndorsementUpdation()
    {
    		logger.info("Cancelling endorsement data update");
    		new Button(CANCEL_ENDORSEMENT_UPDATE_BTN).click();
    		return this;
    }
    
  //Replace Endorsement
    public EndorsementEditToolBar replaceEndorsement()
    {
   		logger.info("Replaceing endorsement data ");
    		new Button(REPLACE_ENDORSEMENT_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar cancelEndorsementReplace()
    {
   		logger.info("Cancelling endorsement data replace");
    		new Button(CANCEL_ENDORSEMENT_REPLACE_BTN).click();
    		return this;
    }
    
    public EndorsementEditToolBar quoteEndorsement()
    {
   		logger.info("Click on quote button");
   		seleniumCommands.waitForElementToBeVisible(QUOTE_TILE);
    		new Tile(QUOTE_TILE).click();
    		return this;
    }
    
    public EndorsementEditToolBar checkCoverage()
    {
   		logger.info("Click on coverage check button");
        seleniumCommands.waitForElementToBeVisible(COV_CHECK_BTN_CLASS_XPATH);
        new Tile(seleniumCommands.findElement(COV_CHECK_BTN_CLASS_XPATH)).click();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }
    
    public String selectEndorsementandAndGetCellvalue(int index, int itemKeyValueIndex) {
    		logger.info("Selecting row at no" + index + "with item key value at index :" + itemKeyValueIndex);
    		String input = this.EDIT_RDBTN_XPATH.replace("ROWINDEX", index+"");
		String cellXpath = this.EDIT_CELL_ITEM_XPATH.replace("ITEMINDEX", itemKeyValueIndex+"").replace("ROWINDEX", index+"");
		String itemName = seleniumCommands.getTextAtLocator(By.xpath(cellXpath));
		seleniumCommands.clickbyJS(seleniumCommands.findElement(By.xpath(input)));
    return itemName;
    }

    public String getCellValue(int index, int itemKeyValueIndex) {
        logger.info("Getting value at row no" + index + "and column index :" + itemKeyValueIndex);
        String input = this.EDIT_RDBTN_XPATH.replace("ROWINDEX", index+"");
        String cellXpath = this.EDIT_CELL_ITEM_XPATH.replace("ITEMINDEX", itemKeyValueIndex+"").replace("ROWINDEX", index+"");
        String itemName = seleniumCommands.getTextAtLocator(By.xpath(cellXpath));
        return itemName;
    }

    //validation

    public void isEditButtonDisabled() {
       new Button(EDIT_BTN).isDisabled("Edit tool bar button is not disabled");
    }
    
    public void isAddButtonPresent() {
    	  new Validation(seleniumCommands.isElementPresent(ADD_BTN)).shouldBeTrue("Add button is not present");
     }
    
    public void isEditButtonPresent() {
        new Validation(seleniumCommands.isElementPresent(EDIT_BTN)).shouldBeTrue("Edit button is not present");
    }
    
    public void isAddValuableButtonPresent() {
        new Validation(seleniumCommands.isElementPresent(VAL_ADD_BTN)).shouldBeTrue("Add valuable button is not present");
    }

    public void isReplaceButtonDisabled() {
        new Button(REPLACE_BTN).isDisabled("Replace tool bar button is not disabled");
    }

    public void isRemoveButtonDisabled() {
        new Button(REMOVE_BTN).isDisabled("Remove tool bar button is not disabled");
    }

}


