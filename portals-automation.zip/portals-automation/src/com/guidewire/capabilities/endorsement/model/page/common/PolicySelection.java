package com.guidewire.capabilities.endorsement.model.page.common;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.widgetcomponents.tile.Tile;

public class PolicySelection {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());
	final String ENDORSEMENT_POLICY_TILE = "data-gw-test-policy-no";
	final String POLICY_SELECTION_PAGE = "gw-tiled-endorsement-policy-list";
	
	@FindBy(css = "[ng-repeat='policy in policies track by $index']")
	WebElement POLICY_SELECTION_LIST;
	
	public PolicySelection() {
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForElementToBeVisible(POLICY_SELECTION_LIST);
	}
	
	public WebElement getPolicyTile() {
		logger.info("Searching the policy tile for " + data.get("POLICY_NUM"));
		return new Tile().getTileByProperty(ENDORSEMENT_POLICY_TILE, data.get("POLICY_NUM"));
	}

	public PolicyChanges selectPolicy() throws TestFrameworkException {
		logger.info("Selecting the policy tile");
		try{
		seleniumCommands.clickbyJS(this.getPolicyTile());
		}
		catch(NullPointerException e)
		{
			throw new TestFrameworkException("Policy "+ data.get("POLICY_NUM")+ " was not found in the list");
		}
		return new PolicyChanges();
	}
	
	public void checkPolicyListing() {
		logger.info("Checking the policy listing");
		new Validation(this.getPolicyTile() != null)
				.shouldBeTrue("Policy is not listed for with number :" + data.get("POLICY_NUM"));
	}
	
	public void checkPolicyIsNotSelectable() {
		logger.info("Checking the policy can not be selected");
		new Validation(this.getPolicyTile().getAttribute("class").contains("_disabled"))
				.shouldBeTrue("Policy is not selectable for with number :" + data.get("POLICY_NUM"));
	}
	
	public void checkPolicyIsSelectable() {
		logger.info("Checking the policy can be selected");
		new Validation(this.getPolicyTile().getAttribute("class").contains("_disabled"))
				.shouldBeFalse("Policy is not selectable for with number :" + data.get("POLICY_NUM"));
	}
	
	public void isPolicySelectionPageIsDisplayed() {
		logger.info("Checking the policy selection page is displayed.");
		new Validation(POLICY_SELECTION_LIST.isDisplayed());
	}
	
	public void validateHOPolicyAddressMatching() {
		logger.info("Checking the policy selection page is displayed.");
		String addline1 =  ParsePolicyData.getInsuredAddressLine1(DataFetch.getAccountPolicyData(data.get("POLICY_NUM")));
		new Validation(getPolicyTile().getText(), addline1).shouldBeEqual("Policy address is not correct on the tile");
	}
}
