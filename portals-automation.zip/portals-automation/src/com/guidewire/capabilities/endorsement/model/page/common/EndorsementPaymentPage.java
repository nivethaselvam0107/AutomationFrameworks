package com.guidewire.capabilities.endorsement.model.page.common;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.endorsement.model.page.common.componant.BankAccountPayment;
import com.guidewire.capabilities.endorsement.model.page.common.componant.CreditCardPayment;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.PolicyDetailPage;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.Modal;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class EndorsementPaymentPage {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	private final String ACCOUNT_NUMBER = "bankAccountDetails.bankAccountNumber";
	private final String ROUTING_NUMBER = "bankAccountDetails.bankABANumber";
	private final String BANK_NAME = "bankAccountDetails.bankName";

	@FindBy(css = "ng-form")
	WebElement FORM;

	@FindBy(css = "button[ng-click='payInFull(form)']")
	WebElement PAYFULL_BUTTON;

	@FindBy(css = "button[ng-click='redistribute()")
	WebElement REDISTRIBUTE_BUTTON;

	@FindBy(xpath = "//p[contains(text(),'Change has been bound')]")
	WebElement CONFIRMATION_MODAL;

	@FindBy(css = "[class*='gw-policy-details']")
	WebElement POLICY_DETAILS_PAGE;

	@FindBy(css = "button[ng-click='cancelPaymentDetails()']")
	WebElement CANCEL_BUTTON;

	@FindBy(css = "button[ng-click='showPaymentDetails()']")
	WebElement PURCHASE_BUTTON;

	@FindBy(css = "[ng-click='confirm()']")
	WebElement CONFIRM_BUTTON;

	By BACK_TO_POLICY_BUTTON = By.cssSelector("[gw-test-endorsement-change-bound-back-to-policy-button],[gw-test-endorsement-common-views-contact-underwriter-back-to-policy-button], [ng-click='gotBackToHomeState()']");

	@FindBy(css = "button[ng-click='gotBackToHomeState()']")
	WebElement GO_HOME;

	@FindBy(css = "span[ng-show*='policyChange.transactionCost.amount'][aria-hidden='false']")
	WebElement PREMIUM_DIFF;

	@FindBy(css = "[gw-test-endorsement-common-views-contact-underwriter-header], h1[class='gw-page-title ng-binding']")
	WebElement UNDERWRITER_HEADER;

	@FindBy(css = "[gw-test-endorsement-common-views-contact-underwriter-line1]")
	WebElement UNDERWRITER_LINE1;

	@FindBy(css = "[gw-test-endorsement-common-views-contact-underwriter-line2]")
	WebElement UNDERWRITER_LINE2;

	String GO_HOME_CSS = "button[ng-click='gotBackToHomeState()']";

	public EndorsementPaymentPage() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(GO_HOME_CSS));
		seleniumCommands.pageWebElementLoader(this);
	}

	public EndorsementPaymentPage payWithBankDetails() {
		seleniumCommands.waitForElementToBeVisible(FORM);
		this.getFormInput(ACCOUNT_NUMBER).setValue("1");
		this.getFormInput(BANK_NAME).setValue("1");
		this.getFormInput(ROUTING_NUMBER).setValue("1");
		seleniumCommands.clickbyJS(PAYFULL_BUTTON);
		seleniumCommands.waitForElementToBeVisible(CONFIRMATION_MODAL);
		return this;
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}

	private ViewModelInput getFormInput(String input) {
		return this.getForm().getInputByModel(input);
	}

	public EndorsementPaymentPage purchase() {
		seleniumCommands.pageWebElementLoader(this);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Button(PAYFULL_BUTTON).click();
		return this;
	}

	public EndorsementPaymentPage payInFull() {
		seleniumCommands.pageWebElementLoader(this);
		new Button(PURCHASE_BUTTON).click();
		return this;
	}

	public EndorsementPaymentPage confirm() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Button(CONFIRM_BUTTON).click();
		return this;
	}

	public PolicyDetailPage clickBackToPolicy() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(BACK_TO_POLICY_BUTTON);
		return new PolicyDetailPage();
	}

	private boolean isNoPaymentDiff() {
		String diff = PREMIUM_DIFF.getText();
		return diff.contains("$0.00") || diff.contains("-$") ;
	}

	public EndorsementPaymentPage payWithSavingBankAccount() {
		BankAccountPayment accountPayment = new BankAccountPayment();
		accountPayment.payWithSavingBankAccount();
		return this;
	}

	public EndorsementPaymentPage purchaseWithCheckingBankAccount() {
		this.payInFull();
		BankAccountPayment accountPayment = new BankAccountPayment();
		accountPayment.payWithCheckingBankAccount();
		this.purchase();
		return this;
	}
	
	public EndorsementPaymentPage purchaseWithSavingBankAccount() {
		this.payInFull();
		BankAccountPayment accountPayment = new BankAccountPayment();
		accountPayment.payWithSavingBankAccount();
		this.purchase();
		return this;
	}
	
	public AccountSummaryPage goToHomePage() {
		new Button(GO_HOME).click();
		return new AccountSummaryPage();
	}

	public EndorsementPaymentPage purchaseWithCreditCard() {
		logger.info("Purchase with credit card Driver");
		this.payInFull();
		new CreditCardPayment().payWithCreditCard();
		this.purchase();
		return this;
	}

	public EndorsementPaymentPage isChangedBound() {
		Modal model  = new Modal();
		model.validateModelMessage(DataConstant.CHANGE_BOUND_MSG);
		new AlertHandler().closeAlert();
		return this;
	}

	public EndorsementPaymentPage confirmOrPayInFullWithCheckingBank() {
		if(isNoPaymentDiff()) {
			this.confirm().isChangedBound();
		}
		else {
			this.purchaseWithCheckingBankAccount().isChangedBound();
		}
		return this;
	}

	public EndorsementPaymentPage redistributeCoverageChanges() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Button(REDISTRIBUTE_BUTTON).click();
		try {
			new AlertHandler().closeAlert();
		}
		catch(Exception e){}
		return this;
	}

	public EndorsementPaymentPage confirmOrPayInFullWithSavingBank() {
		if(isNoPaymentDiff()) {
			this.confirm().isChangedBound();			
		}
		else {
			this.purchaseWithSavingBankAccount().isChangedBound();
		}
		return this;
	}

	public EndorsementPaymentPage confirmOrPayInFullWithCreditCard() {
		if(isNoPaymentDiff()) {
			this.confirm().isChangedBound();
		}
		else	{
			this.purchaseWithCreditCard().isChangedBound();
		}
		return this;
	}
	public void validateUnderwriterIssueMessage() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(UNDERWRITER_HEADER.getText(), DataConstant.UNDERWRITING_MESSAGE_HEADER_ENDORSMENT_PAYMENT_PAGE).shouldBeEqual("Underwriter header is incorrect or missing");
		new Validation(UNDERWRITER_LINE1.getText(), DataConstant.UNDERWRITING_MESSAGE_LINE1_ENDORSMENT_PAYMENT_PAGE).shouldBeEqual("Underwriter message line 1 is incorrect or missing");
		new Validation(UNDERWRITER_LINE2.getText(), DataConstant.UNDERWRITING_MESSAGE_LINE2_ENDORSMENT_PAYMENT_PAGE).shouldBeEqual("Underwriter message line 2 is incorrect or missing");
	}


}
