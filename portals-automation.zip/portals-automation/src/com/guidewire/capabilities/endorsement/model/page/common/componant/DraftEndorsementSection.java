package com.guidewire.capabilities.endorsement.model.page.common.componant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class DraftEndorsementSection {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());
	private String TITLE = "title";
	private String ACTION = "action";
	private String ENDORSEMENT_DETAILS_CSS = ".gw-panel-collapse ng-transclude";
	private String ENDORSEMENT_VEHICLE_DETAILS = "//endorsement-change-box[@ng-repeat='c in vehicleChanges']//*[contains(@class,'gw-panel-collapse')]//div[@class='gw-details ng-scope']";

	private String ENDORSEMENT_COV_DETAILS_CSS = ".gw-panel-collapse ng-transclude div[ng-if]";

	private By ENDORSEMENT_CART_SECTION = By.cssSelector("endorsement-change-box:not([aria-hidden])");

	@FindBy(css = "endorsement-change-box:not([aria-hidden])")
	WebElement ENDORSEMENT_CART_ITEM;

	@FindBy(css = "endorsement-change-box[ng-repeat='c in mortgageeChanges']")
	WebElement MORTGAGEE_DATA;

	@FindBy(css = "endorsement-change-box[ng-repeat='c in scheduledPropertyChanges']")
	WebElement VALUABLES_DATA;

	@FindBy(css = ".gw-panel-collapse ng-transclude span")
	List<WebElement> CART_ITEMS;

	@FindBy(css = "div[class='gw-box-header ng-scope']")
	WebElement COVERAGE_IN_CART;

	public DraftEndorsementSection(WebElement element) {
		seleniumCommands.pageWebElementLoader(this);
		this.ENDORSEMENT_CART_ITEM = element;
	}
	
	public DraftEndorsementSection() {
	}

	public void isEndorsementPresentInCart(String message) {
		logger.info("Checking if  endorsemnt present in cart");
		new Validation(seleniumCommands.isElementPresent(ENDORSEMENT_CART_SECTION)).shouldBeTrue(message);
	}
	
	public void isEndorsementNotPresentInCart(String message) {
		logger.info("Checking if  endorsemnt present in cart");
		new Validation(seleniumCommands.isElementPresent(ENDORSEMENT_CART_SECTION)).shouldBeFalse(message);
	}

	public void isCoveragePresentInCart(String message) {
		logger.info("Checking if  endorsemnt present in cart");
		new Validation(seleniumCommands.isElementPresent(COVERAGE_IN_CART)).shouldBeTrue(message);
	}

	public String getEndorsementTitle() {
		logger.info("Getting endorsemnt title attribute");
		if (ENDORSEMENT_CART_ITEM == null)
		{
			ENDORSEMENT_CART_ITEM = seleniumCommands.findElement(By.cssSelector("endorsement-change-box:not([aria-hidden])"));
		}
		return seleniumCommands.getAttributeValueAtLocator(ENDORSEMENT_CART_ITEM, this.TITLE);
	}

	public void isAdditionAction() {
		logger.info("Checking endorsemnt action attribute");
		new Validation(this.getEndorsementAction(), DataConstant.ADD_ACTION).shouldBeEqual("Endorsement action is not Addition");
	}

	public void isRemoveAction() {
		logger.info("Checking endorsemnt action attribute");
		new Validation(this.getEndorsementAction(), DataConstant.EDIT_ACTION).shouldBeEqual("Endorsement action is not Remove");
	}

	public void isEditAction() {
		logger.info("Checking endorsemnt action attribute");
		new Validation(this.getEndorsementAction().contains(DataConstant.EDIT_ACTION)).shouldBeTrue("Endorsement action is not Edit");
	}

	public void isReplaceAction() {
		logger.info("Checking endorsemnt action attribute");
		new Validation(this.getEndorsementAction(), DataConstant.REPLACE_ACTION).shouldBeEqual("Endorsement action is not Replace");
	}

	private String getEndorsementAction() {
		logger.info("Getting endorsemnt action value");
		if (ENDORSEMENT_CART_ITEM == null)
		{
			ENDORSEMENT_CART_ITEM = seleniumCommands.findElement(By.cssSelector("endorsement-change-box:not([aria-hidden])"));
		}
		return seleniumCommands.getAttributeValueAtLocator(ENDORSEMENT_CART_ITEM, this.ACTION);
	}

	public List<String> getEndorsementDetails() {
		List<String> endorsementData = new ArrayList<>();
		List<WebElement> element = ENDORSEMENT_CART_ITEM.findElements(By.cssSelector(ENDORSEMENT_DETAILS_CSS));
		this.expandCartSection();
		if (element.size() == 1) {
			endorsementData.add(seleniumCommands.getTextAtLocator(element.get(0).findElement(By.xpath("./../.."))));
		} else {
			if (element.get(0).getAttribute("ng-if").contains("coverage")) {
				for (WebElement e : element) {
					endorsementData.add(e.findElement(By.xpath("./..")).getText());
				}
			}

		}
		return endorsementData;
	}
	public String getEndorsementDriversDetails() {
		WebElement element  = ENDORSEMENT_CART_ITEM.findElement(By.cssSelector(ENDORSEMENT_DETAILS_CSS));
		this.expandCartSection();
		String endorsementData = seleniumCommands.getTextAtLocator(element);
		return endorsementData;
	}

	public String getEndorsementVehiclesDetails() {
		this.expandCartSection();
		WebElement element = ENDORSEMENT_CART_ITEM.findElement(By.cssSelector(ENDORSEMENT_DETAILS_CSS));
		String endorsementData = seleniumCommands.getTextAtLocator(element);
		return endorsementData;
	}

	public List<String> getEndorsementCoverageDetails(String covChangeType) {
		List<String> endorsementCoverageData = new ArrayList<>();
		List<WebElement> covType = ENDORSEMENT_CART_ITEM.findElements(By.cssSelector(ENDORSEMENT_COV_DETAILS_CSS));
		this.expandCartSection();
		for (WebElement element : covType){
			if (element.findElement(By.xpath("./div")).getText().contains(covChangeType)) {
				int covCount = element.findElements(By.xpath(".//span")).size();
				List<WebElement> covTitle =  element.findElements(By.xpath(".//span"));
				for (WebElement title : covTitle) {
					endorsementCoverageData.add(title.getText());
				}
			}
		}
		return endorsementCoverageData;
	}

	private DraftEndorsementSection expandCartSection() {
		WebElement expandButton = ENDORSEMENT_CART_ITEM.findElement(By.xpath(".//*[contains(@class, 'gw-chevron')]"));
		if(expandButton.getAttribute("class").contains("-is-closed"))
		{
			seleniumCommands.clickbyJS(expandButton.findElement(By.cssSelector("[class='fa fa-caret-down gw-chevron-icon']")));
			seleniumCommands.waitForElementToHaveClass(ENDORSEMENT_CART_ITEM.findElement(By.xpath(".//div[@gw-pl-collapse]")), "gw-panel-collapse gw-collapse gw-in");
		}
		return this;
	}

}
