package com.guidewire.capabilities.endorsement.model.page.common;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.endorsement.model.page.common.componant.PolicyChangesSummary;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.Modal;
import com.guidewire.widgetcomponents.tile.DateTimeTile;

public class PolicyChanges {
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	String ENDORSEMENT_POLICY_TILE = "data-gw-test-policy-no";

	@FindBy(css = "[gw-test-endorsement-endorsement-entry-withdraw-button], [ng-click='reset()']")
	WebElement WITHDRAW_ENRORSEMENT;
	
	@FindBy(css = "div[ng-click='onNext()'] [class='fa fa-caret-right'], button[ng-click='onNext()']")
	WebElement GO_NEXT_TILE;

	@FindBy(css = "button[on-click='goToNext()'][disabled='disabled']")
	WebElement NEXT_BUTTON_DISABLED;

	@FindBy(css = "[ng-click='next()']")
	WebElement NEXT_TO_CHANGES_FORM;
	
	@FindBy(css = "input[ng-model='model.address']")
	WebElement ADDRESS_CHANGES_CHECKBOX;

	@FindBy(css = "input[ng-model='model.vehicles']")
	WebElement VEHICLES_CHANGES_CHECKBOX;

	@FindBy(css = "input[ng-model='model.drivers']")
	WebElement DRIVERS_CHANGES_CHECKBOX;

	@FindBy(css = "input[ng-model='model.coverages']")
	WebElement COVERAGES_CHANGES_CHECKBOX;

	@FindBy(css = "gw-date-tile[max-date]")
	WebElement DATETIME_TILE;

	@FindBy(css = "[model='address.addressLine2'] input")
	WebElement ADDRESS_LINE2;

	@FindBy(css = "[class='gw-endorsement-save-and-exit'] button")
	WebElement SAVE_AND_EXIT_BTN;

	@FindBy(css = "[gw-test-endorsement-endorsement-entry-wizard-model]")
	WebElement ENDORSMENT_WIZARD;

	@FindBy(css = "[gw-test-endorsement-endorsement-entry-page-title]")
	WebElement ENDORSMENT_WIZARD_PAGE_TITLE;

	@FindBy(css = "[model='policyChange.description'] input")
	WebElement BO_CHANGE_POLICY__DESC_TXT_CSS;
	
	@FindBy(css = "[gw-test-platform-widgets-datetimepicker-date-dropdown-picker]")
	WebElement DATE_FIELD_BO_CHANGE_POLICY_PAGE;

	@FindBy(css = "[on-click='goToNext()']")
	WebElement 	SUBMIT_BUTTON_BO_CHANGE_POLICY_PAGE;

	@FindBy(css = "[gw-test-platform-widgets-basicinputs-ctrl-group-error-message]")
	WebElement MANDATORY_FIELDS_ERROR_BO_CHANGE_POLICY_PAGE;

	public PolicyChanges(){
		seleniumCommands.pageWebElementLoader(this);
	}

	public AccountSummaryPage withDrawEndorsement() {
		logger.info("Withdrawing the policy endorsement");
		new Button(WITHDRAW_ENRORSEMENT).click();
		new AlertHandler().closeAlert();
		return new AccountSummaryPage();
	}
	
	public PolicyChanges cancelWithDrawEndorsement() {
		logger.info("Withdrawing the policy endorsement");
		new Button(WITHDRAW_ENRORSEMENT).click();
		new AlertHandler().closeAlert();
		return this;
	}
	
	public PolicyChanges dismissWithDrawEndorsement() {
		logger.info("Withdrawing the policy endorsement");
		new Button(WITHDRAW_ENRORSEMENT).click();
		new Modal().dismiss();
		return this;
	}
	

	public void checkPolicyListing() {
		logger.info("Checking the policy listing");
//		new Validation(new Tile().getAttribute(ENDORSEMENT_POLICY_TILE), data.get("POLICY_NUMBER"))
//				.shouldBeTrue("Policy is not listed for with number :" + data.get("POLICY_NUMBER"));
	}

	public PolicyChanges checkAddressChanges() {
		logger.info("Checking address checkbox.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(ADDRESS_CHANGES_CHECKBOX);
		return this;
	}

	public PolicyChanges checkVehiclesChanges() {
		logger.info("Checking vehicles checkbox.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(VEHICLES_CHANGES_CHECKBOX);
		return this;
	}
	public PolicyChanges checkDriversChanges() {
		logger.info("Checking drivers checkbox.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(DRIVERS_CHANGES_CHECKBOX);
		return this;
	}
	public PolicyChanges checkCoveragesChanges() {
		logger.info("Checking coverages checkbox.");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(COVERAGES_CHANGES_CHECKBOX);
		return this;
	}
	public PolicyChanges goNext() {
		logger.info("Clicking next");
		seleniumCommands.clickbyJS(GO_NEXT_TILE);
		return this;
	}

	public PolicyChanges goNextToChangePolicyForm() {
		logger.info("Clicking next to change policy form");
		seleniumCommands.clickbyJS(NEXT_TO_CHANGES_FORM);
		return this;
	}

	public PolicyChanges setAddressLine2(){
		logger.info("Setting address to field Address Line 2.");
		ADDRESS_LINE2.sendKeys("Some Address");
		return this;
	}

	public PolicyChangesSummary clickSaveAndExitBtn(){
		logger.info("Clicking Save and Exit button.");
		SAVE_AND_EXIT_BTN.click();
		return new PolicyChangesSummary();
	}


	public String setFuture() {
		logger.info("Setting future date next");
		return new DateTimeTile().setFutureDate();
	}

	public String setPast() {
		logger.info("Setting past date next");
		return new DateTimeTile().setPastDate();
	}
	
	public String getDate() {
		logger.info("Getting selected endorsement date ");
		return new DateTimeTile().getSelectedDate();
	}

	public void verifyEndorsmentWizardPageLoaded() {
		logger.info("Verifying Policy Change wizard page emelents.");
		new Validation(seleniumCommands.isElementPresent(ENDORSMENT_WIZARD)).shouldBeTrue("Endorsment wizard was not loaded on the page.");
		new Validation(ENDORSMENT_WIZARD_PAGE_TITLE.getText(), DataConstant.POLICY_CHANGE_PAGE_TITLE).shouldBeEqual("Policy Changes page title is incorrect or not presented.");
	}

	public PolicyChanges setBODate(String date) {
		logger.info("Setting date for BO change policy page");
		seleniumCommands.type(DATE_FIELD_BO_CHANGE_POLICY_PAGE, date);
		seleniumCommands.focusOff();
		seleniumCommands.click(BO_CHANGE_POLICY__DESC_TXT_CSS);
		return this;
	}

	public PolicyChanges submitBOPolicyChanges() {
		logger.info("Submitting BO change policy page");
		SUBMIT_BUTTON_BO_CHANGE_POLICY_PAGE.click();
		return this;
	}

	public void validateBOPolicyChangesMandatoryFieldsError() {
		logger.info("Validating error messages of BO change policy page mandatory fields");
		new Validation(MANDATORY_FIELDS_ERROR_BO_CHANGE_POLICY_PAGE.getText(), DataConstant.MANDATORY_ERROR_MSG).shouldBeEqual("Error message of missing mandatory field is incorrect or missing");
	}

	public void validateBOPolicyChangesIsNextButtonDisabled() {
		logger.info("Validating Next Button disabled if BO policy page mandatory fields left empty.");
		new Validation(seleniumCommands.isElementPresent(NEXT_BUTTON_DISABLED)).shouldBeTrue("Next Button is not disabled.");
	}
}
