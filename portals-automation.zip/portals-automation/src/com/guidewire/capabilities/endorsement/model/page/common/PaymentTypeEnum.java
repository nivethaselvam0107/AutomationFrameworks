package com.guidewire.capabilities.endorsement.model.page.common;

public class PaymentTypeEnum {

	public enum PaymentMethodEnum {
	    BANKACCOUNT("Bank Account"), CreditCard("Credit Card");

		   private final String type;
		   
		   private PaymentMethodEnum(final String type)
		   {
		      this.type = type;
		   }

		   @Override
		   public String toString()
		   {
		      return this.type.toString();
		   }
	}
	
	public enum BankType {
	    Checking("Left"), Savings("Right");
		
		private final String type;
		   
		   private BankType(final String type)
		   {
		      this.type = type;
		   }

		   @Override
		   public String toString()
		   {
		      return this.type.toString();
		   }

	}
}
