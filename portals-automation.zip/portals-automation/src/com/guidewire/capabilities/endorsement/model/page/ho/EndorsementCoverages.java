package com.guidewire.capabilities.endorsement.model.page.ho;

import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.form.CheckBox;
import com.guidewire.widgetcomponents.table.Table;

public class EndorsementCoverages {

	String PERIL_TITLE = "All Other Perils";
	String HO_OTH_LIMIT_DWEL_TITLE = "Limit - % of Dwelling Coverage";
	String TABLE_BODY = "coverage in model track by coverage.publicID";

	@FindBy(css = "div[gw-amp-editable-coverages*='base'] table")
	WebElement BASECOV_TABLE;

	@FindBy(css = "input[id*='coverage_0']")
	WebElement PERSONAL_INJURY;

	@FindBy(css = "endorsement-change-box[ng-show='hasCoverageChanges()']")
	WebElement COVERAGE_DATA;
	
	@FindBy(xpath = "(//div[contains(@ng-repeat,'coverage')])[1]//gw-pl-ctrl-group[1]//select")
	WebElement HO_OTH_LIMIT_DWEL_DROP_XPATH;
	
	@FindBy(xpath = "(//div[contains(@ng-repeat,'coverage')])[2]//gw-pl-ctrl-group[1]//select")
	WebElement ALL_OTH_PERIL_DROP_XPATH;

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();

	public EndorsementCoverages() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public Table getTable() {
		return new Table(BASECOV_TABLE);
	}

	public EndorsementCoverages setAllOtherPeril() {
		String covValue = seleniumCommands.getSelectedOptionFromDropDown(ALL_OTH_PERIL_DROP_XPATH);
		if(covValue.equals(data.get("ALL_OTHER_PERILS"))) {
			ThreadLocalObject.getData().put("ALL_OTHER_PERILS", "$500");
			seleniumCommands.selectDropDownValueByText(ALL_OTH_PERIL_DROP_XPATH, data.get("ALL_OTHER_PERILS"));
		} else {
			seleniumCommands.selectDropDownValueByText(ALL_OTH_PERIL_DROP_XPATH, data.get("ALL_OTHER_PERILS"));
		}
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public EndorsementCoverages setPersonalInjury() {
		CheckBox ckbox = new CheckBox(PERSONAL_INJURY);
		boolean value = !Boolean.parseBoolean(ckbox.getValue());
		ckbox.setValue(value+"");
		data.put("PER_INJURY_LIMIT", !value+"");
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public EndorsementCoverages setLimitPercentOfDwel() {
		String covValue = seleniumCommands.getSelectedOptionFromDropDown(HO_OTH_LIMIT_DWEL_DROP_XPATH);
		if(covValue.equals(data.get("HO_PER_PROP_VALUATION_METHOD"))) {
			ThreadLocalObject.getData().put("HO_PER_PROP_VALUATION_METHOD", "65%");
			seleniumCommands.selectDropDownValueByText(HO_OTH_LIMIT_DWEL_DROP_XPATH, data.get("HO_PER_PROP_VALUATION_METHOD"));
		}else {
			ThreadLocalObject.getData().put("HO_PER_PROP_VALUATION_METHOD", "50%");
			seleniumCommands.selectDropDownValueByText(HO_OTH_LIMIT_DWEL_DROP_XPATH, data.get("HO_PER_PROP_VALUATION_METHOD"));
		}
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	// Validation
	public void isCoverageTransationPresentInCart() throws TestFrameworkException {
		DraftEndorsementSection section = new DraftEndorsementSection(COVERAGE_DATA);
		section.isCoveragePresentInCart("Coverages endorsement is not present in cart");
	}

	public void isCoverageAddTranscationPresentInCart() throws TestFrameworkException {
		DraftEndorsementSection section  = new DraftEndorsementSection(COVERAGE_DATA);
		section.isCoveragePresentInCart("Coverages endorsement is not present in cart");
		section.isEditAction();
		List<String> covTypeChanged = section.getEndorsementCoverageDetails("Changed");
		if(covTypeChanged.size() != 0)
			{
				for(String cov : section.getEndorsementCoverageDetails("Changed"))
				{
					new Validation(covTypeChanged.contains(cov)).shouldBeTrue(cov + "Coverage is not present in the cart");
				}
			}
		
		List<String> covTypeRemoved = section.getEndorsementCoverageDetails("Removed");
		if(covTypeRemoved.size() != 0)
			{
				for(String cov : section.getEndorsementCoverageDetails("Removed"))
				{
					new Validation(covTypeRemoved.contains(cov)).shouldBeTrue(cov + "Coverage is not present in the cart");
				}
			}
		
		HOEndorsementHistoryCheck check = new HOEndorsementHistoryCheck();
		new Validation(check.isCoverageAddedToCart(covTypeChanged, "changed")).shouldBeTrue("Coverage type changed were not matched");
		new Validation(check.isCoverageAddedToCart(covTypeRemoved, "removed")).shouldBeTrue("Coverage type removed were not matched");
	}

}
