package com.guidewire.capabilities.endorsement.model.page.common.componant;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.EndorsementPaymentPage;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementBackEndCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.Button;
import com.guidewire.widgetcomponents.Div;

public class PremiumSection 
{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	Logger logger = Logger.getLogger(this.getClass().getName());
	private WebElement PREMIUM_SECTION;

    @FindBy(css = ".gw-endorsement-box li div:nth-of-type(2)")
  	WebElement CURRENT_PREMIUM;
    
    @FindBy(css = ".gw-endorsement-box li div[class='gw-detail-value gw-quoted']")
  	WebElement ADJUSTED_PREMIUM;
    
    @FindBy(css = ".gw-summary-value span")
  	WebElement PREMIUM_DIFF;
    
    @FindBy(css = "[ng-click='bind()']")
  	WebElement BUY_BTN;
    


    public PremiumSection(){
    		seleniumCommands.pageWebElementLoader(this);
    }
    
    public EndorsementPaymentPage buyQuote()
    {
    		logger.info("Buying the quote");
    		seleniumCommands.waitForElementToBeVisible(BUY_BTN);
    		arePremiumDetailsCorrect();
    		new Button(BUY_BTN).click();
    		return new EndorsementPaymentPage();
    }
    
    public String getCurrentPremium()
    {
    		logger.info("Getting the current premium value");
    		return new Div(CURRENT_PREMIUM).getText().replaceAll("[$,]", "");
    }
    
    public String getAdjustedPremium()
    {
    		logger.info("Getting the adjusted premium value");
    		return new Div(ADJUSTED_PREMIUM).getText().replaceAll("[$,]", "");
    }
    
    public String getPremiumDifference()
    {
    		logger.info("Getting the premium diff value");
    		return new Div(PREMIUM_DIFF).getText().replaceAll("[$,]", "");
    }
    
    public void arePremiumDetailsCorrect()
    {
    		logger.info("Validating premium details");
    		HashMap<String, String> premiumData = HOEndorsementBackEndCheck.getPolicyPremiumDataChanges();
    		logger.info("Premium data from BackEnd :" + premiumData.toString());
    		new Validation(new Double(this.getCurrentPremium()) , new Double(premiumData.get("CURRENT_PREMIUM"))).shouldBeEqual("Current premium value is not matched");
    		new Validation(new Double(this.getAdjustedPremium()) , new Double(premiumData.get("ADJUSTED_PREMIUM"))).shouldBeEqual("Adjusted premium value is not matched");
    		new Validation(new Double(this.getPremiumDifference()) , new Double(premiumData.get("PREMIUM_DIFF"))).shouldBeEqual("Premium diff value is not matched");
    }

}
