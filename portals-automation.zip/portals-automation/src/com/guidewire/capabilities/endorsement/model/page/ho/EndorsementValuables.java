package com.guidewire.capabilities.endorsement.model.page.ho;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.validation.ho.HOEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.table.Table;

public class EndorsementValuables {

	Logger logger = Logger.getLogger(this.getClass().getName());
	
	By TYPE = 	By.cssSelector("tr[ng-if='newItem'] select, table[class*='actual'] [item='dataItem'] select");
	By VALUE = 	By.cssSelector("tr[ng-if='newItem'] input[class*='currency'], table[class*='actual'] [item='dataItem'] input[class*='currency']");
	By DESC =	    By.cssSelector("tr[ng-if='newItem'] input[ng-blur='applyNewValue()'], table[class*='actual'] [item='dataItem'] input[ng-blur='applyNewValue()'], table[class*='actual'] [item='dataItem'] input[ng-blur]");
	By NEW_VALUABLE_ADD_BUTTON = By.cssSelector("[gw-test-policycommon-common-table-submit-new-valuable-button]");


	String VALUABLE_ROW = "scheduledProperty in model.value.scheduledProperties | filter: notPendingEntries track by $index";

	@FindBy(css = "[name='new_scheduled_property_form'], [name='edit_scheduled_property_form']")
	WebElement FORM;

	@FindBy(css = "[model='wizard.viewModel.lobs.homeOwners'] table")
	WebElement ENDORSMENT_TABLE;

	@FindBy(css = "endorsement-change-box[ng-repeat='c in scheduledPropertyChanges']")
	WebElement VALUABLES_DATA;

	HashMap<String, String> data = ThreadLocalObject.getData();

	SeleniumCommands seleniumCommands = new SeleniumCommands();

	public EndorsementValuables() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}

	public Table getEndorsementList() {
		return new Table(ENDORSMENT_TABLE);
	}

	public EndorsementValuables setValuableValue() {
		seleniumCommands.type(VALUE, data.get("Valuable_Cost"));
		return this;
	}

	public String getValuablesValue() {
		return seleniumCommands.getTextAtLocator(VALUE);
	}

	public EndorsementValuables setValuableDesc() {
		seleniumCommands.type(DESC, data.get("Valuable_Desc"));
		seleniumCommands.click(TYPE);
		seleniumCommands.click(TYPE);
		return this;
	}

	public String getValuableDesc() {
		return seleniumCommands.getTextAtLocator(DESC);
	}

	public EndorsementValuables selectValuableType() {
		seleniumCommands.selectDropDownValueByText(TYPE, data.get("Valuable_Type"));
		return this;
	}

	public String getValuableType() {
		return seleniumCommands.getSelectedOptionFromDropDown(TYPE);
	}
	
	public EndorsementValuables fillValuableFormData() {
		this.setValuableValue();
		String platform = System.getProperty("platform");
		if (platform.equalsIgnoreCase("Ferrite91") | platform.equalsIgnoreCase("Granite")){
			data.put("Valuable_Deductible","$1,000");
			data.put("Valuable_Validation_method","Replacement cost");
			seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(TYPE).get(0), data.get("Valuable_Type"));
			seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(TYPE).get(1), data.get("Valuable_Deductible"));
			seleniumCommands.selectDropDownValueByText(seleniumCommands.findElements(TYPE).get(2), data.get("Valuable_Validation_method"));
			return this;
		}else
		return this.setValuableDesc().selectValuableType();
	}

	// Validation
	public Validation isValuablesTranscationPresentInCart()throws TestFrameworkException {
		logger.info("Checking if  endorsemnt present in cart");
		return new Validation(seleniumCommands.isElementPresent(By.cssSelector("endorsement-change-box:not([aria-hidden])")));
	}

	public void isValuablesAddTranscationPresentInCart() throws TestFrameworkException {
		String platform = System.getProperty("platform");
		String desc = platform.equalsIgnoreCase("Granite") ? "Scheduled Personal Property" : data.get("Valuable_Desc");
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEndorsementItemFromCart(desc));
		String[] title = this.parsetitle(section.getEndorsementTitle());
		String type = "Type: " + data.get("Valuable_Type");
		section.isEndorsementPresentInCart("Valuable endorsement is not present in cart");
		section.isAdditionAction();
		new Validation( desc.contains(title[0])).shouldBeTrue("Valuable desc is not correct. Expected : " + data.get("Valuable_Desc")+ ", but found : " + title[0] );

		new HOEndorsementHistoryCheck().isValuablesAddedToCart(desc, "added").shouldBeTrue("Valuables is not added to history.");
	}
	
	public void isValuablesDeleteTranscationPresentInCart(String itemName) {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEndorsementItemFromCart(itemName));
		String title = section.getEndorsementTitle();
		section.isEndorsementPresentInCart("Valuable endorsement is not present in cart");
		section.isRemoveAction();
		new Validation(title, itemName).shouldBeEqual("Valuable desc is not correct");
	}
	
	public void isValuablesEditTranscationPresentInCart() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		DraftEndorsementSection section  = new DraftEndorsementSection(this.getEndorsementItemFromCart(data.get("Valuable_Desc")));
		String[] title = this.parsetitle(section.getEndorsementTitle());
		String type = "Type: " + data.get("Valuable_Type");
		section.isEndorsementPresentInCart("Valuable endorsement is not present in cart");
		section.isEditAction();
		new Validation(title[0], data.get("Valuable_Desc")).shouldBeEqual("Valuable desc is not correct");
	}
	
	public void validateAddButtonDisabled() {
		new Validation(seleniumCommands.findElement(NEW_VALUABLE_ADD_BUTTON).getAttribute("ng-disabled"),"disabled").shouldBeEqual("Add button is not disabled white it should");
	}

	 private String[] parsetitle(String title)
	 {
		 return title.replaceAll("[$,()]", "").split(" ");
	 }

	 private WebElement getEndorsementItemFromCart(String valuableTitle)
	 {
		 List<WebElement> cartItem = seleniumCommands.findElements(By.cssSelector("endorsement-change-box[ng-repeat='change in scheduledPropertyChanges']"));
		 logger.info("Endorsement item available in no : " + cartItem.size());
		 for (WebElement e : cartItem) {
			if(seleniumCommands.getAttributeValueAtLocator(e, "title").contains(valuableTitle))
			{
				return e;
			}
		}
		 return null;
	 }
}
