package com.guidewire.capabilities.endorsement.model.page.pa;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;


public class EndorsementCoveragesPage {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(xpath = "//gw-pc-editable-coverages//label[contains(@for,'coverage')]/preceding-sibling::input[not(@checked)]")
    WebElement UNCHECKED_COVERAGES;

    By COVERAGE_CART_SECTION = By.cssSelector("endorsement-change-box[ng-show='hasCoverageChanges()']");
    
    By CHECKED_COVERAGES = By.xpath("//label/preceding-sibling::input[@checked]");

    By MEDICAL_LIMIT_VALUE = By.cssSelector("[gw-test-policycommon-editablecoverages-editablecoverages='Medical Limit'] select");

    public EndorsementCoveragesPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public EndorsementCoveragesPage selectFirstUncheckedCoverage() {
        WebElement uncheckedCoverage = seleniumCommands.getElements(UNCHECKED_COVERAGES).get(0);
        data.put("COVERAGE_TO_CHECK", uncheckedCoverage.findElement(By.xpath("./../following-sibling::div//span")).getText());
        seleniumCommands.clickbyJS(uncheckedCoverage);
        return this;
    }

    public EndorsementCoveragesPage setMedicalLimit() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(MEDICAL_LIMIT_VALUE, data.get("COVERAGE_VALUE"));
        return this;
    }

    public EndorsementCoveragesPage uncheckCheckedCoverage() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        WebElement checkedCoverage = seleniumCommands.getElements(CHECKED_COVERAGES).get(1);
        data.put("COVERAGE_TO_CHECK", checkedCoverage.findElement(By.xpath("./../following-sibling::div//span")).getText());
        seleniumCommands.clickbyJS(checkedCoverage);
        return this;
    }

    public Validation isLineCoverageSelected(){
        return isLineCoverageSelected(data.get("COVERAGE_TO_CHECK"));
    }
    public Validation isLineCoverageSelected(String coverageName){
        String jsonData = fetchDataFromBackend(data.get("POLICY_NUM"));
        List<HashMap<String,String>> lineCoverages = ParseEndorsementData.getLineCoverages(jsonData);

        return new Validation(lineCoverages.stream()
                .filter(coverage ->
                        coverage.get("name").equals(coverageName) &&
                        coverage.get("selected").equals("true"))
                .findFirst()
                .isPresent());
    }

    public String fetchDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

    public boolean validateDataAgainstBackend(String backendData, String testData){
        if (testData != null){
            return testData.equals(backendData);
        }
        return true;
    }
    
    public void validateCoverageDataInCart(String action)throws Exception {
    	seleniumCommands.logInfo("Validating coverage data in cart");
    	seleniumCommands.waitForLoaderToDisappearFromPage(15);
        DraftEndorsementSection section  = new DraftEndorsementSection(seleniumCommands.findElement(COVERAGE_CART_SECTION));
    	seleniumCommands.waitForElementToBeVisible(COVERAGE_CART_SECTION);
        String coverage = section.getEndorsementVehiclesDetails();
        section.isEndorsementPresentInCart("Address endorsement is not present in cart");
        //validating coverage data
	    new Validation(coverage.contains(data.get("COVERAGE_TO_CHECK"))).shouldBeTrue("Coverage data ->"+coverage+" do not have updated coverage ->"+ data.get("COVERAGE_TO_CHECK"));
	    
    }
}
