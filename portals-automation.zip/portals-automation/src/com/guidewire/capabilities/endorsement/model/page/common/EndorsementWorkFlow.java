package com.guidewire.capabilities.endorsement.model.page.common;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementEditToolBar;
import com.guidewire.capabilities.endorsement.model.page.common.componant.EndorsementTypeBox;
import com.guidewire.capabilities.endorsement.model.page.common.componant.PremiumSection;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementCoverages;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementMortagee;
import com.guidewire.capabilities.endorsement.model.page.ho.EndorsementValuables;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementAddressPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementDriverPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementVehiclePage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.TestFrameworkException;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.tile.DateTimeTile;

public class EndorsementWorkFlow {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	Logger logger = Logger.getLogger(this.getClass().getName());

	By REDISTRIBUTE_BUTTON = By.cssSelector("button[ng-click='redistribute()']");

	public EndorsementWorkFlow selectPolicy() throws TestFrameworkException
	{
		this.clickChangePolicyLink();
		new PolicySelection().selectPolicy();
		return this;
	}
	
	public EndorsementWorkFlow clickChangePolicyLink() throws TestFrameworkException
	{
		new AccountSummaryPage().changeMyPolicy();
		return this;
	}
	
	public AccountSummaryPage login() throws TestFrameworkException
	{
		return new Pagefactory().getAccountSummaryPage();
	}
	
	public String selectDate()
	{
		PolicyChanges changes = new PolicyChanges();
		String date = changes.getDate();
		changes.goNext();
		return date;
	}
	public String selectFutureDate()
	{
		PolicyChanges  changes = new PolicyChanges();
		String date = changes.setFuture();
		changes.goNext();
		return date;
	}

	public EndorsementWorkFlow selectValuables()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectValuables().goNext();
		return this;
	}

	public EndorsementWorkFlow selectVehicle()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectVehicle().goNext();
		return this;
	}
	public EndorsementWorkFlow selectDriver()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectDriver().goNext();
		return this;
	}
	public EndorsementWorkFlow selectMortgagee()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectMortgagee().goNext();
		return this;
	}
	
	public EndorsementWorkFlow selectCoverages()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectCovareges().goNext();
		return this;
	}

	public EndorsementWorkFlow selectAddress()
	{
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectAddress().goNext();
		return this;
	}
	
	public EndorsementWorkFlow clickAdd()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.add();
		return this;
	}

	public EndorsementWorkFlow clickAddValuable()
	{
		new SeleniumCommands().waitForLoaderToDisappearFromPage();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.addValuable();
		return this;
	}

	public EndorsementWorkFlow clickRemove()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.remove();
		return this;
	}

	public String removeVehicle()
	{
		this.clickRemove();
		String vehicleSelected= new EndorsementVehiclePage().selectVehicleByIndex(2).trim();
		new EndorsementVehiclePage().confirmRemoveVehicle();
		return vehicleSelected;
	}

	public String removeDriver()
	{
		this.clickRemove();
		String driverSelected= new EndorsementDriverPage().selectDriverByIndex(1).trim();
		new EndorsementDriverPage().confirmRemoveDriver() ;
		return driverSelected;
	}
	public String editFirstVehicle()
	{
		this.clickEdit();
		String vehicleSelected= new EndorsementVehiclePage().selectVehicleByIndex(1).trim();
		new EndorsementVehiclePage().editFormData().submitEditChange();

		return vehicleSelected;
	}
	public String editFirstDriver()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.clickEdit();
		String driverSelected= new EndorsementDriverPage().selectDriverByIndex(1).trim();
		new EndorsementDriverPage().editFormData().submitEditChange();
		new EndorsementEditToolBar().check();
		return driverSelected;
	}

	public String replaceFirstDriver()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		this.clickReplace();
		String driverSelected= new EndorsementDriverPage().selectDriverByIndex(1).trim();
		new EndorsementDriverPage().fillFormData().assignVehicleByIndex(0).withLicenseNumber("WER123").replaceChange();
		new EndorsementEditToolBar().check();
		return driverSelected;
	}

	public EndorsementWorkFlow clickEdit()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.edit();
		return this;
	}
	
	public EndorsementWorkFlow editAddress() {
		new EndorsementAddressPage().setCity(ThreadLocalObject.getData().get("NewCity"));
		return this;
	}

	public EndorsementWorkFlow clickReplace()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.replace();
		return this;
	}

	public EndorsementWorkFlow saveAndCheck()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.saveEndorsement();
		editToolBar.check();
		return this;
	}

	public EndorsementWorkFlow deleteAndCheck()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.deleteEndorsement();
		editToolBar.check();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public EndorsementWorkFlow proceedToBuyPage()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new EndorsementEditToolBar().check();
		new EndorsementPage().completeCoverage();
		this.proceedToBuyPageFromCoverages();
		return this;
	}

	public EndorsementWorkFlow proceedToBuyPageFromCoverages()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new EndorsementPage().complete().quote().buy();
		return this;
	}
	public EndorsementWorkFlow updateAndCheck()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.updateEndorsement();
		editToolBar.check();
		return this;
	}

	public EndorsementWorkFlow quoteEndorsement()
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.checkCoverage().quoteEndorsement();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}

	public EndorsementWorkFlow buyWithCheckingBankAccount()
	{
		PremiumSection section = new PremiumSection();
		section.buyQuote();
		new EndorsementPaymentPage().confirmOrPayInFullWithCheckingBank();
		return this;
	}

	public EndorsementWorkFlow buyAndRedistributeCoverageChanges()
	{
		PremiumSection section = new PremiumSection();
		section.buyQuote();
		new EndorsementPaymentPage().redistributeCoverageChanges();
		return this;
	}

	public EndorsementWorkFlow buyAndClickRedistributeCoverageChanges()
	{
		new PremiumSection().buyQuote();
		seleniumCommands.waitForElementToBeClickable(REDISTRIBUTE_BUTTON);
		seleniumCommands.findElement(REDISTRIBUTE_BUTTON).click();
		return this;
	}

	public EndorsementWorkFlow buyWithSavingBankAccount()
	{
		PremiumSection section = new PremiumSection();
		section.buyQuote();
		new EndorsementPaymentPage().confirmOrPayInFullWithSavingBank();
		return this;
	}
	
	public EndorsementWorkFlow buyWithCreditCard()
	{
		PremiumSection section = new PremiumSection();
		section.buyQuote();
		new EndorsementPaymentPage().confirmOrPayInFullWithCreditCard();
		return this;
	}
	
	public EndorsementWorkFlow addValuableDraftEndorsement() throws TestFrameworkException
	{
		this.login();
		this.selectPolicy().selectDate();
		this.addValuableDraftEndorsementFromChangePage();
		return this;
	}

	public EndorsementWorkFlow addValuableDraftEndorsementFromChangePage() throws TestFrameworkException
	{
		this.selectValuables();
		this.clickAddValuable();
		EndorsementValuables endorsementValuables = new EndorsementValuables();
		endorsementValuables.fillValuableFormData();
		this.saveAndCheck();
		return this;
	}
	
	public EndorsementWorkFlow buyValuableAndMortgageeEndorsementTogather() throws TestFrameworkException
	{
		this.login();
		ThreadLocalObject.getData().put("MortGagee_Eff_date", this.selectPolicy().selectDate());
		//this.selectPolicy().selectDate();
		this.addValuableAndMortgageeDraftEndorsement();
		return this;
	}
	
	public EndorsementWorkFlow buyValuableAndMortgageeEndorsementTogatherForFutureDate() throws TestFrameworkException
	{
		this.login();
		ThreadLocalObject.getData().put("MortGagee_Eff_date", this.selectPolicy().selectFutureDate());
		this.addValuableAndMortgageeDraftEndorsement();
		return this;
	}
	
	private EndorsementWorkFlow addValuableAndMortgageeDraftEndorsement() throws TestFrameworkException
	{
		String addBtn = "[mode*='HOMortgagee'][aria-hidden='false']";
		By SAVE_ENDO = By.cssSelector("gw-endorsement-ho-additional-interests-edit [ng-click='submitNewEntry()'][aria-disabled='false']");
		EndorsementTypeBox typeBox = new EndorsementTypeBox();
		typeBox.selectValuables().selectMortgagee().goNext();
		this.clickAddValuable();
		EndorsementValuables endorsementValuables = new EndorsementValuables();
		endorsementValuables.fillValuableFormData();
		this.saveAndCheck();
		this.clickAdd();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(addBtn));
		new EndorsementEditToolBar().add();
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData();
		seleniumCommands.clickbyJS(SAVE_ENDO);
		new EndorsementEditToolBar().check();
		new EndorsementValuables().isValuablesAddTranscationPresentInCart();
		new EndorsementMortagee().isMortgageeAddTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}

	public EndorsementWorkFlow goToSelectChanges() throws TestFrameworkException
	{
		this.login();
		this.selectPolicy().selectDate();
		return this;
	}

	public String removeVehicleEndorsement() throws TestFrameworkException
	{
		String removedVehicle = this.goToSelectChanges().selectVehicle().removeVehicle();
		return removedVehicle;
	}

	public String removeDriverEndorsement() throws TestFrameworkException
	{
		String removedDriver = this.goToSelectChanges().selectDriver().removeDriver();
		return removedDriver;
	}
	public EndorsementWorkFlow editVehicleEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		return editVehicleEndorsementStartingFromDateForm();
	}

	public EndorsementWorkFlow editVehicleEndorsementStartingFromDateForm() throws TestFrameworkException
	{
		new EndorsementWorkFlow().selectVehicle().editFirstVehicle();
		new EndorsementEditToolBar().check();
		return this;
	}

	public EndorsementWorkFlow editDriverEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges().selectDriver().editFirstDriver();
		return this;
	}
	public EndorsementWorkFlow addVehicleDraftEndorsement(boolean assignDriver) throws TestFrameworkException
	{
		this.goToSelectChanges().selectVehicle().addVehicleDraftEndorsementFromEditEndosmentForm(assignDriver);
		return this;
	}

	public EndorsementWorkFlow addVehicleDraftEndorsementFromEditEndosmentForm(boolean assignDriver) throws TestFrameworkException
	{
		this.clickAdd();
		EndorsementVehiclePage vehicle = new EndorsementVehiclePage();
		vehicle.fillFormData();

		if (assignDriver) {
			vehicle.assignDriverByIndex(0);
		}
		this.saveAndCheck();
		return this;
	}



	public EndorsementWorkFlow addDriverDraftEndorsement(boolean assignedVehicle) throws TestFrameworkException
	{
		this.addDriverDraftEndorsementWithoutCoverages(assignedVehicle);
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.check();
		return this;
	}

	public EndorsementWorkFlow addDriverDraftEndorsementWithoutCoverages(boolean assignedVehicle) throws TestFrameworkException
	{
		this.goToSelectChanges();
		return addDriverDraftEndorsementStartingFromDateForm(assignedVehicle);
	}

	public EndorsementWorkFlow addDriverDraftEndorsementStartingFromDateForm(boolean assignedVehicle) throws TestFrameworkException
	{
		selectDriver().clickAdd();
		EndorsementDriverPage driver= new EndorsementDriverPage();
		driver.addewDriverButton().fillFormData() ;
		if(assignedVehicle){
			driver.assignVehicleByIndex(0);
		}
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.saveEndorsement();
		return this;
	}

	public EndorsementWorkFlow addMortageeDraftEndorsement() throws TestFrameworkException
	{
		this.login();
		ThreadLocalObject.getData().put("MortGagee_Eff_date", this.selectPolicy().selectDate());
		addMortageeDraftEndorsementFromChangePage();
		return this;
	}

	public EndorsementWorkFlow addMortageeDraftEndorsementFromChangePage() throws TestFrameworkException
	{
		this.selectMortgagee().clickAdd();
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData();
		this.saveAndCheck();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return this;
	}
	
	public String addMortageeEndorsementWithFutureDate() throws TestFrameworkException
	{
		this.login();
		String date = this.selectPolicy().selectFutureDate();
		this.selectMortgagee().clickAdd();
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData();
		this.saveAndCheck();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return date;
	}
	
	public Validation withDrawDraftValuableEndorsement() throws TestFrameworkException
	{ 
		this.addValuableDraftEndorsement();
		EndorsementValuables endorsementValuables = new EndorsementValuables();
		endorsementValuables.isValuablesAddTranscationPresentInCart();
		new PolicyChanges().withDrawEndorsement();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		boolean flag = false;
		try
		{
			seleniumCommands.pageWebElementLoader(this);
			new Pagefactory().getAccountSummaryPage().changeMyPolicy();
			new PolicySelection().selectPolicy();
			new DateTimeTile();
			return endorsementValuables.isValuablesTranscationPresentInCart();
		}
		catch (TestFrameworkException e) 
		{
			 flag = true;
		}
		catch (NullPointerException e) 
		{
			 flag = true;
		}
		
		return new Validation(flag);
	}

	public Validation withDrawQuotedMortgageeEndorsement() throws TestFrameworkException
	{ 
		this.addMortageeDraftEndorsement().quoteEndorsement();
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.isMortgageeAddTranscationPresentInCart();
		new PolicyChanges().withDrawEndorsement().changeMyPolicy();
		seleniumCommands.waitForLoaderToDisappearFromPage();
		boolean flag = false;
		try
		{
			seleniumCommands.pageWebElementLoader(this);
			new PolicySelection().selectPolicy();
			return endorsementMortagee.isMortgageeTranscationPresentInCart();
		}
		catch (AssertionError e) 
		{
			 flag = true;
		}
		return new Validation(flag);
	}
	
	public Validation cancelWithDrawDraftValuableEndorsement() throws TestFrameworkException
	{ 
		this.addValuableDraftEndorsement();
		EndorsementValuables endorsementValuables = new EndorsementValuables();
		endorsementValuables.isValuablesAddTranscationPresentInCart();
		new PolicyChanges().dismissWithDrawEndorsement();
		new DraftEndorsementSection().isEndorsementPresentInCart("Endorsement cart is not present");
		return new Validation(true);
	}
	
	public Validation cancelWithDrawQuotedMortgageeEndorsement() throws TestFrameworkException
	{ 
		this.addMortageeDraftEndorsement().quoteEndorsement();
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.isMortgageeAddTranscationPresentInCart();
		new PolicyChanges().dismissWithDrawEndorsement();
		new DraftEndorsementSection().isEndorsementPresentInCart("Endorsement is not present in the cart");
		return new Validation(true);
	}
	
	public EndorsementWorkFlow buyAddValuableEndorsement() throws TestFrameworkException
	{ 
		this.addValuableDraftEndorsement();
		new EndorsementValuables().isValuablesAddTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}
	
	public EndorsementWorkFlow buyAddMortageeEndorsement() throws TestFrameworkException
	{ 
		this.addMortageeDraftEndorsement();
		new EndorsementMortagee().isMortgageeAddTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}
	
	public EndorsementWorkFlow buyCoverageChageEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		this.selectCoverages();
		EndorsementCoverages coverages = new EndorsementCoverages();
		coverages.setAllOtherPeril().setLimitPercentOfDwel().setPersonalInjury();
		quoteAndBuyCoverageChangeEndorsement();
		return this;
	}

	public EndorsementWorkFlow quoteAndBuyCoverageChangeEndorsement() throws TestFrameworkException
	{
		this.quoteEndorsement();
		new EndorsementCoverages().isCoverageTransationPresentInCart();
		this.buyWithCheckingBankAccount();
		return this;
	}
	
	public EndorsementWorkFlow buyEditedMortgageeEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		this.editMortgageeEndorsementFromChangePageAndBuyIt();
		return this;
	}

	public EndorsementWorkFlow editMortgageeEndorsementFromChangePageAndBuyIt() throws TestFrameworkException
	{
		this.selectMortgagee().clickEdit();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.selectEndorsementandAndGetCellvalue(1, 3);
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData();
		this.updateAndCheck();
		new EndorsementMortagee().isMortgageeEditTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}
	
	public EndorsementWorkFlow buyReplacedMortgageeEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		this.selectMortgagee().clickReplace();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.selectEndorsementandAndGetCellvalue(1, 3);
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData();
		editToolBar.replaceEndorsement();
		editToolBar.check();
		new EndorsementMortagee().isMortgageeAddTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}

	public String replaceMortgagee()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		clickReplace();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String selectMortagee = editToolBar.selectEndorsementandAndGetCellvalue(1,4);
		EndorsementMortagee endorsementMortagee = new EndorsementMortagee();
		endorsementMortagee.fillMortageeFormData().replaceChange();
		new EndorsementEditToolBar().check();
		return selectMortagee;
	}
	
	public String buyRemoveValuableEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		return this.buyRemoveValuableEndorsementFromChangePage();
	}

	public String buyRemoveValuableEndorsementFromChangePage() throws TestFrameworkException
	{
		this.selectValuables();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String deleted_valuable = editToolBar.removeValuable();

		boolean platformFlag = System.getProperty("platform").equalsIgnoreCase("Ferrite91") || System.getProperty("platform").equalsIgnoreCase("Granite");
		String deletedValuableDesc = (platformFlag)? "": ThreadLocalObject.getData().get("Valuable_Desc");
		this.deleteAndCheck();
		new EndorsementValuables().isValuablesDeleteTranscationPresentInCart(deletedValuableDesc);
		this.quoteEndorsement().buyWithCheckingBankAccount();
		if(platformFlag){
			return deleted_valuable;
		}else {
			return deletedValuableDesc;
		}
	}

	public String buyRemovedVehicleEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		this.selectVehicle().clickRemove();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String vehicleSelected = editToolBar.selectEndorsementandAndGetCellvalue(1,2);
		String vin = editToolBar.selectEndorsementandAndGetCellvalue(1,3);
		logger.info("=============SELECTED VEHICLE's VIN==============>>>>" + vin);
		String[] vehArray = vehicleSelected.split(" ");
		ThreadLocalObject.getData().put("VehicleYear", vehArray[0]);
		ThreadLocalObject.getData().put("Make", vehArray[1]);
		ThreadLocalObject.getData().put("Model", vehArray[2]);
		this.deleteAndCheck();
		new EndorsementVehiclePage().isVehiclesRemoveTranscationPresentInCart(vehicleSelected);
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return vin;
	}

	public String buyRemovedVehicleEndorsementFromEndorsmentChanges() throws TestFrameworkException
	{
		String vehicleSelected = this.removeVehicle() + " (12345/CA)";
		String vin = (vehicleSelected.split(" "))[1];
		new EndorsementEditToolBar().check();
		new EndorsementVehiclePage().isVehiclesRemoveTranscationPresentInCart(vehicleSelected);
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return vin;
	}

	public String buyRemovedDriverEndorsement() throws Exception
	{
		this.goToSelectChanges();
		this.selectDriver().clickRemove();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String driverName = editToolBar.selectEndorsementandAndGetCellvalue(1,2);
		String lisence = editToolBar.selectEndorsementandAndGetCellvalue(1,4);
		this.deleteAndCheck();
		new EndorsementDriverPage().isDriverRemoveTranscationPresentInCart(driverName);;
		this.quoteEndorsement().buyWithCheckingBankAccount();
		seleniumCommands.logInfo("License for the driver to be removed :- " + lisence);
		return lisence;
	}

	public String buyRemovedDriverEndorsementFromEndorsmentChanges() throws Exception
	{
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String lisence = editToolBar.getCellValue(1,4);
		String driverName = this.removeDriver();
		new EndorsementEditToolBar().check();
		new EndorsementDriverPage().isDriverRemoveTranscationPresentInCart(driverName);
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return lisence;
	}

	public String buyRemoveMortgageeEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		return this.buyRemoveMortgageeEndorsementFromChangePage();
	}

	public String buyRemoveMortgageeEndorsementFromChangePage() throws TestFrameworkException
	{
		this.selectMortgagee().clickRemove();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		String mortgagge = editToolBar.selectEndorsementandAndGetCellvalue(1, 2);
		this.deleteAndCheck();
		new EndorsementMortagee().isMortgageeDeleteTranscationPresentInCart(mortgagge);
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return mortgagge;
	}
	
	public EndorsementWorkFlow buyEditedValuableEndorsement() throws TestFrameworkException
	{
		this.goToSelectChanges();
		this.editValuableEndorsementFromChangePageAndBuyIt();
		return this;
	}

	public EndorsementWorkFlow editValuableEndorsementFromChangePageAndBuyIt() throws TestFrameworkException
	{
		this.selectValuables();
		EndorsementEditToolBar editToolBar = new EndorsementEditToolBar();
		editToolBar.editValuable();
		EndorsementValuables endorsementValuables = new EndorsementValuables();
		endorsementValuables.fillValuableFormData();
		this.updateAndCheck();
		seleniumCommands.staticWait(10);
		new EndorsementValuables().isValuablesEditTranscationPresentInCart();
		this.quoteEndorsement().buyWithCheckingBankAccount();
		return this;
	}
	
	
}
