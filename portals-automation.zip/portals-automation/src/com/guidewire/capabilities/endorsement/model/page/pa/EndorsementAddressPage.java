package com.guidewire.capabilities.endorsement.model.page.pa;


import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class EndorsementAddressPage {

    @FindBy(css = "ng-form[name='form']")
    WebElement FORM_FILL;

    @FindBy(css = "[model='address.addressLine1'] input")
    WebElement ADD_LINE1_INPUT_CSS;

    @FindBy(css = "[model='address.addressLine1'] .gw-error-inline")
    WebElement ADD_LINE1_INPUT_ERR_CSS;

    @FindBy(css = "[model='address.addressLine2'] input")
    WebElement ADD_LINE2_INPUT_CSS;

    @FindBy(css = "[model='address.addressLine3'] input")
    WebElement ADD_LINE3_INPUT_CSS;

    @FindBy(css = "[model='address.city'] input")
    WebElement ADD_CITY_INPUT_CSS;

    @FindBy(css = "[model='address.city'] .gw-error-inline")
    WebElement ADD_CITY_INPUT_ERR_CSS;

    @FindBy(css = "[model='address.postalCode'] input")
    WebElement ADD_ZIPCODE_INPUT_CSS;
    
	By ADDRESS_CART_SECTION = By.cssSelector("endorsement-change-box[ng-repeat='change in addressChanges']");

    private static final String NEXT_ADDRESS_BTN_CSS = "button[ng-click='onNext()']";

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();

    public EndorsementAddressPage() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM_FILL);
    }

    public ViewModelInput getInput(String input) {
        return this.getForm().getInputByModel(input);
    }

    public EndorsementAddressPage setAddressLine1(String addLine1){
        seleniumCommands.type(ADD_LINE1_INPUT_CSS, addLine1);
        return this;
    }

    public EndorsementAddressPage setAddressLine2(String addLine2){
        seleniumCommands.type(ADD_LINE2_INPUT_CSS, addLine2);
        return this;
    }

    public EndorsementAddressPage setAddressLine3(String addLine3){
        seleniumCommands.type(ADD_LINE3_INPUT_CSS, addLine3);
        return this;
    }

    public EndorsementAddressPage setCity(String city){
        seleniumCommands.type(ADD_CITY_INPUT_CSS, city);
        return this;
    }

    public EndorsementAddressPage setZipcode(String zipcode){
        seleniumCommands.type(ADD_ZIPCODE_INPUT_CSS, zipcode);
        return this;
    }

    public EndorsementAddressPage clearAddress(){
        this.setAddressLine1("")
                .setAddressLine2("")
                .setAddressLine3("")
                .setCity("")
                .setZipcode("");
        return this;
    }

    //Validation

    public Validation isNextEnabledForAddress(){
        seleniumCommands.logInfo("Verifying if Next is enabled for Address");
        return new Validation(seleniumCommands.isElementClickable(By.cssSelector(NEXT_ADDRESS_BTN_CSS)));
    }

    public Validation isAddLine1MarkedWithMandatoryError(){
        seleniumCommands.logInfo("Verifying if Address Line 1 is marked with mandatory error");
        return new Validation(seleniumCommands.getTextAtLocator(ADD_LINE1_INPUT_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }

    public Validation isCityMarkedWithMandatoryError(){
        seleniumCommands.logInfo("Verifying if City is marked with mandatory error");
        return new Validation(seleniumCommands.getTextAtLocator(ADD_CITY_INPUT_ERR_CSS), DataConstant.MANDATORY_ERROR_MSG);
    }
    
    public void validateAddressDetailsInCart()throws Exception {
    	seleniumCommands.logInfo("Verifying Address in the cart");
    	seleniumCommands.waitForLoaderToDisappearFromPage(15);
    	seleniumCommands.waitForElementToBeVisible(ADDRESS_CART_SECTION);
        DraftEndorsementSection section  = new DraftEndorsementSection(seleniumCommands.findElement(ADDRESS_CART_SECTION));
        String address = section.getEndorsementVehiclesDetails();
        section.isEndorsementPresentInCart("Address endorsement is not present in cart");
        //validating address data
	    new Validation(address.contains(data.get("NewCity"))).shouldBeTrue("Address data ->"+address+" do not have New City name ->"+ data.get("NewCity"));
    }
}
