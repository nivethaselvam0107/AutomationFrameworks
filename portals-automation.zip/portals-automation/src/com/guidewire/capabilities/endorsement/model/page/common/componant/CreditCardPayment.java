package com.guidewire.capabilities.endorsement.model.page.common.componant;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.endorsement.model.page.common.PaymentTypeEnum.PaymentMethodEnum;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.widgetcomponents.form.ViewModelForm;

public class CreditCardPayment 
{
	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	Logger logger = Logger.getLogger(this.getClass().getName());

	String PAYMENT_METHOD_MODEL = "paymentDetails.paymentMethod";
	String CARD_ISSUER_MODEL = "creditCardDetails.creditCardIssuer";
	String CREDIT_CARD_NUM_MODEL = "creditCardDetails.creditCardNumber";
	String CREDIT_CARD_EXP_MONTH_MODEL = "creditCardDetails.creditCardExpDate";
	
	@FindBy(css = "ng-form[ng-show='paymentDetailsEnabled']")
	WebElement FORM;
	
	@FindBy(css = "[ng-model='paymentDetails.paymentMethod']")
	WebElement PAYMENT_METHOD_CSS;

	@FindBy(css = "[gw-pl-radios-binary]")
	WebElement TYPE_TOGGLER;
	
	@FindBy(css = "[name='dateFieldsMonth']")
	WebElement CREDIT_CARD_MONTH_DROP_NAME;

	@FindBy(css = "[name='dateFieldsYear']")
	WebElement CREDIT_CARD_YEAR_DROP_NAME;

	public CreditCardPayment() {
		seleniumCommands.pageWebElementLoader(this);
		data.put("CardNum","234567876542345");
		data.put("ExpMonth", "July");
		data.put("ExpYear", "2019");
		data.put("CardIssuer", "American Express");
	}

	public ViewModelForm getForm() {
		return new ViewModelForm(FORM);
	}
	
	public CreditCardPayment selectCreditCardPaymentMethod() {
			logger.info("Selecting credit card");
			seleniumCommands.pageWebElementLoader(PAYMENT_METHOD_CSS);
			seleniumCommands.selectDropDownValueByText(PAYMENT_METHOD_CSS,PaymentMethodEnum.CreditCard.toString());
			return this;
	}

	public CreditCardPayment withCardIssuer() {
		logger.info("Setting credit card issuer value");
		this.getForm().getInputByModel(CARD_ISSUER_MODEL).setValue(data.get("CardIssuer"));
		return this;
	}
	
	public CreditCardPayment withCreditCardNum() {
		logger.info("Setting credit card issuer num");
		seleniumCommands.type(By.cssSelector("div[model='creditCardDetails.creditCardNumber'] input"), data.get("CardNum"));
		return this;
	}
	
	public CreditCardPayment withExpMonth() {
		logger.info("Setting card exp month");
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_MONTH_DROP_NAME, data.get("ExpMonth"));
		return this;
	}
	
	public CreditCardPayment withExpYear() {
		logger.info("Setting card exp year");
		seleniumCommands.selectDropDownValueByText(CREDIT_CARD_YEAR_DROP_NAME, data.get("ExpYear"));
		return this;
	}
	
	public CreditCardPayment payWithCreditCard() {
		logger.info("Paying with credit card");
		this.selectCreditCardPaymentMethod().withCreditCardNum().withCardIssuer().withExpMonth().withExpYear();
		return this;
	}

}
