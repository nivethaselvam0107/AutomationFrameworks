package com.guidewire.capabilities.endorsement.model.page.pa;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.endorsement.model.page.common.componant.DraftEndorsementSection;
import com.guidewire.capabilities.endorsement.validation.pa.PAEndorsementHistoryCheck;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseEndorsementData;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;


public class EndorsementVehiclePage {
    public static final String VIN = "vehicle.vin";
    public static final String MAKE = "vehicle.make";
    public static final String MODEL = "vehicle.model";
    public static final String YEAR = "vehicle.year";
    public static final String LICENSE_PLATE = "vehicle.license";
    public static final String STATE = "vehicle.licenseState";
    public static final String COST_NEW = "vehicle.costNew.amount";
    private static final String ACTION_ADD_CSS = ".gw-endorsement-button-add";
    private static final String ACTION_REPLACE_CSS = ".gw-endorsement-button-replace";
    private static final String ACTION_EDIT_CSS = ".gw-endorsement-button-edit";
    private static final String ACTION_REMOVE_CSS = ".gw-endorsement-button-remove";

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    String POLICY_XPATH = "//div[contains(text(),'POLICYNUM')]";

    private static final String ERROR_MESSAGE_XPATH = "//*[contains(@class,'warning')]//div[contains(text(),'MAKE-MODEL')]";

    @FindBy(css = "[name='vehicleForm']")
    WebElement FORM;

    @FindBy(css = "div[model='vehicle.year'] div.gw-controls span.ng-binding")
    WebElement VEHICLE_READONLY_CSS; //ViewModelForm doesn't work here

    @FindBy(css = "button[ng-click='submitNewEntry()'][aria-disabled='false']")
    WebElement SUBMIT_BTN_CSS;
    
    @FindBy(css = "button[ng-click='updateEntry()'][aria-disabled='false']")
    WebElement UPDATE_CHANGE_BTN_CSS;
    
    @FindBy(css = "button[ng-click='replaceEntry()'][aria-disabled='false']")
    WebElement REPLACE_CHANGE_BTN_CSS;

    @FindBy(css = "[ng-repeat='driver in policyChange.lobs.personalAuto.drivers']")
    WebElement DRIVER_ASSIGNMENT_FIELDS;

    @FindBy(css = "select[ng-model='selection.item']")
    WebElement VEHICLE_SELECTION_INPUT;

    @FindBy(css = "button[ng-click='deleteEntry($index)']")
    WebElement CONFIRM_BUTTON;

    @FindBy(css = "a[ng-click='changeVehicle(v)']")
    WebElement CHANGE_VEHICLE_WARNING_BUTTON;

    @FindBy(css = "a[ng-click='removeVehicle(v)']")
    WebElement REMOVE_VEHICLE_WARNING_BUTTON;
    
    @FindBy(css = "[model='vehicle.vin'] input")
	 WebElement VIN_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.vin'] span")
	 WebElement VIN_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.make'] span")
	 WebElement MAKE_LBL_CSS;
	
	@FindBy(id = "Make")
	 WebElement MAKE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.make'] input")
	 WebElement MAKE_VALUE_CSS;

	@FindBy(css = "[model='vehicle.model'] input")
	 WebElement MODEL_VALUE_CSS;
	
	@FindBy(css = "[model='vehicle.model'] span")
	 WebElement MODEL_LBL_CSS;
	
	@FindBy(id = "Model")
	 WebElement MODEL_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.year'] select")
	 WebElement YEAR_VALUE_CSS;
	
	@FindBy(css = "[model='vehicle.year'] span")
	 WebElement YEAR_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.year'] select")
	 WebElement YEAR_DROP_CSS;
	
	@FindBy(css = "[model='vehicle.year'] [ng-show='readonly']")
	 WebElement YEAR_VALUE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.license'] input")
	 WebElement LICENSE_PLATE_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.license'] span")
	 WebElement LICENSE_PLATE_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.licenseState'] select")
	 WebElement STATE_DROP_CSS;
	
	@FindBy(css = "[model='vehicle.licenseState'] span")
	 WebElement STATE_LBL_CSS;
	
	@FindBy(css = "[model='vehicle.costNew.amount'] input")
	 WebElement COST_TXT_CSS;
	
	@FindBy(css = "[model='vehicle.costNew.amount'] span")
	 WebElement COST_LBL_CSS;
	
	@FindBy(css = "[class='gw-endorsement-change-area']")
    WebElement DRIVER_ENRORSMENT_CHANGE_AREA;
	
	@FindBy(css = "button[ng-click='updateEntry()'][aria-disabled='false'], button[ng-click='updateEntry()']")
    WebElement EDIT_CHANGE_BTN_CSS;
	
	@FindBy(css = "endorsement-change-box[ng-repeat='c in vehicleChanges']")
	WebElement VEHICLES_CART_DATA;
	
	@FindBy(css = "endorsement-change-box[ng-repeat='change in vehicleChanges']")
	List<WebElement> VEHICLES_CART_SECTION;

    private static final String ADD_VEHICLE_AFTER_DETAILS_CSS = "[ng-click='submitNewEntry()']";

    public EndorsementVehiclePage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public EndorsementVehiclePage selectAction(String action) {
    	seleniumCommands.waitForElementToBeVisible(DRIVER_ENRORSMENT_CHANGE_AREA);
        switch(action){
            case "Add":
                seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_ADD_CSS))));
                break;
            case "Edit":
                seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_EDIT_CSS))));
                break;
            case "Replace":
                seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_REPLACE_CSS))));
                break;
            case "Remove":
                seleniumCommands.clickbyJS(ThreadLocalObject.getDriver().findElement((By.cssSelector(ACTION_REMOVE_CSS))));
                break;
            default:
                break;
        }
        return this;
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public EndorsementVehiclePage withVin() {
    		this.getForm().getInputByModel(VIN).setValue(data.get("VIN"));
        return this;
    }
    
    public EndorsementVehiclePage withMake() {
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class='ng-pristine ng-untouched ng-valid ng-scope ng-empty']"));
		this.getForm().getInputByModel(MAKE).setValue(data.get("Make"));
    return this;
    }
    
    public EndorsementVehiclePage withModel() {
		this.getForm().getInputByModel(MODEL).setValue(data.get("Model"));
    return this;
    }

    public EndorsementVehiclePage withLicensePlate() {
    	  this.getForm().getInputByModel(LICENSE_PLATE).setValue(data.get("LicensePlate"));
        return this;
    }

    public EndorsementVehiclePage withState() {
    	 this.getForm().getInputByModel(STATE).setValue(data.get("VehicleState"));
        return this;
    }

    public EndorsementVehiclePage withCostNew() {
    	 this.getForm().getInputByModel(COST_NEW).setValue(data.get("VehicleCost"));
        return this;
    }
    
    public ViewModelInput withYear() {
        return this.getForm().getInputByModel(YEAR).setValue(data.get("VehicleYear"));
    }

    public ViewModelInput getVinInput() {
        return this.getForm().getInputByModel(VIN);
    }

    public ViewModelInput getMakeInput() {
        return this.getForm().getInputByModel(MAKE);
    }

    public ViewModelInput getModelInput() {
        return this.getForm().getInputByModel(MODEL);
    }

    public ViewModelInput getYearInput() {
        return this.getForm().getInputByModel(YEAR);
    }

    public ViewModelInput getLicensePlateInput() {
        return this.getForm().getInputByModel(LICENSE_PLATE);
    }

    public ViewModelInput getStateInput() {
        return this.getForm().getInputByModel(STATE);
    }

    public ViewModelInput getCostNewInput() {
        return this.getForm().getInputByModel(COST_NEW);
    }

    public EndorsementVehiclePage assignDriverByIndex(int index){
    	seleniumCommands.findElement(By.cssSelector("[for='vehicle-driver-"+index +"']")).click();
        return this;
    }
    
    public EndorsementVehiclePage assignExistingDriver(String index) {
		String driver = "//tablet/body//tr["+ index +"]/td/input".replace("index", index);
		seleniumCommands.waitForElementToBeVisible(By.xpath(driver));
		seleniumCommands.clickbyJS(By.xpath(driver));
    return this;
}

    public String selectVehicleByIndex(int index){
    	return selectExistingVehicleForEdition(index+"");
    }
    
    public String selectExistingVehicleForEdition(String index) {
        String driver = "//table/tbody//tr["+ index +"]/td/input".replace("index", index);
        String vehicle = seleniumCommands.getTextAtLocator(By.xpath(driver + "/../following-sibling::td")).split("in")[0];
        seleniumCommands.waitForElementToBeVisible(By.xpath(driver));
        seleniumCommands.clickbyJS(By.xpath(driver));
        return vehicle;
    }

    public EndorsementPage confirmRemoveVehicle(){
        seleniumCommands.waitForElementToBeVisible(CONFIRM_BUTTON);
        seleniumCommands.clickbyJS(CONFIRM_BUTTON);
        return new EndorsementPage();
    };

    public EndorsementPage submit() {
        //ViewModelForm form = this.getForm();
        seleniumCommands.clickbyJS(SUBMIT_BTN_CSS);
        //if (!form.isShowingAnyErrors()) {
        waitforModelPopUpToDisappear();
            return new EndorsementPage();
        //}

        //return null;
    }
    
    public EndorsementPage submitEditChange() {
        seleniumCommands.clickbyJS(EDIT_CHANGE_BTN_CSS);
            return new EndorsementPage();
    }
    
    private EndorsementVehiclePage waitforModelPopUpToDisappear()
    {
    	 	seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class='gw-modal-body ng-scope']"));
         seleniumCommands.waitForElementToDisappear(By.cssSelector("[class='gw-modal-body ng-scope']"));
         return this;
    }

    public Validation canPerformAction(String action) {
     	seleniumCommands.waitForElementToBeVisible(DRIVER_ENRORSMENT_CHANGE_AREA);
        switch (action) {
            case "Add":
                return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_ADD_CSS)).getAttribute("aria-disabled")), false);
            case "Edit":
                return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_EDIT_CSS)).getAttribute("aria-disabled")), false);
            case "Replace":
                return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_REPLACE_CSS)).getAttribute("aria-disabled")), false);
            case "Remove":
                return new Validation(new Boolean(seleniumCommands.findElement(By.cssSelector(ACTION_REMOVE_CSS)).getAttribute("aria-disabled")), false);
            default:
                return new Validation(false);
        }
    }

    public Validation isAddEnabledForNewVehicle(){
        return new Validation(seleniumCommands.isElementClickable(By.cssSelector(ADD_VEHICLE_AFTER_DETAILS_CSS)));
    }

    public EndorsementVehiclePage fillFormData(){
        withVin().withLicensePlate().withMake().withModel().withCostNew().withState().withYear();
        return this;
    }

    public EndorsementVehiclePage editFormData(){
        data.put("Make",seleniumCommands.getValueAttributeFromLocator(MAKE_VALUE_CSS) );
        data.put("VIN",seleniumCommands.getValueAttributeFromLocator(VIN_TXT_CSS) );
        data.put("Model",seleniumCommands.getValueAttributeFromLocator(MODEL_TXT_CSS) );
        data.put("VehicleYear",seleniumCommands.getSelectedOptionFromDropDown(YEAR_DROP_CSS) );
        withLicensePlate().withCostNew();
        return this;
    }

    public EndorsementVehiclePage clickChangeVehicleWarningButton() {
        seleniumCommands.clickbyJS(CHANGE_VEHICLE_WARNING_BUTTON);
        return this;
    }

    public EndorsementVehiclePage clickRemoveVehicleWarningButton() {
        seleniumCommands.clickbyJS(REMOVE_VEHICLE_WARNING_BUTTON);
        return this;
    }

    public EndorsementVehiclePage getMakeYearModelAndPutInTestData() {
        data.put("MAKE",seleniumCommands.getTextAtLocator(By.xpath("//*[@id='Make']/following-sibling::span")));
        data.put("MODEL",seleniumCommands.getTextAtLocator(By.xpath("//*[@id='Model']/following-sibling::span")));
        String year = VEHICLE_READONLY_CSS.getText();
        if (year.isEmpty()){
            year = YEAR_VALUE_TXT_CSS.getText();
        }
        data.put("YEAR",year);
        return this;
    }

    public EndorsementVehiclePage getVinAndPutInTestData() {
        data.put("VIN",seleniumCommands.getAttributeValueAtLocator(VIN_TXT_CSS, "value"));
        return this;
    }

    public Validation doesVehicleExistOnPolicyChangeFromBackend(){
        List<HashMap<String,String>> vehicles = ParseEndorsementData.getVehicles(fetchDataFromBackend(data.get("POLICY_NUM")));
        return new Validation(vehicles.stream()
                .filter(vehicle ->
                                validateDataAgainstBackend(vehicle.get("vin"),data.get("VIN")) &&
//                                validateDataAgainstBackend(vehicle.get("make"),data.get("MAKE")) &&
//                                validateDataAgainstBackend(vehicle.get("year"),data.get("YEAR")) &&
      //                          validateDataAgainstBackend(vehicle.get("model"),data.get("MODEL"))) &&
                                validateDataAgainstBackend(vehicle.get("costNew"),data.get("COST_NEW"))) 
                                
                .findFirst()
                .isPresent());
    }

    public Validation isVehicleRemovedFromBackend(){
        return isVehicleRemovedFromBackend(data.get("VIN"));
    }

    public Validation isVehicleRemovedFromBackend(String vin){
        List<HashMap<String,String>> vehicles = ParseEndorsementData.getVehicles(fetchDataFromBackend(data.get("POLICY_NUM")));
        return new Validation(vehicles.stream()
                .filter(vehicle ->
                        !vehicle.get("vin").equals(vin))
                .findFirst()
                .isPresent());
    }

    public String fetchDataFromBackend(String policyNumber){
        return DataFetch.getPolicyChangeData(policyNumber, data.get("USER"));
    }

    public boolean validateDataAgainstBackend(String backendData, String testData){
        if (testData != null){
        		System.out.println( "TestData"+ testData +"BackEnd" +backendData );
            return testData.equals(backendData);
        }
        return true;
    }
    
 // Validation
    public void isVehiclesRemoveTranscationPresentInCart(String deletedVehicle) {
    		logger.info("Validating vehicle remove transaction is available in policy cart");
		DraftEndorsementSection section  = new DraftEndorsementSection(getVehicleCartSection());
		section.isEndorsementPresentInCart("Vehicle endorsement is not present in cart");
		section.isRemoveAction();
        new Validation(section.getEndorsementTitle().trim(), deletedVehicle.replace(" in "+data.get("STATE"), "").replaceFirst(" ", "")).shouldBeEqual("Vehicle is not added to cart for deletion");
	}

    public void validateErrorMessageWhileNoDriverAssigned() {
    	seleniumCommands.waitForLoaderToDisappearFromPage();
    	String errorMsg = DataConstant.NO_DRIVER_ASSIGNED_MSG + " " +data.get("Make") +" " + data.get("Model")+" " +data.get("VehicleYear");
    	String errorUI = seleniumCommands.getTextAtLocator(By.xpath(ERROR_MESSAGE_XPATH.replace("MAKE-MODEL", data.get("Make") +" " + data.get("Model"))));
        new Validation(errorUI.contains(errorMsg)).shouldBeTrue("Error message is not correct. Expected this =>" + errorMsg + " to be found in => " + errorUI);
    }

    private void validateDetailsInCart(String action)throws Exception {
        DraftEndorsementSection section  = new DraftEndorsementSection(getVehicleCartSection());
        String[] title = this.parsetitle(section.getEndorsementTitle());
        section.isEndorsementPresentInCart("Vehicle endorsement is not present in cart");
        //validating title data
        new Validation(title[0], data.get("VehicleYear")).shouldBeEqual("Year is not correct");
        new Validation(title[2], data.get("Model")).shouldBeEqual("Model desc is not correct");
        //validating details inside of the card
        String licensePlate= "License Plate: "+ data.get("LicensePlate");
        String sectionText = section.getEndorsementVehiclesDetails().replaceAll("\n", "");
        logger.info("=========CART UI DATA========\n" + sectionText);
        new Validation(sectionText.contains("Cost new: "+ data.get("COST_DESC"))).shouldBeTrue("Cost text : '"+ data.get("COST_DESC") + "' is missing or incorrect in '" + sectionText + "'");
        new Validation(sectionText.contains(licensePlate)).shouldBeTrue("License Plate is missing or incorrect. Looked for ="+ licensePlate + "= inside of *" + sectionText+"*"); ;
        //validating that data was added to Backend
        new PAEndorsementHistoryCheck().isVehicleAddedToCart(action).shouldBeTrue("Vehicle is not " + action+ " to history");

    }

    public void isVehicleAddTranscationPresentInCart() throws Exception {
    		logger.info("================Validating the add vehicle transaction==================");
        new DraftEndorsementSection(getVehicleCartSection()).isAdditionAction();
        this.validateDetailsInCart("added");
    }

    public void isVehicleEditTranscationPresentInCart() throws Exception {
    		logger.info("================Validating the edit vehicle transaction==================");
        new DraftEndorsementSection(getVehicleCartSection()).isEditAction();
        this.validateDetailsInCart("changed");
    }

    private String[] parsetitle(String title)
    {
        return title.replaceAll("[$,()]", "").split(" ");
    }
    
    private WebElement getVehicleCartSection()
	{
		seleniumCommands.waitForLoaderToDisappearFromPage();
		logger.info("Vehicle available in Cart UI =========>> " + VEHICLES_CART_SECTION.size());
		for(WebElement element : VEHICLES_CART_SECTION)
		{
			String vehicleTitle = seleniumCommands.getAttributeValueAtLocator(element, "title");
			if(vehicleTitle.contains(data.get("Make") + " " + data.get("Model")))
			{
				logger.info("=======>>>> Vehicle item was found in cart: "+ vehicleTitle);
				return element;
			}
		}
		return null;
	}
}
