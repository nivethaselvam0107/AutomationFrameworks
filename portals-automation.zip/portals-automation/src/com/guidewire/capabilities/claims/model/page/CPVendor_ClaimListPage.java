package com.guidewire.capabilities.claims.model.page;

import com.guidewire.capabilities.claims.model.component.ClaimListPage;
import com.guidewire.common.testNG.Validation;
import org.apache.log4j.Logger;

public class CPVendor_ClaimListPage extends ClaimListPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @Override
    public Validation isClaimListPageLoaded() {
        logger.info("Validating claim list columns on CP-ClaimVendor");
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
        new Validation(seleniumCommands.isElementNotPresent(PAID_COL_SELECTOR_CSS)).shouldBeTrue("Claim list PAID column is visible");
        new Validation(seleniumCommands.isElementNotPresent(NET_INCURRED_COL_SELECTOR_CSS)).shouldBeTrue("Claim list NET INCURRED column is visible");
        new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
        new Validation(seleniumCommands.isElementPresent(LOB_SELECTED_CSS)).shouldBeTrue("LOB dropdown is not displayed");
        new Validation(seleniumCommands.isElementPresent(CLOSE_CLAIM_LABEL_SELECT_CSS)).shouldBeTrue("Closed claim chkbox is not displayed");

        return new Validation(true);
    }
}
