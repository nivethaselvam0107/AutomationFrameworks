package com.guidewire.capabilities.claims.model.page;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.claims.model.component.ClaimListPage;
import com.guidewire.common.testNG.Validation;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AMP_ClaimListPage extends ClaimListPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[class*='gw-header-nav'] a[href='#/billing-summary/']")
    WebElement BILLING_SUMMARY_LINK;

    public AccountSummaryPage goToBillingPage() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.click(BILLING_SUMMARY_LINK);
        return new AccountSummaryPage();
    }

    @Override
    public Validation isClaimListPageLoaded() {
        logger.info("Validating claim list columns on AMP");
        new Validation(seleniumCommands.isElementNotPresent(PAID_COL_SELECTOR_CSS)).shouldBeTrue("Claim list PAID column is visible");
        new Validation(seleniumCommands.isElementNotPresent(NET_INCURRED_COL_SELECTOR_CSS)).shouldBeTrue("Claim list NET INCURRED column is visible");
        super.isClaimListPageLoaded();
        return new Validation(true);
    }
}
