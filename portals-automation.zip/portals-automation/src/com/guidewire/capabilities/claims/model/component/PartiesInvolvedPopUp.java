package com.guidewire.capabilities.claims.model.component;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.List;

public class PartiesInvolvedPopUp {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    By NAME = By.cssSelector("[class*='gw-heading']");

    By ADDRESS = By.cssSelector("[class='gw-controls gw-multiline ng-binding']");

    By PARIES_INVOLVED_DATA = By.cssSelector("[class='gw-modal-body gw-contact-info-dialog ng-scope'] [class='gw-controls ng-binding']");

    public Validation isPartiesInvolvedDetailsDataMatchingWithBackEnd(String claimNum) {
        logger.info("Validating if Vehicle Driver data is matching backend");
        HashMap<String, String> backEndData = ParseClaimData.getPartiesInvolvedDataFromBackEnd(DataFetch.getAgentClaimData(claimNum));

        List<WebElement> content=seleniumCommands.findElements(PARIES_INVOLVED_DATA);
        new Validation(seleniumCommands.getTextAtLocator(NAME), backEndData.get(ClaimData.PARTIES_INVOLVED_DISPLAY_NAME.getValue())).shouldBeEqual("Parties Involved name is not correct");
        new Validation(content.get(2).getText().contains(backEndData.get(ClaimData.PARTIES_INVOLVED_PHONE.getValue()))).shouldBeTrue("Parties Involved phone is not correct");
        new Validation(content.get(3).getText(), backEndData.get(ClaimData.PARTIES_INVOLVED_EMAIL.getValue())).shouldBeEqual("Parties Involved email is not correct");
        if(!System.getProperty("platform").equalsIgnoreCase("diamond"))
            new Validation(seleniumCommands.getTextAtLocator(ADDRESS).replace(",", "").replace("\n"," "), backEndData.get(ClaimData.PARTIES_INVOLVED_DISPLAY_ADDRESS.getValue())).shouldBeEqual("Parties Involved address is not correct");
        return new Validation(true);
    }

}
