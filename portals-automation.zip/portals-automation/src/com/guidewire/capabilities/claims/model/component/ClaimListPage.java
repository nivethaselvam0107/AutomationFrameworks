package com.guidewire.capabilities.claims.model.component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.guidewire.widgetcomponents.table.Table;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.capabilities.claims.data.ClaimListColumn;
import com.guidewire.capabilities.common.data.SortType;
import com.guidewire.capabilities.common.interfaces.IPaginationPage;
import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseClaimData;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import com.guidewire.portals.claimportal.pages.NewClaimVehicleDriverPage;
import com.guidewire.portals.claimportal.pages.NewGeneralClaimDetails;
import com.guidewire.portals.claimportal.pages.PolicyDetailPage;
import com.guidewire.portals.claimportal.pages.PropertyDetailsPage;
import com.guidewire.portals.claimportal.subpages.VendorDetailsPopUp;

public abstract class ClaimListPage
        extends CommonScenario
        implements IPaginationPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[class*='gw-header-nav'] a")
    protected WebElement HOME_BTN_CSS;

    @FindBy(css = "[model='tableConfig.claimQuery'] input[ng-keypress], [ng-model='tableConfig.search'], [ng-model='_model.value']")
    protected WebElement SEARCH_TXT_CSS;

    @FindBy(css = "[class*='gw-filter-button-div gw-open'] li [class*='tick-icon-visibile'], [id='LOBSelect']")
    protected WebElement LOB_SELECTED_CSS;
    
    @FindBy(css = "[class*='filter'] button")
    protected WebElement LOB_FILTER_BTN_CSS;
    
    @FindBy(css = "[class*='gw-filter-button-div gw-open'] button, i[class='gw-btn-caret fa fa-sort-desc ng-scope']")
    protected WebElement LOB_EXPANDED_BTN_CSS;

    @FindBy(xpath = "//li//input/following-sibling::label")
    protected WebElement CLOSE_CLAIM_LABEL_SELECT_CSS;

    @FindBy(css = "[class='gw-claimsTable gw-table ng-scope'], [list='getFilteredClaimSummaries()'], [list='pageListData.items']")
    protected WebElement CLAIM_LIST_SELECT_CSS;

    @FindBy(css = "div[class='gw-vertical-align-item gw-show-for-phone-landscape-up ng-scope']")
    WebElement ADD_POLICY_BTN_CSS;

    @FindBy(id = "createNoteButton")
    WebElement ADD_NOTE_BTN_ID;

    @FindBy(css = "a[href='#/fnol']")
    protected WebElement FILE_CLAIM_BTN_XPATH;
    
    @FindBy(css = "table[class='gw-claimsTable gw-table ng-scope'] tbody tr")
    WebElement CLAIM_TABLE_ROW_CSS;

    private static final By CLAIM_SEARCH_RESULT_CSS = By.cssSelector("table[class*='gw-table ng-scope'] tbody tr, [list='pageListData.items'], [ng-hide*='failToGetClaims'][aria-hidden='false']");

    private static final By CLAIM_TABLE_ROWS_CSS = By.cssSelector("table[list='paginatedClaims'] tbody tr, table[list='pageListData.items'] tbody tr");

    private static final By CLAIM_TABLE_HIDDEN_CSS = By.cssSelector("[ng-hide][aria-hidden='true'] table[list='paginatedClaims']");
    
    @FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr/td[@attribute='normalizedLobCode']/img")
    List<WebElement> CLAIM_LIST_LOB_XPATH;

    private static final By LOB_OPTIONS_CSS = By.cssSelector("[class*='gw-filter-button-div gw-open'] li[ng-repeat]");
    
    private static final By CLAIM_LIST_PAID_CSS = By.cssSelector("td[attribute='totalPayments.amount']");
    private static final By CLAIM_LIST_TOTAL_INCURRED_CSS = By.cssSelector("td[attribute='totalIncurredNet.amount']");
    
    protected static final By NO_CLAIM_LISTED_CSS = By.cssSelector("[class*='claim-results'][aria-hidden='false'] h4");

    @FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[1]/td[@attribute='claimState']")
    WebElement CLAIM_STATUS_ROW_1_CSS;

    @FindBy(xpath = "//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[4]/td[@attribute='claimState']")
    WebElement CLAIM_STATUS_OF_CLOSED_CLAIM;

    @FindBy(xpath = "//th[text()='Line']")
    WebElement LINE_COL_XPATH;

    @FindBy(css = "th[attribute='claimNumber'], th[ng-click*='claimNumber']")
    protected WebElement CLAIMNUM_COL_CSS;

    By CLAIMNUM_CSS = By.cssSelector("td[attribute='claimNumber'], td[ng-click*='claimNumber']");

    By CLAIMPOLICY_CSS = By.cssSelector("td[attribute='policyNumber'], td[ng-click*='policyNumber']");

    @FindBy(css = "th[attribute='lossDate'], th[ng-click*='lossDate']")
    protected WebElement DOL_COL_CSS;

    @FindBy(css = "th[attribute='status'], th[ng-click*='claimState']")
    protected WebElement STATUS_COL_CSS;

    private final By CLAIM_STATUS_CSS = By.cssSelector("td[title='Status']");

    @FindBy(xpath = "//th[text()='Vendor(s)']")
    WebElement VENDOR_COL_XPATH;

    @FindBy(xpath = "//th[contains(text(),'Policy')]")
    WebElement POLICY_COL_XPATH;

    @FindBy(css = "th[ng-click*='totalPayments']")
    protected WebElement PAID_COL_CSS;

    protected By PAID_COL_SELECTOR_CSS = By.cssSelector("th[ng-click*='totalPayments']");

    @FindBy(css = "th[ng-click*='totalIncurredNet']")
    protected WebElement NET_INCURRED_COL_CSS;

    protected By NET_INCURRED_COL_SELECTOR_CSS = By.cssSelector("th[ng-click*='totalIncurredNet']");

    @FindBy(css = "[ng-if*='auth'] .gw-icon-caret.fa.fa-caret-down")
    WebElement LOGOUT_ARRORW_CSS;

    @FindBy(css = "[ng-click='$ctrl.logout()']")
    WebElement LOGOUT_BUTTON_CSS;

    @FindBy(css = "[ui-sref='accounts.detail.claims']")
    WebElement CLAIM_TILE;

    By SORT_ICON_CSS = By.cssSelector("i[ng-class*='getSortIcon']");
    
    By LOGOUT_EXPAND_BTN_CSS = By.cssSelector("[class*='open'] .gw-icon-caret.fa.fa-caret-down");
    
    By CLAIM_XPATH = By.xpath("//a[text()='" + data.get("ClaimSearchValue") + "']");
    
    By CLOSED_CLAIM_CKBOX_CSS = By.cssSelector("label[for='closedClaimsFilter']");

    By CLAIM_NUMBER_LINK = By.xpath("//td[@attribute='claimNumber']/a");

    static final String LOADER_IMAGE_CSS = "[src='../styles/images/common/ajax-loader.gif']";

    List<String> LOB_DROPDOWN_LIST = Arrays.asList("All Claims", "Businessowners", "Commercial Auto", "Commercial Property", "General Liability", "Homeowners", "Inland Marine", "Personal Auto", "Workers' Compensation");

    @FindBy(css = "table thead th:not([aria-hidden='true'])")
    List<WebElement> CLAIM_LIST_HEADER_CSS;

    public ClaimListPage() {
        super();
        seleniumCommands.waitTillPageIsLoaded();
    }

    public NewClaimDOLPage fileAClaim() {
        if (suiteName == SuiteName.CPPH) {
        	//TODO: Disabling as handler is not working
            //DataFetch.getFNOLPolicyList(data.get("USER"));
        }
        seleniumCommands.clickbyJS(FILE_CLAIM_BTN_XPATH);
        return new NewClaimDOLPage();
    }

    public Validation validateFileAClaimButton(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Validation(seleniumCommands.isElementPresent( FILE_CLAIM_BTN_XPATH));
    }

    public ClaimListPage clickIncludeClaimsClosedCheckBox() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
//        seleniumCommands.click(LOB_EXPANDED_BTN_CSS);
//        seleniumCommands.waitRefreshWithAction(
//                CLAIM_SEARCH_RESULT_CSS,
//                CLOSE_CLAIM_LABEL_SELECT_CSS,
//                seleniumCommands::click
//        );
    	expandLOBFilter();
    	seleniumCommands.waitForElementToBeVisible(CLOSED_CLAIM_CKBOX_CSS);
    	seleniumCommands.click(CLOSED_CLAIM_CKBOX_CSS);
    	collapseLOBFilter();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public ClaimListPage goToClaimTile() {
        new Tiles().selectByTitle("Claims");
        return this;
    }

    public ClaimListPage goToHome() {
        seleniumCommands.clickbyJS(HOME_BTN_CSS);
        seleniumCommands.waitForElementToBeVisible(CLAIM_TABLE_ROW_CSS);
        return this;
    }

    public ClaimSummaryPage openClaimSummary(String claim) {
        searchClaim(claim);
        seleniumCommands.clickbyJS(By.linkText(claim));
        return new ClaimSummaryPage();
    }

    public ClaimSummaryPage openClaimSummary() {
    		By CLAIM_XPATH = By.xpath("//a[text()='" + data.get("ClaimSearchValue") + "']");
    		seleniumCommands.waitForElementToBeVisible(CLAIM_XPATH);
        seleniumCommands.clickbyJS(CLAIM_XPATH);
        return new ClaimSummaryPage();
    }

    public PolicyDetailPage openPolicyDetailsPage() {
        filterClaimByTextSearch();
        seleniumCommands.waitForElementToBeVisible(CLAIM_XPATH);
		seleniumCommands.clickbyJS(By.xpath("//a[text()='" + data.get("POLICY_NUM") + "']"));
        return new PolicyDetailPage();
    }

    public Object openPADraftClaim(String draftNum) {
        seleniumCommands.clickbyJS(By.linkText(draftNum));

        if (data.get("ClaimSubType").equalsIgnoreCase("Theft")) {
            return new NewClaimLocationPage();
        } else {
            return new NewClaimVehicleDriverPage();
        }
    }

    public PropertyDetailsPage openCPDraftClaim(String draftNum) {
        seleniumCommands.clickbyJS(By.linkText(draftNum));
        return new PropertyDetailsPage();
    }

    public NewGeneralClaimDetails openClaimDetailsPage(String claim) {
        this.searchClaim(claim);
        Table claimResultTable  = new Table(CLAIM_LIST_SELECT_CSS);
        seleniumCommands.click(claimResultTable.getRowByIndex(0).getCellByColumnTitle("CLAIM NUMBER").getElement());
        return new NewGeneralClaimDetails();
    }

    public NewClaimDOLPage searchClaim(String value) {
        // static wait for search script/input init
        try {Thread.sleep(3000);} catch (Exception e) {}
        seleniumCommands.waitForElementToBeEnabled(SEARCH_TXT_CSS);
        seleniumCommands.waitForElementToBeVisible(CLAIM_SEARCH_RESULT_CSS);
        seleniumCommands.waitRefreshWithAction(
                CLAIM_SEARCH_RESULT_CSS,
                SEARCH_TXT_CSS,
                value,
                seleniumCommands::type
        );
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(2);
        return new NewClaimDOLPage();
    }

    public ClaimListPage searchClaim() {
        return this.filterClaimByTextSearch(data.get("ClaimSearchValue"));
    }

    public ClaimListPage filterClaimByTextSearch() {
        return this.filterClaimByTextSearch(data.get("ClaimSearchValue"));
    }

    public ClaimListPage filterClaimByTextSearch(String searchValue) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeVisible(CLAIM_SEARCH_RESULT_CSS);
	    SEARCH_TXT_CSS.click();
        seleniumCommands.type(SEARCH_TXT_CSS, searchValue);
        //seleniumCommands.type(SEARCH_TXT_CSS, searchValue);
//        seleniumCommands.waitRefreshWithAction(
//                CLAIM_SEARCH_RESULT_CSS,
//                SEARCH_TXT_CSS,
//                searchValue,
//                seleniumCommands::type
//        );
        return this;
    }

    public ClaimListPage clearTextSearch() {
        return this.filterClaimByTextSearch("");
    }

    public ClaimListPage selectLOB() {
    	expandLOBFilter();
    	seleniumCommands.waitForElementToBeVisible(CLOSED_CLAIM_CKBOX_CSS);
    	WebElement option = seleniumCommands.findElements(LOB_OPTIONS_CSS).stream().filter(subjectElement -> seleniumCommands.getTextAtLocator(subjectElement).equals(data.get("ClaimSearchValue"))).findFirst().get();
        seleniumCommands.click(option);
        //collapseLOBFilter();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public List<String> getOpenClaimIds() {
        return getOpenClaimValues(CLAIMNUM_CSS);
    }

    public List<String> getOpenClaimPolicyIds() {
        return getOpenClaimValues(CLAIMPOLICY_CSS);
    }

    private List<String> getOpenClaimValues(By selector) {
        logger.info("Getting open claim ids");
        List<String> result = new ArrayList<>();
        seleniumCommands.waitForElementListHaveMoreValuesThan(CLAIM_SEARCH_RESULT_CSS, 0);
        seleniumCommands.waitForElementToBeClickable(CLAIM_SEARCH_RESULT_CSS);
        boolean isThereNextPage = true;
        seleniumCommands.waitForLoaderToDisappearFromPage();
        while(isThereNextPage) {
            seleniumCommands.findElements(CLAIM_SEARCH_RESULT_CSS).forEach(el -> {
                if (seleniumCommands.findElement(el, CLAIM_STATUS_CSS).getText().equals("Open")) {
                    result.add(seleniumCommands.getTextAtLocator(seleniumCommands.findElement(el, selector)));
                }
            });

            if (nextButtonEnabled()) {
                nextPage();
            } else {
                isThereNextPage = false;
            }
        }

        if (result.size() == 0) {
            logger.warn("NO OPEN Claims in the portal, check data." + "\n" + seleniumCommands.findElements(CLAIM_SEARCH_RESULT_CSS).size());
        }
        return result;
    }

    public boolean checkIfClaimIsListedInSearchResult(String value) {
        return seleniumCommands.getElements(CLAIMNUM_CSS)
                .stream()
                .filter(el -> el.getText().replace(" ","").equals(value))
                .findFirst()
                .isPresent();
    }

    public int countClaimsOnPage() {
        return  seleniumCommands.getElements(CLAIMNUM_CSS).size();
    }

    public String getFirstClaimNumberFromList() {
        return seleniumCommands.getTextAtLocator(CLAIMNUM_CSS);
    }

    public ClaimListPage claimInSearchResultValidation(String claimNumber) {
        new Validation(
                checkIfClaimIsListedInSearchResult(claimNumber)
        ).shouldBeTrue("Claim number not in list");
        return this;
    }

    public boolean checkIfClaimIsFilteredAsPerSearchText(String ColumnName, String value) {
    	seleniumCommands.staticWait(2);
        seleniumCommands.waitForElementToBePresent(CLAIM_TABLE_ROWS_CSS);

        boolean flag = false;
        int row = ThreadLocalObject.getDriver().findElements(CLAIM_TABLE_ROWS_CSS).size();

        if (ColumnName.equals("ExactClaimNumber")) {
            for (int i = 1; i <= row; i++) {
                if (seleniumCommands
                        .getTextAtLocator(
                                By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[" + i + "]/td[@attribute='claimNumber']")
                        ).equals(value)) {
                    flag = true;
                }
            }
            return flag;
        } else if (ColumnName.equals("PartialClaimNumber")) {
            for (int i = 1; i <= row; i++) {
                if (!seleniumCommands
                        .getTextAtLocator(
                                By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[" + i + "]/td[@attribute='claimNumber']")
                        ).contains(value)) {
                    return false;
                }
            }
            return true;
        } else if (ColumnName.equals("Policy")) {
            for (int i = 1; i <= row; i++) {
                if (!seleniumCommands
                        .getTextAtLocator(
                                By.xpath("//table[@class='gw-claimsTable gw-table ng-scope']/tbody//tr[" + i + "]/td[@title='Policy']/a")
                        ).contains(value)) {
                    return false;
                }
            }
            return true;
        } else if (ColumnName.equals("ClaimStatus")) {
            for (String resultValue : this.getStatusColumnData()) {
                if (!resultValue.equals(value)) {
                    return false;
                }
            }
            return true;
        } else if (ColumnName.equals("LOB")) {
            flag = this.validateLOBOptionSelection(value);
        }

        return flag;
    }

    // Function passes through all the claims in the list, finds the first status that is "Closed" and than exits
    public Validation findIfStatusIsPresented(String value) {
        seleniumCommands.staticWait(2);
        if (this.getStatusColumnData().contains(value)) {
            return new Validation(true);
        } else {
            return new Validation(false);
        }
    }


    public boolean checkIfClaimIsNotFilteredAsPerSearchText(String ColumnName, String value) {
    	seleniumCommands.click(By.cssSelector(".gw-claim-summary_header-row"));
    	seleniumCommands.waitForElementToBePresent(CLAIM_TABLE_HIDDEN_CSS);
        int row = ThreadLocalObject.getDriver().findElements(CLAIM_TABLE_ROWS_CSS).size();

        if (ColumnName.equals("DateOfLoss")) {
            if (row == 0) {
                return true;
            }
        } else if (ColumnName.equals("Vendor")) {
            if (row == 0) {
                return true;
            }
        } else if (ColumnName.equals("Policy")) {
            if (row == 0) {
                return true;
            }
        }
        return false;
    }
    
    private void expandLOBFilter() {
    	seleniumCommands.click(LOB_FILTER_BTN_CSS);
    	seleniumCommands.waitForElementToBeVisible(LOB_EXPANDED_BTN_CSS);
    }
    
    private void collapseLOBFilter() {
    	seleniumCommands.clickbyJS(LOB_EXPANDED_BTN_CSS);
    	seleniumCommands.waitForElementToBeVisible(LOB_FILTER_BTN_CSS);
    }

    //Get Method

    public String getClaimStatus(String claimNum) {
        searchClaim(claimNum);
        return seleniumCommands.getTextAtLocator(CLAIM_STATUS_ROW_1_CSS);
    }


    // Validate a Claim
    public Validation validateClaimListing(String claimNum) {
        searchClaim(claimNum);
        boolean result = checkIfClaimIsListedInSearchResult(claimNum);
        seleniumCommands.type(SEARCH_TXT_CSS, " ");
        return new Validation(result);
    }

    public Validation validateClaimDraftStatus(String claimNum) {
        System.out.println(ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)).get("CLAIM_STATE"));
        new Validation(ParseClaimData.getClaimDetailsDataFromBackEnd(DataFetch.getClaimData(claimNum)).get("CLAIM_STATE"), "draft").shouldBeEqual("Claim is not saved as Draft in backend");
        new Validation(getClaimStatus(claimNum), "Draft").shouldBeEqual("Claim is not saved as Draft On Claim List");
        return new Validation(1, 1);
    }

    public Validation validateClaimOpenStatus(String claimNum) {
        return new Validation(getClaimStatus(claimNum), "Open");
    }

    public Validation validateClaimClosedStatus(String claimNum) {
        return new Validation(getClaimStatus(claimNum), "Closed");
    }

    public Validation validateClaimClosedStatusInList() {
        return new Validation(checkIfClaimIsFilteredAsPerSearchText("ClaimStatus", "Closed"));
    }

    public Validation areVendorDetailsOnPopUpCorrect() throws Exception {
        return new VendorDetailsPopUp().openAndValidateVendorPopDetails();
    }
    

    public Validation validateLOBDropDown() {
    	expandLOBFilter();
    	seleniumCommands.waitForElementToBeVisible(LOB_OPTIONS_CSS);
        new Validation(seleniumCommands.getTextAtLocator(LOB_SELECTED_CSS.findElement(By.xpath("./following-sibling::label"))), "All Claims").shouldBeEqual("LOD default option is not correct.");
        List<String> lobOptions = new ArrayList<>();
        seleniumCommands.findElements(LOB_OPTIONS_CSS).forEach( element -> lobOptions.add(element.getText()));
        new Validation(lobOptions, LOB_DROPDOWN_LIST).shouldBeEqual("LOB options are not listed correctly");
        return new Validation(true);
    }

    public Validation validateClaimNumberFormat(String claimNum) throws Exception {
        String[] claim = claimNum.split("-");
        new Validation(claim.length, 3).shouldBeEqual("Claim num " + claimNum + " format is not correct ");
        new Validation(claim[0].length(), 3).shouldBeEqual("Claim num " + claimNum + " first half is not having 3 digit " + claim[0]);
        new Validation(claim[1].length(), 2).shouldBeEqual("Claim num " + claimNum + " second half is not having 3 digit " + claim[1]);
        new Validation(claim[2].length(), 6).shouldBeEqual("Claim num " + claimNum + " third half is not having 3 digit " + claim[2]);
        return new Validation(true);
    }

    public Validation validateDraftClaimNumberFormat(String claimNum) throws Exception {
        String claimPrefix = claimNum.substring(0, 9);
        String draftNum = claimNum.substring(10);
        new Validation(claimPrefix, "999-99-99").shouldBeEqual("Claim prfix " + claimPrefix + " format is not correct ");
        new Validation(draftNum.length(), 3).shouldBeEqual("Claim draft num " + draftNum + " format is not correct ");
        return new Validation(true);
    }

    private boolean validateLOBOptionSelection(String option) {

//        seleniumCommands.waitRefreshWithAction(
//                CLAIM_SEARCH_RESULT_CSS,
//                LOB_SELECTED_CSS,
//                option,
//                seleniumCommands::selectDropDownValueByText
//        );

        List<String> expectedOptions = new ArrayList<>();
        if (option.equals(LOB_DROPDOWN_LIST.get(0))) {
            for (int i = 1; i < LOB_DROPDOWN_LIST.size(); i++) {
                expectedOptions.add(LOB_DROPDOWN_LIST.get(i).toLowerCase().replace(" ", "").replace("'", ""));
            }
        } else {
            expectedOptions.add(option.toLowerCase().replace(" ", "").replace("'", ""));
        }

        for (WebElement el : CLAIM_LIST_LOB_XPATH) {
            logger.info("ELEMENT ICON TITLE:  " + seleniumCommands.getAttributeValueAtLocator(el, "title"));
            String title = seleniumCommands.getAttributeValueAtLocator(el, "title").replace("-", "");
            if (!expectedOptions.stream().anyMatch(expected -> expected.contains(title))) {
                return false;
            }
        }

        return true;
    }

    private void sort(WebElement sortingHeader, SortType sortOrder) {
        WebElement sortingIndicator = seleniumCommands.findElement(sortingHeader, SORT_ICON_CSS);
        String expectedSortingClassValue = "";
        String actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");

        switch (sortOrder) {
            case ASC:
                expectedSortingClassValue = "up";
                break;
            case DESC:
                expectedSortingClassValue = "down";
                break;
            default:
                logger.error(String.format("Unsupported sorting type [%s]", sortOrder));
        }

        if (actualSortingClassValue.toLowerCase().contains("minus")) {
            seleniumCommands.click(sortingHeader);
            actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");
        }

        if (!actualSortingClassValue.contains(expectedSortingClassValue)) {
            seleniumCommands.click(sortingHeader);
        }

        actualSortingClassValue = seleniumCommands.getAttributeValueAtLocator(sortingIndicator, "class");
        if (actualSortingClassValue.contains(expectedSortingClassValue)) {
            logger.info(String.format("Sorting [%s] done successfully", sortOrder));
        } else {
            logger.error(String.format("Sorting [%s] FAILED", sortOrder));
        }
    }

    public List<String> getStatusColumnData() {
        return this.getColumnData(CLAIM_STATUS_CSS);
    }

    private List<String> getColumnData(final By columnDataCollectionSelector) {
        List<String> colDataList = new ArrayList<>();
        boolean isNextPage = true;
        seleniumCommands.waitForLoaderToDisappearFromPage();
        while(isNextPage) {
            seleniumCommands.findElements(columnDataCollectionSelector).forEach(el ->
                    colDataList.add(seleniumCommands.getTextAtLocator(el).trim())
            );

            if (nextButtonEnabled()) {
                nextPage();
            } else {
                isNextPage = false;
            }
        }

        return colDataList;
    }
    
    private List<String> getColumnDataSinglePage(final By columnDataCollectionSelector) {
        List<String> colDataList = new ArrayList<>();
            seleniumCommands.findElements(columnDataCollectionSelector).forEach(el ->
                    colDataList.add(seleniumCommands.getTextAtLocator(el).trim()));
        return colDataList;
    }

    private Validation validateClaimListIsSorted(ClaimListColumn column, SortType sortOrder) {
        List<String> colDataList = new ArrayList<>();
        List<String> actualList = new ArrayList<>();
        List<String> expectedList = new ArrayList<>();
        By uiDataList = null;
        WebElement colNameHeader = null;

        logger.info("Sorting COL[" + column + "]");
        switch (column) {
            case PAID:
                uiDataList = CLAIM_LIST_PAID_CSS;
                colNameHeader = PAID_COL_CSS;
                break;
            case NET_INCURRED:
                uiDataList = CLAIM_LIST_TOTAL_INCURRED_CSS;
                colNameHeader = NET_INCURRED_COL_CSS;
                break;
            default:
                logger.error(String.format("Unsupported COL[%s]", column));
        }

        //add expected list
        colDataList.addAll(getColumnDataSinglePage(uiDataList));
        Collections.sort(colDataList);

        if (sortOrder.equals(SortType.DESC)) {
            Collections.reverse(colDataList);
        }

        expectedList.addAll(colDataList);

        //add actual list after sorting
        sort(colNameHeader, sortOrder);
        colDataList.clear();
        colDataList.addAll(getColumnDataSinglePage(uiDataList));
        actualList.addAll(colDataList);

        for (int i = 0; i < expectedList.size(); i++) {
            if (!expectedList.get(i).equals(actualList.get(i))) {
                logger.error(String.format("Sorting test[%s] for COL[%s] FAILED: ", sortOrder, column));
                logger.error(String.format("\t EXPECTED VALUE[%s],COL[%s]", expectedList.get(i), column));
                logger.error(String.format("\t ACTUAL VALUE[%s],COL[%s]", actualList.get(i), column));
                return new Validation(false);
            }
        }

        logger.info(String.format("Sorting test[%s] for COL[%s] SUCCESSFUL", sortOrder, column));
        return new Validation(true);
    }

    public Validation validateClaimListPaidColIsSortedAsc() {
        return validateClaimListIsSorted(ClaimListColumn.PAID, SortType.ASC);
    }

    public Validation validateClaimListPaidColIsSortedDesc() {
        return validateClaimListIsSorted(ClaimListColumn.PAID, SortType.DESC);
    }

    public Validation validateClaimListNetIncurredColIsSortedAsc() {
        return validateClaimListIsSorted(ClaimListColumn.NET_INCURRED, SortType.ASC);
    }

    public Validation validateClaimListNetIncurredColIsSortedDesc() {
        return validateClaimListIsSorted(ClaimListColumn.NET_INCURRED, SortType.DESC);
    }

    public Validation validateClaimListIsFiltered(String column) {
        return new Validation(checkIfClaimIsFilteredAsPerSearchText(column, data.get("ClaimSearchValue")));
    }

    public Validation validateClaimListIsFiltered(String column, String claimNum) {
        return new Validation(checkIfClaimIsFilteredAsPerSearchText(column, claimNum));
    }

    public Validation validateClaimListIsNotFiltered(String column) {
        seleniumCommands.staticWait(2);
        return new Validation(checkIfClaimIsNotFilteredAsPerSearchText(column, data.get("ClaimSearchValue")));
    }

    public Validation isClaimListPageLoaded() {
        if(!ThreadLocalObject.getData().containsKey("CreateUser")) {
	        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
	        new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_XPATH)).shouldBeTrue("File a Claim button not visible");
	        new Validation(seleniumCommands.isElementPresent(CLAIM_LIST_SELECT_CSS)).shouldBeTrue("Claim table is not displayed");
	        new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
	        expandLOBFilter();
	        new Validation(seleniumCommands.isElementPresent(LOB_FILTER_BTN_CSS)).shouldBeTrue("LOB dropdown is not displayed");
	        new Validation(seleniumCommands.isElementPresent(CLOSE_CLAIM_LABEL_SELECT_CSS)).shouldBeTrue("Closed claim chkbox is not displayed");

	        if (BrowserType.phone.contains(browserType)) {
	            new Validation(getClaimListColumnsCount(), 6);
	        } else {
	            new Validation(seleniumCommands.isElementPresent(LINE_COL_XPATH)).shouldBeTrue("Claim List Line Column is not visible");
	            new Validation(seleniumCommands.isElementPresent(CLAIMNUM_COL_CSS)).shouldBeTrue("Claim List ClaimNum Column is not visible");
	            new Validation(seleniumCommands.isElementPresent(DOL_COL_CSS)).shouldBeTrue("Claim List Date of Loss Column is not visible");
	            new Validation(seleniumCommands.isElementPresent(STATUS_COL_CSS)).shouldBeTrue("Claim List Status Column is not visible");
	            new Validation(seleniumCommands.isElementPresent(VENDOR_COL_XPATH)).shouldBeTrue("Claim List Vendor Column is not visible");
	            new Validation(seleniumCommands.isElementPresent(POLICY_COL_XPATH)).shouldBeTrue("Claim List Policy Column is not visible");
	        	}
	        collapseLOBFilter();
        } else {
        		new Validation(seleniumCommands.getTextAtLocator(NO_CLAIM_LISTED_CSS), "There are no claims currently active").shouldBeEqual("Claim List Date of Loss Column is not visible");
        }
        seleniumCommands.click(LOGOUT_ARRORW_CSS);
        new Validation(seleniumCommands.isElementPresent(LOGOUT_BUTTON_CSS)).shouldBeTrue("Log Out button is not visible");
        return new Validation(true);
    }

    public Validation isSimpleClaimListPageLoaded() {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
        return new Validation(seleniumCommands.isElementPresent(CLAIM_LIST_SELECT_CSS));
    }

    public Validation isPolicyAddButtonPresent() {
        if (data.get("Suite").equalsIgnoreCase("CP-PolicyHolder")) {
            new Validation(
                    seleniumCommands.isElementPresent(ADD_POLICY_BTN_CSS)
            ).shouldBeTrue("Add policy button is not visible");
        }
        return new Validation(true);
    }

    public Validation validateVendorPopUpDetails() {
        return new VendorDetailsPopUp().openAndValidateVendorPopDetails();
    }

    public int getClaimListColumnsCount() {
        return CLAIM_LIST_HEADER_CSS.size();
    }

    public void isClaimListDataBackendCallsContainingFinancialData() {
        String claimListData = DataFetch.getClaimSummaries(Arrays.asList("open,draft,closed"));

        if (suiteName.equals(SuiteName.CPAGENT) || suiteName.equals(SuiteName.GPA)) {
            new Validation(claimListData.contains("totalIncurredNet")).shouldBeTrue("Financial data[totalIncurredNet] NOT present on backend call for claim list");
            new Validation(claimListData.contains("totalPayments")).shouldBeTrue("Financial data[totalPayments] NOT present on backend call for claim list");
        } else {
            new Validation(claimListData.contains("totalIncurredNet")).shouldBeFalse("Financial data[totalIncurredNet] IS present on backend call for claim list");
            new Validation(claimListData.contains("totalPayments")).shouldBeFalse("Financial data[totalPayments] IS present on backend call for claim list");
        }
    }

    @Override
    public IPaginationPage previousPage() {
        seleniumCommands.waitForElementToBeClickable(PREVIOUS_BUTTON);
        seleniumCommands.waitRefreshWithAction(
                CLAIM_SEARCH_RESULT_CSS,
                PREVIOUS_BUTTON,
                seleniumCommands::clickbyJS
        );
        return this;
    }
    @Override
    public IPaginationPage nextPage() {
        seleniumCommands.waitForElementToBeClickable(NEXT_BUTTON);
        seleniumCommands.waitRefreshWithAction(
                CLAIM_SEARCH_RESULT_CSS,
                NEXT_BUTTON,
                seleniumCommands::clickbyJS
        );
        return this;
    }

    @Override
    public boolean previousButtonEnabled() {
        return seleniumCommands
                .findElement(PREVIOUS_BUTTON)
                .getAttribute("disabled") == null;
    }
    @Override
    public boolean nextButtonEnabled() {
        return seleniumCommands
                .findElement(NEXT_BUTTON)
                .getAttribute("disabled") == null;
    }
}
