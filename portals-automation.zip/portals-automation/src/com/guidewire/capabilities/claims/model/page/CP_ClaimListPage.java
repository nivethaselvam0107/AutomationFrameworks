package com.guidewire.capabilities.claims.model.page;

import com.guidewire.capabilities.claims.model.component.ClaimListPage;
import com.guidewire.common.testNG.SuiteName;
import com.guidewire.common.testNG.Validation;
import org.apache.log4j.Logger;

public class CP_ClaimListPage extends ClaimListPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @Override
    public Validation isClaimListPageLoaded() {
        logger.info("Validating claim list columns on CP");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(seleniumCommands.isElementPresent(NO_CLAIM_LISTED_CSS)) {
	        if(suiteName.equals(SuiteName.CPAGENT)) {
	            new Validation(seleniumCommands.isElementPresent(PAID_COL_SELECTOR_CSS)).shouldBeTrue("Claim list PAID column NOT visible");
	            new Validation(seleniumCommands.isElementPresent(NET_INCURRED_COL_SELECTOR_CSS)).shouldBeTrue("Claim list NET INCURRED column NOT visible");
	        }
	        else {
	            new Validation(seleniumCommands.isElementNotPresent(PAID_COL_SELECTOR_CSS)).shouldBeTrue("Claim list PAID column is visible");
	            new Validation(seleniumCommands.isElementNotPresent(NET_INCURRED_COL_SELECTOR_CSS)).shouldBeTrue("Claim list NET INCURRED column is visible");
	        }
        }
        super.isClaimListPageLoaded();
        return new Validation(true);
    }
}
