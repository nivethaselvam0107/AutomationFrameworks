package com.guidewire.capabilities.claims.model.page;

import com.guidewire.capabilities.claims.model.component.ClaimListPage;
import com.guidewire.common.testNG.Validation;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GPA_ClaimListPage extends ClaimListPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "th[attribute='product']")
    WebElement PRODUT_COL_CSS;

    @FindBy(css = "th[attribute='policyNumber']")
    WebElement POLICY_COL_CSS;

    @FindBy(css = "th[attribute='account'], th[ng-click*='account']")
    WebElement ACCOUNT_COL_CSS;

    @Deprecated
    public Validation validateContainsClaim(String claimNumber) {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
        boolean result = CLAIM_LIST_SELECT_CSS.findElements(By.xpath("tbody//a"))
                .stream()
                .filter(e -> e.getText().equals(claimNumber))
                .findAny()
                .isPresent();

        return new Validation(result);
    }

    @Override
    public Validation isClaimListPageLoaded() {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_SELECT_CSS);
        new Validation(seleniumCommands.isElementPresent(PAID_COL_SELECTOR_CSS)).shouldBeTrue("Claim list PAID column NOT visible");
        new Validation(seleniumCommands.isElementPresent(NET_INCURRED_COL_SELECTOR_CSS)).shouldBeTrue("Claim list NET INCURRED column NOT visible");
        new Validation(seleniumCommands.isElementPresent(CLAIMNUM_COL_CSS)).shouldBeTrue("Claim list CLAIM NUMBER column NOT visible");
        new Validation(seleniumCommands.isElementPresent(DOL_COL_CSS)).shouldBeTrue("Claim list DATE OF LOSS column NOT visible");
        new Validation(seleniumCommands.isElementPresent(STATUS_COL_CSS)).shouldBeTrue("Claim list STATUS column NOT visible");
        return new Validation(true);
    }

    public Validation isClaimListPageLoadedOnAccountClaim() {
        logger.info("Validating claim list columns on GPA->Account->Claims");
        //columns
        this.isClaimListPageLoaded();
        seleniumCommands.waitForElementToBeVisible(POLICY_COL_CSS);
        new Validation(seleniumCommands.isElementPresent(PRODUT_COL_CSS)).shouldBeTrue("Claim list PRODUCT column NOT visible");
        new Validation(seleniumCommands.isElementPresent(POLICY_COL_CSS)).shouldBeTrue("Claim list STATUS column NOT visible");
        new Validation(getClaimListColumnsCount(), 7).shouldBeEqual("Claim list number of columns is incorrect");
        //user interaction elements
        new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_XPATH)).shouldBeTrue("File a Claim button not visible");
        new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
        new Validation(seleniumCommands.isElementPresent(LOB_SELECTED_CSS)).shouldBeTrue("LOB dropdown is not displayed");
        return new Validation(true);
    }

    public Validation isClaimListPageLoadedOnClaims() {
        logger.info("Validating claim list columns on GPA->Claims");
        //columns
        this.isClaimListPageLoaded();
        new Validation(seleniumCommands.isElementPresent(PRODUT_COL_CSS)).shouldBeTrue("Claim list PRODUCT column NOT visible");
        new Validation(seleniumCommands.isElementPresent(POLICY_COL_CSS)).shouldBeTrue("Claim list STATUS column NOT visible");
        new Validation(seleniumCommands.isElementPresent(ACCOUNT_COL_CSS)).shouldBeTrue("Claim list ACCOUNT column NOT visible");
        new Validation(getClaimListColumnsCount(), 8).shouldBeEqual("Claim list number of columns is incorrect");
        return new Validation(true);
    }

    public Validation isClaimListPageLoadedOnPoliciesClaim() {
        logger.info("Validating claim list columns on GPA->Policy->Claims");
        //columns
        this.isClaimListPageLoaded();
        new Validation(getClaimListColumnsCount(), 5).shouldBeEqual("Claim list number of columns is incorrect");
        //user interaction elements
        new Validation(seleniumCommands.isElementPresent(FILE_CLAIM_BTN_XPATH)).shouldBeTrue("File a Claim button not visible");
        new Validation(seleniumCommands.isElementPresent(SEARCH_TXT_CSS)).shouldBeTrue("Search Text box is not displayed");
        return new Validation(true);
    }
}
