package com.guidewire.capabilities.claims.data;

import com.guidewire.common.util.EnumHelper;

public enum ClaimListColumn {

    LOB("lineOfBusiness"),
    CLAIM_NUMBER("claimNumber"),
    INSURED("insured"),
    DOL("dateOfLoss"),
    STATUS("status"),
    VENDOR("vendor"),
    PAID("paid"),
    NET_INCURRED("netIncurred"),
    POLICY("policy");

    private final String columnName;

    ClaimListColumn(final String columnName) {
        this.columnName = columnName;
    }

    @Override
    public String toString() {
        return this.columnName;
    }

    public static ClaimListColumn fromString(String name) {
        return EnumHelper.fromString(ClaimListColumn.class, name);
    }
}