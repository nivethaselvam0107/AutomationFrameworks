package com.guidewire.capabilities.claims.test.cp;

import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.common.model.page.SignUpEnrollmentPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

/**
 * Created by smcdonnell on 06/06/2017.
 */
public class CP_SignUpEnrollmentTest {

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA", "SIGN_UP", "ENROLLMENT" },
            description = "TC2004:EnrollmentAddingPolicyToNotEnrolledUser")
    public void testEnrollmentAfterSignUp(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton()
                .isSignUpSuccessful();
        PolicyGenerator.createBasicBoundPAPolicy();
        new SignUpEnrollmentPage()
                .setEnrollmentData()
                .clickAddPolicy()
                .isEnrollmentSuccessful();
    }
}
