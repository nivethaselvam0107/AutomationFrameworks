package com.guidewire.capabilities.claims.test.cp;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;

public class CP_ClaimPolicySummaryTest {

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testClaimSummary(String browserName) throws Exception {
		new LoginPage().login();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		String claimNum = claimListPage.getOpenClaimIds().get(0);
		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.isClaimSummaryPageLoaded().shouldBeTrue("Claim summary page not loaded properly");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testClaimDetailsTabsPresence(String browserName) throws Exception {
		new LoginPage().login();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		String claimNum = claimListPage.getOpenClaimIds().get(0);

		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.validateClaimSummaryTabsPresence().shouldBeTrue("Claim summary tabs not present");
	}
}