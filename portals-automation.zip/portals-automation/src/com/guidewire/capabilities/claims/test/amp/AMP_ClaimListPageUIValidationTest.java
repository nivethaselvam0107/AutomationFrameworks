package com.guidewire.capabilities.claims.test.amp;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import com.guidewire.portals.claimportal.pages.NewClaimCrimeDetails;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;


public class AMP_ClaimListPageUIValidationTest {
	Pagefactory pagefactory = new Pagefactory();

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimListPageLoading(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();

		claimListPage.isClaimListPageLoaded().shouldBeTrue("Claim Page is not loaded");
		claimListPage.isPolicyAddButtonPresent().shouldBeTrue("Add policy Button is not present");
		claimListPage.validateLOBDropDown().shouldBeTrue("Search filter is not present or doesn't contains proper options.");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" })
	public void testClaimListPageShowingClaimsFromMultipleAccounts(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();

		Map<String, String> policiesToAccountMap =
			AuthorisationServer.getPoliciesForMultiAccountUser();

		// Get ids for all policies for which there is an open claim
		Set<String> policyIds = new HashSet<String>(claimListPage.getOpenClaimPolicyIds());

		// Check that claims from more than one account are shown
		Set<String> accountIds = new HashSet<>();
		policyIds.forEach(policyId -> accountIds.add(policiesToAccountMap.get(policyId)));

		Assert.assertTrue(accountIds.size() > 1, "Could not find claims from multiple accounts being displayed.");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testLOBDropDownOptions(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.validateLOBDropDown().shouldBeTrue("LOB drop down options are not listed correctly.");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testLOBPersonalAutoOptionSelection(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.selectLOB().validateClaimListIsFiltered("LOB").shouldBeTrue("LOB Personal Auto option selection does not filter correctly.");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite"})
	public void testHOLOBSelection(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.selectLOB().validateClaimListIsFiltered("LOB").shouldBeTrue("HO LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testGeneralLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundIMPolicy();

		NewClaimConfirmationPage claimConfirmationPage = pagefactory.createGeneralClaim().goToSummary().submitClaim();
		String claimNumber = claimConfirmationPage.getClaimNumber();

		AMP_ClaimListPage claimListPage = claimConfirmationPage.goToAccountSummaryPage().goToClaimsPage();
		claimListPage.filterClaimByTextSearch(claimNumber).validateClaimListIsFiltered("ExactClaimNumber", claimNumber).shouldBeTrue("Claim list is not filtered as per General(IM) ClaimNumber");
		claimListPage.clearTextSearch();
		claimListPage.validateClaimListIsFiltered("LOB").shouldBeTrue("General(IM) LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testWCLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		NewClaimConfirmationPage claimConfirmationPage = pagefactory.createWCClaim().goToSummary().submitClaim();
		String claimNumber = claimConfirmationPage.getClaimNumber();

		AMP_ClaimListPage claimListPage = claimConfirmationPage.goToAccountSummaryPage().goToClaimsPage();
		claimListPage.filterClaimByTextSearch(claimNumber).validateClaimListIsFiltered("ExactClaimNumber", claimNumber).shouldBeTrue("Claim list is not filtered as per Workers Comp ClaimNumber");
		claimListPage.clearTextSearch();
		claimListPage.validateClaimListIsFiltered("LOB").shouldBeTrue("Workers Comp LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testPAClaimSearchByExactText(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsFiltered("ExactClaimNumber").shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testPAClaimSearchByPartialText(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsFiltered("PartialClaimNumber").shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite"})
	public void testHOClaimSearchByExactText(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsFiltered("ExactClaimNumber").shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite"})
	public void testHOClaimSearchByPartialText(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsFiltered("PartialClaimNumber").shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimSearchByOpenClaimType(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsFiltered("ClaimStatus").shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}


	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimIsNotFilteredByPolicyNum(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsNotFiltered("Policy").shouldBeTrue("Claim list is filtered as per Policy Num");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimIsNotFilteredByDateOfLoss(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsNotFiltered("DateOfLoss").shouldBeTrue("Claim list is not filtered as per DateOfLoss");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimIsNotFilteredByVendorName(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateClaimListIsNotFiltered("Vendor").shouldBeTrue("Claim list is not filtered as per Vendor name");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testVendorPopUpDetails(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch().validateVendorPopUpDetails().shouldBeTrue("Vendor Pop Up details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClosedClaimsAreDisplayedOnClaimsPage(String browserName) throws Exception {
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.clickIncludeClaimsClosedCheckBox().findIfStatusIsPresented("Closed").shouldBeTrue("Claim status should be Closed");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" })
	public void testGoesBackToPreviousSelectionInClaimInformationWizard(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();

		NewClaimCrimeDetails claimCrimeDetails = claimListPage.fileAClaim()
				.selectPolicy().goNext()
				.selectHOClaimType()
				.goToCrimeDetailsPage()
				.setCrimeDetails().goNext()
				.withNewContactPerson().goNext()
				.selectContact("FirstNameNewPerson LastNameNewPerson")
				.withState()
				.withCity().goNext()
				.withContactHomeNum()
				.goToSummary()
				.clikDetailsInWizard();

		claimCrimeDetails.validateExistingCrimeDescription().shouldBeEqual("Details of crime were changed or missing");
	}

	@Parameters("browserName")
	@Test(groups = {"Emerald","Ferrite","Granite", "Diamond"})
	public void testPAClaimListPagination(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimType", "PersonalAuto");
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "San Francisco");
		data.put("State", "California");

		String claimOnFirstPage = null;
		String claimOnSecondPage = null;
		int maxClaimsPerPage = 25;

		for (int i = 0; i <= maxClaimsPerPage; i++) {
			NewClaimLocationPage page = pagefactory.getAccountSummaryPage()
					.goToMakeAClaim()
					.selectPolicy()
					.goNext()
					.selectPAClaimType()
					.goNext();

			if (i == 0) {
				claimOnFirstPage = page.getDraftClaimNumber();
			} else if (i == maxClaimsPerPage) {
				claimOnSecondPage = page.getDraftClaimNumber();
			}

			page.cancelWizardAMP();
		}

		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();

		claimListPage
				.nextPage();
		claimListPage
				.claimInSearchResultValidation(claimOnFirstPage);

		claimListPage
				.previousPage();
		claimListPage
				.claimInSearchResultValidation(claimOnSecondPage);
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimSearchByDraftClaimType(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimType", "PersonalAuto");
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "San Francisco");
		data.put("State", "California");
		data.put("ClaimSearchValue", "Draft");

		String claimOnFirstPage = null;
		String claimOnSecondPage = null;
		int maxClaimsPerPage = 25;

			NewClaimLocationPage page = pagefactory.getAccountSummaryPage()
					.goToMakeAClaim()
					.selectPolicy()
					.goNext()
					.selectPAClaimType()
					.goNext();
			String claimNumber = page.getDraftClaimNumber();
			page.cancelWizardAMP();
		AMP_ClaimListPage claimListPage = pagefactory.goToClaimListPage();
		claimListPage.filterClaimByTextSearch(claimNumber).validateClaimListIsFiltered("ClaimStatus").shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}
}
