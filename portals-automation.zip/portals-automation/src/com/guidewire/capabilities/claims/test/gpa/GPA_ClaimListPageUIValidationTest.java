package com.guidewire.capabilities.claims.test.gpa;

import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.HashMap;

public class GPA_ClaimListPageUIValidationTest {
	@Parameters("browserName")
	@Test(groups = {"Emerald","Ferrite","Granite", "Diamond"})
	public void testClaimListPageViewFromAccount(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		GPA_ClaimPagefactory pageFactory = new GPA_ClaimPagefactory();
		pageFactory.createTheftClaim().withContactCellNum().goToSummary().submitClaim().goToDashboard();
		pageFactory.openClaimViewFromAccount();

		GPA_ClaimListPage claimListPage = new GPA_ClaimListPage();
		claimListPage.isClaimListPageLoadedOnAccountClaim().shouldBeTrue("Claim Account->Claims Page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = {"Emerald","Ferrite","Granite", "Diamond"} , description = "TC3848, PAClaimOnPolicyDetailPage")
	public void testClaimListPageViewFromPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundIMPolicy();

		GPA_ClaimPagefactory pageFactory = new GPA_ClaimPagefactory();
		pageFactory.createGeneralClaim().goToDashboard();
		pageFactory.openClaimViewFromPolicy();

		GPA_ClaimListPage claimListPage = new GPA_ClaimListPage();
		claimListPage.isClaimListPageLoadedOnPoliciesClaim().shouldBeTrue("Claim Policy->Claims Page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3859:  ViewClaimDetailsFromLandingClaims")
	public void testClaimListPageViewFromClaims(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		GPA_ClaimPagefactory pageFactory = new GPA_ClaimPagefactory();
		pageFactory.openClaimView();

		GPA_ClaimListPage claimListPage = new GPA_ClaimListPage();

		claimListPage.isClaimListPageLoadedOnClaims().shouldBeTrue("Claims Page is not loaded");
	}

	@Parameters("browserName")
	@Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3864: PaginationOnClaimsLanding", enabled = false)
	public void testPAClaimListPagination(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimType", "PersonalAuto");
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "San Francisco");
		data.put("State", "California");

		String claimOnFirstPage = null;
		String claimOnSecondPage = null;
		int maxClaimsPerPage = 25;

		GPA_ClaimPagefactory pageFactory = new GPA_ClaimPagefactory();
		pageFactory.openClaimViewFromPolicy();

		for (int i = 0; i <= maxClaimsPerPage; i++) {
			ClaimsTileView claimsTileView = new ClaimsTileView();
			claimsTileView.waitForClaimButtonToAppearOnPage();
			NewClaimLocationPage page = claimsTileView
					.goToMakeAClaim()
					.goNext()
					.selectPAClaimType()
					.goNext();

			if (i == 0) {
				claimOnSecondPage = page.getDraftClaimNumber();
			} else if (i == maxClaimsPerPage) {
				claimOnFirstPage = page.getDraftClaimNumber();
			}

			page.cancelWizardGPA();
		}

		pageFactory.openDashBoard();
		pageFactory.openClaimView().showOpenClaims();
		GPA_ClaimListPage claimListPage = new GPA_ClaimListPage();

		claimListPage
				.nextPage();
		claimListPage
				.claimInSearchResultValidation(claimOnSecondPage);

		claimListPage
				.previousPage();
		claimListPage
				.claimInSearchResultValidation(claimOnFirstPage);
	}
}
