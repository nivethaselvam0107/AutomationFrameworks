package com.guidewire.capabilities.claims.test.gpa;

import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GPA_ClaimFilteringTest {

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testFilteringGeneralClaimsAssociatedWithPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createGeneralClaim();
        String claimNumber = confirmationPage.getClaimNumber();
        GPA_ClaimListPage claimListPage = confirmationPage.goToDashboard().goToPolicySummary(policyNum).goToClaims();

        claimListPage.isClaimListPageLoadedOnPoliciesClaim().shouldBeTrue("Claim Page is not loaded");

        claimListPage.filterClaimByTextSearch(claimNumber);
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim list is not filtered as per number for General FNOL");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testFilteringWCClaimsAssociatedWithPolicy(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundWCPolicy();

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createWCClaim();
        String claimNumber = confirmationPage.getClaimNumber();
        GPA_ClaimListPage claimListPage = confirmationPage.goToDashboard().goToPolicySummary(policyNum).goToClaims();

        claimListPage.isClaimListPageLoadedOnPoliciesClaim().shouldBeTrue("Claim Page is not loaded");

        claimListPage.filterClaimByTextSearch(claimNumber);
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim list is not filtered as per number for WC FNOL");
    }
}
