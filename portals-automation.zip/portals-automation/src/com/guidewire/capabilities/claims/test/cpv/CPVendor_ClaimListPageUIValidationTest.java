package com.guidewire.capabilities.claims.test.cpv;

import com.guidewire.capabilities.claims.model.page.CPVendor_ClaimListPage;
import com.guidewire.capabilities.vendor.model.page.Pagefactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CPVendor_ClaimListPageUIValidationTest {

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA"})
	public void testClaimListPageLoading(String browserName) throws Exception {
		CPVendor_ClaimListPage claimListPage = new Pagefactory().login().goToClaimsLanding();

		claimListPage.isClaimListPageLoaded().shouldBeTrue("Claim Page is not loaded");
		claimListPage.validateLOBDropDown().shouldBeTrue("Search filter is not present or doesn't contains proper options.");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR" })
	public void testClaimListBackendCallForFinancialData(String browserName) throws Exception {
		CPVendor_ClaimListPage claimListPage = new Pagefactory().login().goToClaimsLanding();
		claimListPage.isClaimListDataBackendCallsContainingFinancialData();
	}
}
