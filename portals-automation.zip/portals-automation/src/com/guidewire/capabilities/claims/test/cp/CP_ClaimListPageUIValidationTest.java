package com.guidewire.capabilities.claims.test.cp;

import java.util.HashMap;

import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;

public class CP_ClaimListPageUIValidationTest {
	CPPageFactory cpPageFactory = new CPPageFactory();
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" })
	public void testClaimListPageLoading(String browserName) throws Exception {
		cpPageFactory
				.login()
				.isClaimListPageLoaded()
				.shouldBeTrue("Claim Page is not loaded");

	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5267")
	public void testLOBDropDownOptions(String browserName) throws Exception {
		cpPageFactory
				.login()
				.validateLOBDropDown()
				.shouldBeTrue("LOB drop down options are listed correctly.");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5268")
	public void testLOBPersonalAutoOptionSelection(String browserName) throws Exception {
		cpPageFactory
				.login()
				.selectLOB()
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("LOB Personal Auto option selection does not filter correctly.");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "GPA" })
	public void testHOLOBSelection(String browserName) throws Exception {
		cpPageFactory
				.login()
				.selectLOB()
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("HO LOB filerting is not working properly.");
	}
	
	@Parameters("browserName")
	@Test(groups = {"FNOL", "REG_EMR", "REG_DIA"}, description = "Verify General FNOL claims filtering by type and exact number")
	public void testGeneralGLLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundGLPolicy();
		String claimNum = cpPageFactory.createGeneralClaim().goToSummary().submitClaim().getClaimNumber();

		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome();
		claimListPage.filterClaimByTextSearch(claimNum).validateClaimListIsFiltered("ExactClaimNumber", claimNum).shouldBeTrue("Claim list is not filtered as per General(IM) ClaimNumber");
		claimListPage.clearTextSearch()
			.selectLOB();
		claimListPage.validateClaimListIsFiltered("LOB").shouldBeTrue("General(GL) LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "GPA"})
	public void testAllLOBSelection(String browserName) throws Exception {
		cpPageFactory
				.login()
				.selectLOB()
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("All LOB filerting is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL", "REG_EMR", "REG_DIA"}, description = "Verify General FNOL claims filtering by type and exact number")
	public void testGeneralLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundIMPolicy();

		String claimNum = cpPageFactory
				.createGeneralClaim()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome();
		claimListPage
				.filterClaimByTextSearch(claimNum)
				.validateClaimListIsFiltered("ExactClaimNumber", claimNum)
				.shouldBeTrue("Claim list is not filtered as per General(IM) ClaimNumber");
		claimListPage.clearTextSearch()
				.selectLOB();
		claimListPage
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("General(IM) LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL", "REG_EMR", "REG_DIA"}, description = "Verify WC FNOL claims filtering by type and exact number")
	public void testWCLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		String claimNum = cpPageFactory.createWCClaim().goToSummary().submitClaim().getClaimNumber();

		CP_ClaimListPage  claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome();
		claimListPage
				.filterClaimByTextSearch(claimNum)
				.validateClaimListIsFiltered("ExactClaimNumber", claimNum)
				.shouldBeTrue("Claim list is not filtered as per Workers Comp ClaimNumber");
		claimListPage.clearTextSearch()
				.selectLOB();
		claimListPage
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("Workers Comp LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL", "REG_EMR", "REG_DIA"}, description = "Verify Commercial Property FNOL claims filtering by type and exact number")
	public void testCPLOBSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundCPPolicy();
		ThreadLocalObject.getData().put("ClaimSearchValue", "Commercial Property");

		NewClaimContactPersonPage page = cpPageFactory.createBasicCPClaimWithDefault();

		String claimNum = page
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage  claimListPage =  new CP_ClaimListPage();
		claimListPage.goToHome();
		claimListPage
				.filterClaimByTextSearch(claimNum)
				.validateClaimListIsFiltered("ExactClaimNumber", claimNum)
				.shouldBeTrue("Claim list is not filtered as per Commercial Property ClaimNumber");
		claimListPage.clearTextSearch();
		claimListPage.selectLOB();
		claimListPage
				.validateClaimListIsFiltered("LOB")
				.shouldBeTrue("Commercial Property LOB filtering is not working properly.");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5306")
	public void testPAClaimSearchByExactText(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("ExactClaimNumber")
				.shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5305")
	public void testPAClaimSearchByPartialText(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("PartialClaimNumber")
				.shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "GPA" })
	public void testHOClaimSearchByExactText(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("ExactClaimNumber")
				.shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "GPA" })
	public void testHOClaimSearchByPartialText(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("PartialClaimNumber")
				.shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5307")
	public void testClaimSearchByOpenClaimType(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("ClaimStatus")
				.shouldBeTrue("Claim list is not filtered as per ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5308")
	public void testClaimSearchByDraftClaimType(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsFiltered("ClaimStatus")
				.shouldBeTrue("Claim list is not filtered as per Partial ClaimNumber");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5309")
	public void testClaimIsNotFilteredByPolicyNum(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsNotFiltered("Policy")
				.shouldBeTrue("Claim list is not filtered as per Policy Num");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5310")
	public void testClaimIsNotFilteredByDateOfLoss(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsNotFiltered("DateOfLoss")
				.shouldBeTrue("Claim list is not filtered as per DateOfLoss");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" }, description = "TC5311")
	public void testClaimIsNotFilteredByVendorName(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateClaimListIsNotFiltered("Vendor")
				.shouldBeTrue("Claim list is not filtered as per Vendor name");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA", "GPA" })
	public void testVendorPopUpDetails(String browserName) throws Exception {
		cpPageFactory
				.login()
				.filterClaimByTextSearch()
				.validateVendorPopUpDetails()
				.shouldBeTrue("Vendor Pop Up details are not correct");
	}

	@Parameters("browserName")
	@Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5140 @ Verify closed claims can be displayed on Claims page")
	public void testClosedClaimsAreDisplayedOnClaimsPage(String browserName) throws Exception {
		cpPageFactory
				.login()
				.clickIncludeClaimsClosedCheckBox()
				.filterClaimByTextSearch()
				.findIfStatusIsPresented("Closed")
				.shouldBeTrue("Claim status should be Closed");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, description = "TC5238 @ Verify using the new claim wizard you can go back to previous sections by clicking on that section under Claim Information")
	public void testGoesBackToPreviousSelectionInClaimInformationWizard(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundHOPolicy();
		cpPageFactory
					.createDefaultBurglaryCrimeClaim()
					.goToSummary()
					.goToCrimeDetailsPage()
					.validateExistingCrimeDescription()
					.shouldBeEqual("Details of crime were changed or missing");
	}
	
	@Parameters("browserName")
	@Test(groups = { "REG_EMR" }, enabled = false)
	public void testClaimListBackendCallForFinancialData(String browserName) throws Exception {
		cpPageFactory.login();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.isClaimListDataBackendCallsContainingFinancialData();
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "REG_DIA"})
	public void testClaimListPagination(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimType", "PersonalAuto");
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "San Francisco");
		data.put("State", "California");

		CP_ClaimListPage claimListPage = cpPageFactory.login();
		String claimOnFirstPage = null;
		String claimOnSecondPage = null;
		int maxClaimsPerPage = 25;

		for (int i = 0; i <= maxClaimsPerPage; i++) {
			NewClaimLocationPage page = claimListPage
					.fileAClaim()
					.selectPolicy()
					.goNext()
					.selectPAClaimType()
					.goNext();

			if (i == 0) {
				claimOnSecondPage = page.getDraftClaimNumber();
			} else if (i == maxClaimsPerPage) {
				claimOnFirstPage = page.getDraftClaimNumber();
			}

			claimListPage = page.cancelWizardCP();
		}

		claimListPage
				.nextPage();
		claimListPage.claimInSearchResultValidation(claimOnSecondPage);

		claimListPage
				.previousPage();
		claimListPage.claimInSearchResultValidation(claimOnFirstPage);
	}
}
