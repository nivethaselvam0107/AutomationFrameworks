package com.guidewire.capabilities.claims.test.cpv;

import com.guidewire.capabilities.claims.model.page.CPVendor_ClaimListPage;
import com.guidewire.capabilities.vendor.model.page.Pagefactory;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CPVendor_ClaimPolicySummaryTest {

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testClaimDetailsBackendCallForFinancialData(String browserName) throws Exception {
		CPVendor_ClaimListPage claimListPage = new Pagefactory().login().goToClaimsLanding();
		String claimNum = claimListPage.getOpenClaimIds().get(0);

		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.isClaimDetailsDataBackendCallsContainingFinancialData(claimNum);
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testClaimDetailsTabsPresence(String browserName) throws Exception {
		CPVendor_ClaimListPage claimListPage = new Pagefactory().login().goToClaimsLanding();
		String claimNum = claimListPage.getOpenClaimIds().get(0);

		ClaimSummaryPage claimSummaryPage = claimListPage.openClaimSummary(claimNum);
		claimSummaryPage.validateClaimSummaryTabsPresence().shouldBeTrue("Claim summary tabs not present");
	}
}