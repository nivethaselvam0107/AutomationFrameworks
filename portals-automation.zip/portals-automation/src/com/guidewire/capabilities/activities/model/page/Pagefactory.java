package com.guidewire.capabilities.activities.model.page;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.PageFactory;

import java.util.HashMap;

public class Pagefactory {
    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    private String SIGN_UP_LINK = "//a[@ng-click='$ctrl.signUp()']";


    public Pagefactory() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public ActivitiesHomePage login(){
        new LoginPage().login();
        return new ActivitiesHomePage();
    }

    public SignUp clickSignUp(){
        seleniumCommands.click(By.xpath(SIGN_UP_LINK));
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new SignUp();

    }





}
