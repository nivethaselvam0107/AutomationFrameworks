package com.guidewire.capabilities.activities.model.component;


import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class ActivityPage {

    protected By ACTIVITY_TITLE = By.cssSelector("h1[class='gw-page-title']");

    @FindBy(xpath = "//button[@ng-click='completeActivity()']")
    WebElement MARK_ACTIVITY_COMPLTE_BTN;

    @FindBy(xpath = "//button[@data-ng-click='onNewNote()']")
    WebElement ACTIVITY_ADD_NOTE_BTN;

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public ActivityPage() {
        seleniumCommands.pageWebElementLoader(this);
    }

    public ActivityPage validateActivityPageLoaded(String subject) {
        seleniumCommands.logInfo("Validating Claims page is loaded");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(ACTIVITY_TITLE),"Activity: "+subject).shouldBeEqual("Activity page not loaded");
        return this;
    }

    public ActivityPage markActivityAsComplete(){
        seleniumCommands.isElementPresent(MARK_ACTIVITY_COMPLTE_BTN);
        seleniumCommands.clickbyJS(MARK_ACTIVITY_COMPLTE_BTN);
        return this;
    }

    public ActivityPage addNoteBtn(){
        seleniumCommands.isElementPresent(ACTIVITY_ADD_NOTE_BTN);
        seleniumCommands.clickbyJS(ACTIVITY_ADD_NOTE_BTN);
        return this;
    }

    public boolean verifyAddNoteBtnExists(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return seleniumCommands.isElementPresent(ACTIVITY_ADD_NOTE_BTN);
    }




}
