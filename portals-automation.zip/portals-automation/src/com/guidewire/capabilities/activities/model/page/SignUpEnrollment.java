package com.guidewire.capabilities.activities.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SignUpEnrollment {

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public SignUpEnrollment() {
        seleniumCommands.pageWebElementLoader(this);
    }

    @FindBy(xpath = "//gw-signup-enrollment//h1")
    WebElement HEADER_TXT;

    @FindBy(xpath = "//input[@ng-model='$ctrl.policyNumber']")
    WebElement POLICY_NUMBER;

    @FindBy(xpath = "//input[@ng-model='$ctrl.addressLine1']")
    WebElement ADDRESS_LINE1;

    @FindBy(xpath = "//a[@ng-click='$ctrl.logout()']")
    WebElement LOG_OUT;

    @FindBy(xpath = "//button[@ng-click='$ctrl.enrolUser()']")
    WebElement ADD_POLICY_BTN;

    public Validation validateSignUpEnrollmentPage(){
        seleniumCommands.staticWait(5);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.getTextAtLocator(HEADER_TXT), "Enter Your Details").shouldBeEqual("Mismatch in Header Name");
        new Validation(seleniumCommands.isElementPresent(POLICY_NUMBER)).shouldBeTrue("Missing Policy Number text field");
        new Validation(seleniumCommands.isElementPresent(ADDRESS_LINE1)).shouldBeTrue("Missing Address Line 1 text field");
        new Validation(seleniumCommands.isElementPresent(LOG_OUT)).shouldBeTrue("Missing logout link");
        new Validation(seleniumCommands.isElementPresent(ADD_POLICY_BTN)).shouldBeTrue("Missing Add Policy Button");
        return new Validation(true);
    }


}

