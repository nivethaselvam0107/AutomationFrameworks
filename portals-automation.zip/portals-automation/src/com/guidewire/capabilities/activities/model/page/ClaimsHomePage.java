package com.guidewire.capabilities.activities.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.openqa.selenium.By;
import com.guidewire.widgetcomponents.table.Table;
import com.guidewire.widgetcomponents.table.Row;


public class ClaimsHomePage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    private By LOB_SELECT_CSS = By.cssSelector("div[class='gw-btn-group gw-filter-button-div']");
    private By SEARCH_CLAIM_TXT_CSS = By.cssSelector("[ng-model='_model.value']");
    private By LOB = By.cssSelector("[list='paginatedClaims'] [attribute='normalizedLobCode']");
    private By CLAIM_NUMBER_HEADER =  By.cssSelector("[list='paginatedClaims'] [attribute='claimNumber']");
    private By INSURED_PERSON =  By.cssSelector("[ng-click*='undefined']");
    private By CLAIM_LOSSDATE =  By.cssSelector("[list='paginatedClaims'] [attribute='lossDate']");
    private By CLAIM_STATE =  By.cssSelector("[ng-click*='claimState']");
    private By CLAIM_LIST_TABLE = By.xpath("//table[@list='paginatedClaims']");
    private static final String CLAIM_NUMBER_LINK_CSS = "[list='paginatedClaims'] [attribute='claimNumber'] a[ng-click='navigateTo(item)']";
    private By PARTIES_INVOLVED_TABLE =By.xpath("//table[@id='partiesInvolved']");
    private By ACTIVITIES_TABLE =By.xpath("//table[@id='activitiesTable']");
    private By FILE_A_CLAIM_BTN = By.xpath(" //span[@ng-if='canFileClaimPolicy()']");
    private By LOB_FILTER_BTN = By.xpath("//div[@class='gw-btn-group gw-filter-button-div']");
    private String LOB_VALUE =  "//li[@class='gw-dropdown-content-margin gw-dropdown-item-hover ng-scope'][%s]";
    private By LOB_VALUES = By.xpath("//ul[@ng-click='keepDropdownOpen($event)']");
    private By CLOSED_CLAIMS_CHK_BOX = By.xpath("//input[@ng-model='tableConfig.showClosed']");
    private By LOB_HEADER = By.xpath("//label[@class='gw-filter-type-label ng-binding']");
    private By LOB_WITH_NO_CLAIMS = By.xpath("//div[@class='gw-center gw-claim-results']");
    private String LOB_TITLE = "//table[@list='paginatedClaims']/tbody/tr[%s]/td/img";

    public ClaimsHomePage() {
            seleniumCommands.pageWebElementLoader(this);
    }

    public Validation validateClaimTileViewUIElements() {
        seleniumCommands.logInfo("Validating Claim view tile's UI elements");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(LOB_SELECT_CSS)).shouldBeTrue("LOB dropdownlist is not present");
        new Validation(seleniumCommands.isElementPresent(SEARCH_CLAIM_TXT_CSS)).shouldBeTrue("Search claim textbox is not present");
        new Validation(seleniumCommands.isElementPresent(LOB)).shouldBeTrue("LOB header is not present");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_NUMBER_HEADER), "CLAIM NUMBER").shouldBeEqual("Claim number header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_LOSSDATE), "DATE OF LOSS").shouldBeEqual("Claim loss date header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(CLAIM_STATE), "STATUS").shouldBeEqual("Claim status header text is not matched");
        new Validation(seleniumCommands.getTextAtLocator(INSURED_PERSON), "INSURED").shouldBeEqual("Claim Insured header text is not matched");
        return new Validation(true);
    }

    public ClaimsHomePage filterClaims(String claimNumber) {
        seleniumCommands.logInfo("Filter claims by claim number "+claimNumber);
        seleniumCommands.type(SEARCH_CLAIM_TXT_CSS, claimNumber);
        seleniumCommands.staticWait(5);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    private String generateClaimLink(String claimNumber) {
        return String.format(CLAIM_NUMBER_LINK_CSS, claimNumber);
    }

    public boolean isClaimPresent(String claimNumber) {
        seleniumCommands.waitForElementToBeVisible(CLAIM_LIST_TABLE);
        String claimLink = generateClaimLink(claimNumber);
        seleniumCommands.waitForElementToBePresent(By.cssSelector(claimLink));
        return seleniumCommands.isElementPresent(By.cssSelector(claimLink));
    }


    public ClaimSummaryPage selectClaim() {
        String claimNumber = ThreadLocalObject.getData().get("ClaimNumber");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String claimLinkSelector;
        filterClaims(claimNumber);
        if(isClaimPresent(claimNumber)) {
            claimLinkSelector = generateClaimLink(claimNumber);
            seleniumCommands.clickbyJS(By.cssSelector(claimLinkSelector));
            seleniumCommands.waitForLoaderToDisappearFromPage();
            return new ClaimSummaryPage();
        }
        return null;
    }

    public void validateClaimSummaryPage() throws Exception{
        ClaimSummaryPage claimSummaryPage = this.selectClaim();
        claimSummaryPage.validateClaimSummaryTabsPresenceForVendorEngage();
        claimSummaryPage.isPartiesInvolvedDetailsDataMatchingWithBackEndForVendor();
        claimSummaryPage.isActivitiesDataMatchingWithBackEndForVendor();

    }

    public ClaimSummaryPage validateClaimsDetailsPageThroughClaimLink() {
        String claimNumber = ThreadLocalObject.getData().get("ClaimNumber");
        seleniumCommands.logInfo("Select claim: "+claimNumber);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String claimLinkSelector;
        filterClaims(claimNumber);
        if(isClaimPresent(claimNumber)) {
            claimLinkSelector = generateClaimLink(claimNumber);
            seleniumCommands.clickbyJS(By.cssSelector(claimLinkSelector));
            seleniumCommands.waitForLoaderToDisappearFromPage();
            this.validateSummaryTabClaimsPage(new ClaimSummaryPage());
            seleniumCommands.isElementPresent(PARTIES_INVOLVED_TABLE);
            seleniumCommands.isElementPresent(ACTIVITIES_TABLE);
        }

        return null;
    }

    public ClaimsHomePage clickLOBFilter(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.refreshPage();
        seleniumCommands.click(LOB_FILTER_BTN);
        return this;
    }


    public ClaimsHomePage selectLOB(String lob){
        System.out.println("LOB VALUE: "+lob);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        String LOB_Names[] = seleniumCommands.getElement(LOB_VALUES).getText().split("\n");
        int LOB_Number = -1;

        for(int i=0;i<LOB_Names.length;i++ ){
            if(LOB_Names[i].equalsIgnoreCase(lob)){
                LOB_Number = i;
            }
        }
        seleniumCommands.click(By.xpath(String.format(LOB_VALUE,LOB_Number)));
        this.validateLOB(lob);
        return this;
    }

    public Table claimsTable(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.isElementPresent(CLAIM_LIST_TABLE);
        return new Table(seleniumCommands.findElement(CLAIM_LIST_TABLE));
    }

    public void validateLOB(String lob){
        String displayedLOB = null;

        switch(lob){
            case "Personal Auto":
                displayedLOB="personal-auto";
                break;
            case "Business Owners":
                displayedLOB="business-owner";
                break;
            case "Commercial Owners":
                displayedLOB="commercial-owner";
                break;
            case "Commercial Property":
                displayedLOB="business-owner";
                break;
            case "General Liability":
                displayedLOB="general-liability";
                break;
            case "Homeowners":
                displayedLOB="homeowners";
                break;
            case "Inland Marine":
                displayedLOB="inland-marine";
                break;
            case "Workers' Compensation":
                displayedLOB="workers-compensation";
                break;
            default:
                displayedLOB="All Lines of Business";
                break;
        }

        new Validation(seleniumCommands.getTextAtLocator(LOB_HEADER), lob).shouldBeEqual("Mismatch in LOB");

        seleniumCommands.waitForLoaderToDisappearFromPage();
        if(seleniumCommands.isElementPresent(CLAIM_LIST_TABLE)) {
            for (int i = 0; i < this.claimsTable().getRows().size(); i++) {
                seleniumCommands.waitForLoaderToDisappearFromPage();
                String xpathValue = String.format(LOB_TITLE, i + 1);
                new Validation(seleniumCommands.getAttributeValueAtLocator(By.xpath(xpathValue), "title"), displayedLOB).shouldBeEqual("Line of Business is not working");
            }
        }else{
            new Validation(seleniumCommands.getTextAtLocator(LOB_WITH_NO_CLAIMS), "There are no claims currently active").shouldBeEqual("Mismatch when there are no claims");
        }
    }


    public Validation validateLOBDropDown(){
        this.clickLOBFilter().selectLOB("Personal Auto");
        this.clickLOBFilter().selectLOB("Business Owners");
        this.clickLOBFilter().selectLOB("Commercial Auto");
        this.clickLOBFilter().selectLOB("Commercial Property");
        this.clickLOBFilter().selectLOB("General Liability");
        this.clickLOBFilter().selectLOB("Homeowners");
        this.clickLOBFilter().selectLOB("Inland Marine");
        this.clickLOBFilter().selectLOB("Workers' Compensation");
        return new Validation(true);
    }

    public Validation validateViewClosedClaims(){
        this.clickLOBFilter();
        seleniumCommands.clickbyJS(CLOSED_CLAIMS_CHK_BOX);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        for(Row row:this.claimsTable().getRows())
        {
            String claimNumber = row.getCellByColumnTitle("CLAIM NUMBER").getText();
            String status = row.getCellByColumnTitle("STATUS").getText();

            if(claimNumber.equals(ThreadLocalObject.getData().get("ClosedClaim"))){
                new Validation(status, "Closed").shouldBeEqual("Closed claim is not displayed");
            }else{
                new Validation(status, "Open").shouldBeEqual("Closed claim is not displayed");
            }
        }
        return new Validation(true);
    }


    public ClaimsHomePage validateSummaryTabClaimsPage(ClaimSummaryPage claimSummaryPage){
        claimSummaryPage.validateClaimSummaryTabsPresenceForVendorEngage().shouldBeTrue("Claim summary tabs not present");
        return this;
    }

    public void checkFileAClaimBtnExists(){
        new Validation(seleniumCommands.isElementPresent(FILE_A_CLAIM_BTN)).shouldBeFalse("File a claim exists");
    }

}