package com.guidewire.capabilities.activities.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.Random;

public class SignUp {

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public SignUp() {
        seleniumCommands.pageWebElementLoader(this);
    }

    @FindBy(xpath = "//input[@ng-model='$ctrl.firstName']")
    WebElement FIRST_NAME;

    @FindBy(xpath = "//input[@ng-model='$ctrl.lastName']")
    WebElement LAST_NAME;

    @FindBy(xpath = "//input[@ng-model='$ctrl.email.value']")
    WebElement EMAIL;

    @FindBy(xpath = "//input[@ng-model='$ctrl.password']")
    WebElement PASSWORD;

    @FindBy(xpath = "//input[@ng-model='$ctrl.confirmPassword']")
    WebElement CONFIRM_PASSWORD;

    @FindBy(xpath = "//button[@ng-click='$ctrl.signUp()']")
    WebElement SIGN_UP_BTN;


    public SignUpEnrollment fillSignUpDetails(){
        seleniumCommands.logInfo("Fill Sign Up Form");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(FIRST_NAME, "firstName");
        seleniumCommands.type(LAST_NAME, "lastName");
        seleniumCommands.type(EMAIL, this.generateRandomEmail());
        seleniumCommands.type(PASSWORD, "12345678");
        seleniumCommands.type(CONFIRM_PASSWORD, "12345678");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SIGN_UP_BTN);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new SignUpEnrollment();
    }

    private String generateRandomEmail(){
        Random random = new Random();
        int n = random.nextInt(1000);
        return "email"+String.valueOf(n)+"@email.com";
    }



}
