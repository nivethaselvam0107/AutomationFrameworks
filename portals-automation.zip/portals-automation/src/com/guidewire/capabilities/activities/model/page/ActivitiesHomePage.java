package com.guidewire.capabilities.activities.model.page;
import com.guidewire.capabilities.activities.model.component.ActivityPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.table.Table;
import org.openqa.selenium.By;
import com.guidewire.widgetcomponents.table.Row;
import com.guidewire.widgetcomponents.table.Cell;
import java.util.ArrayList;
import java.util.List;

public class ActivitiesHomePage{

    private By ACTIVITIES_TITLE = By.cssSelector("h1[class='gw-page-title ng-binding']");

    private By SEARCH_ACTIVITIES = By.cssSelector("input[ng-model='activityQuery']");

    private By SELECT_ACTIVITIES_DROPDOWN = By.cssSelector("[ng-model='tableConfig.actStatus']");

    private By SUBJECT_LINK_CSS=By.cssSelector("a[href*='#/activities/detail']");

    protected By ACTIVITIES_TABLE = By.xpath("//table[@id='actTable']");

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    Table activityTable;

    public ActivitiesHomePage verifyActivitiesLandingPage(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(this.ACTIVITIES_TITLE)).shouldBeTrue("Activities Page Not Loaded");
        return  this;
    }

    public ActivitiesHomePage searchActivity(){
        String claimNumber = ThreadLocalObject.getData().get("ClaimNumber");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.type(SEARCH_ACTIVITIES, claimNumber);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        for(Row row: this.activitiesTable().getRows() ) {
            if (claimNumber.equals(row.getCellByIndex(4).getText())) {
                return this;
            }
        }
        return null;
    }

    public List<String> searchOpenAndAllActivities(String activitiesType) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.selectDropDownValueByText(SELECT_ACTIVITIES_DROPDOWN,activitiesType );
        seleniumCommands.waitForLoaderToDisappearFromPage();
        List<String> activityStatusList = new ArrayList<String>();
        for(Row row: this.activitiesTable().getRows() ){
            activityStatusList.add(row.getCellByIndex(2).getText());
        }
        return activityStatusList;
    }

    public ActivitiesHomePage getActivityTableByClaimNumber(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        this.setActivityTable(this.activitiesTable());
        return  this;
    }

    public Table activitiesTable(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new Table(seleniumCommands.findElement(ACTIVITIES_TABLE));
    }


    public ActivityPage validateOpenActivityBySubject(){
        this.searchActivity();
        String SubjectLink = this.activitiesTable().getRows().get(0).getCellByIndex(3).getText();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(SUBJECT_LINK_CSS);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.staticWait(5);
        return new ActivityPage().validateActivityPageLoaded(SubjectLink);
    }

    // Incomplete method, need more information
    public Validation validateClickHeaderName(){
        seleniumCommands.waitForLoaderToDisappearFromPage();

        for(int j=0;j<6;j++) {
            seleniumCommands.staticWait(2);
            Table activitiesTable = this.activitiesTable();
            List<Cell> subjectDataList_Before = activitiesTable.getRowByIndex(0).getCells();
            String subject = activitiesTable.getHeader().getCellByIndex(j).getText();
            this.activitiesTable().getHeader().getCellByIndex(j).getElement().click();
            seleniumCommands.waitForLoaderToDisappearFromPage();
            this.activitiesTable().getHeader().getCellByIndex(j).getElement().click();
            List<Cell> subjectDataList_After = this.activitiesTable().getRowByIndex(j).getCells();
            for (int i = 0; i < subjectDataList_Before.size(); i++) {
                new Validation(subjectDataList_Before.get(i).getText().compareTo(subjectDataList_After.get(i).getText()) > 0).shouldBeTrue("Header Column "+subject +"data is not displayed properly");
            }
            seleniumCommands.staticWait(2);
            seleniumCommands.refreshPage();
        }

        return new Validation(true);
    }

    public void setActivityTable(Table activityTable) {
        this.activityTable = activityTable;
    }

    public Table getActivityTable() {
        return activityTable;

    }

}
