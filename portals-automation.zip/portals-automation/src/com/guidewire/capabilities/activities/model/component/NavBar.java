package com.guidewire.capabilities.activities.model.component;

import com.guidewire.capabilities.activities.model.page.ActivitiesHomePage;
import com.guidewire.capabilities.activities.model.page.ClaimsHomePage;
import com.guidewire.common.selenium.SeleniumCommands;
import org.openqa.selenium.By;


public class NavBar {

    protected By ACTIVITIES_TABLE = By.cssSelector("[ng-class*='activities']");

    protected By CLAIMS_TAB = By.cssSelector("[ng-class*='claims']");

    protected By HOME_TAB = By.cssSelector("[class*='fa fa-home']");

    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public ActivitiesHomePage goToActivities(){
        seleniumCommands.logInfo("Go to Activities Tab");
        seleniumCommands.clickbyJS(ACTIVITIES_TABLE);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new ActivitiesHomePage();
    }

    public ClaimsHomePage goToClaims(){
        seleniumCommands.logInfo("Go to Claims Tab");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(CLAIMS_TAB);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new ClaimsHomePage();
    }

    public ActivitiesHomePage goToHomePage(){
        seleniumCommands.logInfo("Go to Home page");
        seleniumCommands.clickbyJS(HOME_TAB);
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return new ActivitiesHomePage();
    }


}
