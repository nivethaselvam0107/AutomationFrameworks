package com.guidewire.capabilities.activities.test;

import com.guidewire.capabilities.activities.model.component.NavBar;
import com.guidewire.capabilities.activities.model.page.ActivitiesHomePage;
import com.guidewire.capabilities.activities.model.page.ClaimsHomePage;
import com.guidewire.capabilities.activities.model.page.Pagefactory;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.portals.claimportal.subpages.VendorDetailsPopUp;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.guidewire.capabilities.activities.model.component.ActivityPage;
import  com.guidewire.portals.claimportal.subpages.AddNotePage;
import java.util.HashMap;
import java.util.List;
import com.guidewire.capabilities.activities.data.GenerateActivityData;

public class ActivitiesTest {
    ActivitiesHomePage activitiesHomePage = new ActivitiesHomePage();
    ClaimsHomePage claimsHomePage = new ClaimsHomePage();
    Pagefactory pagefactory = new Pagefactory();
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5436 : Verify when you login to Claim portal as Vendor, landing page is Activities")
    public void verifyActivitiesPage(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5436 : Verify when you login to Claim portal as Vendor, landing page is Activities");
        pagefactory.login();
        activitiesHomePage.verifyActivitiesLandingPage();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5437: Verify vendor can search for Open Activities and All Activities")
    public void testSearchOpenAndAllActivities(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5437: Verify vendor can search for Open Activities and All Activities");
        new GenerateActivityData().createNewActivity("Open", "High");
        new GenerateActivityData().createNewActivity("Complete", "High");
        pagefactory.login();
        List<String> activitiesStatusList = activitiesHomePage.searchOpenAndAllActivities("Open Activities");
        new Validation(!activitiesStatusList.contains("Open")).shouldBeFalse("Activities other than open are present");
        activitiesStatusList = activitiesHomePage.searchOpenAndAllActivities("All Activities");
        new Validation(activitiesStatusList.contains("Open") ).shouldBeTrue("Open Activities are not shown");
        new Validation(activitiesStatusList.contains("Complete") ).shouldBeTrue("Complete Activities are not shown");
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5438 : Navigate to Activity Details page through Subject Link")
    public void verifyNavigationToActivityDetailsPageThroughSubjectLink(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5438 : Navigate to Activity Details page through Subject Link");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        activitiesHomePage.validateOpenActivityBySubject();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5439 : Navigate to Activity Details page through Claim Link")
    public void verifyNavigationToClaimsDetailsPageThroughClaimLink(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5439 : Navigate to Activity Details page through Claim Link");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.validateClaimsDetailsPageThroughClaimLink();
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"}, description = "TC5440 : Verify as vendor can view policyholder details by click on insured name on the Activities page")
    public void testClaimDetailsTabsPresence(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5440 : Verify as vendor can view policyholder details by click on insured name on the Activities page");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new VendorDetailsPopUp().openAndValidateVendorPopDetails();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5441: Verify Claims Tab")
    public void verifyClaimsTab(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5441: Verify Claims Tab");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.validateClaimTileViewUIElements();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5443: Verify as vendor can view policyholder details by click on insured name on the Claims page")
    public void verifyPolicyHolderDetailsOnClaimsPage(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5443: Verify as vendor can view policyholder details by click on insured name on the Claims page");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        new VendorDetailsPopUp().openAndValidateVendorPopDetails();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5444: Verify Vendor cannot file a claim")
    public void verifyVendorCannotFileAClaim(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5444: Verify Vendor cannot file a claim");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.checkFileAClaimBtnExists();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5445: Verify as vendor you can complete the activities which with 'Open' status")
    public void verifyCompleteOpenActivitiesAsVendor(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5445: Verify as vendor you can complete the activities which with 'Open' status");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        activitiesHomePage.validateOpenActivityBySubject().markActivityAsComplete();
        new NavBar().goToHomePage();
        activitiesHomePage.searchOpenAndAllActivities("All Activities");
        activitiesHomePage.searchActivity();
        int size = activitiesHomePage.getActivityTableByClaimNumber().getActivityTable().size();
        new Validation(activitiesHomePage.getActivityTableByClaimNumber().getActivityTable().getRowByIndex(size-1).getCellByIndex(2).getText(), "Complete").shouldBeEqual("Claim did not mark as complete");
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5446: Verify Add New Activity to be displayed on Activities page as Open")
    public void verifyAddNewActivityToBeDisplayedOnActivitiesPageAsOpen(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5446: Verify Add New Activity to be displayed on Activities page as Open");
                new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new Validation(activitiesHomePage.searchActivity().searchOpenAndAllActivities("Open Activities").get(0), "Open").shouldBeEqual("New Activity Status is not Open");
    }



    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5448: Verify validation for an Activity Note")
    public void verifyValidationForAnActivityNote(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5448: Verify validation for an Activity Note");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        activitiesHomePage.validateOpenActivityBySubject();
        new ActivityPage().addNoteBtn();
        new AddNotePage().saveNotes();
        new AddNotePage().validateMandatoryFieldsErrorOnNotePage();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5450: Verify validation for Claim Note")
    public void verifyValidationForClaimNote(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5450: Verify validation for an Activity Note");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().addNote();
        new AddNotePage().saveNotes();
        new AddNotePage().validateMandatoryFieldsErrorOnNotePage();
    }


    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5452: Verify Search works on Activities page")
    public void VerifySearchWorksOnActivitesPage(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5452: Verify Search works on Activites page");
                new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new Validation(activitiesHomePage.searchActivity().activitiesTable().getRowByIndex(0).getCellByIndex(4).getText(), ThreadLocalObject.getData().get("ClaimNumber")).shouldBeEqual("Searched Claim Number is not matching");
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5453: Verify Search works on Claims page")
    public void VerifySearchWorksOnClaimsPage(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5453: Verify Search works on Claims page");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.filterClaims(ThreadLocalObject.getData().get("ClaimNumber"));
        new Validation(claimsHomePage.isClaimPresent(ThreadLocalObject.getData().get("ClaimNumber"))).shouldBeTrue("Searched Claim Number is not matching");
    }


    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5454: Verify Line of Business menu works")
    public void VerifyLineOfBusinessMenuWorks(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5454: Verify Line of Business menu works");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.validateLOBDropDown();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5455: Verify Include Closed Claims checkbox works")
    public void VerifyIncludeClosedClaimsCheckboxWorks(String browserName) throws Exception {
        // Create a closed claim in Sample Data
        seleniumCommands.logInfo("TC5455: Verify Include Closed Claims checkbox works");
        //new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        new GenerateActivityData().closeAClaim(ThreadLocalObject.getData().get("ClosedClaim"));
        claimsHomePage.validateViewClosedClaims();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5456: Verify Notes Cannot be added to Closed Activities")
    public void VerifyNotesCannotBeAddedToClosedActivities(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5456: Verify Notes cannot be added to Closed Activities");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new Validation(activitiesHomePage.validateOpenActivityBySubject().verifyAddNoteBtnExists()).shouldBeTrue("Add note button Does Not exists");
        new NavBar().goToHomePage();
        new Validation(activitiesHomePage.validateOpenActivityBySubject().markActivityAsComplete().verifyAddNoteBtnExists()).shouldBeFalse("Add note button exists");
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5458: Verify Return to Home page by Clicking House Icon")
    public void VerifyReturnToHomePageByClickingHouseIcon(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5458: Verify Return to Home page by Clicking House Icon");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        new NavBar().goToHomePage();
        activitiesHomePage.verifyActivitiesLandingPage();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5459: Verify Claims Documents View & Download link works")
    public void verifyClaimsDocumentsViewAndDownloadLinkWorks(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5459: Claims Documents View & Download link works");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().validateClaimSummaryTabsPresenceForVendorEngage();
        new DocumentsTab().openTab();
        new DocumentsTab().uploadDocFromSummary();
        new DocumentsTab().isDocAdded();
        new DocumentsTab().validateDocPageElementsOnClaimSummary();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5460: Verify Remove link works on Claims Documents tab")
    public void verifyRemoveLinkWorksOnClaimsDocumentsTab(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5460: Verify Remove link works on Claims Documents tab");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().validateClaimSummaryTabsPresenceForVendorEngage();
        new DocumentsTab().openTab();
        new DocumentsTab().uploadDocFromSummary();
        new DocumentsTab().isDocAdded();
        new DocumentsTab().deleteDoc();
    }

    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC5461: Search for Uploaded Documents")
    public void verifySearchForUploadedDocuments(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5461: Search for Uploaded Documents");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().validateClaimSummaryTabsPresenceForVendorEngage();
        new DocumentsTab().openTab();
        new DocumentsTab().uploadDocFromSummary();
        new DocumentsTab().isDocAdded();
        new DocumentsTab().searchDoc();
    }


    @Parameters("browserName")
    @Test(groups = { "REG_EMR", "REG_DIA"}, description = "TC8151: Sign-up Page: Vendor")
    public void verifySignUpPageVendor(String browserName) throws Exception {
        seleniumCommands.logInfo("TC8151: Sign-up Page: Vendor");
        pagefactory.clickSignUp().fillSignUpDetails().validateSignUpEnrollmentPage();
    }


    //************************************************//

    // Backend Validation is missing for below test cases

    @Parameters("browserName")
    @Test(enabled = false, groups = { "REG_EMR", "REG_DIA"}, description = "TC5449: Verify as vendor you can add a Claim Note")
    public void verifyVendorCanAddClaimNote(String browserName) throws Exception {
        // Verification from backend is missing
        seleniumCommands.logInfo("TC5449: Verify as vendor you can add a Claim Note");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().addNote();
        new AddNotePage().addNoteDetails();
    }

    @Parameters("browserName")
    @Test(enabled = false, groups = { "REG_EMR", "REG_DIA"}, description = "TC5451: Verify Vendor can add Documents")
    public void verifyVendorCanAddDocuments(String browserName) throws Exception {
        // Backend Validation is missing
        seleniumCommands.logInfo("TC5451: Verify Vendor can add Documents");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.selectClaim();
        new ClaimSummaryPage().validateClaimSummaryTabsPresenceForVendorEngage();
        new DocumentsTab().openTab();
        new DocumentsTab().uploadDocFromSummary();
    }

    @Parameters("browserName")
    @Test(enabled = false, groups = { "REG_EMR", "REG_DIA"}, description = "TC5447: Verify as vendor you can add an Activity Note")
    public void verifyVendorCanAddActivityNote(String browserName) throws Exception {
        // Verification from backend is missing
        seleniumCommands.logInfo("TC5447: Verify as vendor you can add an Activity Note");
        new GenerateActivityData().createNewActivity("Open", "High");
        pagefactory.login();
        activitiesHomePage.validateOpenActivityBySubject();
        new ActivityPage().addNoteBtn();
        new AddNotePage().addNoteDetails();
    }


    @Parameters("browserName")
    @Test(enabled = false, groups = { "REG_EMR", "REG_DIA"}, description = "TC5442: Navigate to Claim Details page through Claim Link")
    // At present verifying  Summary Tabs, Parties Involved and Activities (Vehicles and Coverage not included)
    public void verifyClaimDetailsPageThroughClaimLink(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5442: Navigate to Claim Details page through Claim Link");
        new GenerateActivityData().createNewActivity("Open", "Low");
        pagefactory.login();
        new NavBar().goToClaims();
        claimsHomePage.validateClaimSummaryPage();
    }

    //************************************************//

    // Incomplete, Need Info from Paulie

    @Parameters("browserName")
    @Test(enabled = false, groups = { "REG_EMR1", "REG_DIA"}, description = "TC5457: Verify Ordering Activities based on chosen column works")
      public void VerifyOrderingActivities(String browserName) throws Exception {
        seleniumCommands.logInfo("TC5457: Verify Ordering Activities based on chosen column works");
        pagefactory.login();
        new GenerateActivityData().createNewActivity("Open", "Low");
        activitiesHomePage.validateClickHeaderName();
    }




}
