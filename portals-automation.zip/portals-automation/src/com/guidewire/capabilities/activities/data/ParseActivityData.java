package com.guidewire.capabilities.activities.data;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.util.DataFormatUtil;
import io.restassured.path.json.JsonPath;

import java.util.HashMap;

public class ParseActivityData extends CommonScenario {


    public ParseActivityData(){
        super();
    }


    public  HashMap<String, String> parseNewActivity(String jsonData) throws Exception {
        HashMap<String, String> info = new HashMap<>();
        JsonPath path = new JsonPath(jsonData);
        info.put("ClaimNumber",DataFormatUtil.getNodeValue(path, "ClaimNumber") );
        info.put("VendorID",DataFormatUtil.getNodeValue(path, "VendorID") );
        info.put("ActivityID",DataFormatUtil.getNodeValue(path, "ActivityID") );
        return info;
    }

    public  HashMap<String, String> parseActivityData(String jsonData) throws Exception {
        HashMap<String, String> info = new HashMap<>();
        JsonPath path = new JsonPath(jsonData);
        info.put("VendorSubject",DataFormatUtil.getNodeValue(path, "subject"));
        info.put("VendorDueDate",DataFormatUtil.getNodeValue(path, "dueDate"));
        info.put("VendorStatus",DataFormatUtil.getNodeValue(path, "status"));
        info.put("VendorPriority",DataFormatUtil.getNodeValue(path, "priority"));
        info.put("VendorLastName", DataFormatUtil.getNodeValue(path, "insured", "lastName"));
        info.put("VendorName", DataFormatUtil.getNodeValue(path, "insured", "displayName"));
        info.put("Vendor1Email", DataFormatUtil.getNodeValue(path, "insured", "emailAddress1"));
        info.put("Vendor1FaxNumber", DataFormatUtil.getNodeValue(path, "insured", "cellNumber"));
        info.put("Vendor1PhoneNum", DataFormatUtil.getNodeValue(path, "insured", "workNumber")+" (primary)");
        info.put("Vendor1Address", DataFormatUtil.getNodeValue(path, "insured", "primaryAddress.displayName"));
        info.put("VendorFirstName", DataFormatUtil.getNodeValue(path, "assignedBy", "firstName"));
        info.put("VendorLastName", DataFormatUtil.getNodeValue(path, "assignedBy", "lastName"));
        data.put("NoteSubject", "New Note Subject");
        data.put("NoteBody", "New Note Body");
        return info;
    }



}
