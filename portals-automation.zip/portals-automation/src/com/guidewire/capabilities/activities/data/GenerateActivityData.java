package com.guidewire.capabilities.activities.data;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.data.DataFetch;
import com.guidewire.common.testNG.Validation;

import java.util.HashMap;

public class GenerateActivityData extends CommonScenario {

    public GenerateActivityData(){
        super();
    }

    public HashMap<String, String> createNewActivity(String activityStatus, String activityPriority) throws Exception {
        HashMap<String, String> info = new HashMap<>();
        String createClaimActivityValue = DataFetch.createClaimActivity(activityStatus, activityPriority,data.get("VendorCompanyName"));
        if(createClaimActivityValue!=null) {
            data.putAll(new ParseActivityData().parseNewActivity(createClaimActivityValue));
            data.putAll(new ParseActivityData().parseActivityData(DataFetch.getClaimActivityDetails(data.get("ActivityID"))));
        }else{
            new Validation(false).shouldBeTrue("Activity Not Created");
        }

        seleniumCommands.staticWait(5);
        return info;
    }

    public void closeAClaim(String claim){
        // At the moment using Sample data, will implement in future
        data.put("ClosedClaim" , claim);
    }


}


