package com.guidewire.capabilities.fnol.test.gpa.wc;

import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GPA_WCFileAClaimTest {

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond", "CSR", "CSR_DIA"},  description = " TC4550:GeneralLiabilityClaimCreation, CSR-> TC5847: GeneralLiabilityClaimCreation	")
    public void testWCClaimCreation(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundWCPolicy();
        ThreadLocalObject.getData().put(PolicyData.POLICY_NUM.toString(), policyNum);

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createWCClaim();
        String claimNumber = confirmationPage.getClaimNumber();
        ClaimsTileView claimView = confirmationPage.goToAccountSummary().goToClaimTile();

        claimView.validateClaimListed(claimNumber).shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new GPA_ClaimListPage().openClaimSummary(claimNumber);
        claimSummary.isClaimSummaryDataForAgentMatchingWithBackEnd(claimNumber).shouldBeTrue("Claim Summary Data for Workers Comp policy is not matched with Back End");
        claimSummary.isClaimDetailsDataForAgentMatchingWithBackEnd(claimNumber).shouldBeTrue("Claim Details Data for Workers Comp policy is not matched with Back End");
    }
}
