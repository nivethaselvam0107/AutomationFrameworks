package com.guidewire.capabilities.fnol.test.gpa.cp;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class GPA_CPFileAClaimTest {

  @Parameters("browserName")
  @Test(groups = {"REG_EMR", "REG_DIA"})
  public void testCPDefaultClaim(String browserName) throws Exception {
    PolicyGenerator.createBasicBoundCPPolicy();
    ThreadLocalObject.getData().put("LOSS_CAUSE", "Wind");

    NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createBasicCPClaimWithDefault();

    String claimNum = confirmationPage.getClaimNumber();
    confirmationPage.goToAccountSummaryPage();

    ClaimsTileView claimView = new AccountSummary().goToClaimTile();
    claimView.validateClaimListed(claimNum).shouldBeTrue("Claim is not listed");

    ClaimSummaryPage claimSummary = new GPA_ClaimListPage().openClaimSummary(claimNum);
    claimSummary
            .isCPPropertiesMatchingWithBackEnd(claimNum)
            .shouldBeTrue("CP Claim does not contains all related buildings");
  }
}