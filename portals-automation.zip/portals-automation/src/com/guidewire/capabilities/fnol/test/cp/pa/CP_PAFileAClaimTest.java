package com.guidewire.capabilities.fnol.test.cp.pa;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.generator.VendorGenerator;
import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairFacilityPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.portals.claimportal.pages.*;
import com.guidewire.portals.claimportal.subpages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class CP_PAFileAClaimTest {

	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPADefaultCollisionClaimWithNewRepairFacility(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice();

		String claimNum = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPASpecificCollisionClaimWithNewRepairFacility(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimForVendorChoice();

		String claimNum = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "SMOKE"})
	public void testPATheftEquipmentClaimWithNewRepairFacility(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createTheftClaimForVendorChoice();

		String claimNum = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimWithNewRepairFacility(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createGlassClaimForVendorChoice();

		String claimNum = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimDefaultNoService(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		String claimNum = cpPageFactory.createCollisionClaim()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPATheftVehicleStolenThenChangeToEquipmentClaimWithNoRepairSelection(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimWhatHappenedPage whatHappenedPage = cpPageFactory.createTheftVehicleStolenClaimWithDefaultData()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.goToWhatHappenedPage()
				.selectPAClaimType();

		ThreadLocalObject.getData().put("TheftType", "AudioStolen");

		String claimNum = whatHappenedPage
				.goNext()
				.withTheftVehicleDamageDetails()
				.goToRepairChoicePage()
				.selectNoFacility()
				.goNext()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPATheftVehicleStolenClaimWithNoRepairStep(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimContactPersonPage contactPersonPage = cpPageFactory.createTheftVehicleStolenWithDefaultData();

		String claimNum = contactPersonPage
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "SMOKE"})
	public void testPACollisionClaimWithVendorChoice(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createCollisionClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		String claimNum = page.goNext()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY"})
	public void testPACollisionClaimWithVendorChoiceSummaryPage(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType","Collision");
		data.put("ClaimTypeCollision","Collision with motor vehicle");
		data.put("LossLocationInput","CityOnly");
		data.put("City", "Foster City");
		data.put("State", "California");
		PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createCollisionClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		VendorDto vendorDto = page.getVendorData();

				NewClaimSummaryPage summaryPage = page.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Vendor info should be present on summary page");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY"})
	public void testPACollisionClaimVendorChoiceSummaryPageWithBackForward(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType","Collision");
		data.put("ClaimTypeCollision","Collision with motor vehicle");
		data.put("LossLocationInput","CityOnly");
		data.put("City", "Foster City");
		data.put("State", "California");
		PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createCollisionClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		VendorDto vendorDto = page.getVendorData();

		NewClaimSummaryPage summaryPage = page.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Vendor info should be present on summary page");

		summaryPage
                .getBackToClaimContactPage()
				.getBackToDocumentPage()
                .getBackToRecommendedRepairFacilityDetails()
                .goPrevious()
                .selectNoFacility()
                .goNext()
                .goToSummary();

		summaryPage.validateVendorChoice(null).shouldBeTrue("Vendor info should be present on summary page");

		String claimNum = summaryPage
				.submitClaim()
				.getClaimNumber();
		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimWithVendorChoice(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		String claimNum = page.goNext()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY", "SMOKE"})
	public void testPAGlassClaimWithVendorChoiceSummaryPage(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType", "Glass");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "Foster City");
		data.put("State", "California");
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithGlassService();
		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createGlassClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		VendorDto vendorDto = page.getVendorData();

		NewClaimSummaryPage summaryPage = page.goNext()
			.uploadDocFromFNOL()
			.goNext()
			.setContactData()
			.withContactCellNum()
			.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Vendor info should be present on summary page");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR" , "SMOKE"})
	public void testPATheftEquipmentClaimWithVendorChoice(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createTheftClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		String claimNum = page.goNext()
				.uploadDocFromFNOL()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY"})
	public void testPATheftEquipmentClaimWithVendorChoiceSummaryPage(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType", "Theft");
		data.put("TheftType", "AudioStolen");
		data.put("LossLocationInput", "CityOnly");
		data.put("City", "Foster City");
		data.put("State", "California");
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithAudioService();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createTheftClaimForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();
		page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		VendorDto vendorDto = page.getVendorData();

		NewClaimSummaryPage summaryPage = page.goNext()
			.goNext()
			.setContactData()
			.withContactCellNum()
			.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Vendor info should be present on summary page");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimWithRepairChoicePersistenceMovingForwardAndBack(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility();
		new Validation(recommendedRepairFacilityPage.goPrevious().getSelectedRepairChoice(), "PreferredVendor")
				.shouldBeEqual("Preferred Vendor selection on repair choice step is not persisted when moving step back.");
	}

	@Parameters("browserName")
    @Test(groups = {"REG_EMR"})
    public void testPADefaultCollisionClaimWithRepairChoicePersistenceWithVehiclesOptionMovingForwardAndBack(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        HashMap data = ThreadLocalObject.getData();

        NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();

		String vehicle = data.get(ClaimData.VEHICLE_MAKE1.toString()) + " " + data.get(ClaimData.VEHICLE_MODEL1.toString());

		NewClaimDocumentPage claimDocumentPage =
			claimRepairChoicePage
				.selectVehicle(vehicle)
                .selectNewFacility()
				.withContactData()
				.goToDocumentPage();

		claimDocumentPage.isPageLoaded();
		claimRepairChoicePage = claimDocumentPage.getBackToNewRepairFacilityDetails().getBackToRepairChoice();
		claimRepairChoicePage.isPageLoaded();

		new Validation(claimRepairChoicePage.getSelectedRepairChoice(), "NewVendor")
                .shouldBeEqual("Preferred Vendor selection on repair choice step is not persisted when moving step back.");
        new Validation(claimRepairChoicePage.getSelectedVehicle(), vehicle)
                .shouldBeEqual("Vehicle selection on repair choice step is not persisted when moving step back.");
    }

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"}, description = "DEFECT DE6356 was opened for this test" )
	public void testPATheftEquipmentClaimWithRepairChoicePersistenceAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimContactPersonPage claimContactPersonPage = cpPageFactory
				.createTheftClaimForVendorChoiceWithDefaultData()
				.selectNoFacility()
				.goNext();

		String draftNum = claimContactPersonPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimContactPersonPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);

		claimContactPersonPage
				.isPageLoaded()
				.shouldBeTrue("Contact page is not loaded");

		new Validation(claimContactPersonPage
						.getBackToDocumentPage()
						.getBackToRepairChoice()
						.getSelectedRepairChoice(), "NoRepair")
				.shouldBeEqual("No repair selection on repair choice step is not persisted when moving step back after wizard cancel.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimWithRepairChoicePersistenceWithVehiclesOptionAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithBodyService();

		HashMap data = ThreadLocalObject.getData();

		NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();

		String vehicle1 = data.get(ClaimData.VEHICLE_MAKE1.toString()) + " " + data.get(ClaimData.VEHICLE_MODEL1.toString());

		NewClaimDocumentPage claimDocumentPage =
				claimRepairChoicePage
						.selectVehicle(vehicle1)
						.selectNewFacility()
						.withContactData()
						.goToDocumentPage();

		String draftNum = claimDocumentPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimDocumentPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);

		claimDocumentPage.isPageLoaded().shouldBeTrue("Documents page is not loaded");

		new Validation(claimDocumentPage.getBackToNewRepairFacilityDetails().getBackToRepairChoice().getSelectedRepairChoice(), "NewVendor")
				.shouldBeEqual("No repair selection on repair choice step is not persisted when moving step back after wizard cancel.");

		new Validation(claimRepairChoicePage.getSelectedVehicle(), vehicle1)
				.shouldBeEqual("Vehicle selection on repair choice step is not persisted when moving step back.");

		String vehicle2 = data.get(ClaimData.VEHICLE_MAKE2.toString()) + " " + data.get(ClaimData.VEHICLE_MODEL2.toString());

		claimRepairChoicePage
				.selectVehicle(vehicle2)
				.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);

		claimDocumentPage.isPageLoaded().shouldBeTrue("Documents page is not loaded");

		new Validation(claimDocumentPage.getBackToNewRepairFacilityDetails().getBackToRepairChoice().getSelectedRepairChoice(), "NewVendor")
				.shouldBeEqual("No repair selection on repair choice step is not persisted when moving step back after wizard cancel.");

		new Validation(claimRepairChoicePage.getSelectedVehicle(), vehicle2)
				.shouldBeEqual("Vehicle selection on repair choice step is not persisted when moving step back.");

		String claimNum = claimRepairChoicePage
				.selectRecommendedFacility()
				.selectFirstAvailableVendor()
				.goNext()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimWithRepairChoicePersistenceMovingBackAndForward(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory
				.createCollisionClaimWithDefaultForVendorChoice()
				.selectNewFacility()
				.goToVehicleDriverPage()
				.goToRepairChoicePage();

		repairChoicePage.isPageLoaded().shouldBeTrue("Contact page is not loaded");

		new Validation(repairChoicePage.getSelectedRepairChoice(), "NewVendor")
				.shouldBeEqual("New Vendor selection on repair choice step is not persisted when moving step back after wizard cancel.");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPARecommendedFacilitySort(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage recommendedFacility = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice()
				.selectRecommendedFacility();

		recommendedFacility.isVendorSorted().shouldBeTrue("List of recommended vendors not sorted alphabetically on desktop view");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimWithVendorChoiceSearchNearMapCenter(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRecommendedRepairFacilityPage page = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice()
				.selectRecommendedFacility();

		page.isPageLoaded().shouldBeTrue("Recommended facility page not loaded properly.");

		page.searchOnMobileMap().isPolicyAddressLoadedOnMap().shouldBeTrue("Recommended facility default page not loaded properly");
		page.backToMobileList();
		page.searchNearIncidentAddress().searchOnMobileMap().isIncidentAddressLoadedOnMap().shouldBeTrue("Incident search not showing incident marker");
		page.backToMobileList();
		page.searchNearMyLocationAddress().searchOnMobileMap().isMyLocationAddressLoadedOnMap().shouldBeTrue("My location search not showing my location marker");
		page.backToMobileList();
		page.searchNearPolicyAddress().searchOnMobileMap().isPolicyAddressLoadedOnMap().shouldBeTrue("Policy search not showing policy marker");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimWithNewRepairFacilityPersistenceAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice();

		NewClaimDocumentPage claimDocumentPage = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage();

		String draftNum = claimDocumentPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimDocumentPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);
		claimDocumentPage.isPageLoaded().shouldBeTrue("Claim document page is not loaded");

		NewClaimRepairFacilityPage repairFacilityPage = claimDocumentPage.getBackToNewRepairFacilityDetails();
		repairFacilityPage.containsContactData().shouldBeTrue("New repair facility contact data is not present.");

		String claimNum = repairFacilityPage
				.goToDocumentPage()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"}, description = "DEFECT DE6356 was opened for this test" )
	public void testPATheftEquipmentClaimWithNewRepairFacilityPersistenceAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createTheftClaimForVendorChoiceWithDefaultData();

		NewClaimDocumentPage claimDocumentPage = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage();

		String draftNum = claimDocumentPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimDocumentPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);
		claimDocumentPage.isPageLoaded().shouldBeTrue("Claim document page is not loaded");

		NewClaimRepairFacilityPage repairFacilityPage = claimDocumentPage.getBackToNewRepairFacilityDetails();
		repairFacilityPage.containsContactData().shouldBeTrue("New repair facility contact data is not present.");

		String claimNum = repairFacilityPage
				.goToDocumentPage()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimWithNewRepairFacilityPersistenceAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData();

		NewClaimDocumentPage claimDocumentPage = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage();

		String draftNum = claimDocumentPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimDocumentPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);
		claimDocumentPage.isPageLoaded().shouldBeTrue("Claim document page is not loaded");

		NewClaimRepairFacilityPage repairFacilityPage = claimDocumentPage.getBackToNewRepairFacilityDetails();
		repairFacilityPage.containsContactData().shouldBeTrue("New repair facility contact data is not present.");

		String claimNum = repairFacilityPage
				.goToDocumentPage()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimWithNewRepairFacilityPersistenceMovingBackAndForward(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice();
		NewClaimRepairFacilityPage newClaimRepairFacilityPage = repairChoicePage
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.getBackToNewRepairFacilityDetails();

		newClaimRepairFacilityPage.isPageLoaded().shouldBeTrue("New repair facility details page not loaded");

		newClaimRepairFacilityPage.containsContactData()
				.shouldBeTrue("New repair contact details not persisted after moving forward and back");

		String claimNum = newClaimRepairFacilityPage
				.goToDocumentPage()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		new CP_ClaimListPage().goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
    @Test(groups = {"REG_EMR","SMOKE"})
    public void testPAGlassClaimForVendorChoiceMandatoryRequiredError(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimRecommendedRepairFacilityPage recommendedFacility = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility();

        recommendedFacility.clickNext();
        recommendedFacility.validateRecommendedFacilityErrorMessage().shouldBeEqual("Recommended facility mandatory message not displayed.");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR"})
    public void testPAGlassClaimVendorChoiceSelectedFromListMarkerInfo(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorDto vendorDto = VendorGenerator.generateVendorWithGlassService();

        NewClaimRecommendedRepairFacilityPage recommendedFacility = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility();
        recommendedFacility.selectVendor(vendorDto.VendorName);
        recommendedFacility.validateSelectedVendorPopupInfo(vendorDto).shouldBeEqual("Vendor popup info not properly displayed.");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR"})
    public void testPATheftClaimVendorChoiceBySelectingVendorFromMap(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithAudioService();

        NewClaimRecommendedRepairFacilityPage recommendedFacility = cpPageFactory.createTheftClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility();
        recommendedFacility.isPageLoaded();
        VendorDto vendorDto = recommendedFacility.selectRandomVendorFromMap();
        recommendedFacility.validateSelectedVendorPopupInfo(vendorDto).shouldBeEqual("Vendor popup info not properly displayed.");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR"})
    public void testPACollisionClaimVendorChoiceMatchMarkersWithList(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithAudioService();

        NewClaimRecommendedRepairFacilityPage recommendedFacility = cpPageFactory.createTheftClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility();
        recommendedFacility.isPageLoaded();

        recommendedFacility.validateVendorMarkersDataAgainstListVendorData().shouldBeTrue("Vendor markers are not matching vendor on the list.");
    }

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPATheftEquipmentClaimWitRecommendedRepairFacilityPersistenceMovingBackAndForward(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithAudioService();

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
				.createTheftClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor()
				.goNext()
				.getBackToRecommendedRepairFacilityDetails();

		recommendedRepairFacilityPage.isPageLoaded().shouldBeTrue("Recommended repair facility details page not loaded");

		recommendedRepairFacilityPage.validateSelectedVendor()
				.shouldBeTrue("Recommended repair facility selection not persisted after moving forward and back");

		String claimNum = recommendedRepairFacilityPage
				.goNext()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		new CP_ClaimListPage().goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimWithRecommendedRepairFacilityPersistenceAfterCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithGlassService();

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
				.createGlassClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility();

		recommendedRepairFacilityPage.isPageLoaded();
		
		NewClaimDocumentPage claimDocumentPage = recommendedRepairFacilityPage
				.selectFirstAvailableVendor()
				.goNext();

		String draftNum = claimDocumentPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = claimDocumentPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(draftNum);
		claimDocumentPage.isPageLoaded().shouldBeTrue("Claim document page is not loaded");

		claimDocumentPage.getBackToRecommendedRepairFacilityDetails().
		validateSelectedVendor().shouldBeTrue("Recommended repair facility selection is not present.");

		String claimNum = recommendedRepairFacilityPage
				.goNext()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAClaimWithVendorChoiceSearchPlaces(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendor();

		NewClaimRecommendedRepairFacilityPage repairFacilityPage = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility();

		repairFacilityPage
				.searchPlaceByText("")
				.validateStaticLocations()
				.shouldBeTrue("Static locations not displayed when search empty and in focus");

		repairFacilityPage
				.searchPlaceByText("Guidewire")
				.validateSearchResult()
				.shouldBeTrue("Search result not displayed/related to search request");

		repairFacilityPage
				.selectFirstPlace()
				.validateSearchInputAfterSelection()
				.shouldBeTrue("Search input should contains same text as selection");

		repairFacilityPage
				.selectPolicyLocation()
				.validatePolicyLocation()
				.shouldBeTrue("Map should move to policy location after search");

		repairFacilityPage
				.selectLossLocation()
				.validateLossLocation()
				.shouldBeTrue("Map should move to loss location after search");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "SMOKE"})
	public void testPAGlassClaimWithNewVendorAndSwitchToRecommendedChoiceCancelAndResume(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithGlassService();

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
				.createGlassClaimForVendorChoiceWithDefaultData()
				.selectNewFacility()
				.withContactData()
				.goToDocumentPage()
				.getBackToNewRepairFacilityDetails()
				.getBackToRepairChoice()
				.selectRecommendedFacility();

		String draftNum = recommendedRepairFacilityPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = recommendedRepairFacilityPage.cancelWizardCP();
		claimListPage.openClaimDetailsPage(draftNum);
		recommendedRepairFacilityPage.isPageLoaded().shouldBeTrue("Recommended facility page is not loaded");

		String claimNum = recommendedRepairFacilityPage
				.selectFirstAvailableVendor()
				.goNext()
				.goNext()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY", "SMOKE"})
	public void testPAGlassClaimWithNewRepairFacilitySummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithGlassService();

		NewClaimRepairFacilityPage repairFacilityPage = cpPageFactory
				.createGlassClaimForVendorChoiceWithDefaultData()
				.selectNewFacility()
				.withContactData();

		VendorDto vendorDto = repairFacilityPage.getVendorData();

		NewClaimSummaryPage summaryPage = repairFacilityPage
				.goToDocumentPage()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("New Vendor info should be present on summary page");

		String claimNum = summaryPage
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimDetails = claimListPage.openClaimSummary(claimNum);

		claimDetails.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA fnol is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY"})
	public void testPATheftClaimWithNewRepairFacilitySwitchToRecommendedSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithAudioService();

		NewClaimRepairFacilityPage repairFacilityPage = cpPageFactory
				.createTheftClaimForVendorChoiceWithDefaultData()
				.selectNewFacility()
				.withContactData();

		VendorDto vendorDto = repairFacilityPage.getVendorData();

		NewClaimSummaryPage summaryPage = repairFacilityPage
				.goToDocumentPage()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("New Vendor info should be present on summary page");

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = summaryPage
				.getBackToClaimContactPage()
				.getBackToDocumentPage()
				.getBackToNewRepairFacilityDetails()
				.getBackToRepairChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();

		recommendedRepairFacilityPage.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		vendorDto = recommendedRepairFacilityPage.getVendorData();

		recommendedRepairFacilityPage
				.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Recommended Vendor info should be present on summary page");

		String claimNum = summaryPage
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimDetails = claimListPage.openClaimSummary(claimNum);

		claimDetails.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA fnol is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR", "FNOL-SUMMARY" })
	public void testPACollisionClaimWithRecommendedRepairFacilitySwitchToNewRepairFacilityCancelAndResumeSummaryPage(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithBodyService();

		NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
				.createCollisionClaimWithDefaultForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor();

		recommendedRepairFacilityPage.validateSelectedVendor().shouldBeTrue("Vendor not selected");

		VendorDto vendorDto = recommendedRepairFacilityPage.getVendorData();

		NewClaimSummaryPage summaryPage = recommendedRepairFacilityPage
				.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("Recommended Vendor info should be present on summary page");

		NewClaimRepairFacilityPage newClaimRepairFacilityPage = summaryPage
				.getBackToClaimContactPage()
				.getBackToDocumentPage()
				.getBackToRecommendedRepairFacilityDetails()
				.goPrevious()
				.selectNewFacility()
				.withContactData();

		vendorDto = newClaimRepairFacilityPage.getVendorData();

		newClaimRepairFacilityPage
				.goToDocumentPage()
				.goNext()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("New Vendor info should be present on summary page");

		String claimDraftNum = summaryPage.getDraftClaimNumber();
		CP_ClaimListPage claimListPage = summaryPage.cancelWizardCP();

		claimListPage.openClaimDetailsPage(claimDraftNum);

		NewClaimDocumentPage claimDocumentPage =  new NewClaimDocumentPage();
		claimDocumentPage.isPageLoaded().shouldBeTrue("Documents page is not loaded");

		claimDocumentPage
				.goNext()
				.goToSummary();

		summaryPage.validateVendorChoice(vendorDto).shouldBeTrue("New Vendor info should be present on summary page after resume wizard");

		String claimNum = summaryPage
				.submitClaim()
				.getClaimNumber();

		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimDetails = claimListPage.openClaimSummary(claimNum);
		claimDetails.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for PA fnol is not matched with Back End");
		claimDetails.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim details data for PA fnol NOT matching backend data");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR","SMOKE"})
	public void testPACollisionClaimVendorChoiceServiceRequestStatusCheck(String browserName) throws Exception {
		HashMap<String, String> data = ThreadLocalObject.getData();
		data.put("ClaimSubType","Collision");
		data.put("ClaimTypeCollision","Collision with motor vehicle");
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithBodyService();

		String claimNum = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor()
				.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		SummaryTab claimSummary = new CP_ClaimListPage().goToHome().openClaimSummary(claimNum);
		RepairsTab repairsTab;

		new Validation(claimSummary.openTab().isTabActive()).shouldBeTrue("SummaryTab not opened");
		new Validation(new NotesTab().openTab().isTabActive()).shouldBeTrue("NotesTab not opened");
		new Validation(new DocumentsTab().openTab().isTabActive()).shouldBeTrue("DocumentsTab not opened");
		new Validation(new ChecksTab().openTab().isTabActive()).shouldBeTrue("ChecksTab not opened");
		new Validation((repairsTab = new RepairsTab()).openTab().isTabActive()).shouldBeTrue("RepairsTab not opened");

		repairsTab.validateServiceRequest();
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPAGlassClaimVendorChoiceServiceRequestStatusCheck(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithBodyService();

		String claimNum = cpPageFactory.createGlassClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor()
				.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		new CP_ClaimListPage().goToHome().openClaimSummary(claimNum);
		RepairsTab tab = new RepairsTab();
		tab.openTab();
		tab.validateServiceRequest();
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPATheftClaimVendorChoiceServiceRequestStatusCheck(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		VendorGenerator.generateVendorWithBodyService();

		String claimNum = cpPageFactory.createTheftClaimForVendorChoiceWithDefaultData()
				.selectRecommendedFacility()
				.selectFirstAvailableVendor()
				.goNext()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		new CP_ClaimListPage().goToHome().openClaimSummary(claimNum);
		RepairsTab tab = new RepairsTab();
		tab.openTab();
		tab.validateServiceRequest();
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR"})
	public void testPACollisionClaimDefaultNoServiceWithCustomContact(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		String claimNum = cpPageFactory.createCollisionWithVehicleClaim()
				.selectContact()
				.withContactHomeNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for PA policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithProvidedToWizard(claimNum).shouldBeTrue("Claim Summary Data for PA policy is not matched with provided to wizard");
	}

	@Parameters("browserName")
	@Test(groups = {"REG_EMR","SMOKE"})
	public void testPATheftClaimNoVendorChoiceNoServiceRequest(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		String claimNum = cpPageFactory.createTheftClaimForVendorChoiceWithDefaultData()
				.selectNoFacility()
				.goNext()
				.setContactData()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		new CP_ClaimListPage().goToHome().openClaimSummary(claimNum);
		RepairsTab tab = new RepairsTab();
		tab.openTab();
		tab.validateNoRequest();
	}
}