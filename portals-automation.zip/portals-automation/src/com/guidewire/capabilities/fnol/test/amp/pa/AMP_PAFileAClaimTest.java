package com.guidewire.capabilities.fnol.test.amp.pa;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.generator.VendorGenerator;
import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData_PolicyHolder;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;
import com.guidewire.portals.claimportal.subpages.DocumentsTab;
import com.guidewire.portals.claimportal.subpages.NotesTab;
import com.guidewire.portals.claimportal.subpages.RepairsTab;

public class AMP_PAFileAClaimTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    private void verifyClaimSubmission(String claimNum) throws Exception{
        AccountSummaryPage summaryPage =  new AccountSummaryPage();
        summaryPage.goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary =  new AMP_ClaimListPage().openClaimSummary(claimNum);
        claimSummary.isPAPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary.validateClaimNumberFormat(claimNum).shouldBeTrue("Claim Number format is not correct");
        claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond", "SMOKE"}, description = "T3219 : Verify policyholder can add a claim of type 'Collision")
    public void testPACanAddCollisionClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-155 Verify policyholder can add a claim of type 'Collision'");
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = pagefactory.createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL", "Emerald","Ferrite","Granite"})
    public void testPACollisionClaimWithVendorChoice(String browserName) throws Exception {
        logger.info("Running Test: testPACollisionClaimWithVendorChoice");
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        NewClaimRecommendedRepairFacilityPage page = pagefactory.createCollisionClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectFirstAvailableVendor();
        page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

        String claimNum = page.goNext()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"  , "Diamond"}, description = "T3220 : Verify policyholder can add a claim of type 'Theft")
    public void testPACanAddTheftClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-156 Verify policyholder can add a claim of type 'Theft'");
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = pagefactory.createTheftClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL", "Emerald","Ferrite","Granite"})
    public void testPATheftClaimWithVendorChoice(String browserName) throws Exception {
        logger.info("Running Test: testPAThiefClaimWithVendorChoice");
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        NewClaimRecommendedRepairFacilityPage page = pagefactory.createTheftClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectFirstAvailableVendor();
        page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

        String claimNum = page.goNext()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite"  , "Diamond"}, description = "T3221 : Verify policyholder can add a claim of type 'Theft")
    public void testPACanAddGlassClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-157 Verify policyholder can add a claim of type 'Glass'");
        PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = pagefactory.createGlassClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL", "Emerald","Ferrite","Granite"})
    public void testPAGlassClaimWithVendorChoice(String browserName) throws Exception {
        logger.info("Running Test: testPAGlassClaimWithVendorChoice");
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        NewClaimRecommendedRepairFacilityPage page = pagefactory.createGlassClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectFirstAvailableVendor();
        page.validateSelectedVendor().shouldBeTrue("Vendor not selected");

        String claimNum = page.goNext()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        verifyClaimSubmission(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3228: Document upload to the claim")
    public void testUploadDocumentToAClaim(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	ThreadLocalObject.getData().putAll(ClaimData_PolicyHolder.getPAClaimCommonData());
    	String claimNum = pagefactory.createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

    	AccountSummaryPage summaryPage =  new AccountSummaryPage();
        summaryPage.goToHome().goToClaimsPage();
        new AMP_ClaimListPage().openClaimSummary(claimNum);
        DocumentsTab docTab =new DocumentsTab();
        docTab.openTab();
        docTab.uploadDocFromSummary().isDocAdded().shouldBeEqual("DOC file didn't upload");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3229: Verify Adding a Note")
    public void testAddNoteToAClaim(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	ThreadLocalObject.getData().putAll(ClaimData_PolicyHolder.getPAClaimCommonData());
    	String claimNum = pagefactory.createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

    	AccountSummaryPage summaryPage =  new AccountSummaryPage();
    	summaryPage.goToHome().goToClaimsPage();
        new AMP_ClaimListPage().openClaimSummary(claimNum);
        NotesTab noteTab =new NotesTab();
        noteTab.openTab();
        noteTab.addANewNote().isNotesAdded();
        new ClaimSummaryPage().areNotesValueMatchingWithBackEnd(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "T3222 : Verify policyholder can add a claim of type 'Theft")
    public void testPACanAddOtherClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-158 Verify that as a policy holder when you select the claim type as 'Other' you are prompted to contact agent");
        PolicyGenerator.createBasicBoundPAPolicy();
        ContactUSPage contactUSPage = pagefactory.createOtherClaim();

        contactUSPage.isContactUsPageLoaded().shouldBeTrue("Contact us Page is not loaded correctly");
        new Validation(contactUSPage.goToHomePage().pageDisplayedCorrectly()).shouldBeTrue("Confirmation button doesn't return to account page.");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testPAGlassClaimVendorChoiceServiceRequestStatusCheck(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        String claimNum = pagefactory.createGlassClaimForVendorChoiceWithDefault()
                .selectRecommendedFacility()
                .selectFirstAvailableVendor()
                .goNext()
                .goNext()
                .setContactData()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        new AccountSummaryPage().goToHome().goToClaimsPage();
        new AMP_ClaimListPage().openClaimSummary(claimNum);

        RepairsTab tab = new RepairsTab();
        tab.openTab();
        tab.validateServiceRequest();
    }
}
