package com.guidewire.capabilities.fnol.test.amp.cp;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AMP_CPFileAClaimTest {

    Pagefactory pagefactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testCPDefaultClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();
        NewClaimContactPersonPage page = pagefactory.createBasicCPClaimWithDefault();

        String claimNum = page
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new AMP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);
        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }
}
