package com.guidewire.capabilities.fnol.test.cp.wc;

import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;
import com.guidewire.portals.qnb.pages.AlertHandler;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CP_WCFileAClaimTest {

	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testWCClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		String claimNum = cpPageFactory.createWCClaim()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for Workers Comp policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for Workers Comp policy is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data for Workers Comp policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testWCClaimWithSubmitAsReportOnly(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		boolean isResultsInDeathSelectorNotDisplayed = cpPageFactory
				.startWCClaimWithDefaultData()
				.selectWCClaimType()
				.setNotificationDateInThePast()
				.submitAsReportOnly(true)
				.setInjuredEmployeeName()
				.setInjuredEmployeeAddress()
				.goToWCInjuryDetailsPage()
				.isResultInDeathNotPresent();

		new Validation(isResultsInDeathSelectorNotDisplayed).shouldBeTrue("Results in death selector is present.");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testWCClaimWithMedicalTreatmentCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

		String claimNum = cpPageFactory.createWCClaimWWitDefaultMedicalTreatment()
				.withContactCellNum()
				.goToSummary()
				.submitClaim()
				.getClaimNumber();

		CP_ClaimListPage claimListPage = new CP_ClaimListPage();
		claimListPage.goToHome()
				.validateClaimListing(claimNum)
				.shouldBeTrue("Claim for Workers Comp policy is not listed");

		ClaimSummaryPage claimSummary = claimListPage.openClaimSummary(claimNum);

		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for Workers Comp policy is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data for Workers Comp policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testWCClaimCreationCancel(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundWCPolicy();

        NewClaimContactPersonPage contactPage = cpPageFactory.createWCClaim()
				.withContactCellNum()
				.goNext();

		String draftNumber = contactPage.getDraftClaimNumber();
		contactPage.cancelClaim();

		new CP_ClaimListPage().validateClaimDraftStatus(draftNumber).shouldBeEqual("Claim is not listed as draft claim");
	}
}