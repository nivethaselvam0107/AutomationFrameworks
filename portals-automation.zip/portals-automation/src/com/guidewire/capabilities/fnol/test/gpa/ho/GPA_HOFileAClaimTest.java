package com.guidewire.capabilities.fnol.test.gpa.ho;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.ClaimsList;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;

/**
 * Test Suite :
 * ClaimFeature
 *
 * Test cases under cover :
 * GPA-314
 * GPA-240
 * GPA-239
 * GPA-238
 * GPA-237
 * GPA-236
 * GPA-224
 *
 */
public class GPA_HOFileAClaimTest {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testStartClaimFromPolicy(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_ClaimPagefactory().startClaimFromPolicy();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testStartClaimFromAccount(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        new GPA_ClaimPagefactory().startClaimFromAccount();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3771 : HOClaimOnPolicyDetailsPage")
    public void testFileClaimForHOPolicyFromPolicyDetailPage(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("FireCause","Fire Cause");
        data.put("FireDiscovery", "Fire Discovery");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOFireClaimFromPolicy();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();

        GPA_ClaimListPage claimListPage = new PolicySummary(policyNumber).goToClaims();
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "SMOKE" , "CSR"}, description = "TC3776 : HOClaimOfTypeRiotOrCivilCommotionCrime")
    public void testHOClaimOfTypeRiotOrCivilCommotionCrime(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("CrimeDamageType", "Riot");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOCrimeClaimFromAccount();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();
        new AccountSummary().goToClaimTile();

        ClaimsList claimListPage = new ClaimsList();
        claimListPage.filterClaimByTextSearch(claimNumber);
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3773: HOClaimOfTypeWater")
    public void testHOClaimOfTypeWater(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("WaterDamageType","Mold");
        data.put("WaterDamageSource", "Roof");
        data.put("ROOF_FIXED", "Yes");
        data.put("WaterTurnOff", "Yes");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOWaterClaimFromAccount();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();
        new AccountSummary().goToClaimTile();

        ClaimsList claimListPage = new ClaimsList();
        claimListPage.filterClaimByTextSearch(claimNumber);
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3772: HOClaimOfTypeFire")
    public void testHOClaimOfTypeBurglary (String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("CrimeDamageType", "Burglary");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOCrimeClaimFromPolicy();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();

        GPA_ClaimListPage claimListPage = new PolicySummary(policyNumber).goToClaims();
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3774 : HOClaimOfTypeBurglary")
    public void testHOClaimOfTypeFire(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("FireCause","Fire Cause");
        data.put("FireDiscovery", "Fire Discovery");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOFireClaimFromPolicy();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();

        GPA_ClaimListPage claimListPage = new PolicySummary(policyNumber).goToClaims();
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "CSR"}, description = "TC3776: HOClaimOfTypeMaliciousMischiefOfVandalismCrime")
    public void testHOClaimOfTypeMaliciousMischiefOfVandalismCrime(String browserName) throws Exception {
        String policyNumber = PolicyGenerator.createBasicBoundHOPolicy();

        HashMap<String,String> data = ThreadLocalObject.getData();
        data.put("CrimeDamageType","Vandalism");
        data.put("LOSS_DESC", "Loss Desc");

        NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createHOCrimeClaimFromPolicy();
        String claimNumber = confirmationPage.getClaimNumber();
        confirmationPage.goToAccountSummaryPage();

        GPA_ClaimListPage claimListPage = new PolicySummary(policyNumber).goToClaims();
        claimListPage.validateContainsClaim(claimNumber).shouldBeTrue("Claim does not exist on ClaimsList page");
    }
}
