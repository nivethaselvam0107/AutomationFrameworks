package com.guidewire.capabilities.fnol.test.cp.cp;

import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.ClaimData;
import com.guidewire.portals.claimportal.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

public class CP_CPClaimUIValidationTest {
    CPPageFactory cpPageFactory = new CPPageFactory();

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA", "FNOL", "FNOL_UI"})
    public void testCPMandatorySelectionOnBuildingsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();
        NewClaimPropertiesSelectionPage propertiesSelectionPage = cpPageFactory.createBasicCPClaimForPropertySelection();
        propertiesSelectionPage.clickNext();
        propertiesSelectionPage.validatePropertySelectionErrorMessage().shouldBeEqual("Error message for Building selection is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA", "FNOL", "FNOL_UI"})
    public void testCPFinancialFieldsOnDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();

        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.REPAIR_ESTIMATE_INDEX.getValue(), "1");

        NewClaimPropertiesSelectionPage propertiesSelectionPage = cpPageFactory.createBasicCPClaimForPropertySelection();
        PropertyDetailsPage propertyDetailsPage = propertiesSelectionPage.addProperties(1).goNext();
        propertyDetailsPage.selectRepairEstimate();

        Map<String, String> values = new HashMap<>();
        values.put("Minimum value is 0", "-1");
        values.put("Maximum value is 1000000000000", "1000000000001");
        values.put("Please enter numbers only", "not a number");
        values.put("Value must be a decimal number with no more than 2 digits after the decimal point", "123.321");

        values.forEach(
            (key, value) ->
            {
                data.put(ClaimData.ESTIMATE_REPAIR_COST.getValue(), value);
                data.put(ClaimData.ESTIMATE_LOSS.getValue(), value);
                propertyDetailsPage.setEstimatedRepairCost();
                propertyDetailsPage.validateEstimatedRepairCostErrorMessage(key);

                propertyDetailsPage.setEstimateOfLoss();
                propertyDetailsPage.validateEstimateOfLossErrorMessage(key);
            }
        );
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA", "FNOL", "FNOL_UI"})
    public void testCPNumberOfStoriesFieldOnDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();
        HashMap<String, String> data = ThreadLocalObject.getData();

        NewClaimPropertiesSelectionPage propertiesSelectionPage = cpPageFactory.createBasicCPClaimForPropertySelection();
        PropertyDetailsPage propertyDetailsPage = propertiesSelectionPage.addProperties(1).goNext();

        Map<String, String> values = new HashMap<>();
        values.put("Minimum value is 0", "-1");
        values.put("Maximum value is 200", "201");
        values.put("Value entered must not contain decimal values", "123.321");

        values.forEach(
            (key, value) ->
            {
                data.put(ClaimData.NUMBER_OF_STORIES.getValue(), value);
                propertyDetailsPage.setNumberOfStories();
                propertyDetailsPage.validateNumberOfStorieErrorMessage(key);
            }
        );
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA", "FNOL", "FNOL_UI"})
    public void testCPMandatoryPolicyAddressSelectionOnWherePage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();

        NewClaimPropertiesSelectionPage propertiesSelectionPage = cpPageFactory.createBasicCPClaimForPropertySelection();
        NewClaimLocationPage claimLocationPage = propertiesSelectionPage.addProperties(1).goNext().goNext();
        claimLocationPage.clickNext();
        claimLocationPage.validatePolicyAddressErrorMessage().shouldBeEqual("Error message for Policy Address selection is not correct");
    }
}