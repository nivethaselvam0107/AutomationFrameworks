package com.guidewire.capabilities.fnol.test.gpa.general;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashMap;

public class GPA_GeneralFileAClaimTest {

  @Parameters("browserName")
  @Test(groups = {"FNOL"})
  public void testGeneralBOClaimCreation(String browserName) throws Exception {
    PolicyGenerator.createBasicBoundBOPolicy();

    HashMap<String, String> data = ThreadLocalObject.getData();
    data.put("LOSS_CAUSE", "Explosion");

    NewClaimConfirmationPage confirmationPage = new GPA_ClaimPagefactory().createGeneralClaim();
    String claimNumber = confirmationPage.getClaimNumber();
    confirmationPage.goToAccountSummaryPage();

    ClaimsTileView claimView = new AccountSummary().goToClaimTile();
    claimView.validateClaimListed(claimNumber).shouldBeTrue("Claim is not listed");

    ClaimSummaryPage claimSummary = new GPA_ClaimListPage().openClaimSummary(claimNumber);
    claimSummary.isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
  }
}
