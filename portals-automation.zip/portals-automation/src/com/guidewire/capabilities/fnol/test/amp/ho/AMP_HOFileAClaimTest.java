package com.guidewire.capabilities.fnol.test.amp.ho;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;

public class AMP_HOFileAClaimTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "SMOKE" }, description = "T3223 : Verify as a policyholder you can create a claim as a Home Owner - Fire")
    public void testHOCanAddFireClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-159 Verify as a policyholder you can create a claim as a Home Owner - Fire");
        PolicyGenerator.createBasicBoundHOPolicy();
        String claimNum = pagefactory
                .createFireClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage
                .goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new AMP_ClaimListPage()
                .openClaimSummary(claimNum);
        claimSummary
                .isHOPageDisplayedCorrectly()
                .shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary
                .isClaimSummaryDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary
                .isClaimDetailsDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"} , description = "T3224 : Verify as a policyholder you can create a claim as a Home Owner - Water")
    public void testHOCanAddWaterClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-160 Verify as a policyholder you can create a claim as a Home Owner - Water");
        PolicyGenerator.createBasicBoundHOPolicy();
        String claimNum = pagefactory
                .createWaterClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage
                .goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new AMP_ClaimListPage()
                .openClaimSummary(claimNum);
        claimSummary
                .isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary
                .isClaimSummaryDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary
                .isClaimDetailsDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "T3225 : Verify as a policyholder you can create a claim as a Home Owner - Crime")
    public void testHOCanAddCrimeClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-161 Verify as a policyholder you can create a claim as a Home Owner - Crime");
        PolicyGenerator.createBasicBoundHOPolicy();
        String claimNum = pagefactory
                .createCrimeClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage
                .goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new AMP_ClaimListPage()
                .openClaimSummary(claimNum);
        claimSummary
                .isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary
                .isClaimSummaryDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary
                .isClaimDetailsDataMatchingWithBackEnd(claimNum)
                .shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "T3226 : Cancelling a FNOL")
    public void testHOCanCancelClaim(String browserName) throws Exception {
        logger.info("Running Test: AMP-162 Cancelling a FNOL");
        PolicyGenerator.createBasicBoundHOPolicy();
        NewClaimSummaryPage claimSummaryPage = pagefactory
                .createCrimeClaim()
                .withContactHomeNum()
                .goToSummary();

        String draftNum = claimSummaryPage.getDraftClaimNumber();
        claimSummaryPage.cancelClaim();

        AccountSummaryPage accountSummary = new AccountSummaryPage();
        accountSummary
                .goToClaimsPage()
                .validateClaimDraftStatus(draftNum)
                .shouldBeEqual("Claim is not listed as draft claim");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"}, description = "T3227 : Cancelling a FNOL from Claims Tab")
    public void testCancelClaimFromClaimTab(String browserName) throws Exception {
        logger.info("Running Test: AMP-163 Cancelling a FNOL");
        PolicyGenerator.createBasicBoundHOPolicy();
        NewClaimSummaryPage claimSummaryPage = pagefactory
                .createCrimeClaimFromClaimTab()
                .withContactHomeNum()
                .goToSummary();

        String draftNum = claimSummaryPage.getDraftClaimNumber();
        claimSummaryPage.cancelClaim();

        AMP_ClaimListPage claimPage = new AMP_ClaimListPage();
        claimPage
                .validateClaimDraftStatus(draftNum)
                .shouldBeEqual("Claim is not listed as draft claim");
    }

}
