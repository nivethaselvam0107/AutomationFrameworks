package com.guidewire.capabilities.fnol.test.cp.general;

import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CP_GeneralFileAClaimTest {

	CPPageFactory cpPageFactory = new CPPageFactory();

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testGeneralBOClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundBOPolicy();

		String claimNum = cpPageFactory.createGeneralClaim()
				.withContactCellNum().goToSummary().submitClaim().getClaimNumber();

		ClaimListPage claimListPage =  new ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim for Business Owner policy is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for Business Owner policy is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data for Business Owner policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testGeneralIMClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundIMPolicy();

		String claimNum = cpPageFactory.createGeneralClaim()
				.withContactCellNum().goToSummary().submitClaim().getClaimNumber();

		ClaimListPage claimListPage =  new ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim for InlandMarine policy is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for InlandMarine policy is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data for InlandMarine policy is not matched with Back End");
	}

	@Parameters("browserName")
	@Test(groups = {"FNOL"})
	public void testGeneralGLClaimCreation(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundGLPolicy();

		String claimNum = cpPageFactory.createGeneralClaim()
				.withContactCellNum().goToSummary().submitClaim().getClaimNumber();

		ClaimListPage claimListPage =  new ClaimListPage();
		claimListPage.goToHome().validateClaimListing(claimNum).shouldBeTrue("Claim for GeneralLiability policy is not listed");
		ClaimSummaryPage claimSummary =  claimListPage.openClaimSummary(claimNum);
		claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data for GeneralLiability policy is not matched with Back End");
		claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data for GeneralLiability policy is not matched with Back End");
	}
}