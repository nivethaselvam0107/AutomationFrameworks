package com.guidewire.capabilities.fnol.test.cp.pa;

import java.util.HashMap;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.generator.VendorGenerator;
import com.guidewire.capabilities.fnol.model.page.NewClaimRecommendedRepairFacilityPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairFacilityPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataFetch;
import com.guidewire.portals.claimportal.pages.CPPageFactory;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;

import io.restassured.path.json.JsonPath;

public class CP_PAClaimUIValidationTest {
    CPPageFactory cpPageFactory = new CPPageFactory();

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateMandatoryFieldsOnRepairChoicePage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimRepairChoicePage repairChoicePage = cpPageFactory.createCollisionClaimWithDefaultForVendorChoice();

        repairChoicePage.clickNext();
        repairChoicePage.validateRepairChoiceErrorMessage().shouldBeEqual("Error message for Repair choice is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void testPADefaultCollisionClaimMandatoryFieldsOnVendorChoicePage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
                .createCollisionClaimWithDefaultForVendorChoice()
                .selectRecommendedFacility();

        recommendedRepairFacilityPage.clickNext();
        recommendedRepairFacilityPage.validateRecommendedFacilityErrorMessage().shouldBeEqual("Error message for Vendor choice is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateMandatoryFieldsOnNewRepairFacilityPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        NewClaimRepairFacilityPage newClaimRepairFacilityPage = cpPageFactory
                .createCollisionClaimWithDefaultForVendorChoice()
                .selectNewFacility();

        newClaimRepairFacilityPage.goToDocumentPage();
        newClaimRepairFacilityPage.validateRepairChoiceErrorMessagesPresent().shouldBeTrue("Error messages for new repair facility are not correct");

        newClaimRepairFacilityPage.getBackToRepairChoice();
        NewClaimRepairChoicePage repairChoicePage = new NewClaimRepairChoicePage();
        repairChoicePage
                .selectRecommendedFacility()
                .selectFirstAvailableVendor()
                .goPrevious()
                .selectNewFacility();

        newClaimRepairFacilityPage.goToDocumentPage();
        newClaimRepairFacilityPage.validateRepairChoiceErrorMessagesPresent().shouldBeTrue("Error messages for new repair facility are not correct");
        String draftNum = newClaimRepairFacilityPage.getDraftClaimNumber();
        CP_ClaimListPage claimListPage = newClaimRepairFacilityPage.cancelWizardCP();
        claimListPage.openClaimDetailsPage(draftNum);
        newClaimRepairFacilityPage.goToDocumentPage();
        newClaimRepairFacilityPage.validateRepairChoiceErrorMessagesPresent().shouldBeTrue("Error messages for new repair facility are not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateMandatoryFieldsOnRepairChoiceWithThreeVehiclesPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();

        claimRepairChoicePage.clickNext();

        claimRepairChoicePage.validateRepairChoiceErrorMessage().shouldBeEqual("Error messages for repair choice are not correct");
        claimRepairChoicePage.validateRepairChoiceVehiclesErrorMessage().shouldBeEqual("Error messages for repair choice vehicles are not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateVehiclesSelectorPresenceOnRepairChoiceWithThreeVehiclesPageMovingForwardAndBack(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();

        HashMap data = ThreadLocalObject.getData();
        String vehicle = data.get(ClaimData.VEHICLE_MAKE2.toString()) + " " + data.get(ClaimData.VEHICLE_MODEL2.toString());
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible");

        NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = claimRepairChoicePage
                .selectVehicle(vehicle)
                .selectRecommendedFacility();

        recommendedRepairFacilityPage.isPageLoaded().shouldBeTrue("Recommended repair facility page NOT loaded");
        recommendedRepairFacilityPage.goPrevious();
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible after getting back from Recommended Repair facility");
        new Validation(vehicle, claimRepairChoicePage.getSelectedVehicle()).shouldBeEqual("Vehicle NOT selected after getting back from Recommended Repair facility");

        NewClaimRepairFacilityPage claimRepairFacilityPage = claimRepairChoicePage.selectNewFacility();
        claimRepairFacilityPage.isPageLoaded().shouldBeTrue("New Repair facility is NOT loaded");
        claimRepairFacilityPage.getBackToRepairChoice();

        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible after getting back from New Repair facility");
        new Validation(vehicle, claimRepairChoicePage.getSelectedVehicle()).shouldBeEqual("Vehicle NOT selected after getting back from New Repair facility");

        NewClaimDocumentPage claimDocumentPage = claimRepairChoicePage.selectNoFacility();
        claimDocumentPage.isPageLoaded().shouldBeTrue("Documents page not loaded");
        claimDocumentPage.getBackToRepairChoice();
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeFalse("Vehicle selector IS visible after getting back from Documents page");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateVehiclesSelectorPresenceOnRepairChoiceWithThreeVehiclesPageActionsOnRepairChoiceScreen(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();

        HashMap data = ThreadLocalObject.getData();
        String vehicle = data.get(ClaimData.VEHICLE_MAKE2.toString()) + " " + data.get(ClaimData.VEHICLE_MODEL2.toString());
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible");

        claimRepairChoicePage
                .selectVehicle(vehicle)
                .selectValueRecommendedFacility();

        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible after selecting recommended facility option");
        new Validation(vehicle, claimRepairChoicePage.getSelectedVehicle()).shouldBeEqual("Vehicle NOT set after selecting recommended facility option");

        claimRepairChoicePage.selectValueNewFacility();
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible after selecting new facility option");
        new Validation(vehicle, claimRepairChoicePage.getSelectedVehicle()).shouldBeEqual("Vehicle NOT set after selecting new facility option");

        claimRepairChoicePage.selectValueNoFacility();
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeFalse("Vehicle selector IS visible after selecting no facility option");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void validateVehiclesSelectorNotMandatoryOnRepairChoiceWithThreeVehiclesPageWithNoRepairSelected(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimRepairChoicePage claimRepairChoicePage = cpPageFactory.createCollisionClaimWithThreeVehiclesWithDefaultForVendorChoice();
        claimRepairChoicePage.isPageLoaded().shouldBeTrue("Repair choice page NOT loaded.");
        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeTrue("Vehicle selector NOT visible.");
        claimRepairChoicePage.selectValueNoFacility();

        claimRepairChoicePage.isVehiclesSelectorPresent().shouldBeFalse("Vehicle selector IS visible when No Repair selected.");
        claimRepairChoicePage.selectNoFacility().isPageLoaded().shouldBeTrue("New Claim document page is NOT loaded.");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void testMaxNumberOfVendorsOnRecommendedRepairScreen() {
        PolicyGenerator.createBasicBoundPAPolicy();

        for(int i = 0; i < 53; i++) {
            VendorGenerator.generateVendor();
        }

        NewClaimRecommendedRepairFacilityPage recommendedRepairFacilityPage = cpPageFactory
                .createGlassClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility();

        recommendedRepairFacilityPage.isPageLoaded().shouldBeTrue("Recommended repair facility page NOT loaded.");
        new Validation(50, recommendedRepairFacilityPage.getNumberOfVendors()).shouldBeEqual("Max number of vendors on UI incorrect.");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "FNOL", "FNOL_UI"})
    public void testMaxNumberOfRecommendedVendorsRecommendedRepairFromBackend() {
        for(int i = 0; i < 103; i++) {
            VendorGenerator.generateVendor();
        }

        HashMap<String, Object> localTestData = new HashMap<>();
        localTestData.put("latitude", 37.5549479);
        localTestData.put("longitude", -122.27106019999997);
        localTestData.put("specialistServiceCodes", "autoinsprepairbody");
        localTestData.put("maxNumberOfResults", 103);
        localTestData.put("searchRadius", 300);
        localTestData.put("unitOfDistance", "Mile");
        JsonPath path = new JsonPath(DataFetch.searchForVendorsWithGeoCode(localTestData));
        int numberOfReturnedVendors =path.getList("vendors").size();

        new Validation(100, numberOfReturnedVendors).shouldBeEqual("Max number of vendors from backend incorrect.");
    }
}