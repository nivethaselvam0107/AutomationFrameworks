package com.guidewire.capabilities.fnol.test.gpa.pa;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.agent.model.page.PoliciesLanding;
import com.guidewire.capabilities.claims.model.page.GPA_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.generator.VendorGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.fnol.model.page.GPA_ClaimPagefactory;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimConfirmationPage;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import com.guidewire.portals.claimportal.pages.NewClaimLocationPage;
import com.guidewire.portals.claimportal.pages.NewClaimSummaryPage;
import com.guidewire.portals.claimportal.pages.NewClaimVehicleDriverPage;
import com.guidewire.portals.claimportal.pages.NewClaimWhatHappenedPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;
import com.guidewire.portals.claimportal.subpages.RepairsTab;
import com.guidewire.portals.qnb.pages.AlertHandler;
import com.guidewire.widgetcomponents.table.Row;

public class GPA_PAFileAClaimTest {

String platform = System.getProperty("platform");

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , enabled = false)
    public void CannotFileClaimForNonPAOrNonHOPolicy(String browserName) throws Exception {
        new LoginPage().login();

        PoliciesLanding policiesLanding = new AgentDashboard().goToPolicies();
        policiesLanding.getProducerCodeSelector().selectEverything();
        Row policyRow = policiesLanding
                .toggleQuickAdvancedFilters()
                .advancedToggleCancelled()
                .advancedToggleExpired()
                .advancedToggleLOBByName("Businessowners")
                .advancedToggleLOBByName("Commercial Auto")
                .getPolicies()
                .getRowByIndex(0);

        String NonHOorPAPolicyNumber = policyRow.getCellByColumnTitle("POLICY NUMBER").getText();

        policyRow.getCellByColumnTitle("ACCOUNT")
                .getElement()
                .findElement(By.cssSelector("a[ui-sref]"))
                .click();

        //At this point we're at account summary page for an account that contains a non-pa and non-ha policy.
        new AccountSummary()
                .goToClaimTile()
                .goToMakeAClaim()
                .selectPolicy(NonHOorPAPolicyNumber)
                .isNextButtonDisabledBeforePolicySelection().shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3777: CollisionPAClaim")
    public void CollisionPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();
        
        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }  ,enabled = true , description = "TC3841: MissingLossDateWhileFilingAClaim")
    public void MissingLossDateWhileFilingAClaim(String browserName) throws Exception {
        NewClaimDOLPage selectPolicyPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .withClaimDateOfLoss("");

        selectPolicyPage.hideDoL();
        
        selectPolicyPage.validateDateOfLossRequiredError().shouldBeFalse("Next button is enabled althought the date of loss field is not empty.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}  , description = "TC3778: MissingValuesOnWhereDidItHappenPageWhileFilingAClaim")
    public void MissingValuesOnWhereDidItHappenPageWhileFilingAClaim(String browserName) throws Exception {
        new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .goToVehicleDriverPage();
        
        NewClaimWhatHappenedPage whatHappenedPage = new NewClaimWhatHappenedPage();
        whatHappenedPage.verifyRequiredFieldsErrorDisplayed().shouldBeTrue("Required fields not displayed on location page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3779: MissingValuesOnWhatAboutVehiclePageWhileFilingAClaim")
    public void MissingValuesOnWhatAboutVehiclePageWhileFilingAClaim(String browserName) throws Exception {
        new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .goNext();

        NewClaimVehicleDriverPage vehiclePage = new NewClaimVehicleDriverPage();
        vehiclePage.verifyRequiredFieldsErrorDisplayed().shouldBeTrue("Required fields not displayed on location page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"} , description = "TC3781: CollisionPAClaimWithCityAndState")
    public void CollisionPAClaimWithCityAndState(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"} , description = "TC3783: TheftPAClaim")
    public void TheftPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createTheftClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "CSR", "CSR_DIA"} , description = "TC3784: TheftAudioOnlyPAClaim")
    public void TheftAudioOnlyPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createTheftClaimForVendorChoice()
                .selectNoFacility()
                .goNext()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "CSR", "CSR_DIA"} , description = "TC3785:GlassPAClaim")
    public void GlassPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createGlassClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond", "CSR", "CSR_DIA"} , description = "TC3786: OtherPAClaim")
    public void OtherPAClaim(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummary accountSummary = new GPA_ClaimPagefactory().getAccountWithSuitablePolicy();
        String accountHolderName = accountSummary.getAccountHolderName();

        ContactUSPage contactUSPage = accountSummary
                .goToClaimTile()
                .goToMakeAClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goToContactUsPage();

        contactUSPage.isContactUsPageLoaded().shouldBeTrue("Contact us Page is not loaded correctly");
        contactUSPage.backToClaims().titleContains(accountHolderName).shouldBeTrue("Confirmation button doesn't return to account page.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3787: CollisionWithPedestrainPAClaim")
    public void CollisionWithPedestrianPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim().withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3789: MaliciousMischiefAndVandalismPAClaim")
    public void MaliciousMischiefAndVandalismPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3788: CollisionWhileTurningLeftPAClaim")
    public void CollisionWhileTurningLeftPAClaim(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3782: CollisionPAClaimWithLocationOnMap")
    public void CollisionPAClaimWithLocationOnMap(String browserName) {
		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3842: CannotClaimWithoutPolicySelection")
    public void CannotClaimWithoutPolicySelection(String browserName) {
        WebElement nextButton = new GPA_ClaimPagefactory()
                .getNewClaim()
                .getNextButton();

        new Validation(nextButton.isEnabled()).shouldBeFalse("Next button is enabled, but should not be");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC378691: ExistingContactPAClaim")
    public void ExistingContactPAClaim(String browserName) {
        AccountSummary accountSummary = new GPA_ClaimPagefactory()
                .getAccountWithSuitablePolicy();

        String accountHolderName = accountSummary.getAccountHolderName();

        NewClaimContactPersonPage newClaimContactPersonPage = accountSummary.goToClaimTile()
                .goToMakeAClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext();

        NewClaimSummaryPage newClaimSummaryPage = newClaimContactPersonPage.selectContact(accountHolderName)
                .withContactCellNum()
                .goToSummary();

        new Validation(newClaimSummaryPage.getContactValue().contains(accountHolderName)).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3786: OtherPAClaim")
    public void NewContactPAClaim(String browserName) {
        NewClaimContactPersonPage newClaimContactPersonPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext();

        NewClaimSummaryPage newClaimSummaryPage = newClaimContactPersonPage
                .addNewContact()
                .setNewContactPersonDetails()
                .withContactCellNum()
                .goToSummary();

        HashMap<String, String> data = ThreadLocalObject.getData();
        new Validation(newClaimSummaryPage.getContactValue().contains(data.get("FirstNameNewContact"))).shouldBeTrue();
        new Validation(newClaimSummaryPage.getContactValue().contains(data.get("LastNameNewContact"))).shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"}, description = "TC3794:AtleastOnePhoneNumberOnContactInformationForClaim")
    public void AtleastOnePhoneNumberOnContactInformationForClaim(String browserName) {
    		PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimContactPersonPage newClaimContactPersonPage = new GPA_ClaimPagefactory().createCollisionClaim();
        newClaimContactPersonPage
                .addNewContact()
                .setNewContactPersonDetails()
                .goNext();

        newClaimContactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual();
    }

    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3843:InvalidEmailIdWhileFilingClaim")
    public void InvalidEmailIdWhileFilingClaim() {
    		PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimContactPersonPage newClaimContactPersonPage = new GPA_ClaimPagefactory().createCollisionClaim();

        newClaimContactPersonPage
                .addNewContact()
                .setNewContactPersonDetails()
                .withContactCellNum();

        newClaimContactPersonPage.validateEmailFieldOnSummaryPage().shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3790: MissingNewPersonDetailOnSupportingInformation")
    public void MissingNewPersonDetailOnSupportingInformation(String browserName) {
    		PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimVehicleDriverPage newClaimVehicleDriverPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint();

        newClaimVehicleDriverPage.addNewPassenger();
        newClaimVehicleDriverPage.goNext();
        newClaimVehicleDriverPage.validatePassengerMandatoryFieldsErrorMessage().shouldBeTrue();
    }

    private Validation claimSavedSuccessfully(String claimNumber) {
        boolean claimSavedSuccessfully = true;
        new NewClaimConfirmationPage().goToAccountSummaryPage();
        ClaimsTileView claimView = new AccountSummary().goToClaimTile();
        try {
            claimView.validateClaimListed(claimNumber).shouldBeTrue("Claim is not listed");
            ClaimSummaryPage claimSummary = claimView.selectClaim(claimNumber);
            claimSummary.isPAPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
            claimSummary.validateClaimNumberFormat(claimNumber).shouldBeTrue("Claim Number format is not correct");
        } catch(AssertionError e) {
            e.printStackTrace();
            claimSavedSuccessfully = false;
        }

        return new Validation(claimSavedSuccessfully);
    }

    private ClaimSummaryPage openClaim(String claimNumber ) {
		new NewClaimConfirmationPage().goToAccountSummaryPage();
		ClaimsTileView claimView = new AccountSummary().goToClaimTile();
		return claimView.selectClaim(claimNumber);
	}


    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .jpeg document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .jpeg file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test( groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"}, description = "TC3852, TC5843: UploadJPEGDocToClaim")
    public void testDocUploadJPEG(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("JPEG file didn't upload");
    }


    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .gif document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .gif file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test( groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "NO TEST CASE CURRENTLY IN TEST LINK")
    public void testDocUploadGIF(String browserName) throws Exception {
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("GIF file didn't upload");
    }


    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .png document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .png file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3850: UploadPNGDocToClaim")
    public void testDocUploadPNG(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("PNG file didn't upload");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .doc document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .doc file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3854: UploadWordDocToClaim")
    public void testDocUploadDOC(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("DOC file didn't upload");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .docx document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .docx file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3855: UploadWordDocxToClaim")
    public void testDocUploadDOCX(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("DOCX file didn't upload");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .pdf document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .pdf file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3853: UploadPDFDocToClaim")
    public void testDocUploadPDF(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("PDF file didn't upload");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can upload a .txt document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .txt file and click on Open.

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3851: UploadTXTDocToClaim")
    public void testDocUploadTXT(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().isDocAdded().shouldBeEqual("TXT file didn't upload");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can't upload a .html document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .html file and click on Open

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Error popup window with 'Failed to upload file ' message should be displayed.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "NO TEST CASE CURRENTLY IN TEST LINK")
    public void testDocUploadHTML(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for HTML file");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user can't upload a .js document to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on .js file and click on Open

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Error popup window with 'Failed to upload file ' message should be displayed.
     */

    @Parameters("browserName")
    @Test( groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "NO TEST CASE CURRENTLY IN TEST LINK")
    public void testDocUploadJS(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for JS file");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }

    /**@formatter:off
     * @param browserName
     *
     * Test Description : Verify user cannot upload 2 documents with same name to a personal auto claim

    Actual :-
    1. Login to GPA(aarmstrong/gw)
    2. Click on accounts link on nav bar
    3. Click on any of the quick filters and then click on Account name link
    4. Click on Claims.
    5. Click on personal auto claim number with status as Open on Claims page
    6. Click on Documents Tab
    7. Click on Upload document button
    8. Click on file and click on Open
    9. Click on upload document button again and upload the same file again

    Expected :-
    1. Dashboard page should be displayed.
    2. Account landing page should be displayed
    3. Account details page shouls be displayed
    4. Claims page with claims table should be displayed.
    5. Claims details page should be displayed.
    6. Documents page should be displayed with Upload Document button, Search field and table with exisitng documents listed.
    7. Open window should be displayed
    8. Document should be uploaded successfully and should be listed on Documents page.
    9. Error popup window with 'Failed to upload file ' message should be displayed.
     */

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3856: Upload2DocWithSameNameToClaim")
    public void testSameDocUploadTwice(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        ClaimSummaryPage claimSummaryPage = new ClaimSummaryPage();
        claimSummaryPage.openDocTab().uploadDocFromSummary().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for same file upload");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "CSR", "CSR_DIA"} , description = "TC3807: FileClaimForPAPolicyFromPolicyDetailPage, GPA--915:FileClaimForPAPolicyFromPolicyDetailPage")
    public void testFileClaimFromPolicyDetailPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        NewClaimContactPersonPage newClaimContactPersonPage =  new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext();

        String claimNumber = newClaimContactPersonPage
                .addNewContact()
                .setNewContactPersonDetails()
                .withContactCellNum()
                .goToSummary()
                 .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNumber).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond"} , description = "TC3800: CancelClaimOnDateOfLossPage")
    public void testCancelClaimOnDateOfLossPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        GPA_ClaimListPage claimListPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .cancelWizardGPA();

        claimListPage.goToClaimTile().isSimpleClaimListPageLoaded().shouldBeTrue("Claim list is not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3801: CancelClaimOnWhatHappenedPage")
    public void testCancelClaimOnWhatHappenedPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimWhatHappenedPage claimPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType();

        GPA_ClaimListPage claimListPage = claimPage.cancelWizardGPA();
        claimListPage.goToClaimTile().isSimpleClaimListPageLoaded().shouldBeTrue("Claim list is not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3802: CancelClaimOnDetailsPage")
    public void testCancelClaimOnDetailsPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimLocationPage claimPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withExactAccidentAddress()
                .withClaimDescription()
                .withPropDamageDetails();

        String draftNum = claimPage.getDraftClaimNumber();
        GPA_ClaimListPage claimListPage = claimPage.cancelWizardGPA();
        claimListPage.goToClaimTile().openClaimDetailsPage(draftNum);

        NewClaimVehicleDriverPage claimVehicleDriverPage = new NewClaimVehicleDriverPage();
        claimVehicleDriverPage.isVehicleDriverPageLoaded().shouldBeTrue("Vehicle driver page is not loaded");
        claimVehicleDriverPage.clickPrevious();
        new NewClaimLocationPage().areClaimLocationDetailsAreSaved().shouldBeTrue("Location details are not saved");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3803:CancelClaimOnWhatAboutVehiclePage")
    public void testCancelClaimOnWhatAboutVehiclePage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimVehicleDriverPage claimPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withExactAccidentAddress()
                .goToVehicleDriverPage()
                .selectFirstAvailableVehicle()
				.selectFirstAvailableDriver()
				.setVehicleSafetyToDrive()
				.setAirBagDeployStatus()
				.setEquiFailureStatus()
				.setVehicleTowStatus()
				.setVehicleRentalStatus()
				.setVehicleCollisionPoint();

        String draftNum = claimPage.getDraftClaimNumber();
        GPA_ClaimListPage claimListPage = claimPage.cancelWizardGPA();
        claimListPage.goToClaimTile().openClaimDetailsPage(draftNum);

        NewClaimDocumentPage claimDocumentPage = new NewClaimDocumentPage();
        claimDocumentPage.clickPrevious();
        new NewClaimVehicleDriverPage().isVehicleDriverDetailsDataMatchingWithBackEnd(draftNum);
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3804: CancelClaimOnSupportingInformationPage")
    public void testCancelClaimOnSupportingInformationPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimDocumentPage claimDocPage = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withExactAccidentAddress()
                .goToVehicleDriverPage()
                .selectFirstAvailableVehicle()
				.selectFirstAvailableDriver()
				.setVehicleSafetyToDrive()
				.setAirBagDeployStatus()
				.setEquiFailureStatus()
				.setVehicleTowStatus()
				.setVehicleRentalStatus()
				.setVehicleCollisionPoint()
                .goToRepairChoicePage()
                .selectNoFacility()
                .uploadDocFromFNOL()
                .withNewContactPerson();

        String draftNum = claimDocPage.getDraftClaimNumber();
        GPA_ClaimListPage claimListPage = claimDocPage.cancelWizardGPA();
        claimListPage.goToClaimTile().openClaimDetailsPage(draftNum);
        NewClaimDocumentPage claimDocumentPage = new NewClaimRepairChoicePage().selectNoFacility();
        claimDocumentPage.isDocumentUplaoded().shouldBeTrue("Document page is not displayed");
        claimDocumentPage.areNewPersonDetailsAreSaved().shouldBeTrue("New Person details are not saved");
        claimDocPage.isDocumentUplaoded().shouldBeTrue("Document is not uplaoded");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3805: CancelClaimOnContactPage")
    public void testCancelClaimOnContactPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimContactPersonPage contactPage = new GPA_ClaimPagefactory()
        			.createCollisionClaim()
                .withNewContactPerson()
                .withContactCellNum()
                .withContactHomeNum()
                .withContactWorkNum();

        String draftNum = contactPage.getDraftClaimNumber();
        GPA_ClaimListPage claimListPage = contactPage.cancelWizardGPA();
        claimListPage.goToClaimTile().openClaimDetailsPage(draftNum);
        NewClaimDocumentPage claimDocumentPage = new NewClaimRepairChoicePage().selectNoFacility();
        claimDocumentPage.isDocumentUplaoded().shouldBeTrue("Document page is not displayed");
        claimDocumentPage.goNext();
        contactPage.areContactPersonDetailsAreSaved().shouldBeTrue("Contact person details are not saved");
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3806: CancelClaimOnSummaryPage")
    public void testCancelClaimOnSummaryPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        NewClaimSummaryPage summaryPage = new GPA_ClaimPagefactory()
        		 	.createCollisionClaim()
                .goToSummary();

        HashMap<String, String> summaryData = summaryPage.getBasicClaimSummaryDetails();
        String draftNum = summaryPage.getDraftClaimNumber();
        GPA_ClaimListPage claimListPage = summaryPage.cancelWizardGPA();
        claimListPage.goToClaimTile().openClaimDetailsPage(draftNum);
        NewClaimDocumentPage claimDocumentPage = new NewClaimDocumentPage();
        claimDocumentPage.isDocumentUplaoded().shouldBeTrue("Document page is not displayed");
        claimDocumentPage.goNext().goNext();
        summaryPage.validateClaimSummaryPageData(summaryData).shouldBeTrue();
    }
    
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3792: AddPropertuDamageDetailToClaim")
	public void testAddPropDamageToClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		String claimNum = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withPropDamageDetails()
                .withClaimDescription()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
				.setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage()
                .selectNoFacility()
                .uploadDocFromFNOL()
                .withNewContactPerson()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3799: MissingNewVehicleInfoWhileFilingClaim")
	public void testMandatoryFieldsForNewVehicle(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
		new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withPropDamageDetails()
                .withClaimDescription()
                .goToVehicleDriverPage()
                .selectOtherVehicle()
                .goNext()
                .validateNewVehicleMandatoryFieldsErrorMessage()
                .shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3797: MissingAdditionalNewVehicleInfoWhileFilingAClaim")
	public void testMandatoryFieldsForAdditionalNewVehicle(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withPropDamageDetails()
                .withClaimDescription()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .addAdditionalVehicle()
                .selectVehicleOnAdditionalVehiclePage()
                .selectVehicleOnAdditionalVehiclePage()
                .goNext()
                .validateNewVehicleMandatoryFieldsErrorMessage()
                .shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3808: MissingNewDriverInfoWhileFilingClaim")
	public void testMandatoryFieldsForNewDriver(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();

		new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withPropDamageDetails()
                .withClaimDescription()
                .goToVehicleDriverPage()
                .selectOtherDriver()
                .goNext()
                .validateNewDriverMandatoryFieldsErrorMessage()
                .shouldBeTrue();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "CSR", "CSR_DIA"}, description = "TC3796: AddNoteToPAClaim")
	public void testAddNoteToPAClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		ClaimSummaryPage claimSummaryPage = this.openClaim(claimNum);
		claimSummaryPage.openNoteTab()
                .addNote()
                .addNoteDetails()
                .openNoteTab()
                .searchNote()
                .isNotesAdded()
                .shouldBeTrue("Note is not added correctly");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3798: MissingMandatoryValuesForAddNoteToPAClaim")
	public void testMissingMandatoryValuesForAddNoteToPAClaim(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		ClaimSummaryPage claimSummaryPage = this.openClaim(claimNum);
		claimSummaryPage.openNoteTab()
                .addNote()
                .saveNotes()
                .validateMandatoryFieldsErrorOnNotePage()
                .shouldBeTrue("Note mandatory fields are marked with error message");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" , "SMOKE" }, description = "TC3809: PAClaimWithNewVehicle")
	public void testPAClaimWithNewVehicle(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withExactAccidentAddress()
                .goToVehicleDriverPage()
                .withNewVehicle()
                .selectFirstAvailableDriver()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC3810: PAClaimWithNewDriver")
	public void testPAClaimWithNewDriver(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withExactAccidentAddress()
                .goToVehicleDriverPage()
                .withNewDriver()
                .selectFirstAvailableVehicle()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC4474:PAClaim-DoNotNeedRepair")
	public void testPAClaimWithNoRepair(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
		String claimNum = new GPA_ClaimPagefactory()
                .getNewClaim()
                .selectPolicyByPolicyType()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withExactAccidentAddress()
                .goToVehicleDriverPage()
                .selectFirstAvailableVehicle()
                .selectFirstAvailableDriver()
                .goToRepairChoicePage()
                .selectNoFacility()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

		claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
		 new Validation(new ClaimSummaryPage().getClaimSummaryDataFromUI().containsKey(ClaimData.VENDOR_NAME.getValue())).shouldBeFalse("Vendor is available on UI");
	}

    @Parameters("browserName")
    @Test(groups = { "FNOL" })
    public void testPACollisionClaimForVendorChoice(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        String claimNum = new GPA_ClaimPagefactory()
                .createCollisionClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectVendor()
                .goNext()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "FNOL" })
    public void testPATheftClaimForVendorChoice(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        String claimNum = new GPA_ClaimPagefactory()
                .createTheftClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectVendor()
                .goNext()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
    }

    @Parameters("browserName")
    @Test(groups = { "FNOL", "Emerald","Ferrite","Granite" , "CSR" }, description = "TC4471:PAClaim-SelectRecommendedRepairFacility, CSR -> TC5844: Verify user can select recommended repair facility while filing a PA claim")
    public void testPAGlassClaimForVendorChoice(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        String claimNum = new GPA_ClaimPagefactory()
                .createGlassClaimForVendorChoice()
                .selectRecommendedFacility()
                .selectFirstAvailableVendor()
                .goNext()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        claimSavedSuccessfully(claimNum).shouldBeTrue("Claim was not saved successfully");
        new ClaimSummaryPage().isClaimSummaryDataForAgentMatchingWithBackEnd(claimNum);
    }

    @Parameters("browserName")
    @Test(groups = { "FNOL" })
    public void testPATheftClaimVendorChoiceServiceRequestStatusCheck(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();
        VendorGenerator.generateVendorWithBodyService();

        String claimNum = new GPA_ClaimPagefactory()
                .createTheftClaimForVendorChoiceWithDefaultData()
                .selectRecommendedFacility()
                .selectVendor()
                .goNext()
                .goNext()
                .setContactData()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        new NewClaimConfirmationPage().goToAccountSummaryPage();
        new AccountSummary().goToClaimTile().selectClaim(claimNum);
        RepairsTab tab = new RepairsTab();
        tab.openTab();
        tab.validateServiceRequest();
    }
}



