package com.guidewire.capabilities.fnol.test.amp.wc;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AMP_WCFileAClaimTest {

    Pagefactory pagefactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testWCClaimCreation(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundWCPolicy();
        String claimNum = pagefactory.createWCClaim()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage.goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new ClaimListPage().openClaimSummary(claimNum);
        claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data does not match with the Back End");
    }
}
