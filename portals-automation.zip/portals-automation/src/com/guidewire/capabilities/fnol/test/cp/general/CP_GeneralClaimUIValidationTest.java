package com.guidewire.capabilities.fnol.test.cp.general;

import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CP_GeneralClaimUIValidationTest {
    CPPageFactory cpPageFactory = new CPPageFactory();

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateMandatoryFieldsOnGeneralWhatHappenedPage(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundGLPolicy();

        NewClaimWhatHappenedPage whatHappenedPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext();
        whatHappenedPage.clickNext();

        whatHappenedPage.validateLossCauseFieldErrorMessage().shouldBeEqual("Error message for Loss Cause Field is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateMandatoryFieldsOnGeneraDetailsPageWithExactAddress(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundIMPolicy();

        NewGeneralClaimDetails claimDetailsPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage();
        claimDetailsPage.selectExactAddress().clickNext();

        claimDetailsPage.validateMissingCity().shouldBeEqual("Error message for City Field is not correct");
        claimDetailsPage.validateMissingState().shouldBeEqual("Error message for State Field is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateMandatoryFieldsOnGeneraDetailsPageWithCityOnly(String browserName) throws Exception {
        String policyNum = PolicyGenerator.createBasicBoundBOPolicy();

        NewGeneralClaimDetails claimDetailsPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy(policyNum)
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage();
        claimDetailsPage.selectCityOnlyAddress().clickNext();

        claimDetailsPage.validateMissingCity().shouldBeEqual("Error message for City Field is not correct");
        claimDetailsPage.validateMissingState().shouldBeEqual("Error message for State Field is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateMandatoryFieldsForPersonOnSupportDocumentPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundGLPolicy();

        NewClaimDocumentPage claimDocumentPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage()
                .selectPredefinedAddress()
                .goNext();

        claimDocumentPage.addNewContactPerson().goNext();
        claimDocumentPage.validateNewContactMandatoryFieldsErrorMessag().shouldBeTrue("New Contact fields are not marked with error");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateExistingContactDetailsOnSummaryPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundIMPolicy();

        NewClaimSummaryPage claimSummaryPage = cpPageFactory
                .createGeneralClaim()
                .withContactCellNum()
                .goToSummary();

        claimSummaryPage.validateExistingContactsDetailsOnSummaryPage().shouldBeEqual("Existing contact Person details are not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateNewContactDetailsOnSummaryPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimSummaryPage claimSummaryPage = cpPageFactory
                .createGeneralClaim()
                .withContactCellNum()
                .goToSummary();

        claimSummaryPage.validateNewContactsDetailsOnSummaryPage().shouldBeEqual("New Contact Person details are not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateErrorMessageForMissingContactNumberOnContactPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimContactPersonPage contactPersonPage = cpPageFactory
                .createGeneralClaim()
                .withoutCellNumber();

        contactPersonPage.goNext();
        contactPersonPage.validatePhoneNumberMissingErrorOnOnContactPage().shouldBeEqual("Contact Number required error message is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateEmailErrorMessageOnContactPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimContactPersonPage contactPersonPage = cpPageFactory
                .createGeneralClaim();

        contactPersonPage.validateEmailFieldOnSummaryPage().shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void validateMandatoryErrorMessageForNewContactOnContactPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimContactPersonPage contactPersonPage = cpPageFactory
                .createGeneralClaim()
                .addNewContact()
                .addNewContact()
                .goNext();

        contactPersonPage.validateMandatoryErrorMessageForNewPersonFields().shouldBeTrue("Mandatory error message for New contact is not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testClaimIsNotSavedOnWhatHappenedPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundGLPolicy();

        NewClaimWhatHappenedPage whatHappenedPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext();
        CP_ClaimListPage claimListPage = whatHappenedPage.cancelWizardCP();

        claimListPage.isClaimListPageLoaded().shouldBeTrue("Claim list page is not displayed and Claim save popup is displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testClaimIsSavedAsDraftWhenCancelledOnWhatLocationPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewGeneralClaimDetails claimDetailsPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage();
        String draftNum = claimDetailsPage.getDraftClaimNumber();
        CP_ClaimListPage claimListPage = claimDetailsPage.cancelWizardCP();

        claimListPage.goToHome().validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testClaimIsSavedAsDraftWhenCancelledOnDocumentPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundIMPolicy();

        NewClaimDocumentPage documentPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage()
                .goNext();
        String draftNum = documentPage.getDraftClaimNumber();
        CP_ClaimListPage claimListPage = documentPage.cancelWizardCP();

        claimListPage.goToHome().validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testClaimIsSavedAsDraftWhenCancelledOnContactPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        NewClaimContactPersonPage contactPersonPage = cpPageFactory.login()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage()
                .goNext()
                .uploadDocFromFNOL()
                .withNewContactPerson()
                .goNext();
        String draftNum = contactPersonPage.getDraftClaimNumber();
        CP_ClaimListPage claimListPage = contactPersonPage.cancelWizardCP();

        claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
        ((NewClaimLocationPage) claimListPage.openPADraftClaim(draftNum))
                .goToDocumentPage()
                .areNewPersonDetailsAreSaved()
                .shouldBeTrue("New injured person's details are not correct");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testClaimIsSavedAsDraftWhenCancelledOnSummaryPageGeneralClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundGLPolicy();

        NewClaimSummaryPage summaryPage = cpPageFactory
                .createGeneralClaim()
                .withContactCellNum()
                .goToSummary();
        String draftNum = summaryPage.getDraftClaimNumber();
        CP_ClaimListPage claimListPage = summaryPage.cancelWizardCP();

        claimListPage.validateClaimDraftStatus(draftNum).shouldBeEqual("Claim is not listed as draft claim");
    }
}
