package com.guidewire.capabilities.fnol.test.cp.cp;

import com.guidewire.capabilities.common.dto.PropertyDTO;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.*;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.guidewire.capabilities.claims.model.page.CP_ClaimListPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;

import java.util.List;

public class CP_CPFileAClaimTest {

    CPPageFactory cpPageFactory = new CPPageFactory();

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testCPDefaultClaim(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundCPPolicy();

        NewClaimContactPersonPage page = cpPageFactory.createBasicCPClaimWithDefault();

        String claimNum = page
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);
        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testCPClaimWithManyBuildingsAndPagination(String browserName) throws Exception {
        int buildingMatrix = 6;
        PolicyGenerator.createBasicBoundCPPolicy(buildingMatrix, buildingMatrix);

        NewClaimPropertiesSelectionPage page = cpPageFactory.createBasicCPClaimForPropertySelection();

        String claimNum = page
                .addProperties(buildingMatrix * buildingMatrix)
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);
        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testCPClaimWithManyBuildingsAndPaginationAndSearch(String browserName) throws Exception {
        int buildingMatrix = 10;
        PolicyGenerator.createBasicBoundCPPolicy(buildingMatrix, buildingMatrix);

        NewClaimPropertiesSelectionPage page = cpPageFactory.createBasicCPClaimForPropertySelection();

        page.nextPage();
        page.addProperties(1);

        List<PropertyDTO> selectedProperties = PropertyDTO.fromJson(ThreadLocalObject.getData().get("SELECTED_PROPERTIES"));
        page.searchProperty(selectedProperties.get(0).getBuildingNumber());
        page.nextPage();
        page.addProperties(1);

        selectedProperties = PropertyDTO.fromJson(ThreadLocalObject.getData().get("SELECTED_PROPERTIES"));

        page.searchProperty(selectedProperties.get(0).getDescription());
        page.verifySelectedProperty(selectedProperties.get(0))
                .shouldBeTrue("CP Property not selected or not searched by description");
        page.searchProperty("");

        page.searchProperty(selectedProperties.get(0).getAddress());
        page.verifySelectedProperty(selectedProperties.get(0))
                .shouldBeTrue("CP Property not selected or not searched by address");
        page.searchProperty("");

        page.searchProperty(selectedProperties.get(0).getLocationNumber());
        page.verifySelectedProperty(selectedProperties.get(0))
                .shouldBeTrue("CP Property not selected or not searched by location number");
        page.searchProperty("");

        page.searchProperty(selectedProperties.get(0).getBuildingNumber());
        page.verifySelectedProperty(selectedProperties.get(0))
                .shouldBeTrue("CP Property not selected or not searched by building number");
        page.searchProperty("");
        page.searchProperty(selectedProperties.get(0).getBuildingNumber());
        page.verifySelectedProperty(selectedProperties.get(1))
                .shouldBeTrue("CP Property not selected or not searched by building number");

        String claimNum = page
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .setContactData()
                .withContactCellNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);
        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testClaimIsSavedAsDraftWhenCancelledOnPropertyDetailsPage(String browserName) throws Exception {
        int propertiesPerLocation = 2;
        PolicyGenerator.createBasicBoundCPPolicy(propertiesPerLocation * 2, propertiesPerLocation);

        PropertyDetailsPage propertyDetailsPage = cpPageFactory
                .openBasicCPClaimWithMultiplePropertiesSelected(propertiesPerLocation + 1);

        String draftClaimNumber = propertyDetailsPage.getDraftClaimNumber();
        propertyDetailsPage = propertyDetailsPage
                .setDefaultPropertyData()
                .provideDataForAllListedLocations()
                .cancelClaim()
                .openCPDraftClaim(draftClaimNumber);

        propertyDetailsPage
                .containsAllFieldsFulfilled()
                .shouldBeTrue("CP Claim Draft does not persist provided data regarding property details");

        NewClaimPropertiesSelectionPage propertiesSelectionPage = propertyDetailsPage
                .goBackToPropertiesSelection();

        propertiesSelectionPage
                .containsAllSelectedProperties()
                .shouldBeTrue("CP Claim Draft does not persist selected properties");

        String claimNum = propertiesSelectionPage
                .addMoreProperties(1)
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);

        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testClaimDataPersistsWhileMovingAcrossWizardSteps(String browserName) throws Exception {
        int propertiesPerLocation = 2;
        PolicyGenerator.createBasicBoundCPPolicy(propertiesPerLocation * 2, propertiesPerLocation);

        PropertyDetailsPage propertyDetailsPage = cpPageFactory
                .openBasicCPClaimWithMultiplePropertiesSelected(propertiesPerLocation + 1)
                .setDefaultPropertyData()
                .provideDataForAllListedLocations()
                .goNext()
                .goBackToPropertyDetailsPage();

        propertyDetailsPage
                .containsAllFieldsFulfilled()
                .shouldBeTrue("CP Claim Wizard does persist property details while moving forward to loss location and getting back");

        NewClaimPropertiesSelectionPage propertiesSelectionPage = propertyDetailsPage.goBackToPropertiesSelection();

        propertiesSelectionPage
                .containsAllSelectedProperties()
                .shouldBeTrue("CP Claim Wizard does not persist selected properties while moving forward and back");

        String claimNum = propertiesSelectionPage
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);

        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR", "REG_DIA"})
    public void testClaimDataPersistsWhileNavJumpingAcrossWizardSteps(String browserName) throws Exception {
        int propertiesPerLocation = 2;
        PolicyGenerator.createBasicBoundCPPolicy(propertiesPerLocation * 2, propertiesPerLocation);

        NewClaimPropertiesSelectionPage propertiesSelectionPage = cpPageFactory
                .openBasicCPClaimWithMultiplePropertiesSelected(propertiesPerLocation + 1)
                .setDefaultPropertyData()
                .provideDataForAllListedLocations()
                .goNext()
                .jumpDirectlyToPropertySelectionPage();

        propertiesSelectionPage
                .containsAllSelectedProperties()
                .shouldBeTrue("CP Claim Wizard does not persist selected properties while jumping across steps with left nav panel");

        PropertyDetailsPage propertyDetailsPage = propertiesSelectionPage
                .goNext()
                .goNext()
                .jumpDirectlyToPropertyDetailsPage();

        propertyDetailsPage
                .containsAllFieldsFulfilled()
                .shouldBeTrue("CP Claim Wizard does not persist provided property details while jumping across steps with left nav panel");

        String claimNum = propertyDetailsPage
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        ClaimSummaryPage claimSummary = new CP_ClaimListPage()
                .goToHome()
                .openClaimSummary(claimNum);

        claimSummary
                .isCPPropertiesMatchingWithBackEnd(claimNum)
                .shouldBeTrue("CP Claim does not contains all related buildings");
    }
}
