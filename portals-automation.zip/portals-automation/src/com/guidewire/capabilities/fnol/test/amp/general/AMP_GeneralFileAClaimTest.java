package com.guidewire.capabilities.fnol.test.amp.general;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.claimportal.pages.ClaimListPage;
import com.guidewire.portals.claimportal.pages.ClaimSummaryPage;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AMP_GeneralFileAClaimTest {
    Pagefactory pagefactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testGeneralBOClaimCreation(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundBOPolicy();

        String claimNum = pagefactory.createGeneralClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage.goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new ClaimListPage().openClaimSummary(claimNum);

        claimSummary.isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testGeneralIMClaimCreation(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundIMPolicy();

        String claimNum = pagefactory.createGeneralClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage.goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new ClaimListPage().openClaimSummary(claimNum);

        claimSummary.isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data does not match with the Back End");
    }

    @Parameters("browserName")
    @Test(groups = {"FNOL"})
    public void testGeneralGLClaimCreation(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundGLPolicy();

        String claimNum = pagefactory.createGeneralClaim()
                .withContactHomeNum()
                .goToSummary()
                .submitClaim()
                .getClaimNumber();

        AccountSummaryPage summaryPage = new AccountSummaryPage();
        summaryPage.goToHome()
                .goToClaimsPage()
                .validateClaimListing(claimNum)
                .shouldBeTrue("Claim is not listed");

        ClaimSummaryPage claimSummary = new ClaimListPage().openClaimSummary(claimNum);

        claimSummary.isHOPageDisplayedCorrectly().shouldBeTrue("Claim summary page not displayed correctly. Missing fields/section.");
        claimSummary.isClaimSummaryDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Summary Data does not match with the Back End");
        claimSummary.isClaimDetailsDataMatchingWithBackEnd(claimNum).shouldBeTrue("Claim Details Data does not match with the Back End");
    }
}
