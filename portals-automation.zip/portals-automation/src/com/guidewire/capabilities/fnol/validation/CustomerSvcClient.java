
package com.guidewire.capabilities.fnol.validation;

import java.io.IOException;

import org.apache.commons.httpclient.HttpConnection;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpConnectionParams;
 
public class CustomerSvcClient {
     
    private static final String host="localhost";
    private static final String port="8080";
     
    public static String invokeCustomerSvc(String payload,String endpointURL){
         String wellformedrequest=null;
         String serviceResponse=null;
         HttpConnection httpConn=null;
         try {
            println(" ---- Creating HTTP Connection ----");
            httpConn=new HttpConnection(host,Integer.parseInt(port));
            httpConn.open();
            HttpConnectionParams param = new HttpConnectionParams();
//            param.setParameter("Accept-Encoding", "gzip,deflate");
//            param.setParameter("Content-Type" ,"application/soap+xml;charset=UTF-8");
//            param.setParameter("Content-Length", "648");
//            param.setParameter("Connection", "Keep-Alive");
//            param.setParameter("Host", "mmportal8.guidewire.com:8080");
//            param.setParameter("User-Agent", "Apache-HttpClient/4.1.1 (java 1.5)");
           
            httpConn.setParams(param);
           
            PostMethod postMethod=new PostMethod();
             /**
              * Set Endpoint URL
              */
            postMethod.setPath(endpointURL);
            postMethod.setRequestEntity(new StringRequestEntity(payload.replace("CLAIM-NUMBER", "000-00-050016"), "application/soap+xml", "utf-8"));
            postMethod.execute(new HttpState(), httpConn);
            println("HTTP Response Status :"+postMethod.getStatusLine().toString());
            serviceResponse=postMethod.getResponseBodyAsString();
            println("Service Response :"+serviceResponse);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            httpConn.releaseConnection();
        }
         return serviceResponse;
    }
     
    private static void println(Object content){
        System.out.println(content);
    }

    
    private static String createClaimOnPolicy()
    {
    	 // and here comes some dummy SOAP message
		String reqStr = "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap1=\"http://guidewire.com/ws/soapheaders\"               :tes=\"http://guidewire.com/cc/ws/gw/webservice/TestAPI\">"
				 + "<soap:Header>" + "<soap1:locale>en_US</soap1:locale>"
				+ "<soap1:authentication>" + "<soap1:username>su</soap1:username>" + "<soap1:password>gw</soap1:password>" + "</soap1:authentication>"
				 +" </soap:Header>"
				 	+ "<soap:Body>"
				 		+ "<tes:createAutoClaimOnPolicy>"
				 				+"<tes:policyNumber>54-253465</tes:policyNumber>"
				 			+"</tes:createAutoClaimOnPolicy>"
				 	+ "</soap:Body>"
				 + "</soap1:Envelope>";
		
		return reqStr;
    }
     
    private static String getCheckStatusRequest(){
    	// and here comes some dummy SOAP message
    			String statusRequest = 
    					
    					"<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:soap1=\"http://guidewire.com/ws/soapheaders\" xmlns:pcc=\"http://guidewire.com/cc/ws/gw/webservice/cc/cc800/pcintegration/PCClaimSearchIntegrationAPI\">"
    					+ "<soap:Header>" + "<soap1:locale>en_US</soap1:locale>" +
    						"<soap1:authentication>" + 
    							"<soap1:username>su</soap1:username>" + 
    							"<soap1:password>gw</soap1:password>" + 
    						"</soap1:authentication>"
    					 +" </soap:Header>"
    					 	+ "<soap:Body>"
    					 		+ "<pcc:getClaimByClaimNumber>"
    					 				+ "<pcc:claimNumber>CLAIM-NUMBER</pcc:claimNumber>"
    					 		+ "</pcc:getClaimByClaimNumber>"
    					 	+ "</soap:Body>"
    					 + "</soap:Envelope>";
        return statusRequest;
    }
     
    public static void main(String[] args) {
        String endpointURL="http://localhost:8080/cc/ws/gw/webservice/TestAPI?WSDL";
        //String endpointURL="http://localhost:8080/cc/ws/gw/webservice/cc/cc800/pcintegration/PCClaimSearchIntegrationAPI?WSDL";
        
        /**
         * Call CheckStatus Service
         */
        invokeCustomerSvc(createClaimOnPolicy(), endpointURL);
     
    }
 
}
