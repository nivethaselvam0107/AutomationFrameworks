package com.guidewire.capabilities.fnol.model.page;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.capabilities.common.interfaces.ISearchPlacesPage;
import com.guidewire.capabilities.common.interfaces.IVendorListPage;
import com.guidewire.capabilities.common.interfaces.IWizardPage;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.ClaimData;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimWizardPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import com.guidewire.widgetcomponents.Select;

public class NewClaimRecommendedRepairFacilityPage
        extends ClaimWizardPage
        implements IVendorListPage, IWizardPage, ISearchPlacesPage {

    Logger logger = Logger.getLogger(this.getClass().getName());


    private final String DESKTOP_MAP_CSS = "[map-name='repairFacilitiesMap']";
    private final String MOBILE_MAP_CSS = "[map-name='repairFacilitiesMapMobile']";
    @FindBy(css = DESKTOP_MAP_CSS)
    WebElement MAP;
    
    @FindBy(css = MOBILE_MAP_CSS)
    WebElement MOBILE_MAP;
    private final By DESKTOP_MARKERS_VENDOR_CSS = By.cssSelector(DESKTOP_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-wrench']");
    private final By MOBILE_MARKERS_VENDOR_CSS = By.cssSelector(MOBILE_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-wrench']");
    private String DESKTOP_MARKER_SPECIFIC_VENDOR_CSS = DESKTOP_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-wrench'][data-id='%s']";
    private String MOBILE_MARKER_SPECIFIC_VENDOR_CSS = MOBILE_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-wrench'][data-id='%s']";

    @FindBy(css = "[class*='RepairFacilitiesSearchOption'][ng-click*='policy'][role='button']")
    public WebElement LINK_POLICY_ADDRESS_CSS;

    private final By DESKTOP_MARKER_POLICY_ADDRESS_CSS = By.cssSelector(DESKTOP_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-home']");
    private final By MOBILE_MARKER_POLICY_ADDRESS_CSS = By.cssSelector(MOBILE_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-home']");

    @FindBy(css = "[class*='RepairFacilitiesSearchOption'][ng-click*='incident'][role='button']")
    public WebElement LINK_INCIDENT_ADDRESS_CSS;

    private final By DESKTOP_MARKER_INCIDENT_ADDRESS_CSS = By.cssSelector(DESKTOP_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-car']");
    private final By MOBILE_MARKER_INCIDENT_ADDRESS_CSS = By.cssSelector(MOBILE_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-car']");

    @FindBy(css = "[class*='RepairFacilitiesSearchOption'][ng-click*='navigator'][role='button']")
    public WebElement LINK_MY_LOCATION_ADDRESS_CSS;

    private final By DESKTOP_MARKER_MY_LOCATION_ADDRESS_CSS = By.cssSelector(DESKTOP_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-male']");
    private final By MOBILE_MARKER_MY_LOCATION_ADDRESS_CSS = By.cssSelector(MOBILE_MAP_CSS + " div[class*='CustomMarker'] i[class*='fa-male']");

    private final By DESKTOP_MARKER_INFO_POPUP_XPATH = By.xpath("//*[@class[contains(.,'vendorInformation')]]/..");
    private final By MOBILE_MARKER_INFO_POPUP_CSS = By.cssSelector("[class*='RepairFacilityDetails'][class*='detail']:not(button)");

    @FindBy(css = "[class*='RepairFacilitySelector'][type='button'][ng-click='$ctrl.selectFacility()']")
    public WebElement MOBILE_BTN_SEARCH_ON_MAP_CSS;

    private final By MOBILE_SELECT_SEARCH_CSS = By.cssSelector("[ng-model='$ctrl.searchOption']");

    @FindBy(css = "[role='button'][ng-click='onBack()'] span[class*='arrow']")
    public WebElement MOBILE_BACK_ARROW_CSS;

    @FindBy(css = "gw-fnol-pa-repair-facilities-list ul")
    WebElement VENDOR_LIST_CSS;

    @FindBy(css = "[ng-show='explicitErrorMessage'] [class*='gw-error-inline']")
    WebElement ERROR_TEXT;


    private final By VENDORS_FROM_LIST_XPATH = By.cssSelector("li[ng-repeat*='repairFacilities'] p[class*='primaryDetail']");
    private final By VENDORS_ITEMS_FROM_LIST_XPATH = By.cssSelector("li[ng-repeat*='repairFacilities']");
    private final By VENDORS_FROM_LIST_ADDRESS = By.xpath("//gw-fnol-pa-repair-facilities-list//ul/li//p[2]");
    private final By VENDORS_FROM_LIST_MILES = By.xpath("//gw-fnol-pa-repair-facilities-list//ul/li//p[3]");
    private final By VENDORS_FROM_LIST_RATING = By.xpath("//gw-fnol-pa-repair-facilities-list//ul/li//gw-fnol-pa-repair-facility-rating");
    private final By SELECTED_VENDOR = By.cssSelector("li[class*='RepairFacilitiesList-hashed__selected'] div p:first-child");
    private final By SELECTED_VENDOR_RATING = By.cssSelector("[class*='RepairFacilityRating-hashed__selected']");
    private final By REPAIR_HERE_BTN_CSS = By.cssSelector("button[ng-click='$ctrl.acceptRepair()']");
    private boolean BLN_SHARE_LOCATION = false;
    private boolean BLN_DESKTOP_RESIZED_TO_MOBILE = false;

    public NewClaimDocumentPage goNext() {
        logger.info("Going to doc uploads page");
        if (BrowserType.phone.contains(browserType)) {
            seleniumCommands.clickbyJS(REPAIR_HERE_BTN_CSS);
        } else {
            clickNext();
        }
        return new NewClaimDocumentPage();
    }

    public NewClaimRepairChoicePage goPrevious() {
        logger.info("Going to repair choice page");
        clickPrevious();
        return new NewClaimRepairChoicePage();
    }

    @Override
    public Validation isPageLoaded() {
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            seleniumCommands.waitForElementToBeClickable(MOBILE_SELECT_SEARCH_CSS);
            new Validation(getSelectedSearchNearOnMobile(), "Policy address").shouldBeEqual();
        } else {
            seleniumCommands.waitForElementToBeVisible(DESKTOP_MARKER_POLICY_ADDRESS_CSS);
            seleniumCommands.waitForElementToBeClickable(VENDOR_LIST_CSS);
            new Validation(seleniumCommands.isElementPresent(DESKTOP_MARKER_POLICY_ADDRESS_CSS)).shouldBeTrue();
        }
        return new Validation(true);
    }

    public VendorDto selectRandomVendorFromMap() {
        List<String> vendorMarkersIds = this.getVendorMarkerIds();

        Random generator = new Random();
        int i = generator.nextInt(vendorMarkersIds.size());
        logger.info("Selecting random vendor # " + i);
        String vendorId = vendorMarkersIds.get(i);
        this.selectVendorFromMap(vendorId);
        return this.getVendorDataFromId(vendorId);
    }

    public NewClaimRecommendedRepairFacilityPage selectVendorFromMap(String vendorID) {
        logger.info(String.format("Selecting vendor id[%s] by clicking marker on the map",vendorID));
        By vendorSelector;
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            vendorSelector = By.cssSelector(String.format(MOBILE_MARKER_SPECIFIC_VENDOR_CSS, vendorID));
            seleniumCommands.click(MOBILE_BTN_SEARCH_ON_MAP_CSS);
            seleniumCommands.waitForElementToBeClickable(MOBILE_MAP);
            seleniumCommands.waitForElement(vendorSelector);
            seleniumCommands.clickbyJS(vendorSelector);
            seleniumCommands.waitForElementToBeClickable(MOBILE_MARKER_INFO_POPUP_CSS);
        } else {
            vendorSelector = By.cssSelector(String.format(DESKTOP_MARKER_SPECIFIC_VENDOR_CSS, vendorID));
            seleniumCommands.waitForElementToBeClickable(MAP);
            seleniumCommands.waitForElement(vendorSelector);
            seleniumCommands.clickbyJS(vendorSelector);
            seleniumCommands.waitForElementToBeClickable(DESKTOP_MARKER_INFO_POPUP_XPATH);
        }

        return this;
    }

    public NewClaimRecommendedRepairFacilityPage selectVendor(String vendorName) {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        ThreadLocalObject.getData().put(ClaimData.VENDOR_NAME.getValue(), vendorName);
        return this.selectVendor();
    }

    @Override
    public NewClaimRecommendedRepairFacilityPage selectVendor() {
        String vendorName;
        if ((vendorName = data.get(ClaimData.VENDOR_NAME.getValue())) == null) {
            return this.selectFirstAvailableVendor();
        }

        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_FROM_LIST_XPATH, 0);
        WebElement vendor = seleniumCommands.findElements(VENDORS_FROM_LIST_XPATH)
                .stream()
                .filter( e -> e.getText().equals(vendorName))
                .findFirst()
                .get();
        seleniumCommands.clickbyJS(vendor);

        if (!(BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE)) {
            seleniumCommands.waitForElementToBeClickable(MAP);
        }

        return this;
    }

    @Override
    public NewClaimRecommendedRepairFacilityPage selectFirstAvailableVendor() {
        seleniumCommands.waitForElementToBeClickable(VENDOR_LIST_CSS);
        seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_FROM_LIST_XPATH, 0);
        seleniumCommands.waitForElementToBeClickable(VENDORS_FROM_LIST_XPATH);

        WebElement vendorName = seleniumCommands.findElements(VENDORS_FROM_LIST_XPATH).get(0);
        data.put("VendorName", vendorName.getText());
        WebElement vendorAddress = seleniumCommands.findElements(VENDORS_FROM_LIST_ADDRESS).get(0);
        data.put("VendorAddress", vendorAddress.getText());
        WebElement vendorRating = seleniumCommands.findElements(VENDORS_FROM_LIST_RATING).get(0);
        data.put("VendorRating", vendorRating.getText());
        vendorName.click();
        seleniumCommands.waitForElementToBeClickable(SELECTED_VENDOR);

        return this;
    }

    @Override
    public Validation validateSelectedVendor() {
        logger.info("Validating Selected Vendor Name");
        seleniumCommands.waitForElementToBeClickable(VENDOR_LIST_CSS);
        return new Validation(
                seleniumCommands.findElement(SELECTED_VENDOR).getText().equals(data.get("VendorName")) &&
                seleniumCommands.findElement(SELECTED_VENDOR_RATING).getText().equals(data.get("VendorRating"))
        );
    }

    public Validation isVendorSorted() {
        seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_FROM_LIST_XPATH, 0);
        List<String> vendorData = new ArrayList<>();
        By selector;
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            selector = VENDORS_FROM_LIST_MILES;
        } else {
            selector = VENDORS_FROM_LIST_XPATH;
        }
        seleniumCommands.findElements(selector).forEach(vendorName -> vendorData.add(seleniumCommands.getTextAtLocator(vendorName)));
        return this.isVendorSorted(vendorData);
    }

    public void setMobileDimension() {
        //in case not mobile browser set, using resized desktop view imitating mobile
        if (!BrowserType.mobile.contains(browserType)) {
            seleniumCommands.setWindowDimensions(600, 730);
            BLN_DESKTOP_RESIZED_TO_MOBILE = true;
        }
    }

    public Validation isVendorSorted(List<String> collection) {
        List<String> actualCollection = collection;
        List<String> expectedCollection = collection;
        Collections.sort(expectedCollection);

        for(int i=0; i< expectedCollection.size(); i++) {
            if(!expectedCollection.get(i).equals(actualCollection.get(i))) {
                logger.error(String.format("\t EXPECTED VALUE[%s]", expectedCollection.get(i)));
                logger.error(String.format("\t ACTUAL VALUE[%s]", actualCollection.get(i)));
                return new Validation(false);
            }
        }

        return new Validation(true);
    }

    private void selectSearchNearOnMobile(String valueToSelect) {
        Select searchNearSelect = new Select(seleniumCommands.findElement(MOBILE_SELECT_SEARCH_CSS));
        searchNearSelect.setValue(valueToSelect);
    }

    private String getSelectedSearchNearOnMobile() {
        Select searchNearSelect = new Select(seleniumCommands.findElement(MOBILE_SELECT_SEARCH_CSS));
        return searchNearSelect.getValue();
    }

    public NewClaimRecommendedRepairFacilityPage searchNearPolicyAddress() {
        logger.info("Searching near policy address");
        if (seleniumCommands.isElementClickable(MOBILE_SELECT_SEARCH_CSS)) {
            this.selectSearchNearOnMobile("Policy address");
        } else {
            seleniumCommands.click(LINK_POLICY_ADDRESS_CSS);
        }
        return this;
    }

    public NewClaimRecommendedRepairFacilityPage searchNearIncidentAddress() {
        logger.info("Searching near incident address");
        if (seleniumCommands.isElementClickable(MOBILE_SELECT_SEARCH_CSS)) {
            this.selectSearchNearOnMobile("Incident");
        } else {
            seleniumCommands.click(LINK_INCIDENT_ADDRESS_CSS);
        }
        return this;
    }

    public NewClaimRecommendedRepairFacilityPage searchNearMyLocationAddress() {
        if (seleniumCommands.isElementVisible(LINK_MY_LOCATION_ADDRESS_CSS)) {
            this.BLN_SHARE_LOCATION = true;
            logger.info("Searching near my location address");
            if (seleniumCommands.isElementClickable(MOBILE_SELECT_SEARCH_CSS)) {
                this.selectSearchNearOnMobile("My current location");
            } else {
                seleniumCommands.click(LINK_MY_LOCATION_ADDRESS_CSS);
            }
        } else {
            logger.warn("My location not available in the session");
        }
        return this;
    }

    private Validation isIconLoadedOnMap(By iconSelector) {
        seleniumCommands.waitForElementToBeVisible(iconSelector);
        return new Validation(seleniumCommands.isElementPresent(iconSelector));
    }

    public Validation isPolicyAddressLoadedOnMap() {
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE)
            return this.isIconLoadedOnMap(MOBILE_MARKER_POLICY_ADDRESS_CSS);
        else
            return this.isIconLoadedOnMap(DESKTOP_MARKER_POLICY_ADDRESS_CSS);
    }

    public Validation isIncidentAddressLoadedOnMap() {
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            return this.isIconLoadedOnMap(MOBILE_MARKER_INCIDENT_ADDRESS_CSS);
        }
        return this.isIconLoadedOnMap(DESKTOP_MARKER_INCIDENT_ADDRESS_CSS);
    }

    public Validation isMyLocationAddressLoadedOnMap() {
        if (BLN_SHARE_LOCATION) {
            if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
                return this.isIconLoadedOnMap(MOBILE_MARKER_MY_LOCATION_ADDRESS_CSS);
            }
            return this.isIconLoadedOnMap(DESKTOP_MARKER_MY_LOCATION_ADDRESS_CSS);
        }
        return new Validation(true);
    }

    public NewClaimRecommendedRepairFacilityPage searchOnMobileMap() {
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            seleniumCommands.click(MOBILE_BTN_SEARCH_ON_MAP_CSS);
            seleniumCommands.waitForElementToBeClickable(MOBILE_MAP);
        }
        return this;
    }

    public NewClaimRecommendedRepairFacilityPage backToMobileList() {
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            seleniumCommands.click(MOBILE_BACK_ARROW_CSS);
        }
        return this;
    }

    public Validation validateRecommendedFacilityErrorMessage() {
        logger.info("Validating the Mandatory Error for Recommended facility choice");
        return new Validation(seleniumCommands.getTextAtLocator(ERROR_TEXT), DataConstant.NO_REPAIR_FACILITY_SELECTED_ERROR);
    }

    private Validation isVendorInfoDisplayedProperly(VendorDto vendorDto, By elementSelector) {
        String expectedData = "";
        expectedData += vendorDto.VendorName;
        expectedData += vendorDto.Address;
        expectedData += vendorDto.Phone;
        expectedData += vendorDto.Email;
        expectedData += new BigDecimal(vendorDto.Score/100.0*5)
                .setScale(1, RoundingMode.HALF_EVEN);

        seleniumCommands.waitForElementToBeVisible(elementSelector);
        List<String> tmpData = new ArrayList<>();
        seleniumCommands.findElements(elementSelector).forEach (
                    el -> tmpData.add(seleniumCommands.getTextAtLocator(el).replaceAll("\\n|,", ""))
                );
        String actualData = tmpData.toString().replaceAll(",| |\\[|\\]","");
        expectedData = expectedData.replaceAll(",| ","");
        return new Validation(actualData, expectedData);
    }

    public Validation validateSelectedVendorPopupInfo(VendorDto vendorDto) {
        seleniumCommands.logInfo("Validating info popup for selected vendor");
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            seleniumCommands.waitForElementToBeVisible(MOBILE_MARKER_INFO_POPUP_CSS);
            new Validation(seleniumCommands.findElements(MOBILE_MARKERS_VENDOR_CSS).size() == 1).shouldBeTrue("No (or too many) vendor markers displayed on mobile view.");
            return this.isVendorInfoDisplayedProperly(vendorDto, MOBILE_MARKER_INFO_POPUP_CSS);
        }
        return this.isVendorInfoDisplayedProperly(vendorDto, DESKTOP_MARKER_INFO_POPUP_XPATH);
    }

    private List<String> getVendorListData() {
        List<String> vendorsList = new ArrayList<>();
        seleniumCommands.findElements(VENDORS_FROM_LIST_XPATH).forEach(
                el -> vendorsList.add(seleniumCommands.getTextAtLocator(el))
        );
        return vendorsList;
    }

    private List<String> getVendorMarkerIds() {
        List<String> vendorIDsList = new ArrayList<>();
        By vendorMarkers;
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            vendorMarkers = MOBILE_MARKERS_VENDOR_CSS;
            if (seleniumCommands.isElementNotPresent(By.cssSelector(MOBILE_MAP_CSS))) {
                this.searchOnMobileMap();
            }
        } else {
            vendorMarkers = DESKTOP_MARKERS_VENDOR_CSS;
        }

        seleniumCommands.waitForElementListHaveMoreValuesThan(vendorMarkers, 0);
        seleniumCommands.findElements(vendorMarkers).forEach(
                el -> vendorIDsList.add(seleniumCommands.getAttributeValueAtLocator(el, "data-id"))
        );

        if (seleniumCommands.isElementPresent(By.cssSelector(MOBILE_MAP_CSS))) {
            seleniumCommands.click(MOBILE_BACK_ARROW_CSS);
        }

        return vendorIDsList;
    }

    private List<VendorDto> getVendorDataFromMapObject() {
        WebElement mapComponent;
        By markersSelector;
        if (BrowserType.phone.contains(browserType) || BLN_DESKTOP_RESIZED_TO_MOBILE) {
            mapComponent = MOBILE_MAP;
            markersSelector = MOBILE_MARKERS_VENDOR_CSS;
            if (seleniumCommands.isElementNotPresent(By.cssSelector(MOBILE_MAP_CSS))) {
                this.searchOnMobileMap();
            }
        } else {
            mapComponent = MAP;
            markersSelector = DESKTOP_MARKERS_VENDOR_CSS;
            seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_FROM_LIST_XPATH, 0);
        }
        seleniumCommands.waitForElementToBeClickable(mapComponent);
        seleniumCommands.waitForElementListHaveMoreValuesThan(markersSelector, 0);
        List<Object> vendorsFromTheMapObject = (List<Object>) seleniumCommands.getAngularScopeItem(mapComponent, "$ctrl.repairFacilities");
        List<VendorDto> vendorData = new ArrayList<>();
        vendorsFromTheMapObject.forEach( vendor ->
            {
                VendorDto vendorDto = new VendorDto();
                vendorDto.PublicID = ((Map<String, String>) vendor).get("addressBookUID");
                vendorDto.VendorName = ((Map<String, String>) vendor).get("contactName");
                vendorDto.Email = ((Map<String, String>) vendor).get("emailAddress1");
                vendorDto.Phone = ((Map<String, String>) vendor).get("workNumber");
                if (((Map<String, Long>) vendor).get("score") == null) {
                    vendorDto.Score = 0L;
                } else {
                    vendorDto.Score = ((Map<String, Long>) vendor).get("score");
                }
                vendorDto.Address = ((Map<String, String>) (((Map<String, Object>) vendor).get("primaryAddress"))).get("displayName");
                vendorData.add(vendorDto);
            }

        );

        if (seleniumCommands.isElementPresent(By.cssSelector(MOBILE_MAP_CSS))) {
            seleniumCommands.click(MOBILE_BACK_ARROW_CSS);
        }

        return vendorData;
    }

    public VendorDto getVendorData() {
        return getVendorData(data.get(ClaimData.VENDOR_NAME.getValue()));
    }

    public VendorDto getVendorData(String vendorName) {
        List<VendorDto> vendorsFromTheMapObject = this.getVendorDataFromMapObject();
        return vendorsFromTheMapObject.stream()
                .filter(vendorDataFromMap -> vendorName.equals(vendorDataFromMap.VendorName))
                .findFirst()
                .get();
    }

    public VendorDto getVendorDataFromId(String vendorId) {
        List<VendorDto> vendorsFromTheMapObject = this.getVendorDataFromMapObject();
        return vendorsFromTheMapObject.stream()
                .filter(vendorDataFromMap -> vendorId.equals(vendorDataFromMap.PublicID))
                .findFirst()
                .get();
    }

    private List<String> getVendorMarkersData() {
        List<String> vendorIDsList = this.getVendorMarkerIds();
        List<VendorDto> vendorsFromTheMapObject = this.getVendorDataFromMapObject();
        List<String> vendorNames = new ArrayList<>();

        vendorsFromTheMapObject.forEach( vendorDataFromMap -> {
            if (vendorIDsList.contains(vendorDataFromMap.PublicID)) {
                vendorNames.add(vendorDataFromMap.VendorName);
            }
        });

        if (seleniumCommands.isElementPresent(By.cssSelector(MOBILE_MAP_CSS))) {
            seleniumCommands.click(MOBILE_BACK_ARROW_CSS);
        }

        return vendorNames;
    }

    public Validation validateVendorMarkersDataAgainstListVendorData() {
        List<String> vendorMarkersData = this.getVendorMarkersData();
        List<String> vendorListData = this.getVendorListData();
        boolean result = false;

        if (vendorMarkersData.size() == vendorListData.size()) {
            for (int i=0; i < vendorMarkersData.size(); i++) {
                if (!vendorListData.contains(vendorMarkersData.get((i)))) {
                    break;
                }
                result = true;
            }
        }
        return new Validation(result);
    }

    private By SEARCH_PLACES_INPUT = By.cssSelector("[class*='MapSearch-hashed__toggle'] input");
    private By SEARCH_PLACES_POLICY_LOCATION = By.cssSelector("[class*='MapSearch-hashed__place'][ng-click^='$ctrl.selectSearchAddress'][ng-click*='policy']");
    private By SEARCH_PLACES_LOSS_LOCATION = By.cssSelector("[class*='MapSearch-hashed__place'][ng-click^='$ctrl.selectSearchAddress'][ng-click*='incident']");
    private By SEARCH_PLACES_RESULT = By.cssSelector("[class*='MapSearch-hashed__place'][ng-click='$ctrl.selectPlace(place)']");
    private By SEARCH_PLACES_LIST_FIRST_RESULT = By.cssSelector("[class*='MapSearch-hashed__dropdown'][aria-hidden='false'] [class*='MapSearch-hashed__placeList'] [class*='MapSearch-hashed__place']");
    private String LAST_SEARCH_REQUEST;
    private boolean MOBILE_SEARCH_MAP_OPENED = false;

    @Override
    public ISearchPlacesPage searchPlaceByText(String text) {
        seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_FROM_LIST_XPATH, 0);

        if (!MOBILE_SEARCH_MAP_OPENED && seleniumCommands.isMobileView()) {
            BLN_DESKTOP_RESIZED_TO_MOBILE = true;
            MOBILE_SEARCH_MAP_OPENED = true;
            seleniumCommands.click(MOBILE_BTN_SEARCH_ON_MAP_CSS);
            seleniumCommands.waitForElementToBeClickable(MOBILE_MAP);
        } else {
            seleniumCommands.waitForElementToBeClickable(MAP);
        }

        seleniumCommands.waitForElementToBeClickable(SEARCH_PLACES_INPUT);
        seleniumCommands.click(SEARCH_PLACES_INPUT);

        if (text == null || text.isEmpty()) {
            seleniumCommands.type(SEARCH_PLACES_INPUT, "");
        } else {
            String firstResult = seleniumCommands.findElement(SEARCH_PLACES_LIST_FIRST_RESULT).getText();
            String secondResult = firstResult;

            seleniumCommands.waitRefreshWithAction(
                    SEARCH_PLACES_LIST_FIRST_RESULT,
                    SEARCH_PLACES_INPUT,
                    text,
                    seleniumCommands::type
            );
        }

        LAST_SEARCH_REQUEST = text;

        return this;
    }

    @Override
    public ISearchPlacesPage selectFirstPlace() {
        seleniumCommands.waitForElementToBeClickable(SEARCH_PLACES_LIST_FIRST_RESULT);
        WebElement first = seleniumCommands.findElement(SEARCH_PLACES_LIST_FIRST_RESULT);
        LAST_SEARCH_REQUEST = first.getText();
        seleniumCommands.click(first);

        return this;
    }

    @Override
    public ISearchPlacesPage clearSearchInput() {
        seleniumCommands.waitForElementToBeClickable(SEARCH_PLACES_INPUT);
        seleniumCommands.click(SEARCH_PLACES_INPUT);
        seleniumCommands.type(SEARCH_PLACES_INPUT, "");
        LAST_SEARCH_REQUEST = "";

        return this;
    }

    @Override
    public ISearchPlacesPage selectPolicyLocation() {
        clearSearchInput();

        seleniumCommands.waitForElementToBeClickable(SEARCH_PLACES_POLICY_LOCATION);
        seleniumCommands.click(SEARCH_PLACES_POLICY_LOCATION);

        return this;
    }

    @Override
    public ISearchPlacesPage selectLossLocation() {
        clearSearchInput();

        seleniumCommands.waitForElementToBeClickable(SEARCH_PLACES_LOSS_LOCATION);
        seleniumCommands.click(SEARCH_PLACES_LOSS_LOCATION);

        return this;
    }

    @Override
    public Validation validateStaticLocations() {
        return new Validation(
                seleniumCommands.findElement(SEARCH_PLACES_POLICY_LOCATION).isDisplayed()
                && seleniumCommands.findElement(SEARCH_PLACES_LOSS_LOCATION).isDisplayed()
        );
    }

    @Override
    public Validation validateSearchResult() {
        seleniumCommands.waitForElementListHaveMoreValuesThan(SEARCH_PLACES_RESULT,0);
        boolean notContainsSearchRequest = seleniumCommands.findElements(SEARCH_PLACES_RESULT)
                .stream()
                .filter(el -> !el.getText().startsWith(LAST_SEARCH_REQUEST))
                .findFirst()
                .isPresent();
        return new Validation(!notContainsSearchRequest);
    }

    @Override
    public Validation validateSearchInputAfterSelection() {
        return new Validation(
                seleniumCommands.findElement(SEARCH_PLACES_INPUT).getAttribute("value").equals(LAST_SEARCH_REQUEST)
        );
    }

    @Override
    public Validation validatePolicyLocation() {
        return this.isPolicyAddressLoadedOnMap();
    }

    @Override
    public Validation validateLossLocation() {
        return this.isIncidentAddressLoadedOnMap();
    }

    public int getNumberOfVendors() {
        seleniumCommands.waitForElementListHaveMoreValuesThan(VENDORS_ITEMS_FROM_LIST_XPATH, 0);
        return seleniumCommands.findElements(VENDORS_ITEMS_FROM_LIST_XPATH).size();
    }
}
