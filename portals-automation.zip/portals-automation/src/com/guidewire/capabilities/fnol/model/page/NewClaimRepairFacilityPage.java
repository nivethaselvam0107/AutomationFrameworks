package com.guidewire.capabilities.fnol.model.page;

import com.guidewire.capabilities.common.dto.VendorDto;
import com.guidewire.capabilities.fnol.data.USStatesAbbreviations;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimWizardPage;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.guidewire.common.testNG.Validation;

import java.util.HashMap;
import java.util.List;

public class NewClaimRepairFacilityPage extends ClaimWizardPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    private final String DATA_REPAIR_FACILITY_NAME = "RepairFacilityName";
    private final String DATA_REPAIR_FACILITY_ADDRESS_LINE_1 = "RepairFacilityAddressLine1";
    private final String DATA_REPAIR_FACILITY_ADDRESS_LINE_2 = "RepairFacilityAddressLine2";
    private final String DATA_REPAIR_FACILITY_ADDRESS_LINE_3 = "RepairFacilityAddressLine3";
    private final String DATA_REPAIR_FACILITY_CITY = "RepairFacilityCity";
    private final String DATA_REPAIR_FACILITY_ZIP_CODE = "RepairFacilityZipCode";
    private final String DATA_REPAIR_FACILITY_STATE = "RepairFacilityState";
    private final String DATA_REPAIR_FACILITY_PHONE = "RepairFacilityPhone";
    private final String DATA_REPAIR_FACILITY_EMAIL = "RepairFacilityEmail";
    private final String DATA_REPAIR_FACILITY_TAX_ID = "RepairFacilityTaxId";

    @FindBy(css = "[model='repairFacility.contactName'] input")
    WebElement REPAIR_FACILITY_NAME_INPUT_CSS;

    @FindBy(css = "[model='address.addressLine1'] input")
    WebElement ADDRESS_LINE_1_CSS;

    @FindBy(css = "[model='address.addressLine2'] input")
    WebElement ADDRESS_LINE_2_CSS;

    @FindBy(css = "[model='address.addressLine3'] input")
    WebElement ADDRESS_LINE_3_CSS;

    @FindBy(css = "[model='address.city'] input")
    WebElement CITY_INPUT_CSS;

    @FindBy(css = "[model='address.postalCode'] input")
    WebElement ADDRESS_ZIP_CODE_CSS;

    @FindBy(css = "[model='address.state'] select")
    WebElement STATE_DROP_CSS;

    @FindBy(css = "[model='repairFacility.workNumber'] input")
    WebElement REPAIR_FACILITY_PHONE_CSS;

    @FindBy(css = "[model='repairFacility.emailAddress1'] input")
    WebElement REPAIR_FACILITY_EMAIL_CSS;

    @FindBy(css = "[model='repairFacility.taxID'] input")
    WebElement REPAIR_FACILITY_TAX_ID_CSS;

    @FindBy(css = "[model='repairFacility.contactName'] [class*='gw-error-inline']")
    WebElement FACILITY_NAME_ERROR_TEXT;

    @FindBy(css = "[model='address.city'] [class*='gw-error-inline']")
    WebElement CITY_ERROR_TEXT;

    @FindBy(css = "[model='address.state'] [class*='gw-error-inline']")
    WebElement STATE_ERROR_TEXT;

    public NewClaimRepairFacilityPage withRepairFacilityName() {
        seleniumCommands.type(REPAIR_FACILITY_NAME_INPUT_CSS, data.get(DATA_REPAIR_FACILITY_NAME));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityAddressLine1() {
        seleniumCommands.type(ADDRESS_LINE_1_CSS, data.get(DATA_REPAIR_FACILITY_ADDRESS_LINE_1));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityAddressLine2() {
        seleniumCommands.type(ADDRESS_LINE_2_CSS, data.get(DATA_REPAIR_FACILITY_ADDRESS_LINE_2));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityAddressLine3() {
        seleniumCommands.type(ADDRESS_LINE_3_CSS, data.get(DATA_REPAIR_FACILITY_ADDRESS_LINE_3));
        return this;
    }

    public NewClaimRepairFacilityPage withCity() {
        seleniumCommands.type(CITY_INPUT_CSS, data.get(DATA_REPAIR_FACILITY_CITY));
        return this;
    }

    public NewClaimRepairFacilityPage withZipCode() {
        seleniumCommands.type(ADDRESS_ZIP_CODE_CSS, data.get(DATA_REPAIR_FACILITY_ZIP_CODE));
        return this;
    }

    public NewClaimRepairFacilityPage withState() {
        seleniumCommands.selectDropDownValueByText(STATE_DROP_CSS, data.get(DATA_REPAIR_FACILITY_STATE));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityPhoneNumber() {
        seleniumCommands.type(REPAIR_FACILITY_PHONE_CSS, data.get(DATA_REPAIR_FACILITY_PHONE));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityEmail() {
        seleniumCommands.type(REPAIR_FACILITY_EMAIL_CSS, data.get(DATA_REPAIR_FACILITY_EMAIL));
        return this;
    }

    public NewClaimRepairFacilityPage withRepairFacilityTaxId() {
        seleniumCommands.type(REPAIR_FACILITY_TAX_ID_CSS, data.get(DATA_REPAIR_FACILITY_TAX_ID));
        return this;
    }

    public NewClaimRepairFacilityPage setDefaultContactData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(DATA_REPAIR_FACILITY_NAME, "Laszlo\'s Auto Body & Collision");
        data.putIfAbsent(DATA_REPAIR_FACILITY_ADDRESS_LINE_1, "Main Street");
        data.putIfAbsent(DATA_REPAIR_FACILITY_ADDRESS_LINE_2, "100a");
        data.putIfAbsent(DATA_REPAIR_FACILITY_ADDRESS_LINE_3, "Box 12");
        data.putIfAbsent(DATA_REPAIR_FACILITY_CITY, "Foster City");
        data.putIfAbsent(DATA_REPAIR_FACILITY_ZIP_CODE, "94404");
        data.putIfAbsent(DATA_REPAIR_FACILITY_STATE, "California");
        data.putIfAbsent(DATA_REPAIR_FACILITY_PHONE, "202-555-0198");
        data.putIfAbsent(DATA_REPAIR_FACILITY_EMAIL, "laszloauto@gw.com");
        data.putIfAbsent(DATA_REPAIR_FACILITY_TAX_ID, "123-45-6789");
        return this;
    }

    public NewClaimRepairFacilityPage withContactData() {
        return this.setDefaultContactData()
            .withRepairFacilityName()
            .withRepairFacilityAddressLine1()
            .withRepairFacilityAddressLine2()
            .withRepairFacilityAddressLine3()
            .withCity()
            .withZipCode()
            .withState()
            .withRepairFacilityPhoneNumber()
            .withRepairFacilityEmail()
            .withRepairFacilityTaxId();
    }

    public NewClaimDocumentPage goToDocumentPage() {
        logger.info("Going to doc uploads page");
        clickNext();
        return new NewClaimDocumentPage();
    }

    public Validation isPageLoaded() {
        return new Validation(seleniumCommands.isElementPresent(REPAIR_FACILITY_NAME_INPUT_CSS));
    }

    public Validation containsContactData() {
        String nameData = seleniumCommands.getValueAttributeFromLocator(REPAIR_FACILITY_NAME_INPUT_CSS);
        String cityData = seleniumCommands.getValueAttributeFromLocator(CITY_INPUT_CSS);
        String stateData = seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS);

        return new Validation(nameData != null && nameData.length() > 0 &&
                cityData != null && cityData.length() > 0 &&
                stateData != null && stateData.length() > 0);
    }

    public Validation validateRepairChoiceErrorMessagesPresent() {
        logger.info("Validating mandatory field error messages for new repair facility");
        boolean facilityNameErrorPresent = seleniumCommands.getTextAtLocator(FACILITY_NAME_ERROR_TEXT).equals(DataConstant.MANDATORY_ERROR_MSG);
        boolean cityErrorPresent = seleniumCommands.getTextAtLocator(CITY_ERROR_TEXT).equals(DataConstant.MANDATORY_ERROR_MSG);
        boolean stateErrorPresent = seleniumCommands.getTextAtLocator(STATE_ERROR_TEXT).equals(DataConstant.MANDATORY_ERROR_MSG);
        return new Validation(facilityNameErrorPresent && cityErrorPresent && stateErrorPresent);
    }

    public NewClaimRepairChoicePage getBackToRepairChoice() {
        clickPrevious();
        return new NewClaimRepairChoicePage();
    }

    public VendorDto getVendorData() {
        VendorDto vendorData = new VendorDto();

        vendorData.VendorName = seleniumCommands.getValueAttributeFromLocator(REPAIR_FACILITY_NAME_INPUT_CSS);
        vendorData.Email = seleniumCommands.getValueAttributeFromLocator(REPAIR_FACILITY_EMAIL_CSS);
        vendorData.Phone = seleniumCommands.getValueAttributeFromLocator(REPAIR_FACILITY_PHONE_CSS);
        String address = seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE_1_CSS);
        address += ", " + seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE_2_CSS);
        address += ", " + seleniumCommands.getValueAttributeFromLocator(ADDRESS_LINE_3_CSS);
        address += ", " + seleniumCommands.getValueAttributeFromLocator(CITY_INPUT_CSS);
        address += ", " + USStatesAbbreviations.getStateAbbreviation(seleniumCommands.getSelectedOptionFromDropDown(STATE_DROP_CSS));
        address += " " + seleniumCommands.getValueAttributeFromLocator(ADDRESS_ZIP_CODE_CSS);
        vendorData.Address = address;

        return vendorData;
    }
}
