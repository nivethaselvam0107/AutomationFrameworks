package com.guidewire.capabilities.fnol.model.page;

import org.openqa.selenium.By;

import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.PolicySummary;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.NewClaimWhatHappenedPage;


public class GPA_PolicyDetailsClaimPageFactory extends GPA_ClaimPageAbstractFactory{

    public GPA_PolicyDetailsClaimPageFactory() {
    }

    public GPA_PolicyDetailsClaimPageFactory(String policyNumber) {
        super(policyNumber);
    }

    public NewClaimDOLPage getNewClaim() {
        new AgentDashboard().goToRecentyIssuedPolicies();
        seleniumCommands.click(By.xpath("//tr[descendant::a[contains(@href, '" +
               ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()) + "')]]//a[contains(@href, 'policies')]"));
        return new PolicySummary(this._policyNumber).goToClaimTile().goToMakeAClaim();
    }

    NewClaimWhatHappenedPage startClaim() {
        return getNewClaim()
                .goNext();
    }
}
