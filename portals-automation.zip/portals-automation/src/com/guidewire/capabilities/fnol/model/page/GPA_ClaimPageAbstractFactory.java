package com.guidewire.capabilities.fnol.model.page;

import java.util.HashMap;

import com.guidewire.data.ClaimType;
import com.guidewire.portals.claimportal.pages.*;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.ClaimsLanding;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import com.guidewire.data.PolicyData;

public abstract class GPA_ClaimPageAbstractFactory {
	public HashMap<String, String> data = ThreadLocalObject.getData();
    final Logger LOGGER = Logger.getLogger(this.getClass().getName());
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    String _policyNumber;
    private static final By HOME = By.cssSelector("a[href='#/home']");

    GPA_ClaimPageAbstractFactory() {
        org.openqa.selenium.support.PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        login();
    }

    @Deprecated
    GPA_ClaimPageAbstractFactory(String policyNumber) {
        this._policyNumber = policyNumber;
        org.openqa.selenium.support.PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
        login();
    }

    public void login(){
        new LoginPage().login();
    }

    abstract public NewClaimDOLPage getNewClaim();

    abstract NewClaimWhatHappenedPage startClaim();

    public NewClaimConfirmationPage createGeneralClaim() {
        LOGGER.info("Going to Create a General Claim Page");
        return getNewClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage()
                .selectPredefinedAddress()
                .getLossLocationAddressData()
                .goNext()
                .goNext()
                .goToSummary()
                .submitClaim();
    }

    public NewClaimConfirmationPage createWCClaim() {
        LOGGER.info("Going to Create a WC Claim Page");
        return  getNewClaim()
                .selectPolicy()
                .goNext()
                .selectWCClaimType()
                .setWCLossDesc()
                .setNotificationDateInThePast()
                .setInjuredEmployeeName()
                .setInjuredEmployeeDateOfBirth()
                .setInjuredEmployeeGender()
                .setInjuredEmployeeAddress()
                .goToWCInjuryDetailsPage()
                .selectInjuryType()
                .setDeathReport(false)
                .setLostTimeFromWork(false)
                .setEmploymentInjury(false)
                .setMedicalTreatment(false)
                .goNext()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }

    public NewClaimContactPersonPage createCollisionClaim() {
        LOGGER.info("Create CollisionClaim");
        return startClaim()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .uploadDocFromFNOL()
                .goNext();
    }

    public NewClaimRepairChoicePage createCollisionClaimForVendorChoice() {
        LOGGER.info("Create CollisionClaim ForVendorChoice");
        return startClaimFromPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage();
    }

    public NewClaimContactPersonPage createTheftClaim() {
        LOGGER.info("Create TheftClaim");

        ThreadLocalObject.getData().putIfAbsent("TheftType", "VehicleStolen");
        return startClaim()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .withTheftVehicleDamageDetails()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext();
    }
    public NewClaimRepairChoicePage createTheftClaimForVendorChoice() {
        LOGGER.info("Create TheftClaim ForVendorChoice");

        data.put("ClaimSubType", "Theft");
        data.put("TheftType", "AudioStolen");
        return startClaimFromPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .withTheftVehicleDamageDetails()
                .goToRepairChoicePage();
    }

    public NewClaimRepairChoicePage createTheftClaimForVendorChoiceWithDefaultData() {
        this.setDataForDefaultCityOnlyLocation();
        return this.createTheftClaimForVendorChoice();
    }

    protected void setDataForDefaultCityOnlyLocation() {
        data.putIfAbsent("LossLocationInput", "CityOnly");
        data.putIfAbsent("City", "San Francisco");
        data.putIfAbsent("State", "California");
    }

    public NewClaimContactPersonPage createGlassClaim() {
        LOGGER.info("Create GlassClaim");
        return startClaim()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimRepairChoicePage createGlassClaimForVendorChoice() {
        LOGGER.info("Create GlassClaim ForVendorChoice");
        return startClaimFromPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .goToRepairChoicePage();
    }

    public NewClaimDOLPage startClaimFromPolicy() {
        return openClaimViewFromPolicy().goToMakeAClaim();
    }

    public ClaimsTileView openClaimViewFromPolicy() {
    	  LOGGER.info("Opening Claim tile from Policy Details page");
    		AgentDashboard dashBoard = new AgentDashboard();
    		if(!dashBoard.isCSRDashboardOpened())
    		{
    			 LOGGER.info("Opening Claim tile from Policy Details page for CSR flow");
	        return new AgentDashboard()
	                .goToPolicySummary(data.get(PolicyData.POLICY_NUM.toString()))
	                .goToClaimTile();
    		}
    			return dashBoard
    					.searchUsingSearchBox(ThreadLocalObject.getData()
    							.get(PolicyData.ACCOUNT_NUMBER.toString()))
    							.goToAccount()
    							.goToPolicyInList().goToClaimTile();
    }

    public NewClaimDOLPage startClaimFromAccount() {
    		AgentDashboard dashBoard = new AgentDashboard();
		if(!dashBoard.isCSRDashboardOpened()) {
			 return openClaimViewFromAccount()
		                .goToMakeAClaim()
		                .selectPolicy();
		}
		return dashBoard.searchUsingSearchBox(ThreadLocalObject.getData()
					.get(PolicyData.ACCOUNT_NUMBER.toString()))
					.goToAccount().goToClaimTile()
					.goToMakeAClaim()
					.selectPolicy();
       
    }

    public ClaimsTileView openClaimViewFromAccount() {
        return new AgentDashboard()
                .goToAccounts().showRecentlyCreated()
                .openAccountUsingAccountNumber(data.get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToClaimTile();
    }

    public ClaimsLanding openClaimView() {
        return new AgentDashboard().goToClaims();
    }

    private NewClaimConfirmationPage startFireClaim(NewClaimDOLPage dolPage) {
        return dolPage
                .goNext()
                .selectHOClaimType()
                .goToFireDamageDetailsPage()
                .setFireDetails()
                .goNext()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }
    private NewClaimConfirmationPage startCrimeClaim(NewClaimDOLPage dolPage) {
        return dolPage
                .goNext()
                .selectHOClaimType()
                .goToCrimeDetailsPage()
                .setCrimeDetails()
                .goNext()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }
    private NewClaimConfirmationPage startWaterClaim(NewClaimDOLPage dolPage) {
        return dolPage
                .goNext()
                .selectHOClaimType()
                .goToWaterDamageDetailsPage()
                .setWaterDamageDetails()
                .goNext()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }
    
    public NewClaimConfirmationPage createTheftClaim(NewClaimDOLPage dolPage) {
        LOGGER.info("Create TheftClaim");

        ThreadLocalObject.getData().putIfAbsent("TheftType", "VehicleStolen");
        return dolPage
        			.goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .withTheftVehicleDamageDetails()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext()
                .goToSummary()
                .submitClaim();
    }

    public NewClaimConfirmationPage createHOFireClaimFromPolicy(){
        data.put("ClaimSubType","Fire");
        return startFireClaim(startClaimFromPolicy());
    }

    public NewClaimConfirmationPage createHOFireClaimFromAccount(){
        data.put("ClaimSubType","Fire");
        return startFireClaim(startClaimFromAccount());
    }

    public NewClaimConfirmationPage createHOCrimeClaimFromPolicy(){
        data.put("ClaimSubType","Crime");
        return startCrimeClaim(startClaimFromPolicy());
    }

    public NewClaimConfirmationPage createHOCrimeClaimFromAccount(){
        data.put("ClaimSubType","Crime");
        return startCrimeClaim(startClaimFromAccount());
    }

    public NewClaimConfirmationPage createHOWaterClaimFromPolicy(){
        data.put("ClaimSubType","Water");
        return startWaterClaim(startClaimFromPolicy());
    }

    public NewClaimConfirmationPage createHOWaterClaimFromAccount(){
        data.put("ClaimSubType","Water");
        return startWaterClaim(startClaimFromAccount());
    }
    
    public NewClaimConfirmationPage createTheftClaimFromPolicy(){
        data.put("ClaimSubType","Theft");
        return createTheftClaim(startClaimFromPolicy());
    }

    public AgentDashboard openDashBoard() {
        WebElement link = seleniumCommands.findElements(HOME).get(0);
        seleniumCommands.clickbyJS(link);
        return new AgentDashboard();
    }

    private void setDataForCPClaimType() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put(ClaimType.typeName, ClaimType.CP.lob());
        data.put("LOSS_CAUSE", "Fire");
        data.put("LossDescription", "CP LossDescription");
    }

    public NewClaimConfirmationPage createBasicCPClaimWithDefault() {
        LOGGER.info("Creating Commercial Property Claim");
        this.setDataForCPClaimType();
        this.setDataForDefaultCityOnlyLocation();

        return startClaimFromPolicy()
                .goToWhatPage()
                .selectLossCause()
                .setGeneralLossDesc()
                .setNoticeDate()
                .goToProperties()
                .selectProperties(1)
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext()
                .goToSummary()
                .submitClaim();
    }
}
