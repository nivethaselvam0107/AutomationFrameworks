package com.guidewire.capabilities.fnol.model.page;

import org.openqa.selenium.By;

import com.guidewire.capabilities.agent.model.page.AccountSummary;
import com.guidewire.capabilities.agent.model.page.AgentDashboard;
import com.guidewire.capabilities.agent.model.page.ClaimsTileView;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import com.guidewire.portals.claimportal.pages.NewClaimWhatHappenedPage;

public class GPA_ClaimPagefactory extends GPA_ClaimPageAbstractFactory {

	By CSR_SEARCH_BOX_CSS = By.cssSelector("[model='search.searchParam']");
	
    public GPA_ClaimPagefactory() {
        super();
    }

    public ClaimsTileView goToAccountsClaimsPage(){
        new AgentDashboard().goToAccounts().showRecentlyCreated()
        		.openAccountUsingAccountNumber(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()))
                .goToClaimTile();
        return new ClaimsTileView();
    }

    public ClaimsTileView goToAccountsClaimsPageTroughPolicies(){
        new AgentDashboard().goToPolicySummary(ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString()))
                .goToClaimTile();
        return new ClaimsTileView();
    }

    @Deprecated
    public GPA_ClaimPagefactory(String policyNumber) {
        super(policyNumber);
    }

    @Deprecated
    public NewClaimDOLPage getNewClaim() {
        return getAccountWithSuitablePolicy().goToClaimTile().goToMakeAClaim();
    }

    @Deprecated // use startClaimFromPolicy() or startClaimFromAccount()
    NewClaimWhatHappenedPage startClaim() {
        return getNewClaim()
                .selectPolicyByPolicyType()
                .goNext();
    }

    @Deprecated
    public AccountSummary getAccountWithSuitablePolicy() {
    		seleniumCommands.waitForLoaderToDisappearFromPage();
    		seleniumCommands.staticWait(2);
	    	if(!seleniumCommands.isElementPresent(CSR_SEARCH_BOX_CSS)) {
		        new AgentDashboard().goToRecentyIssuedPolicies();
		        this._policyNumber = this._policyNumber != null ? this._policyNumber : data.get("POLICY_NUM");
		
		        if (this._policyNumber != null) {
		            LOGGER.info("Selecting policy: " + this. _policyNumber);
		            seleniumCommands.click(By.xpath("//tr[descendant::a[contains(@href, '" + this. _policyNumber + "')]]//a[contains(@href, 'accounts')]"));
		            return new AccountSummary();
		        }
		        String table = "//table/tbody/tr";
		        int row = seleniumCommands.findElements(By.xpath("//table/tbody/tr")).size();
		        for (int i = 1; i <= row ; i++) {
		            String policyType = seleniumCommands.findElement(By.xpath(table + "[" + i + "]/td[1]/img")).getAttribute("title");
		            String policyStatus= seleniumCommands.findElement(By.xpath(table + "[" + i + "]/td[2]")).getText();
		            System.out.println(policyStatus + " " + policyType);
		            if ((policyStatus.contains("In Force"))&&(policyType.equals("Personal Auto"))) {
		                seleniumCommands.click(By.xpath(table + "[" + i + "]/td[4]/a"));
		                return new AccountSummary();
		            }
		        }
		        return null;
		    } else {
	    		return new AgentDashboard().searchUsingSearchBox(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString())).goToAccount();
	    	}
    }
}
