package com.guidewire.capabilities.fnol.model.page;

import com.guidewire.capabilities.common.interfaces.IVendorRepairChoicePage;
import com.guidewire.capabilities.common.interfaces.IWizardPage;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.claimportal.pages.ClaimWizardPage;
import com.guidewire.portals.claimportal.pages.NewClaimDocumentPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class NewClaimRepairChoicePage extends ClaimWizardPage
        implements IVendorRepairChoicePage, IWizardPage {

    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(id = "PreferredVendor")
    WebElement REPAIR_RECOMMENDED_FACILITY_RADIOBTN_ID;

    @FindBy(id = "NewVendor")
    WebElement REPAIR_NEW_FACILITY_RADIOBTN_ID;

    @FindBy(id = "NoRepair")
    WebElement NO_REPAIR_RADIOBTN_ID;
    
    @FindBy(css = "[model='$ctrl.model']")
    WebElement REPAIR_OPTIONS_CSS;

    @FindBy(css = "[model='repairOption().vehicleIncident'] select")
    WebElement VEHICLE_SELECT_CSS;

    By VEHICLE_SELECTOR_CSS = By.cssSelector("[model='repairOption().vehicleIncident'] select");

    By VEHICLE_SELECT_VALUES = By.cssSelector("[model='repairOption().vehicleIncident'] select option");

    @FindBy(css = "[model='$ctrl.model'] [ng-show='explicitErrorMessage'] [class*='gw-error-inline']")
    WebElement ERROR_REPAIR_CHOICE_TEXT;

    @FindBy(css = "[model='repairOption().vehicleIncident'] [class='gw-inline-messages'][aria-hidden='false']")
    WebElement ERROR_VEHICLES_CHOICE_TEXT;

    @FindBy(css = "[model='$ctrl.model'] input[type='radio']")
    List<WebElement> REPAIR_OPTIONS_LIST_CSS;


    By NO_REPAIR_RADIOBTN_ID_SELECTOR = By.id("NoRepair");

    @Override
    public NewClaimRepairFacilityPage selectNewFacility() {
        logger.info("Going to new facility page");
        seleniumCommands.clickbyJS(REPAIR_NEW_FACILITY_RADIOBTN_ID);
        clickNext();
        return new NewClaimRepairFacilityPage();
    }

    @Override
    public NewClaimRepairChoicePage selectValueNewFacility() {
        logger.info("Selecting new facility option");
            seleniumCommands.clickbyJS(REPAIR_NEW_FACILITY_RADIOBTN_ID);
        return this;
    }

    @Override
    public NewClaimRecommendedRepairFacilityPage selectRecommendedFacility() {
        logger.info("Going to recommended facility page");
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.clickbyJS(REPAIR_RECOMMENDED_FACILITY_RADIOBTN_ID);
        clickNext();
        return new NewClaimRecommendedRepairFacilityPage();
    }

    @Override
    public NewClaimRepairChoicePage selectValueRecommendedFacility() {
        logger.info("Selecting recommended facility option");
        seleniumCommands.clickbyJS(REPAIR_RECOMMENDED_FACILITY_RADIOBTN_ID);
        return this;
    }

    @Override
    public NewClaimDocumentPage selectNoFacility() {
        if(!seleniumCommands.isElementNotPresent(NO_REPAIR_RADIOBTN_ID_SELECTOR)) {
            logger.info("Going to doc uploads page");
            seleniumCommands.clickbyJS(NO_REPAIR_RADIOBTN_ID);
            clickNext();
        }
        return new NewClaimDocumentPage();
    }

    @Override
    public NewClaimRepairChoicePage selectValueNoFacility() {
        logger.info("Selecting No repair option");
        seleniumCommands.clickbyJS(NO_REPAIR_RADIOBTN_ID);
        return this;
    }

    @Override
    public Validation isPageLoaded() {
        seleniumCommands.waitForElementToBeVisible(REPAIR_OPTIONS_CSS);
        return new Validation(seleniumCommands.isElementPresent(REPAIR_OPTIONS_CSS));
    }

    @Override
    public Validation validateRepairChoiceErrorMessage() {
        logger.info("Validating the Mandatory Error for Repair choice");
        return new Validation(seleniumCommands.getTextAtLocator(ERROR_REPAIR_CHOICE_TEXT), DataConstant.NO_REPAIR_OPTION_SELECTED_ERROR);
    }

    @Override
    public Validation validateRepairChoiceVehiclesErrorMessage() {
        logger.info("Validating the Mandatory Error for vehicle choice");
        return new Validation(seleniumCommands.getTextAtLocator(ERROR_VEHICLES_CHOICE_TEXT), DataConstant.MANDATORY_ERROR_MSG);
    }

    @Deprecated // use instead selectNoFacility()
    public NewClaimDocumentPage goToDocumentPage() {
        if(!seleniumCommands.isElementNotPresent(NO_REPAIR_RADIOBTN_ID_SELECTOR)) {
            logger.info("Going to doc uploads page");
            seleniumCommands.clickbyJS(NO_REPAIR_RADIOBTN_ID);
            clickNext();
        }
        return new NewClaimDocumentPage();
    }

    @Override
    public String getSelectedRepairChoice() {
        for (WebElement el : REPAIR_OPTIONS_LIST_CSS) {
            if (new Boolean(seleniumCommands.getAttributeValueAtLocator(el, "aria-checked"))) {
                return seleniumCommands.getAttributeValueAtLocator(el, "id");
            }
        }
        return null;
    }

    @Override
    public NewClaimRepairChoicePage selectVehicle(String vehicleName) {
        seleniumCommands.waitForElementListHaveMoreValuesThan(VEHICLE_SELECT_VALUES, 1);
        seleniumCommands.selectDropDownValueByText(VEHICLE_SELECT_CSS, vehicleName);
        return this;
    }

    @Override
    public String getSelectedVehicle() {
        return seleniumCommands.getSelectedOptionFromDropDown(VEHICLE_SELECT_CSS);
    }

    @Override
    public Validation isVehiclesSelectorPresent() {
        return new Validation(seleniumCommands.isElementPresent(VEHICLE_SELECTOR_CSS));
    }
}
