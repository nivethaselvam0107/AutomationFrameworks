package com.guidewire.capabilities.fnol.model.component;

import com.guidewire.capabilities.common.scenarios.CommonScenario;
import com.guidewire.common.selenium.BrowserType;
import com.guidewire.common.util.EnumHelper;
import com.guidewire.portals.claimportal.pages.*;
import com.guidewire.portals.qnb.pages.AlertHandler;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.EnumSet;
import java.util.List;

public class WizardNavBar extends CommonScenario {

    private enum WizardStep {
        POLICY_SELECT("policySelect"),
        MORE_INFO("moreInfo"),
        MAIN_CONTACT("mainContact"),
        SUMMARY("summary"),

        CLAIM_TYPE_PA("paClaimType"),
        COLLISION_DETAILS_PA("paCollisionLossDetails"),
        COLLISION_VEHICLES_PA("paCollisionVehicles"),
        THEFT_DETAILS_PA("paTheftDetails"),
        SERVICE_CHOICE_PA("paServiceChoice"),
        NEW_REPAIR_FACILITY_PA("paNewRepairFacility"),

        RISK_UNITS_CP("cpRiskUnits"),
        PROPERTY_DETAILS_CP("cpPropertyDetails"),

        CRIME_DETAILS_HO("hoCrimeDetails"),
        WATER_DETAILS_HO("hoWaterDetails"),
        FIRE_DETAILS_HO("hoFireDetails");

        public static EnumSet<WizardStep> common = EnumSet.of(POLICY_SELECT, MORE_INFO, MAIN_CONTACT, SUMMARY);
        public static EnumSet<WizardStep> pa = EnumSet.of(CLAIM_TYPE_PA, THEFT_DETAILS_PA,
                                                          COLLISION_DETAILS_PA, COLLISION_VEHICLES_PA,
                                                          SERVICE_CHOICE_PA, NEW_REPAIR_FACILITY_PA);
        public static EnumSet<WizardStep> ho = EnumSet.of(CRIME_DETAILS_HO, WATER_DETAILS_HO, FIRE_DETAILS_HO);
        public static EnumSet<WizardStep> cp = EnumSet.of(RISK_UNITS_CP, PROPERTY_DETAILS_CP);

        private final String wizardStep;

        WizardStep(final String wizardStep) {
            this.wizardStep = wizardStep;
        }

        @Override
        public String toString() {
            return this.wizardStep;
        }

        public static WizardStep fromString(String name) {
            return EnumHelper.fromString(WizardStep.class, name);
        }
    }

    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "ul[class='gw-steps'] li")
    List<WebElement> WIZARD_STEPS_LIST_CSS;

    private WizardNavBar selectWizardStep(WizardStep wizardStep) {
        for (WebElement menuItem : WIZARD_STEPS_LIST_CSS) {
            String menuItemName = (String) seleniumCommands.getAngularScopeItem(menuItem, "step.name");
            if (wizardStep.toString().equals(menuItemName)) {
                LOGGER.info(String.format("Changing wizard step by use of left nav bar, going to step [%s]", wizardStep.toString()));
                seleniumCommands.clickbyJS(menuItem);
                break;
            }
        }
        return this;
    }

    public NewClaimDOLPage goToPolicySelectionPage() {
        selectWizardStep(WizardStep.POLICY_SELECT);
        return new NewClaimDOLPage();
    }

    public NewClaimWhatHappenedPage goToWhatHappenedPage() {
        selectWizardStep(WizardStep.CLAIM_TYPE_PA);
        return new NewClaimWhatHappenedPage();
    }

    public NewClaimVehicleDriverPage goToVehicleDriverPage() {
        selectWizardStep(WizardStep.COLLISION_VEHICLES_PA);
        new AlertHandler().closeAlertIfPresent();
        return new NewClaimVehicleDriverPage();
    }

    public NewClaimCrimeDetails goToCrimeDetailsPage() {
        selectWizardStep(WizardStep.CRIME_DETAILS_HO);
        return new NewClaimCrimeDetails();
    }

    public NewClaimPropertiesSelectionPage goToPropertySelectionPage() {
        selectWizardStep(WizardStep.RISK_UNITS_CP);
        new AlertHandler().closeAlertIfPresent();
        return new NewClaimPropertiesSelectionPage();
    }

    public PropertyDetailsPage goToPropertyDetailsPage() {
        selectWizardStep(WizardStep.PROPERTY_DETAILS_CP);
        new AlertHandler().closeAlertIfPresent();
        return new PropertyDetailsPage();
    }
}
