package com.guidewire.capabilities.fnol.data;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.ClaimData;

import java.util.HashMap;

public class FnolData {

    public static void setFirstOtherCarDefaultData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.VEHICLE_MAKE1.toString(), "Honda");
        data.putIfAbsent(ClaimData.VEHICLE_MODEL1.toString(), "Civic");
        data.putIfAbsent(ClaimData.VEHICLE_YEAR1.toString(), "2004");
    }

    public static void setSecondOtherCarDefaultData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.VEHICLE_MAKE2.toString(), "Volvo");
        data.putIfAbsent(ClaimData.VEHICLE_MODEL2.toString(), "XC60");
        data.putIfAbsent(ClaimData.VEHICLE_YEAR2.toString(), "2016");
    }

    public static void setFirstOtherDriverDefaultData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.OTHER_DRIVER_FIRST_NAME1.toString(), "OtherDriverFirstName_1");
        data.putIfAbsent(ClaimData.OTHER_DRIVER_LAST_NAME1.toString(), "OtherDriverLastName_1");
    }

    public static void setSecondOtherDriverDefaultData() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.putIfAbsent(ClaimData.OTHER_DRIVER_FIRST_NAME2.toString(), "OtherDriverFirstName_2");
        data.putIfAbsent(ClaimData.OTHER_DRIVER_LAST_NAME2.toString(), "OtherDriverLastName_2");
    }
}
