/**
 * 
 */
package com.guidewire.capabilities.quote.test.hop;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseQuoteData;
import com.guidewire.portals.qnb.pages.HOPCoverageDetailsPage;
import com.guidewire.portals.qnb.pages.HOPolicyInfoPage;
import com.guidewire.portals.qnb.pages.HOQuotePage;
import com.guidewire.portals.qnb.pages.Pagefactory;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.portals.qnb.pages.PolicyConfirmationPage;
import com.guidewire.portals.qnb.pages.QuoteInfoBar;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HOPQuoteUIValidationTest {

	Pagefactory pagefactory = new Pagefactory();
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4281:HOP Your Info Page")
	public void testYourInfoPageLoading(String browserName) {
		pagefactory
				.getZipCodePage()
				.setZipCodePageDetails()
				.goToYourInfoPage()
				.isYourInfoPageLoaded()
				.shouldBeTrue("Your Info page is not loaded");
	}
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4282:HOP Qualification page")
	public void testVerifyHOPQualificationPageLoading(String browserName) throws Exception {
		pagefactory
				.setHOPolicyDataUpToQualificationPage()
				.goToYourHomePage()
				.isYourHomePageLoaded()
				.shouldBeTrue("Your home page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4283:HOP Verify Home Page")
	public void testVerifyHOPYourHomePageLoading(String browserName) throws Exception {
		pagefactory
				.setHOPolicyDataUpToYourHomePage()
				.goToConstructionPage()
				.isConstructionPageLoaded()
				.shouldBeTrue("Construction page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4284:HOP Verify Construction page")
	public void testVerifyHOPConstructionPageLoading(String browserName) throws Exception {
		pagefactory
				.setHOPolicyDataUpToConstructionPage()
				.goToDiscountPage()
				.isDiscountPageLoaded()
				.shouldBeTrue("Dscount page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4285:HOP Verify Discount page")
	public void testVerifyHOPDiscountPageLoading(String browserName) throws Exception {
		pagefactory
				.setHOPolicyDataUpToDiscountPage()
				.goToHOQuotePage()
				.isHOQuotePageLoaded()
				.shouldBeTrue("HO Quote page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4286:HOP Verify you can get a Quote")
	public void testVerifyHOPQuoteCreation(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory
					.setHOPolicyDataUpToDiscountPage()
					.goToHOQuotePage();
		hoQuotePage
					.isHOQuotePageLoaded()
					.shouldBeTrue("HO Quote page is not loaded");
		hoQuotePage.validateHOQuotePageLayout().shouldBeTrue();
		String quoteDataBackEnd = DataFetch.getQuoteAsJsonData();
		new HOPCoverageDetailsPage()
					.areHOPQuoteBaseCoverageDataMatchingWithBackEnd(quoteDataBackEnd)
					.shouldBeTrue("HOP Base Coverage value are not matched with the Back End");
		hoQuotePage
		.buyBasePolicyWithMonthlyPremium()
		.goToPolicyInfoPage()
		.isHOPolicyInfoPageLoaded()
					.shouldBeTrue("HOP Policy info page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4287:HOP Verify Policy Info")
	public void testVerifyHOPPolicyInfoPageLoading(String browserName) throws Exception {
		HOPolicyInfoPage hoPolicyInfoPage =  pagefactory
					.setHOPolicyDataUpToDiscountPage()
					.goToHOQuotePage()
					.buyBasePolicyWithMonthlyPremium()
					.goToPolicyInfoPage();
		String quoteDataBackEnd = DataFetch.getQuoteAsJsonData();
		hoPolicyInfoPage.isHOPolicyInfoPageLoaded().shouldBeTrue("Policy Info HO page is not loaded");
		hoPolicyInfoPage.validateCoverageDateWithBackEnd(quoteDataBackEnd)
		.shouldBeEqual("Policy Coverage start date is not matched on policy Info page");
		hoPolicyInfoPage
					.validatePolicyAddressWithBackEnd(quoteDataBackEnd)
					.shouldBeEqual("Policy address is not matched on policy Info page");
		hoPolicyInfoPage
					.validatePrimaryInsuredPersonNameWithBackEnd(quoteDataBackEnd)
					.shouldBeEqual("Primary Insured Person name is not mactched on policy Info page");
		new HOPCoverageDetailsPage().areHOPQuoteBaseCoverageDataMatchingWithBackEnd(quoteDataBackEnd);
		hoPolicyInfoPage.isPolicyBillingAddressOptionSelectedByDefault()
					.shouldBeTrue("Billing addess option is is not selected Yes by default");
		hoPolicyInfoPage
					.setPolicyInfoPageDetails()
					.isEmailSaved()
					.shouldBeEqual("Email value is not saved");
		hoPolicyInfoPage
					.isPhoneSaved().shouldBeEqual("Email field is not saved");
		hoPolicyInfoPage
					.goToPaymentDetailsPage()
					.isPaymentDetailsPageLoaded()
					.shouldBeTrue("Policy Payment page is not loaded");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4288:HOP Verify Payment Details page")
	public void testVerifyHOPPaymentPlanPage(String browserName) throws Exception {
		PaymentDetailsPage paymentDetailsPage = pagefactory
					.setHOPolicyDataUpToDiscountPage()
					.goToHOQuotePage()
					.buyBasePolicyWithMonthlyPremium()
					.goToPolicyInfoPage()
					.setPolicyInfoPageDetails()
					.goToPaymentDetailsPage();
		paymentDetailsPage
					.isPaymentDetailsPageLoaded()
					.shouldBeTrue("Payment Details page is not loaded");
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		String jsonQuotedata = DataFetch.getQuoteAsJsonData(quoteNum);
		paymentDetailsPage.
					isAnnualPremiumEqualsTo(jsonQuotedata)
					.shouldBeEqual("Annual premium is not equal");
		paymentDetailsPage
					.isMonthlyPermiumEqualsTo(jsonQuotedata)
					.shouldBeEqual("Monthly premium is not equal");
		PolicyConfirmationPage confirmationPage = 	paymentDetailsPage
										.payMonthlyPremiumWithSavingsBankAccount()
										.purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4289:HOP Add a scheduled item and Quote")
	public void testScheduledItemAddition(String browserName) throws Exception {
		PaymentDetailsPage paymentDetailsPage = pagefactory.setHOPolicyDataUpToDiscountPage()
					.goToHOQuotePage()
					.addScheduledPersonalProperty()
	                .reCalculatePolicyPremium()
	                .buyBasePolicyWithMonthlyPremium()
	                .goToPolicyInfoPage()
	                .setPolicyInfoPageDetails()
	                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
					.payMonthlyPremiumWithSavingsBankAccount()
	                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4280:HOP Edit a scheduled item and Quote")
	public void testScheduledItemEdition(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setHOPolicyDataUpToDiscountPage()
				.goToHOQuotePage();
		hoQuotePage.addScheduledPersonalProperty()
                .reCalculatePolicyPremium();
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.editFirstScheduledPersonalProperty()
        			.buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		confirmationPage.validateHOScheduledPersonalPropertyDataWithBackEnd(jsonQuotePolicydata);
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC4279:HOP Delete a scheduled item and Quote")
	public void testScheduledItemDeletion(String browserName) throws Exception {
		HOQuotePage hoQuotePage = pagefactory.setHOPolicyDataUpToDiscountPage()
				.goToHOQuotePage();
		hoQuotePage.addScheduledPersonalProperty()
                .reCalculatePolicyPremium();
        ThreadLocalObject.getData().put("SchedulePropertyType", "Fine Arts");
        PaymentDetailsPage paymentDetailsPage = hoQuotePage.deleteFirstProperty()
                .buyBasePolicyWithMonthlyPremium()
                .goToPolicyInfoPage()
                .setPolicyInfoPageDetails()
                .goToPaymentDetailsPage();
		String quoteNum = new QuoteInfoBar().getSubmissionNumber();
		PolicyConfirmationPage confirmationPage =paymentDetailsPage
				.payMonthlyPremiumWithSavingsBankAccount()
                .purchasePolicy();
		String jsonQuotePolicydata = DataFetch.getQuoteAsJsonData(quoteNum);
		confirmationPage.validateHOPolicySummaryDetails(jsonQuotePolicydata);
		new Validation(ParseQuoteData.getScheduledPropertyDataFromBackEnd(jsonQuotePolicydata).size(), 0).shouldBeEqual("Scehduled property was available in backend");
	}
}
