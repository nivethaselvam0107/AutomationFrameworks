package com.guidewire.capabilities.amp.model.page;

import com.guidewire.capabilities.common.model.page.AdditionalEnrollmentPage;
import com.guidewire.data.ClaimType;
import com.guidewire.data.DataConstant;
import org.apache.log4j.Logger;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.fnol.model.page.NewClaimRepairChoicePage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.portals.claimportal.pages.NewClaimContactPersonPage;
import com.guidewire.portals.claimportal.subpages.ContactUSPage;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.HashMap;

public class Pagefactory{

    private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

    public Pagefactory() {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public Pagefactory(Object obj) {
        PageFactory.initElements(new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public AccountSummaryPage getAccountSummaryPage() {
        LOGGER.info("Going to Account Summary Page");
        return (AccountSummaryPage)loginOpenAM();
    }

    public Object loginOpenAM() {
        LOGGER.info("Logging in open AM");
        return new OpenAMSignInPage().loginOpenAM();
    }

    public AccountEditPage getAccountEditPage() {
        LOGGER.info("Going to Account Edit Page");
        return getAccountSummaryPage().goToAccountEditPage();
    }

    public AccountInformationPage getAccountInformationPage() {
        LOGGER.info("Going to Account Information Page");
        return getAccountSummaryPage().updateContactDetails();
    }

    public BillingSummaryPage getBillingSummaryPage() {
        LOGGER.info("Going to Billing Summary Page");
        return getAccountSummaryPage().goToBillingSummaryPage();
    }

    public MakeAPaymentPage getMakeAPaymentPage() {
        LOGGER.info("Going to Make A Payment Page");
        return getAccountSummaryPage().goToMakeAPaymentPage();
    }

    public NewClaimContactPersonPage createCollisionClaim() {
        LOGGER.info("Going to Create a Claim Page");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectFirstAvailableDriver()
                .selectFirstAvailableVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimRepairChoicePage createCollisionClaimForVendorChoice() {
        LOGGER.info("Going to Create a Claim Page");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .selectCollisionClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withPropDamageDetails()
                .goToVehicleDriverPage()
                .selectDriver()
                .selectVehicle()
                .setVehicleSafetyToDrive()
                .setAirBagDeployStatus()
                .setEquiFailureStatus()
                .setVehicleTowStatus()
                .setVehicleRentalStatus()
                .setVehicleCollisionPoint()
                .withNewPassenger()
                .goToRepairChoicePage();
    }

    public NewClaimContactPersonPage createTheftClaim() {
        LOGGER.info("Creating Theft Claim");

        ThreadLocalObject.getData().putIfAbsent("TheftType", "VehicleStolen");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .withTheftVehicleDamageDetails()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimRepairChoicePage createTheftClaimForVendorChoice() {
        LOGGER.info("Creating Theft Claim");

        ThreadLocalObject.getData().put("TheftType", "AudioStolen");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .withTheftVehicleDamageDetails()
                .goToRepairChoicePage();
    }

    public NewClaimContactPersonPage createGlassClaim() {
        LOGGER.info("Creating Glass Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .goToRepairChoicePage()
                .selectNoFacility()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimRepairChoicePage createGlassClaimForVendorChoice() {
        LOGGER.info("Creating Glass Claim");

        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .goNext()
                .withLossLocation()
                .withClaimDescription()
                .withVehicleInvolved()
                .goToRepairChoicePage();
    }

    public NewClaimRepairChoicePage createGlassClaimForVendorChoiceWithDefault() {
        ThreadLocalObject.getData().put("ClaimSubType", "Glass");
        this.setDataForDefaultCityOnlyLocation();
        return this.createGlassClaimForVendorChoice();
    }

    protected void setDataForDefaultCityOnlyLocation() {
        ThreadLocalObject.getData().putIfAbsent("LossLocationInput", "CityOnly");
        ThreadLocalObject.getData().putIfAbsent("City", "San Francisco");
        ThreadLocalObject.getData().putIfAbsent("State", "California");
    }

    public ContactUSPage createOtherClaim() {
        LOGGER.info("Creating Other Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectPAClaimType()
                .goToContactUsPage();
    }

    public NewClaimContactPersonPage createWaterClaim() {
        LOGGER.info("Creating Water Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectHOClaimType()
                .goToWaterDamageDetailsPage()
                .setWaterDamageDetails()
                .goNext()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimContactPersonPage createFireClaim() {
        LOGGER.info("Creating Fire Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectHOClaimType()
                .goToFireDamageDetailsPage()
                .setFireDetails()
                .goNext()
                .withNewContactPerson()
                .goNext();
    }
    
    public NewClaimContactPersonPage createCrimeClaimFromClaimTab() {
        LOGGER.info("Creating Crime Claim");
        return getAccountSummaryPage()
                .goToClaimsPage()
                .fileAClaim()
                .selectPolicy()
                .goNext()
                .selectHOClaimType()
                .goToCrimeDetailsPage()
                .setCrimeDetails()
                .goNext()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimContactPersonPage createCrimeClaim() {
        LOGGER.info("Creating Water Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectHOClaimType()
                .goToCrimeDetailsPage()
                .setCrimeDetails()
                .goNext()
                .withNewContactPerson()
                .goNext();
    }

    public NewClaimContactPersonPage createGeneralClaim() {
        LOGGER.info("Creating General Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectGeneralClaimType()
                .setGeneralLossDesc()
                .setGeneralDamageDesc()
                .goToGeneralDetailsPage()
                .getAddress()
                .goNext()
                .uploadDocFromFNOL()
                .goNext();
    }

    public NewClaimContactPersonPage createWCClaim() {
        LOGGER.info("Creating Workers Comp Claim");
        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goNext()
                .selectWCClaimType()
                .setWCLossDesc()
                .setNotificationDateInThePast()
                .setInjuredEmployeeName()
                .setInjuredEmployeeDateOfBirth()
                .setInjuredEmployeeGender()
                .setInjuredEmployeeAddress()
                .goToWCInjuryDetailsPage()
                .selectInjuryType()
                .setDeathReport(false)
                .setLostTimeFromWork(false)
                .setEmploymentInjury(false)
                .setMedicalTreatment(false)
                .goNext()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext();
    }

    public AMP_ClaimListPage goToClaimListPage() {
        return getAccountSummaryPage().goToClaimsPage();
    }

    private void setDataForCPClaimType() {
        HashMap<String, String> data = ThreadLocalObject.getData();
        data.put(ClaimType.typeName, ClaimType.CP.lob());
        data.put("LOSS_CAUSE", "Fire");
        data.put("LossDescription", "CP LossDescription");
    }

    public NewClaimContactPersonPage createBasicCPClaimWithDefault() {
        LOGGER.info("Creating Commercial Property Claim");
        this.setDataForCPClaimType();
        this.setDataForDefaultCityOnlyLocation();

        return getAccountSummaryPage()
                .goToMakeAClaim()
                .selectPolicy()
                .goToWhatPage()
                .selectLossCause()
                .setNoticeDate()
                .goToProperties()
                .selectProperties(1)
                .goNext()
                .goNext()
                .withLossLocation()
                .goToDocumentPage()
                .uploadDocFromFNOL()
                .goNext();
    }

    public AdditionalEnrollmentPage goToAdditionalEnrollmentPage() {
        LOGGER.info("Going to Additional Enrollment Page");
        return (AdditionalEnrollmentPage)getAccountSummaryPage().goToAdditionalEnrollmentPage();
    }

    public PolicyChangePage goToPolicyChangePage() {
        LOGGER.info("Going to Policy Change Page");
        return (PolicyChangePage)getAccountSummaryPage().goToPolicyChangePage();
    }
}