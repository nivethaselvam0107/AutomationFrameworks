package com.guidewire.capabilities.amp.model.page;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseAccountData;
import com.guidewire.widgetcomponents.form.ViewModelForm;


public class AccountInformationPage {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[ng-if='accountInfo']")
    WebElement ACCOUNT_INFO_CSS;

    @FindBy(css = "ng-form")
    WebElement FORM;

    @FindBy(css = "[model='contact.firstName'] span[ng-if]")
    WebElement FIRST_NAME_CSS;

    @FindBy(css = "[model='contact.lastName']  span[ng-if]")
    WebElement LAST_NAME_CSS;

    @FindBy(css = "[ng-click='changeToAccountEditState()'][aria-hidden='false']")
    WebElement EDIT_ADDRESS_CSS;
    
    @FindBy(css = "[ng-click='cancel()'][aria-hidden='false']")
    WebElement CANCEL_ADDRESS_CSS;

    @FindBy(css = "[address='contact.primaryAddress']")
    WebElement ADDRESS_FORM_PANEL;

    @FindBy(css = "[ng-click='updateContactDetails(contactDetailsForm)']")
    WebElement SUBMIT_BUTTON;

    @FindBy(css = "[ng-click='cancel()']")
    WebElement CANCEL_BUTTON;

    @FindBy(css = "[class='gw-modal gw-fade  in'] [ng-click='$close()']")
    WebElement MODAL;

    @FindBy(css = ".gw-modal .gw-message")
    WebElement CONFIRMATION_MESSAGE;

    @FindBy(css = "[ng-click='$close()']")
    WebElement CONFIRM_MODAL;

    String ADDRESS_DISPLAY_NAME_CSS = "[ng-repeat='addressLine in displayAddressArray track by $index']";

    String HOME_BUTTON_AREA = ".gw-header-left-part a";

    String MODAL_BACKGROUND = ".gw-modal-backdrop";

    public enum UpdateTypes {
        PHONE,
        ADDRESS
    }

    public AccountInformationPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public HashMap<String, String> getAccountDetails() {
        HashMap<String, String> details = new HashMap<>();
        details.put("FIRST_NAME", seleniumCommands.getTextAtLocator(FIRST_NAME_CSS));
        details.put("LAST_NAME", seleniumCommands.getTextAtLocator(LAST_NAME_CSS));
        details.put("ADDRESS_LINE1", this.getForm().getInputByModel("address.addressLine1").getValue());
        details.put("ADDRESS_LINE2", this.getForm().getInputByModel("address.addressLine1").getValue());
        details.put("ADDRESS_LINE3", this.getForm().getInputByModel("address.addressLine1").getValue());
        details.put("CITY", this.getForm().getInputByModel("address.city").getValue());
        details.put("ZIP_CODE", this.getForm().getInputByModel("address.postalCode").getValue());
        details.put("STATE", this.getForm().getInputByModel("address.state").getValue());
        return details;
    }

    private String getAddressDisplayName() {
        List<WebElement> addressMatches = seleniumCommands.getElements(By.cssSelector(ADDRESS_DISPLAY_NAME_CSS));
        return addressMatches.stream().map(match -> match.getText()).collect(Collectors.joining(" "));
    }

    public HashMap<String, String> getPhoneEmail() {
        HashMap<String, String> details = new HashMap<>();
        details.put("HOME_PHONE", this.getForm().getInputByModel("phone.homeNumber").getValue());
        details.put("WORK_PHONE", this.getForm().getInputByModel("phone.workNumber").getValue());
        details.put("CELL", this.getForm().getInputByModel("phone.cellNumber").getValue());
        details.put("EMAIL", this.getForm().getInputByModel("contact.emailAddress1").getValue());
        return details;
    }

    public AccountInformationPage updateAddress() {
        seleniumCommands.click(EDIT_ADDRESS_CSS);
        seleniumCommands.waitForElementToBeVisible(ADDRESS_FORM_PANEL);
        getForm().getInputByModel("address.city").setValue(data.get("CITY_UPDATE"));
        return this;
    }

    public AccountInformationPage updatePhone() {
        getForm().getInputByModel("phone.homeNumber").setValue(data.get("HOME_PHONE"));
        getForm().getInputByModel("contact.emailAddress1").setValue(data.get("EMAIL"));
        return this;
    }

    public AccountInformationPage submitFormChanges() {
        //TODO: Add submit type to buttons on this page and then use form.submit instead
        //getForm().submit()
        seleniumCommands.click(SUBMIT_BUTTON);
        return this;
    }

    public AccountSummaryPage goToHome() {
        seleniumCommands.waitForElementToBeClickable(By.cssSelector(HOME_BUTTON_AREA));
        seleniumCommands.waitForElementToDisappear(By.cssSelector(MODAL_BACKGROUND));
        seleniumCommands.click(By.cssSelector(HOME_BUTTON_AREA));
        return new AccountSummaryPage();
    }

    public AccountSummaryPage clickCancel() {
        boolean cancelDisplayedSuccessfully;
        seleniumCommands.click(CANCEL_BUTTON);
        seleniumCommands.waitForElementToBeVisible(MODAL);
        cancelDisplayedSuccessfully = CONFIRMATION_MESSAGE.getText().equals(DataConstant.CANCEL_ACCOUNT_UPDATE_TEXT);
        if(cancelDisplayedSuccessfully) {
            seleniumCommands.click(CONFIRM_MODAL);
            return new AccountSummaryPage();
        }
        return null;
    }

    public AccountSummaryPage closeUpdateSubmissionModal(UpdateTypes type) {
        boolean confirmDisplayed;
        String expectedText = type == UpdateTypes.ADDRESS ? DataConstant.UPDATE_SUBMISSION_TEXT_ADDRESS : DataConstant.UPDATE_SUBMISSION_TEXT_PHONE;
        seleniumCommands.waitForElementToBeVisible(MODAL);
        confirmDisplayed = CONFIRMATION_MESSAGE.getText().equals(expectedText);
        if(confirmDisplayed) {
            seleniumCommands.click(CONFIRM_MODAL);
            return new AccountSummaryPage();
        }
        return null;

    }

    // Validation Methods
    public Validation verifyPageDisplayedCorrectly() throws ParseException {
    		logger.info("Validating account info with the backend");
        HashMap<String, String> displayedDetails;
        HashMap<String, String> phoneEmailDetails;
        new Validation(seleniumCommands.isElementPresent(ACCOUNT_INFO_CSS)).shouldBeTrue("Account Information is not visible");
        seleniumCommands.click(EDIT_ADDRESS_CSS);
        seleniumCommands.waitForElementToBeVisible(CANCEL_ADDRESS_CSS);
        HashMap<String, String> pcData = ParseAccountData.accountInformationFromBackend(DataFetch.getUserProfileData());
        displayedDetails = getAccountDetails();
        MapCompare.compareMap(displayedDetails, pcData).shouldBeTrue("Account details are not correct");

        phoneEmailDetails = getPhoneEmail();
        MapCompare.compareMap(phoneEmailDetails, data).shouldBeTrue("Account details are not correct");

        return new Validation(true);
    }

    public Validation verifyDataMatchesPC() throws ParseException {
        seleniumCommands.click(EDIT_ADDRESS_CSS);
        seleniumCommands.waitForElementToBeVisible(ADDRESS_FORM_PANEL);
        HashMap<String, String> displayedDetails = getAccountDetails();
        HashMap<String, String> pcData = ParseAccountData.accountInformationFromBackend(DataFetch.getUserProfileData());
        return MapCompare.compareMap(displayedDetails, pcData);
    }

    public Validation verifyCancelWorks() {
        boolean pageDisplayedCorrectly = true;
        boolean cancelWorked = true;
        AccountSummaryPage home;

        try {
            verifyPageDisplayedCorrectly();
        }
        catch(ParseException e) {
            pageDisplayedCorrectly = false;
        }

        if(pageDisplayedCorrectly) {
            home = clickCancel();
            cancelWorked = home != null;
        }
        return new Validation(pageDisplayedCorrectly && cancelWorked);
    }
}
