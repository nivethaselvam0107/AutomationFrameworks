package com.guidewire.capabilities.amp.model.page;

import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import org.apache.log4j.Logger;

public class OpenAMSignInPage
{
	Logger logger = Logger.getLogger(this.getClass().getName());
	SeleniumCommands seleniumCommands = new SeleniumCommands();

	public OpenAMSignInPage() {
		seleniumCommands.pageWebElementLoader(this);
	}

	public Object loginOpenAM() {
		logger.info("Logging open AM");
		try {
			new LoginPage().login();
		} catch (Exception e) {
			logger.error(e);
		}
		return new AccountSummaryPage();
	}
}
