package com.guidewire.capabilities.amp.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.HashMap;

public class AccountDetails {

  private SeleniumCommands seleniumCommands = new SeleniumCommands();
  private HashMap<String, String> data = ThreadLocalObject.getData();
  private Logger logger = Logger.getLogger(this.getClass().getName());

  WebElement details;

  WebElement HEADER;
  WebElement FIRST_NAME;
  WebElement LAST_NAME;
  By EDIT_BUTTON_SELECTOR = By.cssSelector("[ng-click='changeToAccountEditState($index)'][aria-hidden='false']");
  By CANCEL_BUTTON_SELECTOR = By.cssSelector("[on-click='cancel()']");
  By SUBMIT_BUTTON_SELECTOR = By.cssSelector("[on-click='updateContactDetails(contactDetailsForm, $index)']");
  By MODAL_SELECTOR = By.cssSelector(".gw-modal");
  By CONFIRM_BUTTON_MODAL_SELECTOR = By.cssSelector("[ng-click='$close(optionsModel)']");

  public AccountDetails(WebElement element) {
    details = element;
    HEADER = element.findElement(By.cssSelector(".gw-user-profile-title"));
    FIRST_NAME = element.findElement(By.cssSelector("[model='contact.firstName'] span[ng-if]"));
    LAST_NAME = element.findElement(By.cssSelector("[model='contact.lastName']  span[ng-if]"));
  }

  public String getHeaderText() {
    return HEADER.getText();
  }

  public AccountDetails edit() {
    seleniumCommands.click(details.findElement(EDIT_BUTTON_SELECTOR));
    seleniumCommands.waitForElementToBeVisible(details.findElement(CANCEL_BUTTON_SELECTOR));
    return this;
  }

  public AccountDetails cancel() {
    seleniumCommands.click(details.findElement(CANCEL_BUTTON_SELECTOR));
    WebElement modal = seleniumCommands.findElement(MODAL_SELECTOR);
    seleniumCommands.click(modal.findElement(CONFIRM_BUTTON_MODAL_SELECTOR));
    return this;
  }

  public AccountDetails submit() {
    seleniumCommands.click(details.findElement(SUBMIT_BUTTON_SELECTOR));
    return this;
  }


}