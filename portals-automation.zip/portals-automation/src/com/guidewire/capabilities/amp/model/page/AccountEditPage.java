package com.guidewire.capabilities.amp.model.page;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.List;
import java.util.stream.Collectors;

public class AccountEditPage {

  @FindBy(css = "[ng-if='accountsInfo']")
  private WebElement ACCOUNT_DETAILS_WRAPPER;

  @FindBy (css = "ng-form[name='contactDetailsForm']")
  List<WebElement> ACCOUNT_DETAILS;

  public AccountEditPage() {
    PageFactory.initElements(
        new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
  }

  public int getNumberOfAccountDetails() {
    return ACCOUNT_DETAILS.size();
  }

  public AccountDetails getAccountDetailsByIndex(Integer index ) {
    return new AccountDetails(ACCOUNT_DETAILS.get(index));
  }

  public List<AccountDetails> getAccountsDetails() {
    return ACCOUNT_DETAILS.stream()
        .map(AccountDetails::new).collect(Collectors.toList());
  }

  public boolean hasPolicyNumberInAnyHeader(String policyNumber) {
    return getAccountsDetails().stream()
        .map(AccountDetails::getHeaderText)
        .anyMatch(text -> text.contains(policyNumber));
  }
}

