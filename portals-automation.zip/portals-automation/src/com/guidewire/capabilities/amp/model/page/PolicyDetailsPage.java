package com.guidewire.capabilities.amp.model.page;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.capabilities.agent.model.component.Tiles;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.common.util.MapCompare;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParsePolicyData;
import com.guidewire.data.PolicyData;
import com.guidewire.data.StringConstants.AMPAssertionConstants;
import com.guidewire.data.StringConstants.AMPAssertionLogConstants;
import com.guidewire.portals.qnb.pages.CommonPage;
import com.guidewire.widgetcomponents.Modal;

public class PolicyDetailsPage extends CommonPage {

    private String policyNumber;

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    final String ACTIVITIES_TILE_SELECTOR = ".gw-tile[tile-title='Open Activities']";

    @FindBy(css = ACTIVITIES_TILE_SELECTOR)
    WebElement ACTIVITIES_TILE;

    @FindBy(css = "[ng-click='goBack()']")
    WebElement BACK_BTN;

    @FindBy(css = "[class='gw-page-section-title ng-binding']")
    WebElement UPLOADED_DOCS_HEADER;

    @FindBy(css = ".gw-page-title")
    WebElement POLICY_DETAILS_HEADER;

    @FindBy(css = ".gw-total-premium")
    WebElement TOTAL_PREMIUM_DIV;

    @FindBy(css = "[ng-click='print()']")
    WebElement PRINT_BTN;

    @FindBy(css = "[ng-click='vehicle.showCoverages=true']")
    WebElement SHOW_VEHICLE_COV_LINK;

    @FindBy(css = "[class='gw-drivers-info gw-table']")
    WebElement COVERED_DRIVERS_TABLE;
    
    By COVERED_DRIVERS_ROW = By.cssSelector("[ng-repeat*='tab in tabs'][class*='active'] [ng-repeat='driver in policyDrivers']");
    
    By DRIVER_SECTION_EXPAND_BUTTON = By.cssSelector("[ng-repeat*='tab in tabs'][class*='active'] [gw-policy-driver-info] [ng-click='toggleOpen()']");
    
    By VEHICLE_ROW = By.cssSelector("[ng-repeat*='tab in tabs'][class*='active'] [ng-repeat='vehicle in policyVehicles']");
    
    By VEHICLE_SECTION_EXPAND_BUTTON = By.cssSelector("[ng-repeat*='tab in tabs'][class*='active'] [gw-policy-vehicle-info] [ng-click='toggleOpen()']");
    
    @FindBy(id = "uploadButton")
    WebElement UPLOAD_DOC_LABEL;

    @FindBy(css = "button[ng-click='showAddActivity()']")
    WebElement ADD_ACTIVITY_BUTTON;

    @FindBy(css = "[ng-click='clickUpload()']")
    WebElement UPLOAD_DOC_BTN_CSS;

    @FindBy(css = ".gw-policy-details a")
    WebElement POLICY_PAGE_HEADER_CSS;

    @FindBy(css = "gw-policy-common-documents>div:nth-of-type(2)")
    WebElement UPLOAD_DOC_EXPAND_CSS;

    @FindBy(css = "a[href='#endorsement'] div[ng-if] div")
            //a[href="#endorsement"] img
    WebElement PERSONALIZED_LEADER_BOARD_AD;

    final String DELETE_DOC_BTN_CSS =  "[ng-click='removeDocument(document)']";

    final String UPLOAD_DOC_INPUT_CSS = "[id='uploadButton'] input";

    final String DOC_TABLE_CSS = "div[class='gw-file-upload-card ng-scope']  .gw-file-upload-info";

    final String POLICY_NUM_CSS = "[class='gw-inline-back-nav ng-binding']";
    
    final String VEH_SEC_EXPANDED_CSS = "//*[@ng-repeat='tab in tabs'][contains(@class,'active')]//*[@gw-policy-vehicle-info]//*[@ng-click='toggleOpen()']/../following-sibling::div[contains(@class,'gw-in')]";

    private static int value = 0;


    public PolicyDetailsPage(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
    }

    public PolicyDetailsPage(String policyNumbner) {
        this.policyNumber = policyNumbner;
        seleniumCommands.waitForLoaderToDisappearFromPage();
    }

    public BillingSummaryPage goToBillingSummaryPage() {
        seleniumCommands.click(BACK_BTN);
        return new BillingSummaryPage();
    }

    public AccountSummaryPage goToAccountSummaryPage() {
        seleniumCommands.click(BACK_BTN);
        return new AccountSummaryPage();
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public String getPolicyID(){
        return seleniumCommands.getTextAtLocator(POLICY_DETAILS_HEADER).split(":")[1].trim();
    }
    
    public HashMap<String, List<String>> getCoveredDriverDataFromPolicyDetailsPage() {
    		HashMap<String, List<String>> driverData = new HashMap<>();
    		seleniumCommands.clickbyJS(DRIVER_SECTION_EXPAND_BUTTON);
    		seleniumCommands.waitForElementToBeVisible(seleniumCommands.findElement(DRIVER_SECTION_EXPAND_BUTTON).findElement(By.cssSelector("span[class*='chevron_open']")));
    		List<WebElement> driverlist = seleniumCommands.findElements(COVERED_DRIVERS_ROW);
    		driverlist.forEach(el -> {
    			List<WebElement> driverdata = seleniumCommands.findElements(el , By.cssSelector("td"));
    			List<String> cellData = new ArrayList<>();
    			driverdata.forEach( td -> {
	    				cellData.add(td.getText());
	    				//System.out.println(td.getText() + " Cell data");
	    			});
    			driverData.put(cellData.get(1), cellData);
    			//System.out.println(driverData.toString() + " With Key as License No : " + cellData.get(1));
             });
    		System.out.println(driverData.toString());
    		System.out.println(driverData.containsKey(data.get("LICENSE_NUMBER")));
        return driverData;
    }

    public List<HashMap<String, String>> getVehicleDataFromPolicyDetailsPage() {
		List<HashMap<String, String>> vehicleData = new ArrayList();
		HashMap<String, String> cellData = new HashMap<String, String>();
		if(seleniumCommands.isElementNotPresent(By.xpath(VEH_SEC_EXPANDED_CSS))) {
			seleniumCommands.clickbyJS(VEHICLE_SECTION_EXPAND_BUTTON);
			seleniumCommands.waitForElementToBeVisible(By.xpath(VEH_SEC_EXPANDED_CSS));
		}
		List<WebElement> vehicleList = seleniumCommands.findElements(VEHICLE_ROW);
		vehicleList.forEach(el -> {
			List<WebElement> vehicleRowdata = seleniumCommands.findElements(el , By.xpath(".//span[contains(@class,'ng-binding')]"));
			
			vehicleRowdata.forEach( span -> {
				String heading = seleniumCommands.findElement(span , By.xpath(".//label")).getText().toUpperCase().replace(":", "");
				String value = span.getText().replace("Make", "").replace("Model", "").replace("Year:", "").replace("License Plate", "");
				cellData.put(heading, value);
    			});
			vehicleData.add(cellData);
         });
    return vehicleData;
}
    
    public Validation verifyPolicyDetailsPageWasLoaded() {
        new Validation(seleniumCommands.isElementPresent(BACK_BTN)).shouldBeTrue("Double Arrow back button wasn't loaded");
        new Validation(seleniumCommands.isElementPresent(UPLOADED_DOCS_HEADER)).shouldBeTrue("Uploaded Documents header wasn't loaded");
        return new Validation(true);
    }

    public Validation verifyTotalPremiumMatchesWithBackend() {
        String totalOnPage = seleniumCommands.getTextAtLocator(TOTAL_PREMIUM_DIV).replaceAll("[^0-9.]", "");;
        String totalFromBakcend = ParsePolicyData.getTotalPremiumData(DataFetch.getPolicyData(data.get("USER"), policyNumber));
        return new Validation(Double.parseDouble(totalOnPage), Double.parseDouble(totalFromBakcend));
    }

    public Validation verifyPrintButtonIsDisplayed() {
        return  new Validation(seleniumCommands.isElementPresent(PRINT_BTN));
    }

    public Validation verifyShowVehicleLinkIsDisplayed() {
        return  new Validation(seleniumCommands.isElementPresent(SHOW_VEHICLE_COV_LINK));
    }

    public Validation verifyCoveredDriversTableIsDisplayed() {
        return  new Validation(seleniumCommands.isElementPresent(COVERED_DRIVERS_TABLE));
    }

    public Validation verifyUploadDocButtonIsDisplayed() {
        return  new Validation(seleniumCommands.isElementPresent(UPLOAD_DOC_LABEL));
    }

    public PolicyDetailsPage goToActivitiesTile(){
        new Tiles().selectByTitle("Activities");
        Modal.waitHidden();
        return this;
    }

    public PolicyDetailsPage clickAddActivityButton() {
    		seleniumCommands.waitForLoaderToDisappearFromPage();
        ADD_ACTIVITY_BUTTON.click();
        seleniumCommands.waitForLoaderToDisappearFromPage();
        return this;
    }

    public PolicyDetailsPage deleteDuplicateDocument(){
        List<WebElement> docElement = seleniumCommands.findElements(By.cssSelector(DOC_TABLE_CSS));
        int docCount = docElement.size();
        if(docCount==0){
            logger.info("No documents already present");
            return this;
        }
        String searchValue = (data.get("DocType") + "File." + data.get("DocType")).toLowerCase();

        for (WebElement element : docElement) {
            seleniumCommands.waitForElementToContainAnyText(element);
            if (element.getText().toLowerCase().contains(searchValue)) {
                this.deleteDocument(element);
                seleniumCommands.waitForElementListHaveLessValuesThan(By.cssSelector(DOC_TABLE_CSS), docCount);
            }
        }
        return this;
    }

    public PolicyDetailsPage deleteDocument(WebElement docElement){
        docElement.findElement(By.cssSelector(DELETE_DOC_BTN_CSS)).click();
        new Modal().confirm();
        return this;
    }

    public PolicyDetailsPage expandUploadedDocTab(){
        seleniumCommands.waitForLoaderToDisappearFromPage();
        //seleniumCommands.waitForElementToBeVisible(UPLOAD_DOC_EXPAND_CSS);
        logger.info("Expanding documents");
        seleniumCommands.click(UPLOAD_DOC_EXPAND_CSS);
        this.deleteDuplicateDocument();
        return this;
    }

    public PolicyDetailsPage uploadDocFromSummary() {

        seleniumCommands.waitForElementToBeVisible(UPLOAD_DOC_BTN_CSS);
        value = seleniumCommands.findElements(By.cssSelector(DOC_TABLE_CSS)).size();
        String docType;
        if(data.containsKey("DocType"))
            docType = data.get("DocType");
        else
            docType = "SAMPLE";
        seleniumCommands.uploadPolicyDoc(UPLOAD_DOC_INPUT_CSS, docType);
        return this;
    }

    private HashMap<String, String> getDocMapForDataDocName(List<HashMap<String, String>> allDocs ) {
        if(data.containsKey("DocType")){
            logger.info("Inside doctype");
            String docName = data.get("DocType")+"File."+data.get("DocType");
            logger.debug("Searching for Document Name: " + docName);
            for ( HashMap doc : allDocs ) {
                if ( doc.containsValue(docName.toLowerCase())) {
                    return doc;
                }
            }
        }
        else{
            logger.debug("Searching for Sample File uploaded ");
            for ( HashMap doc : allDocs ) {
                if ( doc.containsValue(seleniumCommands.getFileType("SAMPLE"))) {
                    return doc;
                }
            }
        }
        return null;
    }

    //Validation
    public Validation isDocAdded() {
        seleniumCommands.waitForElementListHaveMoreValuesThan(By.cssSelector(DOC_TABLE_CSS), value);
        String searchValue = (data.get("DocType")+"File."+data.get("DocType")).toLowerCase();
        return new Validation(seleniumCommands.findElements(By.cssSelector(DOC_TABLE_CSS)).get(value).getText().toLowerCase().contains(searchValue));
    }

    public Validation isDocAddedInBackend()throws Exception{
        return MapCompare.compareMap(data,this.getDocMapForDataDocName(ParsePolicyData.getPolicyDocumentDataFromBackEnd(DataFetch.getAccountPolicyData(this.getPolicyID()))));
    }
    
    public Validation isDriverAvailableOnPolicyDetailsPage()throws Exception{
    		HashMap<String, List<String>> driverMap = this.getCoveredDriverDataFromPolicyDetailsPage();
    		if(!driverMap.containsKey(data.get("LICENSE_NUMBER"))) {
    			return new Validation(false);
    		}
    		List<String> driverData = driverMap.get(data.get("LICENSE_NUMBER"));
    		new Validation(driverData.get(0), data.get("FIRST_NAME") + " " + data.get("LAST_NAME")).shouldBeEqual("Driver name is not matched");
        return new Validation(true);
    }
    
    public Validation isVehicleAvailableOnPolicyDetailsPage(HashMap<String, String> vehicleData, HashMap<String, String> data)throws Exception{
    	seleniumCommands.logInfo("Checking vehicle on policy details page");
    		boolean flag = vehicleData.get("YEAR").equals(data.get("VehicleYear")) 
    				&& vehicleData.get("MODEL").equals(data.get("Model"))
    				&& vehicleData.get("MAKE").equals(data.get("Make"));
		return new Validation(flag);
    }
    
    public void verifyLeaderBoardBannerText() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        new Validation(seleniumCommands.isElementPresent(PERSONALIZED_LEADER_BOARD_AD)).shouldBeTrue(AMPAssertionLogConstants.PERSONALISED_OFFER_RECTANGLE_AD_LOG);
        new Validation(seleniumCommands.isTextPresent(PERSONALIZED_LEADER_BOARD_AD, AMPAssertionConstants.PERSONALISED_OFFER_LEADER_BOARD_AD_TEXT)).shouldBeTrue(AMPAssertionLogConstants.PERSONALISED_OFFER_RECTANGLE_AD_LOG);
    }
    
    public void verifyClickRedirectionLeaderBoardOfferBanner() {
        seleniumCommands.click(PERSONALIZED_LEADER_BOARD_AD);
        EndorsementPage endorsementPage = new EndorsementPage();
        endorsementPage.isEndorsementWizardDisplayed().shouldBeTrue(AMPAssertionLogConstants.PERSONALISED_OFFER_CLICK_REDIRECTION_LOG);
    }
    
    public void isPolicyTransactionPresent() {
        String jsonData = DataFetch.getPolicyChangeData(data.get(PolicyData.POLICY_NUM.toString()), data.get("USER"));
        new Validation(DataFormatUtil.isTransactionAvailable(jsonData), "No Transaction Available").shouldNotBeEqual("Policy change transaction is present");
    }
    
}
