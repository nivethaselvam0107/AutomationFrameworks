package com.guidewire.capabilities.amp.model.page;

import com.guidewire.capabilities.billing.model.page.AutomaticPaymentsPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.claims.model.page.AMP_ClaimListPage;
import com.guidewire.capabilities.common.model.page.AdditionalEnrollmentPage;
import com.guidewire.capabilities.endorsement.model.page.pa.EndorsementPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DateUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseBillingData;
import com.guidewire.data.StringConstants.AMPAssertionConstants;
import com.guidewire.data.StringConstants.AMPAssertionLogConstants;
import com.guidewire.portals.claimportal.pages.NewClaimDOLPage;
import io.restassured.path.json.JsonPath;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class AccountSummaryPage {

	SeleniumCommands seleniumCommands = new SeleniumCommands();
	HashMap<String, String> data = ThreadLocalObject.getData();
	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());

	@FindBy(css = ".gw-account-detail")
	WebElement ACCOUNT_PAGE;

	@FindBy(css = ".gw-page-title")
	WebElement PAGE_TITLE_CSS;

	@FindBy(css = "[class*='gw-links']")
	WebElement QUICK_LINK_CSS;

	@FindBy(css = ".gw-policy-outer")
	WebElement POLICY_LIST_CSS;

	@FindBy(xpath = "//div/a[contains(@href,'document')]")
	WebElement PRINT_ID_LINK;

	@FindBy(xpath = "//a[contains(@href,'policyDocument')][@aria-hidden='false']")
	WebElement PRINT_ID_CELL;

	@FindBy(linkText = "Setup Automatic Payments")
	WebElement SETUP_AUTOMATIC_PAYMENTS_LINK;

	@FindBy(xpath = "//a[@href='#/ampusersprofile']")
	WebElement UPDATE_MY_DETAILS_LINK;

	@FindBy(xpath = "//a[@href='#/endorsement']")
	WebElement CHANGE_MY_POLICY_LINK;

	@FindBy(css = "[class*='gw-header-nav'] a[href='#/billing-summary/']")
	WebElement BILLING_SUMMARY_LINK;

	@FindBy(css = "[billing-summary-tiles]")
	WebElement BILLING_SUMMARY_TILES_DIV;

	@FindBy(css = "[class='gw-billing-tile_container'] a[href='#/make-payment']")
	WebElement PAY_NOW_LINK;

	@FindBy(css = "[gw-policy-account-policies-summary]")
	WebElement ACCOUNT_POLICIES_SUMMARY_DIV;

	@FindBy(xpath = "//*[@href='#/fnol']")
	WebElement FILE_A_CLAIM_LINK;

	@FindBy(css = "[class='gw-pl-dropdown-wrapper']")
	WebElement ACCOUNT_INFORMATION_DROPDOWN;

	@FindBy(css = ".gw-billing-tile_tile:nth-of-type(2) [data-gw-test='nextInvoice']")
	WebElement NEXT_INVOICE_SPAN;

	@FindBy(css = ".gw-dropdown-menu")
	WebElement DROPDOWN_MENU;

	@FindBy(css = ".gw-billing-tile_tile:nth-of-type(3) [data-gw-test='lastPayment']")
	WebElement LAST_PAYMENT_SPAN;

	@FindBy(css = ".gw-billing-tile_tile:nth-of-type(3) [data-gw-test='paymentDate']")
	WebElement LAST_PAYMENT_DATE_CSS;

	@FindBy(css = ".gw-billing-tile_tile:nth-of-type(1) [data-gw-test='earliestDue']")
	WebElement BALANCE_DATE_CSS;

	@FindBy(css = ".gw-billing-tile_tile:nth-of-type(2) [data-gw-test='dueDate']")
	WebElement NXT_INVOICE_DATE_CSS;

	@FindBy(css = "td[class='gw-line ng-binding']")
	WebElement POLICY_TYPE_COL_CSS;

	@FindBy(css = "td[class='gw-status ng-binding']")
	WebElement POLICY_STATUS_COL_CSS;

	@FindBy(css = "td[class='gw-policy ng-binding']")
	WebElement POLICY_NUM_COL_CSS;

	@FindBy(css = "td[class='gw-effective ng-binding']")
	WebElement POLICY_EFFDATE_COL_CSS;

	@FindBy(css = "td[class='gw-premium ng-binding']")
	WebElement POLICY_PREMIUM_COL_CSS;

	@FindBy(css = "td[class='gw-id-card ng-binding']")
	WebElement POLICY_IDCARD_COL_CSS;

	@FindBy(css = "td[class='gw-fnol ng-binding']")
	WebElement POLICY_FNOL_COL_CSS;
	
	@FindBy(css = "[data-gw-test='overdue']")
	WebElement OVER_DUE_VALUE_CSS;

	@FindBy(css = "[data-gw-test='current']")
	WebElement CURRENT_VALUE_CSS;

	@FindBy(css = "[data-gw-test='balance']")
	WebElement BALANCE_VALUE_SPAN;

	@FindBy(css = ".gw-policy > .gw-action-link")
	List<WebElement> POLICY_NUMBER_LINKS;

	@FindBy(css = ".gw-header-left-part .gw-vertical-align-item")
	WebElement HOME_BUTTON;

	@FindBy(css = "[class*='gw-header-nav'] [href='#/claims/list']")
	WebElement CLAIM_TAB;

	@FindBy(css = "a[href='#endorsement'] div[ng-if] div")
	WebElement PERSONALIZED_OFFER_RECTANGLE_AD;

	@FindBy(css = "a[href='#/endorsement']")
	WebElement POLICYCHANGE_LINK;

	@FindBy(css = "[class*='gw-header-nav'] a[href='#/additionalEnrollment']")
	WebElement ADDITIONAL_ENROLLMENT;

	@FindBy(css = ".gw-links")
	WebElement LINKS;

	@FindBy(css = "gw-segmentation-option[default-option] .gw-user-info")
	WebElement AGENT_CONTACT_DETAILS;

	@FindBy(css = "gw-segmentation-option[default-option] div.gw-media-sidebar")
	WebElement MEDIA_SIDEBAR;

	By MAKE_A_PAYMENT_LINK_DISABLED = By.cssSelector("[class*='QuickLinks'] div[aria-hidden='true'] a[href='#/make-payment']");

	By MAKE_A_PAYMENT_LINK =  By.cssSelector("[class*='QuickLinks'] a[href='#/make-payment']");

	By COMMON_AGENT_CONTACT_BOX = By.className("gw-user-info");

	By INDIVIDUAL_AGENT_CONTACT_COLUMN = By.cssSelector("th[attribute=agent]");

	By INDIVIDUAL_AGENT_CONTACT_INFO = By.cssSelector("td[attribute=agent]");
	
	static final String MODAL_BACKDROP = ".gw-modal-backdrop";
	
	final String POLICY_TABLE_COL_COUNT_CSS = "[class='gw-table gw-policy-summaries'] tbody tr:nth-of-type(1) td";
	
	final String POLICY_TABLE_ROW_COUNT_CSS = "[class='gw-table gw-policy-summaries'] tbody tr";

	public AccountSummaryPage() {
		PageFactory.initElements(
				new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
	}

	public AccountInformationPage updateContactDetails() {
		seleniumCommands.clickbyJS(UPDATE_MY_DETAILS_LINK);
		return new AccountInformationPage();
	}

	public AccountEditPage goToAccountEditPage() {
		seleniumCommands.clickbyJS(UPDATE_MY_DETAILS_LINK);
		return new AccountEditPage();
	}

	public EndorsementPage changeMyPolicy() {
		seleniumCommands.clickbyJS(CHANGE_MY_POLICY_LINK);
		seleniumCommands.waitForElementToBeVisible(By.cssSelector("section[class='gw-endorsement-common-selection']"));
		return new EndorsementPage();
	}

	public AutomaticPaymentsPage goToAutomaticPayments() {
		seleniumCommands.clickbyJS(SETUP_AUTOMATIC_PAYMENTS_LINK);
		return new AutomaticPaymentsPage();
	}

	public AccountInformationPage goToAccountInformation() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		if (ThreadLocalObject.getBrowserName().equals("internet explorer")) {
			seleniumCommands.clickbyJS(UPDATE_MY_DETAILS_LINK);
		} else {
			seleniumCommands.click(ACCOUNT_INFORMATION_DROPDOWN);
			seleniumCommands.waitForElementToBeVisible(DROPDOWN_MENU);
			seleniumCommands.click(UPDATE_MY_DETAILS_LINK);
		}
		return new AccountInformationPage();
	}

	public boolean pageDisplayedCorrectly() {
		return seleniumCommands.isElementPresent(PAGE_TITLE_CSS)
				&& seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).equals(DataConstant.ACCOUNT_SUMMARY_TITLE_TEXT);
	}

	public MakeAPaymentPage clickOnPayNow() {
		seleniumCommands.click(PAY_NOW_LINK);
		return new MakeAPaymentPage();
	}

	public MakeAPaymentPage clickOnMakeAPayment() {
		seleniumCommands.click(MAKE_A_PAYMENT_LINK);
		return new MakeAPaymentPage();
	}

	private void goToPageFromMenu(WebElement pageLink) {
		String browser = ThreadLocalObject.getBrowserName();
		if (browser.equals("IPHONE6") || browser.equals("NEXUS5")) {
			seleniumCommands.clickbyJS(By.cssSelector("[ng-click='openDrawer(\'right\')']"));
		}
		seleniumCommands.clickbyJS(pageLink);
		seleniumCommands.waitForLoaderToDisappearFromPage();
	}

	public BillingSummaryPage goToBillingSummaryPage() {
		goToPageFromMenu(BILLING_SUMMARY_LINK);
		this.waitForBillingSummaryToAppearOnPage();
		new SeleniumCommands().staticWait(3);
		return new BillingSummaryPage();
	}

	public AdditionalEnrollmentPage goToAdditionalEnrollmentPage() {
		goToPageFromMenu(ADDITIONAL_ENROLLMENT);
		return new AdditionalEnrollmentPage();
	}

	public PolicyChangePage goToPolicyChangePage() {
		seleniumCommands.clickbyJS(POLICYCHANGE_LINK);
		seleniumCommands.waitForLoaderToDisappearFromPage();
		return new PolicyChangePage();
	}

	public BillingSummaryPage waitForBillingSummaryToAppearOnPage() {
		for(int i =0 ; i< 3; i++) {
			if (!seleniumCommands.isElementPresent(By.cssSelector("[class*='gw-billing-summary-tile gw-billing-summary-tile']"))) {
				try {
					AMP_ClaimListPage amp_claimListPage = new AccountSummaryPage().goToClaimsPage();
					seleniumCommands.waitForLoaderToDisappearFromPage();
					amp_claimListPage.goToBillingPage();
					seleniumCommands.waitForElementToBeVisible(By.cssSelector("[class*='gw-billing-summary-tile gw-billing-summary-tile']"), 30);
				} catch (Exception e) {
					LOGGER.debug(e);
				}
			}
			else {
				break;
			}
		}
		return new BillingSummaryPage();
	}

	public MakeAPaymentPage goToMakeAPaymentPage() {
		seleniumCommands.waitForElementToBeVisible(MAKE_A_PAYMENT_LINK);
		seleniumCommands.clickbyJS(MAKE_A_PAYMENT_LINK);
		seleniumCommands.staticWait(2);
		return new MakeAPaymentPage();
	}

	public NewClaimDOLPage goToMakeAClaim() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.clickbyJS(FILE_A_CLAIM_LINK);
		return new NewClaimDOLPage();
	}

	public AccountSummaryPage goToHome() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.click(HOME_BUTTON);
		return new AccountSummaryPage();
	}

	public AMP_ClaimListPage goToClaimsPage() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.click(CLAIM_TAB);
		return new AMP_ClaimListPage();
	}

	public PolicyDetailsPage goToFirstPolicyInPolicyList() {
		String policyNumber = seleniumCommands.getTextAtLocator(POLICY_NUMBER_LINKS.get(0));
		seleniumCommands.clickbyJS(POLICY_NUMBER_LINKS.get(0));
		return new PolicyDetailsPage(policyNumber);
	}

	// replacing all non numeric characters to get rid off the currency sign or
	// anything else that might get added in future
	private String getNextInvoiceAmount() {
		return seleniumCommands.getTextAtLocator(NEXT_INVOICE_SPAN).replaceAll("[^0-9.]", "");
	}

	// replacing all non numeric characters to get rid off the currency sign or
	// anything else that might get added in future
	private String getLastPaymentAmount() {
		return seleniumCommands.getTextAtLocator(LAST_PAYMENT_SPAN).replaceAll("[^0-9.]", "");
	}

	private String getCurrentAmount() {
		return seleniumCommands.getTextAtLocator(CURRENT_VALUE_CSS).replaceAll("[^0-9.]", "");
	}

	private String getOverDueAmount() {
		return seleniumCommands.getTextAtLocator(OVER_DUE_VALUE_CSS).replaceAll("[^0-9.]", "");
	}

	private String getBalanceAmount() {
		return seleniumCommands.getTextAtLocator(BALANCE_VALUE_SPAN).replaceAll("[^0-9.]", "");
	}

	private String getLastPaymentDate() {
		return seleniumCommands.getTextAtLocator(LAST_PAYMENT_DATE_CSS);
	}

	private String getBalanceDueDate() {
		return seleniumCommands.getTextAtLocator(BALANCE_DATE_CSS);
	}

	private String getNextInvoiceDate() {
		return seleniumCommands.getTextAtLocator(NXT_INVOICE_DATE_CSS);
	}

	public String getFirstPolicyNumber() {
		return seleniumCommands.getTextAtLocator(POLICY_NUMBER_LINKS.get(0));
	}

	public List<String> getPolicyNumbers() {
		return POLICY_NUMBER_LINKS.stream().map(policyNumber -> seleniumCommands.getTextAtLocator(policyNumber)).collect(Collectors.toList());
	}

	public Boolean areQuoteLinksVisible() {
		return !LINKS.findElements( By.cssSelector("div[ng-if='quoteLinkEnabled()'] a")).isEmpty();
	}

  public Boolean isPayNowButtonVisible() {
    return !PAY_NOW_LINK.getAttribute("class").contains("ng-hide");
  }

	// Validation Methods
	public Validation verifyQuickLinksDisplayed() {
		seleniumCommands.waitForElementToBeVisible(QUICK_LINK_CSS);
		new Validation(seleniumCommands.isElementPresent(PRINT_ID_LINK))
				.shouldBeTrue("Print an ID Card is not displayed");
		new Validation(seleniumCommands.isElementPresent(MAKE_A_PAYMENT_LINK))
				.shouldBeTrue("Make a Payment is not displayed");
		new Validation(seleniumCommands.isElementPresent(UPDATE_MY_DETAILS_LINK))
				.shouldBeTrue("Update My Details is not displayed");
		new Validation(seleniumCommands.isElementPresent(CHANGE_MY_POLICY_LINK))
				.shouldBeTrue("Change My Policy is not displayed");
		new Validation(seleniumCommands.isElementPresent(FILE_A_CLAIM_LINK))
				.shouldBeTrue("File a Claim is not displayed");
		return new Validation(true);
	}

	public Validation verifyPrintIDCard() {
		seleniumCommands.waitForElementToBeVisible(QUICK_LINK_CSS);
		seleniumCommands.waitForElementToBeVisible(POLICY_LIST_CSS);
		new Validation(
				seleniumCommands.isElementPresent(PRINT_ID_LINK) && seleniumCommands.isElementPresent(PRINT_ID_CELL))
						.shouldBeTrue("Print ID not available");
		return new Validation(true);
	}

	public Validation verifyMakeAPaymentNotDisplayed() {
		seleniumCommands.waitForElementToBeVisible(QUICK_LINK_CSS);
		new Validation(seleniumCommands.isElementPresent(MAKE_A_PAYMENT_LINK_DISABLED))
				.shouldBeTrue("Make a payment is incorrectly displayed on Account Summary Page");
		return new Validation(true);
	}

	public Validation isAccountPageLoaded()
	{
		return new Validation(seleniumCommands.isElementPresent(ACCOUNT_PAGE));
	}

	public Validation verifyBillingSummaryTilesDisplayed() {
		return new Validation(seleniumCommands.isElementPresent(BILLING_SUMMARY_TILES_DIV));
	}

	public Validation verifyAccountPoliciesDisplayed() {
		new Validation(seleniumCommands.isElementPresent(ACCOUNT_POLICIES_SUMMARY_DIV));
		new Validation(ACCOUNT_POLICIES_SUMMARY_DIV.findElements(By.xpath("./tbody/tr")).size() > 0);
		return new Validation(true);
	}

	public Validation verifyAccountPoliciesSectionUI() {
		new Validation(seleniumCommands.isElementPresent(POLICY_TYPE_COL_CSS)).shouldBeTrue("Policy type column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_STATUS_COL_CSS)).shouldBeTrue("Policy status column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_NUM_COL_CSS)).shouldBeTrue("Policy num column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_EFFDATE_COL_CSS)).shouldBeTrue("Policy effective date period column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_PREMIUM_COL_CSS)).shouldBeTrue("Policy premium column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_IDCARD_COL_CSS)).shouldBeTrue("Policy id card column is not displayed");
		new Validation(seleniumCommands.isElementPresent(POLICY_FNOL_COL_CSS)).shouldBeTrue("Policy file a claim column is not displayed");
		return new Validation(true);
	}

	public Validation verifyAccountPoliciesSectionData() {
		String jsonData = DataFetch.getAccountPolicySummary();
		JsonPath path = new JsonPath(jsonData);
		int policyCount = path.getList("periods").size();
		for (int i = 1; i <= policyCount ; i++) {
			int cellCount = seleniumCommands.findElements(By.cssSelector(POLICY_TABLE_COL_COUNT_CSS)).size();
			String Row = POLICY_TABLE_ROW_COUNT_CSS + ":nth-of-type("+ i +")";
			for (int j = 1; j <= cellCount ; j++) {
				switch(j) {
					case 1:
						String policyType = seleniumCommands.getAttributeValueAtLocator(By.cssSelector(Row+ " td:nth-of-type("+ j +") i"), "class");
						String policyLineBackEnd = getNodeValue(path, "periods[" + (i-1) +"]", "lines[0]").replace("[","").replace("]", "");
						if (policyLineBackEnd.equalsIgnoreCase("PersonalAutoLine")) {
							new Validation(policyType, "fa icon ng-scope fa-car").shouldBeEqual("Policy Line is not personal auto. " + policyType + ": is the class attribute instead of 'ng-scope fa-car'");
						} else {
							new Validation(false).shouldBeTrue("Policy Line details are not matched");
						}
						break;
					case 2:
						String status = seleniumCommands.getAttributeValueAtLocator(By.cssSelector(Row+ " td:nth-of-type("+ j +") span"), "class");
						String policyExpDate = getNodeValue(path, "periods[" + (i-1) +"]", "expiration").replace("[","").replace("]", "");
						if (DateUtil.checkISODateIsAfterToday(policyExpDate)) {
							new Validation(status, "fa fa-check").shouldBeEqual("Policy status is not Active");
						} else {
							new Validation(false).shouldBeTrue("Policy status details are not matched");
						}
						break;
					case 3:
						String policyNum = seleniumCommands.getTextAtLocator(By.cssSelector(Row+ " td:nth-of-type("+ j +") a"));
						String policyNumFromBackEnd = getNodeValue(path, "periods[" + (i-1) +"]", "policyId").replace("[","").replace("]", "");
						new Validation(policyNum, policyNumFromBackEnd).shouldBeEqual("Policy number is not matched");
						break;
					case 4:
						String policyPeriodUI = seleniumCommands.getTextAtLocator(By.cssSelector(Row+ " td:nth-of-type("+ j +")"));
						String policyStartDate = getNodeValue(path, "periods[" + (i-1) +"]", "effective").replace("[","").replace("]", "");
						String policyExpiDate = getNodeValue(path, "periods[" + (i-1) +"]", "expiration").replace("[","").replace("]", "");
						String policyPeriod = DateUtil.getDateFromISODateToMMDDYY(policyStartDate) + " - " + DateUtil.getDateFromISODateToMMDDYY(policyExpiDate);
						new Validation(policyPeriodUI, policyPeriod).shouldBeEqual("Policy period is not matched");
						break;
					case 5:
						String premium = seleniumCommands.getTextAtLocator(By.cssSelector(Row+ " td:nth-of-type("+ j +")")).replaceAll("[^0-9.]", "");
						String policyPremium = getNodeValue(path, "periods[" + (i-1) +"].premium", "amount").replace("[","").replace("]", "");
						new Validation(Double.parseDouble(premium), Double.parseDouble(policyPremium)).shouldBeEqual("Policy premium is not matched");
						break;
					case 8:
						new Validation(seleniumCommands.isElementPresent(By.cssSelector(Row+ " td:nth-of-type("+ j +")")));
						break;
				}
			}
		}

		return new Validation(true);
	}

	public Validation verifyNextInvoiceMatchesBackend(String jsonBillingData) {
		LOGGER.info("Validating the Next Invoice section");
		String nextInvoiceFromBackend = ParseBillingData.getNextInvoice(jsonBillingData);
		new Validation(Double.parseDouble(getNextInvoiceAmount()), Double.parseDouble(nextInvoiceFromBackend))
				.shouldBeEqual("Next invoice amt is not matched");
		new Validation(getNextInvoiceDate(), ParseBillingData.getNextInvoiceDueDate(jsonBillingData))
				.shouldBeEqual("Next invoice date is not matched");
		return new Validation(true);
	}

	public Validation verifyLastPaymentMatchesBackend(String jsonBillingData) {
		LOGGER.info("Validating the LastPayment section");
		String lastPaymentFromBackend = ParseBillingData.getLastPaymentData(jsonBillingData);
		new Validation(getLastPaymentDate(), ParseBillingData.getLastPaymentDate(jsonBillingData))
				.shouldBeEqual("Last payment date not matched");
		new Validation(Double.parseDouble(getLastPaymentAmount()), Double.parseDouble(lastPaymentFromBackend))
				.shouldBeEqual("Last payment did not match");
		return new Validation(true);
	}

	public Validation verifyMyBalanceDetailsMatchesBackend(String jsonBillingData) {
		LOGGER.info("Validating the My balance section");
		double overDue = ParseBillingData.getOverDudeBalanceData(jsonBillingData);
		double current = ParseBillingData.getCurrentBilledData(jsonBillingData);
		DecimalFormat df = new DecimalFormat("#.##");      
		overDue = Double.valueOf(df.format(overDue));
		new Validation(overDue, Double.parseDouble(getOverDueAmount())).shouldBeEqual("Overdue amount is not matched");
		if(!getCurrentAmount().isEmpty())
		{
			new Validation(current, Double.parseDouble(getCurrentAmount())).shouldBeEqual("Current amount is not matched");
		}
		new Validation(current + overDue, Double.parseDouble(getBalanceAmount()))
				.shouldBeEqual("Balance amount is not matched");
		new Validation(getBalanceDueDate(), ParseBillingData.getBalanceDueDate(jsonBillingData))
				.shouldBeEqual("Balance due date is not matched");
		return new Validation(true);
	}

	public void verifyCommonAgentContactDetailsVisibility(boolean expectedVisibility) {
		LOGGER.info("Validating common agent contact details");
		boolean agentContactDetailsVisible = MEDIA_SIDEBAR.findElements(COMMON_AGENT_CONTACT_BOX).size() > 0;
		new Validation(agentContactDetailsVisible, expectedVisibility)
				.shouldBeEqual("Common agent contact details box doesn't match expected visibility state: " + expectedVisibility);
	}

	public void verifyIndividualAgentsContactDetailsVisibility(boolean expectedVisibility) {
		LOGGER.info("Validating individual agents contact details");

		boolean individualAgentsContactsColumnVisibility = POLICY_LIST_CSS.findElements(INDIVIDUAL_AGENT_CONTACT_COLUMN).size() > 0;
		new Validation(individualAgentsContactsColumnVisibility, expectedVisibility)
				.shouldBeEqual("Individual agents contacts column doesn't match expected visibility state: " + expectedVisibility);

		List<WebElement> individualAgentsContactDetails = POLICY_LIST_CSS.findElements(INDIVIDUAL_AGENT_CONTACT_INFO);
		boolean individualAgentsContactDetailsVisibility = individualAgentsContactDetails.size() > 0
				&& individualAgentsContactDetails.stream().noneMatch(contactDetails -> contactDetails.getText().isEmpty());
		new Validation(individualAgentsContactDetailsVisibility, expectedVisibility)
				.shouldBeEqual("Individual agents contacts details don't match expected visibility state: " + expectedVisibility);
	}
	
	 private String getNodeValue(JsonPath path, String nodePath, String nodeName) {
			String value = null;
			try {
				value = path.setRoot(nodePath).get(nodeName).toString().replace(",", "");
			} catch (Exception e) {
				LOGGER.warn(e);
			}
			return value;
		}
	  public void verifyPersonalizedOfferBanner() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		new Validation(seleniumCommands.isElementPresent(PERSONALIZED_OFFER_RECTANGLE_AD)).shouldBeTrue("PO not Present");
		new Validation(seleniumCommands.isTextPresent(PERSONALIZED_OFFER_RECTANGLE_AD, AMPAssertionConstants.PERSONALISED_OFFER_RECTANGLE_AD_TEXT))
				.shouldBeTrue(AMPAssertionLogConstants.PERSONALISED_OFFER_RECTANGLE_AD_LOG);
	   }
	  public void verifyClickRedirectionPersonalizedOfferBanner() {
		seleniumCommands.click(PERSONALIZED_OFFER_RECTANGLE_AD);
		EndorsementPage endorsementPage = new EndorsementPage();
		endorsementPage.isEndorsementWizardDisplayed().shouldBeTrue(AMPAssertionLogConstants.PERSONALISED_OFFER_CLICK_REDIRECTION_LOG);
	   }

}
