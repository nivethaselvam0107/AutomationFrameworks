package com.guidewire.capabilities.amp.model.page;

import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataConstant;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.List;
import java.util.stream.Collectors;

public class PolicyChangePage {

  @FindBy(css = ".gw-endorsement-tile")
  private List<WebElement> POLICY_TILES;

  public PolicyChangePage() {
    PageFactory.initElements(
        new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
  }

  public List<String> getPolicyNumbers() {
    return POLICY_TILES.stream()
        .map(element -> element.getAttribute("data-gw-test-policy-no")).collect(Collectors.toList());
  }
}
