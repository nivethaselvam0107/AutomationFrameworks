package com.guidewire.capabilities.amp.test;

import com.guidewire.capabilities.amp.model.page.AccountDetails;
import com.guidewire.capabilities.amp.model.page.AccountEditPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.List;

public class AccountEditPageTest {

  Pagefactory pagefactory = new Pagefactory();

  @Parameters("browserName")
  @Test(groups = {"REG_EMR" , "REG_DIA"})
  public void testAccountDetailsHeaderHasNoPolicyNumberForSingleAccountUser(String browserName) {
    PolicyGenerator.createBasicBoundPAPolicy();

    AccountEditPage accountEditPage = pagefactory.getAccountEditPage();
    Assert.assertEquals(accountEditPage.getNumberOfAccountDetails(), 1);

    AccountDetails details = accountEditPage.getAccountDetailsByIndex(0);
    Assert.assertEquals(details.getHeaderText(), "Account Details");
  }

  @Parameters("browserName")
  @Test(groups = {"REG_EMR" , "REG_DIA"})
  public void testAccountDetailsHeaderHasPoliciesNumbersForMultiAccountUser(String browserName) {
    List<String> policyNumbers = Arrays.asList(
      PolicyGenerator.createBasicBoundPAPolicy(),
      PolicyGenerator.createBasicBoundPAPolicy()
    );

    AccountEditPage accountEditPage = pagefactory.getAccountEditPage();
    Assert.assertEquals(accountEditPage.getNumberOfAccountDetails(), 2);

    boolean allPolicyNumbersAreShownInHeaders = policyNumbers.stream()
        .allMatch(accountEditPage::hasPolicyNumberInAnyHeader);

    Assert.assertTrue(allPolicyNumbersAreShownInHeaders);
  }
}
