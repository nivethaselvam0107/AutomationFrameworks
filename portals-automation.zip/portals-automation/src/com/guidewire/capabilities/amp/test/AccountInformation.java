package com.guidewire.capabilities.amp.test;

import java.text.ParseException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountInformationPage;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;

public class AccountInformation {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"})
    public void testInfoCorrectAccountInfoPage(String browserName) throws ParseException {
        logger.info("Running Test: AMP-047 Verify that correct information is displayed in Account Information Screen");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToAccountInformation().verifyDataMatchesPC().shouldBeTrue("Account information data does not match PC data");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"})
    public void testUserCannotDirectlyChangeAddress(String browserName) throws ParseException {
        logger.info("Running Test: AMP-048 Verify that user cannot change directly the Address in Account Information Screen");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        // Can fail if modal message is not displayed or if address update is persisted to PC
        accountSummaryPage = accountSummaryPage.goToAccountInformation().updatePhone().submitFormChanges().closeUpdateSubmissionModal(AccountInformationPage.UpdateTypes.PHONE)
                .goToAccountInformation().updateAddress().submitFormChanges().closeUpdateSubmissionModal(AccountInformationPage.UpdateTypes.ADDRESS);
        if(accountSummaryPage != null) {
            accountSummaryPage.goToAccountInformation().verifyPageDisplayedCorrectly().shouldBeTrue("Address information incorrectly updated");
        }
        else {
            Assert.fail("Failed to display address update confirmation modal and return to account summary page.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA" })
    public void testUserCanChangePhone(String browserName) throws ParseException {
        logger.info("Running Test: AMP-049 Verify that user can update Phone and Email in Account Information Screen");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToAccountInformation().updatePhone().submitFormChanges().closeUpdateSubmissionModal(AccountInformationPage.UpdateTypes.PHONE)
                .goToAccountInformation().verifyPageDisplayedCorrectly().shouldBeTrue("Phone information was not updated correctly");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"})
    public void testAddressNotChangedWithPhone(String browserName) throws ParseException {
        logger.info("Running Test: AMP-050 Verify that Address is not directly updated when user updated Email and Phone");

        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        // Can fail if modal message is not displayed or if address update is persisted to PC
        accountSummaryPage = accountSummaryPage.goToAccountInformation().updateAddress().updatePhone().submitFormChanges().closeUpdateSubmissionModal(AccountInformationPage.UpdateTypes.ADDRESS);
        if(accountSummaryPage != null) {
            accountSummaryPage.goToAccountInformation().verifyPageDisplayedCorrectly().shouldBeTrue("Phone information was not updated correctly or address was updated incorrectly");
        }
        else {
            Assert.fail("Failed to display address update confirmation modal and return to account summary page.");
        }
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA",})
    public void testCancelInformationChange(String browserName) {
        logger.info("Running Test: AMP-051 Verify Account information link.");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToAccountInformation().verifyCancelWorks().shouldBeTrue("Cancelling account information change failed");
    }
}
