package com.guidewire.capabilities.amp.test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyChangePage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;

import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import io.restassured.path.json.JsonPath;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.List;

public class PolicyChangePageTest {

  Pagefactory pagefactory = new Pagefactory();

  @Parameters("browserName")
  @Test(groups = {"Emerald","Ferrite","Granite", "Diamond", "SMOKE"} , description = "TC12497: Verify policy change page")
  public void testPolicyChangePageShowingPoliciesFromMultipleAccounts(String browserName) {
    String policyNum1 = PolicyGenerator.createBasicBoundPAPolicy();
    String policyNum2 = PolicyGenerator.createBasicBoundPAPolicy();

    JsonPath path = new JsonPath(DataFetch.getAgentPolicyDataAsSU(policyNum1));
    String accountNumber = DataFormatUtil.getNodeValue(path,"account", "accountNumber");
    String user = ThreadLocalObject.getData().get("USER");
    AuthorisationServer.assignAccountCodeToExistingUser(ThreadLocalObject.getData().get("USER"), accountNumber);

    AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    PolicyChangePage policyChangePage = accountSummaryPage.goToPolicyChangePage();
    List<String> policyNumbers = policyChangePage.getPolicyNumbers();

    Assert.assertTrue(policyNumbers.contains(policyNum1), "Could not find policy from first account");
    Assert.assertTrue(policyNumbers.contains(policyNum2), "Could not find policy from second account");
  }
}
