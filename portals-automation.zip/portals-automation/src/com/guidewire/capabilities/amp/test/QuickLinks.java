package com.guidewire.capabilities.amp.test;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountInformationPage;
import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;

public class QuickLinks {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3164 : Verify the Quick Links on Account Summary Page")
    public void testQuickLinksOnAccountSummaryPage(String browserName) {
        logger.info("Running Test: AMP-023 Verify the Quick Links on Account Summary Page");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.verifyQuickLinksDisplayed().shouldBeTrue("All quick links on Account Summary page not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" },  description ="TC3165 : Verify Quick Link Print an ID card prints the ID")
    public void testPrintIDOnAccountSummaryPage(String browserName) {
        logger.info("Running Test: AMP-024 Verify Quick Link Print an ID card prints the ID");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.verifyPrintIDCard().shouldBeTrue("Print ID Card not available on Account Summary Page");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3166 : Verify Quick Link Make a Payment")
    public void testMakeAPaymentLink(String browserName) throws Exception{
        logger.info("Running Test: AMP-025 Verify Quick Link Make a Payment");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.clickOnMakeAPayment().verifyPageDisplayedCorrectly().shouldBeTrue("Failed to reach the Make a Payment screen using Make a Payment.");
    }

    //Backend apis are not working for this test
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "AMP-68 : Verify Quick Link Update Contact Information", enabled = false)
    public void testUpdateDetailsOnAccountSummaryPage(String browserName) throws Exception{
        logger.info("Running Test: AMP-026 Verify Quick Link Update Contact Information");
        AccountInformationPage accountInformationPage = pagefactory.getAccountInformationPage();
        accountInformationPage.verifyPageDisplayedCorrectly().shouldBeTrue("All panels on Account Information page not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" },  enabled = false)
    public void testMakePaymentNotDisplayedOnAccountSummaryPage(String browserName) {
        logger.info("Running Test: AMP-029 Verify that Make A Payments quick link is not be displayed if automatic payments have been setup for all invoice streams");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToAutomaticPayments()
                .setupAutomaticPayments().returnToSummary().verifyMakeAPaymentNotDisplayed()
                .shouldBeTrue("Make a payment incorrectly displayed.");
    }
}
