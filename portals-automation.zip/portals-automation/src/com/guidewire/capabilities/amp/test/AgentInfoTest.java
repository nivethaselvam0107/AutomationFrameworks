package com.guidewire.capabilities.amp.test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import org.apache.log4j.Logger;
import org.testng.SkipException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AgentInfoTest {

  Pagefactory pagefactory = new Pagefactory();
  Logger logger = Logger.getLogger(this.getClass().getName());

  @BeforeMethod
  public void ensureAppropriatePlatformVersion() {
    if (!System.getProperty("platform").equalsIgnoreCase("granite")) {
      throw new SkipException("Skipping due to sample data inconsistency across platform versions");
    }
  }

  @Parameters("browserName")
  @Test(groups = { "REG_EMR", "SMOKE" }, description = "TC13078: Verify multiple agent contact entries are displayed when they differ (and only than)")
  public void testSingleProducerContactIsDisplayedForSingleAccountUserWithSingleProducer(String browserName) throws Exception {
    AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    accountSummaryPage.verifyCommonAgentContactDetailsVisibility(true);
    accountSummaryPage.verifyIndividualAgentsContactDetailsVisibility(false);
  }

  @Parameters("browserName")
  @Test(groups = { "REG_EMR", "SMOKE" }, description = "TC13078: Verify multiple agent contact entries are displayed when they differ (and only than)")
  public void testMultipleProducerContactsAreDisplayedForSingleAccountUserWithMultipleProducers(String browserName) throws Exception {
    AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    accountSummaryPage.verifyCommonAgentContactDetailsVisibility(false);
    accountSummaryPage.verifyIndividualAgentsContactDetailsVisibility(true);
  }

  @Parameters("browserName")
  @Test(groups = { "REG_EMR", "SMOKE" }, description = "TC13078: Verify multiple agent contact entries are displayed when they differ (and only than)")
  public void testSingleProducerContactIsDisplayedForMultiAccountUserWithSingleProducer(String browserName) throws Exception {
    AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    accountSummaryPage.verifyCommonAgentContactDetailsVisibility(true);
    accountSummaryPage.verifyIndividualAgentsContactDetailsVisibility(false);
  }

  @Parameters("browserName")
  @Test(groups = { "REG_EMR", "SMOKE" }, description = "TC13078: Verify multiple agent contact entries are displayed when they differ (and only than)")
  public void testMultipleProducerContactsAreDisplayedForMultiAccountUserWithMultipleProducers(String browserName) throws Exception {
    AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    accountSummaryPage.verifyCommonAgentContactDetailsVisibility(false);
    accountSummaryPage.verifyIndividualAgentsContactDetailsVisibility(true);
  }
}
