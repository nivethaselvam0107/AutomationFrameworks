package com.guidewire.capabilities.amp.test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AdditionalEnrollmentPage;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.common.model.page.SignUpEnrollmentPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AdditionalEnrollmentPageTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());


    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" },
            description = "TC12340: Additional Enrollment in AMP")
    public void testAMPAdditionalEnrollementFormUI(String browserName) throws Exception {
        logger.info("Running Test: testAMPAdditionalEnrollementFormUI");
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton();
        PolicyGenerator.createBasicBoundPAPolicy();
        new SignUpEnrollmentPage()
                .setAccountEnrollmentData()
                .clickAddPolicy()
                .isEnrollmentSuccessful();
        //first account is connected
        String firstPolicyNumber = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());

        new Validation( new AccountSummaryPage().getFirstPolicyNumber(), firstPolicyNumber).shouldBeEqual();

        String policyNew = PolicyGenerator.createBasicBoundPAPolicy();
        new SeleniumCommands().staticWait(3);
        AdditionalEnrollmentPage additionalEnrollmentPage = pagefactory.goToAdditionalEnrollmentPage();
        additionalEnrollmentPage
                .setAccountEnrollmentData()
                .clickEnrol()
                .isEnrollmentSuccessful()
                .clickReturn();

        String additionalPolicyNumber = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
        new Validation( new AccountSummaryPage().getPolicyNumbers().contains(firstPolicyNumber)).shouldBeTrue("Policies list should still contain first policy");
        new Validation( new AccountSummaryPage().getPolicyNumbers().contains(additionalPolicyNumber)).shouldBeTrue("Policies list should contain added policy number");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" },
            description = "TC12347: Failed Enrollment in AMP")
    public void testAMPAdditionalEnrollementFailed(String browserName) throws Exception {
        logger.info("Running Test: testAMPAdditionalEnrollementFailed");
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton();
        PolicyGenerator.createBasicBoundPAPolicy();
        new SignUpEnrollmentPage()
                .setAccountEnrollmentData()
                .clickAddPolicy()
                .isEnrollmentSuccessful();
        //first account is connected
        String firstPolicyNumber = ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString());
        new Validation( new AccountSummaryPage().getFirstPolicyNumber(), firstPolicyNumber).shouldBeEqual();

        String fakePolicyNumber = "9393";
        ThreadLocalObject.getData().put(PolicyData.POLICY_NUM.toString(), fakePolicyNumber);

        PolicyGenerator.createBasicBoundHOPolicy();
        AdditionalEnrollmentPage additionalEnrollmentPage = pagefactory.goToAdditionalEnrollmentPage();
        additionalEnrollmentPage
                .setAccountEnrollmentData()
                .clickEnrol()
                .clickReturn();

        new Validation( new AccountSummaryPage().getPolicyNumbers().contains(firstPolicyNumber)).shouldBeTrue("Policies list should still contain first policy");
        new Validation( new AccountSummaryPage().getPolicyNumbers().contains(fakePolicyNumber)).shouldBeFalse("There should be no new policy on the list");
    }
}
