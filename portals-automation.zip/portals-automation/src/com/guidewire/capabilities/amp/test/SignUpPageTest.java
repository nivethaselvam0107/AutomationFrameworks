package com.guidewire.capabilities.amp.test;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.capabilities.common.model.page.SignUpEnrollmentPage;
import com.guidewire.capabilities.common.model.page.SignUpPage;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.PolicyData;

/**
 * Created by smcdonnell on 24/05/2017.
 */
public class SignUpPageTest {

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" },
            description = "TC2962: SignUpPageAMP")
    public void testAMPSignUp(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton()
                .isSignUpSuccessful();
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" },
            description = "TC2962: SignUpPageAMP, TC6452: Enrollment in AMP")
    public void testAMPUserEnrollementFormUI(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton();
        PolicyGenerator.createBasicBoundPAPolicy();
        new SignUpEnrollmentPage()
                .setAccountEnrollmentData()
                .clickAddPolicy()
                .isEnrollmentSuccessful();
        new Validation( new AccountSummaryPage().getFirstPolicyNumber(), ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeEqual();
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" },
            description = "TC6634: 	Self Enrollment - Enter Your Details mandatory fields validation")
    public void testAMPPolicyDetailsPageMandatoryFields(String browserName) throws Exception {
    	SignUpPage signUpPage = new LoginPage().goToSignUpPage()
                .setSignUpData()
                .clickSignUpButton();
    	new SignUpEnrollmentPage().clickAddPolicy().validateSignUpEnrollmentPageMandatoryField();
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" },
            description = "TC6457: 	Enroll in PC user with company account")
    public void testAMPCompanyUserEnrollmentInPC(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	String policyNumUI = new Pagefactory().getAccountSummaryPage().getFirstPolicyNumber();
    	new Validation(policyNumUI, ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeEqual();
    }
    
    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" },
            description = "TC6453: 	Enrollment of accountholder in PC")
    public void testAMPAccountUserEnrollmentInPC(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
    	String policyNumUI = new Pagefactory().getAccountSummaryPage().getFirstPolicyNumber();
    	new Validation(policyNumUI, ThreadLocalObject.getData().get(PolicyData.POLICY_NUM.toString())).shouldBeEqual();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SIGN_UP" },
            description = "TC2968: SignUpPageAMPFieldDataMissing, TC6455: Self enrollment in AMP - mandatory fields")
    public void testAMPSignUpMissingDataValidation(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .clickSignUpButton()
                .isMissingDataValidationMessageDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SIGN_UP" },
            description ="TC4472: SignUpPage-ValidEmailAddress")
    public void testAMPSignUpEmailFieldValidation(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .inputIncorrectEmailFormat()
                .clickSignUpButton()
                .isIncorrectEmailValidationMessageDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SIGN_UP" },
            description = "TC2967: SignUpPageAMPPasswordAndConfirmPasswordMismatch")
    public void testAMPSignUpPasswordMismatchValidation(String browserName) throws Exception {
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .changeConfirmPassword()
                .clickSignUpButton()
                .isPasswordValidationMessageDisplayed();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SIGN_UP" },
            description = "TC2969: SignUpPageEmailAlreadyRegistered")
    public void testAMPSignUpEmailAlreadyRegistered(String browserName) throws Exception {
    	PolicyGenerator.createBasicBoundPAPolicy();
        new LoginPage().goToSignUpPage()
                .setSignUpData()
                .inputPreviouslyRegisteredEmail()
                .clickSignUpButton()
                .isEmailAlreadyExistsMessageDisplayed();
    }
}
