package com.guidewire.capabilities.amp.test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.capabilities.common.model.page.LoginPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import io.restassured.path.json.JsonPath;
import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class LandingPage {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" } , description = "AMP-004 : Verify Landing page")
    public void testBillingTilesAndPolicyDataPresent(String browserName) {
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.verifyBillingSummaryTilesDisplayed().shouldBeTrue("Billing summary tiles have not been loaded");
        accountSummaryPage.verifyAccountPoliciesDisplayed().shouldBeTrue("Account policy details have not been loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond", "SMOKE"} , description = "TC4220 : Verify Account Summary section", enabled = false)
    public void testAccountSummaryNumbers(String browserName) throws Exception {
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        String jsonData = DataFetch.getBillingData(DataFetch.fetchUaaToken());
        accountSummaryPage.verifyLastPaymentMatchesBackend(jsonData).shouldBeTrue();
        accountSummaryPage.verifyMyBalanceDetailsMatchesBackend(jsonData).shouldBeTrue();
        accountSummaryPage.verifyNextInvoiceMatchesBackend(jsonData).shouldBeTrue();
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, enabled = false, description = "TC4219 : Display of policies" )
    public void testPolicyDetailsSectionOnSummaryPage(String browserName) {
    		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
    		accountSummaryPage.verifyAccountPoliciesSectionUI().shouldBeTrue();
    		accountSummaryPage.verifyAccountPoliciesSectionData().shouldBeTrue();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, enabled = false)
    public void testPolicyDetailsPageTotalPremiumMatchesBackend(String browserName) {
        PolicyDetailsPage policyDetailsPage = pagefactory.getAccountSummaryPage().goToFirstPolicyInPolicyList();
        policyDetailsPage.verifyTotalPremiumMatchesWithBackend().shouldBeEqual("The total premium displayed does not match the backend");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" ,"Diamond", "SMOKE" } , enabled = false)
    public void testPolicyDetailsPageWasLoadedCorrectly(String browserName) {
        PolicyDetailsPage policyDetailsPage = pagefactory.getAccountSummaryPage().goToFirstPolicyInPolicyList();
        policyDetailsPage.verifyPrintButtonIsDisplayed().shouldBeTrue("Print button has not been loaded");
        policyDetailsPage.verifyShowVehicleLinkIsDisplayed().shouldBeTrue("Show vehicle coverages link has not been loaded");
        policyDetailsPage.verifyCoveredDriversTableIsDisplayed().shouldBeTrue("Covered drivers table has not been loaded");
        policyDetailsPage.verifyUploadDocButtonIsDisplayed().shouldBeTrue("Upload documents button has not been loaded");
        policyDetailsPage.goToAccountSummaryPage().verifyBillingSummaryTilesDisplayed().shouldBeTrue("Account Summary Page has not been loaded");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond"}, description = "TC3170 : Verify if its possible to print or view the policy documents")
    public void testPolicyDetailsPagePrintButton(String browserName) {
        PolicyGenerator.createBasicBoundPAPolicy();
        PolicyDetailsPage policyDetailsPage = pagefactory.getAccountSummaryPage().goToFirstPolicyInPolicyList();
        policyDetailsPage.verifyPrintButtonIsDisplayed().shouldBeTrue("Print button is not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE", "SIGN_UP" })
    public void testAMPSignUp(String browserName) throws Exception {
        new LoginPage().goToSignUpPage().setSignUpData().clickSignUpButton().isSignUpSuccessful();
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite", "Diamond" } , description = "TC4862 : Inline Rectangle- HomePage")
    public void testPersonalizedOffersRectangleAd(String browserName) {
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.verifyPersonalizedOfferBanner();
        accountSummaryPage.verifyClickRedirectionPersonalizedOfferBanner();
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, description = "TC3168 : Verify Pay Now link")
    public void testPayNowLink(String browserName) throws Exception{
        logger.info("Running Test: AMP-028 Verify Pay Now link");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.clickOnPayNow().verifyPageDisplayedCorrectly().shouldBeTrue("Failed to reach the Make a Payment screen using Pay Now.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" })
    public void testLandingPageShowingPoliciesFromMultipleAccounts(String browserName) throws Exception {
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        Map<String, String> policiesToAccountMap =
          AuthorisationServer.getPoliciesForMultiAccountUser();

        // Check that policies from more than one account are shown
        Set<String> accountIds = new HashSet<>();
        accountSummaryPage.getPolicyNumbers().forEach(policyId -> accountIds.add(policiesToAccountMap.get(policyId)));

        Assert.assertTrue(accountIds.size() > 1, "Could not find policies from multiple accounts being displayed.");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC12547 : Verify quote links")
    public void testQuoteLinksAreVisibleForSingleAccount(String browserName) throws Exception{
        PolicyGenerator.createBasicBoundPAPolicy();

        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        Boolean quoteLinksVisible = accountSummaryPage.areQuoteLinksVisible();
        Assert.assertTrue(quoteLinksVisible);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC12547 : Verify quote links")
    public void testQuoteLinksAreHiddenForMultiAccountUser(String browserName) throws Exception{
        String policyNum1 = PolicyGenerator.createBasicBoundPAPolicy();
        PolicyGenerator.createBasicBoundPAPolicy();
        new SeleniumCommands().staticWait(15);
        JsonPath path = new JsonPath(DataFetch.getAgentPolicyDataAsSU(policyNum1));
        String accountNumber = DataFormatUtil.getNodeValue(path,"account", "accountNumber");
        AuthorisationServer.assignAccountCodeToExistingUser(ThreadLocalObject.getData().get("USER"), accountNumber);

        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        Boolean quoteLinksVisible = accountSummaryPage.areQuoteLinksVisible();
        Assert.assertFalse(quoteLinksVisible);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC13063 : Verify pay button")
    public void testPayButtonIsVisibleForSingleAccount(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundPAPolicy();

        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        Boolean payButtonVisible = accountSummaryPage.isPayNowButtonVisible();
        Assert.assertTrue(payButtonVisible);
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC13063 : Verify pay button")
    public void testPayButtonIsHiddenForMultiAccountUser(String browserName) throws Exception {
        String policyNum1 = PolicyGenerator.createBasicBoundPAPolicy();
        PolicyGenerator.createBasicBoundPAPolicy();

        new SeleniumCommands().staticWait(15);
        JsonPath path = new JsonPath(DataFetch.getAgentPolicyDataAsSU(policyNum1));
        String accountNumber = DataFormatUtil.getNodeValue(path,"account", "accountNumber");
        AuthorisationServer.assignAccountCodeToExistingUser(ThreadLocalObject.getData().get("USER"), accountNumber);

        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();

        Boolean payButtonVisible = accountSummaryPage.isPayNowButtonVisible();
        Assert.assertFalse(payButtonVisible);
    }
}
