package com.guidewire.capabilities.amp.test;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.portals.qnb.pages.AlertHandler;

public class PolicyDetailsTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond" }, description = "TC4213 : Verify policyhoder can upload a document in .doc format.")
    public void testDOCUploadOnPolicy(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("DOC didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"})
    public void testDOCXUploadOnPolicy(String browserName) throws Exception {
    		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("DOCX didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"})
    public void testTXTUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("TXT didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description="TC3173: Verify policyhoder can upload a document in .gif format.")
    public void testGIFUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("GIF didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description="TC3171: Verify policyhoder can upload a document in .pdf format.")
    public void testPDFUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("PDF didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description="TC3172: Verify policyhoder can upload a document in .png format.")
    public void testPNGUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("PNG didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"})
    public void testJPEGUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().isDocAdded().shouldBeTrue("JPEG didn't upload");
        new PolicyDetailsPage().isDocAddedInBackend().shouldBeTrue("Document didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description="TC3174: Verify policyhoder can upload a document in .html format.")
    public void testHTMLUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for HTML file");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description="TC3175: Verify policyhoder can not upload a document in javascript format.")
    public void testJSUploadOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for JS file");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"})
    public void testSameDocUploadTwiceOnPolicy(String browserName) throws Exception {
		PolicyGenerator.createBasicBoundPAPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToFirstPolicyInPolicyList().expandUploadedDocTab().deleteDuplicateDocument().uploadDocFromSummary().uploadDocFromSummary();

        AlertHandler alertHandler = new AlertHandler();
        alertHandler.isFailedToUploadPopUpDisplayed().shouldBeEqual("Pop up didn't display for same file upload");
        alertHandler.isFailedToUploadPopUpContentEqualsTo().shouldBeEqual("Pop up content didn't match for same file upload");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"} , enabled = false, description = "TC2715 : Leaderboard UI Component - Text")
    public void testPersonalisedOfferLeaderBoardAd(String browserName) throws Exception {
        PolicyGenerator.createBasicBoundHOPolicy();
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        PolicyDetailsPage policyDetailsPage =  accountSummaryPage.goToFirstPolicyInPolicyList();
        policyDetailsPage.verifyLeaderBoardBannerText();
        policyDetailsPage.verifyClickRedirectionLeaderBoardOfferBanner();
    }
}
