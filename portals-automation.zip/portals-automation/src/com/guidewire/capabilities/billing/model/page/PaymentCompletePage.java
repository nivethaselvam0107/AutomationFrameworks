package com.guidewire.capabilities.billing.model.page;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class PaymentCompletePage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = "[class='gw-page-title ng-binding']")
    WebElement PAYMENT_CONFIRMATION_HEADER;

    @FindBy(css = "[class='gw-btn-primary ng-binding']")
    WebElement RETURN_TO_SUMMARY_BTN;
    
    By PAYMENT_CONFIRMATION_MESSAGE = By.cssSelector("[class*='billing-summary'][ng-if*='Confirmation']");
    
    public PaymentCompletePage() {
    	seleniumCommands.pageWebElementLoader(this);
    }
    
    public Validation verifyPaymentComplete() {
        seleniumCommands.waitForElementToBeVisible(RETURN_TO_SUMMARY_BTN);
        new Validation(seleniumCommands.getTextAtLocator(PAYMENT_CONFIRMATION_HEADER), DataConstant.PAYMENT_COMPLETE_TEXT).shouldBeEqual("Payment was unsuccessful");
        return new Validation(true);
    }
    
    public Validation verifyInvoicePaymentAppliedMessage(String invoiceValue) {
    	seleniumCommands.waitForElementToBeVisible(PAYMENT_CONFIRMATION_MESSAGE);
        new Validation(seleniumCommands.getTextAtLocator(PAYMENT_CONFIRMATION_MESSAGE), String.format(DataConstant.PAYMENT_INVOICE_APPLIED_TEXT, invoiceValue)).shouldBeEqual("Invoice payment applied message was incorrect");
        return new Validation(true);
    }
}
