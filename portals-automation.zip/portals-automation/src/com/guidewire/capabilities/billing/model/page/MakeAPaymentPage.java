package com.guidewire.capabilities.billing.model.page;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.ParseBillingData;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MakeAPaymentPage {

    private String accNum = "bankAccountDetails.bankAccountNumber";
    private String routingNum = "bankAccountDetails.bankABANumber";
    private String bankName = "bankAccountDetails.bankName";
    private String cardIssuer = "creditCardDetails.creditCardIssuer";
    private String cardNumber = "creditCardDetails.creditCardNumber";

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    By INVOICE_LABEL = By.xpath("//input/following-sibling::label");

    @FindBy(css = "[ng-click='payNow()']")
    WebElement PAY_NOW_BTN;

    @FindBy(css = ".gw-one-invoice")
    List<WebElement> INVOICE_ITEM_DIV;

    @FindBy(css = ".gw-invoice-selected")
    List<WebElement> SELECTED_INVOICE_DIV;

    @FindBy(css = ".gw-page-title")
    WebElement PAGE_TITLE_CSS;
    
    @FindBy(css = "[ng-model='model.view.value.paymentMethod']")
    WebElement SOURCE_DROPDOWN;

    @FindBy(css = "[ng-model='dateFields.month']")
    WebElement EXP_DATE_MONTH_DROPDOWN;

    @FindBy(css = "[ng-model='dateFields.year']")
    WebElement EXP_DATE_YEAR_DROPDOWN;

    @FindBy(css = "ng-form")
    WebElement FORM;

    @FindBy(css = "[class='gw-invoice-table gw-table']")
    WebElement INVOICE_TABLE;

    @FindBy(linkText = "View Invoice Details")
    List<WebElement>  VIEW_INVOICE_DETAILS_LINKS;

    @FindBy(css = ".gw-change-payment-amount")
    WebElement CHANGE_PAYMENT_AMOUNT_LINK;

    @FindBy(css = "[model='amount.manualAmount'] input")
    WebElement AMOUNT_INPUT;

    @FindBy(css = ".gw-invoice-list")
    WebElement INVOICE_LIST;

    @FindBy(css = "[gw-pl-radios-binary]")
    WebElement ACC_TYPE_TOGGLER;

    @FindBy(css = ".gw-no-invoices-alert")
    WebElement NO_INVOICE_SELECTED_ALERT;

    @FindBy(css = "[model='amount.manualAmount'] [class*='gw-error-inline']")
    WebElement ERROR_TEXT;

    @FindBy(css = "[data-gw-test-invoice-number]")
    List<WebElement> INVOICE_NUMBER_SPANS;
    
    @FindBy(css = "[model*='bankAccountNumber'] [class*='asterisk']")
    WebElement ACCOUNT_NUM_MANDATORY_ASTERISK_CSS;
    
    @FindBy(css = "[model*='bankABANumber'] [class*='asterisk']")
    WebElement ROUTING_NUM_MANDATORY_ASTERISK_CSS;
    
    @FindBy(css = "[model*='bankName'] [class*='asterisk']")
    WebElement BANK_NAME_MANDATORY_ASTERISK_CSS;
    
    By SELECTED_INVOICE_LABEL = By.xpath("//input[@aria-checked='true']/following-sibling::label");
    
    By UNSELECTED_INVOICE_LABEL = By.xpath("//input/following-sibling::label");
    
    By PAY_NOW_DISABLED_CSS = By.cssSelector("[ng-click='payNow()'][ng-disabled='!isValid()']");
    
    
    String INVOICE_AMT = "";
    

    public MakeAPaymentPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public PaymentCompletePage payWithBankSavingAccount() {
    	new AutomaticPaymentsPage().setupBankSavingData();
    	seleniumCommands.click(PAY_NOW_BTN);
        return new PaymentCompletePage();
    }
    
    public PaymentCompletePage payWithBankCheckingAccount() {
    	new AutomaticPaymentsPage().setupBankCheckingData();
    	seleniumCommands.click(PAY_NOW_BTN);
        return new PaymentCompletePage();
    }

    public PaymentCompletePage payWithCreditCard() {
    	new AutomaticPaymentsPage().setupCreditCardData();
        seleniumCommands.click(PAY_NOW_BTN);
        return new PaymentCompletePage();
    }

    public MakeAPaymentPage viewInvoicesDetails() {
        seleniumCommands.clickbyJS(VIEW_INVOICE_DETAILS_LINKS.get(0));
        return this;
    }

    public MakeAPaymentPage changeAmount() {
         seleniumCommands.clickbyJS(AMOUNT_INPUT);
         seleniumCommands.type(AMOUNT_INPUT, data.get("AMOUNT"));
        return this;
    }

    
    //This method is used just to generate error message for amount filed
    public MakeAPaymentPage changeSourceType() {
    	seleniumCommands.click(SOURCE_DROPDOWN);
        seleniumCommands.selectFromDropdownByIndex(SOURCE_DROPDOWN, 1);
        return this;
    }


    public Validation checkInputAttributeType(String inputType) {
        seleniumCommands.clickbyJS(AMOUNT_INPUT);
        String attributeType = AMOUNT_INPUT.getAttribute("type");
        new Validation(attributeType.equalsIgnoreCase(inputType)).shouldBeTrue("Input Attribute is not of type number");
        return new Validation(true);
    }
    
    public MakeAPaymentPage payForNoInvoice() {
        unselectAllInvoices();
        seleniumCommands.clickbyJS(PAY_NOW_BTN);
        return this;
    }

    public Validation verifyInvoiceListDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(INVOICE_TABLE));
    }

    public Validation verifyAccountTypeInputDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(ACC_TYPE_TOGGLER));
    }

    public Validation verifyAccountNumberInputDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(getAccNumInput().getElement()));
    }
    
    public Validation verifyPayNowButtonIsDisabled() {
        return new Validation(seleniumCommands.isElementPresent(PAY_NOW_DISABLED_CSS));
    }

    public Validation verifyRoutingNUmberInputDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(getRoutingNumberInput().getElement()));
    }

    public Validation verifyBankNameInputDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(getRoutingNumberInput().getElement()));
    }

    public Validation verifySourceDropdownDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(SOURCE_DROPDOWN));
    }

    public Validation verifyErrorMessage(String errorMessage) {
        return new Validation(seleniumCommands.getTextAtLocator(ERROR_TEXT), errorMessage);
    }

    public Validation verifyChangeAmountLinkDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(CHANGE_PAYMENT_AMOUNT_LINK));
    }

    public Validation verifyNoInvoiceSelectedAlertDisplayed() {
        seleniumCommands.waitForElementToBeVisible(NO_INVOICE_SELECTED_ALERT);
        return new Validation(seleniumCommands.isElementPresent(NO_INVOICE_SELECTED_ALERT));
    }

    public Validation verifyCorrectSourceValuesAreAvailable() {
        List<String> availableValues = seleniumCommands.getAllOptionsFromDropDown(SOURCE_DROPDOWN);
        List<String> expectedValues = new ArrayList<>();
        expectedValues.add(data.get("SOURCE_BANK"));
        expectedValues.add(data.get("SOURCE_CREDIT"));
        return new Validation(expectedValues, availableValues);
    }
    
    public Validation verifyAvailablePaymentMethods() {
    	new Validation(seleniumCommands.isElementPresent(ACC_TYPE_TOGGLER)).shouldBeTrue("Account type is not present");
    	new Validation(seleniumCommands.isElementPresent(ACCOUNT_NUM_MANDATORY_ASTERISK_CSS)).shouldBeTrue("Account number is not mandatory");
    	new Validation(seleniumCommands.isElementPresent(ROUTING_NUM_MANDATORY_ASTERISK_CSS)).shouldBeTrue("Routing number is not mandatory");
    	new Validation(seleniumCommands.isElementPresent(BANK_NAME_MANDATORY_ASTERISK_CSS)).shouldBeTrue("Bank Name is not mandatory");
    	verifyCorrectSourceValuesAreAvailable().shouldBeEqual("Source options are not same");
        return new Validation(true);
    }

    public Validation verifyInvoiceDetailsDisplayed() {
        return new Validation(seleniumCommands.isElementPresent(INVOICE_TABLE));
    }

    public Validation verifyNewAmountDisplayed() {
        String amountThatShouldBeDisplayed = data.get("AMOUNT");
        String currentAmountDisplayed = seleniumCommands.getValueAttributeFromLocator(AMOUNT_INPUT);
        return new Validation(amountThatShouldBeDisplayed, currentAmountDisplayed);
    }

    public Validation verifyAllInvoicesSelectedByDefault() {
        int totalInvoices = INVOICE_ITEM_DIV.size();
        int totalInvoicesSelected = SELECTED_INVOICE_DIV.size();
        new Validation(totalInvoices, totalInvoicesSelected).shouldBeEqual("Not all invoices were selected");
        return new Validation(true);
    }

    public Validation verifyPageDisplayedCorrectly() {
        return new Validation(seleniumCommands.isElementPresent(PAGE_TITLE_CSS) &&
                seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).equals(DataConstant.MAKE_PAYMENY_TITLE_TEXT));
    }
    
    public Validation verifyOnlyActiveInvoicesAreDisplayed() throws Exception {
        String jsonData = DataFetch.getBillingData(DataFetch.fetchUaaToken());
        List<String> activeInvoicesFromBackend = ParseBillingData.getActiveInvoiceDataFromBackEnd(jsonData);
        return new Validation(activeInvoicesFromBackend, getAllInvoiceNumbersOnPage());
    }

    public MakeAPaymentPage unselectAllInvoices() {
        seleniumCommands.waitForLoaderToDisappearFromPage();
        seleniumCommands.waitForElementToBeEnabled(INVOICE_LABEL);
        if(seleniumCommands.isElementPresent(SELECTED_INVOICE_LABEL)) {
        	seleniumCommands.findElements(SELECTED_INVOICE_LABEL).forEach(ckBox -> ckBox.click());
        }
        return this;
    }
    
    public String selectFirstInvoices() {
        seleniumCommands.waitForElementToBeEnabled(INVOICE_LABEL);
        seleniumCommands.click(seleniumCommands.findElements(UNSELECTED_INVOICE_LABEL).get(0));
        this.INVOICE_AMT = seleniumCommands.getValueAttributeFromLocator(AMOUNT_INPUT);
        return String.format("%.2f", Float.parseFloat(INVOICE_AMT));
    }

    private void selectFirstInvoice() {
        WebDriver driver = ThreadLocalObject.getDriver();
        ((JavascriptExecutor) driver).executeScript("$('.gw-invoice-list .gw-invoice:eq(0) :checkbox').trigger('click')");
    }

    public List<String> getAllInvoiceNumbersOnPage() {
        List<String> invoiceNumbers = new ArrayList<>();
        for(int i = 0; i < INVOICE_NUMBER_SPANS.size(); i++) {
            invoiceNumbers.add(seleniumCommands.getTextAtLocator(INVOICE_NUMBER_SPANS.get(i)));
        }
        return invoiceNumbers;
    }

    public void withAccNum(String accNum) {
        getAccNumInput().setValue(accNum);
    }

    public void withRoutingNumber(String routingNum) {
        getRoutingNumberInput().setValue(routingNum);
    }

    public void withBankName(String bankName) {
        getBankNameInput().setValue(bankName);
    }

    public void withCardIssuer(String cardIssuer) {
        getCardIssuerInput().setValue(cardIssuer);
    }

    public void withCardNumber(String cardNumber) {
        getCardNumberInput().setValue(cardNumber);
    }

    private ViewModelInput getAccNumInput() {
        return this.getForm().getInputByModel(accNum);
    }

    private ViewModelInput getRoutingNumberInput() {
        return this.getForm().getInputByModel(routingNum);
    }

    private ViewModelInput getBankNameInput() {
        return this.getForm().getInputByModel(bankName);
    }

    private ViewModelInput getCardIssuerInput() {
        return this.getForm().getInputByModel(cardIssuer);
    }

    private ViewModelInput getCardNumberInput() {
        return this.getForm().getInputByModel(cardNumber);
    }
}
