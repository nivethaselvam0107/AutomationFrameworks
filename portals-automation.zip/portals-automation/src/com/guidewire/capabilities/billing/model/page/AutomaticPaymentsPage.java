package com.guidewire.capabilities.billing.model.page;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.CommonPage;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;
import com.guidewire.widgetcomponents.form.ViewModelForm;
import com.guidewire.widgetcomponents.form.ViewModelInput;

public class AutomaticPaymentsPage extends CommonPage{
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());
    
    PaymentDetailsPage paymentPage = new PaymentDetailsPage();

    @FindBy(css = "ng-form")
    WebElement FORM;

    @FindBy(css = "[gw-pl-radios-binary]")
    WebElement TYPE_TOGGLER;

    @FindBy(css = ".gw-payment-instrument > div > .gw-control-group label")
    WebElement SOURCE_FIELD_CSS;

    @FindBy(css = "[ng-click='goBack()'")
    WebElement CANCEL_BUTTON;

    @FindBy(css = ".gw-btn-primary")
    WebElement SUBMIT_BUTTON;
    
    By AUTO_PAY_SETUP_DATE_TXT_CSS = By.cssSelector("[name='autopayForm'] div[class*='control-group']:nth-of-type(3) span");
    
    By AUTO_PAY_SETUP_OR_CHANGE_BTN_CSS = By.cssSelector("[ng-click='setupAutomaticPayment(autopayForm)'], [ng-click*='changeAutopayPaymentMethod']");

    static final List<String> REQUIRED_FIELDS = Arrays.asList("bankAccountDetails.bankAccountNumber","bankAccountDetails.bankABANumber", "bankAccountDetails.bankName");

    public AutomaticPaymentsPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public ViewModelForm getForm() {
        return new ViewModelForm(FORM);
    }

    public void fillForm(ViewModelForm currentForm) {
        currentForm.getInputByModel("bankAccountDetails.bankAccountNumber").setValue(data.get("ACCOUNT_NO"));
        currentForm.getInputByModel("bankAccountDetails.bankABANumber").setValue(data.get("ABA_NO"));
        currentForm.getInputByModel("bankAccountDetails.bankName").setValue(data.get("BANK_NAME"));
    }
    
    public AutomaticPaymentsPage clickOnSetUpAutomaticPaymentsButton() {
    	seleniumCommands.clickbyJS(AUTO_PAY_SETUP_OR_CHANGE_BTN_CSS);
    	System.out.println(ThreadLocalObject.getData());
    	return this;
    }
    
    public Validation isSetUpOrChangeAutomaticPaymentsButtonIsDisabled() {
    	return new Validation (seleniumCommands.getAttributeValueAtLocator(AUTO_PAY_SETUP_OR_CHANGE_BTN_CSS, "disabled"), "true");
    }

    public AutomaticPaymentsConfirmationPage setupAutomaticPayments() {
        ViewModelForm form = getForm();
        fillForm(form);
        seleniumCommands.click(SUBMIT_BUTTON);
        return new AutomaticPaymentsConfirmationPage();
    }
    
    public AutomaticPaymentsConfirmationPage setupAutomaticPaymentsUsingBankSavingAccount() {
        this.setupBankSavingData();
        if(seleniumCommands.isElementPresent(AUTO_PAY_SETUP_DATE_TXT_CSS)) {
	        String startDate = seleniumCommands.getTextAtLocator(AUTO_PAY_SETUP_DATE_TXT_CSS);
	        this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage(startDate);
        }
        	this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage();
    }
    
    public AutomaticPaymentsConfirmationPage setupAutomaticPaymentsUsingBankCheckingAccount() {
    	this.setupBankCheckingData();
        if(seleniumCommands.isElementPresent(AUTO_PAY_SETUP_DATE_TXT_CSS)) {
	        String startDate = seleniumCommands.getTextAtLocator(AUTO_PAY_SETUP_DATE_TXT_CSS);
	        this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage(startDate);
        }
        	this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage();
    }
    
    public AutomaticPaymentsConfirmationPage setupAutomaticPaymentsUsingCreditCard() {
    	this.setupCreditCardData();
        if(seleniumCommands.isElementPresent(AUTO_PAY_SETUP_DATE_TXT_CSS)) {
	        String startDate = seleniumCommands.getTextAtLocator(AUTO_PAY_SETUP_DATE_TXT_CSS);
	        this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage(startDate);
        }
        	this.clickOnSetUpAutomaticPaymentsButton();
	        return new AutomaticPaymentsConfirmationPage();
    }
    
    public AutomaticPaymentsPage setupBankSavingData() {
    	this.setupBankData().put("AccountType", "Savings");
    	paymentPage.setAccountType();
    	return this;
    }
    
    public AutomaticPaymentsPage setupBankCheckingData() {
    	this.setupBankData().put("AccountType", "Checking");
    	paymentPage.setAccountType();
    	return this;
    }
    
    public AutomaticPaymentsPage setupCreditCardData() {
    	paymentPage.setPaymentMethod("Credit Card");
    	paymentPage.setCardIssuer().setCardNumber().setExpirationDate();
    	return this;
    }
    
    private HashMap< String, String> setupBankData() {
    	HashMap< String, String> bankData = ThreadLocalObject.getData();
    	bankData.put("AccountNumber", "XHSHSUD1233");
    	bankData.put("RoutingNumber", "JHDJHWIU242e");
    	bankData.put("BankName", "AIB");
    	paymentPage.setBankPaymentMethod();
    	paymentPage.setAccountNumber();
    	paymentPage.setABARoutingNumber();
    	paymentPage.setBankName();
    	return bankData;
    }
    
    public void validateBankDataSaved() {
    	new Validation(paymentPage.getBankName(), data.get("BankName")).shouldBeEqual("Bank name value is not saved");
    	new Validation(paymentPage.getAccountNumber(), data.get("AccountNumber")).shouldBeEqual("AccountNumber value is not saved");
    	new Validation(paymentPage.getRoutingNumber(), data.get("RoutingNumber")).shouldBeEqual("RoutingNumber value is not saved");
    	new Validation(paymentPage.getBankAccountType(), data.get("AccountType")).shouldBeEqual("AccountType value is not saved");
    }
    
    public void validateCreditCardDataSaved() {
    	new Validation(paymentPage.getCardIssuerName(), data.get("CardIssuer")).shouldBeEqual("Card Issuer value is not saved");
    	new Validation(paymentPage.getCreditCardNumber().replaceAll("-", ""), data.get("CreditCardNumber")).shouldBeEqual("CreditCardNumber value is not saved");
    	new Validation(paymentPage.getCreditCardExpMonth(), data.get("ExpMonth")).shouldBeEqual("ExpMonth value is not saved");
    	new Validation(paymentPage.getCreditCardExpYear(), data.get("ExpYear")).shouldBeEqual("ExpYear value is not saved");
    }

    public BillingSummaryPage cancelForm() {
        seleniumCommands.click(CANCEL_BUTTON);
        return new BillingSummaryPage();
    }

    private boolean allFieldsVisible() {
        boolean togglerPresent = seleniumCommands.isElementPresent(TYPE_TOGGLER);
        boolean sourceFieldPresent = seleniumCommands.isElementPresent(SOURCE_FIELD_CSS);
        boolean allRequiredFieldsVisible = this.getForm().getAllRequiredInputs().stream().map(ViewModelInput::getModel).allMatch(REQUIRED_FIELDS::contains);
        return allRequiredFieldsVisible && togglerPresent && sourceFieldPresent;
    }

    public Validation validateFieldsAndCancel() {
        boolean allFieldsVisible = allFieldsVisible();
        boolean cancelSuccess = cancelForm().pageDisplayedCorrectly();
        return new Validation(allFieldsVisible && cancelSuccess);
    }
    
}
