package com.guidewire.capabilities.billing.model.page;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.data.DataConstant;

public class AutomaticPaymentsConfirmationPage {
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = ".gw-billing-confirmation")
    WebElement BILLING_CONFIRMATION_CSS;

    @FindBy(css = ".gw-billing-confirmation button")
    WebElement RETURN_SUMMARY_BUTTON;

    @FindBy(css = "[ng-if*='Confirmation']")
    WebElement CONFIRMATION_MESSAGE_CSS;
    
    @FindBy(css = "[ng-click*='paymentSourceAction()']")
    WebElement CHANGE_PAYMENT_METHOD_CSS;
    
    private String AUTO_PAY_START_DATE ;

    public AutomaticPaymentsConfirmationPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }
    
    public AutomaticPaymentsConfirmationPage(String date) {
        seleniumCommands.pageWebElementLoader(this);
        this.AUTO_PAY_START_DATE = date;
    }

    public AccountSummaryPage returnToSummary() {
        seleniumCommands.click(RETURN_SUMMARY_BUTTON);
        return new AccountSummaryPage();
    }

    // Validation
    public Validation verifyPaymentsSetupCorrectly() {
        seleniumCommands.waitForElementToBeVisible(CONFIRMATION_MESSAGE_CSS);
        return new Validation(seleniumCommands.isElementPresent(CONFIRMATION_MESSAGE_CSS) && seleniumCommands.getTextAtLocator(CONFIRMATION_MESSAGE_CSS).contains(DataConstant.AUTOMATIC_PAYMENT_ENABLED_TEXT));
    }
    
    public Validation verifyAutoPaymentsSetupConfirmationMessage() {
        seleniumCommands.waitForElementToBeVisible(CONFIRMATION_MESSAGE_CSS);
        return new Validation(seleniumCommands.getTextAtLocator(CONFIRMATION_MESSAGE_CSS), String.format(DataConstant.AUTOMATIC_PAYMENT_ENABLED_TEXT, AUTO_PAY_START_DATE));
    }
    
    public Validation verifyAutoPaymentsSetupChangedMessage() {
        seleniumCommands.waitForElementToBeVisible(CONFIRMATION_MESSAGE_CSS);
        return new Validation(seleniumCommands.getTextAtLocator(CONFIRMATION_MESSAGE_CSS), DataConstant.AUTOMATIC_PAYMENT_CHANGED_TEXT);
    }

    public Validation verifyPageDisplayedCorrectly() {
        return new Validation(seleniumCommands.isElementPresent(BILLING_CONFIRMATION_CSS));
    }

}
