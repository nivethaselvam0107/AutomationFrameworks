package com.guidewire.capabilities.billing.model.page;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataConstant;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;

import io.restassured.path.json.JsonPath;

public class BillingSummaryPage {

    SeleniumCommands seleniumCommands = new SeleniumCommands();
    HashMap<String, String> data = ThreadLocalObject.getData();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @FindBy(css = ".gw-page-title")
    WebElement PAGE_TITLE_CSS;

    @FindBy(linkText = "View Payment Schedule Detail")
    WebElement VIEW_PAYMENT_SCHEDULE_LINK;

    @FindBy(linkText = "Hide Payment Schedule Detail")
    WebElement HIDE_PAYMENT_SCHEDULE_LINK;

    @FindBy(css = ".gw-policy-info:nth-child(2) > .gw-action-link")
    List<WebElement> POLICY_NUMBER_LINKS;

    @FindBy(css = "[ng-click*='paymentSourceAction()']")
    WebElement CHANGE_PAYMENT_METHOD_CSS;

    @FindBy(css = ".gw-billing-summary-tile-badge")
    List<WebElement> POLICY_NUMBER_TILES;

    By AUTOMATIC_PAYMENTS_LINK_CSS = By.cssSelector("gw-billing-summary-actions a");

    @FindBy(css = "[ng-click='automaticAction()']")
    WebElement SETUP_AUTOMATIC_PAYMENT_LINK;


    By MAKE_A_PAY_LINK = By.cssSelector("[ng-click='paymentAction()'][aria-hidden='false']");

    String TILE = "//*[@class='gw-billing-summary-tile-badge ng-binding']";
    
    String POLICY_TILE = "//*[@class='gw-billing-summary-tile-badge ng-binding'][text()='%s']";

    public BillingSummaryPage() {
        PageFactory.initElements(
                new AjaxElementLocatorFactory(ThreadLocalObject.getDriver(), DataConstant.PAGEFACTORY_TIMEOUT), this);
    }

    public BillingSummaryPage showPaymentSchedule() {
        seleniumCommands.clickbyJS(VIEW_PAYMENT_SCHEDULE_LINK);
        return new BillingSummaryPage();
    }

    public PolicyDetailsPage goToPolicyDetailsPage() {
        String policyNumber = POLICY_NUMBER_TILES.get(0).getText();
        seleniumCommands.clickbyJS(POLICY_NUMBER_TILES.get(0));
        return new PolicyDetailsPage(policyNumber);
    }

    public AutomaticPaymentsPage goToAutomaticPaymentsPage() {
        seleniumCommands.findElements(AUTOMATIC_PAYMENTS_LINK_CSS).forEach( webElement -> {
             if(webElement.getText().equalsIgnoreCase("Setup Automatic Payments"))
                webElement.click();
        });

        SETUP_AUTOMATIC_PAYMENT_LINK.click();
        return new AutomaticPaymentsPage();
    }
    
    public BillingSummaryPage selectPolicy() {
    	By policyLocator = By.xpath(String.format(POLICY_TILE, data.get(PolicyData.POLICY_NUM.toString())));
    	//this.waitForBillingSummary();
    	seleniumCommands.waitForElementToBeVisible(policyLocator);
        seleniumCommands.clickbyJS(policyLocator);
        seleniumCommands.waitForElementToBePresent(AUTOMATIC_PAYMENTS_LINK_CSS);
        return this;
    }

    public BillingSummaryPage waitForBillingSummary() {
        for (int i = 1; i < 3 ; i++) {
            try {
                if (!seleniumCommands.isElementPresent(By.xpath(TILE))) {
                    seleniumCommands.refreshPage();
                    seleniumCommands.waitForElementToBePresent(By.xpath(TILE));
                    continue;
                }
                else{
                    break;
                }
            }
        catch(Exception e){

            }
        }
        return this;
    }
    
    public MakeAPaymentPage clickOnMakePaymentLink() {
    	seleniumCommands.waitForLoaderToDisappearFromPage();
    	seleniumCommands.waitForElementToBeVisible(MAKE_A_PAY_LINK);
        seleniumCommands.clickbyJS(MAKE_A_PAY_LINK);
        return new MakeAPaymentPage();
    }
    
    
    public AutomaticPaymentsPage clickOnChangePaymentMethodLink() {
    	seleniumCommands.waitForElementToBeVisible(CHANGE_PAYMENT_METHOD_CSS);
        seleniumCommands.clickbyJS(CHANGE_PAYMENT_METHOD_CSS);
        return new AutomaticPaymentsPage();
    }

    public String getPolicyNumberFromLink() {
        return POLICY_NUMBER_TILES.get(0).getText();
    }

    public List<String> getPolicyNumbersFromTiles() {
        return POLICY_NUMBER_TILES.stream().map(tile -> tile.getText()).sorted().collect(Collectors.toList());
    }

    public boolean pageDisplayedCorrectly() {
        return seleniumCommands.isElementPresent(PAGE_TITLE_CSS) && seleniumCommands.getTextAtLocator(PAGE_TITLE_CSS).equals(DataConstant.BILLING_SUMMARY_TITLE_TEXT);
    }

    public Validation verifyPaymentScheduleVisible() {
        new Validation(seleniumCommands.isElementPresent(HIDE_PAYMENT_SCHEDULE_LINK)).shouldBeTrue("Payment schedule is not displayed");
        return new Validation(true);
    }

    public Validation verifyPaymentScheduleNotVisible() {
        new Validation(seleniumCommands.isElementPresent(VIEW_PAYMENT_SCHEDULE_LINK)).shouldBeTrue("Payment schedules are displayed");
        return new Validation(true);
    }

    public WebElement getDisplayedElement(List<WebElement> elementList) {
        for(WebElement element : elementList) {
            if(element.isDisplayed()) {
                return element;
            }
        }
        return null;
    }
    
    private String getOverridePaymentInstrumentValueFromBackend(){
    	logger.info("Retriving Payment instrument value");
    	return DataFetch.getOverrideAccountPaymentInstrument(data.get(PolicyData.ACCOUNT_NUMBER.toString()));
    }
    
    private String getDefaultPaymentInstrumentValueFromBackend(){
    	logger.info("Retriving Payment instrument value");
    	return DataFetch.getDefaultPaymentInstrument(data.get(PolicyData.ACCOUNT_NUMBER.toString()));
    }
    
    private String getLastPaymentDataFromBackend(){
    	logger.info("Retriving last payment data from backend");
    	String json = DataFetch.getPolicyLastPaymentData(data.get(PolicyData.ACCOUNT_NUMBER.toString()));
		JsonPath path = new JsonPath(json);
		int paymentCount = path.getList("$").size()-1;
    	return DataFormatUtil.getNodeValue(path, "["+ paymentCount +"].Payment_Amount");
    }
    
    public Validation validateOverridenAutoPaymentInstrumentForBankAccount() {
    	String instrumentExpected = "ACH/EFT (SIDOPOC_TOKEN:2:2:"+ data.get("RoutingNumber") +":"+ data.get("AccountNumber") +":"+ data.get("AccountType").toLowerCase() +":" + data.get("BankName") +")" ;
    	return new Validation(getOverridePaymentInstrumentValueFromBackend(), instrumentExpected);
    }
    
    public Validation validateDefaultPaymentInstrumentForAccount() {
    	String instrumentExpected = "Responsive" ;
    	return new Validation(getDefaultPaymentInstrumentValueFromBackend(), instrumentExpected);
    }
    
    public Validation validateOverridenAutoPaymentInstrumentForCreditCard() {
    	String instrumentExpected = "ACH/EFT (SIDOPOC_TOKEN:2:1:"+ data.get("CreditCardNumber") +":"+ data.get("CardIssuer").toLowerCase();
    	String instrumentActual = getOverridePaymentInstrumentValueFromBackend();
    	return new Validation(instrumentActual.substring(0, instrumentActual.lastIndexOf(":")), instrumentExpected);
    }
    
    public Validation validateLastPaymentMadeAccount(String invoicePaymentValue) {
    	return new Validation(Double.parseDouble(this.getLastPaymentDataFromBackend()), Double.parseDouble(invoicePaymentValue));
    }
}
