package com.guidewire.capabilities.billing.test.accountlevelbilling;

import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import io.restassured.path.json.JsonPath;
import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.amp.model.page.PolicyDetailsPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.common.testNG.Validation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BillingSummaryTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite",  "Diamond", "SMOKE"}, enabled = false)
    public void testPaymentScheduleVisibility(String browserName) {
        BillingSummaryPage billingSummaryPage = pagefactory.getBillingSummaryPage().showPaymentSchedule();
        billingSummaryPage.verifyPaymentScheduleVisible().shouldBeTrue("Payment Schedule is not displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite"  ,  "Diamond"}, enabled = false)
    public void testPaymentScheduleVisibilityByDefault(String browserName) {
        BillingSummaryPage billingSummaryPage = pagefactory.getBillingSummaryPage();
        billingSummaryPage.verifyPaymentScheduleNotVisible().shouldBeTrue("Payment Schedule is displayed");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite",  "Diamond", "SMOKE" }, enabled = false)
    public void testPolicyDetailsPageIsShown(String browserName) {
        PolicyDetailsPage policyDetailsPage = pagefactory.getBillingSummaryPage().goToPolicyDetailsPage();
        policyDetailsPage.verifyPolicyDetailsPageWasLoaded().shouldBeTrue("Policy Detail Page isn't displayed");
        String policyDetailsPagePolicyNumber = policyDetailsPage.getPolicyNumber();
        logger.info("Found following policy number: " + policyDetailsPagePolicyNumber + " on Policy Details Page");
        BillingSummaryPage billingSummaryPage = policyDetailsPage.goToBillingSummaryPage();
        billingSummaryPage.verifyPaymentScheduleNotVisible().shouldBeTrue("Billing Summary page wasn't loaded");
        String billingSummaryPagePolicyNumber = billingSummaryPage.getPolicyNumberFromLink();
        logger.info("Found following policy number: " + billingSummaryPagePolicyNumber + " on Billing Summary Page");
        logger.info("Comparing Policy Number link on Billing Summary Page with Policy Number on Policy Details Page");
        new Validation(billingSummaryPagePolicyNumber, policyDetailsPagePolicyNumber).shouldBeEqual("The policy numbers didn't match");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE"}, description = "TC12498: ALB - do not show alb policies on billing summary")
    public void testMultiAccountPoliciesWithALBNotVisibleOnBillingSummary(String browserName) {
        String policyNumberWithALB = PolicyGenerator.createBasicBoundHOPolicy();
        List<String> policies = new ArrayList<>();
        policies.add(PolicyGenerator.createBasicBoundPAPolicy());
        Collections.sort(policies);

        new SeleniumCommands().staticWait(20);

        JsonPath path = new JsonPath(DataFetch.getAgentPolicyDataAsSU(policyNumberWithALB));
        String accountNumber = DataFormatUtil.getNodeValue(path,"account", "accountNumber");
        DataFetch.setAccountBillingLevel(accountNumber);
        AuthorisationServer.assignAccountCodeToExistingUser(ThreadLocalObject.getData().get("USER"), accountNumber);
        BillingSummaryPage billingSummaryPage = pagefactory.getBillingSummaryPage();
        new Validation(billingSummaryPage.getPolicyNumbersFromTiles(), policies).shouldBeEqual("The policy numbers didn't match");
    }
}
