package com.guidewire.capabilities.billing.test.accountlevelbilling;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.billing.model.page.PaymentCompletePage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.data.DataConstant;

public class MakeAPaymentTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" , "SMOKE" }, enabled = false)
    public void testPaymentWithBankAccount(String browserName) {
        PaymentCompletePage paymentCompletePage = pagefactory.getMakeAPaymentPage().changeAmount().payWithBankSavingAccount();
        paymentCompletePage.verifyPaymentComplete().shouldBeTrue("Payment was unsuccessful");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, enabled = false)
    public void testAllInvoicesSelectedByDefault(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage();
        makeAPaymentPage.verifyAllInvoicesSelectedByDefault().shouldBeTrue("Not all invoices were selected by default");
    }

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite" , "Diamond" }, enabled = false)
    public void testPaymentWithCreditCard(String browserName) {
        PaymentCompletePage paymentCompletePage = pagefactory.getMakeAPaymentPage().changeAmount().payWithCreditCard();
        paymentCompletePage.verifyPaymentComplete().shouldBeTrue("Payment was unsuccessful");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, enabled = false)
    public void testInvoiceDetailsAndChangePaymentAmount(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().viewInvoicesDetails();
        makeAPaymentPage.verifyInvoiceDetailsDisplayed().shouldBeTrue("Invoice Details aren't displayed");
        makeAPaymentPage.changeAmount().verifyNewAmountDisplayed().shouldBeEqual("Wrong amount displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond" } )
    public void testMakeAPaymentPageDisplayed(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage();
        makeAPaymentPage.verifyInvoiceListDisplayed().shouldBeTrue("Invoice list is not displayed");
        makeAPaymentPage.verifySourceDropdownDisplayed().shouldBeTrue("Source dropdown is not displayed");
        makeAPaymentPage.verifyCorrectSourceValuesAreAvailable().shouldBeEqual("Source dropdown doesn't have the correct values");
        makeAPaymentPage.verifyAccountTypeInputDisplayed().shouldBeTrue("Account type input is not displayed");
        makeAPaymentPage.verifyAccountNumberInputDisplayed().shouldBeTrue("Account number input is not displayed");
        makeAPaymentPage.verifyRoutingNUmberInputDisplayed().shouldBeTrue("Routing number input is not displayed");
        makeAPaymentPage.verifyBankNameInputDisplayed().shouldBeTrue("Bank name input is not displayed");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description = "TC6603: Overpay verification")
    public void testOverpayNotPossible(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyPayNowButtonIsDisabled().shouldBeTrue("Pay now button is not disabled for overpayment");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3163: 0 Payment Validation")
    public void testPayingZeroNotPossible(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyPayNowButtonIsDisabled().shouldBeTrue("Pay now button is not disabled for payments with zero values");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond" } , description = "TC3153 : Amount To Pay Mandatory Validation")
    public void testPayingBlankNotPossible(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyPayNowButtonIsDisabled().shouldBeTrue("Pay now button is not disabled for blank payments");
    }

    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond" }, enabled = false)
    public void testInvoicesAreCorrectlyRetrieved(String browserName) throws Exception {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage();
        makeAPaymentPage.verifyOnlyActiveInvoicesAreDisplayed().shouldBeEqual("Not all invoices displayed are active or due");
    }
    
    @Parameters("browserName")
    @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"}, description = "TC3157 : ALB: Make A Payment Screen - two payment methods check")
    public void testAvailablePaymentMethods_ALB(String browserName) {
        pagefactory.getMakeAPaymentPage().verifyAvailablePaymentMethods();
    }
    
	
	 @Parameters("browserName")
	 @Test(groups = {"Emerald","Ferrite","Granite" , "Diamond"  }, description = "TC3158: Amount To Pay - alphanumeric fields validation")
	 public void testPayingWithAlphanumericCharsNotPossible(String browserName) {
         MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
         makeAPaymentPage.checkInputAttributeType("number");
         makeAPaymentPage.verifyPayNowButtonIsDisabled().shouldBeTrue("Pay now button is not disabled for blank payments");
	}
	 
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE" }, description = "TC3160 : 	Automatic Payments Hide Make A Payment" , enabled = false)
	public void testAutomaticPaymentsHideMakeAPaymentLink(String browserName) {
		PolicyGenerator.createBasicBoundPAPolicy();
		AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
		accountSummaryPage.goToAutomaticPayments().setupAutomaticPaymentsUsingBankCheckingAccount()
				.verifyAutoPaymentsSetupConfirmationMessage()
				.shouldBeEqual("Setup Auto payment message is not mactched");
		accountSummaryPage.goToHome().verifyMakeAPaymentNotDisplayed();
		new BillingSummaryPage().validateOverridenAutoPaymentInstrumentForBankAccount();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC6419: Payment Can't Be Made For Non-Selected Invoices")
	public void testPaymentNotPossibleWhenNoInvoiceSelected_ALB(String browserName) {
		pagefactory.getMakeAPaymentPage().unselectAllInvoices().verifyPayNowButtonIsDisabled()
				.shouldBeTrue("Pay now button is not disabled");
	}
    
}
