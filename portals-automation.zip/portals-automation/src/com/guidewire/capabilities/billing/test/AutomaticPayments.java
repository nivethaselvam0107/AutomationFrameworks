package com.guidewire.capabilities.billing.test;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.AccountSummaryPage;
import com.guidewire.capabilities.amp.model.page.Pagefactory;

public class AutomaticPayments {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

    @Parameters("browserName")
    @Test(groups = { "REG_EMR" ,  "REG_DIA"}, enabled = false)
    public void testSetupAutomaticPaymentsBillingTab(String browserName) {
        logger.info("Running Test: AMP-022 Verify Setup Automatic Payment page on Billing Summary Page");
        AccountSummaryPage accountSummaryPage = pagefactory.getAccountSummaryPage();
        accountSummaryPage.goToBillingSummaryPage().goToAutomaticPaymentsPage().validateFieldsAndCancel().shouldBeTrue("Failed to cancel automatic payments setup");
    }
}
