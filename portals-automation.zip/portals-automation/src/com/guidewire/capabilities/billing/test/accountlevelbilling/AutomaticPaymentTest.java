package com.guidewire.capabilities.billing.test.accountlevelbilling;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.AutomaticPaymentsPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.data.DataFetch;
import com.guidewire.data.PolicyData;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class AutomaticPaymentTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC3152: ALB - Setup Automatic Payments Bank Account Checking")
	public void testSetupAutomaticPaymentsCheckingBankAccount(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		DataFetch.setAccountBillingLevel(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()));
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6822: ALB - Setup Automatic Payments Bank Account Saving")
	public void testPASetupAutomaticPaymentsSavingBankAccount(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6823: ALB - Setup Automatic Payment Credit Card")
	public void testPASetupAutomaticPaymentsCreditCard(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6824: ALB: Change Payment Instrument Bank Checking to Credit Card")
	public void testPAChangeAutomaticPaymentsFromBankCheckingToCreditCard(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6826: ALB: Change Payment Instrument Bank Checking to Bank Saving")
	public void testPAChangeAutomaticPaymentsFromCheckingBankToSavingBankAccount(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6827: ALB- Change Payment Instrument - Bank Saving to Credit Card")
	public void testPAChangeAutomaticPaymentsFromBankSavingToCreditCard(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6814: ALB: Change Payment Instrument - Bank Saving to Bank Checking")
	public void testPAChangeAutomaticPaymentsFromBankSavingToBankChecking(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6825: 	ALB: Change Payment Instrument Credit Card - Mandatory Validation")
	public void testPASetupAutomaticPaymentsCreditCardMandatoryFields(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateBankDataSaved();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.setupCreditCardData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6830: 	ALB: Change Payment Instrument - Credit Card to Bank Checking - Mandatory Validation")
	public void testPAAutomaticPaymentsBankMandatoryFields(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateCreditCardDataSaved();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.setupBankSavingData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6831: 	ALB: Change Payment Instrument - Credit Card to Bank Checking")
	public void testPAChangeAutomaticPaymentsFromCreditCardToBankChecking(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6832: 	ALB: Change Payment Instrument- Credit Card to Bank Saving")
	public void testPAChangeAutomaticPaymentsFromCreditCardToBankSaving(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "PA Make Payment - Bank Account Checking Method")
	public void testPAMakeAPaymentCheckingBankAccount(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankCheckingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6391: 	PA Make Payment - Credit Card")
	public void testPAMakeAPaymentCreditCard(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithCreditCard()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6393: 	PA Make Payment - Bank Account Saving")
	public void testPAMakeAPaymentSavingBankAccount(String browserName) {
		this.createPolicyAndSetBillingAsAccountLevel();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankSavingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}

	 private void createPolicyAndSetBillingAsAccountLevel() {
		 PolicyGenerator.createBasicBoundPAPolicy();
		 try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		 if(!System.getProperty("platform").equalsIgnoreCase("Diamond")){
			 DataFetch.setAccountBillingLevel(ThreadLocalObject.getData().get(PolicyData.ACCOUNT_NUMBER.toString()));
		 }			 
	 }
}
