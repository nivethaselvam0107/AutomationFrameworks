package com.guidewire.capabilities.billing.test.policylevelbilling;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.AutomaticPaymentsPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HOPAutomaticPaymentTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6915: HOP Policy - Setup Automatic Payments Bank Account Checking")
	public void testHOPSetupAutomaticPaymentsCheckingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6916: HOP Policy - HO Policy - Setup Automatic Payments Bank Account Saving")
	public void testHOPSetupAutomaticPaymentsSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6917: HOP Policy - HO Policy - Setup Automatic Payment Credit Card")
	public void testHOPSetupAutomaticPaymentsCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6918: HOP Policy: Change Payment Instrument Bank Checking to Credit Card")
	public void testHOPChangeAutomaticPaymentsFromBankCheckingToCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6920: HOP: Change Payment Instrument Bank Checking to Bank Saving")
	public void testHOPChangeAutomaticPaymentsFromCheckingBankToSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6921: HOP - Change Payment Instrument - Bank Saving to Credit Card")
	public void testHOPChangeAutomaticPaymentsFromBankSavingToCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6922: HOP - Change Payment Instrument - Bank Saving to Bank Checking")
	public void testHOPChangeAutomaticPaymentsFromBankSavingToBankChecking(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6919: 	HOP Policy: Change Payment Instrument Credit Card - Mandatory Validation")
	public void testHOPSetupAutomaticPaymentsCreditCardMandatoryFields(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateBankDataSaved();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.setupCreditCardData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6923: 	HOP: Change Payment Instrument - Credit Card to Bank Checking - Mandatory Validation")
	public void testHOPAutomaticPaymentsBankMandatoryFields(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateCreditCardDataSaved();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.setupBankCheckingData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6924: 	HOP: Change Payment Instrument - Credit Card to Bank Checking")
	public void testHOPChangeAutomaticPaymentsFromCreditCardToBankChecking(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6925: 	HOP: Change Payment Instrument- Credit Card to Bank Saving")
	public void testHOPChangeAutomaticPaymentsFromCreditCardToBankSaving(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not mactched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6926: HOP Make Payment - Bank Account Checking")
	public void testHOPMakeAPaymentCheckingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankCheckingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6927: 	HOP Make Payment - Credit Card")
	public void testHOPMakeAPaymentCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithCreditCard()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}
	
	@Parameters("browserName")
	@Test(groups = { "HOP" }, description = "TC6928: 	HOP Make Payment - Bank Account Saving")
	public void testHOPMakeAPaymentSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankSavingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}
	
	 @Parameters("browserName")
	 @Test(groups = {"HOP" }, description = "TC6930: HO Policy: Amount To Pay - alphanumeric fields validation")
	 public void testPayingWithAlphanumericCharsNotPossible(String browserName) {
		   pagefactory.getBillingSummaryPage()
	    		.selectPolicy()
	    		.clickOnMakePaymentLink()
	    		.changeAmount()
	    		.changeSourceType()
	    		.verifyErrorMessage(DataConstant.MUST_BE_NUMBER_TEXT)
	    		.shouldBeEqual("Wrong error message");
	  }
	 
	 
}
