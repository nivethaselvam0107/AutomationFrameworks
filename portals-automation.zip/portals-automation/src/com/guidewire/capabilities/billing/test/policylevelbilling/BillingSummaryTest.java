package com.guidewire.capabilities.billing.test.policylevelbilling;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.capabilities.common.model.page.AuthorisationServer;
import com.guidewire.common.selenium.ThreadLocalObject;
import com.guidewire.common.testNG.Validation;
import com.guidewire.common.util.DataFormatUtil;
import com.guidewire.data.DataFetch;
import io.restassured.path.json.JsonPath;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BillingSummaryTest {

    Pagefactory pagefactory = new Pagefactory();

    @Parameters("browserName")
    @Test(groups = { "Emerald","Ferrite","Granite", "Diamond", "SMOKE"}, description = "TC12499: PLB - show plb policies on billing summary")
    public void testMultiAccountPoliciesWithPLBVisibleOnBillingSummary(String browserName) {
        List<String> policies = new ArrayList<>();
        policies.add(PolicyGenerator.createBasicBoundPAPolicy());
        policies.add(PolicyGenerator.createBasicBoundHOPolicy());
        policies.add(PolicyGenerator.createBasicBoundWCPolicy());
        policies.add(PolicyGenerator.createBasicBoundBOPolicy());
        Collections.sort(policies);

        policies.forEach( policyNum -> {
            JsonPath path = new JsonPath(DataFetch.getAgentPolicyDataAsSU(policyNum));
            String accountNumber = DataFormatUtil.getNodeValue(path,"account", "accountNumber");
            AuthorisationServer.assignAccountCodeToExistingUser(ThreadLocalObject.getData().get("USER"), accountNumber);
        });


        BillingSummaryPage billingSummaryPage = pagefactory.getBillingSummaryPage();

        new Validation(billingSummaryPage.getPolicyNumbersFromTiles(), policies).shouldBeEqual("The policy numbers didn't match");
    }
}
