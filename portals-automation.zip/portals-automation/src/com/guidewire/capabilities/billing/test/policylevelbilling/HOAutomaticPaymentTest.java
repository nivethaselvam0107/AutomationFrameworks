package com.guidewire.capabilities.billing.test.policylevelbilling;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.AutomaticPaymentsPage;
import com.guidewire.capabilities.billing.model.page.BillingSummaryPage;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.capabilities.common.model.generator.PolicyGenerator;
import com.guidewire.data.DataConstant;
import com.guidewire.portals.qnb.pages.PaymentDetailsPage;

/**
 * @author dgangwar@guidewire.com
 *
 */
public class HOAutomaticPaymentTest {

	Pagefactory pagefactory = new Pagefactory();
	Logger logger = Logger.getLogger(this.getClass().getName());

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6765: HO Policy - Setup Automatic Payments Bank Account Checking")
	public void testHOSetupAutomaticPaymentsCheckingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
		billingSummaryPage.validateDefaultPaymentInstrumentForAccount().shouldBeEqual("Default instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6764: HO Policy - HO Policy - Setup Automatic Payments Bank Account Saving")
	public void testHOSetupAutomaticPaymentsSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
		billingSummaryPage.validateDefaultPaymentInstrumentForAccount().shouldBeEqual("Default instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6763: HO Policy - HO Policy - Setup Automatic Payment Credit Card")
	public void testHOSetupAutomaticPaymentsCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched");
		billingSummaryPage.validateDefaultPaymentInstrumentForAccount().shouldBeEqual("Default instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6810: HO Policy: Change Payment Instrument Bank Checking to Credit Card")
	public void testHOChangeAutomaticPaymentsFromBankCheckingToCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6813: HO: Change Payment Instrument Bank Checking to Bank Saving")
	public void testHOChangeAutomaticPaymentsFromCheckingBankToSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6812: HO - Change Payment Instrument - Bank Saving to Credit Card")
	public void testHOChangeAutomaticPaymentsFromBankSavingToCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForCreditCard().shouldBeEqual("Override instrument value is not matched for credit card");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6828: HO: Change Payment Instrument - Bank Saving to Bank Checking")
	public void testHOChangeAutomaticPaymentsFromBankSavingToBankChecking(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6811: 	HO Policy: Change Payment Instrument Credit Card - Mandatory Validation")
	public void testHOSetupAutomaticPaymentsCreditCardMandatoryFields(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateBankDataSaved();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setCreditCardPaymentMethod();
		autoPayPage.setupCreditCardData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6817: 	HO: Change Payment Instrument - Credit Card to Bank Checking - Mandatory Validation")
	public void testHOAutomaticPaymentsBankMandatoryFields(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		AutomaticPaymentsPage autoPayPage = billingSummaryPage.clickOnChangePaymentMethodLink();
		autoPayPage.validateCreditCardDataSaved();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldBeEqual();
		new PaymentDetailsPage().setBankPaymentMethod();
		autoPayPage.setupBankSavingData();
		autoPayPage.isSetUpOrChangeAutomaticPaymentsButtonIsDisabled().shouldNotBeEqual();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6815: 	HO: Change Payment Instrument - Credit Card to Bank Checking")
	public void testHOChangeAutomaticPaymentsFromCreditCardToBankChecking(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankCheckingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6818: 	HO: Change Payment Instrument- Credit Card to Bank Saving")
	public void testHOChangeAutomaticPaymentsFromCreditCardToBankSaving(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
			.selectPolicy()
			.goToAutomaticPaymentsPage()
			.setupAutomaticPaymentsUsingCreditCard()
			.verifyAutoPaymentsSetupConfirmationMessage()
			.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.clickOnChangePaymentMethodLink()
			.setupAutomaticPaymentsUsingBankSavingAccount()
			.verifyAutoPaymentsSetupChangedMessage()
        	.shouldBeEqual();
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC1992: HO Make Payment - Bank Account Checking")
	public void testHOMakeAPaymentCheckingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankCheckingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6398: 	HO Make Payment - Credit Card")
	public void testHOMakeAPaymentCreditCard(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithCreditCard()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite" }, description = "TC6386: 	HO Make Payment - Bank Account Saving")
	public void testHOMakeAPaymentSavingBankAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		MakeAPaymentPage makeApayment =
				billingSummaryPage
				.selectPolicy()
				.clickOnMakePaymentLink()
				.unselectAllInvoices();
		String invoicePaidValue = makeApayment.selectFirstInvoices();
		makeApayment
			.payWithBankSavingAccount()
			.verifyInvoicePaymentAppliedMessage(invoicePaidValue);
		billingSummaryPage.validateLastPaymentMadeAccount(invoicePaidValue).shouldBeEqual();
	}

	 @Parameters("browserName")
	 @Test(groups = {"Emerald","Ferrite","Granite" }, description = "TC6762: HO Policy: Amount To Pay - alphanumeric fields validation")
	 public void testPayingWithAlphanumericCharsNotPossible(String browserName) {
		 PolicyGenerator.createBasicBoundHOPolicy();
		   pagefactory.getBillingSummaryPage()
	    		.selectPolicy()
	    		.clickOnMakePaymentLink()
	    		.checkInputAttributeType("number");
	  }

	@Parameters("browserName")
	@Test(groups = { "Emerald","Ferrite","Granite", "Diamond" }, description = "TC13033: PLB - HO make a payment with multi-account policies")
	public void testHOSetupAutomaticPaymentsCheckingBankAccountOnMultiAccount(String browserName) {
		PolicyGenerator.createBasicBoundHOPolicy();
		PolicyGenerator.createBasicBoundHOPolicy();
		BillingSummaryPage billingSummaryPage = pagefactory.getAccountSummaryPage().goToBillingSummaryPage();
		billingSummaryPage
				.selectPolicy()
				.goToAutomaticPaymentsPage()
				.setupAutomaticPaymentsUsingBankCheckingAccount()
				.verifyAutoPaymentsSetupConfirmationMessage()
				.shouldBeEqual("Setup Auto payment message is not matched");
		billingSummaryPage.validateOverridenAutoPaymentInstrumentForBankAccount().shouldBeEqual("Override instrument value is not matched for bank account");
		billingSummaryPage.validateDefaultPaymentInstrumentForAccount().shouldBeEqual("Default instrument value is not matched for bank account");
	}
}
