package com.guidewire.capabilities.billing.test.policylevelbilling;

import org.apache.log4j.Logger;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.guidewire.capabilities.amp.model.page.Pagefactory;
import com.guidewire.capabilities.billing.model.page.MakeAPaymentPage;
import com.guidewire.data.DataConstant;

public class MakeAPaymentTest {

    Pagefactory pagefactory = new Pagefactory();
    Logger logger = Logger.getLogger(this.getClass().getName());

  
    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"}, description = "TC6384: Overpay verification")
    public void testOverpayNotPossible(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyErrorMessage(DataConstant.OVERPAY_ERROR_TEXT).shouldBeEqual("Wrong error message");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"}, description = "TC6385: 0 Payment Validation")
    public void testPayingZeroNotPossible_PLB(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyErrorMessage(DataConstant.POSITIVE_PAYMENT_TEXT).shouldBeEqual("Wrong error message");
    }
    
    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"} , description = "TC3159: Payment Can't Be Made For Non-Selected Invoices")
    public void testPaymentNotPossibleWhenNoInvoiceSelected_PLB(String browserName) {
    	pagefactory.getMakeAPaymentPage().unselectAllInvoices().verifyPayNowButtonIsDisabled().shouldBeTrue("Pay now button is not disabled");
    }

    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA" })
    public void testPayingBlankNotPossible(String browserName) {
        MakeAPaymentPage makeAPaymentPage = pagefactory.getMakeAPaymentPage().changeAmount().changeSourceType();
        makeAPaymentPage.verifyErrorMessage(DataConstant.MUST_BE_NUMBER_TEXT).shouldBeEqual("Wrong error message");
    }
    
    @Parameters("browserName")
    @Test(groups = {"REG_EMR" , "REG_DIA"}, description = "TC6653 : ALB: PLB: Make A Payment Screen - two payment methods check")
    public void testAvailablePaymentMethods_PLB(String browserName) {
        pagefactory.getMakeAPaymentPage().verifyAvailablePaymentMethods();
    }
}
