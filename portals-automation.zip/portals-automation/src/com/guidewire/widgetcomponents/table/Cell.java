package com.guidewire.widgetcomponents.table;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.guidewire.widgetcomponents.Control;
import com.guidewire.widgetcomponents.Select;
import com.guidewire.widgetcomponents.form.CheckBox;

public class Cell {
    private WebElement cell;

    public Cell(WebElement cell) {
        this.cell = cell;
    }

    public String getText() {
        return this.cell.getText();
    }

    public WebElement getElement() {
        return this.cell;
    }

    public boolean equals(Cell otherCell) {
        return this.getElement().equals(otherCell.getElement());
    }
    
    public void setValue(String value) {
        this.findControl().setValue(value);
    }
    
    private Control findControl() {
        try {
            return new Select(this.cell.findElement(By.cssSelector("select")));
        } catch(NoSuchElementException ignored) {}

        try {
            return new CheckBox(this.cell.findElement(By.cssSelector("input")));
        } catch(NoSuchElementException ignored) {}
        
        try {
            //TODO: implement for datepicker
        } catch(NoSuchElementException ignored) {}

        throw new Error("Actual control not found");
    }
}
