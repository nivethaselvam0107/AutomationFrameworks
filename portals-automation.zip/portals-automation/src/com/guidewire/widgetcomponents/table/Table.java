package com.guidewire.widgetcomponents.table;

import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Table implements Iterable<Row> {
    private final By RowLocator = By.xpath("./tbody/tr");
    private Row header;
    private WebElement table;

    public Table(WebElement table) {
        this.table = table;
    }

    public int size() {
        return this.table.findElements(RowLocator).size();
    }

    public Row getHeader() {
        if (this.header != null) {
            return this.header;
        }

        this.header = new Row(this.table.findElement(By.xpath("./thead/tr")));
        return this.header;
    }

    public Row getRowByIndex(int index) {
        return new Row(this.table.findElement(By.xpath(String.format("./tbody/tr[%d]", index + 1))), this.getHeader());
    }

    public List<Row> getRows() {
        List<WebElement> elements = this.table.findElements(RowLocator);
        return elements
                .stream()
                .map(x -> new Row(x, this.getHeader()))
                .collect(Collectors.toList());
    }

    public Row find(Predicate<Row> condition) {
        return StreamSupport.stream(this.spliterator(), false)
                .filter(condition)
                .findAny()
                .get();
    }
    
    public Cell findByTitle(WebElement table, String title) {
    		String td = "td[title ='TITLE']".replace("TITLE", title);
        return new Cell(table.findElement(By.cssSelector(td)));
    }
    
    public WebElement findByInputSelector(WebElement table, String title) {
		String td = "td[title ='TITLE']".replace("TITLE", title);
    return table.findElement(By.cssSelector(td));
}

    @Override
    public Iterator<Row> iterator() {
        return new TableIterator(this);
    }
}

class TableIterator implements Iterator<Row> {
    private final List<Row> rows;
    private int currentCellIndex = 0;
    private final int tableSize;

    public TableIterator(Table table) {
        this.tableSize = table.size();
        this.rows = table.getRows();
    }

    @Override
    public boolean hasNext() {
        return this.currentCellIndex < this.tableSize;
    }

    @Override
    public Row next() {
        return this.rows.get(this.currentCellIndex++);
    }
}