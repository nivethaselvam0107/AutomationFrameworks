package com.guidewire.widgetcomponents.table;

import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Row implements Iterable<Cell> {
    private final By CellLocator = By.xpath("./td|./th");
    private WebElement row;
    private Row heading;

    public Row(WebElement row) {
        this.row = row;
    }

    public Row(WebElement row, Row heading) {
        this.row = row;
        this.heading = heading;
    }

    public int size() {
        return this.row.findElements(CellLocator).size();
    }

    public List<Cell> getCells() {
        List<WebElement> elements = this.row.findElements(CellLocator);
        return elements
                .stream()
                .map(Cell::new)
                .collect(Collectors.toList());
    }

    public Cell getCellByIndex(int index) {
        index++; //Did you know xpath indices are 1-based?
        return new Cell(this.row.findElement(By.xpath(String.format("./td[%d]|./th[%d]", index, index))));
    }

    public int getIndexOf(Cell cell) {
        List<Cell> cells = this.getCells();
        for (int index = 0; index < cells.size(); index++) {
            Cell otherCell = cells.get(index);
            if (otherCell.equals(cell)) {
                return index;
            }
        }

        return -1;
    }

    public Cell find(Predicate<Cell> condition) {
        return StreamSupport.stream(this.spliterator(), false)
                .filter(condition)
                .findAny()
                .get();
    }

    public Cell findInColumn(Predicate<Cell> condition) {
        Cell headingCell = StreamSupport.stream(this.heading.spliterator(), false)
                .filter(condition)
                .findAny()
                .get();
        return this.getCellByIndex(this.heading.getIndexOf(headingCell));
    }

    public Cell getCellByColumnTitle(String title) {
        return this.findInColumn(cell -> cell.getText().equals(title));
    }

    @Override
    public Iterator<Cell> iterator() {
        return new CellIterator(this);
    }
}

class CellIterator implements Iterator<Cell> {
    private final List<Cell> cells;
    private int currentCellIndex = 0;
    private int rowSize;

    public CellIterator(Row row) {
        this.cells = row.getCells();
        this.rowSize = row.size();
    }

    @Override
    public boolean hasNext() {
        return this.currentCellIndex < this.rowSize;
    }

    @Override
    public Cell next() {
        return cells.get(this.currentCellIndex++);
    }
}