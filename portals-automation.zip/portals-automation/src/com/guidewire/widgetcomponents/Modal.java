package com.guidewire.widgetcomponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;

public class Modal {
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    @FindBy(css = "[class*='gw-modal'] span[ng-class='iconClass']")
    static WebElement MODAL;

    @FindBy(css = "[class*='gw-modal'] button[ng-click='$close(optionsModel)']") //TODO: this selector is bad
    static WebElement MODAL_CONFIRM_BTN;

    @FindBy(css = "[ng-click*='dismiss']")
    static WebElement MODAL_DISMISS_BTN;
    
    @FindBy(css = "[class*='gw-modal'] p")
    static WebElement MODAL_MESSAGE;

    By MODEL_CSS = By.cssSelector("[ng-click='$close(optionsModel)']");

    public Modal() {
            seleniumCommands.pageWebElementLoader(this);
    }

    public void confirm() {
        if(seleniumCommands.isElementPresent(MODEL_CSS)) {
            new Button(MODAL_CONFIRM_BTN).click();
            Modal.waitHidden();
        }
    }
    
    public void dismiss() {
        if(seleniumCommands.isElementPresent(MODEL_CSS)) {
            new Button(MODAL_DISMISS_BTN).click();
            Modal.waitHidden();
        }
    }

    public static void waitHidden() {
        //I couldn't make findElement condition to work properly for nonexistent backdrop
        //but there's a class on body when modal is open, I'll rely on that.
        SeleniumCommands seleniumCommands = new SeleniumCommands();
        seleniumCommands.waitForElementToNotHaveClass(seleniumCommands.findElement(By.tagName("body")), "gw-modal-open");
    }
    
    public void validateModelMessage(String message) {
    		seleniumCommands.pageWebElementLoader(this);
       new Validation(seleniumCommands.getTextAtLocator(MODAL_MESSAGE), message).shouldBeEqual("Model message is not matched");
    }
}
