package com.guidewire.widgetcomponents;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;

public class Select implements Control {
    WebElement select;
    SeleniumCommands seleniumCommands = new SeleniumCommands();
	final static String SELECT_XPATH = "//select";

    public Select(WebElement select) {
        this.select = select;
    }
    
    public Select() {
    }

    @Override
    public String getValue() {
        return seleniumCommands.getSelectedOptionFromDropDown(this.select);
    }

    @Override
    public void setValue(String text) {
        seleniumCommands.selectDropDownValueByText(this.select, text);
    }

    @Override
    public WebElement getElement() {
        return this.select;
    }
    
    public List<WebElement> getAlISelectElements() {
    		return seleniumCommands.findElements(By.xpath(SELECT_XPATH));
    }
    
}