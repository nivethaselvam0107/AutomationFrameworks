package com.guidewire.widgetcomponents;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;

public class Button {
	Logger logger = Logger.getLogger(this.getClass().getName());
	WebElement button;
	String buttonProp;
	String buttonPropValue;
	final static String BUTTON_XPATH = "//button";
	static SeleniumCommands seleniumCommands = new SeleniumCommands();

	public Button(WebElement button) {
		seleniumCommands.pageWebElementLoader(this);
		this.button = button;
	}
	
	public Button() {
	}

	public Button(String property, String value) {
		this.buttonProp = property;
		this.buttonPropValue = value;
	}
	
	public void click() {
		logger.info("Clicking the button");
		seleniumCommands.clickbyJS(button);
	}

	public void isEnabled(String message) {
		logger.info("Checking if element is enabled");
		new Validation(false).shouldBeEqual("This method is not implemented yet");
		;
	}

	public void isDisabled(String message) {
		logger.info("Checking if element is enabled");
		new Validation( this.button.getAttribute("disabled"), "true").shouldBeEqual(message);
		;
	}

	public void clickbyProperty(String buttonProp, String buttonPropValue ) {
		logger.info("Clicking the button using property :" + buttonProp);
		seleniumCommands.clickbyJS(this.searchButton(buttonProp, buttonPropValue));
	}
	
	 private static List<WebElement> getAlIButtons() {
	    	return seleniumCommands.findElements(By.xpath(BUTTON_XPATH));
	    }

	 private static WebElement searchButton(String property, String value) {
	    	 for (WebElement button : getAlIButtons()) {
	             if (button.getAttribute(property).equals(value)) {
	            	 	return button;
	             }
	    	 	}
	    	 return null;
	    }
}
