package com.guidewire.widgetcomponents.tile;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.common.testNG.Validation;
import com.guidewire.widgetcomponents.Button;

public class DateTimeTile {
	Logger logger = Logger.getLogger(this.getClass().getName());

	@FindBy(css = "[ng-click='increaseMonth()']")
	WebElement INCREASE_MONTH;

	@FindBy(css = "[ng-click='decreaseMonth()']")
	WebElement DECREASE_MONTH;

	@FindBy(css = "[ng-click='increaseDay()']")
	WebElement INCREASE_DAY;

	@FindBy(css = "[ng-click='decreaseDay()]")
	WebElement DECREASE_DAY;

	@FindBy(css = "[ng-click='decreaseYear()']")
	WebElement DECREASE_YEAR;

	@FindBy(css = "[ng-click='increaseYear()']")
	WebElement INCREASE_YEAR;
	
	@FindBy(css = "gw-date-tile[max-date]")
	WebElement DATE_TILE;

	String MONTH_AND_YEAR_VALUE = "[class*='month-and-year']";
	String DAY_VALUE = "[class*='day-of-month']";
	String YEAR_VALUE = "[class*='bottom-row '] span";

	String DATE_TILE_CSS = "gw-date-tile";

	WebElement dateTile;

	SeleniumCommands seleniumCommands = new SeleniumCommands();

	public DateTimeTile() {
		seleniumCommands.waitForLoaderToDisappearFromPage();
		seleniumCommands.waitForElementToBeVisible(By.cssSelector(DATE_TILE_CSS));
		seleniumCommands.pageWebElementLoader(this);
	}

	public String setFutureDate() {
		new Button(INCREASE_MONTH).click();
		return this.getSelectedDate();
	}
	
	public String setPastDate() {
		new Button(DECREASE_MONTH).click();
		return this.getSelectedDate();
	}

	private String getMonthFromTile() {
		return seleniumCommands.getTextAtLocator(By.cssSelector(MONTH_AND_YEAR_VALUE)).split(" ")[0];
	}

	private String getDayOfMonthFromTile() {
		String day = seleniumCommands.getTextAtLocator(By.cssSelector(DAY_VALUE));;
//		if(day.length()==1)
//		{
//			return day;
//		}
		return  day;
	}

	private String getYearFromTile() {
		return seleniumCommands.getTextAtLocator(By.cssSelector(MONTH_AND_YEAR_VALUE)).split(" ")[1];
	}

	public String getSelectedDate() {
		return this.getMonthFromTile() +" "+ getDayOfMonthFromTile() + ", " + getYearFromTile();
	}

	private String getMonthValue(String monthText) {
		for (Month m : Month.values()) {
			if (m.name().equals(monthText)) {
				return m.getValue();
			}
		}
		return null;
	}

	public Validation isDateSetToPastDate(String effectiveDate, String newDate){
		return new Validation(newDate, effectiveDate);
	}
}

enum Month {
	JAN("01"), FEB("02"), MAR("03"), APR("04"), MAY("05"), JUN("06"), JUL("07"), AUG("08"), SEP("09"), OCT("10"), NOV("11"), DEC("12");

	private String month;

	private Month(String value) {
		this.month = value;
	}

	public String getValue() {
		return month;
	}
}
