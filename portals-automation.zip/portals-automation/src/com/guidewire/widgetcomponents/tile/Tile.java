package com.guidewire.widgetcomponents.tile;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;

public class Tile {
	Logger logger = Logger.getLogger(this.getClass().getName());
	WebElement tileElement;
	String propName;
	String propValue;
	final static String TILE_XPATH = "//gw-wizard-tile[contains(@class,'gw-endorsement-tile')]";
	static SeleniumCommands seleniumCommands = new SeleniumCommands();

	public Tile(WebElement tileElement) {
		seleniumCommands.pageWebElementLoader(this);
		this.tileElement = tileElement;
	}

	public Tile() {
	}

	public Tile(String property, String value) {
		this.propName = property;
		this.propValue = value;
	}

	public void click() {
		logger.info("Clicking the tile");
		seleniumCommands.clickbyJS(tileElement);
	}

	private List<WebElement> getAlITiles() {
		logger.info("Finding all tiles on the page");
		return seleniumCommands.findElements(By.xpath(TILE_XPATH));
	}
	
	public void waitForTileToBeSelected() {
		logger.info("Waiting for tile to be selected");
		seleniumCommands.waitForElementToHaveClass(tileElement, "active");
	}

	public WebElement getTileByProperty(String propName, String propValue) {
		logger.info("Selecting tile based on property : " + propName);
		WebElement tileEle = null;
		for (WebElement tile : getAlITiles()) {
			
			try {
				if (tile.getAttribute(propName).equals(propValue)) {
					tileEle =  tile;
					logger.info("Tile is found by property " + propValue) ;
					return tileEle;
				}
			} catch (Exception e) {
				logger.info("Tile element did not had propName attribute. Going for next iteration.");
			}
		}
		return tileEle;
	}

}
