package com.guidewire.widgetcomponents;

import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;

public class CancelWithModalConfirmation {
    WebElement cancelButton;
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public CancelWithModalConfirmation(WebElement cancelButton) {
        this.cancelButton = cancelButton;
    }

    public void cancel() {
        seleniumCommands.click(this.cancelButton);
        new Modal().confirm();
    }
}
