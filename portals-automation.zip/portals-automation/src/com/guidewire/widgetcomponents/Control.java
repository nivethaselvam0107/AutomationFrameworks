package com.guidewire.widgetcomponents;

import org.openqa.selenium.WebElement;

public interface Control {
    String getValue();
    void setValue(String text);
    WebElement getElement();
}
