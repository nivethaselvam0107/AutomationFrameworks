package com.guidewire.widgetcomponents;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;
public class Div 
{
		Logger logger = Logger.getLogger(this.getClass().getName());
		WebElement div;
		String prop;
		String propValue;
		static SeleniumCommands seleniumCommands = new SeleniumCommands();

		public Div(WebElement div) {
			seleniumCommands.pageWebElementLoader(this);
			this.div = div;
		}

		public String getText() {
			logger.info("Getting text value");
			return seleniumCommands.getTextAtLocator(div).replaceAll("[$,]", "");
		}
}
