package com.guidewire.widgetcomponents.form;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;

public class ViewModelForm {
    WebElement form;
    SeleniumCommands seleniumCommands = new SeleniumCommands();

    public ViewModelForm(WebElement form) {
        if (!(form.getTagName().equals("ng-form") || form.getTagName().equals("form"))) {
            throw new Error("ng-form or form expected");
        }
        this.form = form;
        seleniumCommands.waitForElementToBeVisible(form);
    }

    public List<ViewModelInput> getAllInputs() {
        return this.form.findElements(getInputSelector(null)).stream().map(ViewModelInput::new).collect(Collectors.toList());
    }

    public List<ViewModelInput> getAllRequiredInputs() {
        List<ViewModelInput> requiredFields = getAllInputs();
        requiredFields.removeIf(input -> !input.isRequiredField());
        return requiredFields;
    }

    public ViewModelInput getInputByModel(String modelName) {
        By selector = getInputSelector(modelName);
        seleniumCommands.waitForElementToBeVisible(selector);

        return new ViewModelInput(
                this.form.findElement(
                        selector
                )
        );
    }

    public boolean isShowingAnyErrors() {
        for (ViewModelInput input : this.getAllInputs()) {
            if (input.isShowingError()) {
                return true;
            }
        }

        return false;
    }

    public Object submit() {
        if(seleniumCommands.isElementPresent(By.xpath("//div[@model='contact.firstName']")) || seleniumCommands.isElementPresent(By.xpath("//*[@model='contact.contactName']"))) {
            this.form.findElement(By.xpath("//button[@type='submit']")).click();
        }else{
            this.form.findElement(By.xpath("//button[@type='submit button']")).click();
        }
        return null;
    }

    public Object search() {
        this.form.findElement(By.xpath("//button[@value='Search']")).click();
        return null;
    }

    private static By getInputSelector(String modelName) {
        //Find such gw-pl-input-ctrl that has model attribute ending with modelName
        String modelAttrSelector = modelName != null ? String.format("[model*='%s']", modelName) : "";

        String[] expectedDirectives = {"gw-pl-input-ctrl", "gw-pl-ctrl-group"};
        List<String> mappedDirectives = new ArrayList<>();

        for (String directive : expectedDirectives) {
            mappedDirectives.add(
                    directive + modelAttrSelector + //Element + model: gw-pl-input-ctrl[model$='%s']
                            ", " +
                            String.format("[%s]", directive) + modelAttrSelector //Attribute + model: [gw-pl-input-ctrl][model$='%s']
            );
        }

        return By.cssSelector(StringUtils.join(mappedDirectives, ", "));
    }
}
