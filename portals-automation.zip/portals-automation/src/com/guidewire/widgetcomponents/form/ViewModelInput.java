package com.guidewire.widgetcomponents.form;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

import com.guidewire.widgetcomponents.Control;
import com.guidewire.widgetcomponents.Select;

public class ViewModelInput {
    WebElement inputCtrl;

    private final String REQUIRED_FIELD_CSS = ".gw-required-asterisk:not(.ng-hide)";

    public ViewModelInput(WebElement inputCtrl) {
        boolean foundExpectedDirective = false;
        String[] expectedDirectives = {"gw-pl-input-ctrl", "gw-pl-ctrl-group"};
        for (String directive : expectedDirectives) {
            if (inputCtrl.getTagName().equals(directive) || inputCtrl.getAttribute(directive) != null) {
                foundExpectedDirective = true;
                break;
            }
        }

        if (!foundExpectedDirective) {
            throw new Error(StringUtils.join(expectedDirectives, " or ") + " expected");
        }

        this.inputCtrl = inputCtrl;
    }

    private Control findControl() {
        try {
            return new Input(this.inputCtrl.findElement(By.cssSelector("input[type='text']")));
        } catch(NoSuchElementException ignored) {}

        try {
            return new Input(this.inputCtrl.findElement(By.cssSelector("input[type='number']")));
        } catch(NoSuchElementException ignored) {}

        try {
            return new Select(this.inputCtrl.findElement(By.cssSelector("select")));
        } catch(NoSuchElementException ignored) {}

        try {
            return new Input(this.inputCtrl.findElement(By.cssSelector("input[type='checkbox']")));
        } catch(NoSuchElementException ignored) {}
        
        try {
            //TODO: implement for datepicker
        } catch(NoSuchElementException ignored) {}

        throw new Error("Actual control not found");
    }

    public String getValue() {
        return this.findControl().getValue();
    }

    public WebElement getElement() {return this.inputCtrl; }

    public ViewModelInput setValue(String text) {
        this.findControl().setValue(text);
        return this;
    }

    public Control getControl() {
        return this.findControl();
    }

    public boolean isShowingError() {
        return this.isShowingError(null);
    }

    public boolean isShowingError(String text) {
        List<WebElement> elements = this.inputCtrl.findElements(By.cssSelector(".gw-error-inline"));
        if (text == null) {
            return !elements.isEmpty();
        }

        for (WebElement element : elements) {
            if (element.isDisplayed() && element.getText().equals(text)) {
                return true;
            }
        }

        return false;
    }

    public boolean isRequiredField() {
        return inputCtrl.findElements(By.cssSelector(REQUIRED_FIELD_CSS)).size() > 0;
    }

    public String getModel() {
        return inputCtrl.getAttribute("model");
    }

    public WebElement getLabel() {
        return inputCtrl.findElement(By.cssSelector("label"));
    }
}

class Input implements Control {
    WebElement input;

    public Input(WebElement input) {
        this.input = input;
    }

    @Override
    public String getValue() {
        return this.input.getAttribute("value");
    }

    @Override
    public void setValue(String text) {
        this.input.clear();
        this.input.sendKeys(text);
    }

    @Override
    public WebElement getElement() {
        return this.input;
    }
}



