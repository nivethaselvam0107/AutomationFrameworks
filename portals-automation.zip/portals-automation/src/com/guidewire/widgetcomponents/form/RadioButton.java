package com.guidewire.widgetcomponents.form;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.widgetcomponents.Control;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;

public class RadioButton implements Control {
	private final Logger LOGGER = Logger.getLogger(this.getClass().getName());
	WebElement rBt;
	private final By RADIO_LABEL_XPATH = By.xpath("./../label");
	private final String VALUE = "value";
	private final By ALL_RADIO_BTN_CSS = By.cssSelector("input[type='radio']");
	private SeleniumCommands seleniumCommands = new SeleniumCommands();

	public RadioButton(WebElement rBt) {
		this.rBt = rBt;
		seleniumCommands.waitForElementToBePresent(rBt);
	}

	public void select() {
		setValue(getValue());
	}
	
	public void deSelect() {
		setValue("false");
	}
	
	public List<WebElement> getAllRadioBtn() {
		return seleniumCommands.findElements(ALL_RADIO_BTN_CSS);
	}

	public WebElement searchByProperty(String property, String value) {
		for (WebElement ckBox : getAllRadioBtn()) {
			if (ckBox.getAttribute(property).equals(value)) {
				return ckBox;
			}
		}
		return null;
	}

	@Override
	public String getValue() {
		return this.rBt.isSelected() + "";
	}

	public boolean isSelected() {
		if (this.getValue().equals("true")) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void setValue(String value) {
		if(!(new Boolean(value) == new Boolean(this.getValue())))
		{
			seleniumCommands.clickbyJS(this.rBt.findElement(RADIO_LABEL_XPATH));
		}
	}

	@Override
	public WebElement getElement() {
		return this.rBt;
	}
}
