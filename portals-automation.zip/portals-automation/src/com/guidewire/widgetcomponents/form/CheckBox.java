package com.guidewire.widgetcomponents.form;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;
import com.guidewire.widgetcomponents.Control;;

public class CheckBox implements Control {
	Logger logger = Logger.getLogger(this.getClass().getName());
	WebElement ckBox;
	private final String CKBOX_LABEL_XPATH = "./../label";
	private final String VALUE = "value";
	private static final String ALL_CHEKBOX = "//input[@type='checkbox']";
	static SeleniumCommands seleniumCommands = new SeleniumCommands();

	public CheckBox(WebElement ckBox) {
		this.ckBox = ckBox;
		seleniumCommands.waitForElementToBePresent(ckBox);
	}

	public CheckBox() {
	}

	public void select() {
		setValue(getValue());
	}
	
	public void deSelect() {
		setValue("false");
	}
	
	public static List<WebElement> getAlICheckBox() {
		return seleniumCommands.findElements(By.xpath(ALL_CHEKBOX));
	}

	public WebElement searchByProperty(String property, String value) {
		for (WebElement ckBox : getAlICheckBox()) {
			if (ckBox.getAttribute(property).equals(value)) {
				return ckBox;
			}
		}
		return null;
	}

	@Override
	public String getValue() {
		return this.ckBox.isSelected() + "";
	}

	@Override
	public void setValue(String value) {
		if(!(new Boolean(value) == new Boolean(this.getValue())))
		{
			seleniumCommands.clickbyJS(this.ckBox.findElement(By.xpath(CKBOX_LABEL_XPATH)));
		}
	}

	@Override
	public WebElement getElement() {
		return this.ckBox;
	}

}
