package com.guidewire.widgetcomponents.form;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.guidewire.common.selenium.SeleniumCommands;

public class BinaryToggler {
    Logger logger = Logger.getLogger(this.getClass().getName());
    WebElement toggler;
    SeleniumCommands seleniumCommands = new SeleniumCommands();
    String ARIA_CHECKED = "aria-checked";
    static String RDBTN_XPATH = "input[type='radio'][id='%s']";

    public BinaryToggler(WebElement toggler) {
        if (toggler.getAttribute("gw-pl-radios-binary") == null) {
            throw new Error("gw-pl-radios-binary expected");
        }
        this.toggler = toggler;
    }
    
    public BinaryToggler() {   
    }

    public void toggleById(String id) {
        //There are several labels inside the toggler, we need to specifically look for those that are shown
        String selector = String.format("label[for*='%s']:not([class*='gw-overlap'])", id); //TODO: that's a miracelously brrittle selector, need to change that
        logger.info(String.format("Clicking on %s", selector));
        WebElement label = this.toggler.findElement(By.cssSelector(selector));
        seleniumCommands.clickbyJS(label);
    }

    public BinaryToggler toggle() {
        for (WebElement input : getInputs()) {
            if (!input.getAttribute("checked").equals("true")) {
                this.toggleById(input.getAttribute("id"));
                return this;
            }
        }
        throw new Error("No suitable label found");
    }

    public BinaryToggler toggleByValue(String desiredValue) {
        logger.info(String.format("Searching for %s", desiredValue));
        for (WebElement input : getInputs()) {
            logger.info(input.getAttribute("value"));
            if (input.getAttribute("value").equals(desiredValue)) {
                this.toggleById(input.getAttribute("id"));
                return this;
            }
        }
        throw new Error("No suitable label found");
    }

    public boolean isValueSelected() {
        return this.getSelectedValue() != null;
    }

    public String getSelectedValue() {
        for (WebElement input : getInputs()) {
            String checked = input.getAttribute("checked");
            if (checked != null && checked.equals("true")) {
                return input.getAttribute("value");
            }
        }
        return null;
    }
    
    public String getValueById() {
        for (WebElement input : getInputs()) {
            String checked = input.getAttribute("ARIA_CHECKED");
            if (checked != null && checked.equals("true")) {
                return input.getAttribute("value");
            }
        }

        return null;
    }

    private List<WebElement> getInputs() {
        return this.toggler.findElements(By.cssSelector("input[type='radio']"));
    }
    
    public WebElement getInputByID(String id) {
    		String selector = String.format(RDBTN_XPATH, id);
        return this.toggler.findElement(By.xpath(selector));
    }
}
